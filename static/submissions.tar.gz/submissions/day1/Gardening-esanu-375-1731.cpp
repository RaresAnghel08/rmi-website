/**
* user:  esanu-375
* fname: Mihai
* lname: Eșanu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:22:40.319030
*/
#include <bits/stdc++.h>

using namespace std;

void solve()
{
    int n, m, k;
    cin >> n >> m >> k;
    int ans[n+2][m+2];
    if(n == m && n/2 == k)
    {
        int bound1 = 0, bound2 = n-1, bound3 = 0, bound4 = m-1;
        for(int idx = 1; idx <= k; idx++)
        {
            for(int i = bound3; i <= bound4; i++)
            {
                ans[bound1][i] = idx;
                ans[bound2][i] = idx;
            }
            for(int i = bound1; i <= bound2; i++)
            {
                ans[i][bound3] = idx;
                ans[i][bound4] = idx;
            }
            bound1++;
            bound2--;
            bound3++;
            bound4--;
        }
        cout << "YES" << endl;
        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < m; j++)
            {
                cout << ans[i][j] << " ";
            }
            cout << endl;
        }
        return;
    }
    int idx = 1;
    for(int i = 0; i < n; i+=2)
    {
        for(int j = 0; j < m; j+=2)
        {
            if(idx > k || i+1 >= n || j+1 >= n)
            {
                cout << "NO" << endl;
                return;
            }
            ans[i][j] = idx;
            ans[i+1][j] = idx;
            ans[i][j+1] = idx;
            ans[i+1][j+1] = idx;
            idx++;
        }
    }
    if(idx <= k)
    {
        cout << "NO" << endl;
        return;
    }
    cout << "YES" << endl;
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            cout << ans[i][j] << " ";
        }
        cout << endl;
    }
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        solve();
    }
}
