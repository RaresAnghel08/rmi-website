/**
* user:  alexandru-a70
* fname: Andrei
* lname: Alexandru
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:11:33.827872
*/
#include <bits/stdc++.h> //Andrei Alexandru a.k.a Sho
#define ll long long int
#define double long double
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define aint(a) (a).begin(), (a).end()
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 998244353
#define PI 3.14159265359
#define INF 1000000005
#define LINF 1000000000000000005ll
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
ll t,n,m,k;
int32_t main(){
CODE_START;
cin>>t;
while(t--){
cin>>n>>m>>k;
if(n==1||m==1){
cout<<"NO"<<endl;
continue;
}
if(n==2&&2*k<=m){
cout<<"YES"<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
}else if(n==3&&2*k<=m){
cout<<"YES"<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
}else if(n==4&&k<=m-m%2){
if(2*k<=m){
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
for(ll i=1;i<=k;i++)
{
cout<<i<<' ';
cout<<i<<' ';
}
for(ll i=2*k+1;i<=m;i++)
{
cout<<k<<' ';
}
cout<<endl;
}else {
cout<<"YES"<<endl;
for(ll i=1;i<=m/2;i++)
{
cout<<i<<' '<<i<<' ';
}
ll x=m/2;
x*=2;
if(x<m){
ll y=m/2;
cout<<y<<endl;
}else cout<<endl;
for(ll i=1;i<=m/2;i++)
{
cout<<i<<' '<<i<<' ';
}
x=m/2;
x*=2;
if(x<m){
ll y=m/2;
cout<<y<<endl;
}else cout<<endl;
x=m/2;
for(ll i=x+1;i<=k;i++)
{
cout<<i<<' '<<i<<' ';
}
ll val=k-x;
val*=2;
for(ll i=val+1;i<=m;i++)
{
cout<<k<<' '<<k<<' ';
}
cout<<endl;
x=m/2;
for(ll i=x+1;i<=k;i++)
{
cout<<i<<' '<<i<<' ';
}
val=k-x;
val*=2;
for(ll i=val+1;i<=m;i++)
{
cout<<k<<' '<<k<<' ';
}
cout<<endl;
}
}else cout<<"NO"<<endl;
}
}
