/**
* user:  nizamutdinov-1d5
* fname: Azat
* lname: Nizamutdinov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:54:30.884372
*/
#include <algorithm>
#include <bitset>
#include <deque>
#include <iomanip>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <array>
#include <random>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <chrono>
#include <ctime>
#include <random>
#define ll long long
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
template <typename KEY> using ve = std::vector<KEY>;

using namespace std;

const ll INF = INT64_MAX;

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	ll t; cin >> t;
	while (t--) {
		ll n, m, k; cin >> n >> m >> k;
		bool w = true, b = true;
		ll N = n, M = m;
		ll h = min(n, m), r = max(n, m); n = r, m = h;
		ve<ve<ll>> v(n, ve<ll>(m));
		if (n % 2 == 0 && m % 2 == 0) {
			ll c = 1;
			if (n * m % 4 == 0 && n * m / 4 == k) {
				for (ll i = 0; i < n; i += 2) {
					for (ll j = 0; j < m; j += 2) {
						v[i][j] = c, v[i + 1][j] = c, v[i][j + 1] = c, v[i + 1][j + 1] = c, ++c;
					}
				}
				for (ll i = 0; i < n; ++i) {
					for (ll j = 0; j < n; ++j) {
						cout << v[i][j] << " ";
					} cout << "\n";
				}
			}
			else {
				ll n2 = n, n1 = 0, m2 = m, m1 = 0;
				for (ll i = 0; i < n && b && m % 2 == 0; i += 2) {
					if (max(m, n - i - 2) / 2 == k - c + 1 || max(m, n) / 2 == k - c + 1) {
						b = false;
						break;
					}
					n1 = i + 2;
					for (ll j = 0; j < m && b; j += 2) {
						v[i][j] = c, v[i + 1][j] = c, v[i][j + 1] = c, v[i + 1][j + 1] = c, ++c;
					}
					if (max(m, n - n1) / 2 == k - c + 1) {
						b = false;
						break;
					}
				}
				while ((((n2 - n1 - 1 == 1 || m2 - m1 - 1 == 1) && m2 - m1 - 1 != 1 && n2 - n1 - 1 == 1) || (n2 - n1 - 1 > 1 && m2 - m1 - 1 > 1) && !((m2 - m1) % 2 == 0 && (n2 - n1) % 2 == 0 && (m2 - m1) * (n2 - n1) / 4 == k - c + 1 && (m2 - m1) * (n2 - n1) % 4 == 0))) {
					for (ll j = m1; j < m2; ++j) v[n1][j] = c, v[n2 - 1][j] = c;
					for (ll i = n1; i < n2; ++i) v[i][m2 - 1] = c, v[i][m1] = c;
					++c;
					--n2, --m2, ++n1, ++m1;
				}
				if ((m2 - m1) * (n2 - n1) / 4 == k - c + 1 && (m2 - m1) * (n2 - n1) % 4 == 0 && c <= k && (m2 - m1) % 2 == 0 && (n2 - n1) % 2 == 0) {
					for (ll i = n1; i < n2; i += 2) {
						for (ll j = m1; j < m2; j += 2) v[i][j] = c, v[i + 1][j] = c, v[i][j + 1] = c, v[i + 1][j + 1] = c, ++c;
					}
					m1 = m2, n1 = n2;
				}
				if (!(c == k + 1 && m1 == m2 && n1 == n2)) w = false;
				if (w) {
					cout << "YES\n";
					if (N != n || M != m) {
						for (ll i = 0; i < (ll)v[0].size(); ++i) {
							for (ll j = 0; j < (ll)v.size(); ++j) {
								cout << v[j][i] << " ";
							} cout << "\n";
						}
					}
					else {
						for (ll i = 0; i < n; ++i) {
							for (ll j = 0; j < m; ++j) {
								cout << v[i][j] << " ";
							} cout << "\n";
						}
					}
				}
				else cout << "NO\n";
			}
		}
		else cout << "NO\n";
	}
}

