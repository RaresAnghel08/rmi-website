/**
* user:  kryvoviaz-45e
* fname: Illia
* lname: Kryvoviaz
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 08:26:00.308692
*/
#include <iostream>
#include <vector>
#include <queue>
#include "speedrun.h"
using namespace std;

void ST(int v, int N, int from) {
    int pos = from;
    while (N > 0) {
        setHint(v, pos, N % 2);
        N /= 2;pos++;
    }
}
vector<int> g[1010];

int n;
int L1 = -1, L2 = -1;
void dfs(int v, int pred) {
    for (auto to : g[v]) {
        if (to == pred)continue;
        dfs(to, v);
    }
    if (g[v].size() == 1) {
        if (L1 == -1)L1 = v;
        else L2 = v;
    }
}

bool Tp[3][1010];
vector<int> sv[1010];
void assignHints(int subtask, int N, int A[], int B[]) {
    if (subtask == 2) {
        setHintLen(12);
        for (int II = 1, q, ok = true; II <= 2; II++) {
            if (II == 1)q = A[1];
            else q = B[1];
            for (int i = 2; i < N; i++) {if (q == A[i] || q == B[i])continue;ok = false;break;}
            if (ok) {
                int pos = 1;
                while (q > 0) {
                    for (int i = 1; i <= N; i++)setHint(i, pos, q % 2);
                    q /= 2;pos++;
                }return;
            }
        }
        return;
    }
    setHintLen(20);
    n = N;
    for (int i = 1; i < N; i++) {
        g[A[i]].push_back(B[i]);
        g[B[i]].push_back(A[i]);
    }
    dfs(1, 1);
    sv[L1].push_back(L1);
    sv[L2].push_back(L2);

    queue<pair<int, int> > q;
    q.push({L1, 1});
    q.push({L2, 2});
    Tp[1][L1] = true;
    Tp[2][L2] = true;
    while (!q.empty()) {
        pair<int, int> v = q.front();
        q.pop();
        for (int to : g[v.first]) {
            if (Tp[v.second][to])continue;
            sv[to].push_back(v.first);
            q.push({to, v.second});
            Tp[v.second][to] = true;
        }
    }
    for (int i = 1; i <= n; i++) {
        //cout << i << " --   " << sv[i][0] << " " << sv[i][1] << endl;
        ST(i, sv[i][0], 1);
        ST(i, sv[i][1], 11);
    }
    return;
}
int GT(int from, int to) {
    int V = 0;
    for (int i = from; i <= to; i++) {
        if (getHint(i))
            V += (1ll << (i - from));
    }
    return V;
}

bool used[1010];
void speedrun(int subtask, int N, int start) {
    used[start] = true;
    int L = getLength();
    if (subtask == 2) {
        int V = 0;
        for (int i = 1; i <= L; i++) {
            if (getHint(i))
                V += (1ll << (i - 1));
        }
        if (V != start)goTo(V);
        int lst = -1;
        for (int i = 1; i <= N; i++) {
            if (i == start || i == V)continue;
            if (lst != -1)goTo(V);
            goTo(i);
            lst = i;
        }
        return;
    }
    bool cycle = true;
    for (int i = 11; i <= L; i++) {
        if (getHint(i)){cycle = false;break;}
    }
    int cur = start;
    while (true) {
        int to = GT(1, 10);
        if (to == cur)break;
        cur = to;
        goTo(to);
        used[cur] = true;
        //cout << cur << endl;
    }
    //cout << "STOP" << endl;
    while (true) {
        if (cur == start)break;

        int to = GT(11, 20);
        if (to == cur)break;
        cur = to;
        goTo(to);
        used[cur] = true;
        //cout << cur << endl;
    }
    //cout << "NEW" << endl;
    while (true) {
        int to = GT(11, 20);
        if (used[to])to = GT(1, 10);
        if (used[to])break;

        cur = to;
        goTo(to);
        used[cur] = true;
        //cout << cur << endl;
    }
    return;
}
/**
5
3 4
2 1
3 2
4 5
*/
