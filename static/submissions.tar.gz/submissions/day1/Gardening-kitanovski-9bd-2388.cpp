/**
* user:  kitanovski-9bd
* fname: Teo 
* lname: Kitanovski
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:28:40.824579
*/
#include <bits/stdc++.h>

typedef long long ll;

#define MS(x,y) memset((x), (y), sizeof((x)))
#define pb push_back
#define MN 1000000000

using namespace std;

int n,m,k;
bool ans = false;
int mat[7][7];
map<pair<pair<int,int>,int>, vector<int>> res;

pair<int,int> nextIJ (int i, int j) {
    j++;
    if (j >= m) {
        i++;
        j = 0;
    }

    if (i >= n) return {-1,-1};
    else return {i,j};
}

bool valid(int i, int j) {
    if (i >= n) return false;
    if (j >= m) return false;
    if (i < 0) return false;
    if (j < 0) return false;

    return true;
}

bool check() {
    vector<pair<int,int>> pat[7][7];
    vector<pair<int,int>> prv(k,{-1,-1});
    vector<int> cnt(k,0);

    for (int i = 0; i<n; i++) {
        for (int j = 0; j<m; j++) {
            if (valid(i,j+1) && mat[i][j] == mat[i][j+1]) pat[i][j].pb({i,j+1});
            if (valid(i,j-1) && mat[i][j] == mat[i][j-1]) pat[i][j].pb({i,j-1});
            if (valid(i+1,j) && mat[i][j] == mat[i+1][j]) pat[i][j].pb({i+1,j});
            if (valid(i-1,j) && mat[i][j] == mat[i-1][j]) pat[i][j].pb({i-1,j});

            if (cnt[mat[i][j]] == 0) prv[mat[i][j]] = {i,j};
            cnt[mat[i][j]]++;

            if (pat[i][j].size() != 2) return false;
        }
    }

    for (int i = 0; i<k; i++) {
        if (cnt[i] == 0) return false;

        queue<int> qI,qJ,qC;
        qI.push(prv[i].first);
        qJ.push(prv[i].second);
        qC.push(1);

        bool vis[n][m];
        MS(vis,0);
        vis[prv[i].first][prv[i].second] = 1;
        int maxiC = 0;

        while (!qI.empty()) {
            int i2 = qI.front(), j2 = qJ.front(), c2 = qC.front();
            qI.pop(); qJ.pop(); qC.pop();

            maxiC++;

            for (auto it:pat[i2][j2]) {
                int i3 = it.first;
                int j3 = it.second;

                if (vis[i3][j3]) continue;

                qI.push(i3);
                qJ.push(j3);
                qC.push(c2+1);
                vis[i3][j3] = 1;
            }
        }

        if (maxiC < cnt[i]) return false;
    }

    return true;
}

void rec(int i, int j) {
    if (ans) return;

    if (j >= m) {
        rec(i+1,0);
        return;
    }

    if (i >= n) {
        ans |= check();

        return;
    }

    for (int ctr = 0; ctr<k; ctr++) {
        if (ans) break;

        mat[i][j] = ctr;
        rec(i,j+1);
    }
}

int main() {
    #ifdef LOCAL_DEBUG
        fstream cin("in.txt");
    #endif

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int tt;
    cin>>tt;

    res[{{2,2},1}] = {1,1,1,1};
    res[{{2,4},2}] = {1,1,2,2,1,1,2,2};
    res[{{4,2},2}] = {1,1,1,1,2,2,2,2};
    res[{{4,4},2}] = {1,1,1,1,1,2,2,1,1,2,2,1,1,1,1,1};
    res[{{4,4},4}] = {1,1,2,2,1,1,2,2,3,3,4,4,3,3,4,4};

    for (int ttt = 0; ttt<tt; ttt++) {
//        int tb = ttt;
//        m = tb%16;
//        k = m%4;
//        m = (m-k)/4;
//        n = tb/16;

        n++; m++; k++;

        cin>>n>>m>>k;

       // cout<<n<<" "<<m<<" "<<k<<endl;

        if ( (k > n && k > m) || (n%2==1 || m%2 == 1) ) {
            cout<<"NO"<<endl;
            continue;
        }

        if (res.count({{n,m},k})) {
            auto res2 = res[{{n,m},k}];

            if (res2.size() == 0) cout<<"NO"<<endl;
            else {
                cout<<"YES"<<endl;

                for (int i = 0; i<n; i++) {
                    for (int j = 0; j<m; j++) {
                        cout<<res2[i*m+j]<<" ";
                    }
                    cout<<endl;
                }
            }

            continue;
        } else {
            cout<<"NO"<<endl;
            continue;
        }

        rec(0,0);

        if (!ans) { cout<<"NO"<<endl; res[{{n,m},k}] = {}; }
        else {
            cout<<"YES"<<endl;

            vector<int> res2;

            for (int i = 0; i<n; i++) {
                for (int j = 0; j<m; j++) {
                    cout<<mat[i][j]+1<<" ";

                    res2.pb(mat[i][j]+1);
                }

                cout<<endl;
            }

            res[{{n,m},k}] = res2;
        }

        ans = false;
    }
}
