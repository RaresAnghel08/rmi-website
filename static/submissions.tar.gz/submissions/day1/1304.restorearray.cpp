/**
* user:  sisovic-018
* fname: Marko
* lname: Sisovic
* task:  restore
* score: 20.0
* date:  2019-10-10 06:13:24.539479
*/
#include <bits/stdc++.h>
using namespace std;

struct query
{
	int l,r,k,val;
} in1;

vector<bool> com;
vector<query> q;
int n,m;
bool check(vector<bool> v)
{
	for(int i=0;i<m;i++)
	{
		int zc=0;
		for(int j=q[i].l;j<=q[i].r;j++)
		{
			zc+=!v[j];
		}
		if((q[i].val==1 && zc>=q[i].k) || (q[i].val==0 && zc<q[i].k))
		{
			return false;
		}
	}
	return true;
}

int main()
{
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		com.push_back(0);
	}
	for(int i=0;i<m;i++)
	{
		cin>>in1.l>>in1.r>>in1.k>>in1.val;
		if(in1.val==1)
		{
			for(int j=in1.l;j<=in1.r;j++)
			{
				com[j]=1;
			}
		}
		q.push_back(in1);
	}
	if(n<=18)
	{
		for(int i=0;i<(1<<n);i++)
		{
			com.clear();
			for(int j=n-1;j>=0;j--)
			{
				com.push_back((i&(1<<j))>0);
			}
			if(check(com))
			{
				for(int j=0;j<n;j++)
				{
					cout<<com[j]<<" ";
				}
				return 0;
			}
		}
	}
	if(check(com))
	{
		for(int j=0;j<n;j++)
		{
			cout<<com[j]<<" ";
		}
		return 0;
	}
	cout<<-1;
	return 0;
}
