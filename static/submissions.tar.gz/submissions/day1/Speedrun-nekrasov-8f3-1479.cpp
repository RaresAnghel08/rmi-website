/**
* user:  nekrasov-8f3
* fname: Aleksandr
* lname: Nekrasov
* task:  Speedrun
* score: 63.0
* date:  2021-12-16 08:00:32.788460
*/
#include <bits/stdc++.h>
#include "speedrun.h"
using namespace std;

vector<vector<int>> g;

void dfs(int v, int p) {
    for (int i = 0; i < 10; i++) {
        if (p & (1 << i)) {
            setHint(v, i + 1, 1);
        }
    }
    vector<int> ch;
    for (int u : g[v]) {
        if (u == p)
            continue;
        ch.push_back(u);
    }
    int chv = ch.empty() ? 0 : ch[0];
    for (int i = 0; i < 10; i++) {
        if (chv & (1 << i)) {
            setHint(v, i + 11, 1);
        }
    }
    for (int i = 0; i < (int) ch.size(); i++) {
        for (int j = 0; j < 10; j++) {
            if (ch[(i + 1) % (int) ch.size()] & (1 << j)) {
                setHint(ch[i], j + 21, 1);
            }
        }
    }
    for (int u : ch)
        dfs(u, v);
}

void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(30);
    g.resize(N + 1);
    for (int i = 1; i < N; i++) {
        g[A[i]].push_back(B[i]);
        g[B[i]].push_back(A[i]);
    }
    dfs(1, 0);
    g.clear();
}
vector<int> used;


void dfsAns(int v, int p) {
    used[v] = 1;
    int ch0 = 0;
    int bro = 0;
    for (int i = 0; i < 10; i++) {
        if (getHint(i + 11)) {
            ch0 ^= 1 << i;
        }
        if (getHint(i + 21)) {
            bro ^= 1 << i;
        }
    }
    g[p].push_back(bro);
    if (ch0 == 0)
        return;
    g[v].push_back(ch0);
    int i = 0;
    while (i < (int) g[v].size()) {
        if (!used[g[v][i]]) {
            goTo(g[v][i]);
            dfsAns(g[v][i], v);     
            goTo(v);
            i++;
        } else {
            break;
        }
    }
}

void speedrun(int subtask, int N, int start) { /* your solution here */
    while (true) {
        int p = 0;
        for (int i = 0; i < 10; i++) {
            if (getHint(i + 1)) {
                p ^= 1 << i;
            }
        }
        if (p == 0 || !goTo(p))
            break;
        start = p;
    }
    used.resize(N + 1);
    g.resize(N + 1);
    dfsAns(start, 0);
    g.clear();
}
