/**
* user:  tirziu-3f9
* fname: Petre
* lname: Tirziu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:37:07.636674
*/
#include <fstream>

using namespace std;
ifstream cin("gardening.in");
ofstream cout("gardening.out");
int main()
{
    int n, i, j, k, t, m;
    cin >> t;
    while(t--){
        cin >> n >> m >> k;
        if(n == 1)
            cout << "NO\n";
        else if(n == 2){
            if((m & 1))
                cout << "NO\n";
            else{
                if(k == m / 2){
                    cout << "YES\n";
                    int cnt = 1;
                    for(i = 1; i <= m; i += 2){
                        cout << cnt << " " << cnt << " ";
                        cnt++;
                    }
                    cout << "\n";
                    cnt = 1;
                    for(i = 1; i <= m; i += 2){
                        cout << cnt << " " << cnt << " ";
                        cnt++;
                    }
                    cout << "\n";
                }
                else
                    cout << "NO\n";
            }
        }
        else if(n == 3)
            cout << "NO\n";
        else{
            if((m & 1))
                cout << "NO\n";
            else{
                if(k == m){
                    cout << "YES\n";
                    int cnt = 1;
                    for(i = 1; i <= m; i += 2){
                            cout << cnt << " " << cnt << " ";
                            cnt++;
                        }
                    cout << "\n";
                    cnt = 1;
                    for(i = 1; i <= m; i += 2){
                        cout << cnt << " " << cnt << " ";
                        cnt++;
                    }
                    cout << "\n";
                    int ccnt = cnt;
                    for(i = 1; i <= m; i += 2){
                        cout << cnt << " " << cnt << " ";
                        cnt++;
                    }
                    cout << "\n";
                    cnt = ccnt;
                    for(i = 1; i <= m; i += 2){
                        cout << cnt << " " << cnt << " ";
                        cnt++;
                    }
                    cout << "\n";
                    continue;
                }
                int cm = m - 2;
                k--;
                if(k == cm / 2 and k){
                    cout << "YES\n";
                    for(i = 1; i <= m; i++)
                        cout << "1 ";
                    cout << "\n";
                    cout << "1 ";
                    int cnt = 2;
                    for(i = 2; i <= m - 1; i += 2){
                        cout << cnt << " " << cnt << " ";
                        cnt++;
                    }
                    cout << 1;
                    cout << "\n";
                    cnt = 2;
                    cout << "1 ";
                    for(i = 2; i <= m - 1; i += 2){
                        cout << cnt << " " << cnt << " ";
                        cnt++;
                    }
                    cout << 1;
                    cout << "\n";
                    for(i = 1; i <= m; i++)
                        cout << "1 ";
                    cout << "\n";
                    continue;
                }
                cout << "NO\n";
            }
        }
    }
    return 0;
}
