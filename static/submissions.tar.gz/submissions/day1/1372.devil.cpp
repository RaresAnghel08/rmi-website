/**
* user:  popescu-96c
* fname: Ioan
* lname: Popescu
* task:  devil
* score: 14.0
* date:  2019-10-10 06:29:57.928373
*/
#include <bits/stdc++.h>
using namespace std;

char s[1000005];
int d[11];
vector <int> v[1000005];

int main()
{
//    freopen("1.in", "r", stdin);

    int t, k;
    scanf("%d", &t);

    while(t--){
        scanf("%d", &k);
        int n = 0;
        for(int i = 1; i <= 9 ; ++i)
            scanf("%d", &d[i]), n += d[i];
        s[n + 1] = NULL;

        int nr = k - 1;
        for(int i = 9; i >= 1 && nr > 0 ; --i) while(d[i] > 0 && nr > 0) s[n--] = i + '0', --d[i], --nr;

        int Max = 0;
        for(int i = 9; i >= 1 ; --i) if(d[i]) {Max = i; break ;}

        int groups = d[Max];
//        cerr << Max << " " << d[Max] << endl;

        int st = 1, dr = groups;
        for(int i = 1; i < Max ; ++i){
            while(d[i]){
                int Last = 0;
                for(int j = st; j <= dr && d[i] ; ++j){
                    Last = j;
                    --d[i];
                    v[j].push_back(i);
                }
                if(d[i] == 0 && Last < dr) st = Last + 1;
            }
        }

        st = 1, dr = groups;
        while(st <= dr){
            for(int i = v[st].size() - 1; i >= 0 ; --i) s[n--] = v[st][i] + '0';
            s[n--] = Max + '0';
            ++st;

            if(st > dr) continue ;

            for(int i = v[dr].size() - 1; i >= 0 ; --i) s[n--] = v[dr][i] + '0';
            s[n--] = Max + '0';
            --dr;
        }

//        cerr << n << endl;

        printf("%s\n", s + 1);

        for(int i = 1; i <= groups ; ++i) v[i].clear();
    }

    return 0;
}
