/**
* user:  bortolin-a96
* fname: Alessandro
* lname: Bortolin
* task:  restore
* score: 13.0
* date:  2019-10-10 07:27:52.303628
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
#define fi first
#define se second

constexpr int MAXN = 1e4 + 42;

typedef tuple<int, int, int, int> Q;

Q query[MAXN];
bool bit[MAXN];
bool stop[MAXN];

int main() {
	ios::sync_with_stdio(false);
	
	int N, M;
	cin >> N >> M;
	
	for (int i=0; i<M; i++) {
		int l, r, k, v;
		cin >> l >> r >> k >> v;
		query[i] = make_tuple(r, l, k, v);
	}
	
	sort(query, query + M);
	
	for (int i=0; i<M; i++) {
		int l, r, k, v;
		tie(r, l, k, v) = query[i];
		int rem = (v == 0 ? k : r - l + 2 - k);
		//cerr << ' ' << i << ' ' << l << ' ' << r << ' ' << k << ' ' << v << ' ' << rem << endl;
		for (int j=l; j<=r && rem > 0; j++) {
			if (bit[j] == v && stop[j]) {
				rem--;
			}
		}
		for (int j=l; j<=r && rem > 0; j++) {
			if (!stop[j]) {
				bit[j] = v;
				stop[j] = true;
				rem--;				
			}
		}
		if (rem > 0) {
			cout << -1 << endl;
			exit(0);
		}
		int b[2] = {0, 0};
		for (int j=l; j<=r; j++) {
			b[bit[j]]++;
		}
		if ((v == 0 && b[0] < k) || (v == 1 && b[0] >= k)) {
			cout << -1 << endl;
			exit(0);
		}
	}
	
	for (int i=0; i<N; i++) {
		cout << bit[i] << ' ';
	}
	cout << endl;
	
	return 0;
}
