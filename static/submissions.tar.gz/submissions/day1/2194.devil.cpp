/**
* user:  koynov-034
* fname: Daniel
* lname: Koynov
* task:  devil
* score: 0.0
* date:  2019-10-10 08:41:19.473502
*/
#include<iostream>

using namespace std;
typedef long long ll;

ll d[10], anssum, ans, k, sum;

string change(ll x)
{
    string r = "";
    do
    {
        ll c = x % 10;
        r = (char)(c + '0') + r;
        x /= 10;
    }
    while(x != 0);
    return r;
}

ll change_back(string s)
{
    ll x = 0;
    ll step = 1, sz = s.size(), i;
    for (i = sz - 1; i >= 0; i --)
    {
        x = x + (s[i] - '0') * step;
        step = step * 10;
    }
    return x;
}
ll find_lowest(string d)
{
    int sz = d.size(), i;
    ll maxx = 0;
    for (i = 0; i < sz - k + 1; i ++)
    {
        ll nb = change_back(d.substr(i, k));
        if (nb > maxx)
            maxx = nb;
    }
    return maxx;
}
void gen(ll pos, ll num)
{
    if (pos == sum)
    {
        string d = change(num);
        ll x = find_lowest(d);
        if (x < anssum)
        {
            anssum = x;
            ans = num;
        }
        return;
    }
    int i;
    for (i = 1; i < 5; i ++)
    {
        if (d[i] > 0)
        {
            d[i] -- ;
            gen(pos + 1, num * 10 + i);
            d[i] ++;
        }
    }
}
int main()
{
    ll t, i, j, ii, jj, p;
    cin >> t;
    for (i = 0; i < t; i ++)
    {
        cin >> k;
        sum = 0;
        for (j = 1; j < 10; j ++)
        {
            cin >> d[j];
            sum = sum + d[j];
        }
        ans = 100000000000;
        anssum = 100000000000;
        gen(0, 0);
        cout << ans << endl;

    }

    /**cout << "START" << endl;
    for (i = 0; i <= 3; i ++)
        for (j = 0; j <= 3; j ++)
            for (ii = 0; ii <= 3; ii ++)
                for (jj = 0; jj <= 3; jj ++)
                for (p = 0; p <= max(i, max(ii, max(j, jj))); p ++)
                {
                    k = p;
                    sum = i + j + ii + jj;
                    d[1] = i;
                    d[2] = j;
                    d[3] = ii;
                    d[4] = jj;
                    ans = 1000000000;
                    anssum = 10000000000;
                    gen(0, 0);
                    cout << i << " " << j << " " << ii << " " << jj << " " << p << endl;
                    cout << ans << endl;
                }*/
    return 0;
}
