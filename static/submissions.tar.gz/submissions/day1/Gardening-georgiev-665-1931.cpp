/**
* user:  georgiev-665
* fname: Boyan Ivaylov
* lname: Georgiev
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:42:22.367673
*/
#include<bits/stdc++.h>
using namespace std;
int n,m,k,t;
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin>>t;
    for(int i0=0;i0<t;i0++){
        cin>>n>>m>>k;
        if(n==2){
            if(m%2!=0) cout<<"NO\n";
            else{
                if(m/2!=k) cout<<"NO\n";
                else{
                    cout<<"YES\n";
                    for(int i=0;i<n;i++){
                        for(int i1=0;i1<m;i1++){
                            cout<<i1/2+1;
                            if(i1!=m-1) cout<<" ";
                        }
                        cout<<"\n";
                    }
                }
            }
        }else if(n==4){
            if(m%2!=0) cout<<"NO\n";
            else{
                int z=n*m,rast;
                if(z/4==k){
                    cout<<"YES\n";
                    for(int i=0;i<n;i++){
                        for(int i1=0;i1<m;i1++){
                            if(i<2) cout<<i1/2+1;
                            else cout<<i1/2+1+m/2;
                            if(i1!=m-1) cout<<" ";
                        }
                        cout<<"\n";
                    }
                }else{
                    rast=(z-k*4-4)/2;
                    if(rast==0 || rast+2>m) cout<<"NO\n";
                    else{
                        cout<<"YES\n";
                        int nch=rast/2+1;
                        for(int i=0;i<n;i++){
                            for(int i1=0;i1<m;i1++){
                                if(i1<rast+2){
                                    if(i==0 || i1==0 || i==n-1 || i1==rast+1) cout<<1;
                                    else cout<<(i1-1)/2+2;
                                    if(i1!=m-1) cout<<" ";
                                }else{
                                    if(i<2) cout<<(i1-(rast+2))/2+1+nch;
                                    else cout<<(i1-(rast+2))/2+1+(m-(rast+2))/2+nch;
                                    if(i1!=m-1) cout<<" ";
                                }
                            }
                            cout<<"\n";
                        }
                    }
                }
            }
        }else cout<<"NO\n";
    }

    return 0;
}
