/**
* user:  vildanov-1b1
* fname: Ruslan
* lname: Vildanov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 08:49:23.257734
*/
#ifdef LOCAL
    //#define _GLIBCXX_DEBUG
#endif // LOCAL
#include <bits/stdc++.h>
using namespace std;

//#define int long long
#define f first
#define s second
#define endl '\n'

bool can(int n, int m, int k)
{
    if ((long long)n*(long long)m>200000LL){
        return 0;
    }
    if (k*4>n*m){
        return 0;
    }
    if (n%2==1 || m%2==1){
        return 0;
    }
    if (k<max(n,m)/2)return 0;
    if (n==2 && k!=m/2)return 0;
    if (m==2 && k!=n/2)return 0;
    return 1;
}

vector <vector <int> > solve(int n, int m, int k)
{
    vector <vector <int> > a(n,vector <int> (m,0));
    if (n%2==0 && m%2==0 && k==n*m/4){
        vector <vector <int> > a(n,vector <int> (m,0));
        int x=1;
        for (int i=0; i<n; i+=2){
            for (int j=0; j<m; j+=2){
                a[i][j]=x;
                a[i][j+1]=x;
                a[i+1][j]=x;
                a[i+1][j+1]=x++;
            }
        }
        return a;
    }
    if (can(n-2,m-2,k-1)){
        auto a=solve(n-2,m-2,k-1);
        if (a.size()==n-2 && a[0].size()==m-2){
            vector <vector <int> > b(n,vector <int> (m,0));
            for (int i=0; i<n; i++){
                b[i][0]=k;
                b[i][m-1]=k;
            }
            for (int j=0; j<m; j++){
                b[0][j]=k;
                b[n-1][j]=k;
            }
            for (int i=1; i<n-1; i++){
                for (int j=1; j<m-1; j++){
                    b[i][j]=a[i-1][j-1];
                }
            }
            return b;
        }
    }
    if (n<m && can(n-2,m,k-m/2)){
        auto a=solve(n-2,m,k-m/2);
        if (a.size()==n-2 && a[0].size()==m){
            vector <vector <int> > b(n,vector <int> (m,0));
            int x=k;
            for (int j=0; j<m; j+=2){
                b[0][j]=x;
                b[1][j]=x;
                b[0][j+1]=x;
                b[1][j+1]=x--;
            }
            for (int i=2; i<n; i++){
                for (int j=0; j<m; j++){
                    b[i][j]=a[i-2][j];
                }
            }
            return b;
        }
    }
    if (n>=m && can(n,m-2,k-n/2)){
        auto a=solve(n,m-2,k-n/2);
        if (a.size()==n && a[0].size()==m-2){
            vector <vector <int> > b(n,vector <int> (m,0));
            int x=k;
            for (int i=0; i<n; i+=2){
                b[i][0]=x;
                b[i][1]=x;
                b[i+1][0]=x;
                b[i+1][1]=x--;
            }
            for (int i=0; i<n; i++){
                for (int j=2; j<m; j++){
                    b[i][j]=a[i][j-2];
                }
            }
            return b;
        }
    }
    return {};
}

signed main()
{
    int t;
    cin >> t;
    while (t--){
        int n,m,k;
        cin >> n >> m >> k;
        if (!can(n,m,k)){
            cout << "NO" << endl;
            continue;
        }
        vector <vector <int> > a=solve(n,m,k);
        if (a.size()==n && a[0].size()==m){
            cout << "YES" << endl;
            for (int i=0; i<n; i++){
                for (int j=0; j<m; j++)cout << a[i][j] << " ";
                cout << endl;
            }
        }
        else {
            cout << "NO" << endl;
        }
    }
}
/**
size(n);

1,
2,
3,
6,
9,
16,
29,
54,
87,
138,
317,
404,
1017,
1566,
1971,
4566,
10041,
13732,
33713,
39246,
60383,
149342,
315905,
356036,
684169,
1570362
*/
