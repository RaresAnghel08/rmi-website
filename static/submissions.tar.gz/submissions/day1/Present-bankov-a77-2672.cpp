/**
* user:  bankov-a77
* fname: Mihail
* lname: Bankov
* task:  Present
* score: 8.0
* date:  2021-12-16 09:55:40.904374
*/
#include<bits/stdc++.h>
using namespace std;
const int val=16;
bool a[val];
vector<vector<int> >ans;
bool check()
{
    for(int i=0; i<val; i++)
    {
        if(a[i]==0)
        {
            a[i]=1;
            return true;
        }
        else a[i]=0;
    }
    return false;
}
void precomp()
{
    for(int i=0; i<val; i++)
        a[i]=0;
    while(check())
    {
        vector<int>cur;
        for(int i=0; i<val; i++)
            if(a[i])
                cur.push_back(i+1);
        bool fl=0;
        for(int i:cur)
        {
            for(int j:cur)
            {
                if(a[__gcd(i,j)-1]==0)
                {
                    fl=1;
                    break;
                }
            }
            if(fl)break;
        }
        reverse(cur.begin(),cur.end());
        if(fl==0)ans.push_back(cur);
    }
    sort(ans.begin(),ans.end());
    for(int i=0;i<ans.size();i++)reverse(ans[i].begin(),ans[i].end());
}
void solve()
{
    int x;
    cin>>x;
    if(x==0)
        cout<<0<<endl;
    else
    {
        cout<<ans[x-1].size()<<' ';
        for(int i:ans[x-1])cout<<i<<' ';
        cout<<endl;
    }
}
int main()
{
    precomp();
    //cout<<ans.size()<<endl;
    int t;
    cin>>t;
    while(t--)
        solve();
    return 0;
}
