/**
* user:  kliska-f84
* fname: Pavel
* lname: Kliska
* task:  restore
* score: 13.0
* date:  2019-10-10 09:36:17.972713
*/
#include <cstdio>


using namespace std;

const int MAXN = 5003;
const int MAXM = 10004;

int n,m;

int l[MAXM], r[MAXM], k[MAXM], v[MAXM];

int a[MAXN], b[MAXN];

int main(){
	scanf("%d%d", &n, &m);
	for(int i=0;i<m;++i){
		scanf("%d%d%d%d", &l[i], &r[i], &k[i], &v[i]);
		if(v[i]==1){
			a[l[i]]+=1;
			a[r[i]+1]-=1;	
		}
	}
	for(int i=1;i<n;++i) a[i]+=a[i-1];

	//for(int i=0;i<n;++i) printf("%d ", a[i]);
	//puts("");

	for(int i=0;i<n;++i) b[i]=(a[i]?1:0);
	for(int i=1;i<n;++i) b[i]+=b[i-1];

	//for(int i=0;i<n;++i) printf("%d ", b[i]);
	//puts("");

	for(int i=0;i<m;++i){
		if(v[i]==0){
			int sum = b[r[i]];
			if(l[i]) sum-=b[l[i]-1];
			if(sum==r[i]-l[i]+1){
				puts("-1");
				return 0;	
			}
		}	
	}

	for(int i=0;i<n;++i){
		if(a[i]) printf("1 ");
		else printf("0 ");	
	}
	puts("");
}
