/**
* user:  efremov-95c
* fname: Andrei
* lname: Efremov
* task:  restore
* score: 0.0
* date:  2019-10-10 07:19:19.792187
*/
#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <deque>
#include <iomanip>
#include <cassert>
#define rep(i, n) for (int i = 0; i < (n); i++)
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()

using namespace std;
using ll = long long;
using ul = unsigned long long;
using ld = long double;

const int N = 5001;
int mn[N][N], mx[N][N], e1[N], e0[N], a[N], ps[N];

int main() {
#ifdef ONPC
	freopen("a.in", "r", stdin);
#endif
	ios_base::sync_with_stdio(0); cin.tie(0);
	int n, m, l, r, k, d;
	cin >> n >> m;
	vector<vector<int>> q;
	rep(i, m) {
		cin >> l >> r >> k >> d;
		l--;
		if (d) {
			if (d == 1) {
				e1[l]++;
				e1[r]--;
			}
		}
		else {
			if (d == r - l) {
				e0[l]++;
				e0[r]--;
			}
		}
		q.push_back({l, r, k, d});
	}
	int c0 = 0, c1 = 0;
	rep(i, n) {
		c0 += e0[i];
		c1 += e1[i];
		if (c1)
			a[i] = 1;
	}
	rep(i, n)
		ps[i + 1] = ps[i] + a[i];
	for (auto &pp : q) {
		int cc = ps[pp[1]] - ps[pp[0]];
		if (pp[3] == 0 && cc > r - l - pp[2] || pp[3] == 1 && cc < pp[2]) {
			cout << -1;
			return 0;
		}
	}
	rep(i, n)
		cout << a[i];
}
