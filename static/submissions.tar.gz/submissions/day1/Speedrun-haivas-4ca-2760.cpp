/**
* user:  haivas-4ca
* fname: Vlad
* lname: Haivas
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:04:53.173850
*/
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debug(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast", "unroll-loops")
#include "speedrun.h"

using namespace std;
typedef long long ll;
typedef pair <int, int> pii;

const int NMAX = 1001;
const int nr_of_bits = 21;
const int INF = 2e9;
const int MOD = 1000000007;
const int BLOCK = 5;

vector <int> v[NMAX];
int parent[NMAX];

void assignHints(int subtask, int N, int A[], int B[])   /* your solution here */
{
    for(int i = 1; i < N; i++)
    {
        v[A[i]].push_back(B[i]);
        v[B[i]].push_back(A[i]);
    }
    setHintLen(N / BLOCK + 1); /// Mai vedem
    for(int i = 1; i <= N; i++)
    {
        for(auto x : v[i])
            setHint(i, x / BLOCK + 1, 1);
    }
}

int vi[NMAX];
int pp[NMAX];

void speedrun(int subtask, int N, int start)   /* your solution here */
{
    int p = 0, nr = 0;
    int vizite = 0;
    for(int i = 1; i <= N; i++)
    {
        v[i].clear();
    }
    while(nr != N)
    {
        vizite++;
        if(vizite > (2 * N + 1))
            break;
        if(!vi[start])
            nr++;
        if(nr == N)
            break;
        int gasit = 0;
        if(vi[start])
        {
            for(auto i : v[start])
            {
                for(int j = (i - 1) * BLOCK; j < i * BLOCK; j++)
                {
                    if(j == 0 || j > N)
                        continue;
                    if(vi[j]) continue;
                    if(!goTo(j)) continue;
                    pp[j] = start;
                    start = j;
                    gasit = 1;
                    break;
                }
                if(gasit)
                    break;
            }
        }
        else
        {
            vi[start] = 1;
            for(int i = 1; i <= N / BLOCK + 1; i++) /// MARE GRIJA
            {
                if(getHint(i))
                {
                    v[start].push_back(i);
                }
            }
            random_shuffle(v[start].begin(), v[start].end());
            for(auto i : v[start])
            {
                for(int j = (i - 1) * BLOCK; j < i * BLOCK; j++)
                {
                    if(j == 0 || j > N)
                        continue;
                    if(vi[j]) continue;
                    if(!goTo(j)) continue;
                    pp[j] = start;
                    start = j;
                    gasit = 1;
                    break;
                }
                if(gasit)
                    break;
            }
        }
        if(gasit)
            continue;
        start = pp[start];
        goTo(start);
    }
}

