/**
* user:  vassilev-392
* fname: Yoan Rumenov
* lname: Vassilev
* task:  Gardening
* score: 21.0
* date:  2021-12-16 09:14:04.641658
*/
#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
long long t,N,M,K,a[2001][2001],cr;
bool solve(long long n,long long m,long long k, pair<long long, long long> p){
    long long mn=max(n,m)/2, mx=n*m/4,i,j;
    if((n+m)%2==1 || mx<k || k<mn)return false;
    //cout<<n<<" "<<m<<" "<<k<<" ("<<p.first<<" "<<p.second<<")\n";
    if(n==m && n==2){
        a[p.first][p.second]=a[p.first][p.second+1]=a[p.first+1][p.second]=a[p.first+1][p.second+1]=1;
        return true;
    }
    if(n>2 && m>2 && solve(n-2,m-2,k-1,{p.first+1,p.second+1})){
        for(i=0;i<n;i++)a[p.first+i][p.second]=a[p.first+i][p.second+m-1]=k;
        for(i=0;i<m;i++)a[p.first][p.second+i]=a[p.first+n-1][p.second+i]=k;
        return true;
    }
    else if(n>2 && solve(n-2,m,k-m/2,p)){
        for(i=p.second;i<=p.second+m-1;i++)a[p.first+n-2][i]=a[p.first+n-1][i]=k-(i-p.second)/2;
        return true;
    }
    else if(m>2 && solve(n,m-2,k-n/2,p)){
        for(i=p.first;i<=p.first+n-1;i++)a[i][p.second+m-2]=a[i][p.second+m-1]=k-(i-p.first)/2;
        return true;
    }
    return false;
}
void print(){
    int i,j;
    for(i=1;i<=N;i++){
        for(j=1;j<=M;j++)printf("%lld ",a[i][j]); cout<<endl;
    }
}
int main(){
    long long i,j,f;
    cin>>t;
    for(i=0;i<t;i++){
        cr=0;
        scanf("%lld %lld %lld",&N,&M,&K);
        if(solve(N,M,K,{1,1})){printf("YES\n"); print();}
        else {printf("NO\n"); continue;}
    }

    return 0;
}
/*
*/
