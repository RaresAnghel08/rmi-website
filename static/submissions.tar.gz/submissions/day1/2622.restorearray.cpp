/**
* user:  semerdzhiev-688
* fname: Borislav
* lname: Semerdzhiev
* task:  restore
* score: 7.0
* date:  2019-10-10 09:38:33.480980
*/
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

int n, m;

//FILE* open = fopen("arr_test.txt", "r");

struct masiv
{
    int l, r, k, val;

    masiv(int _l, int _r, int _k, int _val)
    {
        l = _l; r = _r; k = _k; val = _val;
    }
};

vector <masiv> v;

void read_input()
{
    scanf("%d %d", &n, &m);
    //fscanf(open, "%d %d", &n, &m);

    int l, r, k, val;
    for(int i = 0; i < m; i++)
    {
        scanf("%d %d %d %d", &l, &r, &k, &val);
        //fscanf(open, "%d %d %d %d", &l, &r, &k, &val);
        v.push_back(masiv(l, r, k, val));
    }
}

struct t
{
    int pos, val;

    t(int _pos, int _val)
    {
        pos = _pos; val = _val;
    }

    bool operator<(t other) const
    {
        return val < other.val || (val == other.val && pos < other.pos);
    }
};

void solve()
{
    for(int mask = 0; mask < (1 << n); mask++)
    {
        bool fl = true;
        for(int j = 0; j < m; j++)
        {
            int mi = 1, cnt = 0;
            vector <t> v2;
            for(int z = v[j].l; z <= v[j].r; z++)
            {
                int temp = ((1 << z) & mask) == 0? 0 : 1;
                v2.push_back(t(z, temp));
            }
            sort(v2.begin(), v2.end());
            if(v2[v[j].k - 1].val != v[j].val)
            {
                fl = false;
                break;
            }
        }
        if(fl)
        {
            for(int j = 0; j < n; j++)
            {
                printf("%d ", ((1 << j) & mask) == 0? 0 : 1);
            }
            printf("\n");
            return;
        }
    }
    printf("-1\n");
}

int main()
{
    read_input();
    solve();

    return 0;
}
/*
4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0
*/
