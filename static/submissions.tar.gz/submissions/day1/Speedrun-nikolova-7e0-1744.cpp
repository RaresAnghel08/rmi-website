/**
* user:  nikolova-7e0
* fname: Vesela Georgieva
* lname: Nikolova
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 08:23:39.649871
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;

const int maxb = 16, maxn = 1024;
int cnt = 0;
bool bits[maxn], used[maxn];

void to_2(int n)
{
    string ans = "";
    int c;
    while (n != 0)
    {
        c = n%2;
        ans = (char)(c+'0') + ans;
        n >>= 1;
    }

    int i, len = ans.size();
    for (i=0; i<len; ++i)
    {
        bits[i+1] = (ans[i] == '1') ? true : false;
    }
    cnt = len;
}

void assignHints(int subtask, int N, int A[], int B[])
{
     /* your solution here */
     if (subtask == 2)
     {
         int i = 1, j, k;
         if (A[i] == A[i+1] || A[i] == B[i+1]) k = A[i];
         else k = B[i];
         to_2(k);
         setHintLen(cnt);
         for (i=1; i<=N; ++i)
         {
             for (j=1; j<=cnt; ++j)
             {
                 setHint(i, j, bits[j]);
             }
         }
     }
}

int to_10()
{
    int i, sz = getLength(), num = 0, st = 1;
    for (i=sz; i>0; --i)
    {
        if (getHint(i)) num += st;
        st <<= 1;
    }
    return num;
}

void speedrun(int subtask, int N, int start)
{
     /* your solution here */
     if (subtask == 2)
     {
         int k = to_10();
         if (start != k) goTo(k);
         used[k] = true;
         used[start] = true;
         int i;
         for (i=1; i<=N; ++i)
         {
             if (!used[i])
             {
                 goTo(i);
                 goTo(k);
                 used[i] = true;
             }
         }
     }
}
