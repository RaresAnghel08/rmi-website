/**
* user:  dobleaga-e29
* fname: Alexandru
* lname: Dobleaga
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:50:21.882834
*/
#include <bits/stdc++.h>

using namespace std;

bool Exist (int N, int M, int K) {
    return (N % 2 == 0 && M % 2 == 0 && K * 4 <= N * M && K * 2 * (N + M - 2) >= N * M);
}

void Do_Testcase () {
    int N, M, K;

    cin >> N >> M >> K;

    if (!Exist(N, M, K)) {
        cout << "NO" << '\n';
        return;
    }

    if (N == 2) {
        if (M / 2 != K) {
            cout << "NO" << '\n';
            return;
        }

        cout << "YES" << '\n';
        for (int i = 0; i < N; ++ i ) {
            for (int j = 0; j < M; ++ j )
                cout << (j+2) / 2 << " ";
            cout << '\n';
        }

        return;
    }

    if (N == 4) {
        int Min = M / 2;
        if (Min > K) {
            cout << "NO" << '\n';
            return;
        }

        vector <vector <int> > V;
        V.resize(N);
        for (int i = 0; i < N; ++ i )
            V[i].resize(M);
        int dif = K - Min;
        int cnt = 1;

        V[1][0] = V[2][0] = cnt;
        V[1][M-2*dif-1] = V[2][M-2*dif-1] = cnt;
        for (int i = 0; i < M - dif * 2; ++ i )
            V[0][i] = V[3][i] = cnt;

        ++ cnt;
        for (int i = 1; i < M - 2 * dif - 2; i += 2 ) {
            V[1][i] = V[2][i+1] = cnt;
            V[2][i] = V[1][i+1] = cnt;
            ++ cnt;
        }

        for (int i = M - 2 * dif; i < M; i += 2) {
            V[0][i] = V[1][i] = V[0][i+1] = V[1][i+1] = cnt;
            ++ cnt;
            V[2][i] = V[3][i] = V[2][i+1] = V[3][i+1] = cnt;
            ++ cnt;
        }

        cout << "YES" << '\n';
        for (int i = 0; i < N; ++ i ) {
            for (int j = 0; j < M; ++ j )
                cout << V[i][j] << " ";
            cout << '\n';
        }
    }
}

int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T = 1;
    cin >> T;

    for (; T; -- T ) {
        Do_Testcase();
    }

    return 0;
}
