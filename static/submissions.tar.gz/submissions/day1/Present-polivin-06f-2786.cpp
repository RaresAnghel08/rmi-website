/**
* user:  polivin-06f
* fname: Nikita
* lname: Polivin
* task:  Present
* score: 8.0
* date:  2021-12-16 10:06:54.234314
*/
#include <bits/stdc++.h>

using namespace std;

//#define int long long

int gcd(int a, int b){
    if(a == 0){
        return b;
    }
    if(b == 0){
        return a;
    }

    return gcd(b, a % b);
}

void solve(){
    int t;
    cin >> t;
    vector <int> q(t);
    for(int i = 0; i < t; ++i){
        cin >> q[i];
    }

    int k = 0;
    for(int i = 0; i < t; ++i){
        k = max(k, q[i]);
    }

    vector < set <int> > a(1);
    int mx = 1;
    while(a.size() <= k){
        int sz = a.size();
        for(int i = 0; i < sz; ++i){
            bool ok = 1;
            for(auto j : a[i]){
                if(!a[i].count(gcd(mx, j))){
                    ok = 0;
                    break;
                }
            }

            if(ok){
                a.push_back(a[i]);
                a[a.size() - 1].insert(mx);
            }

            if(a.size() > k){
                break;
            }
        }

        ++mx;
    }

    for(auto k : q) {
        cout << a[k].size() << " ";
        for (auto i : a[k]) {
            cout << i << " ";
        }
        cout << '\n';
    }
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    solve();
    /*int tests;
    cin >> tests;
    while(tests--){
        solve();
    }*/
}