/**
* user:  ginzburg-8de
* fname: Yael
* lname: Ginzburg
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:52:40.517246
*/
// Gardening.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;

bool solveS1(int n, int m, int k, vvi& gar)
{
    if (n == 1 || m == 1) return false;
    if (n == 3 && m == 3) return false;
    if (n == 2 && m == 3 || m == 2 && n == 3) return false;
    else if (n == 2)
    {
        if (k != m / 2) return false;
        for (int i = 0; i < k; i++)
        {
            gar[0][i * 2] = i+1;
            gar[1][i * 2] = i+1;
            gar[0][i * 2 + 1] = i+1;
            gar[1][i * 2 + 1] = i+1;
        }
        return true;
    }
    else if (m == 2)
    {
        if (k != n / 2) return false;
        for (int i = 0; i < k; i++)
        {
            gar[i * 2][0] = i+1;
            gar[i * 2][1] = i+1;
            gar[i * 2 + 1][0] = i+1;
            gar[i * 2 + 1][1] = i+1;
        }
        return true;
    }
    else if (n == 4 && m == 4)
    {
        if (k == 2)
        {
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    gar[i][j] = 2;
            gar[1][1] = 1;
            gar[2][1] = 1;
            gar[1][2] = 1;
            gar[2][2] = 1;
            return true;
        }
        else if (k == 4)
        {
            gar[0][0] = 4; gar[1][0] = 4; gar[0][1] = 4; gar[1][1] = 4;
            gar[0][2] = 1; gar[0][3] = 1; gar[1][2] = 1; gar[1][3] = 1;
            gar[2][0] = 2; gar[2][1] = 2; gar[3][0] = 2; gar[3][1] = 2;
            gar[2][2] = 3; gar[2][3] = 3; gar[3][2] = 3; gar[3][3] = 3;
            return true;
        }
        return false;
    }
    return false;
}

bool solveS2(int n, int m, int k, vvi& gar)
{
    if (n % 2 || m % 2) return false;
    else if (n == 2)
    {
        if (k != m / 2) return false;
        for (int i = 0; i < k; i++)
        {
            gar[0][i * 2] = i + 1;
            gar[1][i * 2] = i + 1;
            gar[0][i * 2 + 1] = i + 1;
            gar[1][i * 2 + 1] = i + 1;
        }
        return true;
    }
    else if (n == 4)
    {
        
        if (k == m / 2)
        {
            
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                        gar[i][j] = 1;
            for (int l = 0; l < m - 2; l+= 2)
            {
                int kl = l / 2 + 1;
                gar[1][l + 1] = kl + 1;
                gar[2][l + 1] = kl + 1;
                gar[1][l + 2] = kl + 1;
                gar[2][l + 2] = kl + 1;
            }
            return true;
        }
        else if (k == m)
        {
            for (int l = 0; l < m; l += 2)
            {
                int kl = l;
                gar[0][l+0] = kl + 1; gar[1][l+0] = kl + 1; gar[0][l+1] = kl+ 1; gar[1][l+1] = kl + 1;
                gar[2][l+0] = kl + 2; gar[2][l+1] = kl + 2; gar[3][l+0] = kl + 2; gar[3][l+1] = kl + 2;
            }
            return true;
        }
        return false;
    }
    return false;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    int t; cin >> t;
    for (int i = 0; i < t; i++)
    {
        int n, m, k; cin >> n >> m >> k;
        vector <vector<int>> gar(n, vi(m));
        if (solveS2(n, m, k, gar))
        {
            cout << "YES" << endl;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    cout << gar[i][j] << " ";
                }
                cout << endl;
            }
        }
        else cout << "NO" << endl;
    }
}
