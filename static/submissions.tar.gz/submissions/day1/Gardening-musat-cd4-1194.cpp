/**
* user:  musat-cd4
* fname: Tudor Ştefan
* lname: Muşat
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:14:27.927659
*/
#include <iostream>
#include <vector>

using namespace std;

const int NMAX = 2e5;

vector <int> v[NMAX];

void solve() {
    int n, m, i, j, k;
    cin >> n >> m >> k;
    for ( i = 0; i < n; i ++ )
        v[i].clear();
    for ( i = 0; i + 1 < n; i += 2 ) {
        for ( j = 0; j + 1 < m; j += 2 ) {
            if ( k > 0 ) {
                for ( int l = 0; l < 2; l ++ ) {
                    v[i].push_back( k );
                    v[i + 1].push_back( k );
                }
                k --;
            }
        }
    }
    if ( k > 0 ) {
        cout << "NO\n";
    } else {
        cout << "YES\n";
        for ( i = 0; i < n; i ++ ) {
            if ( v[i].size() == 0 ) {
                for ( j = 0; j < m; j ++ ) {
                    v[i].push_back( v[i - 1][j] );
                }
            }
            for ( j = v[i].size(); j < m; j ++ ) {
                v[i].push_back( v[i][j - 1] );
            }
        }
        for ( i = 0; i < n; i ++ ) {
            for ( j = 0; j < m; j ++ )
                cout << v[i][j] << ' ';
            cout << '\n';
        }
    }
}
int main() {
    int t = 1;
    cin >> t;
    while ( t-- ) {
        solve();
    }
    return 0;
}
