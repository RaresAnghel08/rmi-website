/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:17:59.583658
*/
#include "speedrun.h"
#include <iostream>
#include <vector>
#include <algorithm>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;

void assignHints(int subtask, int n, int A[], int B[]) {
    setHintLen(n);
    vvb bits(n + 1, vb(n + 1));
    for (int i = 1; i < n; i++) {
        bits[A[i]][B[i]] = true;
        bits[B[i]][A[i]] = true;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            setHint(i, j, bits[i][j]);
        }
    }
}

void Dfs(int node, int parent, int n, int &cnt) {
    cnt++;
    if (cnt == n) return;
    vi graph;
    for (int i = 1; i <= n; i++) {
        if (getHint(i)) graph.push_back(i);
    }
    for (int neighbor : graph) {
        if (neighbor == parent) continue;
        goTo(neighbor);
        Dfs(neighbor, node, n, cnt);
        if (cnt == n) return;
        goTo(node);
    }
}

void speedrun(int subtask, int n, int start) {
    int cnt = 0;
    Dfs(start, 0, n, cnt);
}
//5
//1 2
//2 3
//3 4
//3 5
//1