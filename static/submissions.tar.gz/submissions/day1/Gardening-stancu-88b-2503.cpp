/**
* user:  stancu-88b
* fname: Sergiu Nicolae
* lname: Stancu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:38:10.811724
*/
#include <bits/stdc++.h>
#define nl '\n'
using namespace std;

int main()
{
    cin.tie ( 0 )->sync_with_stdio ( 0 );
    cin.tie ( NULL );
    cout.tie ( NULL );
    int T, n, m, K;
    cin >> T;

    while ( T-- )
    {
        cin >> n >> m >> K;

        if ( n % 2 == 1 || m % 2 == 1 )
        {
            cout << "NO\n";
            continue;
        }

        if ( n == 2 )
        {
            if ( K == m / 2 )
            {
                cout << "YES\n";

                for ( int j = 1; j <= 2; j++ )
                {
                    for ( int i = 1; i <= K; i++ )
                        cout << i << ' ' << i << ' ';

                    cout << nl;
                }

                continue;
            }
            else
            {
                cout << "NO\n";
                continue;
            }
        }

        if ( n == 4 )
        {
            if ( m == K )
            {
                cout << "YES\n";
                K /= 2;

                for ( int kk = 0; kk < 2; kk++ )
                {
                    for ( int l = 1; l <= 2; l++ )
                    {
                        for ( int i = 1; i <= K; i++ )
                            cout << i + kk*K << ' ' << i + kk*K << ' ';

                        cout << nl;
                    }
                }

                continue;
            }

            if ( m == K * 2 )
            {
                cout << "YES\n";

                for ( int i = 1; i <= m; i++ )
                    cout << 1 << ' ';

                cout << nl;

                for ( int i = 1; i <= 2; i++ )
                {
                    cout << 1 << ' ';

                    for ( int j = 2; j <= K; j++ )
                        cout << j << ' ' << j << ' ';

                    cout << 1 << nl;
                }

                for ( int i = 1; i <= m; i++ )
                    cout << 1 << ' ';

                continue;
            }

            cout << "NO\n";
            continue;
        }

//        if ( K > ( M / 2 ) * ( N / 2 ) )
//        {
//            cout << "NO\n";
//            continue;
//        }
//        else
//        {
////         cout<<"YES\n";
////         int catepelinie=n/2;
////         int catepecoloane=m/2;
////         int catecoloane=K/catepelinie;
////
//        }
//
////        else
////            if ( n <= 6 )
////            {
////            }
    }

    return 0;
}
