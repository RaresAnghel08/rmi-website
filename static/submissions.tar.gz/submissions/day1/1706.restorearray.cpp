/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  restore
* score: 13.0
* date:  2019-10-10 07:34:41.704350
*/
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int NMAX = 5e3 + 5, MMAX = 1e4 + 5;

int N, M;

int A[NMAX];

struct Query
{
    int Left, Right, K, Val;
};

Query V[MMAX];

int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> N >> M;

    for(int i = 1; i <= M; ++i)
    {
        cin >> V[i].Left >> V[i].Right >> V[i].K >> V[i].Val;

        ++V[i].Left;
        ++V[i].Right;
    }

    for(int i = 1; i <= M; ++i)
    {
        int X = V[i].Val;

        if(X == 1)
        {
            for(int j = V[i].Left; j <= V[i].Right; ++j)
                A[j] = 1;
        }
    }

    bool Ok = true;

    for(int i = 1; i <= M; ++i)
    {
        int X = V[i].Val;

        if(X == 1)
            continue;

        bool Found = false;

        for(int j = V[i].Left; j <= V[i].Right; ++j)
            if(A[j] == 0)
            {
                Found = true;

                break;
            }

        if(!Found)
        {
            Ok = false;

            break;
        }
    }

    if(!Ok)
    {
        cout << -1 << '\n';

        return 0;
    }

    for(int i = 1; i <= N; ++i)
        cout << A[i] << ' ';

    cout << '\n';

    return 0;
}
