/**
* user:  greaca-04d
* fname: Albert Antoniu
* lname: Greaca
* task:  Present
* score: 29.0
* date:  2021-12-16 11:00:23.130741
*/
#include<bits/stdc++.h>
#define ll long long
using namespace std;
int ok(int nr,int i)
{
    if (nr&(1<<i))
        return 1;
    return 0;
}
int gcd(int a,int b)
{
    int r=0;
    while(b){
        r=a%b;
        a=b;
        b=r;
    }
    return a;
}
int n;
int cnt2=0,v[26];
int i1,t;
struct nr
{
    int v[26];
    int k;
    int ind;
}num[6];
int cmp(nr a,nr b)
{
    return a.k<b.k;
}
int cmp2(nr a,nr b)
{
    return a.ind<b.ind;
}
void backt(int nr)
{
    if (nr<n){
        cnt2++;
        while(num[i1].k==cnt2 && i1<=t){
            int i;
            for(i=1;i<=n;i++)
                if (v[i])
                    num[i1].v[++num[i1].v[0]]=i;
            i1++;
        }
    }
    int i,j;
    for(i=1;i<=nr;i++)
        if (v[i]==0){
            v[i]++;
            for(j=1;j<=n;j++)
                if (v[j])
                    v[gcd(i,j)]++;
            backt(i-1);
            v[i]--;
            for(j=n;j>=1;j--)
                if (v[j])
                    v[gcd(i,j)]--;
        }
}
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    int i,cnt=0;
    scanf("%d",&t);
    for(i=1;i<=t;i++){
        scanf("%d",&num[i].k);
        num[i].ind=i;
    }
    sort(num+1,num+t+1,cmp);
    n=25;
    i1=1;
    while(num[i1].k==0 && i1<=t)
        i1++;
    backt(n);
    sort(num+1,num+t+1,cmp2);
    int j;
    for(i=1;i<=t;i++){
        printf("%d ",num[i].v[0]);
        for(j=1;j<=num[i].v[0];j++)
            printf("%d ",num[i].v[j]);
        printf("\n");
    }
return 0;
}
