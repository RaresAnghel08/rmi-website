/**
* user:  odintsov-a3e
* fname: Andrei
* lname: Odintsov
* task:  restore
* score: 7.0
* date:  2019-10-10 07:17:55.064928
*/
#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = long double;
using pii = pair<int, int>;
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define all(x) (x).begin(), (x).end()
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define f first
#define s second

struct rule {
    int l, r, k, x;
};

const int MAXN = 20;
const int MAXM = 205;
int n, m;
int a[MAXN];
int c[MAXN][MAXN];
rule r[MAXM];

int main() {
    FAST_IO;
    cin >> n >> m;
    rep(i, m) {
        cin >> r[i].l >> r[i].r >> r[i].k >> r[i].x;
    }

    for (int mask = 0; mask < (1 << n); ++mask) {
        rep(i, n) {
            if (mask & (1 << i)) {
                a[i] = 1;
            } else {
                a[i] = 0;
            }
        }

        rep(i, n) {
            int cnt = 0;
            for (int j = i; j < n; ++j) {
                cnt += (a[j] == 0);
                c[i][j] = cnt;
            }
        }

        bool ok = true;

        rep(i, m) {
            if (r[i].x == 0) {
                if (c[r[i].l][r[i].r] < r[i].k) {
                    ok = false;
                    break;
                }
            } else {
                if (c[r[i].l][r[i].r] >= r[i].k) {
                    ok = false;
                    break;
                }
            }
        }

        if (!ok) continue;
        rep(i, n) {
            cout << a[i] << ' ';
        }
        cout << endl;
        return 0;
    }

    cout << -1 << endl;
}