/**
* user:  mavrodiev-b5b
* fname: Tsvetoslav
* lname: Mavrodiev
* task:  restore
* score: 0.0
* date:  2019-10-10 07:20:13.375278
*/
#include<bits/stdc++.h>
using namespace std;
struct query
{
    int l,r,k,x;
};
bool cmp(query a,query b)
{
    return a.x>b.x;
}
query q[10001];
int mm[5001];
int main()
{
    ios_base::sync_with_stdio(0);
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++)
    {
        cin>>q[i].l>>q[i].r>>q[i].k>>q[i].x;
    }
    sort(q,q+m,cmp);
    for(int i=0;i<m;i++)
    {
        if(q[i].x==1)
        {
            for(int a=q[i].l;a<q[i].r;a++) mm[a]=1;
        }
        else
        {
            for(int a=q[i].l;a<q[i].r;a++)
            {
                if(mm[a]){cout<<-1<<endl; return 0;}
            }
        }
    }
    for(int i=0;i<n;i++) cout<<mm[i]<<" "; cout<<endl;
    return 0;
}
