/**
* user:  gatev-8cc
* fname: Aleksandar Miroslavov
* lname: Gatev
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:10:51.350193
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;

int n,curr;
vector<int> v[1007];

void assignHints(int subtask, int N, int A[], int B[]){
    n=N;
    for(int i=1;i<=n-1;i++){
        v[A[i]].push_back(B[i]);
        v[B[i]].push_back(A[i]);
    }
    if(subtask==1){
        setHintLen(n);
        for(int i=1;i<=n;i++){
            for(int f=0;f<v[i].size();f++){
                setHint(i,v[i][f],true);
            }
        }
    }
}

void dfs(int x,int p){
     for(int i=1;i<=n;i++){
         if(i!=p and getHint(i)){
             if(!goTo(i))cout<<1/0;
             dfs(i,x);
             if(!goTo(x))cout<<1/0;
         }
     }
}

void speedrun(int subtask, int N, int start){
    if(subtask==1){
         dfs(start,0);
    }
}