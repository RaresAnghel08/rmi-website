/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  Present
* score: 29.0
* date:  2021-12-16 10:10:59.901620
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define endl '\n'
bool used[1010];
vector<int>order;
int K;
void F(int mx){
    if ((--K)==0){
//        cout<<"OOOOOOOOOOOOK\n";
        vector<int>ans=order;
        sort(ans.begin(),ans.end());
        cout<<ans.size()<<" ";
        for (int i:ans) cout<<i<<" ";
        cout<<endl;
        return;
    }
    if (K<0) return;
//    cout<<order.size()<<" "<<K<<endl;
//    if (order.size()==1) cout<<"OOOOOK\n";
    for (int i=1;i<=mx;i++){
        if (!used[i]){
            vector<int>nw={i};
            used[i]=true;
            for (int x:order){
                int g=__gcd(x,i);
                if (!used[g]) {
                    nw.push_back(g);
                    used[g]=true;
                }
            }
            for (int x:nw) used[x]=true,order.push_back(x);
            F(i);
            for (int x:nw) used[x]=false,order.pop_back();
        }
    }
}
void solve(){
    cin>>K;
    K++;
    F(1000);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int tt;cin>>tt;
    while (tt--){
        solve();
    }
    return 0;
}
/**
1
500000000

4
5
6
100
1000
**/



