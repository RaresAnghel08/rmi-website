/**
* user:  stepanov-b9e
* fname: Anton
* lname: Stepanov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:50:55.932042
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <random>
#include <cassert>
#include <array>
#include <deque>
#include <set>
#include <map>


using namespace std;


#define int long long
#define ll long long
#define ld long double
#define flt double
#define pb push_back
#define emb emplace_back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()


ll n, m;
ll k;


int32_t main() {
    int t;
    cin >> t;
    while (t--) {
        cin >> n >> m >> k;
        ll s = (ll)(n) * m;
        if (n % 2 != 0 || m % 2 != 0 || k > (s / 4)) {
            cout << "NO" << "\n";
            continue;
        }
        if (n <= 4) {
            if (n == 2) {
                if (k == s / 4) {
                    cout << "YES" << "\n";
                    for (int i = 0; i < n; ++i) {
                        for (int j = 0; j < m; ++j) {
                            cout << (j / 2) + 1 << " ";
                        }
                        cout << "\n";
                    }
                } else {
                    cout << "NO" << "\n";
                    continue;
                }
            } else {
                ll c = (n * m - 4 * k) / 2;
                if (c > m || c <= 2) {
                    cout << "NO" << "\n";
                    continue;
                }
                cout << "YES" << "\n";
                for(int i = 0; i < n; ++i){
                    for (int j = 0; j < m; ++j) {
                        if (j < c) {
                            if (i == 0 || i == n - 1 || j == 0 || j == c - 1) {
                                cout << c / 2 << " ";
                            } else {
                                cout << ((j - 1) / 2) + 1 << " ";
                            }
                        } else {
                            if (i < 2) {
                                cout << (c / 2) + ((j - c) / 2) * 2 + 1 << " ";
                            } else {
                                cout << (c / 2) + ((j - c) / 2) * 2 + 2 << " ";
                            }
                        }
                    }
                    cout << "\n";
                }
            }
        }
    }
    return 0;
}

/*
1
4 4 3
*/