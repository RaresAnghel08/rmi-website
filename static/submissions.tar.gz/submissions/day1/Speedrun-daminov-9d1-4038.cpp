/**
* user:  daminov-9d1
* fname: Kamil
* lname: Daminov
* task:  Speedrun
* score: 60.0
* date:  2021-12-16 11:54:35.902231
*/
#include <bits/stdc++.h>
using namespace std;

void setHintLen (int l );
void setHint (int i , int j , bool b );
int getLength ();
bool getHint (int j );
bool goTo (int x );

bool used[3000];
vector<int> g[3000];

void dfs(int u, int p = -1) {
    used[u] = true;
    int l = getLength();
    for (int v = 0; v < l; v++){
        if (getHint(v + 1) && !used[v]) {
            goTo(v + 1);
            dfs(v, u);
        }
    }
    if (p != -1)
        goTo(p + 1);
}

void dfs2(int u, int p) {
    int sum = 0;
    for (int i = 0; i < 15; i++) {
        if (getHint(i + 1)) sum += (1 << i);
    }

    if (sum != p) {
        int v = sum - p;
        goTo(v);
        dfs2(v, u);
    }
    goTo(p);
}

int sz;
void dfs3(int u, int p = -1) {
    used[u] = true;
    for (int v = 1; v <= sz; v++) {
        if (getHint((v - 1) / 7 + 1) && !used[v] && goTo(v)) {
            dfs3(v, u);
        }
    }
    if (p != -1)
        goTo(p);
}

void assignHints (int subtask , int N , int A [] , int B []) {

    for (int i = 1; i < N; i++) {
        int a = A[i] - 1;
        int b = B[i] - 1;

        g[a].push_back(b);
        g[b].push_back(a);
    }

    if (subtask == 1) {


        setHintLen(N);

        for (int i = 0; i < N; i++){
            for (int j : g[i]) {
                setHint(i + 1, j + 1, true);
            }
        }
    }

    if (subtask == 2) {
        setHintLen(1);
        for (int u = 0; u < N; u++) {
            if (g[u].size() == N - 1) {
                setHint(u + 1, 1, true);
            }
        }
    }

    if (subtask == 3) {
        setHintLen(20);
        for (int u = 0; u < N; u++) {
            if (g[u].size() == 1) {
                int v = g[u].back() + 1;
                for (int i = 0; i <= 15; i++){
                    if (v & (1 << i)) {
                        setHint(u + 1, i + 1, true);
                    }
                }
            }
            if (g[u].size() == 2){
                int v = g[u][0] + g[u][1] + 2;
                for (int i = 0; i <= 15; i++){
                    if (v & (1 << i)) {
                        setHint(u + 1, i + 1, true);
                    }
                }
            }
        }
    }

    if (subtask == 4) {
        setHintLen(316);
        for (int u = 0; u < N; u++) {
            for (int v : g[u]) {
                setHint(u + 1, v / 7 + 1, true);
            }
        }
    }
}
void speedrun (int subtask , int N , int start ) {

    if (subtask == 1) {
        goTo(start);
        dfs(start - 1);
    }

    if (subtask == 2) {
        int root;
        goTo(start);
        if (getHint(1)) {
            root = start;
        }
        else {
            for (int u = 1; u <= N; u++){
                if (u != start && goTo(u)) {
                    root = u;
                    break;
                }
            }
        }

        for (int u = 1; u <= N; u++){
            if (u != start && u != root) {
                goTo(u);
                goTo(root);
            }
        }
    }

    if (subtask == 3) {

        for (int u = 1; u <= N; u++){
            if (start != u && goTo(u)) {
                dfs2(u, start);
                int sum = 0;
                for (int i = 0; i <= 15; i++) {
                    if (getHint(i + 1)) sum += (1 << i);
                }

                if (sum == u) return;
                else {
                    int v = sum - u;
                    goTo(v);
                    dfs2(v, start);
                }
                return;
            }
        }
    }

    if (subtask == 4) {

        sz = N;
        dfs3(start);
    }

}

