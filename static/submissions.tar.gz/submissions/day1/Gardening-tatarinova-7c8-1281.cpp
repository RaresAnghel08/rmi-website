/**
* user:  tatarinova-7c8
* fname: Yuliia
* lname: Tatarinova
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:37:45.385912
*/
#include <bits/stdc++.h>

using namespace std;
long long mas[4][200005];
int main()
{
    long long t, n,m,k;
    cin>>t;
    for(int step=0; step<t; step++)
    {
        cin>>n>>m>>k;
        if(n==1 || n==3) cout<<"NO\n";
        if(n==2)
        {
            if(k*2==m)
            {
                cout<<"YES\n";
                for(int i=0; i<m; i+=2)
                    cout<<i/2+1<<' '<<i/2+1<<' ';
                cout<<'\n';
                for(int i=0; i<m; i+=2)
                    cout<<i/2+1<<' '<<i/2+1<<' ';
                cout<<'\n';
            } else cout<<"NO\n";
        }
        if(n==4)
        {
            if(k>m || m%2==1 || k<(m-2)/2+1) cout<<"NO\n";
            else
            {
                cout<<"YES\n";
                long long l=m;
                long long x=m, p=1;
                for(int i=0; i<x; i+=2)
                {
                    if(k == (m-2)/2+1)
                    {
                       // cout<<(m-2)/2+1<<' ';
                        l=i;
                        break;
                    }

                    mas[0][i]=p;
                    mas[0][i+1]=p;
                    mas[1][i]=p;
                    mas[1][i+1]=p;
                    mas[2][i]=p+1;
                    mas[2][i+1]=p+1;
                    mas[3][i]=p+1;
                    mas[3][i+1]=p+1;
                    p+=2;
                    k-=2;
                    m-=2;
                }
               // cout<<l<<' ';
                mas[0][l]=p;
                mas[1][l]=p;
                mas[2][l]=p;
                mas[3][l]=p;
                for(int i=l+1; i<x; i++)
                {
                    mas[0][i]=p;
                    mas[3][i]=p;
                }
                if(l!=x)
                {


                mas[0][x-1]=p;
                mas[1][x-1]=p;
                mas[2][x-1]=p;
                mas[3][x-1]=p;
                p++;
                }
                for(int i=l+1; i<x-1; i+=2)
                {
                    mas[1][i]=p;
                    mas[2][i]=p;
                    mas[1][i+1]=p;
                    mas[2][i+1]=p;
                    p++;
                }

                for(int i=0; i<4; i++)
                {
                    for(int j=0; j<x; j++)
                    cout<<mas[i][j]<<' ';
                    cout<<'\n';
                }
            }
        }
    }
    return 0;
}
