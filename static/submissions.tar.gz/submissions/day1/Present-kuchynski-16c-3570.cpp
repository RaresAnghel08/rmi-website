/**
* user:  kuchynski-16c
* fname: Ilya
* lname: Kuchynski
* task:  Present
* score: 0.0
* date:  2021-12-16 11:18:51.940115
*/
#include <bits/stdc++.h>
using namespace std;

const int N = 3e6 + 200;
int ptr = 0;

int all[N];

const int L = 13;
bool cmp(const int& x, const int& y){
      int l = L - 1, r = L - 1;
      while(l >= 0 && !((x >> l) & 1))
            -- l;
      while(r >= 0 && !((x >> r) & 1))
            -- r;
      while(l >= 0 && r >= 0){
            if(l != r)
                  return l < r;
            -- l; -- r;
            while(l >= 0 && !((x >> l) & 1))
                  -- l;
            while(r >= 0 && !((x >> r) & 1))
                  -- r;
      }
      return l < r;
}

int main(){
      for(int mask = 0; mask < (1 << L); mask ++){
            bool bad = false;
            for(int i = 0; i < L; i ++){
                  for(int j = 0; j < L; j ++){
                        if(((mask >> i) & 1) && ((mask >> j) & 1) && !((mask >> (__gcd(i + 1, j + 1) - 1)) & 1))
                              bad = true;
                  }
            }
            if(!bad)
                  all[ptr ++] = mask;
            if(ptr >= N)
                  break;
      }
      sort(all, all + ptr, cmp);
      int t; cin >> t;
      while(t --){
            int k; cin >> k;
            int x = all[k];
            cout << __builtin_popcount(x) << " ";
            for(int i = 0; i < L; i ++)
                  if((x >> i) & 1)
                        cout << i + 1 << " ";
            cout << "\n";
      }

}
