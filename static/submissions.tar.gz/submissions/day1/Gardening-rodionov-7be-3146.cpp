/**
* user:  rodionov-7be
* fname: Valerii
* lname: Rodionov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:40:06.858802
*/
#include <bits/stdc++.h>

using namespace std;

#define int long long 

void solve() {
	int n, m, k;
	cin >> n >> m >> k;

	if (n % 2 != 0 || m % 2 != 0) {
		cout << "NO\n";
		return;
	}

	if (k == n * m / 4) {
		cout << "YES\n";
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < m; ++j) {
				cout << (i / 2) * (m / 2) + (j / 2) + 1 << " ";
			}
			cout << "\n";
		}
		return;
	}

	if (n == 2 || m == 2) {
		cout << "NO\n";
		return;
	}


	if (n == 4) {
		if (k >= m / 2 && k <= m && k != m - 1) {
			cout << "YES\n";
			cout << m - k + 1 << endl;
			vector<vector<int>> ans(4, vector<int>(m, 0));
			int last = 1;
			for (int j = 1; j < m - k + 1; j += 2) {
				for (int i = 1; i < 3; ++i) {
					ans[i][j] = ans[i][j + 1] = last;
				}
				++last;
			}
			for (int j = m - k + 2; j < m; j += 2) {
				for (int i = 0; i < 4; ++i) {
					ans[i][j] = ans[i][j + 1] = last + (i / 2);
				}
				last += 2;
			}
			for (int i = 0; i < 4; ++i) {
				for (int j = 0; j < m; ++j) {
					cout << ans[i][j] + 1 << " ";
				}
				cout << "\n";
			}
		} else {
			cout << "NO\n";
		}
	}
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
}
