/**
* user:  nir-b25
* fname: Itamar
* lname: Nir
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:27:27.074821
*/
// tree.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#include <vector>
#include <algorithm>
void setHintLen(int l);
void setHint(int i, int j, bool b);
int getLength();
bool getHint(int j);
bool goTo(int x);

void assignHints(int subtask, int N, int A[], int B[]) {
	if (N > 2) {


		int x;
		if (A[1] == B[2] || A[1] == A[2]) {
			x = A[1];
		}
		else {
			x = A[2];
		}
		int l = 0;
		vector<bool> vec;
		while (x > 0) {
			vec.push_back(x % 2);
			x /= 2;
			l++;
		}
		reverse(vec.begin(), vec.end());
		setHintLen(l);
		for (int i = 1; i <= N; i++) {
			if (i != x) {
				for (int j = 1; j <= l; j++) {
					setHint(i, j, vec[j-1]);
				}
			}
		}
	}
}


void speedrun(int subtask, int N, int start) {
	int l = getLength();
	if (getHint(1) == 0) {
		for (int i = 1; i <= N; i++) {
			if (i != start) {
				goTo(i);
				goTo(start);
			}
		}
	}
	else {
		int x = 0;
		int it = 1;
		for (int i = l; i > 0; i--) {
			x += it*getHint(i);
			it *= 2;
		}
		start = x;
		goTo(start);
		for (int i = 1; i <= N; i++) {
			if (i != start) {
				goTo(i);
				goTo(start);
			}
		}
	}
	

}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
