/**
* user:  pavic-9e7
* fname: Patrick
* lname: Pavić
* task:  devil
* score: 0.0
* date:  2019-10-10 10:15:42.072624
*/
#include <cstdio>
#include <cassert>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

#define PB push_back

using namespace std;

const int N = 1e5 + 500;
const int ALP = 12;

int D[ALP], T, K;

vector < int > sve, pos;

int main(){
	//ios_base::sync_with_stdio(false);
	//cin.tie(0);
	cin >> T;
	//T = 1;
	for(int _ = 0;_ < T;_++){
		cin >> K;
		assert(K == 2);
		for(int i = 1;i <= 9;i++)
			cin >> D[i];
		//cout << "tu sam\n";
		for(int j = 1;j <= 9;j++){
			for(int k = 0;k < D[j];k++) sve.PB(j);
		}
		
		string OUTPUT;
		int lst = sve.back(); sve.pop_back();
		//cout << "tu sam\n";
		for(int i = 0;i <= (int)sve.size() - i - 1;i++){
			OUTPUT.PB('0' + sve[((int)sve.size() - i - 1)]);
			//cout << sve[((int)sve.size() - i - 1)];
			if(i == (int)sve.size() - i - 1) break;
			OUTPUT.PB('0' + sve[i]);
		}
		OUTPUT.PB('0' + lst);
		cout << OUTPUT << endl;
		sve.clear();
	}
}
