/**
* user:  dimitrov-8ab
* fname: Atanas
* lname: Dimitrov
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 07:54:50.145980
*/
#include "speedrun.h"



#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl "\n"
template<class T, class T2> bool chkmin(T &a, const T2 &b) {return (a > b) ? a = b, 1 : 0;}
template<class T, class T2> bool chkmax(T &a, const T2 &b) {return (a < b) ? a = b, 1 : 0;}
#ifndef LOCAL
#define cerr if(false)cerr
#endif // LOCAL

const int MAX_N = 1e5 + 10;
vector<int> g[MAX_N];
int par[MAX_N], in[MAX_N];
int tme = 0;
vector<int> ord;

void dfs(int x, int p) {
    par[x] = p;
    in[x] = tme ++;
    ord.push_back(x);
    for(auto it : g[x]) {
        if(it != p) {
            dfs(it, x);
        }
    }
}

vector<bool> ans[MAX_N];

void pushTo(int x, int y) {
    for(int i = 9; i >= 0; i --) {
        ans[x].push_back((bool)(y & (1 << i)));
    }
}

void assignHints(int subtask, int n, int a[], int b[]) { /* your solution here */
    for(int i = 1; i < n; i ++) {
        g[a[i]].push_back(b[i]);
        g[b[i]].push_back(a[i]);
    }
    dfs(1, 0);
    setHintLen(20);
    for(int i = 1; i <= n; i ++) {
        pushTo(i, par[i]);
        pushTo(i, ord[(in[i] + 1) % ord.size()]);
    }
    for(int i = 1; i <= n; i ++) {
        for(int j = 0; j < 20; j ++) {
            setHint(i, j + 1, ans[i][j]);
        }
    }
}

bool used[MAX_N];

int decode(int start) {
    start ++;
    int ret = 0;
    for(int i = 0; i < 10; i ++) {
        ret = (ret * 2) + (getHint(start + i));
    }
    return ret;
}

void speedrun(int subtask, int N, int start) { /* your solution here */
    used[start] = true;
    for(int cnt = 1; cnt < N;) {
        int nxt = decode(10);
        while(!goTo(nxt)) {
            int p = decode(0);
            goTo(p);
            start = p;
            if(!used[start]) {
                used[start] = true;
                cnt ++;
            }
        }
        start = nxt;
        if(!used[start]) {
            used[start] = true;
            cnt ++;
        }
    }
}

/**
5
1 2
2 3
3 4
3 5
3
*/
