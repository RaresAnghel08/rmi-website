/**
* user:  chivu-423
* fname: Razvan
* lname: Chivu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:50:16.056443
*/
#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

int calcul_marg(int n, int m, int k){
    int a1 = n + m - 2;
    int a2 = a1 * a1;
    int a3 = n * m - 4 * k;
    a3 *= 4;
    int dif = a2 - a3;
    if(dif < 0)
        return -1;
    int rad = sqrt(dif);
    if(rad * rad != dif)
        return -1;
    int raspuns = a1 - rad;
    if(raspuns < 0)
        raspuns  = a1 + rad;
    if(raspuns < 0)
        return -1;

    raspuns /= 4;
    return raspuns;
}

const int NMAX = 20000;
int a[NMAX][NMAX];

void generare(int n, int m, int k, int p){
    int cnt = 0;
    for(cnt = 0; cnt < p; cnt++){
        //Latura sus si jos
        for(int j = cnt; j < m - cnt; j++){
            a[cnt][j] = cnt + 1;
            a[n - cnt - 1][j] = cnt + 1;
        }
        //Latura dreapta si stanga
        for(int j = cnt; j < n - cnt; j++){
            a[j][m - cnt - 1] = cnt + 1;
            a[j][cnt] = cnt + 1;
        }
    }

    int i = p;
    while(i <= n - p - 1){
        int j = p;
        while(j <= m - p - 1){
            a[i][j] = cnt + 1;
            a[i][j + 1] = cnt + 1;
            a[i + 1][j] = cnt + 1;
            a[i + 1][j + 1] = cnt + 1;
            cnt++;
            j += 2;
        }
        i += 2;
    }
}

//ifstream cin("gard.in");
//ofstream cout("gard.out");

void afisare(int n, int m){
    cout << "YES" << "\n";
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; j++)
            cout << a[i][j] << " ";
        if(i != n -1)
            cout << "\n";
    }
    cout << "\n";
}

int main()
{
    int t;
    cin >> t;

    for(int cnt = 0; cnt < t; cnt++){
        int n, m, k;
        cin >> n >> m >> k;

        if(n == 1 || m == 1 || n == 3 || m == 3){
            cout << "NO" << "\n";
        }else if(n == 2 && m == 2 && k == 1){
            cout << "YES" << "\n";
            cout << "1 1" << "\n";
            cout << "1 1" << "\n";
        }else if(n == 4 && m == 2 && k == 2){
            cout << "YES" << "\n";
            cout << "1 1" << "\n";
            cout << "1 1" << "\n";
            cout << "2 2" << "\n";
            cout << "2 2" << "\n";
        }else if(n == 2 && m == 4 && k == 2){
            cout << "YES" << "\n";
            cout << "1 1 2 2" << "\n";
            cout << "1 1 2 2" << "\n";
        }else if(n == 4 && m == 4){
            if(k == 2){
                cout << "YES" << "\n";
                cout << "1 1 1 1" << "\n";
                cout << "1 2 2 1" << "\n";
                cout << "1 2 2 1" << "\n";
                cout << "1 1 1 1" << "\n";
            }else if(k == 4){
                cout << "YES" << "\n";
                cout << "1 1 2 2" << "\n";
                cout << "1 1 2 2" << "\n";
                cout << "3 3 4 4" << "\n";
                cout << "3 3 4 4" << "\n";
            }else
                cout << "NO" << "\n";
        }else{
            if( (n * m < 3 * k) || n % 2 == 1 || m % 2 == 1)
                cout << "NO" << "\n";
            else {
                int p = calcul_marg(n, m, k);
                if(p < 0)
                    cout << "NO" << "\n";
                else{
                    generare(n, m, k, p);
                    afisare(n, m);
                }
            }
        }
    }

    return 0;
}
