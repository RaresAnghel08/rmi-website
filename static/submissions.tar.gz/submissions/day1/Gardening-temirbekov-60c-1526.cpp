/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:05:17.046989
*/
#include <bits/stdc++.h>

using namespace std;

void solve() {
	int n, m, v;
	cin >> n >> m >> v;
	if(n < 2 or m < 2 or v * 4 > n * m) {
		cout << "NO\n";
		return;
	}
	vector <vector <int> > a(n, vector <int> (m, 0));
	function <void(int, int, int)> fill=[&](int i, int j, int k) {
		a[i][j] = k;
		a[i+1][j] = k;
		a[i+1][j+1] = k;
		a[i][j+1] = k;
	};
	for(int k = 1; k <= v; k ++){
		for(int i = 0; i < n - 1; i +=2) {
			for(int j = 0; j < m - 1; j +=2) {
				if(a[i][j] == 0) { 
					fill(i, j, k);
					goto yes;
				}
			}
		}
		cout << "NO\n";
		return;
		yes:;
	}
	cout << "YES\n";
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < m; j ++) {
			if(j != 0 and a[i][j] == 0) a[i][j] = a[i][j - 1]; 
			else if(a[i][j] == 0 and i != 0) a[i][j] = a[i-1][j];
			else if(a[i][j] == 0) a[i][j] = a[i][j - 1];
			cout << a[i][j] << " ";
		}
		cout << "\n";
	}
}

int main(void) {
	int t;
	cin >> t;
	while(t --) {
		solve();
	}
	
	return 0;
}