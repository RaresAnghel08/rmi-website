/**
* user:  bengin-61a
* fname: Jovan
* lname: Bengin
* task:  devil
* score: 0.0
* date:  2019-10-10 09:26:42.688361
*/
#include <bits/stdc++.h>
using namespace std;

int cnt[10];

int k;
int sum;
int n;
int niz[1000005];

typedef long long ll;

void ispisi(int x){
    for(int i=1; i<=n; i+=x+1){
        if(cnt[2] == 0) break;
        cnt[2]--;
        niz[i] = 2;
        for(int j=i+1; j<=i+x; j++){
            if(cnt[1] == 0) break;
            cnt[1]--;
            niz[j] = 1;
        }
    }
    int tren = x;
    for(int i=1; i<=n; i++){
        if(niz[i]){
            cout << niz[i];
            continue;
        }
        while(!cnt[tren]) tren++;
        cnt[tren]--;
        niz[i] = tren;
        cout << niz[i];
    }
    //cout << "sgdfsdgs";
    cout << "\n";
}

void solve(){
    cin >> k;
    n = 0;
    for(int i=1; i<=9; i++){
        cin >> cnt[i];
        n += cnt[i];
    }
    for(int i=1; i<=n; i++){
        niz[i] = 0;
    }
    if(cnt[2] < k){
        int tren = 1;
        for(int i=1; i<=n; i++){
            while(!cnt[tren]) tren++;
            cout << tren;
            cnt[tren]--;
        }
        cout << "\n";
        return;
    }
    for(int j=1; j<=n; j++){
        int moze = cnt[1]/j;
        if(cnt[2]-moze < k){
            ispisi(j);
            return;
        }
    }
}

int main(){

    int t;
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
