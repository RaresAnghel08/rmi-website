/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 10:21:22.846656
*/
#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

typedef long long ll;
typedef long double ld;

// #define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back


const int maxn = 1100;
vi r[maxn];

void assignHints(int subtask, int N, int A[], int B[]) {
	if (subtask == 1) {
		setHintLen(N);
		for (int j = 1; j < N; ++j) {
			r[A[j]].pb(B[j]);
			r[B[j]].pb(A[j]);
		}
		for (int i = 1; i <= N; ++i) {
			for (auto &u : r[i]) {
				setHint(i, u, 1);
			}
		}
	} else if (subtask == 2) {
		setHintLen(20);
		for (int j = 1; j < N; ++j) {
			r[A[j]].pb(B[j]);
			r[B[j]].pb(A[j]);
		}
		int ans = 0;
		for (int k = 1; k <= N; ++k) {
			if (r[k].size() + 1 == N) {
				ans = k;
			}
		}
		for (int k = 1; k <= N; ++k) {
			if (r[k].size() + 1 == N)  {
				setHint(k, 1, 1);
			} else {
				for (int j = 0; j < 10; ++j) {
					if ((1 << j) & ans) {
						setHint(k, j + 2, 1);
					}
				}
			}
		}
	} else if (subtask == 3) {
		setHintLen(20);
		for (int j = 1; j < N; ++j) {
			r[A[j]].pb(B[j]);
			r[B[j]].pb(A[j]);
		}
		int ans = 0;
		for (int k = 1; k <= N; ++k) {
			for (int j = 0; j < r[k].size(); ++j) {
				for (int d = 0; d < 10; ++d) {
					if ((1 << d) & r[k][j]) {
						setHint(k, j * 10 + d + 1, 1);
					}
				}
			}
		}
	} else {
		setHintLen(22);
		for (int j = 1; j < N; ++j) {
			r[A[j]].pb(B[j]);
			r[B[j]].pb(A[j]);
		}
		int p[N];
		memset(p, 0, sizeof(p));
		int used[N + 1];
		memset(used, 0, sizeof(used));
		
		function<void(int)> dfs = [&] (int v) {
			used[v] = 1;
			for (auto &u : r[v]) {
				if (!used[u]) {
					p[u] = v;
					dfs(u);
				}
			}
		};
		dfs(1);
		for (int i = 2; i <= N; ++i) {
			r[i].erase(find(r[i].begin(), r[i].end(), p[i]));
		}
		for (int i = 1; i <= N; ++i) {
			r[i].pb(p[i]);
			if (r[i].size()) {
				for (int j = 1; j <= 10; ++j) {
					if ((1 << j - 1) & r[i][0]) {
						setHint(i, j, 1);
					}
				}
				for (int k = 0; k < r[i].size() - 1; ++k) {
					for (int j = 11; j <= 20; ++j) {
						if ((1 << j - 11) & r[i][k + 1]) {
							setHint(r[i][k], j, 1);
						}
					}
				}
				if (r[i].size() > 1)
					setHint(r[i][r[i].size() - 2], 21, 1);
			} else {
				setHint(i, 22, 1);
			}
		}
	}
}

void speedrun(int subtask, int N, int start) {
	if (subtask == 1) {
		int used[N + 1];
		memset(used, 0, sizeof(used));
		
		function<void(int)> dfs = [&] (int v) {
			used[v] = 1;
			for (int j = 1; j <= N; ++j) {
				if (!used[j] && getHint(j)) {
					goTo(j);
					dfs(j);
					goTo(v);
				}
			}
		};
		dfs(start);
	} else if (subtask == 2) {
		int now = start;
		int l = getLength();
		int x = getHint(1);
		if (x == 0) {
			int lol = 0;
			for (int j = 0; j < 10; ++j) {
				if (getHint(j + 2)) {
					lol |= (1 << j);
				}
			}
			goTo(lol);
			now = lol;
		}
		for (int i = 1; i <= N; ++i) {
			if (i != now) {
				goTo(i);
				goTo(now);
			}
		}
	} else if (subtask == 3) {
		int used[N + 1];
		memset(used, 0, sizeof(used));
		used[0] = 1;

		function<void(int)> dfs = [&] (int v) {
			used[v] = 1;
			vi rc;
			rc.pb(0);
			rc.pb(0);
			for (int k = 1; k <= 10; ++k) {
				if (getHint(k)) {
					rc[0] |= (1 << k - 1);
				}
			}
			for (int k = 11; k <= 20; ++k) {
				if (getHint(k)) {
					rc[1] |= (1 << k - 11);
				}
			}
			for (auto &j : rc) {
				if (!used[j]) {
					goTo(j);
					dfs(j);
					goTo(v);
				}
			}
		};
		dfs(start);
	} else {
		auto get = [&] (int l, int r) {
			int ans = 0;
			for (int j = l; j <= r; ++j) {
				ans += (getHint(j) << j - l);
			}
			return ans;
		};
		int used[N + 1];
		memset(used, 0, sizeof(used));
		used[0] = 1;
		function<void(int, int)> dfs = [&] (int v, int cum) {
			used[v] = 1;
			int x = get(1, 10);
			deque<int> vc;
			if (x)
				vc.pb(x);
			// cout << r[v].size() << endl;
			int y = get(22, 22);
			int p = 0;
			while (vc.size()) {
				int j = vc.front();
				vc.pop_front();
				goTo(j);
				int x = get(11, 20);
				if (get(21, 21) == 1 && y == 0) {
					p = x;
				}
				if (get(21, 21) == 0 && y == 0)
					vc.pb(x);
				if (!used[j]) {
					dfs(j, v);
				} 
				goTo(v);
				
			}
			if (p) {
				goTo(p);
				dfs(p, cum);
				goTo(v);
			}

		};
		dfs(start, -1);
	}
}