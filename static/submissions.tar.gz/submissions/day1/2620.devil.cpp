/**
* user:  malinin-a1f
* fname: Stoyan
* lname: Malinin
* task:  devil
* score: 0.0
* date:  2019-10-10 09:38:28.944881
*/
#include<iostream>
#include<vector>
#include<queue>
#include<algorithm>

using namespace std;

const int MAXN = 1e6 + 5;
const long long inf = 1e16 + 5;

int k;
int d[10];

vector <int> v;
deque <int> ans;

void specialSolve()
{
    if(v.size()==0)
    {
        return;
    }
    sort(v.begin(), v.end());

    long long minValue = inf;
    vector <int> answer;

    do
    {
        long long currMax = 0;
        for(int i = 0;i<v.size()-k+1;i++)
        {
            long long curr = 0;
            for(int j = i;j<i+k;j++)
            {
                curr = curr*10 + v[j];
            }

            currMax = max(currMax, curr);
        }

        if(currMax < minValue)
        {
            minValue = currMax;
            answer = v;
        }
    }
    while(next_permutation(v.begin(), v.end()));

    for(int d: answer) ans.push_back(d);
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T;
    cin >> T;

    while(T--)
    {
        cin >> k;
        for(int i = 1;i<=9;i++)
        {
            cin >> d[i];
        }

        v.clear();
        int maxDigit = 0;

        for(int digit = 9;digit>=1;digit--)
        {
            if(d[digit]==0) continue;
            if(d[digit]==1)
            {
                d[digit] = 0;
                v.push_back(digit);
                continue;
            }

            maxDigit = digit;
            break;
        }

        specialSolve();
        while(d[maxDigit]!=0)
        {
            d[maxDigit]--;
            for(int i = 1;i<=9;i++)
            {
                if(d[i]!=0)
                {
                    d[i]--;
                    ans.push_front(maxDigit);
                    ans.push_front(i);

                    break;
                }
            }
        }

        for(int i = 1;i<=9;i++)
        {
            for(int j = 0;j<d[i];j++)
            {
                ans.push_front(i);
            }
        }

        while(ans.empty()==false)
        {
            cout << ans.front();
            ans.pop_front();
        }
        cout << '\n';
    }
}
/*
5
ans2212212222
v2221212222

1
2
1 1 2 0 0 0 0 0 0

1
2
1 1 2 1 1 1 1 0 0
*/
