/**
* user:  salomon-bcd
* fname: Mayan
* lname: Salomon
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:47:03.421148
*/

#include <bits/stdc++.h> 

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;

void printgrid(vvi grid) {
    for (int i = 0; i < grid.size(); i++) {
        for (int j = 0; j < grid[i].size(); j++) {
            cout << grid[i][j] << " ";
        }
        cout << endl;
    }
}


void draw(vvi &grid, int n, int m, int out, int in) {
    
    int color = 1;
    for (int i = 0; i < out; i++) {
        for (int j = 0 + i; j < m - i; j++) {
            grid[i][j] = color;
        }
        for (int j = 0 + i; j < n - i; j++) {
            grid[j][i] = color;
        }
        for (int j = 0 + i; j < m - i; j++) {
            grid[n-1-i][j] = color;
        }
        for (int j = 0 + i; j < n - i; j++) {
            grid[j][n-1-i] = color;
        }
        color++;
    }

    for (int i = out; i < in+out; i+=2) {
        for (int j = out; j < in+out; j+=2) {
            grid[i][j] = color;
            grid[i + 1][j] = color;
            grid[i][j + 1] = color;
            grid[i+1][j+1] = color;
            color++;
        }
    }

}

void drawOut(vvi& grid, int n, int m, int out, int in) {

    int color = 1;
    for (int i = 0; i < out; i++) {
        for (int j = 0 + i; j < m - i; j++) {
            grid[i][j] = color;
            grid[n - 1 - i][j] = color;
        }
        for (int j = 0 + i; j < n - i; j++) {
            grid[j][i] = color;
            grid[j][m - 1 - i] = color;

        }
        //for (int j = 0 + i; j < m - i; j++) {
            //grid[n - 1 - i][j] = color;
        //}
        //for (int j = 0 + i; j < n - i; j++) {
            //grid[j][m - 1 - i] = color;
        //}
        color++;
    }

}

void drawLine(vvi& grid, int n, int m, int s, int i, int color) {

    for (int j = s; j < m-s; j += 2) {
        grid[i][j] = color;
        grid[i + 1][j] = color;
        grid[i][j + 1] = color;
        grid[i + 1][j + 1] = color;
        color++;
    }
}


void solvesmall(int n,int m, int k) {

    vvi grid(n, vi(m));

    if (n == 2) {
        if (m % 2 == 0 && m / 2 == k) {
            drawLine(grid, n, m,0, 0, 1);
            cout << "YES" << endl;

            printgrid(grid);
        }
        else
        {
            cout << "NO" << endl;
        }
        return;
    }

    if (n == 4) {
        if (m % 2 == 0 && m == k) {
            drawLine(grid, n, m,0, 0, 1);
            drawLine(grid, n, m, 0,2, m/2+1);
            cout << "YES" << endl;

            printgrid(grid);
        }
        else if (m%2==0 && ((m-2) / 2) + 1 == k) {
            drawOut(grid, n, m, 1, 0);
            drawLine(grid, n, m,1, 1, 2);
            cout << "YES" << endl;

            printgrid(grid);

        }
        else
        {
            cout << "NO" << endl;
        }
        return;
    }


    if (n == 6) {
        if (m % 2 == 0 && (m / 2)*3 == k) {
            drawLine(grid, n, m, 0, 0, 1);
            drawLine(grid, n, m,0, 2, m / 2+ 1);
            drawLine(grid, n, m,0, 4, m / 2 + m / 2 + 1);
            cout << "YES" << endl;

            printgrid(grid);


        }
        else if (m % 2 == 0 && ((m-4) / 2) + 2 == k) {
            drawOut(grid, n, m, 2, 0);
            drawLine(grid, n, m,2, 2, 3);
            cout << "YES" << endl;

            printgrid(grid);
        }
        else
        {
            cout << "NO" << endl;
        }
        return;
    }

    cout << "NO" << endl;

}

void solve(vi N, vi M, vi K, int index) {
    int n, m, k;


    n = N[index];
    m = M[index];
    k = K[index];


    if (n <= 6) {
        solvesmall(n, m, k);
        return;
    }
    else {
        cout << "NO" << endl;
        return;
    }

    vvi grid(n, vi(m));


    for (int i = 2; i <= n; i += 2) {
        ll ck = (i / 2) * (i / 2);
        ll left = k - ck;
        if (left * 2 + i == n) {
            cout << "YES" << endl;
            draw(grid, n, m, left, i);
            printgrid(grid);
            return;
        }
    }
    cout << "NO" << endl;
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int q;
    cin >> q;
    vi n(q), m(q), k(q);
    for (int i = 0; i < q; i++) {
        cin >> n[i] >> m[i] >> k[i];
        solve(n, m, k, i);

    }

    //for (int i = 0; i < q; i++) {
        //solve(n,m,k,i);
    //}
    return 0;
}
