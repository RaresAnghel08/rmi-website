/**
* user:  metehau-fd8
* fname: Luca
* lname: Metehău
* task:  devil
* score: 0.0
* date:  2019-10-10 08:58:12.479020
*/
#include <iostream>
#include <cstring>

using namespace std;

// eventual fac bruturi aici

int t, n, m, k;
string s;

int f[10];

int main() {
  cin >> t;
  for(; t; t--) {
    cin >> k;
    m = 0;
    for(int i = 1; i <= 9; i++)
      cin >> f[i];
    if(k == 2) {
      int c = 0, x = 0;
      for(int i = 9; i >= 1; i--) {
        if(f[i]) {
          c = i;
          f[i]--;
          break;
        }
      }
      x = c;
      while(!f[c] && c)
        c--;
      int sum = 0, ok = 0;
      s.clear();
      for(int i = 1; i < c; i++) {
        if(f[i]) {
          sum += f[i];
          if(sum >= f[c]) {
            sum = f[c];
            for(int j = 1; j < i; j++) {
              if(f[j]) {
                for(int k = 1; k <= f[j]; k++)
                  s += c + '0', s += j + '0';
                sum -= f[j];
                f[j] = 0;
              }
            }
            for(int j = 1; j <= sum; j++)
              s += c + '0', s += i + '0';
            f[i] -= sum;
            for(int j = i; j < c; j++) {
              if(f[j]) {
                for(int k = 1; k <= f[j]; k++)
                  s += j + '0';
              }
            }
            s += x + '0';
            cout << s << "\n";
            ok = 1;
            break;
          }
        }
      }
      if(!ok) {
        for(int i = 1; i <= 9; i++) {
          for(int j = 1; j <= f[i]; j++)
            s += i + '0';
        }
        s += x + '0';
        cout << s << "\n";
      }
    }
    /*if(f[2] < k) {
      for(int i = 1; i <= f[1]; i++)
        cout << 1, S += '1';
      for(int i = 1; i <= f[2]; i++)
        cout << 2, S += '2';
      cout << "\n";
    } else {
      f[2] -= k - 1;
      f[1]--;
      if(f[1] >= f[2]) {
        for(int i = 1; i <= f[2]; i++) {
          cout << 2, S += '2';
          for(int j = 1; j <= f[1] / f[2]; j++)
            cout << 1, S += '1';
        }
        for(int i = 1; i <= f[1] % f[2] + 1; i++)
          cout << 1, S += '1';
        for(int i = 1; i < k; i++)
          cout << 2, S += '2';
        cout << "\n";
      } else {
        for(int i = 1; i <= f[1]; i++)
          cout << "21", S += "21";
        for(int i = 1; i <= f[2] - f[1]; i++)
          cout << 2, S += '2';
        cout << 1, S += '1';
        for(int i = 1; i < k; i++)
          cout << 2, S += '2';
        cout << "\n";
      }
    }*/
  }
  return 0;
}
