/**
* user:  kemanov-48c
* fname: Lachezar
* lname: Kemanov
* task:  restore
* score: 13.0
* date:  2019-10-10 10:11:15.070407
*/
#include<iostream>
using namespace std;
int arr[5005];
int used[5005];
int first[5005];
int n,m;
bool t=false;

    int l,r,x,v;


int main()
{
    cin>>n>>m;
    bool f=true;
    for(int a=0; a<m; a++)
    {
        cin>>l>>r>>x>>v;
        if(v==1 && x==1)
        {
            for(int b=l; b<=r; b++)
            {
                if(used[b] && first[b]==0)
                {
                    f=false;
                }
                if(!used[b])
                {
                    first[b]=1;
                }
                arr[b]=1;
                used[b]=1;
            }
        }
        if(v==0 && x==1)
        {
            bool t=false;
            for(int b=l; b<=r; b++)
            {
                if(!used[b])
                    t=true;
            }
                if(t==false)
                {
                    f=false;
                }
        }
        if(v==1 && x==r)
        {
            for(int b=l; b<=r; b++)
            {
                if(!used[b] || first[b]==1)
                    t=true;
            }
                if(t==false)
                {
                    f=false;
                }
        }
        if(v==0 && x==r)
        {
            t=true;
            for(int b=l; b<r; b++)
            {
                if(used[b] && first[b]==1)
                    f=false;
                if(!used[b])
                {
                    used[b]=1;
                    first[b]=0;
                }
            }
            if(t==false)
            {
                f=false;
            }
        }

    }
    if(f==false)
    {
        cout<<-1<<endl;
        return 0;
    }
    for(int a=0; a<n-1; a++)
    {
        cout<<arr[a]<<" ";
    }
    cout<<arr[n-1]<<endl;
    return 0;
}
