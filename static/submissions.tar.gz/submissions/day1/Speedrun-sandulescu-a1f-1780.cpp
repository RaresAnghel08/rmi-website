/**
* user:  sandulescu-a1f
* fname: Alexandru Nicolae
* lname: Săndulescu
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 08:26:57.928102
*/
#include "speedrun.h"
#include <unordered_map>
#include <vector>
#include <iostream>


std::unordered_map<int, std::vector<int>> nodes;

void df_1(int node, int from = -1)
{
    for(auto it : nodes[node])
        if(it != from) {
            setHint(node, it, 1);
            setHint(it, node, 1);
            df_1(it, node);
        }
}

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */

    for(int i = 1; i < N; i++)
    {
        nodes[A[i]].push_back(B[i]);
        nodes[B[i]].push_back(A[i]);
    }
    if(subtask == 1) {
        setHintLen(N);
        df_1(1);
    } else {
        setHintLen(1);
        for(auto& v : nodes)
        {
            if(v.second.size() == N - 1) {
                setHint(v.first, 1, true);
                break;
            }
        }
    }

}

void df_2(int N, int node, int from = -1)
{
    for(int i = 1; i <= N; i++)
        if(getHint(i) && i != from && i != node) {
            goTo(i);
            df_2(N, i, node);
            goTo(node);
        }
}


void speedrun(int subtask, int N, int start) { /* your solution here */
    if(subtask == 1) {
        df_2(N, start);
    } else if(subtask == 2) {
        for(int i = 1; i <= N; i++) {
            if(goTo(i) == true) {
                if(getHint(1) == true) {
                    for(int j = 1; j <= N; j++) {
                        if(i == j) continue;
                        goTo(j);
                        goTo(i);
                    }
                } else {
                    goTo(start);
                }
            }
        }
    }
}

