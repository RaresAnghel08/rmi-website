/**
* user:  steinebrunner-6ba
* fname: Priska
* lname: Steinebrunner
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 11:11:00.101464
*/
//#pragma GCC optimize("O3")
//#pragma GCC optimize("loop-unroll")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,avx,avx2")
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;

void assignHints(int subtask, int n, int A[], int B[]) {
    if(subtask==1){
        setHintLen(n);
        for(int i=1;i<n;i++){
            setHint(A[i],B[i],1);
            setHint(B[i],A[i],1);
        }
    }else if(subtask==2){
        setHintLen(1);
        vector<int> v(n+1);
        for(int i=1;i<n;i++){
            v[A[i]]++;
            v[B[i]]++;
        }
        for(int i=1;i<=n;i++){
            if(v[i]>1){
                cout<<"ceter: "<<i<<endl;
                setHint(i,1,1);
                break;
            }
        }
    }else if(subtask==3){
        setHintLen(20);
        vector<vector<int>> graph(n+1);
        for(int i=1;i<n;i++){
            graph[A[i]].push_back(B[i]);
            graph[B[i]].push_back(A[i]);
        }
        
        for(int j=1;j<=n;j++){
            
            for(int i=0;i<graph[j].size();i++){
                for(int k=0;k<10;k++){
                    if((1<<k)&(graph[j][i])) {
                        //cout<<j<<" "<<k+1+10*i<<endl;
                        setHint(j,k+1+10*i,1);
                    }
                }
            }
            
        }
    }
}

void dfs1(int v, int n, int p=-1){
    
    //cout<<v<<": ";
    for(int i=1;i<=n;i++){
        if(i==p)continue;
        
        if(getHint(i)){
            assert(goTo(i));
            dfs1(i,n,v);
        }
    }
    if(p!=-1)goTo(p);
    else return;
}

void dfs3(int v,int p=-1){
    //cout<<v;
    int a=0;
    for(int i=0;i<10;i++){
        //cout<<getHint(i+1)<<" ";
        if(getHint(i+1)){
            a+=(1<<i);
        }
    }
    int b=0;
    for(int i=10;i<20;i++){
        //cout<<getHint(i+1)<<" ";
        if(getHint(i+1)){
            b+=(1<<(i-10));
        }
    }
    //cout<<": "<<a<<" "<<b<<endl;
    vector<int> vvvv = {a,b};
    for(int u:vvvv){
        if(u==p)continue;
        if(u==0)continue;
        assert(goTo(u));
        dfs3(u,v);
    }
    if(p!=-1)goTo(p);
    else return;
}

void speedrun(int subtask, int n, int start) { 
    if(subtask==1){
        int l=getLength();
        dfs1(start,l);
    }else if(subtask==2){
        if(getHint(1)){
            for(int i=1;i<n+1;i++){
                if(i==start) continue;
                goTo(i);
                goTo(start);
            }
        }else{
            int center=start;
            for(int i=1;i<n+1;i++){
                if(i==start)continue;
                if(goTo(i)){
                    center=i;
                    break;
                }else{
                    //cout<<i<<" ";
                }
            }
            cout<<center<<endl;
            for(int i=1;i<n+1;i++){
                if(i==start) continue;
                if(i==center) continue;
                assert(goTo(i));
                assert(goTo(center));
            }
        }
    }else if(subtask==3){
        dfs3(start);
    }
}
