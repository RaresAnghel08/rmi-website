/**
* user:  buntov-447
* fname: Atanas Todorov
* lname: Buntov
* task:  Present
* score: 8.0
* date:  2021-12-16 07:43:50.324245
*/
#include<bits/stdc++.h>
#define ll long long
#define f first
#define s second
using namespace std;
ll k,i,q[123];
vector<ll>a[1234567];
ll nod(ll a,ll b)
{
    ll r = a%b;
    while(b!=0)
    {
        r=a%b;
        a=b;
        b=r;
    }
    return a;
}
int main()
{ios_base::sync_with_stdio(false);
cin.tie(NULL);
k=100;
ll pos=2;
a[1].push_back(1);
while(pos<=k){
for(i=2;i<30;i++)
{
    ll p=pos;
    for(ll j=0;j<p;j++)
    {
        if(j==0 && pos<=k){a[pos].push_back(i);pos++;}
        else if(pos<=k)
        {
            memset(q,0,sizeof(q));
            int f=0;
            for(ll l=0;l<a[j].size();l++)
            {
                q[a[j][l]]=1;
                if(q[nod(i,a[j][l])]==0)f=1;
            }
            if(f==0 && pos<=k)
            {
                for(ll l=0;l<a[j].size();l++)
                {
                    a[pos].push_back(a[j][l]);
                }
                a[pos].push_back(i);
                pos++;
            }
        }
    }
}
if(pos==k)break;
}
ll t;
cin>>t;
for(i=0;i<t;i++)
{cin>>k;
cout<<a[k].size()<<" ";
    for(ll j=0;j<a[k].size();j++)cout<<a[k][j]<<" ";
    cout<<endl;
}
return 0;
}
