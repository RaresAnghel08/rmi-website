/**
* user:  smutchak-ea1
* fname: Andrii
* lname: Smutchak
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 08:33:07.341806
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
bool G[1007][1007];
int sz[1007];
vector<int> GG[1007];
void assignHints(int subtask, int N, int A[], int B[]) { 
	if(subtask == 1){
		setHintLen(N);
		for (int i = 1; i < N; ++i)
		{
			setHint(A[i],B[i],1);
			setHint(B[i],A[i],1);
		}
	}
	if(subtask == 2){
		bool array[10] = {0,0,0,0,0,0,0,0,0,0};
		setHintLen(10);
		for (int i = 1; i < N; ++i)
		{
			sz[A[i]]++;
			sz[B[i]]++;
		}
		int c = 0;
		for (int i = 1; i <=N; ++i)
		{
			if(sz[i] == N-1){
				int j = 9;
				int T = i;
				while(T) array[j--] = (T&1),T>>=1;
			}
		}
		for (int i = 1; i <= N; ++i)
		{
			for (int j = 1; j <= 10; ++j)
			{
				setHint(i,j,array[j-1]);
			}
		}
	}
	if(subtask == 3){
		setHintLen(20);
		for (int i = 1; i < N; ++i)
		{
			GG[A[i]].push_back(B[i]);
			GG[B[i]].push_back(A[i]);
		}
		for (int i = 1; i <= N; ++i)
		{
			if(GG[i].size() == 0) break;
			if(GG[i].size() == 1){
				int T = GG[i][0];
				int j = 10;
				while(T) setHint(i,j--,(T&1)),T>>=1;
			}
			if(GG[i].size() == 2){
				int T = GG[i][0];
				int j = 10;
				while(T) setHint(i,j--,(T&1)),T>>=1;
				T = GG[i][1];
				j = 20;
				while(T) setHint(i,j--,(T&1)),T>>=1;
			}
		}
	}
}
int n = 0;
void dfs1(int v,int p){
	for (int i = 1; i <= n; ++i)
		{
			if(i == v or i == p) continue;
			if(getHint(i)) goTo(i),dfs1(i,v);
		}
	if(p) goTo(p);
}
void dfs3(int v,int p){
	vector<int> G;
	int t = 0;
	for (int i = 0; i < 10; ++i)
	{
		t = (t<<1)|(getHint(i+1));
	}
	if(t) G.push_back(t);
	t = 0;
	for (int i = 10; i < 20; ++i)
	{
		t = (t<<1)|(getHint(i+1));
	}
	if(t) G.push_back(t);

	for (int i = 0; i < G.size(); ++i)
	{
		if(G[i] == p) continue;
		else goTo(G[i]),dfs3(G[i],v);
	}
	if(p) goTo(p);

}
void speedrun(int subtask, int N, int start) {
	n = N;
	if (subtask == 1)
	{
		dfs1(start,0);
		return;
	}
	if(subtask == 2){
		int v = 0;
		for (int i = 0; i < 10; ++i)
		{
			v = (v<<1)|(getHint(i+1));
		}
		if(v == start){
			for (int i = 1; i <= N; ++i)
			{
				if(i == start) continue;
				goTo(i);
				goTo(v);
			}
		}
		else{
			goTo(v);
			for (int i = 1; i <= N; ++i)
			{
				if(i == start or i == v) continue;
				goTo(i);
				goTo(v);
			}
		}
		return;
	}
	if(subtask == 3){
		dfs3(start,0);
		return;
	}
}
