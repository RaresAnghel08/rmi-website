/**
* user:  mihov-f9a
* fname: Boris Vladimirov
* lname: Mihov
* task:  Present
* score: 0.0
* date:  2021-12-16 11:55:41.039571
*/
// Da-i, d-d-d-da-i, sistemul turbat, ala turbat, cel mai turbat

#include <iostream>
#include <algorithm>
#include <set>
#include <vector>
#pragma GCC optimize ("O3")
#pragma GCC target ("sse4")
using namespace std;
const int maxn = 2e7;

vector < int > all[maxn], curr;
int cnt, tests;

bool binary(const vector < int > &v, int num) {

    int l = -1, r = v.size(), mid;
    while (l < r - 1) {

        mid = (l+r)/2;
        if (v[mid] == num) return 1;
        if (v[mid] < num) l = mid;
        else r = mid;

    }

    return 0;

}

inline bool cmp(vector < int > a, vector < int > b) {

    for (int i = 1 ; i <= min(a.size(), b.size()) ; ++i) {

        if (a[a.size()-i] < b[b.size()-i]) return 1;
        if (a[a.size()-i] > b[b.size()-i]) return 0;

    }

    return a.size() < b.size();

}

inline void solve() {

    for (int curr = 1 ; curr <= 25 ; ++curr) {
        
        int new_cnt = cnt;
        for (int i = 0 ; i <= cnt ; ++i) {

            bool ok = 1;
            for (int j = 0 ; j < all[i].size() && ok ; ++j)
                ok &= binary(all[i], __gcd(all[i][j], curr));
            if (ok) {

                ++new_cnt;
                all[new_cnt] = all[i];
                all[new_cnt].push_back(curr);

            }

        }

        cnt = new_cnt;

    }


}

void fast_io() {

    ios_base :: sync_with_stdio(0);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cerr.tie(nullptr);

}

int main () {

    fast_io();
    cin >> tests;

    solve();
    for (int i = 1 ; i <= tests ; ++i) {

        int k;
        cin >> k;
        cout << all[k].size() << ' ';
        for (int j : all[k])
            cout << j << ' ';
        cout << '\n';

    }

    return 0;

}
