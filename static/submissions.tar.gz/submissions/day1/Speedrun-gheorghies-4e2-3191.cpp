/**
* user:  gheorghies-4e2
* fname: Alexandru
* lname: Gheorghies
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:43:54.163168
*/
#include "speedrun.h"
#include <vector>
#include <assert.h>
const int NMAX=1050;
void assignHints(int subtask, int N, int A[], int B[]) {
    if(subtask==1){
        bool connected[NMAX][NMAX]{};
        setHintLen(N);
        for(int i=1;i<N;i++)
            connected[A[i]][B[i]]=1,connected[B[i]][A[i]]=1;
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++)
                setHint(i,j,connected[i][j]);
    }
    else if(subtask==2 || subtask==3){
        std::vector<int> edg[NMAX];
        int degree[NMAX]{};
        setHintLen(20);
        for(int i=1;i<N;i++){
            edg[A[i]].push_back(B[i]),edg[B[i]].push_back(A[i]);
            degree[A[i]]++,degree[B[i]]++;
        }
        for(int i=1;i<=N;i++){
            if(degree[i]==1){
                for(int bit=0;bit<10;bit++)
                    setHint(i,bit+1,edg[i][0]>>bit&1);
                for(int bit=10;bit<20;bit++)
                    setHint(i,bit+1,1);
            }
            else if(degree[i]==2){
                for(int bit=0;bit<10;bit++)
                    setHint(i,bit+1,edg[i][0]>>bit&1);
                for(int bit=10;bit<20;bit++)
                    setHint(i,bit+1,edg[i][1]>>bit&1);
            }
            else{
                for(int bit=0;bit<20;bit++)
                    setHint(i,bit+1,1);
            }
        }

    }
}
bool visited[NMAX]{};
int hint_len;
void visit(int u, int N){
    assert(u>=1 && u<=N);
    bool worked=goTo(u);
    assert(worked);
}
void dfs1(int u, int N){
    visited[u]=1;
    for(int i=1;i<=N;i++){
        if(getHint(i) && !visited[i]){
            visit(i,N);
            dfs1(i,N);
            visit(u,N);
        }
    }
}
void dfs23(int u, int N){
    visited[u]=1;
    int n1=0,n2=0;
    for(int i=1;i<=10;i++){
        n1|=(getHint(i)<<(i-1));
    }
    for(int i=11;i<=20;i++){
        n2|=(getHint(i)<<(i-1));
    }
    if(n1==1023 && n2==1023){
        for(int i=1;i<=N;i++){
            if(!visited[i]){
                visit(i,N);
                dfs23(i,N);
                visit(u,N);
            }
        }
        return;
    }
    if(n1!=1023 && !visited[n1]){
        visit(n1,N);
        dfs23(n1,N);
        visit(u,N);
    }
    if(n2!=1023 && !visited[n2]){
        visit(n2,N);
        dfs23(n2,N);
        visit(u,N);
    }
}
void speedrun(int subtask, int N, int start) {
    hint_len=getLength();
    if(subtask==1){
        dfs1(start,N);
    }
    else if(subtask==2 || subtask==3){
        dfs23(start,N);
    }
    else{
        assert(0);
    }
    for(int i=1;i<=N;i++)
        assert(visited[i]);
}

