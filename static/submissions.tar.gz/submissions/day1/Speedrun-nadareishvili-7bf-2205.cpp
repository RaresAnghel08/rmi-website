/**
* user:  nadareishvili-7bf
* fname: Giorgi
* lname: Nadareishvili
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:09:42.148469
*/
#include <bits/stdc++.h>
using namespace std;
#define grader grader
#ifndef grader
void setHintLen(int l) { }
void setHint(int i, int j, bool b) { }
int getLength() { return 0; }
bool getHint(int j) { return 0; }
bool goTo(int x) { return 0; }
#else
#include "speedrun.h"
#endif

void assignHints(int subtask, int n, int a[], int b[]) {
    if(subtask == 1) {
        setHintLen(n);
        for(int i = 0; i < n - 1; ++i) {
            setHint(a[i], b[i], 1);
            setHint(b[i], a[i], 1);
        }
    } else if(subtask == 2) {
        setHintLen(20);
    } else if(subtask == 3) {
        setHintLen(20);
    } else if(subtask == 4) {
        setHintLen(316);
    }
}

int l, n, s;

void dfs(int x, int y = 0) {
}

void dfsez(int x, int y = 0) {
    for(int i = 1; i <= n; ++i) {
        if(i != y && getHint(i)) {
            goTo(i);
            dfs(i, x);
        }
    }
    if(y) goTo(y);
}

void speedrun(int subtask, int _n, int start) {
    n = _n;
    s = subtask;
    l = getLength();
    if(subtask == 1) {
        dfsez(start);
    } else if(subtask == 2) {
    } else if(subtask == 3) {
    } else if(subtask == 4) {
    }
}

#ifndef grader
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    return 0;
}
#endif
