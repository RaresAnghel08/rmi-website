/**
* user:  grecu-015
* fname: Tudor Stefan
* lname: Grecu
* task:  Speedrun
* score: 40.0
* date:  2021-12-16 11:28:13.739794
*/
#include <iostream>
#include <vector>
#include "speedrun.h"

using namespace std;

const int MAXN = 1005;

void assignHints( int subtask, int N, int A[], int B[] ) {
  if ( subtask == 1 ) {
    setHintLen( N );
    for ( int i = 1; i <= N; ++i ) {
      for ( int j = 1; j < N; ++j ) {
        if ( A[j] == i ) {
          setHint( i, B[j], true );
        } else if ( B[j] == i ) {
          setHint( i, A[j], true );
        }
      }
    }
    return;
  }
  if ( subtask == 2 || subtask == 3 ) {
    setHintLen( 20 ); // 1 - 10, 11 - 20
    int pos[N + 5];
    for ( int i = 1; i <= N; ++i ) {
      pos[i] = 1;
    }
    for ( int i = 1; i < N; ++i ) {
      int b = 9;
      for ( int j = pos[A[i]]; j < pos[A[i]] + 10; ++j ) {
        setHint( A[i], j, (B[i] >> b) & 1 );
        --b;
      }
      pos[A[i]] += 10;
      b = 9;
      for ( int j = pos[B[i]]; j < pos[B[i]] + 10; ++j ) {
        setHint( B[i], j, (A[i] >> b) & 1 );
        --b;
      }
      pos[B[i]] += 10;
    }
    return;
  }
}

/// subtask == 1

bool use[MAXN];

void dfs( int N, int u, int p ) {
  use[u] = true;
  int l = getLength();
  for ( int v = 1; v <= l; ++v ) {
    if ( getHint( v ) == false ) continue;
    if ( !use[v] ) {
      goTo( v );
      dfs( N, v, u );
      goTo( u );
    }
  }
}

/// subtask == 2 sau 3

void solveMax2Ngh( int N, int u ) {
  use[u] = true;
  int l = getLength();
  int v1 = 0, v2 = 0;
  for ( int i = 1; i <= 10; ++i ) {
    v1 = v1 * 2 + getHint( i );
  }
  for ( int i = 11; i <= 20; ++i ) {
    v2 = v2 * 2 + getHint( i );
  }
  if ( !use[v1] && v1 ) {
    goTo( v1 );
    solveMax2Ngh( N, v1 );
    goTo( u );
  }
  if ( !use[v2] && v2 ) {
    goTo( v2 );
    solveMax2Ngh( N, v2 );
    goTo( u );
  }
}

void speedrun( int subtask, int N, int start ) {
  if ( subtask == 1 ) {
    dfs( N, start, 0 );
    return;
  }
  if ( subtask == 2 || subtask == 3 ) {
    solveMax2Ngh( N, start );
    return;
  }
}


