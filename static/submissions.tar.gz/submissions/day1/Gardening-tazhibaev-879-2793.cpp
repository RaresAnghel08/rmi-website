/**
* user:  tazhibaev-879
* fname: Iskhak
* lname: Tazhibaev
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:07:17.769019
*/
#include <bits/stdc++.h>
using namespace std;
#define int long long
int ito[4] = {1, -1, 0, 0};
int jto[4] = {0, 0, -1, 1};

 main(){
 	ios_base::sync_with_stdio(false);
	cin.tie(nullptr); 
	cout.tie(nullptr);
	int t;
	cin >> t;
	
	while(t--){
		int n, m, k;
		cin >> n >> m >> k;
		int s = n * m;
		int ker = k * 4;
		if(n == 1 or m == 1){
			cout << "NO" << "\n";
			continue;
		}else if(n == 2 and m == 2 and k !=1){
			cout << "NO" << "\n";
			continue;
		}
		
		int cnt = 1;
		
		int a[n + 2][m + 2];
		for(int i = 1;i <= n; i++){
			for(int j = 1;j <= m; j++){
				a[i][j] = -1;
			}
		}
		function <bool(int, int)> in = [&](int i, int j){
			if(i >= 1 and i <= n){
				if(j >= 1 and j <= m){
					return true;
				}
			}
			return false;
		};

		if(ker == s and n % 2 == 0 and m % 2 == 0){
			cout << "YES" << "\n";
			for(int i = 1;i <= n; i++){
				for(int j = 1;j <= m; j++){
					if(a[i][j] == -1){
						bool f = true;
						int ni = i;
						int nj = j;
						if(in(ni + 1, nj + 1)){
							if(a[ni + 1][nj + 1] != -1){
								f = false;
							}
						}else f = false;
						if(in(ni + 1, nj)){
							if(a[ni + 1][nj] != -1){
								f = false;
							}
						}else f = false;
						if(in(ni, nj + 1)){
							if(a[ni][nj + 1] != -1){
								f = false;
							}
						}else f = false;
						if(f){
							a[ni + 1][nj + 1] = cnt;
							a[ni][nj + 1] = cnt;
							a[ni + 1][nj] = cnt;
							a[i][j] = cnt;
							cnt++;
						}
					}
				}
			}
			for(int i = 1;i <= n; i++){
				for(int j = 1;j <= m; j++){
					cout << a[i][j] << " ";
				}
				cout << "\n";
			}
			continue;
		}
		int x = n;
		int y = m;
		int c = 0;
		bool jp = false;
		cnt = 1;
		while(true){
			if(n % 2 == 1) break;
			if(m % 2 == 1) break;
			s = (n - c) * (m - c);
			if(s < 0){
				jp = false;
				break;
			}
			ker = (k - (c / 2)) * 4;
			if(ker < 0){
				jp = false;
				break;
			}
			if(ker == s and (n - c) % 2 == 0 and (m - c) % 2 == 0){
				jp = true;
				for(int i = 1;i <= n; i++){
				for(int j = 1;j <= m; j++){
					if(a[i][j] == -1){
						bool f = true;
						int ni = i;
						int nj = j;
						if(in(ni + 1, nj + 1)){
							if(a[ni + 1][nj + 1] != -1){
								f = false;
							}
						}else f = false;
						if(in(ni + 1, nj)){
							if(a[ni + 1][nj] != -1){
								f = false;
							}
						}else f = false;
						if(in(ni, nj + 1)){
							if(a[ni][nj + 1] != -1){
								f = false;
							}
						}else f = false;
						if(f){
							a[ni + 1][nj + 1] = cnt;
							a[ni][nj + 1] = cnt;
							a[ni + 1][nj] = cnt;
							a[i][j] = cnt;
							cnt++;
						}
					}
				}
			}
				break;
			}else if(min(m, n) > 2){
				c+= 2;
				for(int i = 1;i <= n; i++){
					for(int j = 1;j <= m; j++){
						if(a[i][j] != -1) continue;
						if(i == c / 2 or j == c/ 2){
							a[i][j] = cnt;
							if(i + 1 == (n + 1 - (c / 2))) jp = false;
							if(j + 1 == (m + 1 - (c/ 2))) jp = false;
						}
						else if(i == (n + 1 - (c / 2)) or j == (m + 1 - (c/ 2))){
							a[i][j] = cnt;
						}
						
					}
				}
				cnt++;
			}else{
				jp = false;
				break;
			}
			
		}
		for(int i = 1;i <= n; i++){
			for(int j = 1;j <= m; j++){
				if(a[i][j] == -1) jp = false;
			}
		}
		if(jp){
		cout << "YES" << "\n";
		for(int i = 1;i <= n; i++){
			for(int j = 1;j <= m; j++){ 
				cout << a[i][j] << " ";
			}
			cout << "\n";
		}
		
		}else{
			cout << "NO" << "\n";
		}
		}
	
	
	
	return 0;
}