/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  Gardening
* score: 11.0
* date:  2021-12-16 08:27:06.771623
*/
#include <iostream>
#include <vector>
#define endl '\n'
using namespace std;

int c;
vector< vector<int> > table;

void solve(int n, int m, int k, int i0, int j0, bool flag)
{
    if (n == 0 or m == 0 or c > k) return;
    int x = n * m - (k - c) * 4;
    if (x == 4 or flag)
    {
        for (int i = i0; i < i0 + 2; ++ i)
        {
            for (int j = j0; j < j0 + 2; ++ j)
            {
                table[i][j] = c;
            }
        }
        c++;
        solve(2, m - 2, k, i0, j0 + 2, true);
        solve(n - 2, m, k, i0 + 2, j0, true);
    }
    else if (x > 2 * (n + m - 2))
    {
        for (int j = j0; j < j0 + m; ++ j)
        {
            table[i0][j] = c;
            table[i0 + n - 1][j] = c;
        }
        for (int i = i0; i < i0 + n; ++ i)
        {
            table[i][j0] = c;
            table[i][j0 + m - 1] = c;
        }
        c++;
        solve(n - 2, m - 2, k, i0 + 1, j0 + 1, false);
    }
    else
    {
        if (x == 8) return;
        x = (x + 4) / 2;
        int n1, m1;
        if (x >= n + 4)
        {
            n1 = n;
            m1 = x - n;
        }
        else
        {
            n1 = x - 4;
            m1 = 4;
        }

        if (n1 > n or m1 > m) return;
        if (min(n1, m1) == 2 and max(n1, m1) > 2) return;

        for (int j = j0; j < j0 + m1; ++ j)
        {
            table[i0][j] = c;
            table[i0 + n1 - 1][j] = c;
        }
        for (int i = i0; i < i0 + n1; ++ i)
        {
            table[i][j0] = c;
            table[i][j0 + m1 - 1] = c;
        }
        c++;
        solve(n1 - 2, m1 - 2, k, i0 + 1, j0 + 1, true);
        solve(n1, m - m1, k, i0, j0 + m1, true);
        solve(n - n1, m, k, i0 + n1, j0, true);
    }
}

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int t;
    cin >> t;

    while (t--)
    {
        int n, m, k;
        cin >> n >> m >> k;

        /*n = 4;
        m = 40;
        k = t;*/

        long long s = 1ll * n * m;

        if (n % 2 or m % 2)
        {
            cout << "NO" << endl;
            continue;
        }

        if (s < 4 * k)
        {
            cout << "NO" << endl;
            continue;
        }

        if (s > 4ll * k * k)
        {
            cout << "NO" << endl;
            continue;
        }

        table.resize(n + 1);
        for (int i = 1; i <= n; ++ i)
        {
            table[i].resize(m + 1, 0);
        }

        c = 1;
        solve(n, m, k, 1, 1, false);

        bool flag = true;
        for (int i = 1; i <= n; ++ i)
        {
            for (int j = 1; j <= m; ++ j)
            {
                if (table[i][j] < 1) flag = false;
            }
        }

        if (!flag or c <= k)
        {
            cout << "NO" << endl;
            continue;
        }

        cout << "YES" << endl;
        for (int i = 1; i <= n; ++ i)
        {
            for (int j = 1; j < m; ++ j)
            {
                cout << table[i][j] << " ";
            }
            cout << table[i][m] << endl;
        }
    }

    return 0;
}
