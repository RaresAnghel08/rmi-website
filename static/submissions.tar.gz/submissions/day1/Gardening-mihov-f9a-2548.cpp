/**
* user:  mihov-f9a
* fname: Boris Vladimirov
* lname: Mihov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:42:31.371115
*/
// Da-i, d-d-d-da-i, sistemul turbat, ala turbat, cel mai turbat

#include <iostream>
#include <ctime>
#include <vector>
using namespace std;
const int maxn = 7, maxm = 2e5+10;

double beg_time, end_time;
vector < int > t[maxm];
int operation[maxm];

int n, m, k;
int startX, startY;
int endX, endY;
int cnt;

void reset() {

    for (int i = 1 ; i <= n ; ++i)
        t[i].clear();

}

void fill_left() {

    for (int i = 0 ; i < (endX-startX+1)/2 ; ++i) {

        ++cnt;
        t[startX + 2*i][startY] = cnt;
        t[startX + 2*i][startY + 1] = cnt;
        t[startX + 2*i + 1][startY] = cnt;
        t[startX + 2*i + 1][startY + 1] = cnt;

    }

    startY += 2;

}

void fill_top() {
    
    for (int i = 0 ; i < (endY-startY+1)/2 ; ++i) {

        ++cnt;
        t[startX][startY + 2*i] = cnt;
        t[startX][startY + 2*i + 1] = cnt;
        t[startX + 1][startY + 2*i] = cnt;
        t[startX + 1][startY + 2*i + 1] = cnt;

    }

    startX += 2;

}

void fill_all() {
    
    ++cnt;
    for (int i = startX ; i <= endX ; ++i)
        t[i][startY] = t[i][endY] = cnt;

    for (int i = startY ; i <= endY ; ++i)
        t[startX][i] = t[endX][i] = cnt;

    ++startX;
    ++startY;
    --endX;
    --endY;

}

int tests;
void solve() {

    end_time = clock();
    if ((end_time - beg_time) / CLOCKS_PER_SEC > 0.1) {
        
        cout << "NO\n";
        return;
    
    }
    
    cin >> n >> m >> k;
    if (n % 2 == 1 || m % 2 == 1) {

        cout << "NO\n";
        return;

    }

    for (int i = 1 ; i <= n ; ++i)
        t[i].resize(m+1);

    int ncpy = n;
    int mcpy = m;
    int kcpy = k;
    
    startX = startY = 1;
    endX = n;
    endY = m;

    cnt = 0;
    for (int curr = 0 ; curr < 100 ; ++curr) {

        end_time = clock();
        n = ncpy / 2;
        m = mcpy / 2;
        k = kcpy;
        int success = 0;

        // cout << "here\n";

        for (int i = 0 ; true ; ++i) {
        
            if (n == 0 && m == 0 && k == 0) {

                success = i;
                break;

            }

            if (n == 0 || m == 0) break;
            if (k < 0) break;

            operation[i] = rand()%3;
            if (operation[i] == 0) {

                n -= 1;
                m -= 1;
                k -= 1;

            }

            if (operation[i] == 1) {

                n -= 1;
                k -= m;

            }

            if (operation[i] == 2) {

                m -= 1;
                k -= n;

            }
        
        }

        if (!success) continue;

        for (int i = 0 ; i < success ; ++i) {

            if (operation[i] == 0) fill_all();
            if (operation[i] == 1) fill_top();
            if (operation[i] == 2) fill_left();

        }

        cout << "YES\n";
        for (int i = 1 ; i <= ncpy ; ++i, cout << '\n')
            for (int j = 1 ; j <= mcpy ; ++j)
                cout << t[i][j] << ' ';

        return;

    }

    cout << "NO\n";

}

void fast_io() {

    ios_base :: sync_with_stdio(0);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cerr.tie(nullptr);

}

int main () {

    beg_time = clock();
    srand(time(nullptr));

    fast_io();
    cin >> tests;

    for (int i = 1 ; i <= tests ; ++i) {

        reset();
        solve();

    }

    return 0;

}