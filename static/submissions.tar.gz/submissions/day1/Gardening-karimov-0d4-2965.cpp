/**
* user:  karimov-0d4
* fname: Renat Airatovich
* lname: Karimov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:23:24.656977
*/
#define _GLIBCXX_DEBUG
#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb push_back
#define ld long double

vector<vector<int>> ans;
int cnt = 1;

pair<int,int> kol(int n, int m){
    return {min(n, m) / 2, n * m / 4};
}

void rec(int i, int j, int n, int m, int k){
    if (k == 0) return;
    if (k == 1){
        int N = i + n, M = j + m;
        for (int ii = i; ii < i + n; ii++){
            for (int jj = j; jj < j + m; jj++){
                ans[ii][jj] = cnt;
            }
        }
        cnt++;
        return;
    }
    pair<int,int> p = kol(n - 2, m - 2);
    if (p.first + 1 <= k && k <= p.second + 1){
        rec(i + 1, j + 1, n - 2, m - 2, k - 1);
        for (int ii = i; ii < i + n; ii++){
            ans[ii][j] = ans[ii][j + m - 1] = cnt;
        }
        for (int jj = j; jj < j + m; jj++){
            ans[i][jj] = ans[i + n - 1][jj] = cnt;
        }
        cnt++;
        return;
    }
    for (int d = 2; d + 2 <= n; d += 2){
        pair<int,int> p = kol(d, m), pp = kol(n - d, m);
        if (p.first + pp.first <= k && k <= p.second + pp.second){
            int need = p.first;
            while(!(need + pp.first <= k && k <= need + pp.second)){
                need++;
            }
            rec(i, j, d, m, need);
            rec(i + d, j, n - d, m, k - need);
            return;
        }
    }
    for (int d = 2; d + 2 <= m; d += 2){
        pair<int,int> p = kol(n, d), pp = kol(n, m - d);
        if (p.first + pp.first <= k && k <= p.second + pp.second){
            int need = p.first;
            while(!(need + pp.first <= k && k <= need + pp.second)){
                need++;
            }
            rec(i, j, n, d, need);
            rec(i, j + d, n, m - d, k - need);
            return;
        }
    }
}

void solve(int n, int m, int k){
    if (n % 2 == 1 || m % 2 == 1){
        cout << "NO" << endl;
        return;
    }
    int mn = min(n, m) / 2, mx = n * m / 4;
    if (!(mn <= k && k <= mx)){
        cout << "NO" << endl;
        return;
    }
    ans.resize(n);
    for (int i = 0; i < n; i++){
        ans[i].resize(m);
    }
    cout << "YES" << endl;
    cnt = 1;
    rec(0, 0, n, m, k);
    for (int i = 0; i < n; i++){
        for (int j = 0; j < m; j++){
            cout << ans[i][j] << ' ';
        }
        cout << endl;
    }
}

signed main()
{
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif // LOCAL
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    while(t--){
        int n, m, k;
        cin >> n >> m >> k;
        solve(n, m, k);
    }
    return 0;
}
