/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:10:53.137932
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)


using namespace std;
typedef long long ll;
typedef pair<int,int> pii;

#include "speedrun.h"

int n;

vector<int> g[1001];

int sub[1001];
int par[1001];
void dfs(int u, int p){
	par[u] = p;
	sub[u] = 1;
	for(auto e : g[u]){
		if(e == p) continue;
		dfs(e, u);
		sub[u] += sub[e];
	}
}

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
		n = N;
		fr(i, 0, n){
			A[i] --, B[i] --;
			g[A[i]].pb(B[i]);
			g[B[i]].pb(A[i]);
		}
		dfs(0, 0);
		setHintLen(20);
		fr(i, 0, n){
			int mx = 0;
			int id = 0;
			for(auto u : g[i]){
				int tsz = sub[u];
				if(u == par[i]){
					tsz = N - sub[i];
				} 
				if(tsz > mx){
					mx = tsz;
					id = u;
				}
			}
			fr(j, 0, 20){
				if(id & (1<<j)) setHint(i+1, j+1, 1);
				else setHint(i+1, j+1, 0);
			}
		}
}
int L;
bool vis[1001];

bool fst[1001];

int cnt = 0;
bool ok[1001][1001];


void _run(int u, int pr){
	vis[u] = true;
	int nxt = 0;
	fr(i, 0, 20) if(getHint(i+1) == 1) nxt &= (1<<i);
	
	if(!fst[u]){
		++cnt;
		if(cnt == n){
			return;
		}
		fst[u] = true;
		if(!vis[nxt]){
			goTo(nxt+1);
			_run(nxt, u);
			return;
		}
		goTo(pr+1);
		_run(pr, u);
	}
	else{
		fr(i, 0, n){
			if(vis[i] || ok[u][i]) continue;
			ok[u][i] = true;
			bool edge = goTo(i+1);
			if(edge){
				_run(i, u);
				return;
			}
		}
	}
} 

void speedrun(int subtask, int N, int start) { /* your solution here */
	L = getLength();
	n = N;
	_run(start-1, start-1);
}

/*
int main(){

	return 0;
}
*/
