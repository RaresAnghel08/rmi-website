/**
* user:  popescu-96c
* fname: Ioan
* lname: Popescu
* task:  devil
* score: 0.0
* date:  2019-10-10 07:09:26.358410
*/
#include <bits/stdc++.h>
using namespace std;

char s[1000005];
int d[11];
int cl[1000005];

void solve(int Max, string c[11]){
    if(Max == 1){
        for(int i = 1; i <= d[Max] ; ++i) cout << c[Max];

        return ;
    }

    int cnt[11];
    string s[11];
    for(int i = 1; i <= 9 ; ++i) cnt[i] = 0;

    int st = 1, dr = d[Max], NR = 1;
    s[NR] = c[Max];
    cnt[NR] = d[Max];

    for(int i = 1; i < Max ; ++i){
        if(d[i] == 0) continue ;

        if(d[i] % (dr - st + 1) == 0){
            for(int j = 1; j <= d[i] / (dr - st + 1) ; ++j)
            s[NR] = s[NR] + c[i];
        }
        else{
            int Last = d[i] % (dr - st + 1) + st - 1;
            s[NR + 1] = s[NR];
            cnt[NR + 1] = cnt[NR] - (Last - st + 1);

            cnt[NR] = Last - st + 1;
            for(int j = 1; j <= d[i] / (dr - st + 1) + 1 ; ++j)
            s[NR] = s[NR] + c[i];
            ++NR;
            st = Last + 1;
        }
    }

    for(int i = 1; i <= 9 ; ++i) d[i] = cnt[i];

    solve(NR, s);
}

int main()
{
    freopen("1.in", "r", stdin);

    string c[11];
    for(int i = 1; i <= 9 ; ++i) c[i].push_back(i + '0');

    int t, k;
    scanf("%d", &t);

    while(t--){
        scanf("%d", &k);
        int n = 0;
        for(int i = 1; i <= 9 ; ++i)
            scanf("%d", &d[i]), n += d[i];

        int nr = k - 1;
        s[nr + 1] = NULL;
        for(int i = 9; i >= 1 && nr > 0 ; --i) while(d[i] > 0 && nr > 0) s[nr] = i + '0', --d[i], --nr;

        int Max = 0;
        for(int i = 9; i >= 1 ; --i) if(d[i]) {Max = i; break ;}

//        cerr << Max << " " << d[Max] << endl;

        solve(Max, c);

//        cerr << n << endl;

        cout << s + 1 << '\n';
    }

    return 0;
}


















