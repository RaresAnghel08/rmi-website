/**
* user:  magirescu-396
* fname: Tudor Stefan
* lname: Magirescu
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:14:07.457823
*/
#include "speedrun.h"
#include <iostream>
#include <vector>
#define NMAX 1000

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
    vector <int> nod[NMAX+10];
    int n = N;
    int deg[NMAX+10] = {0};

    for(int i=1; i<n; i++){
        nod[A[i]].push_back(B[i]);
        nod[B[i]].push_back(A[i]);
        deg[A[i]]++;
        deg[B[i]]++;
    }

    setHintLen(20);
    int center = 0;

    for(int i=1; i<=n; i++)
        if(deg[i] > 1){
            center = i;
            break;
        }
    for(int i=1; i<=n; i++)
        if(i != center)
            for(int j=1; j<=20; j++)
                if(((1 << (j - 1)) & center) > 0){
                    setHint(i, 1, j);
                }

    //exit(0);
}

void speedrun(int subtask, int N, int start) {
    bool ok = true;
    int n = N, center = 0;

    for(int j=1; j<=20; j++)
        if(getHint(j))
            ok = false;
    if(ok){
        for(int i=1; i<=n; i++)
            if(i != start)
                goTo(i), goTo(start);
    }
    else{
        for(int j=20; j; j--){
            center = 2 * center;
            if(getHint(j))
                center++;
        }
        goTo(center);
        for(int i=1; i<=n; i++)
            if(i != start && i != center)
                goTo(i), goTo(center);
    }
}
