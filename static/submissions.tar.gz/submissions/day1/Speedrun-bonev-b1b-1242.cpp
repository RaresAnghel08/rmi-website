/**
* user:  bonev-b1b
* fname: Tsvetomir
* lname: Bonev
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 07:29:19.538530
*/
#include "speedrun.h"

#include <bits/stdc++.h>

void assignHints(int subtask, int N, int A[], int B[]) {
    std::vector<std::vector<bool>> adjacency_matrix(N + 1, std::vector<bool>(N + 1, false));

    for (auto i = 1; i < N; ++i) {
        int u = A[i], v = B[i];

        adjacency_matrix[u][v] = true;
        adjacency_matrix[v][u] = true;
    }

    setHintLen(N);

    for (auto i = 1; i <= N; ++i) {
        for (auto j = 1; j <= N; ++j) {
            setHint(i, j, adjacency_matrix[i][j]);
        }
    }
}

void speedrun(int subtask, int N, int start) {
    auto is_adjacent = [&](int v) {
        return getHint(v);
    };

    std::vector<bool> visited(N + 1);
    auto remaining = N;

    std::function<bool(int)> dfs;
    dfs = [&](int u) {
        visited[u] = true;
        --remaining;

        if (remaining <= 0) {
            return true;
        }

        for (auto v = 1; v <= N; ++v) {
            if (!is_adjacent(v)) {
                continue;
            }

            if (visited[v]) {
                continue;
            }

            goTo(v);

            if (dfs(v)) {
                return true;
            }

            goTo(u);
        }

        return false;
    };

    dfs(start);
}
