/**
* user:  coroian-5c7
* fname: David Nicolae
* lname: Coroian
* task:  lucky
* score: 28.0
* date:  2019-10-10 10:12:59.828583
*/
#include <bits/stdc++.h>
//#include <fstream>

#define MAX_N 100000

using namespace std;

//ifstream cin("l.in");
//ofstream cout("l.out");

string s;

typedef long long lint;

const int MOD = (int)(1e9) + 7;

int n, q;
int v[MAX_N + 1];

void ansQues()
{
    cin >> n >> q;

    cin >> s;
}

void modd(lint &a)
{
    if(a >= MOD)
        a -= MOD;
}

lint dp[MAX_N + 1][10][2];

void solve()
{
    for(int i = 1; i <= n; i ++)
        v[i] = s[i - 1] - '0';

    dp[0][0][1] = 1;
    for(int i = 1; i <= n; i ++)
    {

        for(int j = 0; j <= 9; j ++)
        {
            for(int h = 0; h <= 9; h ++)
            {
                if(!(j == 1 && h == 3))
                {
                    dp[i][h][0] += dp[i - 1][j][0];
                    modd(dp[i][h][0]);
                }

            }
        }

        if(!(v[i - 1] == 1 && v[i] == 3))
        {
            dp[i][v[i]][1] += dp[i - 1][v[i - 1]][1];
            modd(dp[i][v[i]][1]);
        }

        for(int j = 0; j < v[i]; j ++)
        {
            if(!(v[i - 1] == 1 && j == 3))
            {
                dp[i][j][0] += dp[i - 1][v[i - 1]][1];
                modd(dp[i][j][0]);
            }
        }

    }

    lint rez = 0;
    for(int i = 0; i <= 9; i ++)
    {
        for(int h = 0; h <= 1; h ++)
        {
            rez = rez + dp[n][i][h];
            modd(rez);
        }
    }

    cout << rez << "\n";
}

int main()
{
    ansQues();

    solve();

    return 0;
}
