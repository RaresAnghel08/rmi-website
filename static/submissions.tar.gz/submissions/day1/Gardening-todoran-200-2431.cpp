/**
* user:  todoran-200
* fname: Alexandru Raul
* lname: Todoran
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:32:03.080041
*/
/**
 ____ ____ ____ ____ ____
||a |||t |||o |||d |||o ||
||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|

**/

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int NM_MAX = 200000;

int mn (int N, int M) {
    return max(N, M) / 2;
}
int mx (int N, int M) {
    return N * M / 4;
}

bool check (int N, int M, int K) {
    return (mn(N, M) <= K && K <= mx(N, M));
}

bool solve (int N, int M, int K, vector <vector <int>> &mat, int x = 0, int y = 0, int curr = 0) {
    if (check(N, M, K) == false) {
        return false;
    }
    if (K == N * M / 4) {
        for (int i = 0; i < N; i += 2) {
            for (int j = 0; j < M; j += 2) {
                curr++;
                mat[x + i    ][y + j    ] = curr;
                mat[x + i + 1][y + j    ] = curr;
                mat[x + i    ][y + j + 1] = curr;
                mat[x + i + 1][y + j + 1] = curr;
            }
        }
        return true;
    }
    if (N == 2 || M == 2) {
        return false;
    }
    if (solve(N - 2, M - 2, K - 1, mat, x + 1, y + 1, curr) == true) {
        for (int i = 0; i < N; i++) {
            mat[x + i][y + 0] = curr + K;
            mat[x + i][y + (M - 1)] = curr + K;
        }
        for (int j = 0; j < M; j++) {
            mat[x + 0][y + j] = curr + K;
            mat[x + (N - 1)][y + j] = curr + K;
        }
        return true;
    }
    for (int n = 2; n * 2 <= N; n += 2) {
        // mn(n, M) <= k <= mx(n, M)
        // mn(N - n, M) <= K - k <= mx(N - n, M)
        // K - mx(N - n, M) <= k <= K - mn(N - n, M)
        int L = max(mn(n, M), K - mx(N - n, M));
        int R = min(mx(n, M), K - mn(N - n, M));
        for (int k = L; k <= R; k++) {
            if (solve(n, M, k, mat, x, y, curr) == true
             && solve(N - n, M, K - k, mat, x + n, y, curr + k) == true) {
                return true;
            }
        }
    }
    for (int m = 2; m * 2 <= M; m += 2) {
        // mn(N, m) <= k <= mx(N, m)
        // mn(N, M - m) <= K - k <= mx(N, M - m)
        // K - mx(N, M - m) <= k <= K - mn(N, M - m)
        int L = max(mn(N, m), K - mx(N, M - m));
        int R = min(mx(N, m), K - mn(N, M - m));
        for (int k = L; k <= R; k++) {
            if (solve(N, m, k, mat, x, y, curr) == true
             && solve(N, M - m, K - k, mat, x, y + m, curr + k) == true) {
                return true;
            }
        }
    }
    return false;
}

int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int t;
    cin >> t;

    while(t--) {
        int N, M, K;
        cin >> N >> M >> K;
        if (N % 2 != 0 || M % 2 != 0) {
            cout << "NO\n";
            continue;
        }
        if (check(N, M, K) == false) {
            cout << "NO\n";
            continue;
        }
        vector <vector <int>> mat (N, vector <int> (M));
        if (solve(N, M, K, mat) == false) {
            cout << "NO\n";
            continue;
        }
        cout << "YES\n";
        for (int i = 0; i < N; i++, cout << "\n") {
            for (int j = 0; j < M; j++) {
                cout << mat[i][j] << " ";
            }
        }
    }

    return 0;
}
