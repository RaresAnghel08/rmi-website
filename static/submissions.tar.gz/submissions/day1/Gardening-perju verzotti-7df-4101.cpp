/**
* user:  perju verzotti-7df
* fname: Luca
* lname: Perju Verzotti
* task:  Gardening
* score: 50.0
* date:  2021-12-16 11:57:13.164006
*/
#include <bits/stdc++.h>

using namespace std;
vector<int>v[200005];
int okt=0;
bool solve (int n, int m, int k, int l, int c, int vlc)
{
    int i,j;
    if(n%2 || m%2 || k>(n*m/4) || k==0)
        return false;
    if(n==2)
    {
        for(int i=2;i<=m;i+=2)
        {
            v[l][c+i-2]=vlc;
            v[l][c+i-1]=vlc;
            v[l+1][c+i-2]=vlc;
            v[l+1][c+i-1]=vlc;
            ++vlc;
            --k;
        }
        if(k==0)
            return true;
        return false;
    }
    if(m==2)
    {
        for(int i=2;i<=n;i+=2)
        {
            v[l+i-2][c]=vlc;
            v[l+i-1][c]=vlc;
            v[l+i-1][c+1]=vlc;
            v[l+i-2][c+1]=vlc;
            ++vlc;
            --k;
        }
        if(k==0)
            return true;
        return false;
    }
    int amc=(n*m)/4;
    if(k==amc-1)
        return false;
    if(k==amc)
    {
        for(i=1;i<=n;i+=2)
        {
            for(j=1;j<=m;j+=2)
            {
                solve(2,2,1,l+i-1,c+j-1,vlc++);
            }
        }
        return true;
    }
    int need=amc-k;
    int cneed=need,cvlc=vlc;
    bool okc=true,solved=false;
    if(1)
    {
        int scadmx=(n/4)*(2+(m-4)/2);
        //if(amc-scadmx>k || k-1==(n-2)*(m-2)/4)
        //{
            for(i=1;i<=n;++i)
                v[l+i-1][c]=v[l+i-1][c+m-1]=vlc;
            for(j=1;j<=m;++j)
                v[l][c+j-1]=v[l+n-1][c+j-1]=vlc;
            okc= solve(n-2,m-2,k-1,l+1,c+1,vlc+1);
            if(okc==true)
                solved=true;
        //}
        int mxpl=(2+(m-4)/2);
        if(!solved)
        for(i=1;i+3<=n;i+=4)
        {
            int catscad=min(need,mxpl);
            if(need-catscad==1)
            {
                catscad--;
                if(catscad==1)
                {
                    okc=false,solved=true;
                    break;
                }

            }
            int cc=c;
            if(catscad)
            {
                solve(4,catscad*2,catscad,l+i-1,c,vlc);
                vlc+=catscad;
                cc=c+catscad*2;
            }
            for(j=cc;j<=c+m-1;j+=2)
            {
                solve(2,2,1,l+i-1,j,vlc++);
                solve(2,2,1,l+2+i-1,j,vlc++);
            }
            need-=catscad;
        }
        if(!solved)
        if(i+1==n)
        {
            for(j=c;j<=c+m-1;j+=2)
                solve(2,2,1,l+i-1,j,vlc++);
        }
        if(!solved){
        if(need==0)
            okc=true;
        else
            okc=false;
        }
    }
    if(okc==true)
        return true;
    need=cneed;
    vlc=cvlc;
    if(1)
    {
        int scadmx=(m/4)*(2+(n-4)/2);
        if(amc-scadmx>k || k-1==(n-2)*(m-2)/4)
        {
            for(i=1;i<=n;++i)
                v[l+i-1][c]=v[l+i-1][c+m-1]=vlc;
            for(j=1;j<=m;++j)
                v[l][c+j-1]=v[l+n-1][c+j-1]=vlc;
            return solve(n-2,m-2,k-1,l+1,c+1,vlc+1);
        }
        int mxpl=(2+(n-4)/2);
        for(j=1;j+3<=m;j+=4)
        {
            int catscad=min(need,mxpl);
            if(need-catscad==1)
            {
                catscad--;
                if(catscad==1)
                    return false;
            }
            int ll=l;
            if(catscad)
            {
                solve(catscad*2,4,catscad,l,c+j-1,vlc);
                //solve(4,catscad*2,catscad,l+i-1,c,vlc);
                vlc+=catscad;
                ll=l+catscad*2;
            }
            for(i=ll;i<=l+n-1;i+=2)
            {
                //solve(2,2,1,l+i-1,j,vlc++);
                solve(2,2,1,i,c+j-1,vlc++);
                //solve(2,2,1,l+2+i-1,j,vlc++);
                solve(2,2,1,i,c+2+j-1,vlc++);
            }
            need-=catscad;
        }
        if(j+1==m)
        {
            for(i=l;i<=l+n-1;i+=2)
                solve(2,2,1,i,c+j-1,vlc++);
        }
        if(need==0)
            return true;
        return false;
    }
}
int main()
{
    int n,i,j,t,m,k,okc;
    cin>>t;
    while(t--)
    {
        okc=0;
        cin>>n>>m>>k;
        if(n==6)
        {
            swap(n,m);
            okc=1;
        }
        if(n%2 || m%2 || k>(n*m/4))
        {
            cout<<"NO\n";
            continue;
        }
        for(i=1;i<=n;++i)
            v[i].resize(m+2);
        if(solve(n,m,k,1,1,1))
        {
            cout<<"YES\n";
            if(!okc)
            for(i=1;i<=n;++i)
            {
                for(j=1;j<=m;++j)
                {
                    cout<<v[i][j]<<' ';
                }
                cout<<'\n';
            }
            else
            for(j=1;j<=m;++j)
            {
                for(i=1;i<=n;++i)
                {
                    cout<<v[i][j]<<' ';
                }
                cout<<'\n';
            }
        }
        else
        {
            cout<<"NO\n";
        }
    }
    return 0;
}
