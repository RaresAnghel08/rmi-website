/**
* user:  mitrica-67d
* fname: Alessia Georgiana Gabriela
* lname: Mitrică
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:36:00.727770
*/
#include <iostream>

using namespace std;
int t,n,m,k,a[1001][1001];
int main()
{
    cin>>t;
    while(t--)
    {
        cin>>n>>m>>k;
        if(k==1&&m!=n)
            cout<<"NO"<<"\n";
        else
            if(k==1&&m==n&&m!=k)
        {
            cout<<"YES\n";
            for(int i=1;i<=n;i++)
            {
                for(int j=1;j<=n;j++)
                    cout<<1<<" ";
                cout<<"\n";
            }
        }
        else
        if(n==1)
        {
            if(m==k)
            {
                cout<<"YES\n";
            for(int i=1;i<=k;i++)
                cout<<i<<" ";
            }
            else
            {
                cout<<"NU\n";
            }
        }
        else
        if(m==1)
        {
            if(n==k)
            {
                cout<<"YES\n";
            for(int i=1;i<=k;i++)
                cout<<i<<" ";
            }
            else
            {
                cout<<"NU\n";
            }
        }
        else
        {
            if(n==m&&n>3)
                if(k==2)
            {
                cout<<"YES\n";
                for(int i=1;i<=n;i++)
                    a[1][i]=a[n][i]=a[i][1]=a[i][n]=1;
                for(int i=1;i<=n;i++)
                 {
                  for(int j=1;j<=n;j++)
                {
                    if(a[i][j]==0)
                        a[i][j]=2;
                    cout<<a[i][j]<<" ";

                }
                cout<<"\n";
                 }
            }
                if(n==m&&k==2&&(n==2||n==3))
                 cout<<"NO\n";
             else
                if(k==4&&n%2==0&&m==n)
             {
                 cout<<"YES\n";
                 for(int i=1;i<=n/2;i++)
                    for(int j=1;j<=n/2;j++)
                       a[i][j]=1;
                 for(int i=1;i<=n/2;i++)
                    for(int j=n/2+1;j<=n;j++)
                      a[i][j]=2;
                 for(int i=n/2+1;i<=n;i++)
                    for(int j=1;j<=n/2;j++)
                      a[i][j]=3;
                 for(int i=n/2+1;i<=n;i++)
                    for(int j=n/2+1;j<=n;j++)
                     a[i][j]=4;

                 for(int i=1;i<=n;i++)
                 {
                     for(int j=1;j<=n;j++)
                        cout<<a[i][j]<<" ";
                     cout<<"\n";
                 }
             }
        }
      if(n==m&&k==n*m&&n!=2)
      {
          cout<<"YES\n";
          int x=1;
          for(int i=1;i<=n;i++)
          {
              for(int j=1;j<=n;j++)
              {
                  cout<<x<<" ";
                  x++;
              }
              cout<<"\n";
          }
      }
      if(n==2&&m==3||n==3&&m==2)
        cout<<"NO\n";
      else
      {
          if(n<m)
          {
              if(m==k*n)
              {
                  cout<<"YES\n";
                  for(int i=1;i<=n;i++)
                  {
                      for(int j=1;j<=m;j++)
                      {
                          if(j%k!=0)
                          a[i][j]=j/k+1;
                          else
                            a[i][j]=j/k;
                      }
                  }
                  for(int i=1;i<=n;i++)
                 {
                     for(int j=1;j<=m;j++)
                        cout<<a[i][j]<<" ";
                     cout<<"\n";
                 }
              }
          }
          else
            if(m<n)
          {
              if(n==k*m)
              {
                  cout<<"YES\n";
                  for(int j=1;j<=m;j++)
                  {
                      for(int i=1;i<=n;i++)
                      {
                          if(i%k!=0)
                          a[i][j]=i/k+1;
                          else
                            a[i][j]=i/k;
                      }
                  }
                  for(int i=1;i<=n;i++)
                 {
                     for(int j=1;j<=m;j++)
                        cout<<a[i][j]<<" ";
                     cout<<"\n";
                 }
              }
          }
      }
      for(int i=1;i<=n;i++)
         for(int j=1;j<=n;j++)
           a[i][j]=0;

    }
    return 0;
}
