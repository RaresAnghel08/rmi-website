/**
* user:  marciuc-b16
* fname: Andrei
* lname: Marciuc
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:57:03.932427
*/
#include <iostream>
using namespace std;

int n, m, k;

int main()
{
    int q;
    cin >> q;
    while( q-- ) {
        cin >> n >> m >> k;

        int lin = ( n >> 1 );
        int col = ( m >> 1 );
        int maxx = lin * col;

        if( k > maxx || n == 1 || m == 1 || ( n & 1 ) || ( m & 1 ) )
            cout << "NO\n";
        else {
            int culoare = 1, val = 0;
            int a[ n + 10 ][ m + 10 ];
            while( maxx + val > k ) {
                for( int l = val; l < n - val; l++ )
                    a[ l ][ val ] = a[ l ][ m - val - 1 ] = culoare;
                for( int c = val; c < m - val; c++ )
                    a[ val ][ c ] = a[ n - val - 1 ][ c ] = culoare;
                ++val;
                ++culoare;
                lin = ( n - val * 2 + 1 ) >> 1;
                col = ( m - val * 2 + 1 ) >> 1;
                maxx = lin * col;

            }

            //cout << maxx << '\n';
            if( maxx == 0 )
                if( n == m ) {
                        cout << "YES\n";
                    for( int l = 0; l < n; l++ ) {
                    for( int c = 0; c < m; c++ )
                        cout << a[ l ][ c ] << ' ';
                    cout << '\n';
                }
                } else  cout << "NO\n";
            else if( maxx + val == k ) {
                cout << "YES\n";
                int l = val;
               // ++culoare;
                for( ; l + 1 < n - val; l += 2 )
                    for( int c = val; c + 1 < m - val; c += 2, culoare++ ){
                        a[ l ][ c ] = culoare;
                        a[ l + 1 ][ c ] = culoare;
                        a[ l ][ c + 1 ] = culoare;
                        a[ l + 1 ][ c + 1 ] = culoare;
                    }
                for( l = 0; l < n; l++ ) {
                    for( int c = 0; c < m; c++ )
                        cout << a[ l ][ c ] << ' ';
                    cout << '\n';
                }
            } else cout << "NO\n";
        }
    }
    //20 20 1 ( par impar )
    return 0;
}
