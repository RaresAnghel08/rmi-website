/**
* user:  licht-5c2
* fname: Noam
* lname: Licht
* task:  devil
* score: 0.0
* date:  2019-10-10 07:46:47.551983
*/
#include <bits/stdc++.h>
#define int int64_t
#define vi vector<int>
#define ii pair<int,int>
#define vii vector<ii>
#define vvi vector<vi>
#define x first
#define y second
#define loop(i,s,e) for(int i=(s);i<(e);++i)
#define mp make_pair
#define pb push_back
#define chkmax(a,b) a=max(a,b)
#define chkmin(a,b) a=min(a,b)
using namespace std;
using ll=long long;
using ld=long double;
const int INF=1e18;
int k;
int m=9;
int n;
int ma = INF;
vi dig(m);
vi num,ans;

void check(){
    int max_s = 0;
    for(int i=0;i<n-k+1;i++){
        int sub = 0;
        for(int j=0;j<k;j++){
            sub*=10;
            sub += num[i+j];
        }
        chkmax(max_s,sub);
    }
    if (max_s<ma){
        loop(i,0,n) ans[i]=num[i];
        ma = max_s;
    }
}

void dfs(int cnt){
    if(cnt==0){
        check();
        return;
    }
    loop(i,0,m){
        if (dig[i]>0){
            dig[i]--;
            num[n-cnt]=i;
            dfs(cnt-1);
            dig[i]++;
        }
    }
}
void solve(){
    cin>>k;
    n=0;
    loop(i,0,m) cin>>dig[i], n+=dig[i];
    num.resize(n);
    ans.resize(n);
    dfs(n);
    //num = {2,3,1,3};
    //check();
    loop(i,0,n) cout<<(ans[i]+1);
    cout<<endl;
}
int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int t; cin>>t;
    loop(i,0,t) solve();
    return 0;
}

