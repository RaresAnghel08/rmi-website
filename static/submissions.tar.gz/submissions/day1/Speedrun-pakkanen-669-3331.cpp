/**
* user:  pakkanen-669
* fname: Mariia
* lname: Pakkanen
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 10:55:44.659387
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;


void assignHints(int subtask, int N, int A[], int B[]) {
    int n = N;
    int siz[n + 1];
    for(int i = 0; i <= n; ++i)
        siz[i] = 0;
    for(int i = 1; i < n; ++i){
        siz[A[i]]++;
        siz[B[i]]++;
    }
    int ms = 1;
    for(int i = 1; i <= n; ++i){
        if(siz[ms] < siz[i])
            ms = i;
    }
    if(subtask == 2){
        vector <bool> a;
        int cpy = ms;
        while(cpy > 0){
            a.push_back(cpy % 2);
            cpy /= 2;
        }
        reverse(a.begin(), a.end());
        setHintLen(a.size());
        for(int i = 1; i <= n; ++i){
            for(int j = 0; j < a.size(); ++j)
                setHint(i, j+1, a[j]);
        }
    }
    else if(subtask == 3){
        setHintLen(20);
        vector <int> g[n+1];
        for(int i = 1; i < n; ++i){
            g[A[i]].push_back(B[i]);
            g[B[i]].push_back(A[i]);
        }
        for(int i = 1; i <= n; ++i){
            vector <bool> f;
            int cpy = g[i][0];
            while(cpy > 0){
                f.push_back(cpy % 2);
                cpy /= 2;
            }
            reverse(f.begin(), f.end());
            for(int j = 10 - f.size() + 1, j1 = 0;  j <= 10, j1 < f.size(); ++j, ++j1){
                setHint(i, j, f[j1]);
            }
            if(g[i].size() == 1)
                continue;
            cpy = g[i][1];
            f.clear();
            while(cpy > 0){
                f.push_back(cpy % 2);
                cpy /= 2;
            }
            reverse(f.begin(), f.end());
            for(int j = 20 - f.size() + 1, j1 = 0;  j <= 20, j1 < f.size(); ++j, ++j1){
                setHint(i, j, f[j1]);
            }
        }
    }
    else if(subtask == 1){
        setHintLen(n);
        for(int i = 1; i < n; ++i){
            setHint(A[i], B[i], 1);
            setHint(B[i], A[i], 1);
        }
        return;
    }
    return;
}

vector <bool> usd(1015);
void dfs(int v, int p, int n)
{
    usd[v] = true;
    vector <bool> g(n+1, 0);
    for(int i = 1; i <= n; ++i)
        g[i] = getHint(i);
    for(int i = 1; i <= n; ++i){
        if(!usd[i] && g[i]){
            goTo(i);
            dfs(i, v, n);
        }
    }
    if(p != 0)goTo(p);
}

void speedrun(int subtask, int N, int start) {
    int as = getLength();
    if(subtask == 1){
        dfs(start, 0, N);
    }
    else if(subtask == 2) {
        vector<int> a(as + 1);
        for (int i = 1; i <= as; ++i) {
            a[i] = getHint(i);
        }
        int x = 0;
        for (int i = 1; i <= as; ++i) {
            x = x * 2 + a[i];
        }
        vector<bool> used(N + 1, false);
        used[start] = true;
        int cur = 1;
        if (start != x) {
            if (goTo(x))
                start = x;
        }
        used[start] = true;
        for (int i = 1; i <= N; ++i) {
            if (used[i])
                continue;
            used[i] = true;
            if (goTo(x))
                start = x;
            if (goTo(i))
                start = i;
        }
        return;
    }
    else if(as == 20){
        vector <pair <int, int> > g(N+1, {0, 0});
        for(int i = 1; i <= 10; ++i){
            int cc = getHint(i);
            g[start].first = g[start].first * 2 + cc;
        }
        for(int i = 11; i <= 20; ++i){
            int cc = getHint(i);
            g[start].second = g[start].second * 2 + cc;
        }
        while(g[start].second != 0){
            int to = g[start].second;
            goTo(to);
            g[to] = {0, 0};
            for(int i = 1; i <= 10; ++i){
                int cc = getHint(i);
                g[to].first = g[to].first * 2 + cc;
            }
            for(int i = 11; i <= 20; ++i){
                int cc = getHint(i);
                g[to].second = g[to].second * 2 + cc;
            }
            if(g[to].second == start)
                swap(g[to].first, g[to].second);
            start = to;
        }
        swap(g[start].first, g[start].second);
        while(g[start].second != 0){
            int to = g[start].second;
            goTo(to);
            g[to] = {0,0};
            for(int i = 1; i <= 10; ++i){
                int cc = getHint(i);
                g[to].first = g[to].first * 2 + cc;
            }
            for(int i = 11; i <= 20; ++i){
                int cc = getHint(i);
                g[to].second = g[to].second * 2 + cc;
            }
            if(g[to].second == start)
                swap(g[to].first, g[to].second);
            start = to;
        }
        return;
    }
    return;

}
