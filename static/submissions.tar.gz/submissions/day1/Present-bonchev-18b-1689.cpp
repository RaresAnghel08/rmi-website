/**
* user:  bonchev-18b
* fname: Petar Plamenov
* lname: Bonchev
* task:  Present
* score: 8.0
* date:  2021-12-16 08:19:16.843619
*/
#include <iostream>
#include <vector>

using namespace std;

typedef long long ll;

int t;
ll k;

vector<ll> a;
ll br=1;

bool bs(const ll &x)
{
	int i=0,j=a.size()-1;
	int m=(i+j)/2;
	
	while(a[m]!=x&&i<=j)
	{
		if(a[m]>x) j=m-1;
		else i=m+1;
		m=(i+j)/2;
	}
	
	if(a[m]==x) return true;
	return false;
}

ll nod(ll x,ll y)
{
	while(y)
	{
		int r=x%y;
		x=y;
		y=r;
	}
	
	return x;
}

void nextA()
{
	int x=-1,y=-1;

	if(a[0]!=1) {x=0;y=1;}
	else 
		for(int i=1;i<a.size();i++)
		{
			if(a[i-1]+1<a[i])
			{
				x=i;
				y=a[i-1]+1;
				break;
			}
		}
	if(x==-1)
	{
		x=a.size();
		y=a[x-1]+1;
	}
	
	vector<ll> b;
	b.push_back(y);
	for(int i=x;i<a.size();i++)
		b.push_back(a[i]);
	
	a=b;
}

void printA()
{
	cout<<a.size()<<" ";
	for(int i=0;i<a.size();i++)
		cout<<a[i]<<" ";
	cout<<endl;
}

bool lora()
{
	for(int i=0;i<a.size()-1;i++)
	{
		for(int j=i+1;j<a.size();j++)
		{
			if(!bs(nod(a[i],a[j])))
				return false;
		}
	}
	
	return true;
}

int main()
{
	a.push_back(1);
	
	vector<ll> ans[8];
	
	cin>>t;
	
	for(int i=0;i<t;i++)
	{
		cin>>k;
		
		if(k==0)
		{
			a.clear();
			ans[i]=a;
			continue;
		}
		
		a.clear();
		a.push_back(1);
		br=1;
		
		while(br<k)
		{
			nextA();
			
			if(lora())
			{
				br++;
			}
		}
		
		ans[i]=a;
	}
	
	for(int i=0;i<t;i++)
	{
		cout<<ans[i].size();
		for(int j=0;j<ans[i].size();j++)
			cout<<" "<<ans[i][j];
		cout<<endl;
	}
}
