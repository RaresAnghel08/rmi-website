/**
* user:  todorov-dbc
* fname: Andon
* lname: Todorov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:49:29.424589
*/
#include <bits/stdc++.h>
using namespace std;

vector <vector <int> > solve2 (int m, int k){

    /*if (k != m / 2){
        cout << "NO\n";
        return;
    }
    cout << "YES\n";*/
    vector <vector <int> > a;
    for (int i = 0; i < 2; i ++){
        vector <int> b (m, 0);
        a.push_back (b);
    }
    int idx = 1;
    for (int i = 0; i < m; i += 2){
        a [0][i] = a [1][i] = a [0][i + 1] = a [1][i + 1] = idx ++;
    }
    /*for (int i = 0; i < 2; i ++){
        for (int j = 0; j < m; j ++){
            cout << a [i][j] << ' ';
        }
        cout << '\n';
    }*/
    return a;

}

vector <vector <int> > solve4 (int m, int k){

    vector <vector <int> > a;
    for (int i = 0; i < 4; i ++){
        vector <int> b (m, 0);
        a.push_back (b);
    }
    int x = k - m / 2, idx = 1;
    for (int i = 0; i < x; i ++){
        a [0][2 * i] = a [1][2 * i] = a [0][2 * i + 1] = a [1][2 * i + 1] = idx ++;
        a [2][2 * i] = a [3][2 * i] = a [2][2 * i + 1] = a [3][2 * i + 1] = idx ++;
    }
    if (x < m / 2){
        for (int i = 2 * x; i < m; i ++){
            a [0][i] = a [3][i] = idx;
        }
        a [1][2 * x] = a [2][2 * x] = a [1][m - 1] = a [2][m - 1] = idx ++;
        for (int i = 2 * x + 1; i < m - 1; i += 2){
            a [1][i] = a [2][i] = a [1][i + 1] = a [2][i + 1] = idx ++;
        }
    }

    return a;

}

vector <vector <int> > solve6 (int m, int k){

    if (m == 2){
        if (k == 3) return {{1, 1}, {1, 1}, {2, 2}, {2, 2}, {3, 3}, {3, 3}};
        //cout << "YES\n1 1\n1 1\n2 2\n2 2\n3 3\n3 3\n";
        //else cout << "NO\n";
    }
    /*if (m == 4 && k == 2){
        cout << "NO\n";
        return;
    }
    if (k > 3 * m / 2 || k < m / 2 || k == 3 * m / 2 - 1 || k == m - 2 && m < 8){
        cout << "NO\n";
        return;
    }
    cout << "YES\n";*/
    vector <vector <int> > a;
    for (int i = 0; i < 6; i ++){
        vector <int> b (m, 0);
        a.push_back (b);
    }
    int idx = 1;
    if (k == 3 * m / 2){
        for (int i = 0; i < 6; i += 2){
            for (int j = 0; j < m; j += 2){
                a [i][j] = a [i + 1][j] = a [i][j + 1] = a [i + 1][j + 1] = idx ++;
            }
        }
    }
    else if (k >= m){
        int x = k - m;
        for (int i = 0; i < x; i ++){
            a [0][2 * i] = a [1][2 * i] = a [0][2 * i + 1] = a [1][2 * i + 1] = idx ++;
            a [2][2 * i] = a [3][2 * i] = a [2][2 * i + 1] = a [3][2 * i + 1] = idx ++;
        }
        for (int i = 2 * x; i < m; i ++){
            a [0][i] = a [3][i] = idx;
        }
        a [1][2 * x] = a [2][2 * x] = a [1][m - 1] = a [2][m - 1] = idx ++;
        for (int i = 2 * x + 1; i < m - 1; i += 2){
            a [1][i] = a [2][i] = a [1][i + 1] = a [2][i + 1] = idx ++;
        }
        for (int i = 0; i < m; i += 2){
            a [4][i] = a [4][i + 1] = a [5][i] = a [5][i + 1] = idx ++;
        }
    }
    else if (k == m - 1){
        for (int i = 0; i < m; i ++) a [0][i] = a [5][i] = idx;
        for (int i = 1; i < 5; i ++) a [i][0] = a [i][m - 1] = idx;
        idx ++;
        for (int i = 1; i < 5; i += 2){
            for (int j = 1; j < m - 1; j += 2){
                a [i][j] = a [i + 1][j] = a [i][j + 1] = a [i + 1][j + 1] = idx ++;
            }
        }
    }
    else if (k == m - 2){
        for (int i = 0; i < 6; i ++) a [i][0] = a [i][3] = idx;
        a [0][1] = a [0][2] = a [5][1] = a [5][2] = idx ++;
        a [1][1] = a [1][2] = a [2][1] = a [2][2] = idx ++;
        a [3][1] = a [3][2] = a [4][1] = a [4][2] = idx ++;
        for (int i = 4; i < m; i ++) a [0][i] = a [5][i] = idx;
        for (int i = 1; i < 5; i ++) a [i][4] = a [i][m - 1] = idx;
        idx ++;
        for (int i = 1; i < 5; i += 2){
            for (int j = 5; j < m - 1; j += 2){
                a [i][j] = a [i + 1][j] = a [i][j + 1] = a [i + 1][j + 1] = idx ++;
            }
        }
    }
    else{
        for (int i = 0; i < m; i ++) a [0][i] = a [5][i] = idx;
        for (int i = 1; i < 5; i ++) a [i][0] = a [i][m - 1] = idx;
        idx ++;
        int x = k - m / 2;
        for (int i = 0; i < x; i ++){
            a [1][2 * i + 1] = a [2][2 * i + 1] = a [1][2 * i + 2] = a [2][2 * i + 2] = idx ++;
            a [3][2 * i + 1] = a [4][2 * i + 1] = a [3][2 * i + 2] = a [4][2 * i + 2] = idx ++;
        }
        for (int i = 2 * x + 1; i < m - 1; i ++){
            a [1][i] = a [4][i] = idx;
        }
        a [2][2 * x + 1] = a [3][2 * x + 1] = a [2][m - 2] = a [3][m - 2] = idx ++;
        for (int i = 2 * x + 2; i < m - 2; i += 2){
            a [2][i] = a [3][i] = a [2][i + 1] = a [3][i + 1] = idx ++;
        }
    }
    /*for (int i = 0; i < 6; i ++){
        for (int j = 0; j < m; j ++){
            cout << a [i][j] << ' ';
        }
        cout << '\n';
    }*/
    return a;

}

vector <vector <int> > solve (int n, int m, int k){

    if (n == 6) return  solve6 (m, k);
    if (n == 4) return solve4 (m, k);
    if (n == 2) return solve2 (m, k);

    vector <vector <int> > a;
    for (int i = 0; i < n; i ++){
        vector <int> b (m, 0);
        a.push_back (b);
    }
    if (k >= m){
        auto a1 = solve (n - 2, m, k - m / 2);
        for (int i = 0; i < n - 2; i ++){
            for (int j = 0; j < m; j ++){
                a [i][j] = a1 [i][j];
            }
        }
        int idx = k - m / 2;
        for (int i = 0; i < m; i += 2){
            a [n - 2][i] = a [n - 1][i] = a [n - 2][i + 1] = a [n - 1][i + 1] = idx ++;
        }
    }
    else{
        auto a1 = solve (n - 2, m - 2, k - 1);
        for (int i = 1; i < n - 1; i ++){
            for (int j = 1; j < m - 1; j ++){
                a [i][j] = a1 [i - 1][j - 1];
            }
        }
        for (int i = 0; i < m; i ++) a [0][i] = a [n - 1][i] = k;
        for (int i = 0; i < n; i ++) a [i][0] = a [i][m - 1] = k;
    }
    return a;

}

int main (){

    ios::sync_with_stdio (false);
    cin.tie (0);

    int t;
    cin >> t;
    while (t --){
        int n, m, k;
        cin >> n >> m >> k;
        if (n % 2 == 1 || m % 2 == 1){
            cout << "NO\n";
            continue;
        }
        bool flag = 0;
        if (n > m){
            swap (n, m);
            flag = 1;
        }
        vector <vector <int> > a;
        if (n == 2){
            if (k != m / 2){
                cout << "NO\n";
                continue;
            }
            a = solve2 (m, k);
            if (flag){
                for (int i = 0; i < m; i ++){
                    for (int j = 0; j < 2; j ++){
                        cout << a [j][i] << ' ';
                    }
                    cout << '\n';
                }
            }
            else{
                for (int i = 0; i < 2; i ++){
                    for (int j = 0; j < m; j ++){
                        cout << a [i][j] << ' ';
                    }
                    cout << '\n';
                }
            }
            continue;
        }
        else if (n == 4){
            if (k < m / 2 || k > m || k == m - 1){
                cout << "NO\n";
                continue;
            }
            cout << "YES\n";
            a = solve4 (m, k);
            if (flag){
                for (int i = 0; i < m; i ++){
                    for (int j = 0; j < 4; j ++){
                        cout << a [j][i] << ' ';
                    }
                    cout << '\n';
                }
            }
            else{
                for (int i = 0; i < 4; i ++){
                    for (int j = 0; j < m; j ++){
                        cout << a [i][j] << ' ';
                    }
                    cout << '\n';
                }
            }
            continue;
        }
        else if (n == 6){
            if (k > 3 * m / 2 || k < m / 2 || k == 3 * m / 2 - 1 || k == m - 2 && m < 8){
                cout << "NO\n";
                continue;
            }
            cout << "YES\n";
            a = solve6 (m, k);
            if (flag){
                for (int i = 0; i < m; i ++){
                    for (int j = 0; j < 6; j ++){
                        cout << a [j][i] << ' ';
                    }
                    cout << '\n';
                }
            }
            else{
                for (int i = 0; i < 6; i ++){
                    for (int j = 0; j < m; j ++){
                        cout << a [i][j] << ' ';
                    }
                    cout << '\n';
                }
            }
            continue;
        }
        else{
            if (k < m / 2 || k > n / 2 * m / 2 || k == n / 2 * m / 2 - 1){
                cout << "NO\n";
                continue;
            }
            a = solve (n, m, k);
            if (flag){
                for (int i = 0; i < m; i ++){
                    for (int j = 0; j < n; j ++){
                        cout << a [j][i] << ' ';
                    }
                    cout << '\n';
                }
            }
            else{
                for (int i = 0; i < n; i ++){
                    for (int j = 0; j < m; j ++){
                        cout << a [i][j] << ' ';
                    }
                    cout << '\n';
                }
            }
        }
    }

}
