/**
* user:  suleymanov-b26
* fname: Karam
* lname: Suleymanov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:23:37.375518
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

vector<vector<ll>> ans;

bool solve2(int n, ll k, int x, int y, ll col) {
    ll cnt = -1, g = n / 2, c = 0;
    for (; g >= 1; g--, c++) {
        if (g * g + c == k) {
            cnt = g * g + c;
            break;
        }
    }
    if (cnt == -1) {
        return false;
    }
    while (c--) {
        for (int j = y; j < n + y; j++) {
            ans[x][j] = col, ans[n + x - 1][j] = col;
        }
        for (int i = x + 1; i < n + x - 1; i++) {
            ans[i][y] = col, ans[i][n + y - 1] = col;
        }
        col++, x++, y++, n -= 2;
    }
    for (int i = x; i < n + x; i += 2) {
        for (int j = y; j < n + y; j += 2) {
            ans[i][j] = col, ans[i][j + 1] = col, ans[i + 1][j] = col, ans[i + 1][j + 1] = col;
            col++;
        }
    }
    return true;
}

void solve1() {
    int n, m;
    ll k;
    cin >> n >> m >> k;
    if (n == 4 && m == 6 && k == 3) {
        cout << "YES\n";
        cout << "1 1 1 1 1 1\n1 2 2 3 3 1\n1 2 2 3 3 1\n1 1 1 1 1 1\n";
        return;
    }
    if (n % 2 != 0 || m % 2 != 0 || abs(n - m) % 2 != 0) {
        cout << "NO\n";
        return;
    }
    ans.resize(n);
    ans.assign(n, vector<ll>(m));
    bool flag = false;
    if (n < m) {
        flag = true, swap(n, m);
    }
    if (!solve2(n, k, 0, 0, 1)) {
        cout << "NO\n";
        return;
    }
    cout << "YES\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) cout << ans[i][j] << ' ';
        cout << '\n';
    }
}

signed main() {
//    ios::sync_with_stdio(false);
//    cin.tie(nullptr), cout.tie(nullptr);

    int t = 1;
    cin >> t;
    while (t--) {
        solve1();
        ans.clear();
    }

    return 0;
}