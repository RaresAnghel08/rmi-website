/**
* user:  apostol-64a
* fname: Ilie-Daniel
* lname: Apostol
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:42:41.181114
*/
#include <bits/stdc++.h>

using namespace std;

using ll = long long;
#define dbg(x) cerr << #x << " " << x << "\n"
vector <vector <int>> sol;
int tag;


void full_rect(int x1, int y1, int x2, int y2) {
    for (int x = x1; x <= x2; x += 2)
        for (int y = y1; y <= y2; y += 2) {
            ++tag;
            sol[x][y] = sol[x][y + 1] = sol[x + 1][y] = sol[x + 1][y + 1] = tag;
        }
}
bool ok;
void solve(int x1, int y1, int x2, int y2, int K) {
  //  cout << x1 << " " << y1 << " " << x2 << " " << y2 << " " << K << "\n";
    /// we first want to make a frame that starts from (x1, y1) and ends in a cell (x2, y),
    /// we want to find a good y
    int L = (x2 - x1 + 1);
    int C = (y2 - y1 + 1);
    int left_cells = L * C;
    int needed = K * 4;
    int rest = left_cells - needed;
    /// rest > (L - 2) * 2 + y * 2
    if (rest == 0) {
        full_rect(x1, y1, x2, y2);
        return;
    }
    if (L == 2) {
        ok = false;
        return;
    }
    if (C == 2) {
        ok = false;
        return;
    }
    /// try from row
    if ((rest - (L - 2) * 2) < 4) {
        /// we make the first row with and solve(x1 + 2, y1, x2, y2)
        /// x x y y z z
        /// x x y y z z
        full_rect(x1, y1, x1 + 1, y2);
        solve(x1 + 2, y1, x2, y2, K - C / 2);
        return;
    }
    int best_y = min (y2, y1 + min((rest - (L - 2) * 2) / 2 + 1, L * 2 - 1));
    /// make the frame (x1, y1, x2, best_y)
    ++tag;
    for (int y = y1; y <= best_y; y++)
        sol[x1][y] = sol[x2][y] = tag;
    for (int x = x1; x <= x2; x++)
        sol[x][y1] = sol[x][best_y] = tag;
    if (best_y == y2) {
        solve(x1 + 1, y1 + 1, x2 - 1, y2 - 1, K - 1);
    }
    else {
        /// we solve everything now
        full_rect(x1 + 1, y1 + 1, x2 - 1, best_y - 1);
        full_rect(x1, best_y + 1, x2, y2);
    }
}
void solve_test(int N, int M, int K) {
  //  dbg(N);  dbg(M); dbg(K);
    if (N % 2 != 0 || M % 2 != 0)  {
        cout << "NO\n";
        return;
    }
    if (N * M / 4 < K) {
        cout << "NO\n";
        return;
    }
    sol.resize(1 + N);
    for (int i = 0; i <= N; i++)
        sol[i].resize(1 + M);
    tag = 0;
    ok = true;
    solve(1, 1, N, M, K);
   // assert(min(N, M) / 2 <= K);
    if (ok) {
       // if (K != tag) {
         //   dbg(N); dbg(M); dbg(K);
       // }
    //    assert(K == tag);
        cout << "YES\n";
        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= M; j++) {
                cout << sol[i][j] << " ";
            }
            cout << "\n";
        }
    }
    else {
        cout << "NO\n";
    }
    sol.clear();
}

int main() {
    int Q;
   /* freopen("output", "w", stdout);
    for (int N = 1; N <= 6; N++)
        for (int M = 1; M <= 100; M++)
            for (int K = 1; K <= 100; K++) {
                cout << "N : " << N << "M : " << M << "K : "<<  K << "\n";
                solve_test(N, M, K);
            }
    */
    cin >> Q;
    while (Q--) {
        int N, M, K;
        cin >> N >> M >> K;
        solve_test(N, M, K);
    }
    return 0;
}
/**
1
4 6 4
**/
