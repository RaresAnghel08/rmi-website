/**
* user:  linhart-f5e
* fname: Yoav
* lname: Linhart
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 08:58:55.466320
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <queue>
#include "speedrun.h"

#define upmin(a, b) if(a > b) a = b
#define upmax(a, b) if(a < b) a = b
#define pr(x) cout << x << endl
#define spr(x) cout << x << " "
#define wpr(x) cout << #x << ": " << x << endl
#define wprv(x) cout << #x << ": " << endl; for(auto it : x) cout << it << " "; cout << endl;
#define wprvv(x) cout << #x << ": " << endl; for(auto it : x) { for(auto it2 : it) cout << it2 << " "; cout << endl;}
#define rep(i, s, e) for(ll i = s; i < e; i++)
#define repr(i, s, e) for(ll i = e - (ll)1; i >= s; i--)


using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vvvll = vector<vvll>;
using pll = pair<ll, ll>;
using vpll = vector<pll>;
using vvpll = vector<vpll>;
using vb = vector<bool>;
using vi = vector<int>;

const ll sz = 20;

/*

subtask 2:
enconde the middle 

*/

void assignHints(int subtask, int n, int A[], int B[])
{
	vvll tree(n+1);
	rep(i, 1, n+1) {
		ll xt = A[i], yt = B[i];
		tree[xt].push_back(yt); tree[yt].push_back(xt);
	}
	ll center = -1;
	rep(i, 1, n + 1) {
		if (tree[i].size() == n - (ll)1) center = i;
	}
	//wpr(center);
	setHintLen(sz);
	
	rep(i, 1, n + 1) {
		if (i == center) continue;
		//wpr(i);
		rep(j, 1, sz+1) {
			if ((center >> (j-(ll)1)) & (ll)1) {
				setHint(i, j, true);
				//wpr(j);
			}
		}
	}

	
}



void speedrun(int subtask, int n, int start)
{

	ll l = getLength();
	ll num = 0;
	rep(j, 1, l+1) {
		bool c = getHint(j);
		//wpr(c);
		if (c) num += (ll)1 << (j-(ll)1);
	}
	//wpr(num);
	if (num == 0) // we are in the center:
	{
		rep(i, 1, n + 1) {
			if (i == start) continue;
			goTo(i);
			goTo(start);
		}
		return;
	}
	goTo(num); // to center:
	rep(i, 1, n + 1) {
		if (i == start) continue;
		if (i == num) continue;
		goTo(i);
		goTo(num);
	}

}

/*




*/