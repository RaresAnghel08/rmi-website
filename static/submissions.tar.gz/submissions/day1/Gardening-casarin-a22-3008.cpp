/**
* user:  casarin-a22
* fname: Filippo
* lname: Casarin
* task:  Gardening
* score: 5.0
* date:  2021-12-16 10:28:04.239165
*/
#include <iostream>
#include <vector>

bool solve(size_t N, size_t M, size_t K, uint32_t A[], size_t x, size_t y) {
	if (N * M == 0) return K == 0;
	if (N * M > 4 * K * K) return false;
	if (N * M < 4 * K) return false;

	if (true || N == M) {
		if (4 * K == N * M) {
			for (size_t i{}; i < N; ++i)
				for (size_t j{}; j < M; ++j)
					A[i * x + j * y] = (i / 2) + (N / 2) * (j / 2);
			return true;
		}

		for (size_t i{}; i < N; ++i) A[i * x] = K - 1;
		for (size_t i{}; i < N; ++i) A[i * x + (M-1) * y] = K - 1;
		for (size_t j{}; j < M; ++j) A[j * y] = K - 1;
		for (size_t j{}; j < M; ++j) A[(N-1) * x + j * y] = K - 1;
		return solve(N - 2, M - 2, K - 1, A + x + y, x, y);
	}


	return false;
}

int main() {
	size_t T;
	std::cin >> T;

	std::vector<uint32_t> A;
	while (T--) {
		size_t N, M, K;
		std::cin >> N >> M >> K;
		A.resize(N * M);
		if (solve(N, M, K, &A[0], M, 1)) {
			std::cout << "YES\n";
			for (size_t i{}; i < N; ++i) {
				for (size_t j{}; j < M; ++j)
					std::cout << A[i * M + j] + 1 << ' ';
				std::cout << '\n';
			}
		} else {
			std::cout << "NO\n";
		}
	}
}
