/**
* user:  budnikov-2df
* fname: Mikhail
* lname: Budnikov
* task:  devil
* score: 14.0
* date:  2019-10-10 06:15:33.812866
*/
#include <bits/stdc++.h>
#define all(x) begin(x), end(x)
typedef long long ll;
typedef long double ld;
using namespace std;

void solve() {
	int k;
	cin >> k;
	ll pw = 1;
	for (int i = 0; i < k; ++i) {
		pw *= 10;
	}
	auto test = [&](vector<int> a) {
		ll max_sub = 0, sub = 0;
		for (int i = 0; i < k; ++i) {
			sub = 10 * sub + a[i];
		}
		max_sub = sub;
		for (int i = k; i < (int)a.size(); ++i) {
			sub = 10 * sub + a[i];
			sub -= pw * a[i - k];
			max_sub = max(max_sub, sub);
		}
		return max_sub;
	};
	vector<int> a;
	for (int i = 1; i < 10; ++i) {
		int c;
		cin >> c;
		while (c--) {
			a.push_back(i);
		}
	}
	
	deque<int> d(all(a));
	sort(all(d));
	reverse(all(d));
	a.clear();
	while (d.size()) {
		a.push_back(d.front());
		d.pop_front();
		if (d.size()) {
			a.push_back(d.back());
			d.pop_back();
		}
	}
	reverse(all(a));
	
#ifdef LC
	cout << test(a) << endl;
	for (int e : a) {
		cerr << e;
	}
	cerr << "\n";
#else
	for (int e : a) {
		cout << e;
	}
	cout << "\n";
#endif
}

int main() {
#ifdef LC
	assert(freopen("input.txt", "r", stdin));
#endif
	ios::sync_with_stdio(0);
	cin.tie(0);
	
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
	
	return 0;
}

