/**
* user:  tatarinova-7c8
* fname: Yuliia
* lname: Tatarinova
* task:  Gardening
* score: 23.0
* date:  2021-12-16 11:45:44.338238
*/
#include <bits/stdc++.h>

using namespace std;

pair<bool, vector<vector<int>>> d(int n, int m, int k)
{
       vector<vector<int>> v;

    if((m==0 || n==0) && k==0)
    {
        return {1, v};
    }
    if((m==0 || n==0) && k!=0)
    {

        return {0, v};
    }

      if(k<m/2 || m%2==1 ||n%2==1|| k == m/2+1 || k>m*n/4 || k == m*n/4-1 ) return {0, v};


    pair<bool, vector<vector<int>>> y = d(n-2,m-2,k-1);
    vector<vector<int>> r=y.second;
    if(y.first==1)
    {
        v.resize(n);
        for(int i=0; i<n; i++)
            v[i].resize(m);

        for(int i=0; i<m; i++)
        {
        v[0][i]=k;
            v[n-1][i]=k;
        }
         for(int i=0; i<n; i++)
        {
            v[i][0]=k;
            v[i][m-1]=k;
        }
        for(int i=1; i<n-1; i++)
            for(int j=1; j<m-1; j++)
            v[i][j]=r[i-1][j-1];

        return {1, v};
    }

     y = d(n-2, m,k-m/2);
    r=y.second;
    if(y.first==1)
    {
        v.resize(n);
        for(int i=0; i<n; i++)
            v[i].resize(m);
       long long p=k;
        for(int i=0; i<m; i+=2)
        {
            v[n-1][i]=p;
            v[n-1][i+1]=p;
             v[n-2][i]=p;
            v[n-2][i+1]=p;
            p--;
        }

        for(int i=0; i<n-2; i++)
            for(int j=0; j<m; j++)
            v[i][j]=r[i][j];

        return {1, v};
    }

    y = d(n, m-2,k-n/2);
      r=y.second;
    if(y.first==1)
    {
        v.resize(n);
        for(int i=0; i<n; i++)
            v[i].resize(m);
       long long p=k;
        for(int i=0; i<n; i+=2)
        {
            v[i][m-1]=p;
            v[i+1][m-1]=p;
            v[i][m-2]=p;
            v[i+1][m-2]=p;
            p--;
        }

        for(int i=0; i<n; i++)
            for(int j=0; j<m-2; j++)
            v[i][j]=r[i][j];

        return {1, v};
    }

     return {0, v};
}

int main()
{
    long long t,n,m,k;
    cin>>t;
    for(int step=0; step<t; step++)
    {
        cin>>n>>m>>k;
        long long n1=n, m1=m;
        if(n1>m1) swap(n1,m1);
        pair<bool, vector<vector<int>>> y = d(n1,m1,k);
        if(y.first==0) cout<<"NO\n";
        else
        {
            vector<vector<int>> r = y.second;
            cout<<"YES\n";
            if(n<m)
            for(int i=0; i<n; i++)
            {
                for(int j=0; j<m; j++)
                    cout<<r[i][j]<<' ';
                cout<<'\n';
            } else
            {
                 for(int i=0; i<n; i++)
            {
                for(int j=0; j<m; j++)
                    cout<<r[j][i]<<' ';
                cout<<'\n';
            }
            }
        }
    }
    return 0;
}
