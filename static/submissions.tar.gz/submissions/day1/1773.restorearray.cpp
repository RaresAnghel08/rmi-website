/**
* user:  pavic-9e7
* fname: Patrick
* lname: Pavić
* task:  restore
* score: 0.0
* date:  2019-10-10 07:44:35.806772
*/
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstring>

#define X first
#define Y second
#define PB push_back

using namespace std;

typedef pair < int, int > pii;

const int INF = 0x3f3f3f3f;
const int N = 5005;

int n, m;

int p[N];
vector < pair < pii, int > > v;

void bellman(){
	//printf("%d\n", v.size());
	for(int i = 0;i < n + 10;i++){
		for(pair < pii, int > edg : v)
			p[edg.X.Y] = min(p[edg.X.Y], p[edg.X.X] + edg.Y);
	}
}

int main(){
	memset(p, INF, sizeof(p));
	p[0] = 0;
	scanf("%d%d", &n, &m);
	for(int i = 0;i < n;i++){
		v.PB({{i, i + 1}, 1});
		v.PB({{i + 1, i}, 0});
	}
	for(int i = 0;i < m;i++){
		int l, r, val, k;
		scanf("%d%d%d%d", &l, &r, &k, &val); l++, r++;
		k = (r - l + 1) - k;
		if(val == 0)
			v.PB({{l - 1, r}, k});
		else
			v.PB({{r, l - 1}, -k});
	}
	bellman();
	if(p[0] != 0){
		printf("-1\n");
	}
	for(int i = 0;i < n;i++)
		printf("%d ", p[i + 1] - p[i]);
	printf("\n");
}
