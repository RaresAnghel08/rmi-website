/**
* user:  lupov-261
* fname: Ivan Stiliyanov
* lname: Lupov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:23:25.617756
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>

#define de(x) cout << #x << " = " << x << endl;
#define pb push_back
#define fr first
#define sc second
#define bit(x) x&(-x)
#define ll long long
#define ld long double

using namespace __gnu_pbds;
using namespace std;

template<class T> using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<class T> using matrix = vector<vector<T>>;

void s(){
	int n, m, k; cin >> n >> m >> k;
	if(n % 2 == 1 || m % 2 == 1){ cout << "NO\n"; return; }
	if(n == 2){
		if(m / 2 == k){
			cout << "YES\n";
			for(int i = 0, T = 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			return;
		}
	}
	if(n == 4){
		if(m == 2 && k == 2){
			cout << "YES\n";
			cout << "1 1\n";
			cout << "1 1\n";
			cout << "2 2\n";
			cout << "2 2\n";
			return;
		}
		if(m == k){
			cout << "YES\n";
			for(int i = 0, T = 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = m / 2 + 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = m / 2 + 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			return;
		}
		if((m - 2) / 2 == k - 1 && k > 1){
			cout << "YES\n";
			for(int i = 0; i < m; i ++) cout << "1 "; cout << endl;
			cout << "1 "; for(int i = 0, T = 2; i < m - 2; i += 2, ++ T) cout << T << " " << T << " "; cout << "1\n";
			cout << "1 "; for(int i = 0, T = 2; i < m - 2; i += 2, ++ T) cout << T << " " << T << " "; cout << "1\n";
			for(int i = 0; i < m; i ++) cout << "1 "; cout << endl;
			return;
		}
	}
	if(n == 6){
		if(m == 2 && k == 3){
			cout << "YES\n";
			cout << "1 1\n";
			cout << "1 1\n";
			cout << "2 2\n";
			cout << "2 2\n";
			cout << "3 3\n";
			cout << "3 3\n";
			return;
		}
		if(m == 4){
			if(k == 6){
				cout << "YES\n";
				cout << "1 1 4 4\n";
				cout << "1 1 4 4\n";
				cout << "2 2 5 5\n";
				cout << "2 2 5 5\n";
				cout << "3 3 6 6\n";
				cout << "3 3 6 6\n";
				return;
			}
			if(k == 3){
				cout << "YES\n";
				cout << "1 1 1 1\n";
				cout << "1 2 2 1\n";
				cout << "1 2 2 1\n";
				cout << "1 3 3 1\n";
				cout << "1 3 3 1\n";
				cout << "1 1 1 1\n";
			}
		}
		if(3 * m / 2 == k){
			cout << "YES\n";
			for(int i = 0, T = 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = m / 2 + 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = m / 2 + 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = m     + 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			for(int i = 0, T = m     + 1; i < m; i += 2, T ++) cout << T << " " << T << " "; cout << endl;
			return;
		}
		if(m - 2 == k - 1 && k > 1){
			cout << "YES\n";
			for(int i = 0; i < m; i ++) cout << "1 "; cout << endl;
			cout << "1 "; for(int i = 0, T = 2; i < m - 2; i += 2, ++ T) cout << T << " " << T << " "; cout << "1\n";
			cout << "1 "; for(int i = 0, T = 2; i < m - 2; i += 2, ++ T) cout << T << " " << T << " "; cout << "1\n";
			cout << "1 "; for(int i = 0, T = m / 2 + 1; i < m - 2; i += 2, ++ T) cout << T << " " << T << " "; cout << "1\n";
			cout << "1 "; for(int i = 0, T = m / 2 + 1; i < m - 2; i += 2, ++ T) cout << T << " " << T << " "; cout << "1\n";
			for(int i = 0; i < m; i ++) cout << "1 "; cout << endl;
			return;
		}
		if((m - 4) / 2 == k - 2 && k > 2){
			cout << "YES\n";
			for(int i = 0; i < m; i ++) cout << "1 "; cout << endl;
			cout << "1 "; for(int i = 0; i < m - 2; i ++) cout << "2 "; cout << "1\n";
			cout << "1 2 "; for(int i = 0, T = 3; i < m - 4; i += 2, ++ T) cout << T << " " << T << " "; cout << "2 1\n";
			cout << "1 2 "; for(int i = 0, T = 3; i < m - 4; i += 2, ++ T) cout << T << " " << T << " "; cout << "2 1\n";
			cout << "1 "; for(int i = 0; i < m - 2; i ++) cout << "2 "; cout << "1\n";
			for(int i = 0; i < m; i ++) cout << "1 "; cout << endl;
			return;
		}
	}
	cout << "NO\n";
}

void s1(int n, int m, int k){
	if(n == 2 && m == 2){
		if(k == 1){
			cout << "YES\n1 1\n1 1\n";
			return;
		}
	}
	if(n == 2 && m == 4){
		if(k == 2){
			cout << "YES\n";
			cout << "1 1 2 2\n";
			cout << "1 1 2 2\n";
			return;
		}
	}
	if(n == 4 && m == 2){
		if(k == 2){
			cout << "YES\n";
			cout << "1 1\n";
			cout << "1 1\n";
			cout << "2 2\n";
			cout << "2 2\n";
			return;
		}
	}
	if(n == 4 && m == 4){
		if(k == 2){
			cout << "YES\n";
			cout << "1 1 1 1\n";
			cout << "1 2 2 1\n";
			cout << "1 2 2 1\n";
			cout << "1 1 1 1\n";
			return;
		}
		if(k == 4){
			cout << "YES\n";
			cout << "1 1 2 2\n";
			cout << "1 1 2 2\n";
			cout << "3 3 4 4\n";
			cout << "3 3 4 4\n";
			return;
		}
	}
	cout << "NO\n";
}

int main(){
	int t; cin >> t; while(t --) s();
}
/*
5
2 2 2
2 2 1
4 4 4
4 4 2
4 6 3
6 8 4

((n - 2x) / 2) * ((m - 2x) / 2) = k - x
(n - 2x) * (m - 2x) = 4k - 4x
n * m - 2xn - 2xm + 4x^2 = 4k - 4x
n * m - 2xn - 2xm + 4x + 4x^2 = 4k
nm - 2x(n + m - 2) + 4x^2 = 4k
4x^2 - 2x(n + m - 2) + nm - 4k


4*4 + 
4x^2 + x * 2(2 - n - m) + (nm - 4k) = 0
*/
