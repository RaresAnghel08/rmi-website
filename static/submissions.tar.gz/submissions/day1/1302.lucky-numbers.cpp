/**
* user:  kopchev-ba2
* fname: Martin
* lname: Kopchev
* task:  lucky
* score: 0.0
* date:  2019-10-10 06:12:26.370657
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=1e5+42,mod=1e9+7;
int n,q;
int inp[nmax];

int any[nmax],start_3[nmax];

int query(int x,int y)
{
            int ret=0;

            bool one=0;

            for(int j=x;j<=y;j++)
            {
                if(j-1>=x&&inp[j-1]==1)one=1;

                if(one==0)
                {
                    int stop=inp[j]-1;
                    if(j==y)stop=inp[j];

                    for(int k=0;k<=stop;k++)
                        ret=(ret+(k==1?any[y-j]-start_3[y-j]+mod:any[y-j])%mod)%mod;
                }
                else//one=1
                {
                    int stop=inp[j]-1;
                    if(j==y)stop=inp[j];

                    for(int k=0;k<=stop;k++)
                        ret=(ret+(k==3?0:(any[y-j]-start_3[y-j]+mod))%mod)%mod;
                }
                //cout<<"j= "<<j<<" ret= "<<ret<<endl;
            }

            //cout<<ret<<endl;
    return ret;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie();
    cout.tie();

    cin>>n>>q;

    char c;

    for(int i=1;i<=n;i++)
    {
        cin>>c;
        inp[i]=c-'0';
    }

    any[0]=1;
    start_3[0]=0;

    for(int i=1;i<=n;i++)
    {
        any[i]=((1LL*10*any[i-1]-start_3[i-1])%mod+mod)%mod;
        start_3[i]=any[i-1]%mod;

        cout<<i<<" -> "<<any[i]<<" "<<start_3[i]<<endl;
    }

    cout<<query(1,n)<<endl;

    int t,x,y;

    for(int i=1;i<=q;i++)
    {
        cin>>t>>x>>y;
        if(t==2)
        {
            inp[x]=y;
        }
        else
        {
            cout<<query(x,y)<<endl;
        }
    }
    return 0;
}
