/**
* user:  ghiberdic-f48
* fname: David
* lname: Ghiberdic
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 10:53:50.012420
*/
#include <iostream>
#include <vector>
#include "speedrun.h"

int const nmax = 1000;
int degree[nmax + 5];
std::vector <int> adj[nmax + 5];

void dfsS3 (int nod, int p) {
    int size = adj[nod].size();
    for (int bit = 0; bit < 10; bit++)
        if ((p & (1 << bit)) != 0)
            setHint(nod, bit + 1, true);
    for (int i = 0; i < 2; i++)
        if (p != adj[nod][i]) {
            for (int bit = 0; bit < 10; bit++)
                setHint(nod, 10 + bit + 1, true);
            dfsS3 (adj[nod][i], nod);
        }
}

void assignHints(int subtask, int N, int A[], int B[]) {
    if (subtask == 1) {
        setHintLen(N);
        for (int i = 1; i < N; i++) {
            setHint(A[i], B[i], true);
            setHint(B[i], A[i], true);
        }
    }
    if (subtask == 2) {
        setHintLen(10);
        for (int i = 1; i < N; i++) {
            degree[A[i]]++;
            degree[B[i]]++;
        }
        int nod = -1;
        for (int i = 1; i < N; i++) {
            if (degree[A[i]] > 1) {
                nod = A[i];
                break;
            }
            if (degree[B[i]] > 1) {
                nod = B[i];
                break;
            }
        }
        for (int i = 1; i <= N; i++)
            for (int bit = 0; bit < 10; bit++)
                if ((nod & (1 << bit)) != 0)
                    setHint(i, bit + 1, 1);
    }
    if (subtask == 3) {
        setHintLen(20);
        for (int i = 1; i < N; i++) {
            degree[A[i]]++;
            degree[B[i]]++;
            adj[A[i]].push_back(B[i]);
            adj[B[i]].push_back(A[i]);
        }
        for (int i = 1; i < N; i++) {
            if (degree[A[i]] == 1)
                dfsS3(A[i], 0);
            if (degree[B[i]] == 1)
                dfsS3(B[i], 0);
        }
    }
}

bool seen[nmax];
int n;

void dfsS1 (int nod) {
    seen[nod] = true;
    for (int i = 1; i <= n; i++) {
        if (getHint(i) && !seen[i]) {
            goTo(i);
            dfsS1(i);
            goTo(nod);
        }
    }
}

void dfsS3solve (int nod, int p) {
    int first = 0;
    for (int bit = 0; bit < 10; bit++)
        if (getHint(bit + 1))
            first |= (1 << bit);
    int second = 0;
    for (int bit = 0; bit < 10; bit++)
        if (getHint(10 + bit + 1))
            first |= (1 << bit);
    if (first != p) {
        goTo(first);
        dfsS3solve(first, nod);
        goTo(nod);
    }
    if (second != p) {
        goTo(second);
        dfsS3solve(second, nod);
        goTo(nod);
    }
}

void speedrun(int subtask, int N, int start) {
    if (subtask == 1) {
        n = N;
        dfsS1 (start);
    }
    if (subtask == 2) {
        int nod = 0;
        for (int bit = 0; bit < 10; bit++)
            if (getHint(bit + 1))
                nod |= (1 << bit);
        goTo(nod);
        for (int i = 1; i <= N; i++) {
            if (i != nod) {
                goTo(i);
                goTo(nod);
            }
        }
    }
    if (subtask == 3) {
        dfsS3solve(start, 0);
    }
}