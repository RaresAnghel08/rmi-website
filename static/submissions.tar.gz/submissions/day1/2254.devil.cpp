/**
* user:  sanzani-a32
* fname: Filippo
* lname: Sanzani
* task:  devil
* score: 13.0
* date:  2019-10-10 08:50:03.811974
*/
#include <bits/stdc++.h>

using namespace std;

#define int long long

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;

int K, N;
int MOD = 1;

vector<int> best;
int mini = 4e18;

void test(vector<int>& v){
	int m = -1;
	int val = 0;
	for(int i=0; i<K; i++)
		val = 10*val + v[i];

	m = max(m, val);
	for(int i=K; i<v.size(); i++){
		val = (val%MOD) * 10 + v[i];
		m = max(val, m);
	}

	if(m < mini){
		mini =  m;
		best = v;
	}
}

void solve(){
 	cin >> K;

 	vector<int> v;
 	best.clear();
 	MOD = 1;
 	mini = 4e18;

 	for(int i=1; i<K; i++) MOD*=10;

 	vector<int> cont(11, 0);
 	for(int i=1; i<10; i++){
 		cin >> cont[i];
 		N += cont[i];
 	}

 	for(int i=1; i<=4; i++){
 		for(int x=0; x<cont[i]; x++) v.push_back(i);
 	}

 	do{
 		test(v);
 	}while(next_permutation(v.begin(), v.end()));

 	for(auto i : best) cout << i;
}

signed main(){
    cin.tie(0); cin.sync_with_stdio(0);
    int T;
    cin >> T;
    while(T--){
    	solve();
    	cout << "\n";
    }
}
