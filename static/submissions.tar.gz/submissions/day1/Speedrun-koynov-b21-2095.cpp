/**
* user:  koynov-b21
* fname: Daniel Iliev
* lname: Koynov
* task:  Speedrun
* score: 63.0
* date:  2021-12-16 08:59:33.062691
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;


const int maxn = 1010;
vector < int > g[maxn], ch[maxn];
int deg[maxn], par[maxn];

void assignDfs(int v, int p)
{
    for (int i = 0; i < g[v].size(); i ++)
    {
        int u = g[v][i];
        if (u == p)
            continue;
        par[u] = v;
        ch[v].push_back(u);
        assignDfs(u, v);
    }
}
void assignHints(int subtask, int N, int A[], int B[])
{
    setHintLen(30);
    for (int i = 1; i < N; i ++)
    {
        g[A[i]].push_back(B[i]);
        g[B[i]].push_back(A[i]);
        deg[A[i]] ++;
        deg[B[i]] ++;
    }

    assignDfs(1, -1);

    for (int i = 1; i <= N; i ++)
    {

        for (int j = 0; j < 10; j ++)
        {
            if ((par[i] & (1 << j)) > 0)
                setHint(i, j + 1, true);
        }


        if (ch[i].size() > 0)
        {
            int u = ch[i][0];
            for (int j = 0; j < 10; j ++)
            {
                if ((u & (1 << j)) > 0)
                    setHint(i, j + 11, true);
            }
        }
        for (int p = 0; p < (int)(ch[i].size()) - 1; p ++)
        {
            int v1 = ch[i][p], v2 = ch[i][p + 1];

            for (int j = 0; j < 10; j ++)
            {
                if ((v2 & (1 << j)) > 0)
                    setHint(v1, j + 21, true);
            }
        }
    }
}

void getParent(int ver)
{
    for (int bit = 0; bit < 10; bit ++)
        if (getHint(bit + 1))
            par[ver] += (1 << bit);

    if (par[ver] != 0)
        g[ver].push_back(par[ver]);
}

void getChildren(int ver)
{
    int child = 0;
    for (int bit = 0; bit < 10; bit ++)
        if (getHint(bit + 11))
            child += (1 << bit);
    if (child != 0)
    {
        g[ver].push_back(child);

        while(child != 0)
        {

            int nextChild = 0;
            goTo(child);

            for (int bit = 0; bit < 10; bit ++)
                if (getHint(bit + 21))
                    nextChild += (1 << bit);

            if (nextChild != 0)
            {
                g[ver].push_back(nextChild);
            }
            goTo(ver);
            child = nextChild;
        }
    }
}
int used[maxn];
void dfs(int ver, int p, int N)
{
    getParent(ver);
    getChildren(ver);
    used[ver] = 1;
    for (int i = 0; i < g[ver].size(); i ++)
    {
        int u = g[ver][i];
        if (used[u])
            continue;
        if (goTo(u))
        dfs(u, ver, N);
    }
    if (p != -1)
        goTo(p);
}
void speedrun(int subtask, int N, int start)
{
    int l = getLength();
    for (int i = 1; i <= N; i ++)
        par[i] = 0, g[i].clear(), ch[i].clear();
    dfs(start, -1, N);

}
