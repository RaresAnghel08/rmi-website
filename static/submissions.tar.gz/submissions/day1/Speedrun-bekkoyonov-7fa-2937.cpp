/**
* user:  bekkoyonov-7fa
* fname: Tengiz
* lname: Bekkoyonov
* task:  Speedrun
* score: 90.0
* date:  2021-12-16 10:20:41.635847
*/
#include "speedrun.h"
#ifndef EVAL
#include "grader.cpp"
#endif
#include <bits/stdc++.h>
using namespace std;
const int n = 1005;
vector<int> e[n];
int par[n], nxt[n], child[n];

void dfs(int u, int p) {
    par[u] = p;
    int lst = -1;
    for (int v : e[u]) {
        if (v != p) {
            if (lst == -1) {
                child[u] = v;
                lst = v;
            } else {
                nxt[lst] = v;
                lst = v;
            }
            dfs(v, u);
        }
    }
}
void assignHints(int subtask, int N, int A[], int B[]) {
    if (N == 1) {
        setHintLen(20);
        return;
    }
    for (int i = 1; i < N; i++) {
        e[A[i]].push_back(B[i]);
        e[B[i]].push_back(A[i]);
    }
    if (subtask == 2) {
        int x = 1;
        for (int i = 1; i <= N; i++) {
            if (e[i].size() > 1) {
                x = i;
            }
        }
        setHintLen(20);
        for (int j = 0; j < 10; j++) {
            setHint(x, j + 1, x >> j & 1);
            if (N == 1) {
                setHint(x, j + 10 + 1, x >> j & 1);
            } else {
                setHint(x, j + 10 + 1, e[x].back() >> j & 1);
            }
        }
        int lst = x;
        for (int i : e[x]) {
            for (int j = 0; j < 10; j++) {
                setHint(i, j + 1, x >> j & 1);
                setHint(i, j + 10 + 1, lst >> j & 1);
            }
            lst = i;
        }
        return ;
    } else if (subtask == 3) {
        memset(par, -1, sizeof par);
        memset(nxt, -1, sizeof nxt);
        fill(child, child + n, -1);
        dfs(1, -1);
        int x = 1;
        for (int i = 1; i <= N; i++) {
            if (child[i] == -1) {
                x = i;
            }
        }
        int l[N + 1] {}, r[N + 1] {};
        r[x] = e[x][0];
        l[r[x]] = x;
        int lst = x;
        x = r[x];
        for (int i = 1; i <= N; i++) {
            if (e[x].size() == 1) break;
            int to = e[x][0] ^ e[x][1] ^ lst;
            r[x] = to;
            l[to] = x;
            lst = x;
            x = to;
        }
        setHintLen(20);
        for (int i = 1; i <= N; i++) {
            for (int j = 0; j < 10; j++) {
                setHint(i, j + 1, l[i] >> j & 1);
                setHint(i, j + 10 + 1, r[i] >> j & 1);
            }
        }
        return;
    }
    memset(par, -1, sizeof par);
    memset(nxt, -1, sizeof nxt);
    fill(child, child + n, 1);
    dfs(1, -1);
    setHintLen(30);
    for (int i = 1; i <= N; i++) {
        for (int j = 0; j < 10; j++) {
            setHint(i, j + 1, nxt[i] >> j & 1);
            setHint(i, j + 10 + 1, child[i] >> j & 1);
            setHint(i, j + 20 + 1, par[i] >> j & 1);
        }
    }
    // for (int i = 1; i <= N; i++) {
        // cout << child[i] << " " << nxt[i] << "\n";
    // }
}

int find(int u, int p) {
    // cout << u << " " << p << "\n";
    int v = 0, nxt = 0;
    for (int j = 0; j < 10; j++) {
        v |= getHint(j + 10 + 1) << j;
        nxt |= getHint(j + 1) << j;
    }
    // cout << v << " " << nxt << "\n";
    if (v == 1) {
        goTo(p);
        return nxt;
    }
    assert(goTo(v));
    int t = find(v, u);
    while (t != 1023) {
        assert(goTo(t));
        t = find(t, u);
    }
    goTo(p);
    return nxt;
}
void speedrun(int subtask, int N, int start) {
    if (N == 1) {
        return;
    }
    if (subtask == 2) {
        int p = 0, c = 0;
        for (int j = 0; j < 10; j++) {
            p |= getHint(j + 1) << j;
            c |= getHint(j + 10 + 1) << j;
        }
        goTo(p);
        int x = 0;
        for (int j = 0; j < 10; j++) {
            x |= getHint(j + 10 + 1) << j;
        }
        for (int i = 0; i < N; i++) {
            goTo(x);
            x = 0;
            for (int j = 0; j < 10; j++) {
                x |= getHint(j + 10 + 1) << j;
            }
            goTo(p);
        }
        return;
    } else if (subtask == 3) {
        for (int i = 0; i < N; i++) {
            int l = 0, r = 0;
            for (int j = 0; j < 10; j++) {
                l |= getHint(j + 1) << j;
                r |= getHint(j + 10 + 1) << j;
            }
            if (l != 0) assert(goTo(l));
        }
        for (int i = 0; i < N; i++) {
            int l = 0, r = 0;
            for (int j = 0; j < 10; j++) {
                l |= getHint(j + 1) << j;
                r |= getHint(j + 10 + 1) << j;
            }
            if (r != 0) assert(goTo(r));
        }
        return;
    }
    int s = start;
    while (s != 1) {
        int c = 0;
        for (int j = 0; j < 10; j++) {
            c |= getHint(j + 20 + 1) << j;
        }
        assert(goTo(c));
        s = c;
    }
    find(1, 1);
}

/*


5
1 2
1 5
2 3
2 4
2



4
1 2
1 3
4 1
1


4
1 2
2 3
3 4
1


5
1 2
3 4
2 3
4 5
5



*/
