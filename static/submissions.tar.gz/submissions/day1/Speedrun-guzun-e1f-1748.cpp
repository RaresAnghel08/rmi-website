/**
* user:  guzun-e1f
* fname: Veaceslav
* lname: Guzun
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:23:55.724185
*/
//#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define ll long long
#define sz(a) (int)a.size()
#define all(v) v.begin(),v.end()

void setHintLen(int l){}
void setHint(int i,int j,bool b){}
int getLength(){}
bool getHint(int j){}
bool goTo(int x){}

void assignHints(int subtask, int N, int A[], int B[]) {

    if(subtask == 1){
        setHintLen(N);
        for(int i = 1;i <= N - 1; ++i){
            setHint(A[i], B[i], 1);
            setHint(B[i], A[i], 1);
        }
    }else if(subtask == 3){
        setHintLen(20);
        vector<vector<int>> adj(N + 1);
        for(int i = 1;i <= N; ++i){
            adj[A[i]].pb(B[i]);
            adj[B[i]].pb(A[i]);
        }

        int idx = 1;
        for(int i = 1;i <= N; ++i){
            if(sz(adj[i]) == 1)adj[i].pb(0);
            for(int v: adj[i])
            {
                for(int j = 9;j >= 0; --j){
                    if(v & (1 << j))setHint(i, idx, 1);
                    ++idx;
                }
            }
        }
    }
}

void dfs1(int u, int par, vector<bool>& vis, int n){
    vis[u] = true;
    for(int v = 1;v <= n; ++v){
        if(!vis[v] && getHint(v) == 1){
            int x = goTo(v);
            assert(x == 1);
            dfs1(v, u, vis, n);
        }
    }
    if(par != -1){
        int x = goTo(par);
        assert(x == 1);
    }
}

void dfs3(int u, int par, vector<bool>& vis, vector<vector<int>>& adj){
    vis[u] = true;

    int A = 0, B = 0;
    for(int j = 20;j >= 11; --j){
        if(getHint(j) == 1){
            A += (1 << (j - 10 - 1));
        }
    }
    for(int j = 10; j >= 1; --j){
        if(getHint(j) == 1){
            B += (1 << (j - 1));
        }
    }
    adj[u].pb(A);
    adj[u].pb(B);

    for(int v: adj[u]){
        if(!vis[v]){
            int x = goTo(v);
            assert(x == 1);
            dfs3(v, u, vis, adj);
        }
    }

    if(par != -1){
        int x = goTo(par);
        assert(x == 1);
    }
}
void speedrun(int subtask, int N, int start) {
    if(subtask == 1){
        int l = getLength();
        vector<bool> vis(N + 5, false);
        dfs1(start, -1, vis, N);
    }else if(subtask == 3){
        int l = getLength();
        vector<bool> vis(N + 5, false);
        vector<vector<int>> adj(N + 5);
        dfs3(start, -1, vis, adj);
    }
}

/*
int32_t main(){
    //represent both children of node
}
*/

