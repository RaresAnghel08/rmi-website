/**
* user:  bankov-a77
* fname: Mihail
* lname: Bankov
* task:  Speedrun
* score: 27.0
* date:  2021-12-16 11:21:57.931879
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;
void assignHints(int subtask,int n,int A[],int B[])
{
    if(subtask==1)
    {
        int a[n+1][n+1];
        for(int i=1;i<=n;i++)for(int j=0;j<=n;j++)a[i][j]=0;
        for(int i=1;i<=n-1;i++)
        {
            a[A[i]][B[i]]=a[B[i]][A[i]]=1;
        }
        setHintLen(n);
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                setHint(i,j,a[i][j]);
            }
        }
    }
    else if(subtask==2)
    {
        vector<int>a[n+1];
        for(int i=1; i<=n-1; i++)
        {
            a[A[i]].push_back(B[i]);
            a[B[i]].push_back(A[i]);
        }
        int x=-1;
        for(int i=1; i<=n; i++)
        {
            if(a[i].size()==n-1)
            {
                x=i;
            }
        }
        vector<int>bits;
        while(x!=0)
        {
            bits.push_back(x%2);
            x/=2;
        }
        reverse(bits.begin(),bits.end());
        setHintLen(bits.size());
        for(int i=1;i<=n;i++)
        {
            for(int j=0;j<bits.size();j++)
            {
                setHint(i,j+1,bits[j]);
            }
        }
    }
    else if(subtask==3)
    {
        vector<int>a[n+1];
        for(int i=1;i<=n-1;i++)
        {
            a[A[i]].push_back(B[i]);
            a[B[i]].push_back(A[i]);
        }
        int x;
        for(int i=1;i<=n;i++){if(a[i].size()==1)x=i;}
        a[x]={0,a[x][0]};
        int next=a[x][1];
        while(a[next].size()!=1)
        {
            if(a[next][1]==x)swap(a[next][1],a[next][0]);
            x=next;
            next=a[next][1];
        }
        setHintLen(20);
        a[next].push_back(0);
        for(int i=1;i<=n;i++)
        {
            x=a[i][0];
            int y=a[i][1];
            for(int j=1;j<=10;j++)
            {
                setHint(i,j,x%2);
                x/=2;
            }
            for(int j=11;j<=20;j++)
            {
                setHint(i,j,y%2);
                y/=2;
            }
        }
    }
    return;
}
bool used[1002];
void dfs(int cur,int n)
{
    used[cur]=1;
    for(int i=1;i<=n;i++)
    {
        if(!used[i] && getHint(i))
        {
            goTo(i);
            dfs(i,n);
            goTo(cur);
        }
    }
}
bool upd(int &x,int &y)
{
    x=y=0;
    for(int i=10;i>=1;i--){x*=2;x+=getHint(i);}
    for(int i=20;i>=11;i--){y*=2;y+=getHint(i);}
    return x!=0;
}
bool updd(int &x,int &y)
{
    x=y=0;
    for(int i=10;i>=1;i--){x*=2;x+=getHint(i);}
    for(int i=20;i>=11;i--){y*=2;y+=getHint(i);}
    return y!=0;
}
void speedrun(int subtask,int n,int start)
{
    if(n==1)return;
    if(subtask==1)
    {
        for(int i=0;i<=n;i++)used[i]=0;
        dfs(start,n);
    }
    else if(subtask==2)
    {
        int l=getLength();
        int x=0;
        for(int i=1;i<=l;i++)
        {
            x*=2;
            x+=getHint(i);
        }
        if(start!=x)goTo(x);
        for(int i=1;i<=n;i++)
        {
            if(i!=x)
            {
                goTo(i);
                goTo(x);
            }
        }
    }
    else if(subtask==3)
    {
        int x=0,y=0;
        while(upd(x,y))
        {
            goTo(x);
        }
        while(updd(x,y))
        {
            goTo(y);
        }
    }
    return;
}
