/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:30:33.294396
*/
#include "speedrun.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;

inline int Log(int n) {
    return 32 - __builtin_clz(n);
}

inline vb Convert(int n, int block) {
    vb ans(block + 1);
    for (int i = 0; i < n; i++) {
        if ((n >> i) & 1) {
            ans[block - i] = true;
        }
    }
    return ans;
}

void Dfs(vvi &tree, int node, int parent, int &up, int &last, int block) {
    vb par = Convert(parent, block);
    for (int i = 1; i <= block; i++) if (par[i]) setHint(node, i, par[i]);
    last = node, up = 0;
    for (int neighbor : tree[node]) {
        if (neighbor == parent) continue;
        vb next = Convert(neighbor, block);
        vb steps = Convert(up, block);
        for (int i = block + 1; i <= 2 * block; i++) {
            if (steps[i - block]) setHint(last, i, steps[i - block]);
        }
        for (int i = 2 * block + 1; i <= 3 * block; i++) {
            if (next[i - 2 * block]) {
                setHint(last, i, next[i - 2 * block]);
            }
        }
        Dfs(tree, neighbor, node, up, last, block);
    }
    up++;
}

void assignHints(int subtask, int n, int A[], int B[]) {
    int sz = 3 * (Log(n) + 1);
    int block = sz / 3;
    setHintLen(sz);
    vvi tree(n + 1);
    for (int i = 1; i < n; i++) {
        tree[A[i]].push_back(B[i]);
        tree[B[i]].push_back(A[i]);
    }
    int up = 0, last = 0;
    stack<int> stk;
    stk.push(1);
    int parent = 0;
    vb visited(n + 1);
    while (!stk.empty()) {
        int node = stk.top();
        if (!visited[node]) {
            last = node, up = 0;
            vb par = Convert(parent, block);
            for (int i = 1; i <= block; i++) if (par[i]) setHint(node, i, par[i]);
        }
        if (tree[node].empty()) {
            stk.pop();
            up++;
            continue;
        }
        visited[node] = true;
        int neighbor = tree[node].back();
        tree[node].pop_back();
//        for (int neighbor : tree[node]) {
            if (neighbor == parent) continue;
            vb next = Convert(neighbor, block);
            vb steps = Convert(up, block);
            for (int i = block + 1; i <= 2 * block; i++) {
                if (steps[i - block]) setHint(last, i, steps[i - block]);
            }
            for (int i = 2 * block + 1; i <= 3 * block; i++) {
                if (next[i - 2 * block]) {
                    setHint(last, i, next[i - 2 * block]);
                }
            }
            stk.push(neighbor);
            parent = node;
            continue;
//            Dfs(tree, neighbor, node, up, last, block);
//        }
    }
//    Dfs(tree, 1, 0, up, last, sz / 3);
}

void speedrun(int subtask, int n, int start) {
    int node = start;
    int block = getLength() / 3;
    while (node != 1) {
        int parent = 0;
        for (int i = 1; i <= block; i++) {
            parent <<= 1;
            parent += getHint(i);
        }
        goTo(parent);
        node = parent;
    }
    for (int i = 0; i < n - 1; i++) {
        int next = 0, steps = 0;
        for (int j = 2 * block + 1; j <= 3 * block; j++) {
            next <<= 1;
            next += getHint(j);
        }
        for (int j = block + 1; j <= 2 * block; j++) {
            steps <<= 1;
            steps += getHint(j);
        }
        while (steps--) {
            int parent = 0;
            for (int j = 1; j <= block; j++) {
                parent <<= 1;
                parent += getHint(j);
            }
            goTo(parent);
        }
        goTo(next);
    }
}
//5
//1 2
//2 3
//3 4
//3 5
//1

//6
//5 1
//5 2
//5 3
//5 4
//5 6
//5