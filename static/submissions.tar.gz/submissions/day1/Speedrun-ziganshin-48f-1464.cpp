/**
* user:  ziganshin-48f
* fname: Emir Ramilevich
* lname: Ziganshin
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 07:58:45.240246
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;

const int MXN = 1e3 + 10, K = 20;
int L = 20;

vector<int> a[MXN];

void write(int i, int pos, int val) {
    for (int j = 0; j < K; j++) {
        setHint(i, pos + j, (val >> j) & 1);
    }
}

void assignHints(int subtask, int N, int A[], int B[]) {
    for (int i = 1; i < N; i++) {
        a[A[i]].push_back(B[i]);
        a[B[i]].push_back(A[i]);
    }
    if (subtask == 1) {
        setHintLen(N);
        for (int i = 1; i <= N; i++) {
            for (int j = 0; j < a[i].size(); j++) {
                setHint(i, a[i][j], true);
            }
        }
    } else if (subtask == 2) {
        setHintLen(L);
        int pos = -1;
        for (int i = 0; i < N; i++) {
            if (a[i].size() == N - 1) {
                pos = i;
                break;
            }
        }
        setHint(pos, 1, true);
    }
}

bool used[MXN];

int read(int i, int pos) {

}

void dfs1(int v, int p, int N) {
    used[v] = true;
    for (int i = 1; i <= N; i++) {
        if (!used[i] && getHint(i)) {
            goTo(i);
            dfs1(i, v, N);
        }
    }
    if (p != -1) {
        goTo(p);
    }
}

void speedrun(int subtask, int N, int start) {
    if (subtask == 1) {
        dfs1(start, -1, N);
    } else if (subtask == 2) {
        used[start] = true;
        int v = -1;
        if (getHint(1) != 1) {
            for (int i = 1; i <= N; i++) {
                if (i != start) {
                    if (goTo(i)) {
                        v = i;
                        break;
                    }
                }
            }
        } else {
            v = start;
        }
        used[v] = true;
        for (int i = 1; i <= N; i++) {
            if (!used[i]) {
                goTo(i);
                goTo(v);
            }
        }
    } else if ( subtask == 3) {

    }
}
