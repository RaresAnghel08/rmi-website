/**
* user:  gatev-8cc
* fname: Aleksandar Miroslavov
* lname: Gatev
* task:  Gardening
* score: 11.0
* date:  2021-12-16 07:50:22.703806
*/
#include<bits/stdc++.h>
using namespace std;

int t,n,m,k,cnt,p;

int main(){

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin>>t;
    for(int i=1;i<=t;i++){
        cin>>n>>m>>k;
        if(n*m<4*k or n%2==1 or m%2==1){
            cout<<"NO\n";
        }else{
            if(n==2){
                if(k!=m/2){
                    cout<<"NO\n";continue;
                }
                cout<<"YES\n";
                for(int i=1;i<=n;i++){
                    for(int f=1;f<=m;f++){
                        cout<<(f+1)/2<<" ";
                    }
                    cout<<"\n";
                }
            }else if(n==4){
                if(k<m/2 or k==m-1){
                    cout<<"NO\n";continue;
                }
                cout<<"YES\n";
                cnt=m-(m-k)*2;
                for(int i=1;i<=n;i++){
                    for(int f=1;f<=cnt;f++){
                        if(i<=2)cout<<(f+1)/2<<" ";
                        else cout<<(f+1)/2+cnt/2<<" ";
                    }
                    p=cnt;
                    for(int f=cnt+1;f<=m;f++){
                        if(f>cnt+1 and f<m and i>1 and i<4)cout<<p+(f-cnt)/2<<" ";
                        else cout<<k<<" ";
                    }
                    cout<<"\n";
                }
            }

        }
    }

    return 0;
}