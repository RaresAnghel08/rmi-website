/**
* user:  cercelescu-278
* fname: Șerban Ion
* lname: Cercelescu
* task:  restore
* score: 7.0
* date:  2019-10-10 10:32:35.965469
*/
// Gott mit uns!
#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;

using pii = pair<int, int>;

const int N = 1005, M = 10005, INF = 1e9;

struct Check {
	int l, r, k, tip; };

struct Query {
	int l, tip; };

int dp[N][N][2];
int enf[N];
vector<Query> qs[N];

vector<Check> ch;
int n, m;

int main() {
#ifdef HOME
	freopen("restore.in", "r", stdin);
	freopen("restore.out", "w", stdout);
#endif
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);

	cin >> n >> m;
	ch.reserve(m);
	while (m--) {
		int l, r, k, val;
		cin >> l >> r >> k >> val;
		ch.push_back({++l, ++r, k, val}); }

	if (n > 20) exit(0);

	for (int i = 0; i < (1 << n); ++i) {
		bool flag = true;
		for (int j = 0; j < n; ++j) {
			if (i & (1 << j))
				enf[j + 1] = 1;
			else
				enf[j + 1] = 0; }

		for (int i = 1; i <= n; ++i)
			enf[i]+= enf[i - 1];

		for (auto q: ch) {
			if (q.tip == 1) { // there are fewer zeros than k
				if (q.r - q.l + 1 - (enf[q.r] - enf[q.l - 1]) >= q.k) {
					flag = false;
					break; } }
			else { // there are fewer ones than len - k
				if (q.r - q.l + 1 - (enf[q.r] - enf[q.l - 1]) < q.k) {
					flag = false;
					break; } } }

		if (!flag)
			continue;

		for (int i = 1; i <= n; ++i)
			cout << enf[i] - enf[i - 1] << " \n"[i == n];
		return 0;  }

	cout << "-1\n";

	return 0; }

