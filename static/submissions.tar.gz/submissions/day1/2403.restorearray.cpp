/**
* user:  semerdzhiev-688
* fname: Borislav
* lname: Semerdzhiev
* task:  restore
* score: 0.0
* date:  2019-10-10 09:11:42.392185
*/
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

int n, m;

//FILE* open = fopen("arr_test.txt", "r");

struct masiv
{
    int l, r, k, val;

    masiv(int _l, int _r, int _k, int _val)
    {
        l = _l; r = _r; k = _k; val = _val;
    }

    bool operator<(masiv other) const
    {
        return (r - l) < (other.r - other.l);
    }
};

vector <masiv> v;

void read_input()
{
    scanf("%d %d", &n, &m);
    //fscanf(open, "%d %d", &n, &m);

    int l, r, k, val;
    for(int i = 0; i < m; i++)
    {
        scanf("%d %d %d %d", &l, &r, &k, &val);
        //fscanf(open, "%d %d %d %d", &l, &r, &k, &val);
        v.push_back(masiv(l, r, k, val));
    }
    sort(v.begin(), v.end());
}

void solve()
{
    for(int mask = 0; mask < (1 << n); mask++)
    {
        bool fl = true;
        for(int j = 0; j < m; j++)
        {
            int mi = 1, cnt = 0;
            for(int z = v[j].l; z <= v[j].r; z++)
            {
                if(!(mask && (1 << j)))
                {
                    mi = 0;
                    break;
                }
            }
            for(int z = v[j].l; z <= v[j].r; z++)
            {
                if(!(mask & (1 << j)))
                {
                    cnt++;
                }
                else
                {
                    if(mi == 1)
                    {
                        cnt++;
                    }
                }
                if(cnt == v[j].k)
                {
                    int temp = ((1 << j) & mask) == 0? 0 : 1;
                    if(v[j].val != temp) fl = false;
                    break;
                }
            }
        }
        if(fl)
        {
            for(int j = 0; j < n; j++)
            {
                printf("%d ", ((1 << j) & mask) == 0? 0 : 1);
            }
            printf("\n");
            return;
        }
    }
    printf("-1\n");
}

int main()
{
    read_input();
    solve();

    return 0;
}
/*
4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0
*/
