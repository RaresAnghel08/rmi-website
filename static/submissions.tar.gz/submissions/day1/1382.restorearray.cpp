/**
* user:  czarkowski-d42
* fname: Arkadiusz
* lname: Czarkowski
* task:  restore
* score: 38.0
* date:  2019-10-10 06:31:27.989438
*/
#include <bits/stdc++.h>

using namespace std;

int n, m, l, r, k, v, t[5010], lp, ll, x;
pair <pair <int, int>, int> p[10010];

int main()
{
	scanf("%d%d", &n, &m);
	for(int i=0; i<m; ++i)
	{
		scanf("%d%d%d%d", &l, &r, &k, &v);
		if(k==1)
		{
			if(v==1)
			{
				for(int j=l; j<=r; ++j)
				{
					if(t[j]==2)
					{
						printf("-1");
						return 0;
					}
					t[j]=1;
				}
			}
			else
			{
				p[lp++]={{r, l}, 2};
			}
		}
		else    //k==r-l+1
		{
			if(v==1)
			{
				p[lp++]={{r, l}, 1};
			}
			else
			{
				for(int j=l; j<=r; ++j)
				{
					if(t[j]==1)
					{
						printf("-1");
						return 0;
					}
					t[j]=2;
				}
			}
		}
	}
	for(int i=0; i<lp; ++i)
	{
		ll=0;
		x=-1;
		l=p[i].first.second;
		r=p[i].first.first;
		v=p[i].second;
		bool fl=false;
		for(int j=l; j<=r; ++j)
		{
			if(t[j]==v)
			{
				fl=true;
				break;
			}
			if(!t[j])
			{
				x=j;
				++ll;
			}
		}
		if(fl)
			continue;
		if(!ll)
		{
			printf("-1");
			return 0;
		}
		if(ll>=2)
		{
			continue;
		}
		t[x]=v;
	}
	l=0;
	for(int i=0; i<n; ++i)
	{
		if(!t[i])
		{
			if(l)
			{
				t[i]=1;
			}
			else
			{
				t[i]=2;
			}
			l^=1;
		}
		printf("%d ", t[i]&1);
	}
	return 0;
}
