/**
* user:  handarov-0db
* fname: Radostin
* lname: Handarov
* task:  devil
* score: 0.0
* date:  2019-10-10 07:38:34.508125
*/
#include <bits/stdc++.h>

#pragma GCC optimize "-O3"

#define endl "\n"
#define trace(x) cerr << #x << " = " << x << endl
#define sz(x) ((int)x.size())
#define all(x) x.begin(), x.end()

using namespace std;

template<class T, class T1> inline bool chkmax(T &x, const T1 &y) { return x < y ? x = y, true : false; }
template<class T, class T1> inline bool chkmin(T &x, const T1 &y) { return x > y ? x = y, true : false; }

int k;
vector<int> cntDig(10);

void read() {
	cin >> k;
	for (int i = 1; i <= 9; i++) {
		cin >> cntDig[i];
	}
}

void solve() {
	vector<int> perm;
	for (int i = 1; i <= 9; i++) {
		for (int j = 0; j < cntDig[i]; j++) {
			perm.emplace_back(i);
		}
	}
	vector<int> answer;
	long long minNum = (long long)1e10;
	long long power10 = 1;
	for (int i = 1; i < k; i++) {
		power10 *= 10;
	}
	do {
		long long maxNum = 0;
		for (int i = 0; i < k; i++) {
			maxNum = maxNum * 10 + perm[i];
		}
		long long currNum = maxNum;
		for (int i = k; i < sz(perm); i++) {
			currNum %= power10;
			currNum = currNum * 10 + perm[i];
			chkmax(maxNum, currNum);
		}
		if (chkmin(minNum, maxNum)) {
			answer = perm;
		}
	} while (next_permutation(all(perm)));
	for (int i = 0; i < sz(answer); i++) {
		cout << answer[i];
	}
	cout << endl;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int t;
	cin >> t;
	while (t--) {
		read();
		solve();
	}

	return EXIT_SUCCESS;
}