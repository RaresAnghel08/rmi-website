/**
* user:  yacouel-598
* fname: Assaf
* lname: Yacouel
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 11:53:55.045651
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <stack>
#include "speedrun.h"
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
vi bin(ll n) {
	vi ans;
	ll m = n;
	while (m > 0) {
		ans.push_back(m % 2);
		m /= 2;
	}
	while (ans.size() < 20) ans.push_back(0);
	return ans;
}
void assignHints(int subtask, int N, int A[], int B[]) {
	if (subtask == 2) {
		setHintLen(20);
		vvi adj;
		for (int i = 0; i < N; i++) adj.push_back({});
		for (int i = 1; i < N; i++) {
			A[i]--, B[i]--;
			adj[A[i]].push_back(B[i]);
			adj[B[i]].push_back(A[i]);
		}
		int ind = 0;
		if (N > 2) while (adj[ind].size() == 1) ind++;
		vi s = bin(ind + 1);
		for (int i = 0; i < N; i++) {
			if (i == ind) {
				for (int j = 0; j < 20; j++) {
					setHint(i + 1, j + 1, 0);
				}
			}
			else {
				for (int j = 0; j < 20; j++) {
					setHint(i + 1, j + 1, s[j]);
				}
			}
		}
	}
	else if(subtask == 3) {
		setHintLen(20);
		vvi adj;
		vi nums;
		stack<int> st;
		for (int i = 0; i < N; i++) {
			adj.push_back({});
			nums.push_back(-1);
		}
		for (int i = 1; i < N; i++) {
			A[i]--, B[i]--;
			adj[A[i]].push_back(B[i]);
			adj[B[i]].push_back(A[i]);
		}
		int ind = 0;
		if (N > 2) while (adj[ind].size() > 1) ind++;
		nums[ind] = 0;
		st.push(ind);
		while(st.size() > 0) {
			ind = st.top();
			st.pop();
			for (int x : adj[ind]) {
				if (nums[x] == -1) {
					nums[x] = nums[ind] + 1;
					st.push(x);
				}
			}
		}
		vi s = bin(ind + 1);
		for (int i = 0; i < N; i++) {
			for (int x : adj[i]) {
				if (nums[x] < nums[i]) {
					s = bin(x + 1);
					for (int j = 0; j < 10; j++) setHint(i + 1, j + 1, s[j]);
				}
				else {
					s = bin(x + 1);
					for (int j = 0; j < 10; j++) setHint(i + 1, j + 11, s[j]);
				}
			}
		}
	}
	else {
		setHintLen(N);
		vvi adj;
		stack<int> st;
		for (int i = 0; i < N; i++) {
			adj.push_back({});
		}
		for (int i = 1; i < N; i++) {
			A[i]--, B[i]--;
			adj[A[i]].push_back(B[i]);
			adj[B[i]].push_back(A[i]);
		}
		for (int i = 0; i < N; i++) {
			for (int x : adj[i]) {
				setHint(i + 1, x + 1, 1);
			}
		}
	}
}
void speedrun(int subtask, int N, int start) {
	if (subtask == 2) {
		int center = 0;
		for (int i = 0; i < 20; i++) {
			center += (1 << i) * getHint(i + 1);
		}
		if (center == 0) {
			for (int i = 0; i < N; i++) {
				if ((i + 1) != start) {
					goTo(i + 1);
					goTo(start);
				}
			}
		}
		else {
			goTo(center);
			for (int i = 0; i < N; i++) {
				if ((i + 1) != start && (i + 1) != center) {
					goTo(i + 1);
					goTo(center);
				}
			}
		}
	}
	else if (subtask == 3) {
		int x = 0;
		for (int i = 0; i < 10; i++) {
			x += (1 << i) * getHint(i + 1);
		}
		while (x != 0) {
			goTo(x);
			int x = 0;
			for (int i = 0; i < 10; i++) {
				x += (1 << i) * getHint(i + 1);
			}
		}
		x = 0;
		for (int i = 0; i < 10; i++) {
			x += (1 << i) * getHint(i + 11);
		}
		while (x != 0) {
			goTo(x);
			int x = 0;
			for (int i = 0; i < 10; i++) {
				x += (1 << i) * getHint(i + 11);
			}
		}
	}
	/*else {
		stack<int> st;
		vi visited;
		for (int i = 0; i < N; i++) visited[i] = 0;
		int ind;
		visited[ind] = 1;
		st.push_back(start + 1);
		while (st.size() > 0) {
			ind = st.top();
			for (int i = 1; i <= N; i++) {
				if (getHint(i) == 1) {
					goTo(i);
					goTo(ind);
				}
			}

		}
	}*/
}