/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  restore
* score: 7.0
* date:  2019-10-10 07:29:56.474475
*/
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int NMAX = 5e3 + 5, MMAX = 1e4 + 5;

int N, M;

int A[NMAX];

struct Query
{
    int Left, Right, K, Val;
};

Query V[MMAX];

bool Sel[NMAX];

static inline void Task1 ()
{
    for(int i = 0; i < (1 << N); ++i)
    {
        for(int j = 0; j < N; ++j)
            if(i & (1 << j))
                Sel[j + 1] = true;
            else Sel[j + 1] = false;

        bool Ok = true;

        for(int j = 1; j <= M; ++j)
        {
            vector < int > q;

            for(int k = V[j].Left; k <= V[j].Right; ++k)
                q.push_back(Sel[k]);

            sort(q.begin(), q.end());

            if(q[V[j].K - 1] != V[j].Val)
            {
                Ok = false;

                break;
            }
        }

        if(Ok)
        {
            for(int j = 1; j <= N; ++j)
                cout << Sel[j] << ' ';

            cout << '\n';

            return;
        }
    }

    cout << -1 << '\n';

    return;
}

int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> N >> M;

    for(int i = 1; i <= M; ++i)
    {
        cin >> V[i].Left >> V[i].Right >> V[i].K >> V[i].Val;

        ++V[i].Left;
        ++V[i].Right;
    }

    if(N <= 18)
        Task1();

    return 0;
}
