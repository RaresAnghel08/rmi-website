/**
* user:  fomiuk-cd9
* fname: Artem
* lname: Fomiuk
* task:  restore
* score: 13.0
* date:  2019-10-10 08:19:40.502396
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

template<class A>using sett=tree<A,null_type,less<A>,rb_tree_tag,tree_order_statistics_node_update>;
template<class A,class B>using mapp=tree<A,B,less<A>,rb_tree_tag,tree_order_statistics_node_update>;
template<class A>using multisett=tree<A,null_type,less_equal<A>,rb_tree_tag,tree_order_statistics_node_update>;
template<class A,class B>using multimapp=tree<A,B,less_equal<A>,rb_tree_tag,tree_order_statistics_node_update>;

#define i128 __int128
#define DIM 200009
#define INF ((long long)1e18+9ll)
#define pairll pair<long long,long long>
#define fi first
#define se second
#define ld long double
#define fast ios_base::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define amen exit(0)
#define endl '\n'
#define eps 0.0000000001
#define MODULO 1000000007

long long i,j,k,l,n,m;

struct query{
	long long l,r,k,t;
};

vector<query>q;

long long a[DIM],dp[DIM][2];

int main(){

	//fast;

	cin>>n>>m;

	for(i=1;i<=m;i++){
		int l,r,k,t;
		cin>>l>>r>>k>>t;
		l++;
		r++;
		if(t==1){
			for(j=l;j<=r;j++)a[j]=1;
		}
		else q.push_back({l,r,k,t});
	}

	for(auto to:q){
		k=0;
		for(i=to.l;i<=to.r;i++){
			k+=a[i];
		}
		if(k==to.r-to.l+1)return cout<<-1<<endl,0;
	}

	for(i=1;i<=n;i++)cout<<a[i]<<' ';
	cout<<endl;

	amen;
}
/*
3
2
1 1 2 0 0 0 0 0 0
7
2 4 2 0 0 6 2 2 2 
7
3 3 3 0 0 6 2 2 2
*/