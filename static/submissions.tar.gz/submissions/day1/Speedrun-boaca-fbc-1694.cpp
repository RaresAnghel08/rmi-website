/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:19:39.409239
*/
#include "speedrun.h"
#include <bits/stdc++.h>
//#include "grader.cpp"

vector<int> muchii[1005];
int n;
void assignHints(int subtask, int N, int A[], int B[])
{
    n=N;
    for(int i=1;i<n;i++)
    {
        int a=A[i];
        int b=B[i];
        muchii[a].push_back(b);
        muchii[b].push_back(a);
    }
    setHintLen(n);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            setHint(i,j,0);
        for(int j:muchii[i])
            setHint(i,j,1);
    }
}
bool use[1005];
void dfs(int nod,int par)
{
    for(int i=1;i<=n;i++)
        if(getHint(i)==1&&i!=par)
        {
            goTo(i);
            dfs(i,nod);
        }
    if(par!=0)
        goTo(par);
}
void speedrun(int subtask, int N, int start)
{
    int l=getLength();
    dfs(start,0);

}
