/**
* user:  almazbekov-a71
* fname: Beksultan
* lname: Almazbekov
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 11:20:15.189769
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
#define pii pair<int,int>
#define fr first
#define sc second
#define NO puts("NO");
#define YES puts("YES");
#define endi puts("");
#define pb push_back
#define ret return
vector <int> g[1002];
int h = 0,hh;
void assignHints(int subtask, int N, int A[], int B[]) {
	int z = 1,i,j;
	while (z <= N){
		z *= 2;
		h++;
	}
	setHintLen(h+1);
	for (i=1;i<N;++i){
		g[A[i]].pb(B[i]);
		g[B[i]].pb(A[i]);
	}
	for (i=1;i<=N;++i){
		if (g[i].size() == 1){
			int z = g[i][0],cnt=1;
			while (z > 0){
				if (z%2== 1){
					setHint(i,cnt,1);
				}
				z/=2;
				cnt++;
			}
		}
		else 
			for (j=1;j<=h+1;++j)
				setHint(i,j,1);
			
	
	}
	ret ;
}

void speedrun(int subtask, int N, int start) {
	hh = getLength();
	int c=1,y=0,z=0,i;
	for (i=1;i<=hh;++i){
		if (getHint(i) == 1){
			y += c;
			z++;
		}
		c*=2;
	}
	if (z == hh){
		for (i=1;i<=N;++i){
			if (i == start)continue;
			goTo(i);
			goTo(start);
		}
	}
	else {
		goTo(y);
		for (i=1;i<=N;++i){
			if (i == y || i == start)continue;
			goTo(i);
			goTo(y);
		}
	}
}
