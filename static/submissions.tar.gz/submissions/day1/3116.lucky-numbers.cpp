/**
* user:  metehau-fd8
* fname: Luca
* lname: Metehău
* task:  lucky
* score: 14.0
* date:  2019-10-10 10:32:34.110905
*/
#include <iostream>

using namespace std;

const int MOD = (int)1e9 + 7;

int n, m, k, ans;

int v[10005], dp[10005], dp3[10005];

int f(int n) {
  if(n < 0)
    return 0;
  if(n == 0)
    return 1;
  if(n == 1)
    return 10;
  if(dp[n])
    return dp[n];
  dp[n] = (10LL * f(n - 1) % MOD - f(n - 2) + MOD) % MOD;
  return dp[n];
}


int main() {
  cin >> n >> m >> n;
  int ans = 0;
  for(int i = 0; i <= n; i++) {
    int tmp = i, ok = 1;
    while(tmp > 10) {
        if(tmp % 100 == 13)
        ok = 0;
        tmp /= 10;
    }
    ans += ok;
  }
  cout << ans;
  return 0;
}
