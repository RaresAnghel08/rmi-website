/**
* user:  verzotti-765
* fname: Matteo-Alexandru
* lname: Verzotti
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:21:18.236008
*/
#include <bits/stdc++.h>
#define dbg(x) cerr << #x << ' ' << x << '\n'
#define dsp(x) cerr << #x << ' ' << x << ' '

using namespace std;

void SetIO();

struct Dim {
    int n, m, k;
};

vector <Dim> v;
bool sePoate(int n, int m, int k) {
    if (n == 6 && m == 6 && k == 25)
        cerr << "AICIICICI";
    if (k < 1) return false;
    if ((n & 1) || (m & 1)) return false;
    if (n == 2 && m == 2) {
        if (k == 1) v.push_back({n, m, k});
        return k == 1;
    }

    bool ok = sePoate(n - 2, m - 2, k - 1);
    if (ok == true) {
        v.push_back({n, m, k});
        return true;
    }

    for (int i = 2; i * i <= n && ok == false; i++) {
        if (n % i == 0 && i % 2 == 0) {
            if (k % ((n / i) * (n / i)) == 0)
                ok |= sePoate(i, i, k / (n / i) / (n / i));
        }

        if (ok == false && n % i == 0 && ((n / i) & 1) == 0)
            if (k % (i * i) == 0)
            ok |= sePoate(n / i, n / i, k / (i * i));
    }
    
    if (ok == true)
        v.push_back({n, m, k});
    return ok;
}

void coloreaza(vector <vector <int>> &a, int k, int idx, int i = 0, int j = 0) {
    if (idx == 0) {
        a[i][j] = a[i + 1][j] = a[i][j + 1] = a[i + 1][j + 1] = k;
        return;
    } else {
        if (v[idx].n == v[idx - 1].n + 2 && v[idx].m == v[idx - 1].m + 2 && v[idx].k == v[idx - 1].k + 1) {
            // colorez borderu
            for (int ii = i; ii < i + v[idx].n; ii++)
                a[ii][j] = a[ii][j + v[idx].m - 1] = k;
            for (int jj = j; jj < j + v[idx].m; jj++)
                a[i][jj] = a[i + v[idx].n - 1][jj] = k;

            coloreaza(a, k - 1, idx - 1, i + 1, j + 1);
        } else {
            assert(v[idx].n % v[idx - 1].n == 0);
            assert(v[idx].m % v[idx - 1].m == 0);
            for (int ii = 0; ii < v[idx].n; ii += v[idx - 1].n)
                for (int jj = 0; jj < v[idx].m; jj += v[idx - 1].m) {
                    coloreaza(a, k, idx - 1, i + ii, j + jj);
                    k--;
                }
        }
    }
}

void solve() {
    int n, m, k;
    bool ok; 
    vector <vector <int>> a;
    // facem subtasku cu N = M
    cin >> n >> m >> k;
    ok = sePoate(n, m, k);
    if (ok == 1) cout << "YES\n";
    else cout << "NO\n";
    
    if (ok == true) {
        a.resize(n, vector <int>(m));
        coloreaza(a, k, v.size() - 1);

        for (int i = 0; i < n; i++, cout << '\n')
            for (int j = 0; j < m; j++)
                cout << a[i][j] << ' ';
    }
    /*if (ok == true) {
        dsp(n); dsp(m); dbg(k);
        for (auto it : v) {
            cerr << it.n << ' ' << it.m << ' ' << it.k << '\n';
        }
        cerr << '\n';
    }*/
    v.clear();
}

int main() {
    SetIO();
    int t;
    cin >> t;

    while (t--)
        solve();
    return 0;
}

void SetIO() {
#ifdef BLAT
    freopen("gardening.in", "r", stdin);
    freopen("gardening.out", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
}
