/**
* user:  nizamutdinov-1d5
* fname: Azat
* lname: Nizamutdinov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 10:39:02.293827
*/
#include <algorithm>
#include <bitset>
#include <deque>
#include <iomanip>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <array>
#include <random>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <chrono>
#include <ctime>
#include <random>
#define ll long long
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
template <typename KEY> using ve = std::vector<KEY>;

using namespace std;

const ll INF = INT64_MAX;

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	ll t; cin >> t;
	while (t--) {
		ll n, m, k; cin >> n >> m >> k;
		ve<ve<ll>> v(n, ve<ll>(m));
		bool w = true, b = true;
		ll n2 = n, n1 = 0, m2 = m, m1 = 0, c = 1;
		for (ll i = 0; i < n && b; i += 2) {
			if (max(m, n - i - 2) / 2 == k - c + 1 || max(m, n) / 2 == k - c + 1) {
				b = false;
				break;
			}
			n1 = i + 2;
			for (ll j = 0; j < m && b; j += 2) {
				v[i][j] = c, v[i + 1][j] = c, v[i][j + 1] = c, v[i + 1][j + 1] = c, ++c;
			}
			if (max(m, n - n1) / 2 == k - c + 1) {
				b = false;
				break;
			}
		}
		while (n2 - n1 > 1 && m2 - m1 > 1 && !((m2 - m1) % 2 == 0 && (n2 - n1) % 2 == 0 && (m2 - m1) * (n2 - n1) / 4 == k - c + 1 && (m2 - m1) * (n2 - n1) % 4 == 0)) {
			for (ll j = m1; j < m2; ++j) v[n1][j] = c, v[n2 - 1][j] = c;
			for (ll i = n1; i < n2; ++i) v[i][m2 - 1] = c, v[i][m1] = c;
			++c;
			--n2, --m2, ++n1, ++m1;
		}
		if ((m2 - m1) * (n2 - n1) / 4 == k - c + 1 && (m2 - m1) * (n2 - n1) % 4 == 0 && c <= k && (m2 - m1) % 2 == 0 && (n2 - n1) % 2 == 0) {
			for (ll i = n1; i < n2; i += 2) {
				for (ll j = m1; j < m2; j += 2) v[i][j] = c, v[i + 1][j] = c, v[i][j + 1] = c, v[i + 1][j + 1] = c, ++c;
			}
			m1 = m2, n1 = n2;
		}
		if (!(c == k + 1 && m1 == m2 && n1 == n2)) w = false;
		if (w) {
			cout << "YES\n";
			for (ll i = 0; i < n; ++i) {
				for (ll j = 0; j < m; ++j) {
					cout << v[i][j] << " ";
				} cout << "\n";
			}
		}
		else cout << "NO\n";
	}
}

