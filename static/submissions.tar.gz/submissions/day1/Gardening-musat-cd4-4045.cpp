/**
* user:  musat-cd4
* fname: Tudor Ştefan
* lname: Muşat
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:55:06.642020
*/
#include <iostream>
#include <vector>

using namespace std;

const int NMAX = 2e5;

vector <int> v[NMAX];
int dirl[4] = { -1, 0, 1, 0 };
int dirc[4] = { 0, 1, 0, -1 };

void init( int n, int m ) {
    for ( int i = 0; i <= n + 1; i ++ )
        v[i].clear();
    for ( int i = 1; i <= n; i ++ ) {
        v[i].push_back( -1 );
        for ( int j = 1; j <= m; j ++ )
            v[i].push_back( 0 );
        v[i].push_back( -1 );
    }
    for ( int j = 0; j <= m + 1; j ++ ) {
        v[0].push_back( -1 );
        v[n + 1].push_back( -1 );
    }
}
void cover( int l, int c, int l2, int c2, int color ) {
    for ( int i = l; i <= l2; i ++ ) {
        for ( int j = c; j <= c2; j ++ ) {
            v[i][j] = color;
        }
    }
}
bool verify( int n, int m ) {
    for ( int i = 1; i <= n; i ++ ) {
        for ( int j = 1; j <= m; j ++ ) {
            int cnt = 0;
            for ( int k = 0; k < 4; k ++ ) {
                if ( v[i + dirl[k]][j + dirc[k]] == v[i][j] )
                    cnt ++;
            }
            if ( cnt != 2 )
                return false;
        }
    }
    return true;
}
void afis( int n, int m ) {
    cout << "YES\n";
    for ( int i = 1; i <= n; i ++ ) {
        for ( int j = 1; j <= m; j ++ )
            cout << v[i][j] + 1 << ' ';
        cout << '\n';
    }
}
void wrong() {
    cout << "NO\n";
}
bool two( int n, int m, int add, int k, int color ) {

    for ( int j = 1; j <= m; j += 2 ) {
        cover( 1 + add, j + add, 2 + add, j + 1 + add, color++ );
    }
    if ( verify( n, m ) && color == k ) {
        return 1;
    }
    return 0;
}
bool four( int n, int m, int add, int k, int color ) {
    int j;
    for ( j = 1; j + 3 <= m; j += 4 ) {
        if ( color + 2 + m - ( j + 3 ) >= k ) {
            cover( 1 + add, j + 0 + add, 4 + add, j + 3 + add, color++ );
            cover( 2 + add, j + 1 + add, 3 + add, j + 2 + add, color++ );
        } else {
            cover( 1 + add, j + add, 2 + add, j + 1 + add, color++ );
            cover( 3 + add, j + add, 4 + add, j + 1 + add, color++ );
            cover( 1 + add, j + 2 + add, 2 + add, j + 3 + add, color++ );
            cover( 3 + add, j + 2 + add, 4 + add, j + 3 + add, color++ );
        }
    }
    if ( j + 1 <= m ) {
        cover( 1 + add, j, 2 + add, j + 1, color++ );
        cover( 3 + add, j, 4 + add, j + 1, color++ );
    }
    if ( verify( n, m ) && color == k ) {
        return 1;
    }
    return 0;
}
void solve() {
    int n, m, i, j, k, color;
    cin >> n >> m >> k;
    if ( n % 2 == 1 || m % 2 == 1 ) {
        wrong();
        return;
    }
    init( n, m );
    color = 0;
    if ( n == 2 ) {
        if ( two( n, m, 0, k, 0 ) )
            afis( n, m );
        else
            wrong();
    } else if ( n == 4 ) {
        cover( 1, 1, n, m, 0 );
        if ( two( 2, m - 2, 1, k, 1 ) ) {
            afis( n, m );
            return;
        }
        cover( 1, 1, n, m, 0 );
        if ( four( n, m, 0, k, 0 ) )
            afis( n, m );
        else
            wrong();
    } else if ( n == 6 ) {
        color = 0;
        for ( j = 1; j + 5 <= m; j += 6 ) {
            if ( color + 3 + ( m - ( j + 5 ) ) / 2 * 3 >= k ) {
                cover( 1, j, 6, j + 5, color++ );
            } else if ( color + 7 + ( m - ( j + 5 ) ) / 2 * 3 >= k ) {
                cover( 1, j, 4, j + 3, color ++ );
                cover( 2, j + 1, 3, j + 2, color++ );
                cover( 1, j + 4, 2, j + 5, color++ );
                cover( 3, j + 4, 4, j + 5, color++ );
                cover( 5, j + 4, 6, j + 5, color++ );
                cover( 5, j, 6, j + 1, color++ );
                cover( 5, j + 2, 6, j + 3, color++ );
            }
        }
        if ( verify( n, m ) && color == k )
            afis( n, m );
        else {
            cover( 1, 1, n, m, 0 );
            if ( four( n - 2, m - 2, 1, k, 1 ) )
                afis( n, m );
            else {
                cover( 2, 2, n - 1, m - 1, 1 );
                if ( two( n - 4, m - 4, 2, k, 1 ) )
                    afis( n, m );
                else
                    wrong();
            }
        }
    }

}
int main() {
    int t = 1;
    cin >> t;
    while ( t-- ) {
        solve();
    }
    return 0;
}
