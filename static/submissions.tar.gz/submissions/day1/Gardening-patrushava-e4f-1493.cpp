/**
* user:  patrushava-e4f
* fname: Hanna
* lname: Patrushava
* task:  Gardening
* score: 5.0
* date:  2021-12-16 08:01:52.411079
*/
#pragma GCC optimize ("unroll-loops")
#pragma GCC optimize ("Ofast")
#include <bits/stdc++.h>

#define f first
#define s second
#define pb push_back
#define pii pair<int, int>
#define ll long long

using namespace std;

int n, m;

vector < vector < int > > a, ans;
vector < pii > pp = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
bool dfs(int x, int y, int len, int nom) {
    a[x][y] = nom;

    if (len > 2) {
        int cnt = 0;
        for (int i = 0; i < 4; i++)
            if (x + pp[i].f < n && x + pp[i].f >= 0 && y + pp[i].s < m && y + pp[i].s >= 0 && a[pp[i].f + x][pp[i].s + y] == nom) {
                cnt++;
            }
        if (cnt == 2)
            return true;
    }


    int cnt = 0;
    for (int i = 0; i < 4; i++) {
        if (x + pp[i].f < n && x + pp[i].f >= 0 && y + pp[i].s >= 0 && y + pp[i].s < m) {
            if (a[x + pp[i].f][y + pp[i].s] == nom)
                cnt++;
        }
    }

    if (cnt >= 2) {
        a[x][y] = 0;
        return false;
    }

    for (int i = 0; i < 4; i++)
        if (x + pp[i].f < n && x + pp[i].f >= 0 && y + pp[i].s < m && y + pp[i].s >= 0 && a[pp[i].f + x][pp[i].s + y] == 0) {
            if (dfs(x + pp[i].f, y + pp[i].s, len + 1, nom) == true)
                return true;
        }

    a[x][y] = 0;
    return false;
}

vector < vector < int > > p;
bool go(int ost) {


    int kol = 0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (p[i][j] == 0)
                kol++;

    if (ost == 0 && kol == 0) {
        ans = p;
        return true;
    } else if (ost == 0)
        return false;

    a = p;
    bool f = 0;
    kol = 0;
    for (int i = 0; i < n; i++) {
        if (f == 1)
            break;
        for (int j = 0; j < m; j++) {
            if (a[i][j] == 0) {
                if (ost == kol) {
                    f = 1;
                    break;
                }

                bool fl = dfs(i, j, 1, ost - kol);
                kol++;
                if (fl == false)
                    f = 1;

            }
        }
    }

    if (f == 0 && kol == ost) {
        ans = a;
        return true;
    }
    for (int i = 0; i + 1 < n; i++)
        for (int j = 0; j + 1 < m; j++) {
            if (p[i][j] == 0 && p[i + 1][j] == 0 && p[i][j + 1] == 0 && p[i + 1][j + 1] == 0) {
                p[i][j] = ost;
                p[i + 1][j] = ost;
                p[i][j + 1] = ost;
                p[i + 1][j + 1] = ost;
                if (go(ost - 1) == true)
                    return true;
                p[i][j] = 0;
                p[i + 1][j] = 0;
                p[i][j + 1] = 0;
                p[i + 1][j + 1] = 0;

            }
        }

    return false;
}
void solve() {
    cin >> n >> m;
    if (n * m > 200000) {
        cout << "NO\n";
        return;
    }

    if (n % 2 == 1 && m % 2 == 1) {
        cout << "NO\n";
        return;
    }

    int need;
    cin >> need;

    int ma = (n * m) / 2;

    if (need > ma) {
        cout << "NO\n";
        return;
    }

    if (need < max(n, m) / 2) {
        cout << "NO\n";
        return;
    }


    p.resize(n);
    for (int i = 0; i < n; i++) {
        p[i].resize(m);
    }

    for (int i = 0; i < n; i++)
    for (int j = 0; j < m; j++) p[i][j] = 0;

    if (go(need) == false)
        cout << "NO\n";
    else {
        cout << "YES\n";
        for (auto to: ans) {
            for (auto x: to)
                cout << x << ' ';
            cout << "\n";
        }
    }

}
int32_t main() {

#ifdef LOCAL
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
#endif // LOCAL

    ios_base::sync_with_stdio();
    cin.tie(0);
    cout.tie(0);

    int t;
    cin >> t;

    while (t--) {
        solve();
    }

    return 0;
}
