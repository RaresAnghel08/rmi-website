/**
* user:  slanina-aed
* fname: Iulia
* lname: Slănină
* task:  devil
* score: 14.0
* date:  2019-10-10 06:26:42.638354
*/
#include <iostream>

using namespace std;
long long v[10],n,sol[1000005],vv[15],vvv[15],mini=2134567894567,k,put,vc[15];
void verif()
{
    long long i,x=0,maxi;
    for (i=1;i<=k;i++)
        x=x*10+vv[i];
    maxi=x;
    for (i=k+1;i<=n;i++)
    {
        x=x-put*vv[i-k];
        x=x*10+vv[i];
        maxi=max(maxi,x);
    }
    if (maxi<mini)
    {
        mini=maxi;
        for (i=1;i<=n;i++)
            sol[i]=vv[i];
    }
}
void bkt (int p)
{
    int i;
    if (p==n+1)
    {
        verif();
    }
    else
    {
        for (i=1;i<=n;i++)
            if(vc[i]==0)
            {
                vc[i]=1;
                vv[p]=vvv[i];
                bkt (p+1);
                vc[i]=0;
            }
    }
}
int main()
{
    int t,h,tip=0,i,j,p=0;
    cin>>t;
    for (h=1;h<=t;h++)
    {
        cin>>k;
        n=0;
        for (i=1;i<=9;i++)
        {
            cin>>v[i];
            n+=v[i];
        }
        p=n;
        if (k==2)
        {
            i=1;
            j=9;
            while (p>1)
            {
                while (v[i]==0)
                    i++;
                while (v[j]==0)
                    j--;
                sol[p]=j;
                sol[p-1]=i;
                v[j]--;
                v[i]--;
                p-=2;
            }
            if (p==1)
            {
                while (v[i]==0)
                    i++;
                sol[p]=i;
            }
        }
        else
        {
int         ok=0;
            for (i=5;i<=9&&ok;i++)
                if (v[i]!=0)
                ok=1;
            if (ok==0)
            {
                if (v[3]==0&&v[4]==0)
                    tip=3;
                else
                {
                    for (i=1;i<=4;i++)
                        if (v[i]>3)
                            ok=1;
                    if (ok==0)
                        tip=1;
                }
            }
           /* if (tip==1)
            {
                put=1;
                for (i=1;i<k;i++)
                    put*=10;
                p=0;
                for (i=1;i<=4;i++)
                    for (j=1;j<=v[i];j++)
                        vvv[++p]=i;
                mini=2134567894567;
                bkt(1);

            }*/
        }
        for (i=1;i<=n;i++)
            cout<<sol[i];
        cout<<'\n';
    }
    return 0;
}
