/**
* user:  talipov-208
* fname: Islam Iliasovich
* lname: Talipov
* task:  Gardening
* score: 100.0
* date:  2021-12-16 08:16:12.735783
*/
//#define _GLIBCXX_DEBUG

#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <string>
#include <numeric>
#include <algorithm>

#define ll long long
#define all(v) v.begin(), v.end()

using namespace std;

const ll INF = 1e15;
const int INFI = 1e9;
const int MOD = 1e9 + 7;


int cmn_k(int n, int m) {
    int lines = min(n, m) / 2 - 1;
    int sq = (max(n, m) - lines * 2) / 2;
    return lines + sq;
}

map<tuple<int, int, int>, vector<vector<int>>> s;

vector<vector<int>> solve(int n, int m, int k) {
    if (s.count({n, m, k})) return s[{n, m, k}];
    int size = n * m;
    int mx_k = size / 4;
    int mn_k = cmn_k(n, m);
    if (size < 0) return {{-1}};
    if (size == 0 && k != 0) return {{-1}};
    if (size == 0) return {{}};
    if (k <= 0) return {{-1}};
    if (n % 2 == 1 || m % 2 == 1) return {{-1}};
    if (k < mn_k || k > mx_k) return {{-1}};
    if (size / 4 == k) {
        vector<vector<int>> res(n, vector<int>(m));
        int c = 1;
        for (int i = 0; i < n; i += 2) {
            for (int j = 0; j < m; j += 2) {
                res[i][j] = res[i + 1][j + 1] = res[i][j + 1] = res[i + 1][j] = c;
                c++;
            }
        }
        s[{n, m, k}] = res;
        return res;
    } else {
        auto prev = solve(n - 2, m - 2, k - 1);
        if (prev != vector<vector<int>>{{-1}} && n > 2 && m > 2) {
            vector<vector<int>> res(n, vector<int>(m));
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < m; ++j) {
                    if (i == 0 || i == n - 1 || j == 0 || j == m - 1) res[i][j] = k;
                    else res[i][j] = prev[i - 1][j - 1];
                }
            }
            s[{n, m, k}] = res;
            return res;
        } else {
            auto hor = solve(n, m - 2, k - n / 2);
            if (hor != vector<vector<int>>{{-1}}) {
                vector<vector<int>> res(n, vector<int>(m));
                int c = k - n / 2 + 1;
                for (int i = 0; i < n; ++i) {
                    for (int j = 0; j < m - 1; ++j) {
                        if (j < m - 2) {
                            res[i][j] = hor[i][j];
                        } else if (res[i][j] == 0 && i + 1 < n) {
                            res[i][j] = res[i + 1][j + 1] = res[i][j + 1] = res[i + 1][j] = c;
                            c++;
                        }
                    }
                }
                s[{n, m, k}] = res;
                return res;
            }
            auto vert = solve(n - 2, m, k - m / 2);
            if (vert != vector<vector<int>>{{-1}}) {
                vector<vector<int>> res(n, vector<int>(m));
                int c = k - m / 2 + 1;
                for (int i = 0; i < n - 1; ++i) {
                    for (int j = 0; j < m; ++j) {
                        if (i < n - 2) {
                            res[i][j] = vert[i][j];
                        } else if (res[i][j] == 0 && j + 1 < m) {
                            res[i][j] = res[i + 1][j + 1] = res[i][j + 1] = res[i + 1][j] = c;
                            c++;
                        }
                    }
                }
                s[{n, m, k}] = res;
                return res;
            }
            s[{n, m, k}] = {{-1}};
            return {{-1}};
        }
    }
}

int main() {
    srand(time(0));
    cin.tie(nullptr);
    ios::sync_with_stdio(false);
    int t;
    cin >> t;
    while (t-- > 0) {
        int n, m, k;
        cin >> n >> m >> k;
//        n = 6;
//        m = rand() % 10 + 1;
//        k = rand() % 20 + 1;
//        cout << n << " " << m << " " << k << "\n";
        auto res = solve(n, m, k);
        if (res == vector<vector<int>>{{-1}}) {
            cout << "NO\n";
        } else {
            cout << "YES\n";
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << res[i][j] << " ";
                }
                cout << "\n";
            }
        }
    }
}