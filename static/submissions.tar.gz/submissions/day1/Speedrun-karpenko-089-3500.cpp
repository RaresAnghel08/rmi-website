/**
* user:  karpenko-089
* fname: Daryna
* lname: Karpenko
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:11:58.189817
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
typedef int ll;

void H3(int subtask, int N, int A[], int B[]) { /* your solution here */
    ll n=N;
    ll d[1007];
    setHintLen(20);
    for(int i=1;i<n;i++){
        ll k=B[i];
        ll h=1;
        while(k>0){
            setHint(A[i],h,k%2);
            k/=2;
            h++;
        }

        k=A[i];
        h=11;
        while(k>0){
            setHint(B[i],h,k%2);
            k/=2;
            h++;
        }
    }
    return ;
}

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    //H1(subtask,N,A,B);
   // H2(subtask,N,A,B);
    H3(subtask,N,A,B);
    return ;
}


void S3(int subtask, int N, int start) { /* your solution here */
    ll l=getLength();
    ll n=N;
    ll h[1007],f[1007];
    for(int i=1;i<=n;i++){
        h[i]=0;
        f[i]=0;
    }
    ll x=start;
    h[x]=x;
    f[0]=1;
    while(1){
        f[x]=1;
        ll a=0;
        ll b=0;
        for(int i=10;i>=1;i--){
            a*=2;
            a+=getHint(i);
        }
        for(int i=20;i>=11;i--){
            b*=2;
            b+=getHint(i);
        }
        if(a==0){
            a=b;
            b=0;
        }
        if(b==0 && x!=start){
            while(h[x]!=x){
                //cout<<x<<endl;
                goTo(h[x]);
                x=h[x];
            }
            break;
        }
        if(f[a]!=1){
            h[a]=x;
            goTo(a);
            x=a;
            f[x]=1;
        }else if(f[b]!=1){
            h[b]=x;
            goTo(b);
            x=b;
            f[x]=1;
        }else break;
    }
    while(1){
        ll a=0;
        ll b=0;
        f[x]=1;
        for(int i=10;i>=1;i--){
            a*=2;
            a+=getHint(i);
        }
        for(int i=20;i>=11;i--){
            b*=2;
            b+=getHint(i);
        }
        if(a==0){
            a=b;
            b=0;
        }
        if(b==0){
            break;
        }
        if(f[a]!=1){
            h[a]=x;
            goTo(a);
            x=a;
            f[x]=1;
        }else if(f[b]!=1){
            h[b]=x;
            goTo(b);
            x=b;
            f[x]=1;
        }else break;
    }
    return ;
}


void speedrun(int subtask, int N, int start) { /* your solution here */
    //S1(subtask, N, start);
    //S2(subtask, N, start);
    S3(subtask, N, start);
    return ;
}
