/**
* user:  chkhaidze-a0b
* fname: George
* lname: Chkhaidze
* task:  Present
* score: 8.0
* date:  2021-12-16 08:39:24.287233
*/
#include <bits/stdc++.h>
#define ll long long
#define pb push_back
using namespace std;

bool f[3000003];
vector < vector < int > > S; 

inline void solve() {
	ll k;
	cin >> k;
	cout << S[k].size() << " ";
	for (int i = 0; i < S[k].size(); ++i) {
		cout << S[k][i] << " ";
	}
	cout << "\n";
}

inline void pre() {
	for (int i = 0; i < (1 << 20); ++i) {
		vector < int > v;
		for (int j = 0; j < 20; ++j) {
			if (i & (1 << j)) {
				v.pb(j + 1);
			}
		}
		
		for (int j = 0; j < v.size(); ++j) {
			f[v[j]] = true;
		}
		
		bool res = true;
		for (int a = 0; a < v.size(); ++a) {
			for (int b = a + 1; b < v.size(); ++b) {
				if (!f[__gcd(v[a], v[b])]) {
					res = false;
					break;
				}
			}
			if (!res) break;
		}
		
		for (int j = 0; j < v.size(); ++j) 
			f[v[j]] = false;
		if (!res) continue;
		S.pb(v);
		v.clear();	
	}
}

main () { 
	ios::sync_with_stdio(false);
	cin.tie(NULL), cout.tie(NULL);
	
	pre();
	
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
}
/*
1 1 2 3 6 9 16 29

0

1 1

2 2
3 1 2

4 3
5 1 3
6 1 2 3

7 4
8 1 4
9 2 4
10 1 2 4
11 1 3 4
12 1 2 3 4

13 5
14 1 5
15 1 2 5
16 1 3 5
17 1 2 3 5
18 1 4 5
19 1 2 4 5
20 1 3 4 5
21 1 2 3 4 5

22 6
23 1 6
24 2 6
25 1 2 6
26 3 6
27 1 3 6
28 1 2 3 6
29 2 4 6
30 1 2 4 6
31 1 2 3 4 6
32 1 5 6
33 1 2 5 6
34 1 3 5 6
35 1 2 3 5 6
36 1 2 4 5 6
37 1 2 3 4 5 6

38 7
39 1 7
40 1 2 7
41 1 3 7
42 1 2 3 7
43 1 4 7
44 1 2 4 7
45 1 3 4 7
46 1 2 3 4 7
47 1 5 7
48 1 2 5 7
49 1 3 5 7
50 1 2 3 5 7
51 1 4 5 7
52 1 2 4 5 7
53 1 3 4 5 7
54 1 2 3 4 5 7
55 1 6 7
56 1 2 6 7
57 1 3 6 7
58 1 2 3 6 7
59 1 2 4 6 7
60 1 2 3 4 6 7
61 1 5 6 7
62 1 2 5 6 7
63 1 3 5 6 7
64 1 2 3 5 6 7
65 1 2 4 5 6 7
66 1 2 3 4 5 6 7

*/
