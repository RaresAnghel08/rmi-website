/**
* user:  vukelic-2d0
* fname: Mateja
* lname: Vukelic
* task:  lucky
* score: 28.0
* date:  2019-10-10 10:29:25.313851
*/
#include <bits/stdc++.h>
#define mod 1000000007
#define pb push_back
using namespace std;
typedef long long ll;
ll dp[10055][20];
int n;
int digit[10505];
int cif[10005];
string x;
int q;
ll resi(int l, int r){
    int m = 0;
    for(int i=l; i<=r; i++)cif[m++] = digit[i];
    ll res = 0;
    int prosla = 0;
    //res += dp[n+1][prosla];
    int maks = 0;
    for(int i=0; i<m; i++){
        int tr = digit[i];
        maks = max(maks, tr);
        for(int j=0; j<tr; j++){
            if(j == 3 && prosla == 1)continue;
            res += dp[n-i][j];
            res %= mod;
        }
        if(tr == 3 && prosla == 1)return res;
        if(i == n-1)res++;
        prosla = tr;
        //res += dp[n-i][prosla];
        //res %= mod;
    }
    if(maks == 0)return 1;
    return res;
}
bool check(int a){
    int prosla = 0;
    while(a>0){
        int tr = a%10;
        a /= 10;
        if(tr == 1 && prosla == 3)return 0;
        prosla = tr;
    }
    return 1;
}
ll broj;
int brut(ll a){
    broj = a;
    int st = 1;
    int res = 0;
    //for(int i=0; i<n; i++)st *= 10;
    for(int i=0; i<=broj; i++){
        if(check(i))res++;
    }
    return res;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin >> n >> q;
    cin >> x;
    for(int i=0; i<n; i++){
        digit[i] = x[i] - '0';
    }
    /*ll st = 1;
    for(int i=n-1; i>=0; i--){
        broj += st*digit[i];
        st *= 10;
    }*/
    for(int j=0; j<10; j++)dp[0][j] = dp[1][j] = 1;
    for(int i=2; i<=10000; i++){
        for(int j=0; j<10; j++){
            for(int k=0; k<10; k++){
                if(j == 1 && k == 3)continue;
                dp[i][j] += dp[i-1][k];
                dp[i][j] %= mod;
            }
        }
    }
    cout << resi(0,n-1) << endl;
    while(q--){
        int t;
        cin >> t;
        int l,r;
        cin >> l >> r;
        l--;
        r--;
        cout << resi(l,r) << endl;
    }
    return 0;
}
