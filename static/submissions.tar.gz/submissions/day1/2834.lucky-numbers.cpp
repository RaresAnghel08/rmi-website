/**
* user:  casarin-262
* fname: Filippo
* lname: Casarin
* task:  lucky
* score: 14.0
* date:  2019-10-10 10:05:09.303386
*/
#include "bits/stdc++.h"

int main() {
	int N, Q;
	scanf("%d %d", &N, &Q);
	char X[100000];
	scanf("%s", X);

	int K = 0;
	for (int i=0; i<N; i++) {
		K *= 10;
		K += X[i] - '0';
	}

	int R=0;
	for (int i=0; i<=K; i++) {
		std::string s = std::to_string(i);
		
		bool ok = true;
		for (int j=0; j+1<s.size() && ok; j++)
			if (s[j] == '1' && s[j+1] == '3')
				ok = false;

		if (ok) R += 1;
	}

	printf("%d\n", R);
}

