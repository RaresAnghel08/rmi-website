/**
* user:  spinei-1ec
* fname: Mihai
* lname: Spinei
* task:  lucky
* score: 14.0
* date:  2019-10-10 07:54:35.856782
*/
#include <bits/stdc++.h>
#define fr first
#define sc second
#define pb push_back
#define ll long long
#define INF 1e9+7
#define LINF 1e18+7
#define pii pair<int,int>


using namespace std;

int n, m;
int X;
int d[10];
int t, p , valid;
int main(){
    cin >> n >> m;
    cin >> X;
    int rez = 0;
    for(int i = 0 ; i <= X ; i++){
        t = i , p = 1 , valid = 1;
        while(t > 0){
            d[p] = t%10;
            if(d[p]==1 && p != 1 && d[p-1]==3)valid = 0;
            t /= 10;
            p++;
        }
        if(valid)rez++;
        for(int i = 1 ; i <= 10 ; i++)d[i] = 0;
    }
    cout << rez;
}
