/**
* user:  saitov-09b
* fname: Damir
* lname: Saitov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:33:49.004348
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
void assignHints(int subtask, int N, int A[], int B[]) {
    if(subtask == 1)
    {
        setHintLen(N);
        bool a[N];
        for(int i = 0; i < N; ++i)
    }
    if(subtask == 2)
    {
        vector <int> used(N + 1,0);
        int f = 1;
        for(int i = 1; i < N; ++i)
        {
            used[A[i]]++;
            if(used[A[i]] == 2)
            {
                f = A[i];
                break;
            }
            used[B[i]]++;
            if(used[B[i]] == 2)
            {
                f = B[i];
                break;
            }
        }
        bitset <10> kek = f;
        setHintLen(10);
        for(int i = 1; i <= N; ++i)
        {
            for(int j = 1; j <= 10; ++j)
            {
                if(kek[j - 1])
                    setHint(i,j,true);
            }
        }
    }
}

void speedrun(int subtask, int N, int start) {
    if(subtask == 1)
    {

    }
    if(subtask == 2)
    {
        int l = getLength();
        int ns = 1;
        int f = 0;
        for(int i = 1; i <= l; ++i)
        {
            f += getHint(i) * ns;
            ns = ns << 1;
        }
        if(start != f)
            goTo(f);
        for(int i = 1; i <= N; ++i)
        {
            goTo(i);
            goTo(f);
        }

    }
}
