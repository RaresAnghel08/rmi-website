/**
* user:  purice-512
* fname: Victor
* lname: Purice
* task:  restore
* score: 0.0
* date:  2019-10-10 09:09:19.337012
*/
#include <bits/stdc++.h>
#define rc(s) return cout << s,0
#define all(s) s.begin(),s.end()
#define int long long
#define fr first
#define sc second
using namespace std;

int n,m,l[5005],r[5005],val[5005],res[5005];
vector<int>ans;

vector<pair<pair<int,int>,pair<int,int>>>curr;


int32_t main(){
    ios_base::sync_with_stdio();cin.tie();cout.tie();
    cin >> n >> m;
 /**  if(n<=18){ for(int i=1;i<=m;i++) cin >> l[i] >> r[i] >> val[i] >> res[i];
    for(int i=0;i<(1<<n);i++){
        int cnt=i;
        int j=0;
        int arr[n+5];
        while(cnt>=1){
            j++;
            arr[j]=(cnt%2);
            cnt/=2;
        }
        j++;
        for(int t=j;t<=n;t++) arr[t]=0;
        bool tr=true;
        for(int t=1;t<=m;t++){
            cnt=0;
            for(int k=l[t]+1;k<=r[t]+1;k++) cnt+=arr[k];
            if(res[t]==1 && val[t]<=(r[t]-l[t]+1-cnt)) tr=false;
            else if(res[t]==0 && val[t]>(r[t]-l[t]+1-cnt)) tr=false;
        }
        if(tr==true){
            for(int t=1;t<=n;t++){
                ans.push_back(arr[t]);
            }
            break;
        }
    }
    if(ans.size()){
        for(int i=0;i<ans.size();i++) cout << ans[i] << ' ';
    }
    else{
        cout << -1 << '\n';
    } } */
        for(int i=1;i<=m;i++){
            int a1,a2,a3,a4;
            cin >> a1 >> a2 >> a3 >> a4;
            curr.push_back({{a4,a3},{a1,a2}});
        }
        sort(all(curr));
        vector<int>ans12(n+5);
        for(int i=1;i<=n;i++) ans12[i]=0;
        for(int i=0;i<m;i++){
            for(int j=curr[i].sc.fr;j<=curr[i].sc.sc;j++){
                if(curr[i].fr.fr==1) ans12[j+1]=1;
                else ans12[j+1]=0;
            }
        }
        bool tr=false;
        for(int i=0;i<m;i++){
            int cnt=0;
            for(int j=curr[i].sc.fr;j<=curr[i].sc.sc;j++){
                cnt+=ans12[j+1];
            }
            if(curr[i].fr.fr==1 && cnt<(curr[i].sc.sc-curr[i].sc.fr+1)) tr=true;
        }
        if(tr==true) cout << -1;
        else{
            for(int i=1;i<=n;i++) cout << ans12[i] << ' ';
        }
}

