/**
* user:  borevkovic-894
* fname: Vlatko
* lname: Borevković
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:36:57.860764
*/
#include<bits/stdc++.h>

#define X first
#define Y second
#define MP make_pair
#define PB push_back
#define ll long long

using namespace std;

const int MAXN=1005;

int x,y,prov;
int bio[MAXN];
int br;
int parent[MAXN];
int djete[MAXN];
int pom;
int zad;
int trn;
int trn1,trn2;
int listp[MAXN];
vector <int> ve[MAXN];

void par(int a, int b){
    pom=a;
    for(int i=11; i<=20; i++){
  //      setHint(b,i,0);
        if(pom%2==1){
   //         setHint(b,i,1);
        }
        pom/=2;
    }
}

void dj(int a, int b){
    pom=b;
    for(int i=1; i<=10; i++){
//        setHint(a,i,0);
        if(pom%2==1){
    //        setHint(a,i,1);
        }
        pom/=2;
    }
}

void gore(int a, int b, int c){
    pom=b;
    for(int i=1; i<=10; i++){
      //  setHint(a,i,0);
        if(pom%2==1){
    //        setHint(a,i,1);
        }
        pom/=2;
    }
    pom=c;
    for(int i=11; i<=20; i++){
//        setHint(a,i,0);
        if(pom%2==1){
    //        setHint(a,i,1);
        }
        pom/=2;
    }
}

int nadip(){
    pom=0;
    trn=1;
    for(int i=11; i<=20; i++){
        if(getHint(i)==1){
            pom+=trn;
        }
        trn*=2;
    }
    return pom;
}

int nadid(){
    pom=0;
    trn=1;
    for(int i=1; i<=10; i++){
        if(getHint(i)==1){
            pom+=trn;
        }
        trn*=2;
    }
    return pom;
}

void assignHints(int subtask, int n, int a[], int b[]){
    setHintLen(20);
    x=1;
    for(int i=1; i<n; i++){
        ve[a[i]].PB(b[i]);
        ve[b[i]].PB(a[i]);
    }
    setHint(1,1,1);
    br=1;
    bio[x]=1;
    zad=-1;
    while(br<n){
        prov=0;
        for(int i=0; i<ve[x].size(); i++){
            y=ve[x][i];
            if(bio[y]==0){
                bio[y]=1;
                br++;
                if(zad!=-1){
                    gore(zad,x,y);
                    zad=-1;
                }
                parent[y]=x;
                par(x,y);
                if(djete[x]==0){
                    djete[x]=y;
                    dj(x,y);
                }
                x=y;
                prov=1;
                break;
            }
        }
        if(prov==0){
            if(ve[x].size()==1){
                zad=x;
            }
            x=parent[x];
        }
    }
}

void speedrun(int subtask, int n, int start){
    x=start;
    br=0;
    memset(bio,0,sizeof(bio));
    while(x!=1){
        y=nadip();
        prov=goTo(y);
        x=y;
        if(prov==0){
            for(int i=1; i<=n; i++){
                if(i!=y){
                    prov=goTo(i);
                    if(prov==1){
                        x=i;
                        break;
                    }
                }
            }
        }
    }
    br=1;
    bio[1]=1;
    while(br<n){
        y=nadid();
        if(bio[y]==0){
            listp[x]=1;
            bio[y]=1;
            br++;
            prov=goTo(y);
            parent[y]=x;
            x=y;
        }
        else{
            if(listp[x]==0){
                trn1=nadid();
                trn2=nadip();
                prov=goTo(parent[x]);
                x=parent[x];
            }
            else{
                if(trn1==x && bio[trn2]==0){
                    y=trn2;
                    bio[y]=1;
                    br++;
                    prov=goTo(y);
                    parent[y]=x;
                    x=y;
                }
                else{
                    prov=goTo(parent[x]);
                    x=parent[x];
                }
            }
        }
    }
}
