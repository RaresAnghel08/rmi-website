/**
* user:  efremov-95c
* fname: Andrei
* lname: Efremov
* task:  restore
* score: 7.0
* date:  2019-10-10 07:35:22.842196
*/
#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <deque>
#include <iomanip>
#include <cassert>
#define rep(i, n) for (int i = 0; i < (n); i++)
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()

using namespace std;
using ll = long long;
using ul = unsigned long long;
using ld = long double;

const int N = 5001;
int mn[N][N], mx[N][N], e1[N], e0[N], a[N], ps[N];

int main() {
#ifdef ONPC
	freopen("a.in", "r", stdin);
#endif
	ios_base::sync_with_stdio(0); cin.tie(0);
	int n, m, l, r, k, d;
	cin >> n >> m;
	vector<vector<int>> q;
	rep(i, m) {
		cin >> l >> r >> k >> d;
		r++;
		q.push_back({l, r, k, d});
	}
	rep(w, 1 << n) {
		rep(i, n) {
			a[i] = (w & (1 << i) ? 1 : 0);
			ps[i + 1] = ps[i] + a[i];
		}
		int f = 1;
		for (auto &pp : q) {
			int cc = ps[pp[1]] - ps[pp[0]];
			if (pp[3] == 0 && cc < pp[2] || pp[3] == 1 && cc >= pp[2]) {
				f = 0;
				break;
			}
		}
		if (f) {
			rep(i, n)
				cout << 1 - a[i] << ' ';
			return 0;
		}
	}
	cout << -1;
}
