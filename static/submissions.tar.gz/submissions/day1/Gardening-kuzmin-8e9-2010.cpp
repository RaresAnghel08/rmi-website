/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:49:57.358786
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

void solve() {
	int n, m, k;
	cin >> n >> m >> k;
	vector<vi> ans(n, vi(m));
	if (n % 2 || m % 2) {
		cout << "NO\n";
		return;
	}
	int mn = 0;
	int x = n, y = m;
	while (x && y) {
		if (x == 2 || y == 2) {
			mn += x * y / 4;
			break;
		} else {
			mn++;
			x -= 2;
			y -= 2;
		}
	}
	int mx = n * m / 4;
	if (k >= mn && k <= mx) {
		int now = mx;
		vector<pii> v;
		int d = 0;
		if (k != mx) {
			while (k < now) {
				int x = 2, y = 2;
				if (v.size()) {
					x = v.back().f + 2;
					y = v.back().s + 2;
				}
				if (x <= n && y <= m) {
					int zm = 1;
					zm -= (2 * x + 2 * y - 4) / 4;
					if (k <= zm + now) {
						now += zm;
						v.pb({x, y});
					} else {
						break;
					}
				} else {
					break;
				}
			}
			for (int i = v.size() - 1; k != now && i >= 0; --i) {
				int x = v[i].f, y = v[i].s;
				int mx = n, my = m;
				if (i != v.size() - 1) {
					mx = v[i + 1].f - 2, my = v[i + 1].s - 2;
				}
				int cnt = (mx - x) / 2 + (my - y) / 2;
				if (now - cnt >= k) {
					v[i] = {mx, my};
					now -= cnt;
				} else {
					if ((mx - x) / 2 <= now - k) {
						now -= (mx - x) / 2;
						v[i].f += mx;
						v[i].s += (now - k) * 2;
					} else {
						v[i].f += (now - k) * 2;
						now = k;
					}
				}
			}
			if (k != now) {
				cout << "NO\n";
				return;
			}
			
		}
		cout << "YES\n";
		int it = 1;
		int l = 0, r = 0;
		for (int i = v.size() - 1; i >= 0; --i) {
			for (int k = 0; k < v[i].f; ++k) {
				ans[l + k][r] = ans[l + k][r + v[i].s - 1] = it;
			}
			for (int k = 0; k < v[i].s; ++k) {
				ans[l][r + k] = ans[l + v[i].f - 1][r + k] = it;
			}
			l++;
			r++;
			
			it++;
		}
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < m; ++j) {
				if (ans[i][j] ==0) {
					ans[i][j] = ans[i + 1][j] = ans[i][j + 1] = ans[i + 1][j + 1] = it;
					it++;
				}
			}
		}
		for (auto &i : ans) {
			for (auto &j : i) {
				cout << j << ' ';
			}
			cout << endl;
		}
	} else {
		cout << "NO\n";
	}
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	cin >> t;
	while (t--)
		solve();
}