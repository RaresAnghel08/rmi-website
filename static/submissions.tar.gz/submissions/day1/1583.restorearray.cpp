/**
* user:  petkov-737
* fname: Georgy
* lname: Petkov
* task:  restore
* score: 7.0
* date:  2019-10-10 07:10:33.161827
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXM = 10003;

int n, m;
struct restriction
{
	int l, r, k, val;
};

restriction q[MAXM];
void read()
{
	cin >> n >> m;

	for (int i = 1; i <= m; i++)
	{
		cin >> q[i].l >> q[i].r >> q[i].k >> q[i].val;
		q[i].l++;
		q[i].r++;
	}
}

void solve()
{
		for (int mask = 0; mask < (1 << n); mask++)
		{
			int cnt[20];
			memset(cnt, 0, sizeof(cnt));

			for (int j = 1; j <= n; j++)
			{
				cnt[j] = cnt[j-1];

				if (mask & (1 << (j - 1)))
					cnt[j]++; 
			}

			bool can = true; 
			for (int i = 1; i <= m; i++)
			{
				int cnt_0 = cnt[q[i].r] - cnt[q[i].l-1];

				if (q[i].val == 0)
					if (cnt_0 < q[i].k)
					{
						can = false;
					    break;	
					}

				if (q[i].val == 1)
					if (cnt_0 >= q[i].k)
					{
						can = false;
						break; 
					}
			}

			if (can)
			{
				for (int j = 1; j <= n; j++)
				{
					if (mask & (1 << (j - 1)))
						cout << 0 << " ";

					else 
						cout << 1 << " ";
				}

				cout << endl;
				return; 
			}
		}

		cout << -1 << endl;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	read();
	solve();
}
