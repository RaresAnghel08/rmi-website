/**
* user:  todorov-dbc
* fname: Andon
* lname: Todorov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:49:33.832424
*/
#include <bits/stdc++.h>
#include "speedrun.h"
#include "grader.cpp"
using namespace std;

int N, par [1024];
vector <int> adj [1024];

int dfs1 (int a){
    int lastVisited = a;
    for (int i : adj [a]){
        if (i == par [a]) continue;
        for (int k = 0; k < 10; k ++){
            setHint (lastVisited, k + 1, (i >> k) & 1);
        }
        par [i] = a;
        for (int k = 0; k < 10; k ++){
            setHint (i, k + 11, (a >> k) & 1);
        }
        lastVisited = dfs1 (i);
    }
    return lastVisited;
}

int dfs2 (int a){
    int adj1 = 0, adj2 = 0;
    for (int k = 0; k < 10; k ++){
        adj1 += (getHint (k + 1) << k);
    }
    for (int k = 0; k < 10; k ++){
        adj2 += (getHint (k + 11) << k);
    }
    while (goTo (adj1)){
        adj1 = dfs2 (adj1);
    }
    if (adj2) goTo (adj2);
    return adj1;
}

void assignHints (int subtask, int n, int a [], int b []){

    setHintLen (20);
    for (int i = 1; i < n; i ++){
        adj [a [i]].push_back (b [i]);
        adj [b [i]].push_back (a [i]);
    }
    dfs1 (1);

}

void speedrun (int subtask, int n, int start){

    dfs2 (start);

}
