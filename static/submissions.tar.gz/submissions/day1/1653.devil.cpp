/**
* user:  bengin-61a
* fname: Jovan
* lname: Bengin
* task:  devil
* score: 0.0
* date:  2019-10-10 07:25:08.300049
*/
#include <bits/stdc++.h>
using namespace std;

int cnt[10];

int k;
int sum;
int n;
int niz[1000005];

typedef long long ll;

void solve(){
    cin >> k;
    n = 0;
    for(int i=1; i<=9; i++){
        cin >> cnt[i];
        n += cnt[i];
    }
    int mx = 0;
    for(int i=9; i>=1; i--){
        if(cnt[i]){
            mx = i;
            break;
        }
    }
    if(n == 1){
        cout << mx << "\n";
        return;
    }
    if(cnt[mx] == 1){
        cnt[mx] = 0;
        niz[n] = mx;
        while(!cnt[mx]) mx--;
        for(int i=1; i<n; i++) niz[i] = 0;
        for(int i=1; i<n; i+=2){
            niz[i] = mx;
            cnt[mx]--;
            if(!cnt[mx]) break;
        }
        mx = 1;
        for(int i=1; i<n; i++){
            if(!niz[i]){
                while(!cnt[mx]) mx++;
                cnt[mx]--;
                niz[i] = mx;
            }
        }
    }
    else{
        for(int i=1; i<=n; i++) niz[i] = 0;
        for(int i=n; i>=1; i-=2){
            niz[i] = mx;
            cnt[mx]--;
            if(!cnt[mx]) break;
        }
        mx = 1;
        for(int i=n; i>=1; i--){
            if(!niz[i]){
                while(!cnt[mx]) mx++;
                cnt[mx]--;
                niz[i] = mx;
            }
        }
    }
    for(int i=1; i<=n; i++) cout << niz[i];
    cout << "\n";
}

int main(){

    int t;
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
