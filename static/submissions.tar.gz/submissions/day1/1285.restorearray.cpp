/**
* user:  malinin-a1f
* fname: Stoyan
* lname: Malinin
* task:  restore
* score: 0.0
* date:  2019-10-10 06:08:03.446774
*/
#include<iostream>
#include<vector>

using namespace std;

const int MAXN = 5005;

struct requirement
{
    int l, r, k, val;
};

int n, m;
vector <requirement> v;

int answer[MAXN];

int cnt0(int l, int r)
{
    int cnt = 0;
    for(int i = l;i<=r;i++)
    {
        if(answer[i]==0) cnt++;
    }

    return cnt;
}

int cnt1(int l, int r)
{
    int cnt = 0;
    for(int i = l;i<=r;i++)
    {
        if(answer[i]==1) cnt++;
    }

    return cnt;
}

bool check(bool mode)
{
    for(int i = 0;i<m;i++)
    {
        if(v[i].val==0)
        {
            if(cnt0(v[i].l, v[i].r)<v[i].k) return false;
        }

        if(v[i].val==1 && mode==true)
        {
            if(cnt0(v[i].l, v[i].r)>=v[i].k) return false;
        }
    }

    return true;
}

bool checkInd(int index)
{
    for(int i = 0;i<m;i++)
    {
        if(v[i].l>index) continue;

        if(v[i].val==1)
        {
            if(cnt0(v[i].l, v[i].r)>=v[i].k) return false;
        }
    }

    return true;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n >> m;
    for(int i = 0;i<m;i++)
    {
        int l, r, k, val;
        cin >> l >> r >> k >> val;

        v.push_back({l, r, k, val});
    }

    for(int i = 0;i<n;i++)
    {
        if(checkInd(i)==true) continue;

        answer[i] = 1;
        if(check(false)==false)
        {
            answer[i] = 0;
        }
    }

    if(check(true)==false)
    {
        cout << "-1" << '\n';
        return 0;
    }

    for(int i = 0;i<n;i++) cout << answer[i] << " ";
    cout << '\n';
}
/*
4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0
*/
