/**
* user:  haivas-4ca
* fname: Vlad
* lname: Haivas
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 09:46:45.038740
*/
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debug(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast", "unroll-loops")
#include "speedrun.h"

using namespace std;
typedef long long ll;
typedef pair <int, int> pii;

const int NMAX = 1001;
const int nr_of_bits = 9;
const int INF = 2e9;
const int MOD = 1000000007;

vector <int> v[NMAX];
int parent[NMAX];

void assignHints(int subtask, int N, int A[], int B[])   /* your solution here */
{
    for(int i = 1; i < N; i++)
    {
        v[A[i]].push_back(B[i]);
        v[B[i]].push_back(A[i]);
    }
    setHintLen(20);
    for(int i = 1; i <= N; i++)
    {
        int act = 1;
        for(auto x : v[i]){
            for(int j = 0; j <= nr_of_bits; j++){
                if(x & (1 << j))
                    setHint(i, act, 1);
                act++;
            }
        }
    }
}

int vi[NMAX];
int pp[NMAX];

void speedrun(int subtask, int N, int start)   /* your solution here */
{
    int p = 0, nr = 0;
    int vizite = 0;
    for(int i = 1; i <= N; i++)
    {
        v[i].clear();
    }
    while(nr != N)
    {
        vizite++;
        if(vizite > (2 * N + 1))
            break;
        if(!vi[start])
            nr++;
        if(nr == N)
            break;
        int gasit = 0;
        if(vi[start])
        {
            for(auto i : v[start])
            {
                if(vi[i]) continue;
                pp[i] = start;
                start = i;
                goTo(start);
                gasit = 1;
                break;
            }
        }else{
            vi[start] = 1;
            int vecin1 = 0;
            int vecin2 = 0;
            for(int i = 1; i <= nr_of_bits + 1; i++){
                if(getHint(i)){
                    vecin1 |= (1 << (i - 1));
                }
            }
            for(int i = 1; i <= nr_of_bits + 1; i++){
                if(getHint(nr_of_bits + 1 + i)){
                    vecin2 |= (1 << (i - 1));
                }
            }
            if(vecin1)
            v[start].push_back(vecin1);
            if(vecin2)
            v[start].push_back(vecin2);
            for(auto i : v[start])
            {
                if(vi[i]) continue;
                pp[i] = start;
                start = i;
                goTo(start);
                gasit = 1;
                break;
            }
        }
        if(gasit)
            continue;
        start = pp[start];
        goTo(start);
    }
}

