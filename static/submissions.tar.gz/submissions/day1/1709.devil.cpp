/**
* user:  oparlakov-daf
* fname: Dimitar
* lname: Oparlakov
* task:  devil
* score: 0.0
* date:  2019-10-10 07:35:14.956921
*/
#include <iostream>
#include <cstdio>
using namespace std;

int t, k, dig[10];
int fl;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    scanf("%d", &t);

    for(int x=0; x<t; x++)
    {
        scanf("%d", &k);

        string ans = "", digs = "";
        fl = 0;
        int cur = 0;

        for(int i=1; i<=9; i++)
        {
            scanf("%d", &dig[i]);

            for(int j=0; j<dig[i]; j++)
                digs += char(i + '0');
        }

        for(int i=9; i>=1; i--)
        {
            if(dig[i] == 0) continue;

            if(fl == 0 && dig[i] == 1)
            {
                ans = char(i + '0');
                dig[i]--;
                fl = 1;
            }
            else if(fl == 0 && dig[i] > 1)
            {
                ans += char(i + '0');
                dig[i]--;

                while(dig[i] > 0)
                {
                    if((digs[cur] - '0') != i)
                    {
                        ans = digs[cur] + ans;
                        dig[digs[cur++] - '0']--;
                    }
                    ans = char(i + '0') + ans;
                    dig[i]--;
                }
                fl = 2;
            }
            else if(fl == 1)
            {
                while(dig[i] > 0)
                {
                    if((digs[cur] - '0') != i)
                    {
                        ans = digs[cur] + ans;
                        dig[digs[cur++] - '0']--;
                    }
                    ans = char(i + '0') + ans;
                    dig[i]--;
                }
                fl = 2;
            }
            else if(fl == 2)
            {
                for(int j = 0; j<dig[i]; j++)
                    ans = char(i + '0') + ans;
            }

        }
        cout << ans << endl;
    }

    return 0;
}
