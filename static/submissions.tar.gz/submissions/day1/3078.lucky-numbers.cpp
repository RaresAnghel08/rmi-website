/**
* user:  nagy-e76
* fname: Nándor
* lname: Nagy
* task:  lucky
* score: 28.0
* date:  2019-10-10 10:29:12.712385
*/
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll mod = 1000000007LL;

ll dp[20][10];

int main()
{
    ll n, q;
    ll x[20];
    cin>>n>>q;
    for(int i=0;i<n;i++) {
        char c;
        cin>>c;
        x[i] = (ll)(c-'0');
    }
    ll sol = 0;
    for(int j=0;j<=9;j++) {
        dp[1][j] = 1LL;
    }
    for(int i=2;i<=n;i++) {
        for(int j=0;j<=9;j++) {
            for(int ne=0;ne<=9;ne++)  {
                if(j != 1 || ne != 3) {
                    dp[i][j] += dp[i-1][ne];
                    dp[i][j] = dp[i][j] % mod;
                }
            }
        }
    }
    bool th = false;
    bool muk = true;
    for(int i=0;i<n && muk;i++) {
        for(int fe = 0; fe < x[i];fe++) {
            if(!(fe == 3 && th)) sol += dp[n-i][fe];
        }
        if(i > 0 && x[i-1]==1LL && x[i] == 3LL) {
            muk = false;
        }
        th = (x[i] == 1);
        sol = sol % mod;
    }
    if(muk) sol++;
    cout<<sol<<endl;
    return 0;
}
