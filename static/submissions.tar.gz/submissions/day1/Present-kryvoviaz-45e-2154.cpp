/**
* user:  kryvoviaz-45e
* fname: Illia
* lname: Kryvoviaz
* task:  Present
* score: 8.0
* date:  2021-12-16 09:05:20.608053
*/
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
int gcd(int a, int b) {
    while (true) {
        if (a == 0)return b;
        if (b == 0)return a;
        if (a > b)a %= b;
        else b %= a;
    }
}
vector<vector<int> > All;

vector<int> now;
bool ok() {
    if (now.size() == 1)return true;
    for (int i = 0; i < now.size(); i++) {
        for (int j = 0; j < now.size(); j++) {

            bool ok = false;
            for (int k = 0; k < now.size(); k++) {
                if (now[k] == gcd(now[i], now[j])){ok = true;break;}
            }
            if (!ok)return false;
        }
    }
    return true;
}

void rec(int lst, int depth) {
    if (depth <= 0) {
        if (ok()) {
            All.push_back(now);
        }
        return;
    }
    for (int id = lst + 1; id <= 15; id++) {
        now.push_back(id);
        rec(id, depth - 1);
        now.pop_back();
    }
}

int MX(vector<int> &a) {
    int mx = -1010101010;
    for (int i : a)
        mx = max(mx, i);
    return mx;
}

int main()
{
    for (int len = 1; len <= 30; len++) {
        rec(0, len);
    }
    sort(All.begin(), All.end(), [](vector<int> q, vector<int> w) {
         for (int i = 1;; i++) {
            if ((int)q.size() - i < 0)return true;
            if ((int)w.size() - i < 0)return false;

            if (q[(int)q.size() - i] < w[(int)w.size() - i])return true;
            if (q[(int)q.size() - i] > w[(int)w.size() - i])return false;
         }
    });
    /*for (int i = 0; i < 100; i++) {
        cout << i << " ----- ";
        for (int j = 0; j < All[i].size(); j++)
            cout << All[i][j] << " ";
        cout << endl;
    }*/
    int t;
    cin >> t;
    while (t--) {
        int x;
        cin >> x;
        if (x == 0){cout << "0\n";continue;}
        x--;
        cout << All[x].size();
        for (int i = 0; i < All[x].size(); i++)
            cout << " " << All[x][i];
        cout << endl;
    }
    return 0;
}
/**
*/
