/**
* user:  lukachik-dc4
* fname: Vladislav
* lname: Lukachik
* task:  Gardening
* score: 11.0
* date:  2021-12-16 08:42:24.505047
*/
#include<bits/stdc++.h>
using namespace std;

void solve() {
    int n, m, k;
    cin >> n >> m >> k;
    vector<vector<int>> ans(n, vector<int>(m, 0));
    if (n % 2 == 1 || m % 2 == 1) {
        cout << "NO\n";
        return;
    }
    if (k > n * m / 4) {
        cout << "NO\n";
        return;
    }
    if (n == 2) {
        if (m / 2 == k) {
            cout << "YES\n";
            for (int i = 0; i < m; ++i) {
                cout << i / 2 + 1 << " ";
            }
            cout << "\n";
            for (int i = 0; i < m; ++i) {
                cout << i / 2 + 1 << " ";
            }
            cout << "\n";
        } else {
            cout << "NO\n";
        }
        return;
    }
    int t = k - m / 2;
    //cout << t << endl;
    if (0 <= t && t <= m / 2 && t != m / 2 - 1) {
        cout << "YES\n";
        int nc = 1;
        for (int j = 0; j < t * 2; j += 2) {
            ans[0][j] = ans[1][j] = ans[0][j + 1] = ans[1][j + 1] = nc;
            nc++;
            ans[2][j] = ans[3][j] = ans[2][j + 1] = ans[3][j + 1] = nc;
            nc++;
        }
        for (int j = t * 2; j < m; j += 2) {
            ans[0][j] = k;
            ans[3][j] = k;
            ans[0][j + 1] = k;
            ans[3][j + 1] = k;
            if (j == t * 2) {
                ans[1][j] = ans[2][j] = k;
                ans[1][j + 1] = ans[2][j + 1] = nc;
            } else if (j == m - 2) {
                ans[1][j] = ans[2][j] = nc;
                nc++;
                ans[1][j + 1] = ans[2][j + 1] = k;
            } else {
                ans[1][j] = ans[2][j] = nc;
                nc++;
                ans[1][j + 1] = ans[2][j + 1] = nc;
            }
        }
        for (auto it : ans) {
            for (auto x : it) {
                cout << x << " ";
            }
            cout << "\n";
        }
        return;
    }
    cout << "NO\n";
}

int32_t main() {
    #ifdef LOCAL
    freopen("input.txt", "r", stdin);
    #endif // LOCAL
    cin.tie(0);
    ios_base::sync_with_stdio(0);
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
