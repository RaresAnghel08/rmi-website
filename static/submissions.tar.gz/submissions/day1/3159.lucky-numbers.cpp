/**
* user:  mordecki-e78
* fname: Marcin
* lname: Mordecki
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:35:59.738395
*/
#include <bits/stdc++.h>
using namespace std;
typedef unsigned uns;
typedef long long lld;
typedef pair<int,int> pii;
typedef pair<lld,lld> pll;
typedef complex<double> cd;
typedef vector<cd> vcd;
typedef double lf;
typedef long double llf;
typedef pair<lf,lf> pff;
#define ff first
#define dd second
#define mp make_pair
#define pb push_back
#define sz size()
#define For(i,s,a) for(lld i = (lld)s;i<(lld)a;++i)
#define rpt(S,it) for(auto it=S.begin();it=S.end();++it)

inline void scan(int *i);
inline void scanll(int *i);
inline void scanu(int *i);
inline void print(int x);

const lld mod = 1e9+7;
const int N = 1e5+1;
#define m(x) (x>=mod?x%mod:x)
lld hdp[2][N];
lld dp[N];
char s[N];

void chp(){
	hdp[0][0]=1;
	hdp[0][1]=8;
	hdp[1][1]=1;
	hdp[1][0]=0;
	For(i,2,N){
		hdp[0][i]=(((lld)hdp[0][i-1]*9ll)%mod+((lld)hdp[1][i-1]*8ll  )%mod)%mod;
		hdp[1][i]=((lld)hdp[0][i-1]+(lld)hdp[1][i-1])%mod;
	}
}

lld get(lld a){
	if(a<0)return 0;
	return dp[a];
}

lld cdp(int p, int k){
	lld a1 = dp[k-p-1];
	lld sum=0;
	lld x;
	lld broke=0;
	For(i,p,k){
		if(i-p>0 && s[i]=='3' && s[i-1]=='1')break;
		x=s[i]-'0';
		//cout<<k-i-1<<" "<<(x-1+1-(x-1>=1)-(!broke))<<" "<<get(k-i-1)<<"   "<<(x>1)<<"   "<<(get(k-i-2)*8+get(k-i-3)*2)<<endl;
		sum=m(( sum+ (x-1+1-(x-1>=1)-(!broke))*(get(k-i-1)) + 
		(x>1)*((get(k-i-2)*9ll)-get(k-i-3) )));
		broke=max(broke,x);
		//cout<<sum+a1<<endl;
		if(i==k-1 && x==0)++sum;
		if(i==k-1 && x>0)++sum;
		if(i==k-1 && x>1)++sum;
	}
	return sum+a1;
}

int main(){
	int ct = 0;
	For(i,0,220001){
		int x=i;
		int xd = 0;
		while(x){
		if(x%10==3 && (x/10)%10==1){xd=1;break;}
		x/=10;
		}
		++ct;
		ct-=xd;
	}
	//cout<<ct<<endl;
	chp();
	dp[0]=1;
	For(i,1,N+1)
	dp[i]=dp[i-1]+hdp[0][i]+hdp[1][i],
	dp[i]%=mod;
	//For(i,1,10+1)cout<<dp[i]<<" ";puts("");
	//For(i,0,7)cout<<hdp[0][i]<<" "<<hdp[1][i]<<endl;
	//cout<<ct<<endl;
	int n,t;
	scanf("%d",&n);scanf("%d",&t);
	scanf("%s",s);
	printf("%lld\n",cdp(0,n));
	while(t--){
		int typ, a,b;
		scanf("%d%d%d", &typ,&a,&b);
		if(typ==2){
			--a;
			s[a]=b+'0';
		}
		else
		printf("%lld\n",cdp(a-1,b));
	}
}







 

inline void scan(int *i){
	int t = 0;
	char z = 'a';
	bool neg = 0;
	while((z<'0') || (z>'9')){if(z=='-')neg=1;z=getchar_unlocked();}
	while((z>='0') && (z<='9')){t=((t<<3ll)+(t<<1ll)+z-'0');z=getchar_unlocked();}
	if(neg)t=(~(t-1));
	*i=t;
}

inline void scanll(lld *i){
	lld t = 0;
	char z = 'a';
	bool neg = 0;
	while((z<'0') || (z>'9')){if(z=='-')neg=1;z=getchar_unlocked();}
	while((z>='0') && (z<='9')){t=((t<<3ll)+(t<<1ll)+z-'0');z=getchar_unlocked();}
	if(neg)t=(~(t-1));
	*i=t;
}

inline void scanu(uns *i){
	uns t = 0;
	char z = 'a';
	while((z<'0') || (z>'9')){z=getchar_unlocked();}
	while((z>='0') && (z<='9')){t=((t<<3ll)+(t<<1ll)+z-'0');z=getchar_unlocked();}
	*i=t;
}


//repair
inline void print(int x){
	if(x==0){putchar_unlocked('0');return;}
	short stos[18],_end=0,help,help2;
	while(x){
		help=x;
		help>>=1;
		help/=5;
		help2=(help<<3ll)+(help<<1ll);
		stos[++_end]=help2;
		x=help;
	}
	while(_end)putchar_unlocked(stos[_end]+'0'),--_end;
}
