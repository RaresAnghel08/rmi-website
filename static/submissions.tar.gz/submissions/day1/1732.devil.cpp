/**
* user:  apostol-c2d
* fname: Daniel
* lname: Apostol
* task:  devil
* score: 0.0
* date:  2019-10-10 07:38:23.123254
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define pb push_back
#define get_here cerr << "-1\n"
#define dbg(x) cerr << #x << " " << x << "\n"

int n, k;

int d[10];
const int N = 1e5;
int ans[1 + N];

void solve_3 () {
    if (d[1] > d[2]) {
        while (d[1] || d[2]) {
            if (d[1] > d[2]) {
                cout << "1";
                d[1]--;
            }
            if (d[1]) {
                d[1]--;
                cout << "1";
            }
            if (d[2]) {
                d[2]--;
                cout << "2";
            }
        }
    }
    else {
        while (d[1] || d[2]) {
            int dd = d[1];
            if (d[1]) {
                d[1]--;
                cout << "1";
            }
            if (dd < d[2]) {
                cout << "2";
                d[2]--;
            }
            if (d[2]) {
                d[2]--;
                cout << "2";
            }
        }
    }
}

void solve () {
    cin >> k;
    n = 0;
    for (int i = 1; i <= 9; i++)
        cin >> d[i], n += d[i];
    if (n == d[1] + d[2]) {
        solve_3 ();
        return;
    }
    // good ->
    int big = 9;
    for (int i = n; i > n - k + 1; i--) {
        while (d[big] == 0)
            big--;
        d[big]--;
        ans[i] = big;
    }
   /* int small = 1;
    while (d[small] == 0)
        small++;
    ans[n - k + 1] = small;
    d[small]--;*/
    /*lft = n - k + 1;
    for (int sz = 1; sz <= lft; sz++) {
        for (int i = 1; i <= n; i++) {

        }
    }*/
    // <-
   // for (int i = 1; i <= n; i++)
    for (int i = 1; i <= n; i++)
        cout << ans[i];
    cout << "\n";
}

int main () {
    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);
   // freopen ("devil.in", "r", stdin);
    //freopen ("devil.out", "w", stdout);
    int t;
    cin >> t;
    while (t--)
        solve ();
    return 0;
}
