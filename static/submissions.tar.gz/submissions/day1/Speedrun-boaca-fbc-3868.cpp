/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:43:29.784311
*/
#include <bits/stdc++.h>
#include "speedrun.h"
//#include "grader.cpp"
typedef pair<int,int> pii;
int parent[1005],nr[1005],nodes[1005][1005],l[1005];
void calc(int nod,int par)
{
    nr[nod]=1;
    for(int i=1;i<=l[nod];i++)
        if(nodes[nod][i]!=par)
        {
            calc(nodes[nod][i],nod);
            nr[nod]+=nr[nodes[nod][i]];
        }
}
void assignHints(int subtask, int N, int A[], int B[])
{
    int n=N;
    setHintLen(40);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            if(A[j]==i||B[j]==i)
                nodes[i][++l[i]]=(i^A[j]^B[j]);
    for(int i=1;i<=n;i++)
    {
        calc(i,0);
        pii s[1005];
        for(int j=1;j<=l[i];j++)
        {
            int nod=nodes[i][j];
            s[j]={nr[nod],nod};
        }
        sort(s+1,s+l[i]+1);
        int p=0;
        int b[5];
        for(int j=1;j<=4;j++)
            b[j]=0;
        int j=l[i];
        while(j>0&&p<4)
        {
            pii it=s[j];
            p++;
            b[p]=it.second;
            j--;
        }
        int m=0;
        for(int j=1;j<=4;j++)
        {
            for(int bit=9;bit>=0;bit--)
            {
                m++;
                if((b[j]>>bit)&1)
                    setHint(i,m,1);
                else
                    setHint(i,m,0);
            }
        }
    }
}
bool use[1005];
void dfs(int nod,int par,int N)
{
    int n=N;
    use[nod]=1;
    int nr=0;
    for(int i=1;i<=10;i++)
        nr=nr*2+getHint(i);
    if(nr!=0&&nr!=par)
    {
        goTo(nr);
        dfs(nr,nod,N);
    }
    nr=0;
    for(int i=11;i<=20;i++)
        nr=nr*2+getHint(i);
    if(nr!=0&&nr!=par)
    {
        goTo(nr);
        dfs(nr,nod,N);
    }
    nr=0;
    for(int i=21;i<=30;i++)
        nr=nr*2+getHint(i);
    if(nr!=0&&nr!=par)
    {
        goTo(nr);
        dfs(nr,nod,N);
    }
    nr=0;
    for(int i=31;i<=40;i++)
        nr=nr*2+getHint(i);
    if(nr!=0&&nr!=par)
    {
        goTo(nr);
        dfs(nr,nod,N);
    }
    int nodes[1005];
    int lg=0;
    for(int i=1;i<=n;i++)
        if(!use[i])
        {
            bool ok=goTo(i);
            if(ok)
            {
                nodes[++lg]=i;
                goTo(nod);
            }
        }
    for(int i=1;i<=lg;i++)
        if(nodes[i]!=par&&!use[nodes[i]])
        {
            goTo(nodes[i]);
            dfs(nodes[i],nod,N);
        }
    if(par!=0)
        goTo(par);
}
void speedrun(int subtask, int N, int start)
{
    int l=getLength();
    dfs(start,0,N);
}
