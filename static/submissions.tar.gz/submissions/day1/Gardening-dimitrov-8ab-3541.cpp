/**
* user:  dimitrov-8ab
* fname: Atanas
* lname: Dimitrov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:16:13.694701
*/
#include <bits/stdc++.h>
#pragma GCC target("sse4")
using namespace std;
typedef long long ll;
#define endl "\n"
template<class T, class T2> bool chkmin(T &a, const T2 &b) {return (a > b) ? a = b, 1 : 0;}
template<class T, class T2> bool chkmax(T &a, const T2 &b) {return (a < b) ? a = b, 1 : 0;}
#ifndef LOCAL
#define cerr if(false)cerr
#endif // LOCAL

const int MAX_N = 50;
short gcd[MAX_N][MAX_N];
int k;
bool used[MAX_N];

vector<short> vec;
vector<short> indep;
int cnt = 0;

void dfs(int bound) {
    cout << cnt << ":" << endl;
    auto cpy = vec;
    sort(cpy.begin(), cpy.end());
    cout << vec.size() << " -> ";
    for(auto it : cpy) {
        cout << it << " ";
    }
    cout << endl;
    cpy = indep;
    sort(cpy.begin(), cpy.end());
    cout << indep.size() << " -> ";
    for(auto it : cpy) {
        cout << it << " ";
    }
    cout << endl;
    cout << endl;

    if(cnt == k) {
        cnt ++;
        return;
    }
    cnt ++;
    for(int i = 1; i <= bound; i ++) {
        if(used[i]) {continue;}
        short bot = vec.size();
        vec.push_back(i);
        indep.push_back(i);
        used[i] = true;
        for(int j = 0; vec[j] != i; j ++) {
            auto it = vec[j];
            if(!used[gcd[i][it]]) {
                vec.push_back(gcd[i][it]);
                used[gcd[i][it]] = true;
            }
        }
        dfs(i - 1);
        while(vec.size() != bot) {
            used[vec.back()] = false;
            vec.pop_back();
        }
        indep.pop_back();
        if(cnt > k) {break;}
    }
}

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

    for(int i = 1; i < MAX_N; i ++) {
        for(int j = 1; j < MAX_N; j ++) {
            gcd[i][j] = __gcd(i, j);
        }
    }

    k = 30;
    dfs(50);

    return 0;
}

