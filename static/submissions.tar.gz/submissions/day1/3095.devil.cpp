/**
* user:  babin-1c1
* fname: Claudiu
* lname: Babin
* task:  devil
* score: 0.0
* date:  2019-10-10 10:30:51.493880
*/
//# pragma GCC optimize("O3")
//# pragma GCC optimize("unroll-loops,avx2,avx,sse,sse3")
# include "bits/stdc++.h"
# include "ext/pb_ds/assoc_container.hpp"
# include "ext/pb_ds/tree_policy.hpp"
# define ll long long
# define mp make_pair
# define pb push_back
# define _ ios_base::sync_with_stdio(0);cin.tie(0);
# define clock (clock() * 1000.0 / CLOCKS_PER_SEC)
# define rc(x) return cout << x,0
# define sz(x) (int)(x.size())
# define db(x) cerr << #x << "= " << x << '\n'
std::pair<int,int>DR[] = {{0,1},{0,-1},{1,0},{-1,0},{1,-1},{1,1},{-1,1},{-1,-1}};
using namespace std;
using namespace __gnu_pbds;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
template <class T> using Tree = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

vector<int>ans;
int t,k,d[15];

void solve(){
	vector<int>vec;
	for(int i = 1;i < 10;i++){
		while(d[i]--){
			vec.pb(i);
		}
	}
	ans.clear();
	ans.pb(vec.back());
	vec.pop_back();
	int r = sz(vec) - 1;
	int l = 0;
	while(l <= r){
		if(l == r){
			ans.pb(l);
			return ;
		}
		ans.pb(vec[l]);
		ans.pb(vec[r]);
		l++;
		r--;
	}
}

int32_t main(){_
	cin >> t;
	while(t--){
		cin >> k;
		for(int i = 1;i < 10;i++) cin >> d[i];
		solve();
		reverse(ans.begin(),ans.end());
		for(auto it : ans) cout << it << ' ';
	}
	return 0;
}

