/**
* user:  chivu-423
* fname: Razvan
* lname: Chivu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:40:09.952158
*/
#include <iostream>

using namespace std;

int main()
{
    int t;
    cin >> t;
    for(int i = 0; i < t; i++){
        int m, n, k;
        cin >> m >> n >> k;
        if(m == 1 && n == 1)
            cout << "NO";
        else if(m == 1 || n == 1)
            cout << "NO";
        else if(n == 3 || m == 3)
            cout << "NO";
        else if(n == 2 && m == 2 && k ==1)
                cout << "YES" << "\n" << "1 1" << "\n" << "1 1";
        else{
            if(n == 4 && m == 4){
                if(k == 2){
                    cout << "YES" << "\n";
                    cout << "1 1 1 1" << "\n";
                    cout << "1 2 2 1" << "\n";
                    cout << "1 2 2 1" << "\n";
                    cout << "1 1 1 1" ;
                }else if(k == 4){
                    cout << "YES" << "\n";
                    cout << "1 1 2 2" << "\n";
                    cout << "1 1 2 2" << "\n";
                    cout << "3 3 4 4" << "\n";
                    cout << "3 3 4 4" ;
                }
            }

            if(n == 2 && m == 4 && k == 2){
                cout << "YES" << "\n";
                cout << "1 1 2 2" << "\n";
                cout << "1 1 2 2";
            }else if(n == 4 && m == 2 && k == 2){
                cout << "YES" << "\n";
                cout << "1 1" << "\n";
                cout << "1 1" << "\n";
                cout << "2 2" << "\n";
                cout << "2 2";
            }else{
                cout << "NO";
            }
        }
        cout << "\n";
    }

    return 0;
}
