/**
* user:  musat-50e
* fname: Tiberiu Ioan
* lname: Mușat
* task:  devil
* score: 13.0
* date:  2019-10-10 06:59:51.098051
*/
#include <iostream>
#include <algorithm>

using namespace std;

const int MAX_S = 1e5;
int v[MAX_S];
int f[10];

char s[MAX_S + 1];

int main() {
    int t;
    for (cin >> t; t > 0; t--) {
        int k, n = 0;
        cin >> k;
        for (int i = 1; i < 10; i++) {
            cin >> f[i];
            while (f[i] > 0) {
                v[n++] = i;
                f[i]--;
            }
        }

        if (n <= 12) {

            long long ans = 0, ans_val = 1e16;
            do {
                long long x = 0, p10 = 1, mx;
                for (int i = 0; i < k; i++) {
                    x = x * 10 + v[i];
                    p10 *= 10;
                }
                mx = x;
                for (int i = k; i < n; i++) {
                    x = x * 10 + v[i];
                    mx = max(mx, x % p10);
                }
                if (mx < ans_val) {
                    ans = x;
                    ans_val = mx;
                }
            } while (next_permutation(v, v + n));
            cout << ans << '\n';
        } else if (k == 2) {
            int ix = 0;
            for (int i = 0; i * 2 < n; i++) {
                if (i * 2 != n - 1)
                    s[ix++] = '0' + v[n - i - 1];
                s[ix++] = '0' + v[i];
            }
            s[n] = 0;
            cout << s << '\n';
        }
    }

    return 0;
}
