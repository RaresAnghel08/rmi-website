/**
* user:  buntov-447
* fname: Atanas Todorov
* lname: Buntov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:33:19.480812
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;
void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(N);

    for(int i=1;i<N;i++)
    {
        setHint(A[i],B[i],1);
        setHint(B[i],A[i],1);
    }
}

void speedrun(int subtask, int N, int start) {

    int l = getLength();
    bool f[1100];
    for(int i=1;i<=l;i++)f[i]=0;
    f[start] = 1;
    int curr = start;
    int pos=0;
    vector<int>vis;
    vis.push_back(start);
    int br=1,pp=1;
    while(br<l){
    int r=0;
    for(int i=1;i<=l;i++)
    {
        //cout<<curr<<" "<<i<<" "<<f[i]<<" "<<getHint(i)<<" "<<current_node<<endl;
        if(getHint(i)==1&&f[i]==0){
                if(goTo(i)==true){curr=i;vis.push_back(i);f[curr]=1;pos = vis.size()-1;br++;r=1;break;}
        }
    }
    //cout<<curr<<" "<<r<<" "<<pos<<endl;
    if(r==0){pos--;vis.push_back(vis[pos]);goTo(vis[pos]);curr = vis[pos];}
    pp++;
    if(pp==1000)break;
    }
}
