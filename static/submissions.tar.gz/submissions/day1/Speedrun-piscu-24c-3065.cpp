/**
* user:  piscu-24c
* fname: Stefan Constantin
* lname: Piscu
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 10:32:50.316160
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;

int nrDet, N;

struct nodHints{
	bool leftmost;
	int fat;
	vector<int> out;
	int a=0, b=0;
};

struct nodSpeed{
	bool isDet=0;
	bool leftmost=0, isLeaf=0;
	int a=0, b=0;
	int fat=-1;
};

vector<nodHints> g;
vector<nodSpeed> gs;

void compute1(int x, int fat=0){
	g[x].fat=fat;
	if(fat==0) g[x].out.push_back(0);
	for(int i=0;(i+1)<g[x].out.size();++i){
		auto &it=g[x].out[i];
		if(it==fat){
			swap(it, g[x].out.back());	
			i--;
			continue;
		}
		compute1(it, x);
	}
	g[x].out.pop_back();
	if(g[x].out.size()) g[g[x].out.back()].leftmost=1;
}

void gethints(int x, int brother=0){
  g[x].b=brother;
	if(!g[x].out.size()){
		if(!g[x].leftmost) g[x].a=g[x].fat;
		else{
			int cr=x;
			while(cr&&g[cr].leftmost) cr=g[cr].fat;
			if(cr){
				g[x].a=g[cr].fat;
			}
		}
		return;
	}
	g[x].a=g[x].out[0];
	for(int i=0;i<g[x].out.size();++i){
		auto &it=g[x].out[i];
		if((i+1)==g[x].out.size()) gethints(it, x);
		else gethints(it, g[x].out[i+1]);
	}
}

void print(int x){
	cout<<x<<" "<<g[x].fat<<" "<<g[x].leftmost<<" "<<g[x].a<<" "<<g[x].b<<"*\n";
	for(auto it:g[x].out) print(it);
}

void assignHints(int subtask, int n, int a[], int b[]) { /* your solution here */
	g.resize(n+1);
	for(int i=1;i<n;++i){
		g[a[i]].out.push_back(b[i]);
		g[b[i]].out.push_back(a[i]);
	}
	compute1(1);
	gethints(1);
	//print(1);
	//cout<<"\n";
	setHintLen(20);
	for(int i=1;i<=n;++i){
		for(int j=0;j<10;++j){
			setHint(i, j+1, g[i].a&(1<<j));
		}
		for(int j=0;j<10;++j){
			setHint(i, j+11, g[i].b&(1<<j));
		}
	}
	g.clear();
}

void getInfo(int x){
	if(gs[x].isDet) return;
	//cout<<"-----\n";
	gs[x].isDet=1;
	nrDet++;
	for(int j=0;j<10;++j){
		gs[x].a|=(getHint(j+1)<<j);
	}
	for(int j=0;j<10;++j){
		gs[x].b|=(getHint(j+11)<<j);
	}
	if(gs[x].b>0&&goTo(gs[x].b)){
		gs[x].leftmost=1;
		gs[x].fat=gs[x].b;
		goTo(x);
	}
	gs[x].isLeaf=0;
	if(gs[x].leftmost){
		if(gs[x].a<=0) gs[x].isLeaf=1;
		else if(goTo(gs[x].a)){
			//cout<<"**";
			goTo(x);
		}
		else{
			gs[x].isLeaf=1;
		}
	}
	else{
		if(gs[x].a>0&&goTo(gs[x].a)){
			if(gs[x].b>0&&goTo(gs[x].b)){
				gs[x].isLeaf=1;
				gs[x].fat=gs[x].a;
				goTo(gs[x].a);
			}
			goTo(x);
		}
	}
	//cout<<"+++++\n";
}

void visit(int x){
	if(nrDet==N) return;
	//cout<<x<<"*\n";
	getInfo(x);
	if(gs[x].isLeaf){
		if(gs[x].leftmost){
			int val=gs[x].a;
			int cr=x;
			stack<int> road;
			while((cr>0)&&gs[cr].leftmost){
				if(gs[cr].fat<=0) break;
			//	cout<<"*";
				goTo(gs[cr].fat);
				road.push(cr);
				//getInfo(gs[cr].fat);
				cr=gs[cr].fat;
			}
			while(!road.empty()){
				//cout<<"^", 
				goTo(road.top());
				road.pop();
			}
			if(cr>0) gs[cr].fat=val;
		}
	}
	else if((gs[x].a>0)&&(!gs[gs[x].a].isDet)){
		gs[gs[x].a].fat=x;
		goTo(gs[x].a);
		visit(gs[x].a);
		
	}
	int nextBro=0;
	if(gs[x].fat<=0) return;
	if(gs[x].leftmost) nextBro=gs[gs[x].fat].a;
	else nextBro=gs[x].b;
	if(nextBro>0&&(!gs[nextBro].isDet)){
		//cout<<"-"<<" "<<x<<" ";
		goTo(gs[x].fat);
		//getInfo(gs[x].fat);
		//cout<<"+";
		goTo(nextBro);
		visit(nextBro);
	}
	else if(x!=1){
		//cout<<"&";
		goTo(gs[x].fat);
		visit(gs[x].fat);
	}
}

void speedrun(int subtask, int n, int start) { /* your solution here */
	nrDet=0;
	N=n;
	gs.resize(n+1);
	visit(start);
	//cout<<gs[start].isDet<<" "<<gs[start].isLeaf<<" "<<gs[start].leftmost<<" "<<gs[start].a<<" "<<gs[start].b<<"\n";
}





