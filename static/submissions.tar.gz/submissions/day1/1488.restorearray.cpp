/**
* user:  apostol-c2d
* fname: Daniel
* lname: Apostol
* task:  restore
* score: 13.0
* date:  2019-10-10 06:55:42.400464
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define pb push_back
#define get_here cerr << "-1\n"
#define dbg(x) cerr << #x << " " << x << "\n"

int n, m;
const int N = 5000, M = 1e4;
int ans[1 + N];
int k[1 + M];
int val[1 + M];
int l[1 + M];
int r[1 + M];

int main () {
   // freopen ("restore.in", "r", stdin);
   // freopen ("restore.out", "w", stdout);

    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);

    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        cin >> l[i] >> r[i] >> k[i] >> val[i];
        l[i]++;
        r[i]++;
        if (val[i] == 1) {
            for (int j = l[i]; j <= r[i]; j++)
                ans[j] = 1;
        }
    }
    for (int i = 1; i <= m; i++) {
        if (val[i] == 0) {
            bool ok = false;
            for (int j = l[i]; j <= r[i]; j++)
                if (ans[j] == 0)
                    ok = true;
            if (!ok) {
                cout << "-1\n";
                return 0;
            }
        }
    }
    for (int i = 1; i <= n; i++)
        cout << ans[i] << " ";
    return 0;
}
