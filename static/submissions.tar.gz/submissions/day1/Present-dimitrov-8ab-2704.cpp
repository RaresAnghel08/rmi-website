/**
* user:  dimitrov-8ab
* fname: Atanas
* lname: Dimitrov
* task:  Present
* score: 29.0
* date:  2021-12-16 09:59:20.324334
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl "\n"
template<class T, class T2> bool chkmin(T &a, const T2 &b) {return (a > b) ? a = b, 1 : 0;}
template<class T, class T2> bool chkmax(T &a, const T2 &b) {return (a < b) ? a = b, 1 : 0;}
#ifndef LOCAL
#define cerr if(false)cerr
#endif // LOCAL

const int MAX_N = 200;
ll gcd[MAX_N][MAX_N];
int k;
bool used[MAX_N];

vector<int> vec;
vector<int> bot;
int cnt = 0;

void dfs(int bound) {
    if(cnt == k) {
        cnt ++;
        cout << vec.size() << " ";
        sort(vec.begin(), vec.end());
        for(auto it : vec) {
            cout << it << " ";
        }
        cout << endl;
        return;
    }
    cnt ++;
    for(int i = 1; i <= bound; i ++) {
        if(used[i]) {continue;}
        bot.push_back(vec.size());
        vec.push_back(i);
        used[i] = true;
        for(int j = 0; vec[j] != i; j ++) {
            auto it = vec[j];
            if(!used[gcd[i][it]]) {
                vec.push_back(gcd[i][it]);
                used[gcd[i][it]] = true;
            }
        }
        dfs(i - 1);
        while(vec.size() != bot.back()) {
            used[vec.back()] = false;
            vec.pop_back();
        }
        bot.pop_back();
        if(cnt > k) {break;}
    }
}

signed main() {
    //ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

    for(int i = 1; i < MAX_N; i ++) {
        for(int j = 1; j < MAX_N; j ++) {
            gcd[i][j] = __gcd(i, j);
        }
    }

    vec.resize(0);

    int t;
    cin >> t;
    while(t --) {
        cin >> k;
        cnt = 0;
        dfs(200);
    }

    return 0;
}

