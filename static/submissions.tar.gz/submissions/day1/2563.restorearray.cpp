/**
* user:  andreescu-960
* fname: Mihnea
* lname: Andreescu
* task:  restore
* score: 0.0
* date:  2019-10-10 09:31:22.933754
*/
#include <bits/stdc++.h>

using namespace std;

const int N=20;
int n,m;
int cnt0[N],cnt1[N],val[N];

struct oly
{
        int l;
        int r;
        int k;
        int x;
};

oly a[200+7];

int main()
{
        ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

     ///   freopen("input","r",stdin);

        cin>>n>>m;
        for(int i=1;i<=m;i++)
                cin>>a[i].l>>a[i].r>>a[i].k>>a[i].x;

        for(int mt=0;mt<(1<<n);mt++)
        {
                for(int i=0;i<n;i++)
                        val[i+1]=(mt&(1<<i));
                for(int i=1;i<=n;i++)
                {
                        cnt0[i]=cnt0[i-1]+(val[i]==0);
                        cnt1[i]=cnt1[i-1]+(val[i]==1);
                }
                bool ok=1;
                for(int j=1;j<=m && ok;j++)
                {
                        int l=a[j].l+1,r=a[j].r+1;
                        int k=a[j].k,x=a[j].x;
                        int c0=(cnt0[r]-cnt0[l-1]);
                        int c1=(cnt1[r]-cnt1[l-1]);
                        if(x==0)
                        {
                                if(c0>=k) continue;
                                ok=0;
                        }
                        else
                        {
                                if(c0<k) continue;
                                ok=0;
                        }
                }
                if(ok)
                {
                        for(int i=1;i<=n;i++)
                                cout<<val[i]<<" ";
                        cout<<"\n";
                        return 0;
                }
        }
        cout<<"-1\n";

        return 0;
}
