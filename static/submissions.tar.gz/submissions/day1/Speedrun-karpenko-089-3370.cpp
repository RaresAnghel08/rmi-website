/**
* user:  karpenko-089
* fname: Daryna
* lname: Karpenko
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:59:44.932090
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
typedef int ll;

void H1(int subtask, int N, int A[], int B[]) { /* your solution here */
    setHintLen(N);
    for(int i=1;i<N;i++){
        setHint(A[i],B[i],true);
        setHint(B[i],A[i],true);
    }
    return ;
}

void H2(int subtask, int N, int A[], int B[]) { /* your solution here */
    ll n=N;
    ll d[1007];
    for(int i=1;i<=n;i++)d[i]=0;
    for(int i=1;i<n;i++){
        d[A[i]]++;
        d[B[i]]++;
    }
    ll k=0;
    for(int i=1;i<=n;i++){
        if(d[i]==n-1)k=i;
    }
    setHintLen(10);
    ll h=1;
    while(k>0){
        for(int i=1;i<=n;i++){
            setHint(i,h,k%2);
        }
        k/=2;
        h++;
    }
    return ;
}

void H3(int subtask, int N, int A[], int B[]) { /* your solution here */
    ll n=N;
    ll d[1007];
    setHintLen(20);
    for(int i=1;i<n;i++){
        ll k=B[i];
        ll h=1;
        while(k>0){
            setHint(A[i],h,k%2);
            k/=2;
            h++;
        }

        k=A[i];
        h=11;
        while(k>0){
            setHint(B[i],h,k%2);
            k/=2;
            h++;
        }
    }
    return ;
}

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    //H1(subtask,N,A,B);
   // H2(subtask,N,A,B);
    H3(subtask,N,A,B);
    return ;
}
void S1(int subtask, int N, int start) { /* your solution here */
    ll l=getLength();
    ll d[1007];
    for(int i=1;i<=N;i++){
        d[i]=1;
    }

    ll h[1007];
    ll x=start;
    h[x]=x;

    for(;d[x]<=N+1;d[x]++){
        if(d[x]==N+1){
            if(h[x]!=x)d[h[x]]--;
            if(x!=h[x])goTo(h[x]);
            x=h[x];

            continue;
        }
        ll y=getHint(d[x]);
        //cout<<d[x]<<" ! "<<x<<" "<<y<<endl;
        if(y==1 && d[x]!=h[x] && goTo(d[x])){
            h[d[x]]=x;
            d[x]++;
            x=d[x]-1;
            //cout<<x<<endl;
            d[x]--;
        }
        if(d[x]==N){
            if(h[x]!=x)d[h[x]]--;
            if(x!=h[x])goTo(h[x]);
            x=h[x];
        }
    }
    return ;
}

void S2(int subtask, int N, int start) { /* your solution here */
    ll l=getLength();
    ll n=N;
    ll k=0;
    ll x=0;
    for(int i=10;i>=1;i--){
        k*=2;
        k+=getHint(i);
    }
    if(k!=start){
        goTo(k);
    }
    for(int i=1;i<=n;i++){
        if(i!=k){
            goTo(i);
            goTo(k);
        }
    }
    return ;
}

void S3(int subtask, int N, int start) { /* your solution here */
    ll l=getLength();
    ll n=N;
    ll h[1007],f[1007];
    for(int i=1;i<=n;i++){
        h[i]=0;
        f[i]=0;
    }
    ll x=start;
    h[x]=x;
    while(1){
        //cout<<1<<" "<<x<<endl;
        f[x]=1;
        ll a=0;
        ll b=0;
        for(int i=10;i>=1;i--){
            a*=2;
            a+=getHint(i);
        }
        for(int i=20;i>=11;i--){
            b*=2;
            b+=getHint(i);
        }
        if(a==0){
            a=b;
            b=0;
        }
        if(b==0){
            while(h[x]!=x){
                //cout<<x<<endl;
                goTo(h[x]);
                x=h[x];
            }
            break;
        }
        if(f[a]!=1){
            h[a]=x;
            goTo(a);
            x=a;
            f[x]=1;
        }else{
            h[b]=x;
            goTo(b);
            x=b;
            f[x]=1;
        }
    }
    while(1){
        //cout<<2<<" "<<endl;
        ll a=0;
        ll b=0;
        f[x]=1;
        for(int i=10;i>=1;i--){
            a*=2;
            a+=getHint(i);
        }
        for(int i=20;i>=11;i--){
            b*=2;
            b+=getHint(i);
        }
        if(a==0){
            a=b;
            b=0;
        }
        if(b==0){
            break;
        }
        if(f[a]!=1){
            h[a]=x;
            goTo(a);
            x=a;
            f[x]=1;
        }else{
            h[b]=x;
            goTo(b);
            x=b;
            f[x]=1;
        }
    }
    return ;
}


void speedrun(int subtask, int N, int start) { /* your solution here */
    //S1(subtask, N, start);
    //S2(subtask, N, start);
    S3(subtask, N, start);
    return ;
}
