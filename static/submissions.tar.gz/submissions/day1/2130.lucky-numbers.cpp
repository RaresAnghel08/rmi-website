/**
* user:  perju-verzotti-a3f
* fname: Luca
* lname: Perju-Verzotti
* task:  lucky
* score: 14.0
* date:  2019-10-10 08:34:47.425620
*/
#include <iostream>

using namespace std;
bool verif (int val)
{
    while(val)
    {
        if(val%100==13)
            return false;
        val/=10;
    }
    return true;
}
int main()
{
    ios_base::sync_with_stdio(0);
    int n,i,j,q,cnt=0;
    cin>>n>>q>>n;
    for(i=n;i>=0;--i)
    {
        if(verif(i))
            ++cnt;
    }
    cout<<cnt;
    return 0;
}
