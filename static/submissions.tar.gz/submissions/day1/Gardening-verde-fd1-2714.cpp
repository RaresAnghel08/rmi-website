/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Gardening
* score: 18.0
* date:  2021-12-16 09:59:52.223184
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast","unroll-loops")
#pragma GCC target("avx","avx2","fma")
using namespace std;
map <pair<int,int>,set<int>> mp;
vector <int> v[200001];
void vruum(int a,int b)
{
    if(a==0||b==0)
        return;
    if(a==2)
    {
        mp[ {a,b}]= {b/2};
        return;
    }
    if(b==2)
    {
        mp[ {a,b}]= {a/2};
        return;
    }
    if(mp[ {a,b}].empty()==0)
        return;
    if(mp[ {b,a}].empty()==0)
    {
        mp[ {a,b}]=mp[ {b,a}];
        return;
    }
    vruum(a-2,b-2);
    vruum(a-2,b);
    vruum(a,b-2);
    for(auto it:mp[ {a-2,b-2}])
        mp[ {a,b}].insert(it+1);
    for(auto it:mp[ {a-2,b}])
        mp[ {a,b}].insert(it+b/2);
    if(a!=b)
        for(auto it:mp[ {a,b-2}])
            mp[ {a,b}].insert(it+a/2);
}
int k,cnt;
void afis(int x1,int y1,int x2,int y2)
{
    int ok=0,l=x2-x1+1,c=y2-y1+1;
    if(l==2)
    {
        for(int i=y1;i<=y2;i+=2)
                v[x1][i]=v[x1][i+1]=v[x1+1][i]=v[x1+1][i+1]=++cnt;
        return;
    }
    else if(c==2)
    {
        for(int i=y1;i<=y2;i+=2)
                v[x1][i]=v[x1][i+1]=v[x1+1][i]=v[x1+1][i+1]=++cnt;
        return;
    }
    for(auto it:mp[ {l-2,c-2}])
        if(it+1==k)
        {
            k--;
            afis(x1+1,y1+1,x2-1,y2-1);
            ///fac chenarele
            ++cnt;
            for(int i=y1;i<=y2;i++)
                v[x1][i]=v[x2][i]=cnt;
            for(int i=x1;i<=x2;i++)
                v[i][y1]=v[i][y2]=cnt;
            ok=1;
            break;
        }
    if(!ok)
    for(auto it:mp[{l-2,c}])
        if(it+c/2==k)
        {
            k-=c/2;
            afis(x1+2,y1,x2,y2);
            ///fac liniile
            for(int i=y1;i<=y2;i+=2)
                v[x1][i]=v[x1][i+1]=v[x1+1][i]=v[x1+1][i+1]=++cnt;
            ok=1;
            break;
        }
    if(!ok)
        for(auto it:mp[{l,c-2}])
        if(it+l/2==k)
        {
            k-=l/2;
            afis(x1,y1+2,x2,y2);
            ///fac coloanele
            for(int i=x1;i<=x2;i+=2)
                v[i][y1]=v[i][y1+1]=v[i+1][y1]=v[i+1][y1+1]=++cnt;
            ok=1;
            break;
        }
}
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int t,n,m,i,j;
    cin>>t;
    while(t--)
    {
        cin>>n>>m>>k;
        cnt=0;
        for(i=1; i<=n; i++)
            v[i].resize(m+1);
        vruum(n,m);
        int ok=0;
        for(auto it:mp[ {n,m}])
            if(it==k)
                ok=1;
        if(ok==0)
            cout<<"NO\n";
        else
        {
            cout<<"YES\n";
            afis(1,1,n,m);
            for(i=1; i<=n; i++)
            {
                for(j=1; j<=m; j++)
                    cout<<v[i][j]<<" ";
                cout<<'\n';
            }
        }
    }
    return 0;
}
