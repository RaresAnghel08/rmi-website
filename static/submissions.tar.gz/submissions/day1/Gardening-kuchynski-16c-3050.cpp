/**
* user:  kuchynski-16c
* fname: Ilya
* lname: Kuchynski
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:31:04.135511
*/
#include <bits/stdc++.h>
using namespace std;

int main(){
      ios_base :: sync_with_stdio(0);
      cin.tie(0); cout.tie(0);
      int t; cin >> t;
      while(t --){
            int n, m, k;
            cin >> n >> m >> k;
            if(n % 2 == 1 || m % 2 == 1 || (n * m / 4) < k || min(n / 2, m / 2) > k){
                  cout << "NO\n";
                  continue;
            }
            int now = n * m / 4;
            vector<vector<int>> f(n, vector<int>(m, -1));
            auto paint = [&](int x1, int y1, int x2, int y2, int color){
                  for(int j = y1; j <= y2; j ++)
                        f[j][x1] = f[j][x2] = color;
                  for(int i = x1; i <= x2; i ++)
                        f[y1][i] = f[y2][i] = color;
//                  cout << x1 << " " << y1 << " " << x2 << " " << y2 << endl;
            };
//            cout << "now = " << now << endl;
            int clr = 0;
            bool bad = false;
            for(int b = 1; !bad && b + 1 <= min(n, m) / 2; b ++){
                  int r = n / 2 - b + 1, c = m / 2 - b + 1;
                  int tr = 1, tc = 1;
                  bool nxt = false;
                  if(now - 4 >= k){
                        tr = 3;
                        tc = 3;
//                        now -= 4;
                        if(now - 2 >= k){
                              nxt = true;
                              now -= 2;
                        }
                  }
                  if(now - (tc - 1) - (r - 1) >= k){
                        tr = r;
                        if(now - (c - 1) - (tr - 1) >= k){
                              tc = c;
                        }else{
                              while(now - (tc - 1) - (tr - 1) > k)
                                    ++ tc;
                        }
                  }else{
                        while(now - (tc - 1) - (tr - 1) > k)
                              ++ tr;
                  }
                  if(tr == 1 && tc > 1)
                        bad = true;
                  if(tc == 1 && tr > 1)
                        bad = true;
                  now -= (tr - 1);
                  now -= (tc - 1);

                  int x1 = 0 + (b - 1), y1 = n - 2 - (b - 1) - 2 * (tr - 1);
                  int x2 = 1 + 2 * (tc - 1) + (b - 1), y2 = n - 1 - (b - 1);

//                  cout << tr << " : " << tc << endl;
//                  cout << x1 << " " << y1 << " " << x2 << " " << y2 << endl;
                  paint(x1, y1, x2, y2, ++ clr);

                  if(nxt){
                        now += 2;
                  }else{
                        break;
                  }

//                  int x2 = x1 + 1, y2 = y1 + 1;
////                  cout << b << " : " << r << " " << c << endl;
//                  bool br = false;
//                  if(now - r + 1 >= k){
//                        now = now - r + 1;
//                        y2 = n - 1 - (b - 1);
//                        if(now - c + 1 >= k){
//                              now = now - c + 1;
//                              x2 = m - 1 - (b - 1);
//                        }else{
////                              cout << b << " : " <C< x2 << " " << y2 << endl;
//                              while(now > k){
//                                    now --;
//                                    x2 += 2;
//                              }
//                              br = true;
//                        }
//                  }else{
//                        while(now > k){
//                              now --;
//                              y2 += 2;
//                        }
//                        br = true;
//                  }
//                  paint(x1, y1, x2, y2, ++ clr);
//                  cout << " * " << now << endl;
//                  if(br)
//                        break;
            }
            if(bad){
                  cout << "NO\n";
                  return 0;
            }
            for(int i = 0; i + 1 < n; i ++){
                  for(int j = 0; j + 1 < m; j ++){
                        bool ok = true;
                        for(int x = 0; x <= 1; x ++){
                              for(int y = 0; y <= 1; y ++){
                                    if(f[i + x][j + y] != -1)
                                          ok = false;
                              }
                        }
                        if(ok){
                              ++ clr;
                              for(int x = 0; x <= 1; x ++){
                                    for(int y = 0; y <= 1; y ++){
                                          f[i + x][j + y] = clr;
                                    }
                              }
                        }
                  }
            }
            if(clr != k){
                  cout << "NO\n";
                  continue;
            }
            cout << "YES\n";
            for(int i = 0; i < n; i ++){
                  for(int j = 0; j < m; j ++){
                        cout << f[i][j] << " ";
                  }
                  cout << "\n";
            }
      }
}
