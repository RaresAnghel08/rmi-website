/**
* user:  nechyporuk-b72
* fname: Vladyslav
* lname: Nechyporuk
* task:  Present
* score: 29.0
* date:  2021-12-16 09:11:25.707890
*/
#pragma GCC optimize("Ofast")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
using namespace std;
int MXA=26;
vector<vector<int> > mas;
vector<vector<bool> > cant;
void solve() {
    int n;
    cin>>n;
    cout<<mas[n].size()<<' ';
    for(auto j:mas[n])cout<<j<<' ';
    cout<<'\n';

}
signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    mas.push_back(vector<int>());
    cant.push_back(vector<bool>(MXA));
    int num=1;
    int j=0;
    int to=1;
    for(int i=1;i<=1000000;i++)
    {
        if(j==to)
        {
            num++;
            to=i;
            j=0;
            i--;
            //cout<<num-1<<' '<<i+1<<'\n';
            continue;
        }
        if(cant[j][num])
        {
            i--;
            j++;
            continue;
        }
        mas.push_back(mas[j]);
        mas[i].push_back(num);
        cant.push_back(cant[j]);
        vector<bool> was(MXA);
        for(auto z:mas[i])was[z]=1;
        for(int z=num+1;z<=MXA;z++)
        {
            if(!was[__gcd(z,num)])cant[i][z]=1;
        }
        j++;
        /*for(auto z:mas[i])
        {
            cout<<z<<' ';
        }
        cout<<'\n';*/
    }

    int t=1;
    cin>>t;
    while(t--)solve();
}
/*
1 2
2 4
3 7
4 13
5 22
6 38
7 67
8 121
9 208
10 346
11 663
12 1067
13 2084
14 3650
15 5621
16 10187
17 20228
18 33960
19 67673
20 106919
21 167302
22 316644
23 632549
24 988585
25 1672754
26 3243116
*/
