/**
* user:  todoran-200
* fname: Alexandru Raul
* lname: Todoran
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 11:51:54.749422
*/
/**
 ____ ____ ____ ____ ____
||a |||t |||o |||d |||o ||
||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|

**/

#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

typedef long long ll;

const int N_MAX = 1000;

int N;

vector <int> adj[N_MAX + 2];

void setHintLen (int l);
void setHint (int i, int j, bool b);

bool seen[N_MAX + 2];

vector <int> ord;

int down[N_MAX + 2];
int parent[N_MAX + 2];

void dfs (int u) {
    seen[u] = true;
    ord.push_back(u);
    while (adj[u].empty() == false && seen[adj[u].back()] == true) {
        adj[u].pop_back();
    }
    if (adj[u].empty() == false) {
        int v = adj[u].back();
        adj[u].pop_back();
        down[u] = v;
        parent[v] = u;
        dfs(v);
    }
    for (int v : adj[u]) {
        if (seen[v] == false) {
            down[ord.back()] = v;
            parent[v] = u;
            dfs(v);
        }
    }
}

void assignHints (int subtask, int _N, int A[], int B[]) {
    N = _N;
    for (int i = 1; i <= N - 1; i++) {
        adj[A[i]].push_back(B[i]);
        adj[B[i]].push_back(A[i]);
    }
    setHintLen(20);
    dfs(1);
    for (int u = 1; u <= N; u++) {
        int curr = 0;
        for (int b = 0; b < 10; b++) {
            setHint(u, ++curr, ((down[u] >> b) & 1));
        }
        for (int b = 0; b < 10; b++) {
            setHint(u, ++curr, ((parent[u] >> b) & 1));
        }
    }
}

int getLength ();
bool getHint (int j);
bool goTo (int x);

void extract (int u) {
    down[u] = 0;
    parent[u] = 0;

    int curr = 0;
    for (int b = 0; b < 10; b++) {
        down[u] |= (getHint(++curr) << b);
    }
    for (int b = 0; b < 10; b++) {
        parent[u] |= (getHint(++curr) << b);
    }
}

vector <int> euler;

void solve (int u) {
    extract(u);
    if (down[u] == 0) {
        return;
    }
    int v = u;
    while (true) {
        if (goTo(down[u]) == true) {
            break;
        }
        v = parent[v];
        goTo(v);
    }
    solve(down[u]);
}

void speedrun (int subtask, int _N, int start) {
    int L = getLength();
    N = _N;
    while (start != 1) {
        extract(start);
        start = parent[start];
        goTo(start);
    }
    solve(1);
}
