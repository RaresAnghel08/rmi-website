/**
* user:  elbaum-6df
* fname: Eitan
* lname: Elbaum
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 07:56:29.143698
*/
#include "speedrun.h"
#include<vector>
#include<iostream>
using namespace std;
void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(20);
    int f[N+1];
    for(int i=1;i<=N;i++) f[i]=0;
    for(int i=1;i< N;i++){
        f[A[i]]++; f[B[i]]++;
    }
    int x=-1;
    for(int i=1;i<=N;i++){
        if(f[i] == (N-1)) x=i;
    }
    int p=1;
    while(x>0){
        for(int i=1;i<=N;i++){
            setHint(i,p,x%2);
        }
        x/=2; p++;
    }
}
/*void rec(int i, int f, bool f1, int n, vector<bool>&vis){
    cout<<i<<' ';
    vis[i]=1;
    for(int j=1;j<=n;j++){
        if(getHint(j) && !vis[j]){
            goTo(j);
            rec(j,i,1,n,vis);
        }
    }
    if(f1) goTo(f);
}*/
void speedrun(int subtask, int N, int start) {
    int x=0,p=11;
    while(p>0){
        x*=2;
        x += getHint(p);
        p--;
    }
    goTo(x);
    for(int i=1;i<=N;i++){
        goTo(i);
        goTo(x);
    }
}