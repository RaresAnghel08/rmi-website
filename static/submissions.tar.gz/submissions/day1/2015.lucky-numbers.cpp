/**
* user:  popescu-96c
* fname: Ioan
* lname: Popescu
* task:  lucky
* score: 0.0
* date:  2019-10-10 08:20:42.549954
*/
#include <bits/stdc++.h>
using namespace std;

const int MOD = 1e9 + 7;

struct node{
    int a[4], b[4], l, n0;
    node() {
        for(int i = 0; i < 4 ; ++i) a[i] = b[i] = 0;
        l = 0;
    }
};
node Sol, Arb[400005];

int n, q;
char s[100005];
int dp[100005][4];

void bolt(){
    dp[1][0] = 8;
    dp[1][1] = 1; ///care se termina cu 1
    dp[1][2] = 1; ///care incep cu 3
    dp[1][3] = 0; ///care incep cu 3 si se termina in 1

    for(int i = 2; i <= 100000 ; ++i){
        dp[i][0] = (dp[i - 1][0] * 9LL + dp[i - 1][1] * 8LL) % MOD;
        dp[i][1] = (dp[i - 1][0] + dp[i - 1][1]) % MOD;
        dp[i][2] = (dp[i - 1][2] * 9LL + dp[i - 1][3] * 8LL) % MOD;
        dp[i][3] = (dp[i - 1][3] + dp[i - 1][2]) % MOD;
    }
}

void combine(int a[4], int b[4], int c[4]){
    ///in c tin rezultatul

    c[0] = (c[0] + 1LL * a[0] * (b[0] + b[2]) + 1LL * a[1] * b[0]) % MOD;
    c[1] = (c[1] + 1LL * a[0] * (b[1] + b[3]) + 1LL * a[1] * b[1]) % MOD;
    c[2] = (c[2] + 1LL * a[2] * (b[2] + b[0]) + 1LL * a[3] * b[0]) % MOD;
    c[3] = (c[3] + 1LL * a[2] * (b[3] + b[1]) + 1LL * a[3] * b[1]) % MOD;
}

inline int get_num(int a[4], int b[4]){
    int Sol = 0;
    for(int i = 0; i < 4 ; ++i){
        Sol = Sol + a[i];
        if(Sol >= MOD) Sol -= MOD;
        Sol = Sol + b[i];
        if(Sol >= MOD) Sol -= MOD;
    }
    return Sol;
}

void build(int st = 1, int dr = n, int nod = 1){
    if(st == dr){
        for(int j = 0; j < 4 ; ++j) Arb[nod].b[j] = Arb[nod].a[j] = 0;

        if(s[st] == '1') Arb[nod].b[1] = 1;
        else if(s[st] == '3') Arb[nod].b[2] = 1;
        else Arb[nod].b[0] = 1;

        for(int i = 0; i < s[st] - '0' ; ++i){
            if(i == 1) ++Arb[nod].a[1];
            else if(i == 3) ++Arb[nod].a[2];
            else ++Arb[nod].a[0];
        }

        Arb[nod].l = 1; Arb[nod].n0 = 0;
        if(s[st] == '0') Arb[nod].l = 0, Arb[nod].n0 = 1;

        return ;
    }

    int mij = (st + dr) / 2;
    build(st, mij, nod * 2);
    build(mij + 1, dr, nod * 2 + 1);

    if(Arb[nod * 2].l == 0) {
        Arb[nod] = Arb[nod * 2 + 1];
        Arb[nod].n0 -= Arb[nod * 2 + 1].n0;
        Arb[nod].l += Arb[nod * 2 + 1].l;

        Arb[nod].n0 += Arb[nod * 2].n0;
        return ;
    }

    for(int j = 0; j < 4 ; ++j) Arb[nod].b[j] = Arb[nod].a[j] = 0;
    Arb[nod].l = Arb[nod].n0 = 0;

    Arb[nod].l = Arb[nod * 2].l + Arb[nod * 2 + 1].l + Arb[nod * 2 + 1].n0;
    Arb[nod].n0 = Arb[nod * 2].n0;

    combine(Arb[nod * 2].a, dp[Arb[nod * 2 + 1].l + Arb[nod * 2 + 1].n0], Arb[nod].a);
    combine(Arb[nod * 2].b, Arb[nod * 2 + 1].a, Arb[nod].a);
    combine(Arb[nod * 2].b, Arb[nod * 2 + 1].b, Arb[nod].b);
}

void update(int x, int st = 1, int dr = n, int nod = 1){
    if(st == dr){
        for(int j = 0; j < 4 ; ++j) Arb[nod].b[j] = Arb[nod].a[j] = 0;

        if(s[st] == '1') Arb[nod].b[1] = 1;
        else if(s[st] == '3') Arb[nod].b[2] = 1;
        else Arb[nod].b[0] = 1;

        for(int i = 0; i < s[st] - '0' ; ++i){
            if(i == 1) ++Arb[nod].a[1];
            else if(i == 3) ++Arb[nod].a[2];
            else ++Arb[nod].a[0];
        }

        Arb[nod].l = 1; Arb[nod].n0 = 0;
        if(s[st] == '0') Arb[nod].l = 0, Arb[nod].n0 = 1;

        return ;
    }

    int mij = (st + dr) / 2;
    if(x <= mij) update(x, st, mij, nod * 2);
    else update(x, mij + 1, dr, nod * 2 + 1);

    if(Arb[nod * 2].l == 0) {
        Arb[nod] = Arb[nod * 2 + 1];
        Arb[nod].n0 -= Arb[nod * 2 + 1].n0;
        Arb[nod].l += Arb[nod * 2 + 1].l;

        Arb[nod].n0 += Arb[nod * 2].n0;
        return ;
    }

    for(int j = 0; j < 4 ; ++j) Arb[nod].b[j] = Arb[nod].a[j] = 0;
    Arb[nod].l = Arb[nod].n0 = 0;

    Arb[nod].l = Arb[nod * 2].l + Arb[nod * 2 + 1].l + Arb[nod * 2 + 1].n0;
    Arb[nod].n0 = Arb[nod * 2].n0;

    combine(Arb[nod * 2].a, dp[Arb[nod * 2 + 1].l + Arb[nod * 2 + 1].n0], Arb[nod].a);
    combine(Arb[nod * 2].b, Arb[nod * 2 + 1].a, Arb[nod].a);
    combine(Arb[nod * 2].b, Arb[nod * 2 + 1].b, Arb[nod].b);
}

void query(int x, int y, int st = 1, int dr = n, int nod = 1){
    if(x <= st && dr <= y){
        if(Sol.l == 0){
            for(int j = 0; j < 4 ; ++j) Sol.a[j] += Arb[nod].a[j], Sol.b[j] += Arb[nod].b[j];
            Sol.l += Arb[nod].l + Arb[nod].n0;
        }
        else{
            node aux;
            combine(Sol.a, dp[Arb[nod].l + Arb[nod].n0], aux.a);
            combine(Sol.b, Arb[nod].a, aux.a);
            combine(Sol.b, Arb[nod].b, aux.b);

            int L = Sol.l + Arb[nod].l + Arb[nod].n0;
            aux.n0 = Sol.n0;
            aux.l = L;
            Sol = aux;
        }
        return ;
    }

    int mij = (st + dr) / 2;
    if(x <= mij) query(x, y, st, mij, nod * 2);
    if(mij + 1 <= y) query(x, y, mij + 1, dr, nod * 2 + 1);
}

int main()
{
//    freopen("1.in", "r", stdin);

    bolt();
    scanf("%d%d", &n, &q);
    scanf("%s", s + 1);
    build();

    printf("%d\n", get_num(Arb[1].a, Arb[1].b));

    int tip, x, y;
    while(q--){
        scanf("%d%d%d", &tip, &x, &y);
        if(tip == 1){
            for(int j = 0; j < 4 ; ++j) Sol.a[j] = Sol.b[j] = 0;
            Sol.l = 0;
            query(x, y);
            printf("%d\n", get_num(Sol.a, Sol.b));
            continue ;
        }
        else{
            s[x] = y + '0';
            update(x);
        }
    }

    return 0;
}




















