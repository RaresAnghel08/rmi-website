/**
* user:  saprykin-5aa
* fname: Maxim
* lname: Saprykin
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:35:51.076151
*/
#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
#define int ll
typedef pair<int, int> pii;
#define all(a) a.begin(), a.end()
#define _ << ' ' <<
#define vec vector

void solve() {
    int n, m, k;
    cin >> n >> m >> k;
    if (n % 2 || m % 2) {
        cout << "NO";
        return;
    }
    if (n > m) {
        swap(n, m);
    }
    if (n == 2) {
        if (k == m / 2) {
            cout << "YES\n";
            for (int i = 0; i < 2; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << j / 2 + 1 << ' ';
                }
                cout << '\n';
            }
        } else {
            cout << "NO\n";
        }
        return;
    }
    if (n == 4) {
        map<int, int> mp;
        m /= 2;
        for (int i = 0; i <= m; ++i) {
            if (i == 1) continue;
            int cnt = i + (m - i) * 2;
            mp[cnt] = i;
        }
        m *= 2;
        vec<vec<int>> ans(n, vec<int>(m));
        if (mp.count(k) == 0) {
            cout << "NO\n";
            return;
        }
        cout << "YES\n";
        int x = mp[k];
        if (x == 0) {
            for (int i = 0; i < 2; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << j / 2 + 1 << ' ';
                }
                cout << '\n';
            }
            for (int i = 0; i < 2; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << j / 2 + 1 + m / 2 << ' ';
                }
                cout << '\n';
            }
            return;
        }
        int val = 1;
        for (int i = 0; i < x - 1; ++i) {
            int ind = (i) *2 + 1;
            ans[1][ind] = val;
            ans[2][ind] = val;
            ans[1][ind + 1] = val;
            ans[2][ind + 1] = val;
            val++;
        }
        m /= 2;
        for (int i = x; i < m; ++i) {
            for (int j = 0; j < 2; ++j) {
                int ind1 = j * 2;
                int ind2 = 2 * i;
                ans[ind1][ind2] = val;
                ans[ind1 + 1][ind2 + 1] = val;
                ans[ind1][ind2 + 1] = val;
                ans[ind1 + 1][ind2] = val;
                val++;
            }
        }
        m *= 2;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                cout << ans[i][j] + 1 << ' ';
            }
            cout << '\n';
        }
    }
}

signed main() {
#ifdef HOME
    freopen("input.txt", "r", stdin);
#endif
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int tt = 1;
    cin >> tt;
    for (int i = 1; i <= tt; ++i) {
        solve();
//        cout << '\n';
    }
}