/**
* user:  metehau-bba
* fname: Luca
* lname: Metehau
* task:  Gardening
* score: 78.0
* date:  2021-12-16 10:08:35.775818
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
#define ll long long
#define ld long double

using namespace std;

const ll N = 200005LL;

int T;
int n, m, k;

int col;

vector <vector <int>> v;

unordered_map <ll, bool> sol;

ll cod(int n, int m, int k) {
  return N * N * n + N * m + k;
}

bool check(int a, int b, int c) {
  if(a > b)
    swap(a, b);

  ll kek = cod(a, b, c);

  return sol.find(kek) != sol.end() && sol[kek];
}

bool solve(int n, int m, int k) {
  if(n > m)
    swap(n, m);

  ll kek = cod(n, m, k);

  if(sol.find(kek) != sol.end())
    return sol[kek];

  if(k < m / 2) {
    sol[kek] = 0;
    return 0;
  }

  if(k > n * m / 4) {
    sol[kek] = 0;
    return 0;
  }

  if(n % 2 || m % 2) {
    sol[kek] = 0;
    return 0;
  }

  if(k == 1) {
    sol[kek] = (n == 2 && m == 2);
    return n == 2 && m == 2;
  }

  for(int k1 = 1; k1 < k; k1++) {
    for(int j = 2; j < m - 1; j += 2) {
      if(solve(n, j, k1) && solve(n, m - j, k - k1)) {
        if(k == 2)
          assert((n == 2 && m == 4) || (n == 4 && m == 4));
        sol[kek] = 1;
        return 1;
      }
    }
  }

  /*for(int j = 2; j < n - 1; j++) {
    for(int k1 = 1; k1 < k; k1++) {
      if(solve(j, m, k1) && solve(n - j, m, k - k1)) {
        sol[kek] = 1;
        return 1;
      }
    }
  }*/

  if(solve(n - 2, m - 2, k - 1)) {
    if(k == 2)
      assert((n == 2 && m == 4) || (n == 4 && m == 4));
    sol[kek] = 1;
    return 1;
  }

  sol[kek] = 0;
  return 0;
}

void rec(int a, int b, int c, int d, int k) {
  int n = c - a + 1, m = d - b + 1;

  if(n == 1 || m == 1)
    return;

  if(k == 1) {
    if(n == 2 && m == 2) {
      v[a][b] = v[a][d] = v[c][b] = v[c][d] = col;
      col++;
    }
    return;
  }

  for(int j = b + 1; j < d; j++) {
    for(int k1 = 1; k1 < k; k1++) {
      if(check(c - a + 1, j - b + 1, k1) && check(c - a + 1, d - j, k - k1)) {
        rec(a, b, c, j, k1);
        rec(a, j + 1, c, d, k - k1);
        return;
      }
    }
  }

  for(int j = a + 1; j < c; j++) {
    for(int k1 = 1; k1 < k; k1++) {
      if(check(j - a + 1, d - b + 1, k1) && check(c - j, d - b + 1, k - k1)) {
        rec(a, b, j, d, k1);
        rec(j + 1, b, c, d, k - k1);
        return;
      }
    }
  }

  if(check(c - a - 1, d - b - 1, k - 1)) {
    for(int i = b; i <= d; i++)
      v[a][i] = v[c][i] = col;

    for(int i = a; i <= c; i++)
      v[i][b] = v[i][d] = col;
    col++;
    rec(a + 1, b + 1, c - 1, d - 1, k - 1);
    return;
  }

  return;
}

void solve() {
  cin >> n >> m >> k;

  sol.clear();
  bool ok = solve(n, m, k);

  if(!ok) {
    cout << "NO\n";
    return;
  }

  cout << "YES\n";
  v.resize(n + 1);
  for(int i = 1; i <= n; i++)
    v[i].resize(m + 1);
  col = 1;
  rec(1, 1, n, m, k);

  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++)
      cout << v[i][j] << " ";
    cout << "\n";
  }
}

int main() {
  cin >> T;

  /*for(int i = 1; i <= 20; i++) {
    for(int j = 1; j <= 20; j++) {
      int lst = 0;
      cout << i << " " << j << "\n";
      for(int k = 1; k <= 20; k++) {
        if(solve(i, j, k))
          cout << k << " ";
      }
      cout << "\n";
    }
    cout << "\n";
  }*/

  for(; T; T--) {
    solve();
  }
  return 0;
}
