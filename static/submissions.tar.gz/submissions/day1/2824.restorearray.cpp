/**
* user:  andreescu-960
* fname: Mihnea
* lname: Andreescu
* task:  restore
* score: 7.0
* date:  2019-10-10 10:04:11.088451
*/
#include <bits/stdc++.h>

using namespace std;

const int N=5000+7;
const int M=10000+7;
int n,m,a[N],c[N];
int l[M];
int r[M];
int k[M];
int x[M];

int main()
{
        ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

      ///  freopen("input","r",stdin);

        cin>>n>>m;
        for(int i=1;i<=m;i++)
        {
                cin>>l[i]>>r[i]>>k[i]>>x[i];
                l[i]++;
                r[i]++;
        }

        for(int mask=0;mask<(1<<n);mask++)
        {
                for(int i=0;i<n;i++)
                {
                        if(mask&(1<<i))
                                a[i+1]=1;
                        else
                                a[i+1]=0;
                        c[i+1]=c[i]+(a[i+1]==0);
                }
                bool gud=1;
                for(int i=1;i<=m && gud;i++)
                {
                        int cnt=c[r[i]]-c[l[i]-1];
                        if(x[i]==0)
                        {
                                /// cnt>=k[i]
                                gud&=(cnt>=k[i]);
                        }
                        else
                        {
                                /// cnt<k[i]
                                gud&=(cnt<k[i]);
                        }
                }
                if(gud)
                {
                        for(int i=1;i<=n;i++)
                                cout<<a[i]<<" ";
                        cout<<"\n";
                        return 0;
                }
        }
        cout<<"-1\n";

        return 0;
}
