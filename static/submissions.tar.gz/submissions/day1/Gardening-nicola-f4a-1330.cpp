/**
* user:  nicola-f4a
* fname: Alexandra Mihaela
* lname: Nicola
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:43:35.164200
*/
#include <bits/stdc++.h>

using namespace std;

int t,n,m,k,i,j;

int main (){

    ifstream cin ("date.in");
    ofstream cout ("date.out");

    cin>>t;
    for (;t--;){
        cin>>n>>m>>k;
        if (n % 2 || m % 2){
            cout<<"NO\n";
            continue;
        }

        if (n == 2){

            if (m % 2 || m / 2 != k){
                cout<<"NO\n";
                continue;
            }

            cout<<"YES\n";

            for (i=1;i<=n;i++){
                for (j=1;j<=m;j++)
                    cout<<(j+1)/2<<" ";
                cout<<"\n";
            }

            continue;
        }

        if (n == 4){

            if (m == 2){

                if (k != 2)
                    cout<<"NO\n";
                else cout<<"YES\n1 1\n1 1\n2 2\n2 2\n";

                continue;
            }

            if (m == 4){

                if (k == 2){
                    cout<<"YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
                } else {
                    if (k == 4){
                        cout<<"YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";

                    } else cout<<"NO\n";
                }

                continue;
            }

        }

    }


    return 0;
}
