/**
* user:  erdim-fbd
* fname: Yasmin Behich
* lname: Erdim
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:53:22.981654
*/
#include <bits/stdc++.h>
using namespace std;


int main()
{
	int t;
	cin>>t;
	while(t--) {
		int n, m, k;
		cin>>n>>m>>k;
		if(n%2 == 1 || m%2 == 1) {
			cout<<"NO"<<endl;
			continue;
		}
		if(n == 4) {
		int i;
		int x = k-(m/2);
		if(x<0) {
			cout<<"NO"<<endl;
			continue;
		}
		cout<<"YES"<<endl;
		for(i=1;i<=x;i++) cout<<i+1<<" "<<i+1<<" ";
		for(i=1;i<=m-2*x;i++) cout<<1<<" ";
		cout<<endl;
		for(i=1;i<=x;i++) cout<<i+1<<" "<<i+1<<" ";;
		cout<<1<<" ";
		int tek = 2*x+2;
		for(i=1;i<=(m-x-2)/2;i++) {
			cout<<tek<<" "<<tek<<" ";
			tek++;
		}
		cout<<1<<endl;
		for(i=x+1;i<=2*x;i++) cout<<i+1<<" "<<i+1<<" ";
		cout<<1<<" ";
		tek = 2*x+2;
		for(i=1;i<=(m-x-2)/2;i++) {
			cout<<tek<<" "<<tek<<" ";
			tek++;
		}
		cout<<1<<endl;
		for(i=x+1;i<=2*x;i++) cout<<i+1<<" "<<i+1<<" ";
		for(i=1;i<=m-2*x;i++) cout<<1<<" ";
		cout<<endl;

		continue;
		}


		int i, j;
		int ram=-1;
		for(i=0;2*i<min(n,m);i++) {
			int st = (n-2*i)/2*(m-2*i)/2 + i;
			if(st < k) break;
			if(st == k) {
				ram = i;
				break;
			}
		}
		if(ram == -1) {
			cout<<"NO"<<endl;
			continue;
		}
		cout<<"YES"<<endl;
		for(i=1;i<=ram;i++) {
			for(j=1;j<=i;j++) cout<<j<<" ";
			for(j=i+1;j<=m-i;j++)  cout<<i<<" ";
			for(j=i;j>=1;j--) cout<<j<<" ";
			cout<<endl;
		}
		int tek = ram+1;
        for(i=ram+1;i<=n-ram;i++) {
			for(j=1;j<=ram;j++) cout<<j<<" ";
			if((i-ram-1)%2 == 0 && i!=ram+1) tek+=(m-2*ram)/2;
			int tt = tek;
			for(j=1;j<=(m-2*ram)/2;j++) {
				cout<<tt<<" "<<tt<<" ";
				tt++;
			}
			for(j=ram;j>=1;j--) cout<<j<<" ";
			cout<<endl;
        }
        for(i=ram;i>=1;i--) {
			for(j=1;j<=i;j++) cout<<j<<" ";
			for(j=i+1;j<=m-i;j++)  cout<<i<<" ";
			for(j=i;j>=1;j--) cout<<j<<" ";
			cout<<endl;
		}

	}


	return 0;
}
