/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Present
* score: 29.0
* date:  2021-12-16 09:26:08.384886
*/
#include <bits/stdc++.h>

using namespace std;
/*ifstream fin("date.in");
ofstream fout("date.out");*/
int n,maxi[1000005],t,k,nr[100005];
int last=1000000;
vector<int> S[1000005];
int invalid=0;
bool f[1000005];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    maxi[0]=0;
    int cur=1;
    int poz=0;
    int lgmax=0;
    for(int i=1;i<=last;i++)
    {
        bool ok=0;
        while(ok==0)
        {
            ok=1;
            if(maxi[poz]==cur)
            {
                poz=0;
                cur++;
            }
            if(S[poz].empty())
            {
                S[i]=S[poz];
                S[i].push_back(cur);
                maxi[i]=cur;
                nr[maxi[i]]++;
                poz++;
                break;
            }
            for(int j=0;j<=maxi[poz];j++)
                f[j]=0;
            for(int j=0;j<S[poz].size();j++)
                f[S[poz][j]]=1;
            for(int j=0;j<S[poz].size();j++)
            {
                int cmmdc=__gcd(S[poz][j],cur);
                if(f[cmmdc]==0)
                {
                    ok=0;
                    break;
                }
            }
            if(ok)
            {
                S[i]=S[poz];
                S[i].push_back(cur);
                maxi[i]=cur;
                nr[maxi[i]]++;
            }
            else
                invalid++;
            poz++;
        }
        lgmax=max(lgmax,(int)S[i].size());
        /*for(auto i:S[i])
            fout<<i<<' ';
        fout<<'\n';*/
    }
    cin>>t;
    while(t--)
    {
        cin>>k;
        cout<<S[k].size()<<' ';
        if(S[k].empty())
        {
            cout<<'\n';
            continue;
        }
        for(auto i:S[k])
            cout<<i<<' ';
        cout<<'\n';
    }
    return 0;
}
