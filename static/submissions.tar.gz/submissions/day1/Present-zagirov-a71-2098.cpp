/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Present
* score: 29.0
* date:  2021-12-16 09:00:11.829745
*/
#include <bits/stdc++.h>

#define pb push_back
#define f first
#define s second

using namespace std;

const int N = 26;
char correct[(1 << N)];
int gcd[N + 1][N + 1];

bool comp(pair<pair<int, int>, int> a, pair<pair<int, int>, int> b){
    return a.f.s < b.f.s;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++)
            gcd[i][j] = __gcd(i, j);
    }
    int t, num, i = 0;
    cin >> t;
    vector<pair<pair<int, int>, int>> vec;
    while(t--){
        cin >> num;
        num--;
        vec.pb({{num, i}, 0});
        i++;
    }
    sort(vec.begin(), vec.end());
    int need_to_ans = 0;
    if (vec[0].f.f == -1){
        vec[0].s = 0;
        need_to_ans++;
    }
    correct[0] = '1';
    int number = 0;
    for (int mask = 1; mask < (1 << N); mask++) {
        int last = 0;
        for (int j = N - 1; j >= 0; j--) {
            if ((1 << j) & mask) {
                last = j;
                break;
            }
        }
        if (correct[mask ^ (1 << last)] == '1') {
            char bl = '1';
            for (int i = 0; i < last; i++) {
                if ((1 << i) & mask) {
                    if (!(mask & (1 << (gcd[i + 1][last + 1] - 1)))) {
                        bl = '0';
                        break;
                    }
                }
            }
            correct[mask] = bl;
            if (bl == '1') {
                if (number == vec[need_to_ans].f.f){
                    vec[need_to_ans].s = mask;
                    need_to_ans++;
                    if (need_to_ans == int(vec.size()))
                        break;
                }
                number++;
            }
        }
    }
    sort(vec.begin(), vec.end(), comp);
    for (auto u : vec){
        vector<int> ans;
        for (int i = 0; i < N; i++){
            if ((1 << i) & u.s){
                ans.pb(i + 1);
            }
        }
        cout << ans.size() << ' ';
        for (auto v : ans)
            cout << v << ' ';
        cout << endl;
    }
}