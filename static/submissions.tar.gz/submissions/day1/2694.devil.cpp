/**
* user:  pavic-9e7
* fname: Patrick
* lname: Pavić
* task:  devil
* score: 0.0
* date:  2019-10-10 09:48:21.730186
*/
#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

#define PB push_back

using namespace std;

const int N = 1e5 + 500;
const int ALP = 12;

int D[ALP], T, K;

string eend, raz[N];
vector < int > sve, pos, tkks[N]; // tko kuda kiki svuda

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cin >> T;
	//T = 1;
	for(;T--;){
		cin >> K;
		D[0] = 0;
		for(int i = 1;i <= 9;i++)
			cin >> D[i];
		//cout << "tu sam\n";
		for(int j = 1;j < 10;j++){
			for(int k = 0;k < D[j];k++) sve.PB(j);
		}
		int lst = sve.back(); sve.pop_back();
		//cout << "tu sam\n";
		for(int i = 0;i <= (int)sve.size() - i - 1;i++){
			cout << sve[((int)sve.size() - i - 1)];
			if(i == (int)sve.size() - i - 1) break;
			cout << sve[i];
		}
		cout << lst << "\n";
		sve.clear();
	}
}
