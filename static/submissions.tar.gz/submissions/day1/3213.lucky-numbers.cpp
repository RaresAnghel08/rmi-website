/**
* user:  kamenov-5bd
* fname: Konstantin
* lname: Kamenov
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:39:15.435447
*/
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int cnts[10];
int digs[1000000];
int main(){
    int t;
    cin>>t;
    while(t--){
        int k;
        cin>>k;
        int to=0;
        for(int i=0;i<10;i++){
            cin>>cnts[i];
            for(int j=0;j<cnts[i];j++)digs[to++]=i;
        }
        sort(digs,digs+k);
        for(int i=0;i<k;i++){
            if(i%2==0){
                    cout<<digs[k-1-i];
            }else{
                cout<<digs[i];
            }
        }
    }
    return 0;
}
