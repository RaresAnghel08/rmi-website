/**
* user:  todoran-200
* fname: Alexandru Raul
* lname: Todoran
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:15:46.141456
*/
/**
 ____ ____ ____ ____ ____
||a |||t |||o |||d |||o ||
||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|

**/

#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

typedef long long ll;

const int N_MAX = 1000;

void setHintLen (int l);
void setHint (int i, int j, bool b);

void assignHints (int subtask, int N, int A[], int B[]) {
    int cnt[N + 2];
    for (int u = 1; u <= N; u++) {
        cnt[u] = 0;
    }
    for (int i = 1; i <= N - 1; i++) {
        cnt[A[i]]++;
        cnt[B[i]]++;
    }
    int root = 1;
    for (int u = 1; u <= N; u++) {
        if (cnt[u] > cnt[root]) {
            root = u;
        }
    }
    setHintLen(20);
    for (int u = 1; u <= N; u++) {
        for (int b = 0; b < 20; b++) {
            setHint(u, b, ((root >> b) & 1));
        }
    }
}

int getLength ();
bool getHint (int j);
bool goTo (int x);

void speedrun (int subtask, int N, int start) {
    int L = getLength();
    int root = 0;
    for (int b = 0; b < 20; b++) {
        root |= (getHint(b) << b);
    }
    goTo(root);
    for (int u = 1; u <= N; u++) {
        goTo(u);
        goTo(root);
    }
}
