/**
* user:  peticaru-505
* fname: Alexandru
* lname: Peticaru
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:37:20.296021
*/
#include <bits/stdc++.h>
#define ll long long
#define ld long double
#include "speedrun.h"

using namespace std;

const ll MOD = 1e9 + 7;
const ll INF = 1e9;

vector<int>G[1002];

void dfs (int nod, int p) {
  for (int k = 0; k < 10; k++)
    setHint(nod, k + 11, ((p & (1 << k)) > 0));
  for (auto it : G[nod])
    if (it != p) {
      dfs(it, nod);
      for (int k = 0; k < 10; k++)
        setHint(nod, k + 1, ((it & (1 << k)) > 0));
    }
}


void assignHints (int subtask, int N, int a[], int b[]) {
  if (subtask == 3) {
    setHintLen(20);
    for (int i = 1; i < N; i++) {
      G[a[i]].push_back(b[i]);
      G[b[i]].push_back(a[i]);
    }
    for (int i = 1; i <= N; i++) {
      if (G[i].size() == 1) {
        dfs(1, 0);
        break;
      }
    }
  }
  
}

int Next () {
  int ans = 0;
  for (int k = 0; k < 10; k++) {
    if (getHint(k + 1))
      ans += (1 << k);
  }
  return ans;
}

int Prev () {
  int ans = 0;
  for (int k = 0; k < 10; k++) {
    if (getHint(k + 11))
      ans += (1 << k);
  }
  return ans;
}


void speedrun (int subtask, int N, int start) {
  if (subtask == 3) {
    while (Next()) {
      int val = Next();
      goTo(val);
      start = val;
    }
    while (Prev()) {
      int val = Prev();
      goTo(val);
      start = val;
    }
  }
}
