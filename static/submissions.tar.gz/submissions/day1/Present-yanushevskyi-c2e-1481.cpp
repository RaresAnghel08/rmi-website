/**
* user:  yanushevskyi-c2e
* fname: Roman
* lname: Yanushevskyi
* task:  Present
* score: 0.0
* date:  2021-12-16 08:00:36.979518
*/
#pragma GCC target ("avx2")
#include <cstdio>
#include <vector>
#include <algorithm>

bool cmp(int a, int b) 
{
	while (a && b) {
		int i = 31 - __builtin_clz(a), j = 31 - __builtin_clz(b);
		if (i != j) return i < j;
		a &= ~(1 << i);
		b &= ~(1 << j);
	}
	if (!b) return 0;
	return 1;
}

const int A = 25;

int mm[A][A];

int main() 
{
	for (int i = 0; i < A; ++i) for (int j = i + 1; j < A; ++j) mm[i][j] = std::__gcd(i + 1, j + 1) - 1;
	std::vector<int> res;
	for (int i = 0; i < 1 << A; ++i) {
		bool ok = 1;
		for (int j = 0; j < A && ok; ++j) if (i >> j & 1) for (int k = j + 1; k < A && ok; ++k) if (i >> k & 1 && i >> mm[j][k] & 1 ^ 1) ok = 0;
		if (ok) res.push_back(i);
	}
	std::sort(res.begin(), res.end(), cmp);
	int t;
	scanf("%d", &t);
	while (t--) {
		int x;
		scanf("%d", &x);
		printf("%d ", __builtin_popcount(res[x]));
		for (int i = 0; i < A; ++i) if (res[x] >> i & 1) printf("%d ", i + 1);
		printf("\n");
	}
	return 0;
}
