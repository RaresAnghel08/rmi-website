/**
* user:  kemanov-48c
* fname: Lachezar
* lname: Kemanov
* task:  restore
* score: 7.0
* date:  2019-10-10 09:53:44.419258
*/
#include<iostream>
using namespace std;
int arr[20];
int n,m;
bool t=false;
struct query
{
    int l,r,x,v;
};
query q[202];
bool checkArr()
{
    for(int a=0; a<m; a++)
    {
        int o=0,z=0;
        for(int b=q[a].l; b<=q[a].r; b++)
        {
            if(arr[b]==0)z++;
            else o++;
        }
        ///cout<<a<<" "<<z<<" "<<o<<endl;
        if(q[a].v==0 && z<q[a].x)
            return false;
        if(q[a].v==1 && z>=q[a].x)
            return false;
    }
    return true;
}
void createArr(int pos)
{
    if(t==true)
        return;
    if(pos==n)
    {
        /**for(int a=0; a<n; a++)
            cout<<arr[a];
        cout<<endl;*/
        if(checkArr())
        {
            for(int a=0; a<n-1; a++)
                cout<<arr[a]<<" ";
            cout<<arr[n-1]<<endl;
            t=true;
        }
        return;
    }
    arr[pos]=0;
    createArr(pos+1);
    arr[pos]=1;
    createArr(pos+1);
    return;
}

int main()
{
    cin>>n>>m;
    for(int a=0; a<m; a++)
    {
        cin>>q[a].l>>q[a].r>>q[a].x>>q[a].v;
    }
    createArr(0);
    if(t==false)
        cout<<-1<<endl;
    return 0;
}
