/**
* user:  popp-36b
* fname: Iancu Alexandru
* lname: Popp
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:08:08.796546
*/
#include "speedrun.h"
#include <vector>
#include <cassert>

using namespace std;

void assignHints(int subtask, int n, int a[], int b[]) {
 if (subtask == 1) {
    setHintLen(n);
    for (int i = 1; i <= n - 1; ++i) {
      setHint(a[i], b[i], true);
      setHint(b[i], a[i], true);
    }
  } else if (subtask == 2) {
    setHintLen(10);
    vector<int> grad(n, 0);
    for (int i = 1; i <= n - 1; ++i)
      ++grad[a[i]], ++grad[b[i]];
    int centru = -1;
    for (int i = 1; i <= n; ++i)
      if (grad[i] > 1) {
        centru = i;
        break;
      }
    for (int i = 1; i <= n; ++i)
      for (int j = 1; j <= 10; ++j)
        if (centru & (1 << (j - 1)))
          setHint(i, j);
  }
}

void speedrun(int subtask, int n, int start) {
  vector<bool> vis(n + 1, false);
  vector<int> tata(n + 1, 0);
  int nod = start, cnt = 1;
  if (subtask == 1) {
  vis[nod] = true;
    while (cnt < n) {
      vis[nod] = true;
      int nxt = -1;
      for (int i = 1; i <= n; ++i) {
        if (!getHint(i)) continue;
        if (vis[i] || i == nod) continue;
        nxt = i;
        break;
      }
      if (nxt != -1) {
        ++cnt;
        assert(goTo(nxt) == true);
        tata[nxt] = nod;
        nod = nxt;
        vis[nod] = true;
      } else {
        goTo(tata[nod]);
        nod = tata[nod];
        vis[nod] = true;
      }
    }
  } else if (subtask == 2) {
    int centru = 0;
    for (int i = 1; i <= 10; ++i)
      if (getHint(i))
        centru += (1 << (i - 1));
    if (nod != centru) {
      goTo(centru);
      vis[nod] = true;
    }
    for (int i = 1; i <= n; ++i)
      if (i != nod && !vis[i]) {
        goTo(i);
        goTo(centru);
      }
  }
}
