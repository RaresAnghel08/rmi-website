/**
* user:  bengin-61a
* fname: Jovan
* lname: Bengin
* task:  restore
* score: 13.0
* date:  2019-10-10 06:18:25.740307
*/
#include <bits/stdc++.h>
using namespace std;

int l[10005];
int r[10005];
int k[10005];
int val[100005];
int mora[100005];

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int n, m;
    cin >> n >> m;
    for(int i=1; i<=m; i++){
        cin >> l[i] >> r[i] >> k[i] >> val[i];
        if(val[i]){
            for(int j=l[i]; j<=r[i]; j++){
                mora[j] = 1;
            }
        }
    }
    for(int i=1; i<=m; i++){
        if(val[i] == 0){
            bool ima = 0;
            for(int j=l[i]; j<=r[i]; j++){
                if(!mora[j]) ima = 1;
            }
            if(!ima){
                cout << -1;
                return 0;
            }
        }
    }
    for(int i=0; i<n; i++){
        cout << mora[i] << " ";
    }
    return 0;
}
