/**
* user:  suleymanov-b26
* fname: Karam
* lname: Suleymanov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:33:05.119107
*/
#include <vector>

void setHintLen(int l);

void setHint(int i, int j, bool b);

void assignHints(int subtask, int N, int A[], int B[]) {
    if (subtask == 1) {
        setHintLen(N);
        for (int i = 0; i < N; i++) {
            setHint(A[i] - 1, B[i] - 1, true);
            setHint(B[i] - 1, A[i] - 1, true);
        }
    }
}

int getLength();

bool getHint(int j);

bool goTo(int x);

void dfs(int v, int p, std::vector<bool> &used) {
    used[v] = true;
    int l = getLength();
    for (int u = 0; u < l; u++) {
        if (getHint(u)) {
            goTo(u + 1);
            dfs(u, v, used);
        }
    }
    if (p == -1) {
        return;
    }
    goTo(p + 1);
}

void speedrun(int subtask, int N, int start) {
    if (subtask == 1) {
        std::vector<bool> used(N);
        dfs(0, -1, used);
    }
}
