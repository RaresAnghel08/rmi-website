/**
* user:  calota-e12
* fname: Andrei
* lname: Calotă
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:48:03.045928
*/
void assignHints ( int subtask , int N , int A [] , int B []) {
    setHintLen ( N );
    vector<int> arb[1 + N];
    for ( i = 1; i <= N; i ++ )
       setHint ( A[i], B[i], 1 );
}

bool visited[1 + N];
void dfs ( int root ) {
    visited[root] = true;
    for ( int node = 1; node <= root; node ++ ) {
       bool get = getHint ( node );
       if ( get == true && !visited[node] )
         dfs ( node );
    }
}
void speedrun ( int subtask , int N , int start ) {
    int l = getLenght ();
    dfs ( start );
}
