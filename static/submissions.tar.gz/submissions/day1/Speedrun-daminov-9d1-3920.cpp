/**
* user:  daminov-9d1
* fname: Kamil
* lname: Daminov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:47:43.483238
*/
#include <bits/stdc++.h>
using namespace std;

void solve() {
    int n, m, k; cin >> n >> m >> k;

    if (n % 2 != 0 || m % 2 != 0 || k * 4 > n * m || k < max(n, m) / 2) {
        cout << "NO\n";
        return;
    }

    if (n == 2) {
        cout << "YES\n";
        int c = 1;
        for (int i = 0; i < m; i++) {
            cout << c << " ";
            c += i % 2;
        }
        cout << "\n";
        c = 1;
        for (int i = 0; i < m; i++){
            cout << c << " ";
            c += i % 2;
        }
        cout << "\n";
        return;
    }

    if (n == 4) {
        for (int i = 0; i <= m; i += 2){
            if (i == k || (m - i) >= 4 && ((m - i) / 2) + i == k){
                int ans[n][m];
                int c = 1;
                for (int j = 0; j < i; j+=2){
                    ans[0][j] = ans[0][j + 1] = ans[1][j] = ans[1][j + 1] = c++;
                    ans[2][j] = ans[2][j + 1] = ans[3][j] = ans[3][j + 1] = c++;
                }

                for (int j = i; j < m;){
                    if (j + 6 == m) {
                        ans[0][j] = ans[0][j + 1] = ans[0][j + 2] = ans[0][j + 3] = ans[0][j + 4] = ans[0][j + 5] = c;
                        ans[1][j] = ans[1][j + 5] = c;
                        ans[2][j] = ans[2][j + 5]= c;
                        ans[3][j] = ans[3][j + 1] = ans[3][j + 2] = ans[3][j + 3] = ans[3][j + 4] = ans[3][j + 5] = c++;
                        ans[1][j + 1] = ans[1][j + 2] = ans[2][j + 1] = ans[2][j + 2] = c++;
                        ans[1][j + 3] = ans[1][j + 4] = ans[2][j + 3] = ans[2][j + 4] = c++;
                        j += 6;
                    }
                    else {
                        ans[0][j] = ans[0][j + 1] = ans[0][j + 2] = ans[0][j + 3] = c;
                        ans[1][j] = ans[1][j + 3] = c;
                        ans[2][j] = ans[2][j + 3] = c;
                        ans[3][j] = ans[3][j + 1] = ans[3][j + 2] = ans[3][j + 3] = c++;
                        ans[1][j + 1] = ans[1][j + 2] = c;
                        ans[2][j + 1] = ans[2][j + 2] = c++;
                        j += 4;
                    }
                }

                cout << "YES\n";
                for (int i1 = 0; i1 < n; i1++){
                    for (int j = 0; j < m; j++){
                        cout << ans[i1][j] << " ";
                    }
                    cout << "\n";
                }
                return;
            }
        }
    }
}


int main() {
    int t; cin >> t;
    while (t--) solve();
    return 0;
}