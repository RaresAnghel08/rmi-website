/**
* user:  weber-eb0
* fname: Daniel
* lname: Weber
* task:  Speedrun
* score: 63.0
* date:  2021-12-16 07:40:38.096845
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define vll vector<ll>
#define vvll vector<vll>

void dfs(vvll& graph, vll& parent, ll node, ll par) {
    // cout << "dfs node " << node << endl;
    parent[node] = par;
    for (ll f : graph[node]) {
        // cout << "friend " << f << " of " << node << endl;
        if (parent[f] == -1)
            dfs(graph, parent, f, node);
    }
}

void setbits(ll i, ll val, ll offset) {
    // cout << "setting " << i << " to " << val << " offset " << offset << endl;
    for (ll j = 0; j < 10; j++) {
        if (val & (1 << j)) {
            setHint(i+1, offset+j+1, true);
        }
    }
}

ll getbits(ll offset) {
    ll val = 0;
    for (ll j = 0; j < 10; j++) {
        if (getHint(offset + j + 1)) {
            // cout << "bit " << j << endl;
            val |= 1 << j;
        }
    }
    return val;
}

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    setHintLen(30);
    vvll graph(N);
    for (ll i = 1; i < N; i++) {
        // cout << A[i] << ' ' << B[i] << endl;
        graph[A[i]-1].push_back(B[i]-1);
        graph[B[i]-1].push_back(A[i]-1);
    }
    // cout << "s1" << endl;
    vll parent(N, -1);
    dfs(graph, parent, 0, 1023);
    // cout << parent[0] << endl;
    // cout << "s2" << endl;
    vvll sons(N);
    for (ll i = 0; i < N; i++) {
        // cout << parent[i] << endl;
        if (parent[i] != 1023)
            sons[parent[i]].push_back(i);
    }
    // cout << "s3" << endl;
    vll brother(N, 1023);
    for (ll i = 0; i < N; i++) {
        for (ll j = 0; j + 1 < sons[i].size(); j++) {
            brother[sons[i][j]] = sons[i][j+1];
        }
    }
    // cout << "s4" << endl;
    for (ll i = 0; i < N; i++) {
        setbits(i, parent[i], 0);
        if (sons[i].empty())
            setbits(i, 1023, 10);
        else
            setbits(i, sons[i][0], 10);
        setbits(i, brother[i], 20);
    }
    // cout << "s5" << endl;
}

ll visit_subtree(ll v) {
    ll node = getbits(10);
    while (node != 1023) {
        goTo(node+1);
        node = visit_subtree(node);
        goTo(v+1);
    }
    return getbits(20);
}

void speedrun(int subtask, int N, int start) { /* your solution here */
    while (1) {
        ll parent = getbits(0);
        // cout << parent << endl;
        if (parent == 1023) break;
        goTo(parent+1);
    }
    visit_subtree(0);
}