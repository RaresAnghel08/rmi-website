/**
* user:  stancu-88b
* fname: Sergiu Nicolae
* lname: Stancu
* task:  Present
* score: 29.0
* date:  2021-12-16 08:55:12.672399
*/
#include <bits/stdc++.h>
#define nl '\n'
#define pb push_back
using namespace std;
const int NMAX = 1e6 + 1;
bool ans[NMAX][30];
int lg[NMAX];
int gcd[100][100];
void precalcGCD ( int nr )
{
    for ( int j = 1; j <= nr; j++ )
        for ( int k = 1; k <= nr; k++ )
            gcd[j][k] = __gcd ( j, k );
}
int mxcrt[50];
void precalculare ( int N )
{
    ans[1][1] = 1;
    lg[1] = 1;
    int maxcrt = 1;

    for ( int i = 2; i <= N; i++ )
    {
        if ( lg[i - 1] == maxcrt )
        {
            lg[i] = 1;
            maxcrt++;
            ans[i][maxcrt] = 1;
            mxcrt[maxcrt]++;
            continue;
        }

        mxcrt[maxcrt]++;

        for ( int j = 1; j < maxcrt; j++ )
            if ( ans[i - 1][j] == 0 )
            {
                ans[i][j] = 1;
                lg[i]++;

                for ( int k = j + 1; k <= maxcrt; k++ )
                    if ( ans[i - 1][k] )
                        if ( ans[i][gcd[k][j]] == 0 )
                        {
                            lg[i]++;
                            ans[i][gcd[k][j]] = 1;
                        }

                for ( int k = j + 1; k <= maxcrt; k++ )
                    if ( ans[i - 1][k] )
                    {
                        ans[i][k] = 1;
                        lg[i]++;

                        if ( ans[i][gcd[j][k]] == 0 )
                        {
                            ans[i][gcd[j][k]] = 1;
                            lg[i]++;
                        }

                        for ( int l = k + 1; l <= maxcrt; l++ )
                            if ( ans[i - 1][l] )
                            {
                                if ( ans[i][gcd[l][k]] == 0 )
                                {
                                    ans[i][gcd[l][k]] = 1;
                                    lg[i]++;
                                }
                            }
                    }

                break;
            }

        for ( int k = 1; k <= maxcrt; k++ )
            if ( ans[i][k] )
                for ( int l = k + 1; l <= maxcrt; l++ )
                    if ( ans[i][l] )
                    {
                        if ( !ans[i][gcd[k][l]] )
                        {
                            lg[i]++;
                            ans[i][gcd[k][l]] = 1;
                        }
                    }
    }
}
int main()
{
    int T;
    cin >> T;
    precalcGCD ( 50 );
    precalculare ( NMAX - 1 );

    while ( T-- )
    {
        int K;
        cin >> K;

        if ( K == 0 )
        {
            cout << 0 << nl;
            continue;
        }

        cout << lg[K]  << ' ';

        for ( int i = 1; i < 27; i++ )
            if ( ans[K][i] )
                cout << i << ' ';

        cout << nl;
    }

    return 0;
}
