/**
* user:  andreescu-216
* fname: Mihnea
* lname: Andreescu
* task:  Gardening
* score: 100.0
* date:  2021-12-16 08:44:25.470278
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

const int INF = (int) 1e9;

int getmx(int n, int m) {
  if (n % 2 || m % 2) return -INF;
  if (n == 0 || m == 0) return 0;
  return n * m / 4;
}

int getmn(int n, int m) {
  if (n % 2 || m % 2) return +INF;
  if (n == 0 || m == 0) return 0;
  if (n > m) {
    swap(n, m);
  }
  assert(n <= m);
  int cnt = n / 2 - 1;
  return cnt + (m - 2 * cnt) / 2;
}

int getmx(int r1, int c1, int r2, int c2) {
  assert((r2 - r1 + 1) % 2 == 0);
  assert((c2 - c1 + 1) % 2 == 0);
  return getmx(r2 - r1 + 1, c2 - c1 + 1);
}

int getmn(int r1, int c1, int r2, int c2) {
  assert((r2 - r1 + 1) % 2 == 0);
  assert((c2 - c1 + 1) % 2 == 0);
  return getmn(r2 - r1 + 1, c2 - c1 + 1);
}

bool isok(int r1, int c1, int r2, int c2, int k) {
  int mn = getmn(r1, c1, r2, c2);
  int mx = getmx(r1, c1, r2, c2);
  if (mn <= k && k <= mx) {
    if (k == mn || k == mx) {
      return 1;
    }
    if (k == mx - 1) {
      return 0;
    }
    int R = r2 - r1 + 1;
    int C = c2 - c1 + 1;
    R /= 2;
    C /= 2;
    if (k == mn + 1) {
      if (R == C || min(R, C) == 1) {
        return 0;
      } else {
        return 1;
      }
    }
    return 1;
  }
  return 0;
}

int y;
vector<vector<int>> sol;

void split(int r1, int c1, int r2, int c2, int k) {
  assert(isok(r1, c1, r2, c2, k));
  if (k == getmx(r1, c1, r2, c2)) {
    for (int i = r1; i <= r2; i += 2) {
      for (int j = c1; j <= c2; j += 2) {
        y++;
        sol[i][j] = y;
        sol[i][j + 1] = y;
        sol[i + 1][j + 1] = y;
        sol[i + 1][j] = y;
      }
    }
    return;
  }
  if (getmn(r1 + 1, c1 + 1, r2 - 1, c2 - 1) <= k - 1 && k - 1 <= getmx(r1 + 1, c1 + 1, r2 - 1, c2 - 1) && isok(r1 + 1, c1 + 1, r2 - 1, c2 - 1, k - 1)) {
    y++;
    for (int i = r1; i <= r2; i++) {
      sol[i][c1] = sol[i][c2] = y;
    }
    for (int i = c1; i <= c2; i++) {
      sol[r1][i] = sol[r2][i] = y;
    }
    split(r1 + 1, c1 + 1, r2 - 1, c2 - 1, k - 1);
    return;
  }
  /// split pe rand
  for (int r = r1 + 1; r < r2; r += 2) {
    int mn1 = getmn(r1, c1, r, c2), mn2 = getmn(r + 1, c1, r2, c2);
    int mx1 = getmx(r1, c1, r, c2), mx2 = getmx(r + 1, c1, r2, c2);
    if (mn1 + mn2 <= k && k <= mx1 + mx2) {
      for (int cnt1 = mn1; cnt1 <= mx1; cnt1++) {
        int cnt2 = k - cnt1;
        if (mn2 <= cnt2 && cnt2 <= mx2) {
          if (isok(r1, c1, r, c2, cnt1) && isok(r + 1, c1, r2, c2, cnt2)) {
            split(r1, c1, r, c2, cnt1);
            split(r + 1, c1, r2, c2, cnt2);
            return;
          }
        }
      }
    }
  }
  /// split pe coloana
  for (int c = c1 + 1; c < c2; c += 2) {
    int mn1 = getmn(r1, c1, r2, c), mn2 = getmn(r1, c + 1, r2, c2);
    int mx1 = getmx(r1, c1, r2, c), mx2 = getmx(r1, c + 1, r2, c2);
    if (mn1 + mn2 <= k && k <= mx1 + mx2) {
      for (int cnt1 = mn1; cnt1 <= mx1; cnt1++) {
        int cnt2 = k - cnt1;
        if (mn2 <= cnt2 && cnt2 <= mx2) {
          if (isok(r1, c1, r2, c, cnt1) && isok(r1, c + 1, r2, c2, cnt2)) {
            split(r1, c1, r2, c, cnt1);
            split(r1, c + 1, r2, c2, cnt2);
            return;
          }
        }
      }
    }
  }
  assert(0);
}
void solve(int n, int m, int k) {
  y = 0;
  sol.clear();
  if (n % 2 == 1 || m % 2 == 1) {
    cout << "NO\n";
    return;
  }
  if (!isok(1, 1, n, m, k)) {
    cout << "NO\n";
    return;
  }
  sol.resize(n + 1, vector<int> (m + 1, -1));
  split(1, 1, n, m, k);
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= m; j++) {
      if (sol[i][j] == -1) {
        cout << "NO\n";
        return;
      }
    }
  }
  cout << "YES\n";
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= m; j++) {
      cout << sol[i][j] << " ";
    }
    cout << "\n";
  }
}


void genall() {
  freopen ("input", "w", stdout);
  vector<vector<int>> sol;
  for (int i = 1; i <= 8; i++) {
    for (int j = 1; j <= 8; j++) {
     // if (i != j) continue;
      for (int k = 1; k <= i * j; k++) {
        sol.push_back({i, j, k});
      }
    }
  }
  cout << (int) sol.size() << "\n";
  for (auto &v : sol) {
    for (auto &x : v) {
      cout << x << " ";
    }
    cout << "\n";
  }
  exit(0);
}
/*
pot 2, 4, dar pot 3? : nu

? ? ? ?
? ? ? ?
? ? ? ?
? ? ? ?

4 * k1 + 4 * k2 + 4 * k3 = 16
k1 + k2 + k3 = 16 / 4
k1 + k2 + k3 = 4

1 1
1 1 => 4 = 4 * 1

1 1 1 1
1 ? ? 1
1 ? ? 1
1 1 1 1 => 12 = 4 * 3


1 1 1 1 1 1
1 ? ? ? ? 1
1 ? ? ? ? 1
1 ? ? ? ? 1
1 ? ? ? ? 1
1 1 1 1 1 1 => 20 = 4 * 5

1 1 1 1
1 ? ? 1
1 ? ? 1
1 ? ? 1
1 ? ? 1
1 1 1 1 => 16
*/

signed main() {
  ios::sync_with_stdio(0); cin.tie(0);

 // genall();


  ///6 6 : 3 5 6 7 9

  int t;
  cin >> t;
  while (t--) {
    int n, m, k;
    cin >> n >> m >> k;
    solve(n, m, k);
  }


  return 0;
}
/**

n = 4
m = 6

? ? ? ? ? ?
? ? ? ? ? ?
? ? ? ? ? ?
? ? ? ? ? ?

**/

/*
2 2 2 2 1 1
2 3 3 2 1 1
2 3 3 2 2 2
2 4 4 5 5 2
2 4 4 5 5 2
2 2 2 2 2 2


1 1 1 1 2 2 2 2
1 6 6 1 2 5 5 2
1 6 6 1 2 5 5 2
1 7 7 1 2 2 2 2
1 7 7 1 3 3 3 3
1 8 8 1 3 4 4 3
1 8 8 1 3 4 4 3
1 1 1 1 3 3 3 3

1 1 1 1 1 1 1 1
1 2 2 2 2 2 2 1
1 2 3 3 4 4 2 1
1 2 3 3 4 4 2 1
1 2 6 6 5 5 2 1
1 2 6 6 5 5 2 1
1 2 2 2 2 2 2 1
1 1 1 1 1 1 1 1



1 1 1 1 1 1 1 1
1 ? ? ? ? ? ? 1
1 ? ? ? ? ? ? 1
1 ? ? ? ? ? ? 1
1 ? ? ? ? ? ? 1
1 ? ? ? ? ? ? 1
1 ? ? ? ? ? ? 1
1 1 1 1 1 1 1 1
*/
