/**
* user:  patrushava-e4f
* fname: Hanna
* lname: Patrushava
* task:  Present
* score: 29.0
* date:  2021-12-16 11:06:39.750682
*/
#pragma GCC optimize ("unroll-loops")
#pragma GCC optimize ("Ofast")
#include <bits/stdc++.h>

#define f first
#define s second
#define pb push_back
#define pii pair<int, int>
#define ll long long

using namespace std;

vector < int > a;


int c[100];
int now = 1;
bool good()
{
    now++;
    for (auto to: a) c[to] = now;
    int n = (int)a.size();
    for (int i = 0; i < n; i++)
    for (int j = i + 1; j < n; j++)
    {
        int x = __gcd(a[i], a[j]);
        if (c[x] != now) return false;
    }
    return true;
}


bool ssort(vector < int > a, vector < int > b)
{
    if (a == b) return false;

    int ma1 = -1e9;
    int ma2 = ma1;
    for (auto to: a) ma1 = max(ma1, to);
    for (auto to: b) ma2 = max(ma2, to);

    int l = (int)a.size() - 1, r = (int)b.size() - 1;
    while (l >= 0 && r >= 0 && a[l] == b[r])
    {
        l--;
        r--;
    }

    if (l >= 0 && r >= 0)
    return a[l] < b[r];
    return (l == -1);
}

int32_t main() {

#ifdef LOCAL
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
#endif // LOCAL

    ios_base::sync_with_stdio();
    cin.tie(0);
    cout.tie(0);
    int k = 25;
    vector < vector < int > > res;
    res.pb({});

    for (int c = 1; c <= k; c++)
    {
        int m = (int)res.size();
        for (int i = 0; i < m && (int)res.size() < 1000000; i++)
        {
            a = res[i];
            a.pb(c);
            if (good() == true) res.pb(a);
        }
    }


    int t;
    cin >> t;

    while (t--)
    {
        int nom;
        cin >> nom;

        cout << res[nom].size() << " ";
        for (auto to: res[nom]) cout << to << ' ';
        cout << "\n";
    }

    return 0;
}
