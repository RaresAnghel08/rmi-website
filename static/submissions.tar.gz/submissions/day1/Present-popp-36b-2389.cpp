/**
* user:  popp-36b
* fname: Iancu Alexandru
* lname: Popp
* task:  Present
* score: 29.0
* date:  2021-12-16 09:28:42.312202
*/
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int N = 1e6 + 5;
const int M = 25;

vector<vector<bool>> s;

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr), cout.tie(nullptr);
  vector<bool> s0(M, 0);
  s.push_back(s0);
  vector<bool> s1(M, 0);
  s1[1] = true;
  s.push_back(s1);
  for (int i = 2; i <= M; ++i) {
    vector<vector<bool>> add;
    for (auto& ss: s) {
      bool ok = true;
      for (int j = 1; j < M; ++j)
        if (ss[j] && !ss[__gcd(i, j)]) {
          ok = false;
          break;
        }
      if (ok) {
        add.push_back(ss);
        add.back()[i] = true;
      }
    }
    for (auto& ss: add)
      s.push_back(ss);
  }
  int q;
  cin >> q;
  while (q--) {
    int n;
    cin >> n;
    if (n == 0)
      cout << "0\n";
    else {
      vector<int> ans;
      for (int i = 1; i < M; ++i)
        if (s[n][i])
          ans.push_back(i);
      cout << ans.size();
      for (auto i: ans)
        cout << " " << i;
      cout << "\n";
    }
  }
  return 0;
}
