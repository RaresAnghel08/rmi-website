/**
* user:  dekany-ab1
* fname: Csaba
* lname: Dékány
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:45:55.687895
*/
#include "speedrun.h"


void assignHints(int subtask, int N, int A[], int B[]) {
   /* if(subtask==1)
    {
        setHintLen(N);
        for(int i=1;i<=N-1;i++)
        {
            setHint(A[i],B[i],1);
            setHint(B[i],A[i],1);
        }

    }
    else if(subtask==2)
    {
          setHintLen(10);
        int hany[N+1]={0};
       /* int log[N+1]={0};
        for(int i=1;i<N+1;i++)
        {
            log[i]=log[i/2]+1;
        }*/
      /*   int hatvany[10]={0};
        hatvany[0]=1;
        for(int i=1;i<10;i++)
        {
            hatvany[i]=2*hatvany[i-1];
        }

        int x=0;
        for(int i=1;i<=N-1;i++)
        {
            hany[A[i]]++;
            hany[B[i]]++;
            if(hany[A[i]]>1)
            {
                x=A[i];
                break;
            }
            else if(hany[B[i]]>1)
            {
                x=B[i];
                break;
            }
        }
        bool xhez[11]={0};
        int j=9;
        while(x!=0)
        {
            if(x/hatvany[j]>=1)
            {
                x=x-hatvany[j];
                xhez[j+1]=1;
            }
            j--;
        }
        for(int i=1;i<N+1;i++)
        {
            if(i==x)
            {

            }
            else{
                    for(j=1;j<11;j++)
                    {
                        if(xhez[j]==1)
                        {
                            setHint(i,j,1);
                        }

                    }
            }

        }

    }
    else*/ if(subtask==3)
    {
        setHintLen(20);
        int hatvany[10]={0};
        int a,b;
        int d=0;
        hatvany[0]=1;
        for(int i=1;i<10;i++)
        {
            hatvany[i]=2*hatvany[i-1];
        }
         bool volt[N+1]={0};
        for(int i=1;i<=N-1;i++)
        {
            a=A[i];
            b=B[i];
            int j=9;
            if(volt[B[i]]==1)
            {
                d=10;
            }
            else{
                d=0;
            }
        while(a!=0)
        {
            if(a/hatvany[j]>=1)
            {
                a=a-hatvany[j];
                setHint(B[i],j+1+d,1);
            }
            j--;
        }
        j=9;
        if(volt[A[i]]==1)
            {
                d=10;
            }
            else{
                d=0;
            }
         while(b!=0)
        {
            if(b/hatvany[j]>=1)
            {
                b=b-hatvany[j];
                setHint(A[i],j+1+d,1);
            }
            j--;
        }
        volt[A[i]]=1;
        volt[B[i]]=1;

        }

    }


}




 void melyseg(int p, int x, int l)
    {
          goTo(x);
        for(int i=1;i<=l;i++)
        {
            if(getHint(i)==true && i!=p)
            {
                melyseg(x,i,l);
                goTo(x);
            }
        }

    }
int melyseg2(int p, int x, int l, int A[], int keresett)
{
    goTo(x);
   int a=0, b=0;
        for(int i=1;i<=l-10;i++)
        {
            if(getHint(i)==true)
            {
                a=a+A[i-1];

            }
        }
        for(int i=11;i<=l;i++)
        {
            if(getHint(i)==true)
            {
                b=b+A[i-1-11];

            }
        }
        if(a!=p && a!=0)
        {
                 melyseg2(x,a,l,A,keresett);
        }
        else if(b!=p && b!=0)
        {

                 melyseg2(x,b,l,A,keresett);
        }
        else{
            return x;
        }
        return -1;

}

void speedrun(int subtask, int N, int start) {
    int l=getLength();
    /*if(subtask==1)
    {
       melyseg(0,start,l);
    }
    else if (subtask==2)
    {
         int hatvany2[10]={0};
        hatvany2[0]=1;
        for(int i=1;i<10;i++)
        {
            hatvany2[i]=2*hatvany2[i-1];
        }
        bool kezd=1;
        int csucs=0;
        for(int i=1;i<=l;i++)
        {
            if(getHint(i)==true)
            {
                kezd=0;
                csucs=csucs+hatvany2[i-1];

            }
        }
        if(kezd==0)
        {
            goTo(csucs);
        }
        for(int i=1;i<N+1;i++)
        {
            if(i!=csucs && i!=start)
            {
                goTo(i);
                goTo(csucs);
            }
        }


    }
    else */if(subtask==3)
    {
        bool volt[N+2]={0};
        int hatvany2[10]={0};
        int keres=-1;
        int kovi=0;
        hatvany2[0]=1;
        for(int i=1;i<10;i++)
        {
            hatvany2[i]=2*hatvany2[i-1];
        }
        kovi=melyseg2(-1,start,l,hatvany2,keres);
        melyseg2(-1,kovi,l,hatvany2,keres);
       // melyseg2(-1,keres,l,hatvany2,-2);
    }


}
