/**
* user:  ruslanov-d88
* fname: Aktan
* lname: Ruslanov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:43:09.912924
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;
main(){
	int t;
	cin >> t;
	while(t--){
		int n,m,k;
		cin >> n >> m >> k;
		if((n*m)/4>=k && n>1 && m>1){
			if((n*m)/4==k && (n*m)%4!=0){
				cout << "NO" << endl;
				continue;
			}
			cout << "YES" << endl;
			int ans=1,l=ans;
			for(int j=0;j<n;j++){
				int l=ans;
				for(int i=0;i<m;i++){
					if(i%2==0 && i!=0 && l<k && i!=m-1){
						l++;
					}
				cout << l << " ";
			    }
			    cout << endl;
			    if(j%2==1){
			    	if(l<k){
			    		ans=l+1;
					}
					else{
						ans=l;
					}
				}
			}
		}
		else{
			cout << "NO" << endl;
		}
	}
}
