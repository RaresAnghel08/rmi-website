/**
* user:  idiriz-fcd
* fname: Nermin Hyusmen
* lname: Idiriz
* task:  Present
* score: 8.0
* date:  2021-12-16 10:55:41.775398
*/
#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
vector<int>v;
int a[9];
struct red
{
    int a1,a2,a3,a4,a5,a6,a7,a8;
    red() {};
    red(int _a1,int _a2,int _a3,int _a4,int _a5,int _a6,int _a7,int _a8)
    {
        a1=_a1;
        a2=_a2;
        a3=_a3;
        a4=_a4;
        a5=_a5;
        a6=_a6;
         a7=_a7;
          a8=_a8;
    }
    void print()
    {
        cout<<a1<<" "<<a2<<" "<<a3<<" "<<a4<<" "<<a5<<" "<<a6<<" "<<a7<<" "<<a8<<endl;
    }
};
vector<red>r;
int cnt=0;
void check()
{
    for(int i=1;i<=8;i++)
    {
        for(int j=i+1;j<=8;j++)
        {
            if(a[i]!=-1&&a[j]!=-1)
            {
                int nod=__gcd(a[i],a[j]);
                bool found=false;
                for(int s=1;s<=8;s++)
                {
                    if(a[s]==nod){
                           found=true;
                    }
                }
                if(found==false)return;
            }
        }
    }
cnt++;
        r.push_back(red(a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8]));
        return;
}
void gen(int pos,int prev)
{
    if(pos>8)
    {
        check();
        return;
    }
    for(int i=0; i<v.size(); i++)
    {
        if(v[i]>prev||(prev==-1&&i==0))
        {
            a[pos]=v[i];
            gen(pos+1,v[i]);
            a[pos]=0;
        }
    }
}
void print_r()
{
    for(int i=0; i<cnt; i++)
    {
        cout<<i<<endl;
        r[i].print();
    }
}
bool cmp(red r1,red r2)
{
    if(r1.a8!=r2.a8)
    {
        return (r1.a8<r2.a8);
    }
    if(r1.a7!=r2.a7)
    {
        return (r1.a7<r2.a7);
    }
    if(r1.a6!=r2.a6)
    {
        return (r1.a6<r2.a6);
    }
    if(r1.a5!=r2.a5)
    {
        return (r1.a5<r2.a5);
    }
    if(r1.a4!=r2.a4)
    {
        return (r1.a4<r2.a4);
    }
    if(r1.a3!=r2.a3)
    {
        return (r1.a3<r2.a3);
    }
    if(r1.a2!=r2.a2)
    {
        return (r1.a2<r2.a2);
    }

    if(r1.a1!=r2.a1)
    {
        return (r1.a1<r2.a2);
    }



}
void print_answer(int k)
{
    vector<int>ans;
    int cnt=0;
    if(r[k].a1!=-1)
    {
        cnt=1;
        ans.push_back(r[k].a1);
    }
    if(r[k].a2!=-1)
    {
        ans.push_back(r[k].a2);
    }
    if(r[k].a3!=-1)
    {
        ans.push_back(r[k].a3);
    }
    if(r[k].a4!=-1)
    {
        ans.push_back(r[k].a4);
    }
    if(r[k].a5!=-1)
    {
        ans.push_back(r[k].a5);
    }
    if(r[k].a6!=-1)
    {
        ans.push_back(r[k].a6);
    }
    if(r[k].a7!=-1)
    {
        ans.push_back(r[k].a7);
    }
    if(r[k].a8!=-1)
    {
        ans.push_back(r[k].a8);
    }
    cout<<ans.size()<<" ";
    for(int i=0; i<ans.size(); i++)
        cout<<ans[i]<<" ";
    cout<<endl;
}
int main()
{
    v.push_back(-1);
    v.push_back(1);
    v.push_back(2);
    v.push_back(3);
    v.push_back(4);
    v.push_back(5);
    v.push_back(6);
    v.push_back(7);
    v.push_back(8);
    gen(1,-1);
    //print_r();
    sort(r.begin(),r.end(),cmp);
    //print_r();
    int t;
    cin>>t;
    while(t--)
    {
        int x;
        cin>>x;
        print_answer(x);
    }
    return 0;
}
