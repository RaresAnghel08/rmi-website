/**
* user:  jianu-4fe
* fname: Ioana
* lname: Jianu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:32:33.216340
*/
#include <bits/stdc++.h>

using namespace std;

const int NMAX = 6;
const int MMAX = 2e5+5;

int a[NMAX][MMAX];

int cul, n, m;

void divide(int st, int k) {
    int lung = (m - st + 1);
    int kmin = lung / 2;
    if (k == kmin) {
        /// bordare
        for (int i = 2; i <= 3; i++)
            a[i][st] = a[i][m] = cul;
        for (int j = st; j <= m; j++)
            a[1][j] = a[4][j] = cul;
        cul++;
        for (int j = st + 1; j < m; j+=2) {
            a[2][j] = a[3][j] = a[2][j + 1] = a[3][j + 1] = cul;
            cul++;
        }
        return;
    }
    for (int i = 1; i <= 3; i += 2) {
        a[i][st] = a[i][st + 1] = a[i + 1][st] = a[i + 1][st + 1] = cul;
        cul++;
    }
    divide(st + 2, k - 2);
}

void solve (int k) {
    cul = 1;
    if (n % 2 == 1 || m % 2 == 1) {
        cout << "NO\n";
        return;
    }
    if (n == 2) {
        if (k != m / 2) {
            cout <<"NO\n";
            return;
        }

        cout << "YES\n";
        for (int i = 1; i <= m; i+=2) {
            a[1][i] = a[1][i + 1] = a[2][i] = a[2][i + 1] = cul;
            cul++;
        }
    }

    else if (n == 4) {
        if (k < m / 2) {
            cout << "NO\n";
            return;
        }
        if (k == m - 1) {
            cout << "NO\n";
            return;
        }
        cout <<"YES\n";
        if (k == m) {
            for (int j = 1; j <= m; j+=2)
                for (int i = 1; i <= 3; i += 2) {
                    a[i][j] = a[i][j + 1] = a[i + 1][j] = a[i + 1][j + 1] = cul;
                    cul++;
                }
        }
        else
            divide(1, k);
    }

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++)
            cout << a[i][j] << " ";
        cout << "\n";
    }


}

int main() {

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);


    int tests;
    cin >> tests;
    for (int t = 1; t <= tests; t++) {
        int k;
        cin >> n >> m >> k;
        solve(k);
    }

    return 0;
}

/* 2
1
4 10 7

3
2 2 2
2 2 1
2 8 4
*/
