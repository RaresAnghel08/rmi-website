/**
* user:  ivan-e65
* fname: Tudor
* lname: Ivan
* task:  Speedrun
* score: 63.0
* date:  2021-12-16 10:56:03.278145
*/
#include "speedrun.h"
#include<bits/stdc++.h>
using namespace std;
const int LMAX = 30;
void makehint(int nod, int val, int fs){
  int startb = 1;
  if(fs == 2)
    startb = 11;
  else if(fs == 3)
    startb = 21;
  for(int b = 0; b < 10 ; b++){
    setHint(nod, startb, (val>>b)&1);
    startb++;
  }
}
int dep[1005];
void dfs_init(vector<vector<int>> &gr, int nod, int dad){
  vector<int> sons;
  dep[nod] = 1 + dep[dad];
  for(auto x:gr[nod]){
    if(x == dad)
      continue;
    sons.push_back(x);
    dfs_init(gr, x, nod);
  }
  makehint(nod, dep[nod], 3);
  if(sons.size() == 0){
    setHint(nod, LMAX, 1);
    makehint(nod, dad, 1);
    return;
  }
  makehint(nod, sons[0], 1);
  for(int i = 0; i < sons.size() - 1; i++){
    makehint(sons[i], sons[i + 1], 2);
  }
  makehint(sons[sons.size() - 1], dad, 2);
}
void assignHints(int subtask, int N, int A[], int B[]) {
  setHintLen(LMAX);
  vector<vector<int>> gr;
  gr.resize(N + 1, vector<int>(0));
  for(int i =1 ; i <N; i++){
    int u, v;
    u = A[i], v = B[i];
    gr[u].push_back(v);
    gr[v].push_back(u);
  }
  dfs_init(gr, 1, 0);

}
int LEN;
int getnr(int tip){
  int ans = 0;
  int startb = 1;
  if(tip == 2)
    startb = 11;
  else if(tip == 3)
    startb = 21;
  for(int b = 0; b <10; b++){
    bool val = getHint(startb);
    if(val)
      ans += (1<<b);
    startb++;
  }
  return ans;
}
bool viz[1005];
int h[1005];
const int UNK = 0;
int n;
int dfs_solve(int nod, int dad){
  h[nod] = getnr(3);
  viz[nod] = true;

  int son = getnr(1);
  if(son == dad)
    return getnr(2);
  goTo(son);
  int dson = getnr(3);
  if(dson < h[nod]){
    dad = son;
    dfs_solve(son, UNK);
    return getnr(2);
  }
  goTo(nod);
  while(son != dad){
    goTo(son);
    if(getnr(3) < h[nod]){
      dad = son;
      dfs_solve(son, UNK);
      return getnr(2);
    }
    int nson;
    if(viz[son]){
      nson = getnr(2);
    }
    else{
      nson = dfs_solve(son, nod);
      dson = h[son];
    }
    goTo(nod);
    son = nson;
  }
  return getnr(2);

}
void speedrun(int subtask, int N, int start) {
  LEN = getLength();
  n = N;
  dfs_solve(start, UNK);
}


