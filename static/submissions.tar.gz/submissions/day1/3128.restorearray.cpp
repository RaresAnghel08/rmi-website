/**
* user:  handarov-0db
* fname: Radostin
* lname: Handarov
* task:  restore
* score: 7.0
* date:  2019-10-10 10:33:36.046548
*/
#include <bits/stdc++.h>

#pragma GCC optimize "-O3"

#define endl "\n"
#define trace(x) cerr << #x << " = " << x << endl
#define sz(x) ((int)x.size())
#define all(x) x.begin(), x.end()

using namespace std;

template<class T, class T1> inline bool chkmax(T &x, const T1 &y) { return x < y ? x = y, true : false; }
template<class T, class T1> inline bool chkmin(T &x, const T1 &y) { return x > y ? x = y, true : false; }

struct Restriction {
	int l;
	int r;
	int k;
	int value;
};

int n, m;
vector<Restriction> rest;
bitset<20> curr;

void f(int pos) {
	if (pos == n) {
		bool good = true;
		for (int i = 0; i < m; i++) {
			int cnt0 = 0;
			for (int j = rest[i].l; j <= rest[i].r; j++) {
				if (curr[j] == 0) {
					cnt0++;
				}
			}
			if (rest[i].value == 0 && rest[i].k > cnt0) {
				good = false;
				break;
			} else if (rest[i].value == 1 && rest[i].k <= cnt0) {
				good = false;
				break;
			}
		}
		if (good) {
			for (int i = 0; i < n; i++) {
				cout << curr[i] << ' ';
			}
			cout << endl;
			exit(EXIT_SUCCESS);
		}
		return;
	}
	curr[pos] = 0;
	f(pos + 1);
	curr[pos] = 1;
	f(pos + 1);
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m;

	rest.resize(m);
	for (int i = 0; i < m; i++) {
		cin >> rest[i].l >> rest[i].r >> rest[i].k >> rest[i].value;
	}

	f(0);

	cout << -1 << endl;

	return EXIT_SUCCESS;
}
