/**
* user:  casarin-262
* fname: Filippo
* lname: Casarin
* task:  restore
* score: 0.0
* date:  2019-10-10 07:36:58.282419
*/
#include "bits/stdc++.h"

#define QUIT() printf("-1\n"), exit(0)

#define MAXN 5000
#define MAXM 10000

typedef std::pair<int, int> ii;
typedef std::vector<int> vi;
typedef std::vector<ii> vii;

struct Struct {
	int L, R;
	int K, V;

	Struct(int l, int r, int k, int v) : L(l), R(r), K(k), V(v) {}

	bool operator <(const Struct& oth) const {
		if (L != oth.L) return L > oth.L;
		return R > oth.R;
	}
};

signed char A[MAXN];

int main() {
	int N, M;
	scanf("%d %d", &N, &M);

	for (int i=0; i<N; i++)
		A[i] = -1;

	std::priority_queue<Struct> queue;
	for (int i=0; i<M; i++) {
		int L, R, K, V;
		scanf("%d %d %d %d", &L, &R, &K, &V);
		queue.emplace(L, R, K, V);
	}

	while (!queue.empty()) {
		Struct S = queue.top(); queue.pop();

		if (S.K == 1) {
			if (S.V == 1) {
				for (int j=S.L; j<=S.R; j++) {
					if (A[j] == 0) QUIT();
					A[j] = 1;
				}
			}
		} else {
			if (S.V == 0) {
				for (int j=S.L; j<=S.R; j++) {
					if (A[j] == 1) QUIT();
					A[j] = 0;
				}
			}
		}






		if (S.K == 1) {
			if (S.V == 0) {
				bool ok = false;
				for (int j=S.L; j<=S.R && !ok; j++)
					if (A[j] != 1) {
						ok = true;
						A[j] = 0;
					}

				if (!ok) QUIT();
			}
		} else {
			if (S.V == 1) {
				bool ok = false;
				for (int j=S.L; j<=S.R && !ok; j++)
					if (A[j] != 0) {
						ok = true;
						A[j] = 1;
					}

				if (!ok) QUIT();
			}
		}
	}

	for (int i=0; i<N; i++)
		printf("%d ", A[i] != -1 ? A[i] : 0);
	printf("\n");
}

