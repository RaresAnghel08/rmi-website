/**
* user:  gospodinov-b8b
* fname: Antani
* lname: Gospodinov
* task:  restore
* score: 0.0
* date:  2019-10-10 10:05:49.884878
*/
#include <bits/stdc++.h>
#define ll long long
#define mp make_pair
#define pb push_back
using namespace std;
const int N = 5e3 + 5;
const int M = 1e4 + 5;

int n, m;
int a[N];
struct constraint{

    int l, r, k, val;

}c[M];


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        cin >> c[i].l >> c[i].r >> c[i].k >> c[i].val;
        c[i].l++; c[i].r++;

        if(c[i].val == 1)
            c[i].k = (c[i].r - c[i].l - c[i].k + 2);
    }

    for(int i = 1; i <= n; i++)
        cout << i % 2 << " ";
    cout << endl;

    for(int i = 1; i <= n; i++)
    {
        int d[2] = {N, N};
        int cnt[2] = {0, 0};
        for(int j = 1; j <= m; j++)
        {
            if(i > c[j].r || i < c[j].l || c[j].k == 0)
                continue;
            d[c[j].val] = min(d[c[j].val], c[j].r);
            cnt[c[j].val]++;
        }

        if(d[0] < d[1])
            a[i] = 0;
        if(d[0] > d[1])
            a[i] = 1;

        for(int j = 1; j <= m; j++)
        {
            if(i > c[j].r || i < c[j].l || c[j].k == 0)
                continue;

            if(c[j].val == a[i])
                c[j].k--;
        }
    }

    for(int j = 1; j <= m; j++)
    {
        if(c[j].k != 0)
        {
            cout << -1 << endl;
            return 0;
        }
    }

    for(int i = 1; i <= n; i++)
        cout << a[i] << " ";
    cout << endl;


}

/*

4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0

*/
