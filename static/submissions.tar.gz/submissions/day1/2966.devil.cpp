/**
* user:  frolov-001
* fname: Konstantin
* lname: Frolov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:19:14.598792
*/
#include <bits/stdc++.h>
#define FOR(i, n) for (int i = 0; i < n; ++i)
#define debug(x) std::cout << #x << ": " << x << '\n';
#define pb push_back
typedef long long ll;
int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(0); std::cout.tie(0);
	int t;
	std::cin >> t;
	while(t--) {
		int k;
		std::cin >> k;
		std::vector<int> per;
		for (int i = 1; i <= 9; ++i) {
			int x;
			std::cin >> x;
			while(x--) {
				per.pb(i);
			}
		}
		std::vector<int> min = {10};
		do {
			std::vector<int> curMax = {0};
			for (int i = 0; i <= (int)per.size() - k; ++i) {
				std::vector<int> kek;
				for (int j = i; j < i + k; ++j) {
					kek.pb(per[j]);
				}
				curMax = std::max(curMax, kek);
				if (curMax > min) break;
			}
			min = std::min(min, curMax);
		} while (std::next_permutation(per.begin(), per.end()));
		// for (auto e : min) {
		// 	std::cout << e << ' ';
		// }
		do {
			std::vector<int> curMax = {0};
			for (int i = 0; i <= (int)per.size() - k; ++i) {
				std::vector<int> kek;
				for (int j = i; j < i + k; ++j) {
					kek.pb(per[j]);
				}
				curMax = std::max(curMax, kek);
				if (curMax > min) break;
			}
			// for (auto e : curMax) {
			// 	std::cout << e << ' ';
			// }
			// std::cout << '\n';
			if (curMax == min) {
				for (auto e : per) {
					std::cout << e;
				}
				std::cout << '\n';
				break;
			}
		} while (std::next_permutation(per.begin(), per.end()));
	}
}