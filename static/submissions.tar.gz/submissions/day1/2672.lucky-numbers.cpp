/**
* user:  bashev-75b
* fname: Dobrin
* lname: Bashev
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:46:39.506099
*/
#include <iostream>
using namespace std;

const int MAXN = 100005;
const int MOD = 1000000007;

int n, q;
string s;

long long dp[MAXN], pw[MAXN];

int main()
{
    cin >> n >> q;
    cin >> s;

    pw[0] = 1;
    pw[1] = 10;
    for (int i = 2; i <= n; ++ i)
    {
        pw[i] = pw[i - 1] * 10;
        pw[i] %= MOD;
    }

    dp[0] = 1;
    dp[1] = 10;
    dp[2] = 99;
    for (int i = 3; i <= n; ++ i)
    {
        dp[i] = pw[i] - pw[i - 2];
        for (int j = 2; j <= i - 1; ++ j)
        {
            dp[i] -= dp[j - 1] * pw[i - j - 1];
            dp[i] %= MOD;
            // cout << dp[j - 1] << ' ' << pw[i - j - 1] << endl;
        }

        if (dp[i] < 0) dp[i] += MOD;
        // cout << dp[i] << endl;
    }


    long long ans = 1;
    for (int i = 0; i < n; ++ i)
    {
        if (i != 0 and s[i] == '3' and s[i - 1] == '1')
        {
            s[i]--;
            for (int j = i + 1; j < n; ++ j) s[j] = '9';
        }

        ans += (long long)(s[i] - '0') * dp[n - i - 1];
        if (s[i] > '1')
        {
            ans -= dp[n - i - 2];
            // cout << "-" << dp[n - i - 2] << endl;
        }

        ans %= MOD;
        // cout << (int)(s[i] - '0') << ' ' <<  dp[n - i - 1] << endl;
    }

    if (ans < 0) ans += MOD;
    cout << ans << endl;

    return 0;
}
