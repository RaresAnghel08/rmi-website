/**
* user:  kruhlikau-b9e
* fname: Ihar
* lname: Kruhlikau
* task:  Present
* score: 29.0
* date:  2021-12-16 09:21:10.180879
*/
#include <bits/stdc++.h>

#define fi first
#define se second
#define mp make_pair

#define pb push_back
#define pob pop_back

#define ld long double
#define ll long long

#define y1 abc

#define re return
#define cont continue

#define endl '\n'

using namespace std;

set <ll> Set;

vector <ll> v, v1[1200001];

ll g[111][111], n, i, j, z, k, t, len;

bool used[111], x;

    ll gcd(ll a, ll b)
    {
        if (a < b)
        swap(a, b);

        while (b != 0) {
            a %= b;

            swap(a, b);
        }

        re a;
    }

    void solve()
    {
        cin >> k;

        cout << v1[k].size() - 1 << " ";

        for (i = v1[k].size() - 1; i >= 1; i--) cout << v1[k][i] << " ";

        cout << endl;
    }

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    for (i = 1; i <= 100; i++)
        for (j = 1; j <= 100; j++) g[i][j] = gcd(i, j);

    v.pb(1000000000);

    v1[0] = v;

    for (z = 1; z <= 1000000; z++) {
        len = (ll) v.size();

        for (i = 1; i <= len; i++)
            if (v.back() == i) v.pob();
            else {
                v.pb(i);

                break;
            }

        for (i = 1; i <= 30; i++) used[i] = false;

        for (i = 1; i < v.size(); i++) used[v[i]] = true;

        for (i = 1; i < v.size(); i++)
            for (j = 1; j < i; j++)
                if (!used[g[v[i]][v[j]]]) {
                    used[g[v[i]][v[j]]] = true;

                    v.pb(g[v[i]][v[j]]);
                }

        v.clear();

        v.pb(1000000000);

        for (i = 30; i >= 1; i--)
            if (used[i]) v.pb(i);

        v1[z] = v;
    }

    cin >> t;

    while (t--) solve();

    re 0;
}
