/**
* user:  beliaev-6a5
* fname: Vladislav
* lname: Beliaev
* task:  Present
* score: 0.0
* date:  2021-12-16 11:32:56.857709
*/
#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <map>

using namespace std;

typedef long long ll;

vector<ll> v;
vector<bool> used;
ll cnt = 0;
ll k;
map<set<ll>, ll> mp;

ll gcd(ll a, ll b) {
	if (a < b) {
		swap(a, b);
	}
	if (b == 0)
		return a;
	else
		return gcd(a % b , b);
}

int main() {
	ll tt;
	cin >> tt;
	for (int t = 0; t < tt; t++) {
		cin >> k;
		ll it = 1;
		queue<vector<ll>> q;
		vector<ll> res;
		while (cnt < k) {
			v.clear();
			v.push_back(it);
			q.push(v);
			while (!q.empty()) {
				vector<ll> a = q.front();
				set<ll> s;
				q.pop();
				for (int i = 0; i < a.size(); i++) {
					s.insert(a[i]);
				}
				if (mp[s] > 0) {
					continue;
				}
				else {
					mp[s] ++;
				}
				
				bool flag = true;
				for (int i = 0; i < a.size(); i++) {
					for (int j = 1; j < a.size(); j++) {
						if (s.find(gcd(a[i], a[j])) == s.end()) {
							flag = false;
						}
					}
				}
				if (flag) {
					cnt++;
					if (cnt == k) {
						res = a;
						break;
					}
				}
				for (int i = 1; i < it; i++) {
					if (s.find(i) == s.end()) {
						a.push_back(i);
						q.push(a);
						a.pop_back();
					}
				}

			}
			it++;
		}
		sort(res.begin(), res.end());
		cout << res.size() << " ";
		for (int i = 0; i < res.size(); i++) {
			cout << res[i] << " ";
		}
		cout << endl;
		res.clear();
		v.clear();
		cnt = 0;
		mp.clear();
	}
	return 0;
}