/**
* user:  slavchev-772
* fname: Yuliyan Radoslavov
* lname: Slavchev
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 09:30:04.558973
*/
#include "speedrun.h"
#include <vector>
#include <string>
//#include <iostream>
using namespace std;
#define MAXN 1005
vector<int> tree[MAXN];
int cnt[MAXN];
string tobinary(int val)
{
    string res;
    while(val > 0){
        int rem = val % 2; val /= 2;
        res.push_back(rem + '0');
    }
    return res;
}
void assignHints(int subtask, int _br, int a[], int b[])
{
    if(subtask == 1){
        setHintLen(_br);
        for(int i = 1; i <= _br - 1; ++i){
            int from, to; from = a[i]; to = b[i];
            setHint(from, to, 1); setHint(to, from, 1);
        }
    }
    else if(subtask == 2){
        setHintLen(20);
        for(int i = 1; i <= _br - 1; ++i){
            int from, to; from = a[i]; to = b[i];
            cnt[from]++; cnt[to]++;
        }
        int center;
        for(int i = 1; i <= _br; ++i){
            if(cnt[i] != 1){
                center = i; break;
            }
        }
        string bc = tobinary(center);
        for(int i = 1; i <= _br; ++i){
            if(i == center) continue;
            for(int z = 0; z < bc.size(); ++z){
                if(bc[z] == '0') continue;
                setHint(i, z + 1, 1);
            }
        }
    }
    else if(subtask == 3){
        setHintLen(20);
        for(int i = 1; i <= _br - 1; ++i){
            int from, to; from = a[i]; to = b[i];
            tree[from].push_back(to); tree[to].push_back(from);
        }
        for(int i = 1; i <= _br; ++i){
            int beg = 1;
            for(int z : tree[i]){
                string s = tobinary(z);
                for(int q = 0; q < s.size(); ++q){
                    if(s[q] == '0') continue;
                    setHint(i, beg + q, 1);
                }
                beg = 11;
            }
        }
    }
}
int br;
void dfs1(int v, int p)
{
    for(int i = 1; i <= br; ++i){
        if(i == v || i == p) continue;
        bool go = getHint(i);
        //cout << v << ' ' << i << ' ' << go << endl;
        if(!go) continue;
        goTo(i); dfs1(i, v);
    }
    if(p != -1) goTo(p);
}

int getval(int from, int to)
{
    int pow = 1; int sum = 0;
    for(int i = from; i <= to; ++i, pow *= 2){
        bool b = getHint(i);
       // cout << "Hint " << i << ' ' << b << endl;
        sum += (b * pow);
    }
    return sum;
}

void dfs3(int v, int p)
{
    int one = getval(1, 10), two = getval(11, 20);
    if(one != 0 && one != p){
        goTo(one); dfs3(one, v);
    }
    if(two != 0 && two != p){
        goTo(two); dfs3(two, v);
    }
    if(p != -1) goTo(p);
}

void speedrun(int subtask, int _br, int start)
{
    //active = start; //
    br = _br;
    if(subtask == 1){
        dfs1(start, -1);
    }
    else if(subtask == 2){
        int center = getval(1, 10);
        if(center != 0) goTo(center);
        else center = start;
        //cout << "Center: " << center << endl;
        for(int i = 1; i <= _br; ++i){
            if(i == center) continue;
            goTo(i); goTo(center);
        }
    }
    else if(subtask == 3){
        dfs3(start, -1);
    }
}


