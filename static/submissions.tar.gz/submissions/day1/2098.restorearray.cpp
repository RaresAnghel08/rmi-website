/**
* user:  gospodinov-b8b
* fname: Antani
* lname: Gospodinov
* task:  restore
* score: 0.0
* date:  2019-10-10 08:30:53.273261
*/
#include <bits/stdc++.h>
#define ll long long
#define mp make_pair
#define pb push_back
using namespace std;
const int N = 5e3 + 5;
const int M = 1e4 + 5;

int n, m;
int a[N];
struct constraint{

    int l, r, k, val;

}c[M];


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        cin >> c[i].l >> c[i].r >> c[i].k >> c[i].val;
        c[i].l++; c[i].r++;
    }

    for(int i = 1; i <= n; i++)
        a[i] = 1;

    for(int i = 1; i <= m; i++)
    {
        if(c[i].val == 1)
        for(int j = c[i].l; j <= c[i].r; j++)
            a[j] = 0;
    }

    for(int i = 1; i <= m; i++)
    {
        if(c[i].val == 0)
        {
            bool cool = false;
            for(int j = c[i].l; j <= c[i].r; j++)
                cool |= a[j];
            if(!cool)
            {
                cout << -1 << endl;
                return 0;
            }
        }
    }

    for(int i = 1; i <= n; i++)
        cout << a[i] << " ";

    return 0;
}

/*

4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0

*/
