/**
* user:  fomiuk-cd9
* fname: Artem
* lname: Fomiuk
* task:  lucky
* score: 0.0
* date:  2019-10-10 06:36:52.371506
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

template<class A>using sett=tree<A,null_type,less<A>,rb_tree_tag,tree_order_statistics_node_update>;
template<class A,class B>using mapp=tree<A,B,less<A>,rb_tree_tag,tree_order_statistics_node_update>;
template<class A>using multisett=tree<A,null_type,less_equal<A>,rb_tree_tag,tree_order_statistics_node_update>;
template<class A,class B>using multimapp=tree<A,B,less_equal<A>,rb_tree_tag,tree_order_statistics_node_update>;

#define i128 __int128
#define DIM 200009
#define INF ((long long)1e18+9ll)
#define pairll pair<long long,long long>
#define fi first
#define se second
#define ld long double
#define fast ios_base::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define amen exit(0)
#define endl '\n'
#define eps 0.0000000001
#define MODULO 1000000007

long long i,j,k,l,n,m;

long long a[DIM];

string s,ss,res,mx;

string getmin(string s,long long n){
	string mx;
	mx="";
	for(int i=1;i<=n;i++)mx+='0';
	for(int i=0;i<s.length()-n+1;i++){
		string curr="";
		for(int j=i;j<i+n;j++)curr+=s[j];
		if(curr>mx)mx=curr;
	}
	return mx;
}

string dummy(long long* a,long long n){
	string s="",ss="",res="",mx="";

	for(int i=1;i<=n;i++)ss+='9';

	for(int i=1;i<10;i++){
		for(int j=1;j<=a[i];j++)s+=i+'0';
	}

	do{
		mx=getmin(s,n);
		if(mx<ss){
			ss=mx;
			res=s;
		}
	}while(next_permutation(s.begin(),s.end()));
	return res;
}

int main(){

	//fast;

	int nt;
	cin>>nt;
	while(nt--){
		cin>>n;
		for(i=1;i<=9;i++)cin>>a[i];

		string res="";

		for(i=1;i<=n;i+=2){
			for(j=9;j>0;j--){
				if(a[j]>0){
					a[j]--;
					res+=j+'0';
					break;
				}
			}
			for(j=1;j<10;j++){
				if(a[j]>0){
					a[j]--;
					res+=j+'0';
					break;
				}
			}
		}

		//cout<<res<<endl;

		string ress=res;
		char t=ress[ress.size()-1];
		ress.pop_back();
		ress=t+ress;
		if(getmin(ress,n)<getmin(res,n))res=ress;
		cout<<res<<endl;
	}

	amen;
}
/*
3
2
1 1 2 0 0 0 0 0 0
7
2 4 2 0 0 6 2 2 2 
7
3 3 3 0 0 6 2 2 2
*/