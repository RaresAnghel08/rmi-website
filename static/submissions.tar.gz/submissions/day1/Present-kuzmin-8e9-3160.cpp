/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  Present
* score: 0.0
* date:  2021-12-16 10:41:21.955842
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

void solve() {
	int k;
	cin >> k;
	if (k == 0) {
		cout << 0 << endl;
		return;
	}
	set<int> free;
	set<int> now;
	for (int i = 1; i <= 500; ++i) {
		free.insert(i);
	}
	function<int(int)> dfs = [&] (int mx) {
		k--;
		if (k == 0) {
			cout << now.size() << ' ';
			for (auto &i : now)
				cout << i << ' ';
			cout << endl;
			return 1;
		}
		vi v;
		for (auto &j : free) {
			if (j < mx)
				v.pb(j);
		}
		for (auto &k : v) {
			free.erase(k);
			now.insert(k);
			vi dop;
			for (auto &j : now) {
				int g = gcd(j, k);
				if (free.count(g)) {
					dop.pb(g);
				}
			}
			sort(dop.begin(), dop.end());

			for (auto &i : dop) {
				now.insert(i);
				free.erase(i);
			}
			if (dfs(k))
				return 1;

			for (auto &i : dop) {
				now.erase(i);
				free.insert(i);
			}

			now.erase(k);
			free.insert(k);
		}

		return 0;
	};
	for (int i = 1; i <= 500; ++i) {
		free.erase(i);
		now.insert(i);
		if (dfs(i)) {
			return;
		}
		now.erase(i);
		free.insert(i);
	}
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t;
	cin >> t;
	while (t--)
		solve();
}