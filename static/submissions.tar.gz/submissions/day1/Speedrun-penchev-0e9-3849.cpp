/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:42:05.388755
*/
#include "speedrun.h"
#include <algorithm>
#include <iostream>
#include <vector>
//#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

const int MAXN = 1000;

bool used[MAXN + 5];
vector<int> G[MAXN + 5];

void setHintLen(int l);
void setHint(int i, int j, bool b);
int getLength();
bool getHint(int j);
bool goTo(int x);

void assignHints(int subtask, int N, int A[], int B[])
{
    for (int i = 1; i < N; ++ i)
    {
        int u = A[i], v = B[i];
        G[u].push_back(v);
        G[v].push_back(u);
    }

    setHintLen(40);

    for (int u = 1; u <= N; ++ u)
    {
        sort(G[u].begin(), G[u].end());
        for (int i = 0; i < G[u].size(); ++ i)
        {
            if (G[u][i] <= 40) setHint(u, G[u][i], true);
        }
    }

    return;
}

void DFS(int u, int p, int N)
{
    used[u] = true;
    vector<int> v;
    for (int i = 1; i <= 40; ++ i)
    {
        if (getHint(i)) v.push_back(i);
    }

    for (int i = 0; i < v.size(); ++ i)
    {
        if (v[i] != p)
        {
            goTo(v[i]);
            DFS(v[i], u, N);
        }
    }

    for (int v1 = 41; v1 <= N; ++ v1)
    {
        if (used[v1]) continue;
        if (goTo(v1)) DFS(v1, u, N);
    }

    if (p != -1) goTo(p);
}

void speedrun(int subtask, int N, int start)
{
    int l = getLength();

    DFS(start, -1, N);

    return;
}

/*
static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;

void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}

int main() {
    int N;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(1, N, a, b);

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(1, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;
    return 0;
}*/
