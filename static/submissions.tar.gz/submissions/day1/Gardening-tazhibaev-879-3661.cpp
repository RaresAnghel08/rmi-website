/**
* user:  tazhibaev-879
* fname: Iskhak
* lname: Tazhibaev
* task:  Gardening
* score: 11.0
* date:  2021-12-16 11:26:12.812678
*/
#include <bits/stdc++.h>
using namespace std;
int ito[4] = {1, -1, 0, 0};
int jto[4] = {0, 0, -1, 1};
int n, m, k;
bool in(int i, int j){
	if(i >= 1 and i <= n){
		if(j >= 1 and j <= m){
			return true;
		}
	}
			return false;
}
 main(){
	int t;
	cin >> t;
	while(t--){
		cin >> n >> m >> k;
		if(n % 2 == 1 or m % 2 == 1){
			cout << "NO" << "\n";
			continue;
		}
		int a[n + 2][m + 2];
		for(int i = 1;i <= n; i++){
			for(int j = 1;j <= m; j++){
				a[i][j] = -1;
			}
		}
		int s = (n * m) / 4;
		map<int, int> mp;
		int x;
		mp[s] = 1;
		for(int i = 4;i <= max(n, m); i+=2){
			if(i > s) break;
			x = s - i;
			x+= i / 2;
			mp[x] = i;
			//cout << x << " ";
		}
		if(mp[k] == 0){
			//cout << 't' << " ";
			cout << "NO" << "\n";
			continue;
		}
		int cnt = 1;
		for(int c = 4;c <= max(n, m); c+=2){
			x = s - c;
			x+= c /2;
			if(x == k){

				for(int i = 1;i <= n; i++){
					for(int j = 1; j <= c; j++){
						if(i == 1 or j == 1 or i == n or j == c)
						a[i][j] = 1;
					}
				}
				cnt = 2;
				break;
			}
		}
		
	for(int i = 1;i <= n; i++){
		for(int j = 1;j <= m; j++){
			if(a[i][j] == -1){
				bool f = true;
				int ni = i;
				int nj = j;
				if(in(ni + 1, nj + 1)){
					if(a[ni + 1][nj + 1] != -1){
						f = false;
					}
				}else f = false;
				if(in(ni + 1, nj)){
					if(a[ni + 1][nj] != -1){
						f = false;
					}
				}else f = false;
				if(in(ni, nj + 1)){
					if(a[ni][nj + 1] != -1){
						f = false;
					}
				}else f = false;
				if(f){
					a[ni + 1][nj + 1] = cnt;
					a[ni][nj + 1] = cnt;
					a[ni + 1][nj] = cnt;
					a[i][j] = cnt;
					cnt++;
				}
			}
		}
		}
		bool jp = true;
		for(int i = 1;i <= n; i++){
			for(int j = 1;j <= m; j++){
				if(a[i][j] == -1) jp = false;
			}
		}
		set<int> st;
		for(int i = 1;i <= n; i++){
			for(int j = 1;j <= m; j++){
				int ans = 0;
				st.insert(a[i][j]);
				for(int x = 0; x < 4; x++){
					
					int ni = i + ito[x];
					int nj = j + jto[x];
					if(in(ni, nj)){
						if(a[i][j] == a[ni][nj])
							ans++;
					}
				}
				if(ans != 2) jp = false;
			}
		}
		if(st.size() != k) jp = false;
		if(jp){
		cout << "YES" << "\n";
		for(int i = 1;i <= n; i++){
			for(int j = 1;j <= m; j++){ 
				if(j == m) cout << a[i][j];
				else
				cout << a[i][j] << " ";
			}
			cout << "\n";
		}
		
		}else{
			cout << "NO" << "\n";
			}
		}
		
		
	
	return 0;
}
