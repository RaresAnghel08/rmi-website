/**
* user:  verde-76f
* fname: Flaviu-Cristian
* lname: Verde
* task:  lucky
* score: 0.0
* date:  2019-10-10 08:51:33.904144
*/
#include <iostream>
#include <cstdio>
using namespace std;
const int MOD=1e9+7;
char s[100001];
int v[100001],dp[100001][10],cate[100001],dp1[100001][10],catesuf[100001];
bool sufix[100002];
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    int n,q,i,j,t,a,b,rez,sum=0;
    cin>>n>>q>>ws>>(s+1);
    for(i=1; i<=n; i++)
        v[i]=s[i]-'0';
    for(i=0; i<=9; i++)
        dp[1][i]=1;
    cate[1]=10;
    cate[0]=1;
    for(i=2; i<=100000; i++)
    {
        sum=0;
        for(j=0; j<=9; j++)
            sum=(sum+dp[i-1][j])%MOD;
        for(j=0; j<=9; j++)
            dp[i][j]=sum;
        dp[i][3]=(dp[i][3]-dp[i-1][1]+MOD);
        if(dp[i][3]>=MOD)
            dp[i][3]-=MOD;
        cate[i]=(1LL*10*sum-dp[i-1][1]+MOD)%MOD;

    }
    sufix[n]=0;
    for(j=0; j<=v[n]; j++)
        dp1[n][j]=1;
    catesuf[n]=v[n]+1;
    for(i=n-1; i>=1; i--)
    {
        sufix[i]=sufix[i+1];
        if(v[i]*10+v[i+1]==13)
            sufix[i]=1;
        for(j=0; j<v[i]; j++)
            dp1[i][j]=cate[n-i];
        if(1<v[i])
            dp1[i][1]=(dp1[i][1]-cate[n-i-1]+MOD);
        if(dp1[i][1]>=MOD)
            dp1[i][1]-=MOD;
        dp1[i][v[i]]=catesuf[i+1]-sufix[i];
        if(v[i]==1&&sufix[i]==1)
            dp1[i][v[i]]=0;
        for(j=0;j<=9;j++)
        catesuf[i]=(catesuf[i]+dp1[i][j])%MOD;
        //cout<<catesuf[i]<<" ";
    }
    cout<<catesuf[1]<<'\n';
    for(i=1;i<=q;i++)
    {
     cin>>t>>a>>b;
     rez=(catesuf[a]-catesuf[b+1])/cate[n-b];
     cout<<rez<<'\n';
    }
    return 0;
}
