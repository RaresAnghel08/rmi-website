/**
* user:  babin-880
* fname: Aleksandr
* lname: Babin
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 08:41:29.328785
*/
#include <bits/stdc++.h>

#include "speedrun.h"

void write_number(int v, int offset, int x) {
    for (int t = 0; t < 10; ++t) {
        setHint(v, t + offset + 1, x & 1);
        x >>= 1;
    }
}

int read_number(int offset) {
    int res = 0;
    for (int t = 10; t--; ) {
        res = 2 * res;
        if (getHint(offset + t + 1)) res++;
    }
    return res;
}

using namespace std;

const int N = 1001;

int par[N];
vector<int> g[N], cyc;

void dfs(int v, int p = -1) {
    cyc.push_back(v);
    if (v != 1) write_number(v, 0, p);
    for (int to : g[v]) if (to != p) dfs(to, v);
}

void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(20);

    for (int i = 1; i < N; ++i) {
        g[A[i]].push_back(B[i]);
        g[B[i]].push_back(A[i]);
    }

    dfs(1);

    cyc.push_back(cyc.front());
    for (int i = 0; i < N; ++i) {
        write_number(cyc[i], 10, cyc[i+1]);
    }
}

void speedrun(int subtask, int N, int start) {
    vector<int> st;

    int v = start;

    auto go = [&](int u) {
        if (goTo(u)) {
            v = u;
            return true;
        } else {
            return false;
        }
    };

    while (v != 1) {
        // cout << "go " << read_number(0) << endl;
        go(read_number(0));
    }

    st.push_back(v);
    for (int i = 1; i < N; ++i) {
        int nxt = read_number(10);
        // cout << "nxt = " << nxt << endl;
        while (!goTo(nxt)) {
            st.pop_back();
            goTo(st.back());
        }
        st.push_back(nxt);
    }


}
