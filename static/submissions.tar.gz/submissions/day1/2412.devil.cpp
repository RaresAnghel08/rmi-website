/**
* user:  odintsov-a3e
* fname: Andrei
* lname: Odintsov
* task:  devil
* score: 0.0
* date:  2019-10-10 09:12:47.014030
*/
#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = long double;
using pii = pair<int, int>;
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define all(x) (x).begin(), (x).end()
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define f first
#define s second

const int MAXN = 1e6 + 5;
int n;
int k;
int c[10];
int a[MAXN];
int r[MAXN];

void ans(int x, int y) {
    if (x == y) {
        int i = 0;
        for (i = 0; c[x] > 0; ++i) {
            a[i] = x;
            c[x]--;
        }
        for (int j = 1; j <= 9; ++j) {
            while (c[j]) {
                a[i] = j;
                c[j]--;
                i++;
            }
        }
    } else {
        int i = 0;
        for (int j = 1; j <= 9; ++j) {
            while (c[j] > 0 && c[x] > 0) {
                c[j]--; c[x]--;
                a[i] = x;
                a[i + 1] = j;
                i += 2;
            }
        }
        for (int j = 1; j <= 9; ++j) {
            while (c[j]) {
                a[i] = j;
                c[j]--;
                i++;
            }
        }
    }
    rep(i, n) {
        cout << a[i];
    }
    cout << '\n';
}

void solve() {
    cin >> k;
    n = 0;
    for (int i = 1; i <= 9; ++i) {
        cin >> c[i];
        n += c[i];
    }

    int t = 0;
    for (int i = 9; i >= 1; --i) {
        while (t < k - 1 && c[i] > 0) {
            a[n - 1 - t] = i;
            c[i]--;
            t++;
        }
    }

    int x = -1;
    for (int i = 9; i >= 1; --i) {
        if (c[i]) {
            x = i;
            break;
        }
    }

    int s = 0;
    for (int y = 1; y < x; ++y) {
        s += c[y];
        if (s <= c[x]) {
            ans(x, y);
            return;
        }
    }

    ans(x, x);
}

int main() {
    int t;
    cin >> t;
    rep(tt, t) {
        solve();
    }
}
