/**
* user:  dzheentaev-018
* fname: Bektur
* lname: Dzheentaev
* task:  Present
* score: 0.0
* date:  2021-12-16 08:01:31.742430
*/
﻿
#include <iostream>
#include<vector>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
using namespace std;
typedef long long ll;
int main()
{
    ll t;
    cin >> t;
    while (t > 0) {
        ll n, m, k;
        cin >> n >> m >> k;
        ll x = n / 2;
        ll y = m / 2;
        if (k == 1) {
            cout << "YES" << endl;
            for (ll i = 0; i < n; i++) {
                for (ll j = 0; j < m; j++) {
                    cout << k << " ";
                }
                cout << endl;
            }
        }
        else {
            if (x * y >= k) {
                cout << "YES" << endl;
                if (n % 2 == 0) {
                    if (m % 2 == 0) {
                        ll cnt = 1;
                        for (ll i = 0; i < n; i++) {
                            if (i % 2 == 0 && i != 0) {
                                cnt += m / 2;
                            }
                            if (cnt > k) {
                                for (ll l = i; i < n; i++) {
                                    for (ll p = 0; p < m; p++) {
                                        cout << k << " ";
                                    }
                                    cout << endl;
                                }
                                break;
                            }
                            ll cnt1 = cnt;
                            for (ll j = 0; j < m; j++) {
                                if (j % 2 == 0 && j != 0) {
                                    cnt1++;
                                    if (cnt1 > k) {
                                        cnt1--;
                                        for (ll d = j; j < m; j++) {
                                            cout << cnt1 << " ";
                                        }
                                        break;
                                    }
                                }
                                cout << cnt1 << " ";
                            }
                            cout << endl;
                        }
                    }
                    else {
                        ll cnt = 1;
                        for (ll i = 0; i < n; i++) {
                            if (i % 2 == 0 && i != 0) {
                                cnt += m / 2;
                            }
                            if (cnt > k) {
                                for (ll l = i; i < n; i++) {
                                    for (ll p = 0; p < m; p++) {
                                        cout << k << " ";
                                    }
                                    cout << endl;
                                }
                                break;
                            }
                            ll cnt1 = cnt;
                            for (ll j = 0; j < m-3; j++) {
                                if (j % 2 == 0 && j != 0) {
                                    cnt1++;
                                    if (cnt1 > k) {
                                        cnt1--;
                                    }
                                }
                                cout << cnt1 << " ";
                            }
                            cout << min(k,cnt1 + 1) << " " << min(k,cnt1 + 1) << " " << min(k,cnt1 + 1);
                            cout << endl;
                        }
                    }
                }
                else{
                    if (m % 2 == 0) {
                        ll cnt = 1;
                        for (ll i = 0; i < n-3; i++) {
                            if (i % 2 == 0 && i != 0) {
                                cnt += m / 2;
                            }
                            if (cnt > k) {
                                for (ll l = i; i < n; i++) {
                                    for (ll p = 0; p < m; p++) {
                                        cout << k << " ";
                                    }
                                    cout << endl;
                                }
                                break;
                            }
                            ll cnt1 = cnt;
                            for (ll j = 0; j < m; j++) {
                                if (j % 2 == 0 && j != 0) {
                                    cnt1++;
                                    if (cnt1 > k) {
                                        cnt1--;
                                    }
                                }
                                cout << cnt1 << " ";
                            }
                            cout << endl;
                        }
                        cnt += m / 2;
                        for (ll i = n - 3; i < n; i++) {
                            ll cnt1 = cnt;
                            for (ll j = 0; j < m; j++) {
                                if (j % 2 == 0 && j != 0) {
                                    cnt1++;
                                    if (cnt1 > k)
                                        cnt1--;
                                }
                                cout << cnt1 << " ";
                            }
                            cout << endl;
                        }
                    }
                    else {
                        ll cnt = 1;
                        for (ll i = 0; i < n-3; i++) {
                            if (i % 2 == 0 && i != 0) {
                                cnt += m / 2;
                            }
                            if (cnt > k) {
                                for (ll l = i; i < n; i++) {
                                    for (ll p = 0; p < m; p++) {
                                        cout << k << " ";
                                    }
                                    cout << endl;
                                }
                                break;
                            }
                            ll cnt1 = cnt;
                            for (ll j = 0; j < m - 3; j++) {
                                if (j % 2 == 0 && j != 0) {
                                    cnt1++;
                                    if (cnt1 > k) {
                                        cnt1--;
                                    }
                                }
                                cout << cnt1 << " ";
                            }
                            cout << cnt1 + 1 << " " << cnt1 + 1 << " " << cnt1 + 1;
                            cout << endl;
                        }
                        for (ll i = n - 3; i < n; i++) {
                            ll cnt1 = cnt+m/2;
                            for (ll j = 0; j < m - 3; j++) {
                                if (j % 2 == 0 && j != 0) {
                                    cnt1++;
                                    if (cnt1 > k) {
                                        cnt1--;
                                    }
                                }
                                cout << cnt1 << " ";
                            }
                            cout << cnt1 + 1 << " " << cnt1 + 1 << " " << cnt1 + 1;
                            cout << endl;
                        }
                    }
                }
            }
            else
                cout << "NO" << endl;
        }
        t--;
    }
    return 0;
}

