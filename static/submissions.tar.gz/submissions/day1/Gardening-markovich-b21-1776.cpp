/**
* user:  markovich-b21
* fname: Vesselin Nikolaev
* lname: Markovich
* task:  Gardening
* score: 5.0
* date:  2021-12-16 08:26:22.792056
*/
#include<bits/stdc++.h>
#define endl '\n'

using namespace std;

vector<vector<int> > t;
int r[2][200000];
long long n, m, k;

void popl(int bi, int bj, int rn, int rm, int cv)
{
    for(int i=0; i<rn-1; i++)
    {
        t[bi][bj]=cv;
        bi++;
    }
    for(int i=0; i<rm-1; i++)
    {
        t[bi][bj]=cv;
        bj++;
    }
    for(int i=0; i<rn-1; i++)
    {
        t[bi][bj]=cv;
        bi--;
    }
    for(int i=0; i<rm-1; i++)
    {
        t[bi][bj]=cv;
        bj--;
    }
}

void solve()
{
    bool fl=0;
    cin>>n>>m>>k;
    if(n>m)
    {
        swap(n, m);
        fl=1;
    }
    if(n*m>200000 || n%2 || m%2 || k*4-4==n*m || (n==m && k==n/2+1) || k*4>n*m)
    {
        cout<<"NO\n";
        return;
    }
    long long mn=0;
    long long n2=n, m2=m;
    if(n2>m2) swap(n2, m2);
    int brr=(n-2)/2;
    mn=brr+(m-2*brr)/2;
    if(k<mn)
    {
        cout<<"NO\n";
        return;
    }
    cout<<"YES\n";

    t.resize(n);
    for(int i=0; i<n; i++) t[i].resize(m);
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++) t[i][j]=0;
    }

    for(int i=0; i<brr; i++)
    {
        r[0][i]=2*(i+2);
        r[1][i]=m-2*(brr-i-1);
    }
    int brotm=k-mn, id=0;
    while(brotm)
    {
        if(r[1][id]>4)
        {
            r[1][id]-=2;
            brotm--;
        }
        else if(r[0][id]>4)
        {
            r[1][id]-=2;
            brotm--;
        }
        else if(brotm>=2)
        {
            r[0][id]=0;
            r[1][id]=0;
            id++;
            brotm-=2;
        }
        else id++;
    }
    int brc=1;
    for(int i=0; i<brr; i++)
    {
        if(!r[0][i]) continue;
        else
        {
            popl(i, i, r[0][i], r[1][i], brc);
            brc++;
        }
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if(!t[i][j])
            {
                t[i][j]=t[i+1][j]=t[i][j+1]=t[i+1][j+1]=brc;
                brc++;
            }
        }
    }
    if(!fl)
    {
        for(int i=0; i<n; i++)
        {
            cout<<t[i][0];
            for(int j=1; j<m; j++) cout<<" "<<t[i][j];
            cout<<endl;
        }
    }
    else
    {
        for(int j=0; j<m; j++)
        {
            cout<<t[0][j];
            for(int i=1; i<n; i++) cout<<" "<<t[i][j];
            cout<<endl;
        }
    }
    for(int i=0; i<n; i++) t[i].resize(0);
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int tt;
    cin>>tt;
    while(tt--) solve();
    return 0;
}
/**
5
2 2 2
2 2 1
4 4 4
4 4 2
4 6 3
*/
