/**
* user:  bem-c1d
* fname: Andrei
* lname: Bem
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:41:18.843919
*/
#include <bits/stdc++.h>

using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n, m, k;
        cin>>n>>m>>k;
        if(4*k>m*n)
        {
            cout<<"NO\n";
            continue;
        }
        if(n%2==0 && m%2==0)
        {
            cout<<"YES\n";
            int cnt=1, ans=1;
            for(int i=1; i<=n/2; i++)
            {
                for(int j=1; j<=m/2; j++)
                {
                    cout<<cnt<<" "<<cnt<<" ";
                    if(cnt<k){
                        cnt++;
                    }
                }
                cout<<"\n";
                cnt=ans;
                for(int j=1; j<=m/2; j++)
                {
                    cout<<cnt<<" "<<cnt<<" ";
                    if(cnt<k){
                        cnt++;
                    }
                }
                ans=cnt;
                cout<<"\n";
            }
        }
    }
    return 0;
}
