/**
* user:  ulmeanu-8ba
* fname: Vlad
* lname: Ulmeanu
* task:  lucky
* score: 14.0
* date:  2019-10-10 08:28:07.954662
*/
#include <bits/stdc++.h>
#define ll long long
#define pii pair<int,int>
#define pll pair<ll,ll>
#define fi first
#define se second
#define vi vector<int>
#define pb push_back
#define all(a) begin(a),end(a)
#define sz(a) (int)(a).size()
#define y0 y5656
#define y1 y7878
#define inf (INT_MAX/2-1)
#define infl (1LL<<61)
#define dbg(x) cerr<<(#x)<<": "<<x<<'\n';
#define dbga(x,n) cerr<<(#x)<<"[]: ";for(int _=0;_<n;_++)cerr<<x[_]<<' ';cerr<<'\n';
#define dbgs(x) cerr<<(#x)<<"[stl]: ";for(auto _: x)cerr<<_<<' ';cerr<<'\n';
#define maxn 100000

using namespace std;

string s;
vi v;
ll mod = 1000000007;
ll d[maxn+5][15], d1[maxn+5][15], d2[maxn+5][15];

void mad (ll &a, ll b) {
  a = (a+b)%mod;
}

ll nrmod (int k) {
  ll ans = 0;
  for (int i = 0; i <= 9; i++) mad(ans, d2[k-1][i]);
  return ans;
}

void gg () {
  int gogu;
  cout << "pause: ";
  cin >> gogu;
}

ll sub6 (int nr) {
  vi u;
  int nrc = 0;
//  dbg(nr);
//  gg();
  while (nr > 0) u.pb(nr%10), nr /= 10, nrc++;
  reverse(all(u));
//  dbgs(u);
//  gg();
  for (int i = 0; i < nrc-1; i++)
    if (u[i] == 1 && u[i+1] == 3) return 0;
  return 1;
}

int main () {
//  ifstream cin ("a.in");
//  ofstream cout ("a.out");
  int n, t; cin >> n >> t;
  cin >> s;
  int i, j, z, k;
  ll ans = 0;
  for (i = 0; i < n; i++) v.pb(s[i]-'0');
  if (n <= 6) {
    int nr = 0;
    for (i = 0; i < n; i++) nr = nr*10 + v[i];
    for (i = 1; i <= nr; i++) ans += 1LL*sub6(i);
    cout << ans+1;
    return 0;
  }
  if (t == 0) {
    if (n == 1) { cout << n; return 0; }
    ///MOD
    ///d1 fara 0
    ///sub k cifre
    for (i = 1; i <= 9; i++) d1[0][i] = 1, mad(ans, d1[0][i]);
    for (k = 1; k < n-1; k++)
      for (i = 0; i <= 9; i++) {
        for (j = 0; j <= 9; j++)
          if (i != 3 || j != 1) mad(d1[k][i], d1[k-1][j]);
        mad(ans, d1[k][i]);
      }
  }
  return 0;
}
