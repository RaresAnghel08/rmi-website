/**
* user:  ulukbekov-6c0
* fname: Erzhan
* lname: Ulukbekov
* task:  Present
* score: 8.0
* date:  2021-12-16 07:50:31.870697
*/
#include <iostream>
#include <bits/stdc++.h>

using namespace std;

vector<int> a;

int check(const vector<int> & a) {
   set<int> st(a.begin(), a.end());
   for (int i = 0; i < a.size(); i++) {
      for (int j = i + 1; j < a.size(); j++) {
         if (!st.count(__gcd(a[i], a[j]))) return 0;
      }
   }
   return 1;
}

int main() {
   ios::sync_with_stdio(0);
   cin.tie(0);
   int cnt = 0;
   vector<vector<int>> mas(101);
   for (int i = 0; cnt <= 100; i++) {
      vector<int> a;
      for (int j = 0; j <= 30; j++) {
         if (i & (1 << j)) a.push_back(j + 1);
      }
      if (i == 0 || check(a) == 1) {
         for (int x : a) mas[cnt].push_back(x);
         cnt++;
      }
   }
   int q;
   cin >> q;
   while (q --) {
      int k; cin >> k;
      assert(k <= 100);
      cout << mas[k].size() << ' ';
      for (auto x : mas[k]) cout << x << ' ';
      cout << '\n';
   }
   return 0;
}