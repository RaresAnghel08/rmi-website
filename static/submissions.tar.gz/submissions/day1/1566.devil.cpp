/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  devil
* score: 0.0
* date:  2019-10-10 07:08:20.882395
*/
#include <iostream>

using namespace std;

int T, K, A[15];

int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> T;

    while(T--)
    {
        cin >> K;

        for(int i = 1; i<= 9; ++i)
            cin >> A[i];

        if(A[1] && !A[2])
        {
            for(int i = 1; i <= A[1]; ++i)
                cout << 1;

            cout << '\n';

            continue;
        }

        if(!A[1] && A[2])
        {
            for(int i = 1; i <= A[2]; ++i)
                cout << 2;

            cout << '\n';

            continue;
        }

        for(int i = 1; i <= min(A[1], A[2]); ++i)
            cout << "12";

        for(int i = min(A[1], A[2]) + 1; i <= A[1]; ++i)
            cout << 1;

        for(int i = min(A[1], A[2]) + 1; i <= A[2]; ++i)
            cout << 2;

        cout << '\n';
    }

    return 0;
}
