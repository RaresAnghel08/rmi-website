/**
* user:  yanev-c4c
* fname: Aleksandar Angelov
* lname: Yanev
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:13:37.351312
*/
#include "speedrun.h"

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    setHintLen(N);
    for(int i=1; i<=N-1; i++)
    {
        setHint(A[i],B[i],1);
    }
}
int len;
vector<int> used;
void dfs(int cur, int hint, int par)
{
    int tmp = hint;
    used[cur] = 1;
    for(int i=len; i>=1; i--)
    {
        if((tmp&1) && used[i] == 0)
        {
            goTo(i);
            dfs(i, getHint(i), cur);
        }
    }
    if(par != -1) goTo(par);
}
void speedrun(int subtask, int N, int start) { /* your solution here */
    len = getLength();
    int cur_hint = getHint(start);
    used.resize(n+1);
    dfs(start,cur_hint, -1);
}
