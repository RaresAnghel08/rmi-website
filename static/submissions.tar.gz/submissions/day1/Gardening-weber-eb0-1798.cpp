/**
* user:  weber-eb0
* fname: Daniel
* lname: Weber
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:28:40.588128
*/
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define vll vector<ll>
#define vvll vector<vll>

int main() {
    ll t;
    cin >> t;
    while (t--) {
        ll n, m, k;
        cin >> n >> m >> k;
        if ((n|m)&1) {
            goto END;
        }
        if (n == 2) {
            if (k == m/2) {
                cout << "YES\n";
                for (ll j = 0; j < n; j++) {
                    for (ll i = 0; i < m; i++) cout << 1+i/2 << ' ';
                    cout << '\n';
                }
                continue;
            }
            goto END;
        }
        if (k == m) {
            cout << "YES\n";
            ll v = 1;
            for (ll j = 0; j < n; j++) {
                if (j == 2) v += m/2;
                for (ll i = 0; i < m; i++) cout << v+i/2 << ' ';
                cout << '\n';
            }
            continue;
        } 
        if (k-1 == (m-2)/2) {
            cout << "YES\n";
            for (ll j = 0; j < n; j++) {
                for (ll i = 0; i < m; i++) {
                    if (j == 0 || j == 3 || i == 0 || i == m-1) cout << "1 ";
                    else
                        cout << 1 + (i+1)/2 << ' ';
                }
                cout << '\n';
            }
            continue;
        }
        END:
        cout << "NO\n";
    }
}