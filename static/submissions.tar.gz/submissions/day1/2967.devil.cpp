/**
* user:  florescu-0a6
* fname: Cella
* lname: Florescu
* task:  devil
* score: 13.0
* date:  2019-10-10 10:19:17.080857
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXD = 9;
const int MAXN = 1e6;

int freq[MAXD + 1];
string v;
int main()
{
//    ifstream cin(".in");
//    ofstream cout(".out");
    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(false);
    int t;
    cin >> t;
    for (int test = 0; test < t; ++test) {
      int k, sum = 0, zero = 0;
      cin >> k;
      for (int i = 1; i <= MAXD; ++i) {
        cin >> freq[i];
        sum += freq[i];
        zero += (freq[i] == 0);
      }
      int n = sum, p = 0;
      v.resize(n);
      for (int i = 0; i < n; ++i) {
        while (freq[p] == 0)
          ++p;
        v[i] = p + '0';
        --freq[p];
      }
      string mn = "", ans;
      for (int i = 0; i < k; ++i)
        mn += char('9' + 1);
      do {
        int mx = 0, j;
        for (int i = 1; i < n - k + 1; ++i) {
          j = 0;
          while (j < k && v[i + j] == v[mx + j])
            ++j;
          if (j < k && v[i + j] > v[mx + j])
            mx = i;
        }
        j = 0;
        while (j < k && v[mx + j] == mn[j])
          ++j;
        if (j < k && v[mx + j] < mn[j]) {
          for (int i = 0; i < k; ++i)
            mn[i] = v[mx + i];
          ans = v;
        }
      } while (next_permutation(v.begin(), v.end()));
      cout << ans << '\n';
    }
    return 0;
}
