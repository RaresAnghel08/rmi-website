/**
* user:  chiriac-c10
* fname: Matei
* lname: Chiriac
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:31:45.522309
*/
#include <iostream>

using namespace std;

long long t,n,m,k,a,b;

long long calc(long long n, long long m, long long k)
{
    for(long long a=0;a<min(n/2, m/2);a++)
    {
        long long b=k-a;

        if(b*4 == (n-2*a)*(m-2*a))
            return a;
    }

    /*
    else
    {
        a = n*m - 4*k;
        b = 2*(m+n) - 8;

        if(a % b)
        {
            cout<<"NO\n";
            continue;
        }

        a/=b;

        if(n - 2*a < 2 || m - 2*a < 2)
        {
            cout<<"NO\n";
            continue;
        }

        if(a > k)
        {
            cout<<"NO\n";
            continue;
        }

        if((k-a)*4 != (n-2*a)*(m-2*a))
        {
            cout<<"NO\n";
            continue;
        }
    }
    */
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    cin>>t;
    while(t)
    {
        t--;
        cin>>n>>m>>k;

        if(n%2 || m%2)
        {
            cout<<"NO\n";
            continue;
        }
        if(k*4 > m*n)
        {
            cout<<"NO\n";
            continue;
        }

        a = calc(n, m, k);

        cout<<"YES\n";
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m; j++)
            {
                long long val = min(min((long long)i, n-i+1), min((long long)j, m-j+1));

                if(val <= a)
                    cout<<val<<' ';
                else
                    cout<<((i-a-1)/2)*((m-2*a)/2) + (j-a-1)/2 + a + 1<<' ';
            }

            cout<<'\n';
        }

    }
    return 0;
}
