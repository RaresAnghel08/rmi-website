/**
* user:  nicola-f4a
* fname: Alexandra Mihaela
* lname: Nicola
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:45:07.870327
*/
#include <bits/stdc++.h>
//#include "speedrun.h"
#define DIM 1010
using namespace std;


static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;
void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}





int mrk[DIM],g[DIM];

void assignHints (int subtask, int n, int a[], int b[]){

    int i;
    if (subtask == 1){
        setHintLen(n);

        for (i=1;i<n;i++){
            int x = a[i], y = b[i];
            setHint(x,y,1);
            setHint(y,x,1);
        }
    }

    if (subtask == 2){

        for (i=1;i<=n;i++){
            g[a[i]]++;
            g[b[i]]++;
        }

        setHintLen(20);

        int val = 0;
        for (i=1;i<=n;i++)
            if (g[i] == n-1)
                val = i;

        for (i=1;i<=n;i++){
            if (i != val){
                for (int bit=0;bit<20;bit++){
                    if (val & (1<<bit))
                        setHint(i,bit+1,1);
                }
            }
        }
    }

}

void dfs (int nod, int n){
    mrk[nod] = 1;
    for (int i=1;i<=n;i++){
        if (!mrk[i] && getHint(i)){
            goTo(i);
            dfs (i,n);
            goTo(nod);
        }
    }
}

void speedrun (int subtask, int n, int start ){

    int i;
    if (subtask == 1){
        int mrk[n+1];
        for (int i=1;i<=n;i++)
            mrk[i] = 0;

        dfs (start,n);
    } else {

        /// start e centrul sau nu
        int val = 0;
        for (i=1;i<=20;i++)
            if (getHint(i))
                val += (1<<(i-1));

        if (!val){ /// e centru

            val = start;
            for (i=1;i<=n;i++){
                if (i == val)
                    continue;

                goTo(i);
                goTo(val);
            }

        } else {

            int aux = start;
            goTo(val);


            for (i=1;i<=n;i++){
                if (i == val || i == aux)
                    continue;
                goTo(i);
                goTo(val);
            }

        }


    }

}
/*
int main (){

    ifstream cin ("date.in");
    ofstream cout ("date.out");

    int N;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(1, N, a, b);

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(1, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;



    return 0;
}
*/
