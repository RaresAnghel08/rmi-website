/**
* user:  almazbekov-a71
* fname: Beksultan
* lname: Almazbekov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:53:14.864434
*/
//#include "speedrun.h"
#include <bits/stdc++.h>
#include "grader.cpp"
using namespace std;
#define pii pair<int,int>
#define fr first
#define sc second
#define NO puts("NO");
#define YES puts("YES");
#define endi puts("");
#define pb push_back
#define ret return
vector <int> g[1002];
int h;
void sett(int x,int z,int h){
	
	while (z>0){
		if (z%2==1)
			setHint(x,h,1);
		h++;
		z/=2;
	}
	
}


void dfs1(int x,int p){
	sett(x,p,1);
	if (g[x][0] != p)
		sett(x,g[x][0],h+1);
	else if (g[x].size() > 1){
		sett(x,g[x][1],h+1);
	}
	for (int i=0;i<g[x].size();++i){
		if (g[x][i] == p)continue;
		
		if (i+1 < g[x].size()){
			int to = g[x][i+1];
			if (to == p){
				if (i+2 < g[x].size())to = g[x][i+2];
				else continue;
				sett(g[x][i],to,h+h+1);
			}
			else 
				sett(g[x][i],to,h+h+1);
		}
			
		dfs1(g[x][i],x);
	}
}



void assignHints(int subtask, int N, int A[], int B[]) {
	int z = 1,i,j;
	while (z <= N){
		z *= 2;
		h++;
	}
	setHintLen(h*3);
	for (i=1;i<N;++i){
		g[A[i]].pb(B[i]);
		g[B[i]].pb(A[i]);
	}
	
	dfs1(1,0);
	
	ret ;
}
int sz;

int get1(){
	int c = 1,sum=0;
	for (int i=1;i<=sz/3;++i){
		if (getHint(i) == 1){
			sum+=c;
		}
		c*=2;
	}
	ret sum;
}

int get2(){
	int c = 1,sum=0;
	for (int i=sz/3+1;i<=sz/3+sz/3;++i){
		if (getHint(i) == 1){
			sum+=c;
		}
		c*=2;
	}
	ret sum;
}
int get3(){
	int c = 1,sum=0;
	for (int i=sz/3*2+1;i<=sz;++i){
		if (getHint(i) == 1){
			sum+=c;
		}
		c*=2;
	}
	ret sum;
}
set <int> s[1001];
int used[1001];
void dfs(int v){
	goTo(v);
	used[v]++;
	int x = get1(),y = get2() ,z = get3();
	if (x != 0){
		s[v].insert(x);
	}
	if (y != 0){
		s[v].insert(y);
	}
	if (z != 0){
		s[x].insert(z);
	}
	for (auto to:s[v]){
		if (used[to] == 0){
			dfs(to);
		}
	}
	for (auto to:s[v]){
		if (used[to] == 1){
			
			dfs(to);
			goTo(v);
		}
	}
}

void speedrun(int subtask, int N, int start) {
	sz = getLength();
	dfs(start);
	
}
