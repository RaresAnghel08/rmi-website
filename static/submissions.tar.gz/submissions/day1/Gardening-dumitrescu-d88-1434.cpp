/**
* user:  dumitrescu-d88
* fname: Eduard Valentin
* lname: Dumitrescu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:55:26.289724
*/
#include <bits/stdc++.h>

//std::ifstream fin("date.in");

#define fin std::cin
#define fout std::cout

std::vector <std::vector <int>> x;
std::vector <std::vector <int>> min;

int max(int n, int m) {
    return (n/2) * (m/2);
}

int color = 0;

void divide(int si, int sj, int n, int m, int k) {
    int min1, min2, max1, max2;

    if(n == 2) {
        for(int j = sj; j < sj+m; j += 2) {
            color++;
            x[si][j] = x[si][j+1] = x[si+1][j] = x[si+1][j+1] = color;
        }
        return;
    }
    if(m == 2) {
        for(int i = si; i < si+n; i += 2) {
            color++;
            x[i][sj] = x[i][sj+1] = x[i+1][sj] = x[i+1][sj+1] = color;
        }
        return;
    }

    if(min[n-2][m-2] <= k - 1 and  k - 1 <= max(n-2, m-2)) {
        color ++;
        for(int i = si; i  < si+n; i ++)
            x[i][sj] = x[i][sj+m-1] = color;
        for(int j = sj; j < sj+m; j ++)
            x[si][j] = x[si+n-1][j] = color;
        divide(si+1, sj+1, n-2, m-2, k-1);
        return;
    }

    for(int j = 2; j < m; j += 2) {
        min1 = min[n][j];
        min2 = min[n][m-j];
        max1 = max(n, j);
        max2 = max(n, m-j);
        if(min1 + min2 <= k and k <= max1 + max2) {
            if(min1 + max2 <= k) {
                divide(si, sj, n, j, k-max2);
                divide(si, sj+j, n, m-j, max2);
                return;
            }
            else{
                divide(si, sj, n, j, min1);
                divide(si, sj+j, n, m-j, k-min1);
                return;
            }
        }
    }

    for(int i = 2; i < n; i += 2) {
        min1 = min[i][m];
        min2 = min[n-i][m];
        max1 = max(i, m);
        max2 = max(n-i, m);
        if(min1 + min2 <= k and k <= max1 + max2) {
            if(min1 + max2 <= k) {
                divide(si, sj, i, m, k-max2);
                divide(si+i, sj, n-i, m, max2);
                return;
            }
            else{
                divide(si, sj, i, m, min1);
                divide(si+i, sj, n-i, m, k-min1);
                return;
            }
        }
    }




}

void solve() {
    int n, m, k;
    fin >> n >> m >> k;

    if(n % 2 == 1 or m % 2 == 1) {
        fout << "NO\n";
        return;
    }

    min.resize(n+2);
    for(int i = 0; i <= n; i ++)
        min[i].resize(m+2);
    min[2][2] = 1;

    for(int i = 2; i <= n; i += 2)
        min[i][2] = i / 2;

    for(int j = 2; j <= m; j += 2)
        min[2][j] = j / 2;

    for(int i = 4; i <= n; i ++) {
        for(int j = 4; j <= m; j ++) {
            min[i][j] = min[i-2][j-2] + 1;
        }
    }

    if(k < min[n][m] or k > max(n, m)) {
        fout << "NO\n";
        return;
    }

    x.resize(n+1);
    for(int i = 1; i <= n; i ++)
        x[i].resize(m+1);
    color = 0;
    divide(1, 1, n, m, k);


    fout << "YES\n";
    for(int i = 1; i <= n; i ++, fout << '\n')
        for(int j = 1; j <= m; j ++)
            fout << x[i][j] << ' ';


}
int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);


    int Q;
    fin >> Q;
    while(Q --) {
        solve();
    }

    return 0;
}