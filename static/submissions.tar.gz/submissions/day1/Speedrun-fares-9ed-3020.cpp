/**
* user:  fares-9ed
* fname: Yusuf
* lname: Fares
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 10:28:28.160199
*/
#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

int f[1003];

void assignHints(int subtask , int n , int A[] , int B[]) {
  int i, j, val, start1, start2;

  if (subtask == 1) {
    setHintLen(n);
    for (i = 1; i < n; i++) {
      setHint(A[i], B[i], 1);
      setHint(B[i], A[i], 1);
    }
  }
  else if (subtask == 2) {
    setHintLen(10);

    for (i = 1; i <= n; i++)
      f[i] = 0;

    for (i = 1; i < n; i++) {
      f[A[i]]++, f[B[i]]++;
      if (f[A[i]] == n - 1)
        val = A[i];
      else if (f[B[i]] == n - 1)
        val = B[i];
    }

    string s;
    for (i = 0; i < 10; i++) {
      if (val & (1 << i))
        s += '1';
    }

    for (i = 1; i <= n; i++) {
      for (j = 0; j < s.size(); j++)
        setHint(i, j + 1, s[i] - '0');
    }
  }
  else if (subtask == 3) {

    for (i = 1; i <= n; i++)
      f[i] = 0;

    setHintLen(20);
    for (i = 1; i < n; i++) {
      string s1, s2;
      f[A[i]]++;
      f[B[i]]++;
      val = A[i];
      for (j = 0; j < 10; j++) {
        if (val & (1 << j))
          s1 += '1';
      }

      val = B[i];
      for (j = 0; j < 10; j++) {
        if (val & (1 << j))
          s2 += '1';
      }

      if (f[A[i]] == 1)
        start1 = 1;
      else
        start1 = 11;

      if (f[B[i]] == 1)
        start2 = 1;
      else
        start2 = 11;

      for (j = start1; j < start1 + 10; j++)
        setHint(A[i], j, s2[j - start1] - '0');
      for (j = start2; j < start2 + 10; j++)
        setHint(B[i], j, s1[j - start2] - '0');
    }
  }
}

int distnode;

void dfs1(int node, int n) {
  int i;
  if (f[node] == 0)
    distnode++, f[node] = 1;

  if (distnode == n)
    return;

  for (i = 1; i <= n; i++) {
    if (i != node && f[i] == 0 && getHint(i) == true) {
      goTo(i);
      dfs1(i, n);
      if (distnode != n)
        goTo(node);
    }
  }
}

void dfs2(int node, int n) {
  int i, son1, son2;

  f[node] = 1;
  distnode++;

  if (distnode == n)
    return;

  son1 = 0;
  for (i = 1; i <= 10; i++)
    if (getHint(i))
      son1 += (1 << (i - 1));

  son2 = 0;
  for (i = 11; i <= 20; i++)
    if (getHint(i))
      son2 += (1 << (i - 11));

  if (f[son1] == 0) {
    goTo(son1);
    dfs2(son1, n);
    if (distnode != n)
      goTo(node);
  }
  if (f[son2] == 0) {
    goTo(son2);
    dfs2(son2, n);
    if (distnode != n)
      goTo(node);
  }
}

void speedrun ( int subtask , int n , int start ) {
  int i, node;
  if (subtask == 1) {
    for (i = 1; i <= n; i++)
      f[i] = 0;
    distnode = 0;
    dfs1(start, n);
  }
  else if (subtask == 2) {
    node = 0;
    for (i = 1; i <= 10; i++) {
      if (getHint(i))
        node += (1 << (i - 1));
    }

    if (start != node)
      goTo(node);
    for (i = 1; i <= n; i++) {
      if (i != start && i != node) {
        goTo(i);
        goTo(node);
      }
    }
  }
  else if (subtask == 3) {
    for (i = 1; i <= n; i++)
      f[i] = 0;

  }
}
