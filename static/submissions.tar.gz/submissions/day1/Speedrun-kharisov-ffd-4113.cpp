/**
* user:  kharisov-ffd
* fname: Bulat Rafailevich
* lname: Kharisov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:57:42.860679
*/
#include "speedrun.h"
#include<bits/stdc++.h>
using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    vector<vector<bool>> gr(N, vector<bool>(N));
    for (int i = 1; i < N; ++i) {
        --A[i], --B[i];
        gr[A[i]][B[i]] = gr[B[i]][A[i]] = true;
    }

    if (subtask == 1 || subtask == 4) {
        setHintLen(250);
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; j += 4) {
                int c = 0;
                for (int k = 0; k < 4 && j+k < N; ++k)
                    c += gr[i][j+k];
                setHint(i+1, j/4*2, c>>1);
                setHint(i+1, j/4*2+1, c&1);
            }
        }
    } else {
        setHintLen(20);
        for (int i = 0; i < N; ++i) {
            int num = 0;
            for (int j = 0; j < N; ++j) {
                if (!gr[i][j]) continue;
                for (int k = 0; k < 10; ++k) {
                    setHint(i+1, num++, (j+1)>>k&1);
                }
            }
        }
    }
}

int n, su;

void dfs(int v, int pr = -1) {
    if (su == 1 || su == 4) {
        for (int j = 0; j < n; j += 4) {
            int c = getHint(j/4*2)*2+getHint(j/4*2+1);
            if (pr >= j && pr < j+4) --c;
            if (c > 0) {
                for (int k = j; k < n && k < j+4; ++k) {
                    if (k+1 != v && k+1 != pr && goTo(k+1)) dfs(k+1, v);
                }
            }
        }
    } else {
        for (int it = 0; it < 2; ++it) {
            int num = 0;
            for (int i = 0; i < 10; ++i) {
                num += (getHint(it*10+i) << i);
            }
            if (num && num != pr) {
                goTo(num);
                dfs(num, v);
            }
        }
    }
    if (pr != -1) goTo(pr);
}

void speedrun(int subtask, int N, int start) { /* your solution here */
    n = N;
    su = subtask;
    dfs(start);    
}