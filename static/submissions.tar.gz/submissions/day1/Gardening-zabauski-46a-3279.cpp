/**
* user:  zabauski-46a
* fname: Daniil
* lname: Zabauski
* task:  Gardening
* score: 5.0
* date:  2021-12-16 10:51:31.333970
*/
#include<bits/stdc++.h>
#define fi first
#define se second
#define sz(x) (int)(x).size()
using namespace std;

const bool debug = 0;

vector < pair < int , int > > travel = {
{-1 , 0},
{+1 , 0},
{0 , +1},
{0 , -1}
};
bool bad = 0;
void dfs(int i , int j, int n , int m , vector < vector < int > > &answer , vector <  vector < bool > > &used){
    used[i][j] = 1;
    int t = 0;
    for(auto &u : travel){
        int i1 = i + u.fi , j1 = j + u.se;
        if(i1 < n && i1 >= 0 && j1 < m && j1 >= 0 && answer[i1][j1] == answer[i][j]){
            t++;
            if(!used[i1][j1])
            dfs(i1 , j1, n , m , answer , used);
        }
    }
    if(t != 2)
    bad = 1;
}



bool check(int n , int m , int k ,vector < vector < int > > &answer){
    set < int > colors;
    for(int i = 0 ; i < n; ++i){
        for(int j = 0 ; j < m; ++j){
            colors.insert(answer[i][j]);
        }
    }
    if(sz(colors) != k)
        return false;
    vector < int > bycolor(k + 1);
    for(int i = 0; i < n; ++i){
        for(int j = 0 ; j < m; ++j){
            if(answer[i][j] == 0){
                return false;
            }
            if(answer[i][j] > k){
                return false;
            }
        }
    }
    bad = 0;
    vector < vector < bool > >  used(n , vector < bool > (m));
    for(int i = 0; i < n; ++i){
        for(int j = 0 ; j < m; ++j){
            if(used[i][j])
                continue;
            bycolor[answer[i][j]]++;
            dfs(i , j , n , m , answer , used);
        }
    }
    for(int f = 1; f <= k; ++f){
        if(bycolor[f] > 1)
        return false;
    }
    if(bad)
    return false;
    return true;

}
void solve(int n , int m , int k){

    if((n & 1) || (m & 1)){
        if(!debug)cout << "NO\n";
        return;
    }
    if(k > (n / 2) * (m / 2)){
        if(!debug)cout << "NO\n";
        return;
    }
    int prv = 0;
    vector < vector < int > > answer(n , vector < int > (m));
    int cur = 1;
    bool done = 0;


    int times = min(n / 2, m / 2);




    if(k < times){
        if(!debug)cout << "NO\n";
        return;
    }
    int clr = 1;


    /// kek

    int t = times - 1;
    for(int i = 0; i < times - 1; ++i){

        if((n / 2 - (i + 1)) * (m / 2 - (i + 1)) < (k + 1 - clr) - 1){
            t = i;
            break;
        }


        for(int fj = i; fj < m - i; ++fj){
            answer[i][fj] = clr;
        }

        for(int fj = i; fj < m - i; ++fj){
            answer[n - 1 - i][fj] = clr;
        }

        for(int fi = i; fi < n - i; ++fi){
            answer[fi][m - 1 - i] = clr;
        }

        for(int fi = i; fi < n - i; ++fi){
            answer[fi][i] = clr;
        }
        clr++;

    }

//    cout << " HERE " << t << endl;
    /// okay
    int ostcolors = k - clr + 1;

    int ostcells = (n / 2 - t) * (m / 2 - t);

    int candelete = ((n / 2 - t) / 2)  * ((m / 2 - t) / 2);


    int left = ostcolors;


//    cout << "yo " << t << ' '<< ostcells << ' ' << candelete << endl;

//    cout <<
    int needdelete = (ostcells - ostcolors);
//    cout << " here " << needdelete << ' ' << candelete << ' ' << endl;
//    cout << " here " << ostcells << ' ' << ostcolors << endl;
    if(needdelete < 0){
//        cout << "LOL " << n << ' ' << m << ' ' << k << endl;

        if(!debug)cout << "NO\n";
        return;
    }
    if(needdelete % 2 == 1){
//        cout << "LOL " << n << ' ' << m << ' ' << k << endl;

        if(!debug)cout << "NO\n";
        return;
    }
    needdelete /= 2;
    if(needdelete > candelete){
//        cout << "WTF "
//        cout << "LOL " << n << ' ' << m << ' ' << k << endl;
        if(!debug)cout << "NO\n";
        return;
    }
    for(int i = t; i < n - t; i += 4){
        for(int j = t; j < m - t ;j += 4){
            if(i + 4 > n - t)
                break;
            if(j + 4 > m - t)
                break;

            if(needdelete){
                for(int fj=j;fj<j+4;++fj){
                    answer[i][fj] = clr;
                }
                for(int fj=j;fj<j+4;++fj){
                    answer[i+3][fj] = clr;
                }
                for(int fi=i;fi<i+4;++fi){
                    answer[fi][j] = clr;
                }
                for(int fi=i;fi<i+4;++fi){
                    answer[fi][j + 3] = clr;
                }
                clr++;
                answer[i + 1][j + 1] = clr;
                answer[i  + 1][j + 2] = clr;
                answer[i + 2][j + 1] = clr;
                answer[i + 2][j + 2] = clr;
                clr++;
                assert(clr != (k + 2));
                needdelete--;
            }
        }
    }



    for(int i = t; i < n - t; i += 2){
        for(int j = t; j < m - t; j += 2){
            if(answer[i][j])
                continue;
            answer[i][j]=clr;
            answer[i+1][j]=clr;
            answer[i][j+1]=clr;
            answer[i+1][j+1]=clr;
            clr++;
            assert(clr != (k + 2));
        }
    }

    done = 1;

    if(!debug){
        if(!done || (n == 1) || (m == 1)){
            cout << "NO\n";
        }else{
            cout << "YES\n";
            if(!check(n , m , k , answer)){
                cout << " FUKK \n";
                cout << n << ' '  << m << ' ' << k << endl;
                assert(false);
                exit(0);

            }
            for(int i = 0 ; i < n; ++i){
                for(int j = 0;  j < m; ++j){
                    cout << answer[i][j] << ' ';
                }
                cout << '\n';
            }
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);
//    solve(6 , 12 , 12);
//    for(int n = 1; n <= 4; ++n){
//        for(int m = 10000 ; m <= 10000; ++m){
//            for(int k = 1; k <= max(n , m); ++k){
////                cout << n << ' ' << m << ' ' << k << endl;
//                solve(n , m , k);
////                cout << endl;
//            }
//        }
//    }
    int t;
    cin >> t;
    while(t--){
        int n , m , k;
        cin >> n >> m >> k;
        solve(n , m , k);
    }
    return 0;
}
