/**
* user:  kostylev-ce5
* fname: Gleb
* lname: Kostylev
* task:  Gardening
* score: 11.0
* date:  2021-12-16 10:15:14.391487
*/
#include <bits/stdc++.h>
#define pb push_back
#define mp make_pair
#define ff first
#define ss second
#define LONG

typedef long long ll;
typedef long double ld;

using namespace std;

const int inf9 = 1e9 + 10;
const ll inf18 = 1e18 + 10;

#ifdef LONG
#define int ll
#define inf inf18
#else
#define inf inf9
#endif

template <typename T1, typename T2> istream& operator>>(istream& is, pair <T1, T2>& a){is >> a.ff >> a.ss;return is;}
template <typename T1, typename T2> ostream& operator<<(ostream& os, pair <T1, T2> a){os << "(" << a.ff << ", " << a.ss << ")";return os;}
template <typename T> istream& operator>>(istream& is, vector <T>& a){for (int i = 0; i < a.size(); i++){is >> a[i];}return is;}
template <typename T> ostream& operator<<(ostream& os, vector <T> a){for (int i = 0; i < a.size(); i++){os << a[i] << " ";}/*os << endl;*/return os;}
template <typename T> void print(T a){for (auto x : a){cout << x << " ";}cout << endl;}

void solve()
{
    int n, m, k;
    cin >> n >> m >> k;
    if (n % 2 || m % 2)
    {
        cout << "NO\n";
        return;
    }
    if (n == 2)
    {
        if (m == k * 2)
        {
            cout << "YES\n";
            for (int i = 0; i < 2; i++)
            {
                for (int j = 1; j <= k; j++)
                {
                    cout << j << " " << j << " ";
                }
                cout << endl;
            }
        }
        else
        {
            cout << "NO\n";
        }
    }
    else if (n == 4)
    {
        int c = (m - k) * 2, d = m - c;
        if ((c == 0 || c >= 4) && d >= 0)
        {
            cout << "YES\n";
            vector <int> l1, l2, l3, l4;
            if (c > 0)
            {
                l2.pb(1);
                l1.pb(1);
                for (int i = 2; i <= c / 2; i++)
                {
                    l1.pb(1);
                    l1.pb(1);
                    l2.pb(i);
                    l2.pb(i);
                }
                l1.pb(1);
                l2.pb(1);
            }
            for (int i = c / 2 + 1; i <= k; i += 2)
            {
                l3.pb(i);
                l3.pb(i);
                l4.pb(i + 1);
                l4.pb(i + 1);
            }
            cout << l1 << l3 << endl << l2 << l3 << endl << l2 << l4 << endl << l1 << l4 << endl;
        }
        else
        {
            cout << "NO\n";
        }
    }
    else
    {
        cout << ":(\n";
    }
}

int32_t main()
{
    #ifndef LOCAL
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    #endif
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}

