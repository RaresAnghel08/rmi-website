/**
* user:  kwiatkowski-76e
* fname: Jan
* lname: Kwiatkowski
* task:  devil
* score: 100.0
* date:  2019-10-10 07:03:38.078951
*/
#include <bits/stdc++.h>

using namespace std;

#define f first
#define s second

const int MAXN = 13;
const int MAXM = 1e6 + 3;

int t[MAXN];
vector<int> odp;
vector<int> v[MAXM];
vector<int> vec;

int main() {
    int z, n, k;
    int pnt, ile;
    int pop, zab;
    bool st;
    scanf("%d", &z);
    while (z--) {
        scanf("%d", &k);
        for (int i = 1; i < 10; i++)
            scanf("%d", &t[i]);
        pnt = 9;
        ile = 0;
        while (t[pnt] + ile < k) {
            ile += t[pnt];
            for (int i = 1; i <= t[pnt]; i++)
                odp.push_back(pnt);
            pnt--;
        }
        while (ile != k - 1) {
            odp.push_back(pnt);
            t[pnt]--;
            ile++;
        }
        for (int i = 1; i <= t[pnt]; i++)
            v[i].push_back(pnt);
        for (int i = pnt - 1; i > 0; i--) {
            for (int j = 1; j <= t[i]; j++)
                vec.push_back(i);
        }
        pop = 1;
        while (!vec.empty()) {
            for (int i = pop; i <= t[pnt]; i++) {
                if (!vec.empty()) {
                    v[i].push_back(vec.back());
                    vec.pop_back();
                }
            }
            while (v[pop].back() < v[t[pnt]].back() || v[pop].size() != v[t[pnt]].size())
                pop++;
        }
        //printf("%d ", pop);
        /*
        for (int i = 1; i <= t[pnt]; i++) {
            for (auto it:v[i])
                printf("%d ", it);
            printf("\n");
        }
        */
        st = false;
        if (v[t[pnt]].size() >= k)
            st = true;
        zab = 1;
        while (!st) {
            for (int i = pop; i <= t[pnt]; i++) {
                if (zab != pop) {
                    for (auto it:v[zab])
                        v[i].push_back(it);
                    zab++;
                }
            }
            while (v[pop].size() != v[t[pnt]].size() || v[pop].back() < v[t[pnt]].back())
                pop++;
            if (pop == zab || v[t[pnt]].size() >= k)
                st = true;
        }
        for (int i = t[pnt]; i >= zab; i--) {
            for (auto it:v[i])
                printf("%d", it);
        }
        for (int i = 1; i <= t[pnt]; i++)
            v[i].clear();
        for (int i = odp.size() - 1; i >= 0; i--)
            printf("%d", odp[i]);
        odp.clear();
        printf("\n");
    }
    return 0;
}
