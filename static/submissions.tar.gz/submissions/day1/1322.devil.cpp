/**
* user:  enache-10e
* fname: Alexandru
* lname: Enache
* task:  devil
* score: 0.0
* date:  2019-10-10 06:17:39.584205
*/
//ALEX ENACHE

#include <bits/stdc++.h>

using namespace std;

int v[11];
int k;

deque < int > q;

string s;

void solve2(){
    s.clear();
    for (int i=1; i<=9; i++){
        while (v[i]--){
            q.push_back(i);
        }
    }

    int fata = 1;
    while (!q.empty()){
        if (fata){
            s += char('0' + q.back());
            q.pop_back();
        }
        else{
            s += char('0' + q.front());
            q.pop_front();
        }
        fata ^= 1;
    }
    cout<<s<<'\n';
}

int main()
{
    //freopen ("input" , "r" , stdin);freopen ("output" , "w" , stdout);

    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int t;
    cin>>t;

    while (t--){
        cin>>k;
        for (int i=1; i<=9; i++){
            cin>>v[i];
        }
        solve2();
    }

    return 0;
}
