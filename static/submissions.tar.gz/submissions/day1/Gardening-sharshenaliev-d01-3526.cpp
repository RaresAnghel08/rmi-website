/**
* user:  sharshenaliev-d01
* fname: Nazar
* lname: Sharshenaliev
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:14:49.469601
*/
#include <bits/stdc++.h>
using namespace std;
int a[500][200000];
int main(){
	int t; cin >> t;
	while(t--){	
	int n , m , k;
	cin >> n >> m >> k;
		//true answer
		if(n == m and n == 2 and k == 1){
			cout << "YES" << endl;
			cout << "1 1"<<endl;
			cout << "1 1"<< endl;
		}else if(n == m and k == 2 and m == 4){
			cout << "YES" << endl;
			cout << "1 1 1 1"<<endl;
			cout << "1 2 2 1"<<endl;
			cout << "1 2 2 1"<<endl;
			cout << "1 1 1 1"<<endl;
		}
		else if(n == m and k == 4 and m == 4){
			cout <<"YES"<<endl;
			cout << "1 1 2 2"<<endl;
			cout << "1 1 2 2"<<endl;
			cout << "3 3 4 4"<<endl;
			cout << "3 3 4 4"<<endl;
		}else if (n == 4 and (m - 2) % 4 == 0 and k == (m - 2) / 2 + 1){
			for (int j = 0; j < m; j++){
				a[0][j] = 1;
				a[3][j] = 1;
			}
			a[1][0] = 1;
			a[2][0] = 1;
			a[1][m-1] = 1;
			a[2][m-1] = 1;
			int r = 2;
			for (int j = 1; j < m - 1; j++){
				a[1][j] = r;
				a[2][j] = r;
				if(j % 2 == 0)r++;			}
			for (int i = 0; i < n; i++){
				for (int j = 0; j < m; j++){
					cout << a[i][j] <<" ";
				}
				cout << endl;
			}
		}else cout << "NO" << endl;
	}return 0;
}