/**
* user:  asadullin-bba
* fname: Aidar Ildarovich
* lname: Asadullin
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 08:42:39.051469
*/
#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

int getbit(int mask, int i) {
    return (mask >> i) & 1;
}

void setbit(int &mask, int i, int op) {
    if (op == 1)
        mask |= (1 << i);
}

void assignHints(int subtask, int N, int A[], int B[]) {

    vector<int> g[N];
    for (int i = 1; i < N; ++i) {
        int a = A[i] - 1;
        int b = B[i] - 1;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    if (subtask == 1) {
        setHintLen(N);
        for (int j = 0; j < N; ++j) {
            for (int i = 0; i < g[j].size(); ++i) {
                int to = g[j][i] + 1;
                setHint(j + 1, to, 1);
            }
        }
    }
    if (subtask == 2) {
        int v = 0;
        for (int i = 0; i < N; ++i) {
            if (g[v].size() < g[i].size())v = i;
        }
        setHintLen(20);
        vector<int> bits(10);
        for (int k = 0; k < 10; ++k) {
            bits[k] = getbit(v + 1, k);
        }
        for (int j = 0; j < N; ++j) {
            for (int m = 0; m < bits.size(); ++m) {
                setHint(j + 1, m + 1, bits[m]);
            }
        }
    }
    if (subtask == 3) {
        setHintLen(20);
        for (int j = 0; j < N; ++j) {
            vector<int> bits;
            for (int i = 0; i < g[j].size(); ++i) {
                int to = g[j][i] + 1;
                vector<int> b(10);
                for (int k = 0; k < 10; ++k) {
                    b[k] = getbit(to, k);
                }
                for (int l = 0; l < b.size(); ++l) {
                    bits.push_back(b[l]);
                }
            }
            for (int m = 0; m < bits.size(); ++m) {
                setHint(j + 1, m + 1, bits[m]);
            }
        }
    }
}

int n;

void dfs(int v, int p) {
    for (int i = 0; i < n; ++i) {
        if (i == p)continue;
        if (getHint(i + 1) == 1) {
            goTo(i + 1);
            dfs(i, v);
        }
    }
    if (p != -1) {
        goTo(p + 1);
    }
}

void dfs3(int v, int p) {
    vector<int> to(2);
    for (int j = 0; j < 10; ++j) {
        setbit(to[0], j, getHint(j + 1));
    }
    for (int j = 0; j < 10; ++j) {
        setbit(to[1], j, getHint(j + 1 + 10));
    }
    for (int i = 0; i < to.size(); ++i) {
        int t = to[i] - 1;
        if (t == p || t == -1)continue;
        goTo(t + 1);
        dfs3(t, v);
    }
    if (p != -1) {
        goTo(p + 1);
    }
}

void dfs2(int v, int p) {
    vector<int> to;
    int el = 0;
    for (int j = 0; j < 10; ++j) {
        setbit(el, j, getHint(j + 1));
    }
    if (el - 1 == v) {
        for (int i = 0; i < n; ++i) {
            to.push_back(i + 1);
        }
    } else {
        to.push_back(el);
    }
    for (int i = 0; i < to.size(); ++i) {
        int t = to[i] - 1;
        if (t == p || t == v)continue;
        goTo(t + 1);
        dfs2(t, v);
    }
    if (p != -1) {
        goTo(p + 1);
    }
}

void speedrun(int subtask, int N, int start) {
    n = N;
    if (subtask == 1) {
        dfs(start - 1, -1);
    }
    if (subtask == 2) {
        dfs2(start - 1, -1);
    }
    if (subtask == 3) {
        dfs3(start - 1, -1);
    }
}
