/**
* user:  verzotti-765
* fname: Matteo-Alexandru
* lname: Verzotti
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 07:45:45.710584
*/
#include "speedrun.h"
#include <bits/stdc++.h>
#define dbg(x) cerr << #x << ' ' << x << '\n'
#define dbgsp(x) cerr << #x << ' ' << x << ' '

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(N);
    for (int i = 1; i < N; i++) {
        setHint(B[i], A[i], true);
        setHint(A[i], B[i], true);
    }

    return;
}

void dfs(int node, int n, int parent = -1) {
    //dbgsp(node); dbg(parent);
    for (int i = 1; i <= n; i++) {
        bool bit = getHint(i);
        if (bit == true && i != parent) {
            goTo(i);
            dfs(i, n, node);
        }
    }
    
    if (parent != -1)
        goTo(parent);
}

void speedrun(int subtask, int N, int start) {
    dfs(start, N);
}
