/**
* user:  calota-e12
* fname: Andrei
* lname: Calotă
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:52:35.394892
*/

#include "speedrun.h"

void assignHints ( int subtask, int N, int A[], int B[] ) {
    setHintLen ( N );
   for ( int i = 1; i < N; i ++ ) {
      setHint ( A[i], B[i], 1 );
      setHint ( B[i], A[i], 1 );
   }
}

void speedrun ( int subtask, int N, int start) {
   for ( int node = 1; node <= N; node ++ ) {
      if ( getHint ( node ) && viz.find ( node ) == end ( viz ) ) {
        goTo ( node );
        speedrun ( sub, N, node );
      }
      current_node = start;
     /// cout << start << " " << current_node << " " << node << "\n";
  }
}

