/**
* user:  karagyozov-c76
* fname: Ivo
* lname: Karagyozov
* task:  lucky
* score: 28.0
* date:  2019-10-10 07:11:42.236222
*/
#include <bits/stdc++.h>

const int64_t MAX_N = 1e5;
const int64_t MOD = 1e9 + 7;

int64_t dp[MAX_N + 5];

int64_t calc(const std::string &s) {
	int64_t ans = 0;
	for(int64_t i = 0; i < s.size(); i++) {
		if(i == s.size() - 1) {
			ans = (ans + (s[i] - '0') + 1) % MOD;
			break;
		}

		if(s[i] == '0') {
			continue;
		}
		
		if(i == 0 || s[i - 1] != '1') {
			ans = ((int64_t) ans + (int64_t) (s[i] - '0') * dp[s.size() - i - 1]) % MOD;
			if(s[i] != '1' && s.size() - i - 2 >= 0) {
				ans -= dp[s.size() - i - 2];	
				if(ans < 0) {
					ans += MOD;
				}
			}
		}
		else {
			if(s[i] <= '3') {
				ans = ((int64_t) ans + (int64_t) (s[i] - '0') * dp[s.size() - i - 1]) % MOD;
				if(s[i] == '2' && s.size() - i - 2 >= 0) {
					ans -= dp[s.size() - i - 2];
					if(ans < 0) {
						ans += MOD;	
					}
				}

				if(s[i] == '3') {
					break;
				}
			}
			else {
				ans = ((int64_t) ans + (int64_t) (s[i] - '0' - 1) * dp[s.size() - i - 1]) % MOD;
				if(s.size() - i - 2 >= 0) {
					ans -= dp[s.size() - i - 2];
					if(ans < 0) {
						ans += MOD;
					}
				}
			}
		}
	}

	return ans;
}

int main() {
	std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);

	int64_t n;
	std::cin >> n;
	
	dp[0] = 1;
	dp[1] = 10;
	dp[2] = 99;
	for(int64_t i = 3; i <= n - 1; i++) {	
		dp[i] = ((int64_t) 10 * dp[i - 1] - dp[i - 2]) % MOD;
	}

	int64_t k;
	std::cin >> k;

	std::string x;
	std::cin >> x;

	std::cout << calc(x) << '\n';

	for(int64_t i = 0; i < k; i++) {
		int64_t type;
		std::cin >> type;

		if(type == 1) {
			int64_t l, r;
			std::cin >> l >> r;
			
			std::string aux = x.substr(l - 1, r - l + 1);
			std::cout << calc(aux) << '\n';
		}
		else {
			int32_t ind, newD;
			std::cin >> ind >> newD;

			x[ind - 1] = (char) (newD + '0');
		}
	}
}
