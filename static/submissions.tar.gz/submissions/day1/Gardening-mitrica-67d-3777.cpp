/**
* user:  mitrica-67d
* fname: Alessia Georgiana Gabriela
* lname: Mitrică
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:35:14.081407
*/
#include <iostream>

using namespace std;
int t,n,m,k,a[1001][1001];
void afisare()
{
    for(int i=1;i<=n;i++)
   {
      for(int j=1;j<=m;j++)
        cout<<a[i][j]<<" ";
      cout<<"\n";
    }
}
int main()
{
    cin>>t;
    while(t--)
    {
        cin>>n>>m>>k;
        if(k==1&&m!=n)
            cout<<"NO"<<"\n";
        else
            if(k==1&&m==n&&m!=k)
        {
            cout<<"YES\n";
            for(int i=1;i<=n;i++)
            {
                for(int j=1;j<=n;j++)
                    cout<<1<<" ";
                cout<<"\n";
            }
        }
        /*else
        if(n==1)
        {
            if(m==k)
            {
                cout<<"YES\n";
            for(int i=1;i<=k;i++)
                cout<<i<<" ";
            }
            else
            {
                cout<<"NO\n";
            }
        }*/
       /* else
        if(m==1)
        {
            if(n==k)
            {
                cout<<"YES\n";
            for(int i=1;i<=k;i++)
                cout<<i<<" ";
            }
            else
            {
                cout<<"NO\n";
            }
        }*/
        else

            if(n==m&&n>3)
                if(k==2)
            {
                cout<<"YES\n";
                for(int i=1;i<=n;i++)
                    a[1][i]=a[n][i]=a[i][1]=a[i][n]=1;
                for(int i=1;i<=n;i++)
                 {
                  for(int j=1;j<=n;j++)
                {
                    if(a[i][j]==0)
                        a[i][j]=2;
                    cout<<a[i][j]<<" ";

                }
                cout<<"\n";
                 }
            }
                if(n==m&&k==2&&(n==2))
                 cout<<"NO\n";
             else
                if(k==4&&n%2==0&&m==n)
             {
                 cout<<"YES\n";
                 for(int i=1;i<=n/2;i++)
                    for(int j=1;j<=n/2;j++)
                       a[i][j]=1;
                 for(int i=1;i<=n/2;i++)
                    for(int j=n/2+1;j<=n;j++)
                      a[i][j]=2;
                 for(int i=n/2+1;i<=n;i++)
                    for(int j=1;j<=n/2;j++)
                      a[i][j]=3;
                 for(int i=n/2+1;i<=n;i++)
                    for(int j=n/2+1;j<=n;j++)
                     a[i][j]=4;

                 for(int i=1;i<=n;i++)
                 {
                     for(int j=1;j<=n;j++)
                        cout<<a[i][j]<<" ";
                     cout<<"\n";
                 }
             }

        else
      if(n==m&&k==n*m&&n!=2)
      {
          cout<<"YES\n";
          int x=1;
          for(int i=1;i<=n;i++)
          {
              for(int j=1;j<=n;j++)
              {
                  cout<<x<<" ";
                  x++;
              }
              cout<<"\n";
          }
      }
      else
        if(k==n*m)
        {
            cout<<"YES\n";
            int x=1;
            for(int i=1;i<=n;i++)
            {
              for(int j=1;j<=m;j++)
              {
                  cout<<x<<" ";
                  x++;
              }
              cout<<"\n";
            }

        }
      if(n==2&&m==3)
      {
        if(k==2)
        cout<<"NO\n";
        else
            if(k==3)
        {
            cout<<"YES\n";
            cout<<"1 1 2\n";
            cout<<"1 1 3\n";
        }
        else
            if(k==4||k==5)
              cout<<"NO\n";
      }
      else
        if(n==3&&m==2)
      {
          if(k==2)
            cout<<"NO\n";
          else
            if(k==3)
          {
              cout<<"YES\n";
              cout<<"1 1\n";
              cout<<"1 1\n";
              cout<<"2 3\n";
          }
          else
            if(k==4||k==5)
            cout<<"NO\n";
      }
      else
        if(n==2&&m==4)
      {
          if(k==6||k==7)
            cout<<"NO\n";
        else
         if(k==5)
         {
             cout<<"YES\n";
             cout<<"1 1 2 3\n";
             cout<<"1 1 4 5\n";
         }
         else
            if(k==2)
         {
             cout<<"YES\n";
             cout<<"1 1 2 2\n";
             cout<<"1 1 2 2\n";
         }
         else
            if(k==3)
         {
             cout<<"YES\n";
             cout<<"1 1 1 2\n";
             cout<<"1 1 1 3\n";
         }

      }
      else
        if(n==4&&m==2)
      {
          if(k==6||k==7)
            cout<<"NO\n";
        else
            if(k==5)
            {
                cout<<"YES\n";
                cout<<"1 1\n";
                cout<<"1 1\n";
                cout<<"2 3\n";
                cout<<"4 5\n";
            }
            else
                if(k==2)
            {
                cout<<"YES\n";
                cout<<"1 1\n";
                cout<<"1 1\n";
                cout<<"2 2\n";
                cout<<"2 2\n";
            }
            else
                if(k==3)
            {
                cout<<"YES\n";
                cout<<"1 1\n";
                cout<<"1 1\n";
                cout<<"1 1\n";
                cout<<"2 3\n";
            }
      }
      else
       if(n==3&&m==3)
      {
          if(k==2)
          {
              cout<<"YES\n";
              cout<<"1 1 1\n";
              cout<<"1 2 1\n";
              cout<<"1 1 1\n";
          }
          else
            if(k==6)
          {
              cout<<"YES\n";
              cout<<"1 1 2\n";
              cout<<"1 1 3\n";
              cout<<"4 5 6\n";
          }
          else
            if(k==4||k==5||k==7||k==8)
            cout<<"NO\n";
      }
     else
        if(n==3&&m==4)
        {
            if(k==2)
                cout<<"NO\n";
            else
                if(k==3)
            {
                cout<<"YES\n";
                for(int i=1;i<=m;i++)
                    a[1][i]=a[n][i]=1;
                for(int i=1;i<=n;i++)
                    a[i][1]=a[i][m]=1;
                a[2][2]=2;
                a[2][3]=3;
                afisare();
            }
            else
                if(k==4)
                 {
                     cout<<"YES\n";
                   cout<<"1 1 1 2"<<"\n";
                   cout<<"1 1 1 3"<<"\n";
                   cout<<"1 1 1 4"<<"\n";
                 }
              else
                if(k==5)
              {
                  cout<<"YES\n";
                   cout<<"1 1 1 3"<<"\n";
                   cout<<"1 2 1 4"<<"\n";
                   cout<<"1 1 1 5"<<"\n";
              }
              else
                if(k==6)
                {
                    cout<<"YES\n";
                    cout<<"1 1 2 2\n";
                    cout<<"1 1 2 2\n";
                    cout<<"3 4 5 6\n";
                }
                else
                    if(k==9)
                {
                    cout<<"YES\n";
                    cout<<"1 1 2 3\n";
                    cout<<"1 1 4 5\n";
                    cout<<"6 7 8 9\n";
                }
                else
                    if(k==7||k==8||k==10||k==11)
                      cout<<"NO\n";
        }
        else
            if(n==4&&m==3)
        {
            if(k==2)
                cout<<"NO\n";
            else
                if(k==3)
            {
                cout<<"YES\n";
                cout<<"1 1 1\n";
                cout<<"1 2 1\n";
                cout<<"1 3 1\n";
                cout<<"1 1 1\n";
            }
            else
                if(k==4)
            {
                cout<<"YES\n";
                cout<<"1 1 1\n";
                cout<<"1 1 1\n";
                cout<<"1 1 1\n";
                cout<<"2 3 4\n";
            }
            else
                if(k==5)
            {
                cout<<"YES\n";
                cout<<"1 1 1\n";
                cout<<"1 2 1\n";
                cout<<"1 1 1\n";
                cout<<"3 4 5\n";
            }
            else
                if(k==6)
            {
                cout<<"YES\n";
                cout<<"1 1 2\n";
                cout<<"1 1 3\n";
                cout<<"4 4 5\n";
                cout<<"4 4 6\n";
            }
            else
                if(k==7||k==8||k==10||k==11)
                  cout<<"NO\n";
        }
        else
            if(n==m&&n==4)
            {
                if(k==3||k==6||k==11||k==12||k==14||k==15)
                    cout<<"NO\n";
                else
                {
                    if(k==5)
                    {
                        cout<<"YES\n";
                        cout<<"1 1 1 1\n";
                        cout<<"1 2 3 1\n";
                        cout<<"1 4 5 1\n";
                        cout<<"1 1 1 1\n";
                    }
                    else
                        if(k==7)
                        {
                            cout<<"YES\n";
                            cout<<"1 1 2 2\n";
                            cout<<"1 1 2 2\n";
                            cout<<"3 3 4 5\n";
                            cout<<"3 3 6 7\n";
                        }
                        else
                            if(k==8)
                        {
                            cout<<"YES\n";
                            cout<<"1 1 1 2\n";
                            cout<<"1 1 1 3\n";
                            cout<<"1 1 1 4\n";
                            cout<<"5 6 7 8\n";
                        }
                        else
                            if(k==9)
                        {
                            cout<<"YES\n";
                            cout<<"1 1 1 2\n";
                            cout<<"1 3 1 4\n";
                            cout<<"1 1 1 5\n";
                            cout<<"6 7 8 9\n";
                        }
                        else
                            if(k==10)
                        {
                            cout<<"YES\n";
                            cout<<"1 1 2 2\n";
                            cout<<"1 1 2 2\n";
                            cout<<"3 4 5 6\n";
                            cout<<"7 8 9 10\n";
                        }
                        else
                            if(k==13)
                        {
                            cout<<"YES\n";
                            cout<<"1 1 2 3\n";
                            cout<<"1 1 4 5\n";
                            cout<<"6 7 8 9\n";
                            cout<<"10 11 12 13\n";
                        }
                }
            }


         /* if(n<m)
          {
              if(m==k*n)
              {
                  cout<<"YES\n";
                  for(int i=1;i<=n;i++)
                  {
                      for(int j=1;j<=m;j++)
                      {
                          if(j%k!=0)
                          a[i][j]=j/k+1;
                          else
                            a[i][j]=j/k+1;
                      }
                  }
                  for(int i=1;i<=n;i++)
                 {
                     for(int j=1;j<=m;j++)
                        cout<<a[i][j]<<" ";
                     cout<<"\n";
                 }
              }
          }
          else
            if(m<n)
          {
              if(n==k*m)
              {
                  cout<<"YES\n";
                  for(int j=1;j<=m;j++)
                  {
                      for(int i=1;i<=n;i++)
                      {
                          if(i%k!=0)
                          a[i][j]=i/k+1;
                          else
                            a[i][j]=i/k+1;
                      }
                  }
                  for(int i=1;i<=n;i++)
                 {
                     for(int j=1;j<=m;j++)
                        cout<<a[i][j]<<" ";
                     cout<<"\n";
                 }
              }
          }
      }*/
      for(int i=1;i<=n;i++)
         for(int j=1;j<=n;j++)
           a[i][j]=0;

    }
    return 0;
}
