/**
* user:  yankova-448
* fname: Denitsa Marinova
* lname: Yankova
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:46:20.389952
*/
#include<bits/stdc++.h>
using namespace std;

int t, n, m, k;


void read()
{
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        cin>>n>>m>>k;
        if(n%2!=0||m%2!=0) cout<<"NO"<<endl;
        else
        {
            if(n>m) swap(n,m);
            if(n==2)
            {
                if(k==m/2)
                {
                    cout<<"YES"<<endl;
                    for(int l=1;l<=m;l++)
                    {
                        cout<<(l+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int l=1;l<=m;l++)
                    {
                        cout<<(l+1)/2<<" ";
                    }
                    cout<<endl;
                }
                else cout<<"NO"<<endl;
            }
            else if(n==4)
            {
                if(k==m)
                {
                    cout<<"YES"<<endl;
                    for(int l=1;l<=m;l++)
                    {
                        cout<<(l+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int l=1;l<=m;l++)
                    {
                        cout<<(l+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int l=1;l<=m;l++)
                    {
                        cout<<(l+m+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int l=1;l<=m;l++)
                    {
                        cout<<(l+m+1)/2<<" ";
                    }
                    cout<<endl;
                }
                else if(k==m/2)
                {
                    cout<<"YES"<<endl;
                    for(int j=1;j<=m;j++)
                    {
                        cout<<1<<" ";
                    }
                    cout<<endl;
                    cout<<1<<" ";
                    for(int j=3;j<=m;j++)
                    {
                        cout<<(j+1)/2<<" ";
                    }
                    cout<<1<<endl;
                    cout<<1<<" ";
                    for(int j=3;j<=m;j++)
                    {
                        cout<<(j+1)/2<<" ";
                    }
                    cout<<1<<endl;
                    for(int j=1;j<=m;j++)
                    {
                        cout<<1<<" ";
                    }
                    cout<<endl;
                }
                else cout<<"NO"<<endl;
            }
        }
    }
}

int main()
{
	read();
	return 0;
}
