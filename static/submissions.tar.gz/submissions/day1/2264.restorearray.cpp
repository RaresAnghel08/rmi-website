/**
* user:  todorov-9fe
* fname: Andon
* lname: Todorov
* task:  restore
* score: 13.0
* date:  2019-10-10 08:51:39.649105
*/
#include <bits/stdc++.h>
using namespace std;
int n, m, zero [5003], one [5003];
struct str{
	int l, r, k, v;
	bool operator < (str s) const{
		return r < s.r;
	}
};
vector <str> b;
int main (){

	ios::sync_with_stdio (false);
	cin.tie (0);

	cin >> n >> m;
	for (int i = 0; i < m; i ++){
		int l, r, k, v;
		cin >> l >> r >> k >> v;
		b.push_back ({l + 1, r + 1, k, v});
	}
	sort (b.begin (), b.end ());
	int last = 0;
	for (auto i : b){
		for (last; last < i.r; last ++){
			if (one [last] + zero [last] > last){
				cout << "-1\n";
				return 0;
			}
			for (int j = last - 1; j > 0; j --){
				one [j] = max (one [j], one [last] + j - last);
				zero [j] = max (zero [j], zero [last] + j - last);
			}
			one [last + 1] = max (one [last], one [last + 1]);
			zero [last + 1] = max (zero [last + 1], zero [last]);
		}
		if (i.v) one [i.r] = max (one [i.r], one [i.l - 1] + i.r - i.l + 1 - i.k + 1);
		else zero [i.r] = max (zero [i.r], zero [i.l - 1] + i.k);
	}
	if (one [last] + zero [last] > n){
		cout << "-1\n";
		return 0;
	}
	for (int i = n; i > 0; i --){
			for (int j = i - 1; j > 0; j --){
				one [j] = max (one [j], one [i] + j - i);
				zero [j] = max (zero [j], zero [i] + j - i);
			}
	}
	int br1 = 0, br0 = 0;
	for (int i = 1; i <= n; i ++){
		if (br1 < one [i]){
			cout << "1 ";
			br1 ++;
		}
		else{
			cout << "0 ";
			br0 ++;
		}
	}
	cout << '\n';

}
