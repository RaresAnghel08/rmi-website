/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Present
* score: 8.0
* date:  2021-12-16 11:57:21.901389
*/
#include <iostream>
#include <vector>
#include <algorithm>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;

int Gcd(int a, int b) {
    if (!a) return b;
    return Gcd(b % a, a);
}

const int MAX = 100;

int gcd[MAX][MAX];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    for (int i = 1; i < MAX; i++) {
        for (int j = i + 1; j < MAX; j++) {
            gcd[i][j] = Gcd(i, j);
        }
    }
    int t;
    cin >> t;
    while (t--) {
        int k;
        cin >> k;
        int cnt = 0;
        if (!k) {
            cout << 0 << '\n';
            continue;
        }
        for (int i = 1; cnt < k; i++) {
            vi v;
            for (int j = 0; j < 30; j++) {
                if ((i >> j) & 1) {
                    v.push_back(j + 1);
                }
            }
            int n = v.size();
            bool bad = false;
            for (int j = 0; j < n; j++) {
                for (int l = j + 1; l < n; l++) {
                    int x = gcd[v[j]][v[l]];
                    if (!((i >> (x - 1)) & 1)) {
                        bad = true;
                        break;
                    }
                }
                if (bad) break;
            }
            cnt += !bad;
            if (cnt == k) {
                cout << v.size() << ' ';
                for (int x : v) cout << x << ' ';
                cout << '\n';
                break;
            }
        }
    }
}
