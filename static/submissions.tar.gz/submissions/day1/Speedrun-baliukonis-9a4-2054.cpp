/**
* user:  baliukonis-9a4
* fname: Tsimafei
* lname: Baliukonis
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:55:10.862969
*/
#include<bits/stdc++.h>
#include "speedrun.h"

#define ll long long
#define f first
#define s second
#define pb push_back

using namespace std;
/*
void setHintLen (int l ) {};
void setHint (int i , int j , bool b ){};
int getLength (){};
bool getHint (int j ){};
bool goTo (int x ){}; */

vector<ll> v[1007];
vector<ll> obh;
ll pred[1007];
void dfs(ll v1, ll pr) {
 obh.pb(v1);
 pred[v1] = pr;
 for(auto to: v[v1]) {
    if(to == pr) continue;
    dfs(to, v1);
 }
}
void assignHints (int subtask , int n , int a [] , int b []) {

  for(int j = 1; j < n; j++) {
        v[a[j]].pb(b[j]);
        v[b[j]].pb(a[j]);
  }
  setHintLen(30);
  dfs(1, 1);
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= 10; j++) {
     setHint(j, i, ((pred[i] >> j) & 1));
    }
  }
  for(int i = 1; i < n; i++) {
    for(int j = 0; j < 10; j++) {
     setHint(j + 10, obh[i - 1], ((pred[obh[i]] >> j) & 1));
    }
    for(int j = 0; j < 10; j++) {
     setHint(j + 20, obh[i - 1], ((obh[i] >> j) & 1));
    }
  }
  return;
};


void speedrun (int subtask , int N , int start ) {
int now = start;
while(now != 1) {
    ll x = 0;
    for(ll e = 0; e < 10; e++) {
       x += getHint(e) << e;
    }
    goTo(now);
    now = x;
}

for(int j = 1; j < N; j++) {
    ll sl = 0, x2 = 0;
    for(ll e = 0; e < 10; e++) {
       sl += getHint(e + 10) << e;
       x2 += getHint(e + 20) << e;
    }
    while(sl != now) {
     ll x = 0;
     for(ll e = 0; e < 10; e++) {
       x += getHint(e) << e;
     }
     goTo(now);
     now = x;
    }
    goTo(x2);
}
return;
}
/*

int32_t main() {
cin.tie(0);
cout.tie(0);
ios_base::sync_with_stdio(0);
#ifdef LOCAL
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif // LOCAL


ll t;
cin >> t;
while(t--) {
    ll k;
    cin>> k;

}
}*/
