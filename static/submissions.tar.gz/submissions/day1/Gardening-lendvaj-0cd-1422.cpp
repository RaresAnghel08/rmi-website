/**
* user:  lendvaj-0cd
* fname: Dorijan
* lname: Lendvaj
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:53:56.851213
*/
#include <bits/stdc++.h>
#define x first
#define y second
#define pii pair<int,int>
using namespace std;
using ll=long long;
#define pll pair<ll,ll>
#define vi vector<int>
#define vl vector<ll>
#define all(a) begin(a),end(a)
#define pb push_back
#define eb emplace_back

const int N=300010,MOD=1e9+7;
const char en='\n';
const ll LLINF=1ll<<60;

ll t,n,m,k;
vi v[N];

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin>>t;
	while (t--)
	{
		cin>>n>>m>>k;
		if (n%2 || m%2)
		{
			cout<<"NO\n";
			continue;
		}
		int n1=n/2,m1=m/2;
		if (k>n1*m1 || k<min(n1,m1))
		{
			cout<<"NO\n";
			continue;
		}
		cout<<"YES\n";
		for (int i=0;i<n;++i) v[i]=vi(m);
		if (m1<=n1)
		{
			int ex=(k+m1-1)/m1*m1-k;
			for (int i=0;i<(k+m1-1)/m1*m1;++i)
			{
				int va;
				if (i<=ex) va=k;
				else va=i-ex;
				v[(i/m1)*2][(i%m1)*2]=va;
				v[(i/m1)*2][(i%m1)*2+1]=va;
			}
			for (int i=0;i<n;++i) for (int j=0;j<m;++j) if (!v[i][j])
			{
				if (i && v[i-1][j]) v[i][j]=v[i-1][j];
				else assert(0);
			}
		}
		else
		{
			int ex=(k+n1-1)/n1*n1-k;
			for (int i=0;i<(k+n1-1)/n1*n1;++i)
			{
				int va;
				if (i<=ex) va=k;
				else va=i-ex;
				v[(i%n1)*2][(i/n1)*2]=va;
				v[(i%n1)*2+1][(i/n1)*2]=va;
			}
			for (int j=0;j<m;++j) for (int i=0;i<n;++i) if (!v[i][j])
			{
				if (j && v[i][j-1]) v[i][j]=v[i][j-1];
				else assert(0);
			}
		}
		for (int i=0;i<n;++i,cout<<en) for (int j=0;j<m;++j) cout<<v[i][j]<<' ';
	}
}
