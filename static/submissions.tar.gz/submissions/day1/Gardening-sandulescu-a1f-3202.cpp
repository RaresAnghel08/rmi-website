/**
* user:  sandulescu-a1f
* fname: Alexandru Nicolae
* lname: Săndulescu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:44:39.443201
*/
#include <iostream>
#include <unordered_map>

using namespace std;

int T, N, M, K;
unordered_map<int, unordered_map<int, int>> a;

void testcase()
{
    unordered_map<int, bool> appears;
    int c1 = 0;
    cin >> N >> M >> K;
    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= M; j++)
        {
            int my = (i - 1) / 2 * M / 2  + (j - 1) / 2 + 1;
            if(my > K) continue;
            else
            {
                a[i][j] = my;
                if(!appears[my]) c1++, appears[my] = true;
            }
        }

    if(c1 != K)
    {
        cout << "NO\n";
        return;
    }
    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= M; j++)
        {
            int c2 = (a[i][j] == a[i + 1][j]) + (a[i][j] == a[i - 1][j]) + (a[i][j] == a[i][j + 1]) + (a[i][j] == a[i][j - 1]);
            if(c2 != 2)
            {
                cout << "NO\n";
                /*
                cerr << "\n";
                for(int i = 1; i <= N; i++)
                {
                    for(int j = 1; j <= M; j++)
                        cerr << a[i][j] << " ";
                    cerr << "\n";
                }*/
                return;
            }
        }
    }
    cout << "YES\n";
    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= M; j++)
            cout << a[i][j] << " ";
        cout << "\n";
    }
}
int main()
{
    cin >> T;
    while(T--) testcase();
    return 0;
}
