/**
* user:  melnyk-1f2
* fname: Sofiia
* lname: Melnyk
* task:  devil
* score: 0.0
* date:  2019-10-10 09:05:11.920489
*/
#include<bits/stdc++.h>
using namespace std;

#define mp make_pair
#define ff first
#define ss second
#define pb push_back

const int N = 1e6 + 11;

int d[N];

void up()
{
    int k;
    cin>>k;
    for (int i=1; i<=9; i++)
        cin>>d[i];
    int k1=d[1],k2=d[2];
    if (k1==0)
    {
        for (int i=1; i<=k2; i++)
            cout<<2;
        cout<<endl;
        return;
    }
    if (k2==0)
    {
        for (int i=1; i<=k1; i++)
            cout<<1;
        cout<<endl;
        return;
    }
    if (k2<=k-1)
    {
        for (int i=1; i<=k1; i++)
            cout<<1;
        for (int i=1; i<=k2; i++)
            cout<<2;
        cout<<endl;
        return;
    }
    k2-=k-1;
    string ans="";
    string s="2";
    while (s.size()<k&&k1>0)
    {
        if (k1>=k2)
        {
            k1-=k2;
            s+="1";
        } else
        {
            if (k2%2==1)
            {
                ans+=s;
                ans+="1";
                k1--;
            }
            k2/=2;
            s=s+s;
        }
    }
    for (int i=1; i<=k1; i++)
        cout<<1;
    for (int i=1; i<=k2; i++)
        cout<<s;
    cout<<ans;
    for (int i=1; i<=k-1; i++)
        cout<<2;
    cout<<endl;
}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t;
    cin>>t;
    while (t--)
        up();
}
/**
3
2
1 1 2 0 0 0 0 0 0
7
2 4 2 0 0 6 2 2 2
7
3 3 3 0 0 6 2 2 2


**/
