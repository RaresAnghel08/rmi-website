/**
* user:  gasan-03e
* fname: Carol Luca
* lname: Gasan
* task:  lucky
* score: 14.0
* date:  2019-10-10 10:25:53.354563
*/
#include <iostream>
using namespace std;
const long long int mod=1e9+7;
const int lim=1e5+3;
int v[lim];
long long int x[lim];
long long int p[lim];
long long int m(long long int r)
{
    while(r<0)
        r+=mod;
    r%=mod;
    return r;
}
int main()
{
    long long int nr;
    int n,q;
    cin>>n>>q;
    /*for(int i=1;i<=n;++i)
    {
        char ch;
        cin>>ch;
        v[i]=ch-'0';
    }*/
    cin>>nr;
    x[1]=0;
    x[2]=1;
    p[1]=10;
    for(int i=3;i<=n;i++)
    {
        x[i]=(((x[i-1]*10)%mod+(p[i-2]-x[i-2]+mod)%mod)%mod)%mod;
        p[i-1]=(p[i-2]*10)%mod;
    }
    p[n]=p[n-1]*10;
    long long int cnt=0;
    for( long long int i=p[n-1];i<=nr;++i)
    {
         long long int c=i;
        long long int last=0;
        bool ok=0;
        while(c>0 and ok==0)
        {
            if(last==3 and c%10==1)
                ok=1;
            last=c%10;
            c/=10;
        }
        if(ok==1)
            cnt++;
    }
    cout<<nr-cnt-x[n-1]+1;

    /*for(int w=1;w<=q;++w)
    {
        int t;
        cin>>t;
        if(t==2)
        {
            int pos,val;
            cin>>pos>>val;
            v[pos]=val;
        }
        else if(t==1)
        {
            int l,r;
            cin>>l>>r;
            for(int i=l;i<=r;++i)
            if(v[i]!=0)
            {

            }
        }
    }*/
    return 0;
}
