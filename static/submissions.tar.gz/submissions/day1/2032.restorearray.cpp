/**
* user:  craciun-5f9
* fname: Mihai
* lname: Crăciun
* task:  restore
* score: 0.0
* date:  2019-10-10 08:22:02.722471
*/
#include <bits/stdc++.h>

using namespace std;

struct cer  {
    int l, r, k, val;
};

cer v[205];
int n, m;

vector <int> sol, ans;
bool ok = 0;
int s0[20], s1[20];

inline bool ver()  {
    for(int i = 1;i <= m;i++)  {
        int nr0, nr1;
        int l, r, k, val;
        l = v[i].l, r = v[i].r, k = v[i].k, val = v[i].val;
        nr0 = s0[r] - s0[l - 1];
        nr1 = s1[r] - s1[l - 1];
        if(val == 0)  {
            if(nr0 < k)  {
                return 0;
            }
        }
        else  {
            if(nr0 >= k)
                return 0;
        }
    }
    return 1;
}

void bkt()  {
    if(sol.size() == n)  {
        for(int i = 1;i <= n;i++)  {
            s0[i] = s0[i - 1];
            s1[i] = s1[i - 1];
            if(sol[i - 1] == 0)
                s0[i]++;
            else
                s1[i]++;
        }
        if(ver())
            ans = sol, ok = 1;
        return;
    }
    if(ok == 1)
        return;
    sol.push_back(0);
    bkt();
    sol.pop_back();
    sol.push_back(1);
    bkt();
    sol.pop_back();
}

int main()  {
    cin >> n >> m;
    for(int i = 1;i <= m;i++)  {
        cin >> v[i].l >> v[i].r >> v[i].k >> v[i].val;
        v[i].l++, v[i].r++;
    }
    bkt();
    for(auto x : ans)
        cout << x << " ";
    return 0;
}
