/**
* user:  frolov-001
* fname: Konstantin
* lname: Frolov
* task:  devil
* score: 14.0
* date:  2019-10-10 10:33:53.451572
*/
#include <bits/stdc++.h>
#define FOR(i, n) for (int i = 0; i < n; ++i)
#define debug(x) std::cout << #x << ": " << x << '\n';
#define pb push_back
typedef long long ll;
const int N = 1e5;
struct seg_tree
{
	int tree[4 * N], push[4 * N];
	seg_tree() {
		memset(tree, 0, sizeof(tree));
	}
	void doPush(int v, int tl, int tr) {
		tree[v] += push[v] * (tr - tl + 1);
		if (2 * v < 4 * N) {
			push[2 * v] += push[v];
			push[2 * v + 1] += push[v];
		}
		push[v] = 0;
	}
	void upd(int v, int tl, int tr, int i, int x) {
		if (tl == tr) {
			tree[v] = x;
			return;
		}
		int tm = (tl + tr) / 2;
		if (tm >= i) {
			upd(v * 2, tl, tm, i, x);
		}
		else {
			upd(v * 2 + 1, tm + 1, tr, i, x);
		}
		tree[v] = tree[v * 2] + tree[v * 2 + 1];
	}
	int get(int v, int tl, int tr, int l, int r) {
		if (l > r) return 0;
		if (tl == l && tr == r) {
			return tree[v];
		}
		int tm = (tl + tr) / 2;
		return get(v * 2, tl, tm, l, std::min(r, tm)) + get(v * 2 + 1, tm + 1, tr, std::max(tm + 1, l), r);
	}
};

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(0); std::cout.tie(0);
	int t;
	std::cin >> t;
	// debug(t)
	while (t--) {
		int k;
		std::cin >> k;
		// debug(k)
		std::vector<int> num(9);
		int s = 0;
		FOR(i, 9) {
			std::cin >> num[i];
			s += num[i];
		}
		std::deque<int> answer;
		for (int i = 0; i < s; ++i) {
			int s = 0;
			for (int j = 8; j >= 0; --j) {
				while (num[j] && s < k - 1) {
					answer.pb(j + 1);
					--num[j];
					++s;
				}
			}
			s = 0;
			for (int j = 0; j < 9; ++j) {
				while (num[j] && s < k - 1) {
					answer.pb(j + 1);
					--num[j];
					++s;
				}
			}
		}
		std::reverse(answer.begin(), answer.end());
		for (auto e : answer) {
			std::cout << e;
		}
		std::cout << '\n';
	}
}