/**
* user:  fares-9ed
* fname: Yusuf
* lname: Fares
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:48:30.013316
*/
#include <bits/stdc++.h>
#define int long long

using namespace std;

static inline int myabs(int val) {
  return val < 0 ? -val : val;
}

static inline int minim(int a, int b) {
  return a < b ? a : b;
}

static inline int maxim(int a, int b) {
  return a > b ? a : b;
}

int get_flower(int i, int j, int x, int n, int m) {
  int gradmin, lins, cols, linf, colf;

  lins = cols = x + 1;
  linf = n - x; colf = m - x;
  gradmin = minim(i, j);
  gradmin = minim(gradmin, n - i + 1);
  gradmin = minim(gradmin, m - j + 1);

  if (gradmin <= x)
    return gradmin;
  else
    return x + 1 + ((i - lins) / 2) * ((colf - cols + 1) / 2) + (j - cols) / 2;
}

signed main() {
  int n, m, q, x, i, j, k, kn, km, t, p, absp, d, solx, lins, cols, linf, colf, crtform, xmax, gradmin, val, cnt, ok;
  cin >> q;

  while (q--) {
    cin >> n >> m >> k;
    kn = n / 2;
    km = m / 2;

    solx = -1;
    if (kn != km)
      xmax = minim(kn, km) - 1;
    else
      xmax = kn;
    p = (k - (kn * km));
    absp = myabs(p);
    t = 1 - (kn + km);
    for (d = 1; d * d <= absp; d++) {
      if (d * (d + t) == p && d <= xmax) {
        solx = d;
        break;
      }
      else if ((absp / d) * (absp / d + t) == p && (absp / d) <= xmax) {
        solx = absp / d;
        break;
      }
    }

    if (p == 0)
      solx = 0;

    if (solx == -1)
      cout << "NO\n";
    else {

      x = solx;
      ok = 1;
      for (i = 1; i <= n; i++) {
        for (j = 1; j <= m; j++) {
          cnt = 0;
          val = get_flower(i, j, x, n, m);
          if (get_flower(i, j + 1, x, n, m) == val)
            cnt++;
          if (get_flower(i + 1, j, x, n, m) == val)
            cnt++;
          if (get_flower(i, j - 1, x, n, m) == val)
            cnt++;
          if (get_flower(i - 1, j, x, n, m) == val)
            cnt++;
          if (cnt != 2)
            ok = 0;
        }
      }

      if (ok == 0)
        cout << "NO\n";
      else {
        cout << "YES\n";
        for (i = 1; i <= n; i++) {
          for (j = 1; j <= m; j++) {
            cout << get_flower(i, j, x, n, m) << " ";
          }
          cout << "\n";
        }
      }
    }
  }
  return 0;
}
