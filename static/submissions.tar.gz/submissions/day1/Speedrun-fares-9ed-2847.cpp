/**
* user:  fares-9ed
* fname: Yusuf
* lname: Fares
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 10:11:45.425787
*/
#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

int f[1003];

void assignHints(int subtask , int n , int A[] , int B[]) {
  int i, j, val;

  if (subtask == 1) {
    setHintLen(n);
    for (i = 1; i < n; i++) {
      setHint(A[i], B[i], 1);
      setHint(B[i], A[i], 1);
    }
  }
  else if (subtask == 2) {
    setHintLen(10);

    for (i = 1; i <= n; i++)
      f[i] = 0;

    for (i = 1; i < n; i++) {
      f[A[i]]++, f[B[i]]++;
      if (f[A[i]] == n - 1)
        val = A[i];
      else if (f[B[i]] == n - 1)
        val = B[i];
    }

    string s;
    for (i = 0; i < 10; i++) {
      if (val & (1 << i))
        s += '1';
    }

    for (i = 1; i <= n; i++) {
      for (j = 0; j < s.size(); j++)
        setHint(i, j + 1, s[i] - '0');
    }
  }
}

int distnode;

void dfs(int node, int n) {
  int i;
  if (f[node] == 0)
    distnode++, f[node] = 1;

  if (distnode == n)
    return;

  for (i = 1; i <= n; i++) {
    if (i != node && f[i] == 0 && getHint(i) == true) {
      goTo(i);
      dfs(i, n);
      goTo(node);
    }
  }
}

void speedrun ( int subtask , int n , int start ) {
  int i, node;
  if (subtask == 1) {
    for (i = 1; i <= n; i++)
      f[i] = 0;
    distnode = 0;
    dfs(start, n);
  }
  else {
    node = 0;
    for (i = 0; i < 10; i++) {
      if (getHint(i))
        node += (1 << i);
    }

    if (start != node)
      goTo(node);
    for (i = 1; i <= n; i++) {
      if (i != start && i != node) {
        goTo(i);
        goTo(node);
      }
    }
  }
}
