/**
* user:  mihov-0af
* fname: Petar Velislavov
* lname: Mihov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:45:27.208369
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long t;
    cin>>t;
    for (int q12=0;q12<t;q12++)
    {
        long long n,m,k;
        cin>>n>>m>>k;
        if (n>6) break;
        if (n%2!=0 || m%2!=0) {cout<<"NO\n";continue;}
        if (n==4 && m==2)
        {
            if (k!=2) cout<<"NO\n";
            else
            {
                cout<<"YES\n1 1 \n1 1 \n2 2 \n2 2 \n";
            }
            continue;
        }
        if (n==2)
        {
            if (k!=(m/2)) cout<<"NO\n";
            else
            {
                cout<<"YES\n";
                for (int q=1;q<=k;q++) cout<<q<<" "<<q<<" ";
                cout<<"\n";
                for (int q=1;q<=k;q++) cout<<q<<" "<<q<<" ";
                cout<<"\n";
            }
            continue;
        }
        if (n==4)
        {
            if (k==(m/2)) // 1 1 1 1 ; 1 2 2 1; 1 2 2 1; 1 1 1 1
            {
                cout<<"YES\n";
                for (int q=0;q<m;q++) cout<<"1 ";
                cout<<"\n1 ";
                for (int q=2;q<=k;q++) cout<<q<<" "<<q<<" ";
                cout<<"1\n1 ";
                for (int q=2;q<=k;q++) cout<<q<<" "<<q<<" ";
                cout<<"1\n";
                for (int q=0;q<m;q++) cout<<"1 ";
                cout<<"\n";
            }
            else
            {
                if (k==m)
                {
                    cout<<"YES\n";
                    for (int q=1;q<=k/2;q++) cout<<q<<" "<<q<<" ";
                    cout<<"\n";
                    for (int q=1;q<=k/2;q++) cout<<q<<" "<<q<<" ";
                    cout<<"\n";
                    for (int q=k/2+1;q<=k;q++) cout<<q<<" "<<q<<" ";
                    cout<<"\n";
                    for (int q=k/2+1;q<=k;q++) cout<<q<<" "<<q<<" ";
                    cout<<"\n";
                }
                else
                {
                    cout<<"NO\n";
                }
            }
            continue;
        }
    }
}
