/**
* user:  ergeshov-18a
* fname: Mukhammed
* lname: Ergeshov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:57:36.718501
*/
#include <iostream>
using namespace std;
int main(){
    int tests_number;
    scanf("%d", &tests_number);
    int rows, columns, types;
    while (tests_number){
        scanf("%d%d%d", &rows, &columns, &types);
        if ((rows / 2) * (columns / 2) >= types){
            printf("YES\n");
            for (int i = 0; i < rows; ++i){
                for (int j = 0; j < columns; ++j){
                    int y = i / 2 + 1, x = j / 2 + 1;
                    if (rows - i == 1){
                        --y;
                    }
                    if (columns - j == 1){
                        --x;
                    }
                    printf("%d ", min(types, (y - 1) * (columns / 2) + x));
                }
                printf("\n");
            }
        }
        else{
            printf("NO\n");
        }
        --tests_number;
    }
}
