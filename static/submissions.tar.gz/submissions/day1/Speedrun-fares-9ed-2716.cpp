/**
* user:  fares-9ed
* fname: Yusuf
* lname: Fares
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:00:00.495937
*/
#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

void assignHints(int subtask , int n , int A[] , int B[]) {
  int i;

  if (subtask == 1) {
    setHintLen(n);
    for (i = 1; i < n; i++) {
      setHint(A[i], B[i], 1);
      setHint(B[i], A[i], 1);
    }
  }
}

bool f[1003], distnode;

void dfs(int node, int n) {
  int i;
  if (f[node] == 0)
    distnode++, f[node] = 1;

  if (distnode == n)
    return;

  for (i = 1; i <= n; i++) {
    if (i != node && getHint(i) == true) {
      goTo(i);
      dfs(i);
      goTo(node);
    }
  }
}

void speedrun ( int subtask , int n , int start ) {
  int i;
  if (subtask == 1) {
    for (i = 1; i <= n; i++)
      f[i] = 0;
    distnode = 0;
    dfs(start, n);
  }
}
