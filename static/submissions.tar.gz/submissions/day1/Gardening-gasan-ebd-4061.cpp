/**
* user:  gasan-ebd
* fname: Luca Carol
* lname: Gasan
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:55:39.674908
*/
#include <bits/stdc++.h>
using namespace std;
int tst,n,m,k;
int v[1005][1005];
int main()
{
    cin>>tst;
    while(tst--)
    {
        cin>>n>>m>>k;
        if(n==2)
        {
            if(m==2)
            {
                if(k==1)
                {
                    cout<<"YES"<<'\n';
                    cout<<"1 1\n";
                    cout<<"1 1\n";
                }
                else cout<<"NO"<<'\n';
            }
            else if(m==4)
            {
                if(k==2)
                {
                    cout<<"YES"<<'\n';
                    cout<<"1 1 2 2\n";
                    cout<<"1 1 2 2\n";
                }
                else cout<<"NO"<<'\n';
            }
            else cout<<"NO"<<'\n';
        }
        else if(n==4)
        {
            if(m==2)
            {
                if(k==2)
                {
                    cout<<"YES"<<'\n';
                    cout<<"1 1\n";
                    cout<<"1 1\n";
                    cout<<"2 2\n";
                    cout<<"2 2\n";
                }
                else cout<<"NO"<<'\n';
            }
            else if(m==4)
            {
                if(k==2)
                {
                    cout<<"YES"<<'\n';
                    cout<<"1 1 1 1\n";
                    cout<<"1 2 2 1\n";
                    cout<<"1 2 2 1\n";
                    cout<<"1 1 1 1\n";
                }
                else if(k==3)
                {
                    cout<<"YES"<<'\n';
                    cout<<"1 1 1 1\n";
                    cout<<"1 2 3 1\n";
                    cout<<"1 2 3 1\n";
                    cout<<"1 1 1 1\n";
                }
                else if(k==4)
                {
                    cout<<"YES"<<'\n';
                    cout<<"1 1 2 2\n";
                    cout<<"1 1 2 2\n"
                    cout<<"3 3 4 4\n"
                    cout<<"3 3 4 4\n";
                }
                else cout<<"NO"<<'\n';
            }
            else cout<<"NO"<<'\n';
        }
        else cout<<"NO"<<'\n';


    }
    return 0;
}
