/**
* user:  polivin-06f
* fname: Nikita
* lname: Polivin
* task:  Speedrun
* score: 40.0
* date:  2021-12-16 08:56:32.228165
*/
#include "speedrun.h"

#include <bits/stdc++.h>

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
    int n = N;
    vector < vector <int> > a(n);
    for(int i = 1; i < n; ++i){
        int x = A[i] - 1;
        int y = B[i] - 1;

        a[x].push_back(y);
        a[y].push_back(x);
    }

    if(subtask == 1){
        setHintLen(n);

        for(int i = 0; i < n; ++i){
            for(auto to : a[i]){
                setHint(i + 1, to + 1, 1);
            }
        }
    }

    if(subtask == 3){
        setHintLen(20);
        for(int i = 0; i < n; ++i){
            int z = 0;
            for(auto to : a[i]){
                bitset<10> x = to + 1;
                for(int j = 0; j < 10; ++j){
                    setHint(i + 1, j + 1 + z * 10, x[j]);
                }
                ++z;
            }
        }
    }
}

vector <int> used;

void dfs1(int v, int p){
    used[v] = 1;

    int n = used.size();
    //cout << v << '\n';
    for(int i = 0; i < n; ++i){
        if(!used[i] && getHint(i + 1)){
            goTo(i + 1);
            dfs1(i, v);
        }
    }

    if(p != -1){
        goTo(p + 1);
    }
}

void dfs2(int v, int p){
    used[v] = 1;

    int n = used.size();
    //cout << v << '\n';
    bitset <10> x, y;
    for(int i = 0; i < 10; ++i){
        x[i] = getHint(i + 1);
        y[i] = getHint(i + 1 + 10);
    }

    int to1 = x.to_ullong();
    int to2 = y.to_ullong();
    to1--; to2--;

    if(to1 != -1 && !used[to1]){
        goTo(to1 + 1);
        dfs2(to1, v);
    }
    if(to2 != -1 && !used[to2]){
        goTo(to2 + 1);
        dfs2(to2, v);
    }

    if(p != -1){
        goTo(p + 1);
    }
}

void speedrun(int subtask, int N, int start) {
    int n = N;
    start--;

    if(subtask == 1){
        used.resize(n);
        dfs1(start, -1);
    }

    if(subtask == 3){
        used.resize(n);
        dfs2(start, -1);
    }
}
