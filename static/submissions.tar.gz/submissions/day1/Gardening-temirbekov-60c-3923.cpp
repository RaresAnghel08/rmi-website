/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:47:50.665204
*/
#include <bits/stdc++.h>

using namespace std;

void solve() {
	int n, m, v;
	cin >> n >> m >> v;
	
	bool isn = false, ism = false;
	
	if(v * 4 > n * m) {
		cout << "NO\n";
		return;
	}
	
	
	int k = v;
	bool f = false;
	vector <vector <int>> a(n, vector <int> (m));
	int fm = m, fn = n;
	if(fm % 2 == 1) fm --;
	if(fn % 2 == 1) fn --;
	if(k * 4 > fm * fn or n == 1 or m == 1 ) {
		cout << "NO\n";
		return;
	} 
	if(n == 2 and m == 2) {
		if(k == 1) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[1][1] = 1;
			f = true;
			a[0][1] = 1;
		}
	}else if(n == 2 and m == 3) {
		if(k == 1) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[1][1] = 1;
			f = true;
			
			a[0][1] = 1;
			a[0][2] = 1;
			a[1][2] = 1;
		}
	}else if(m == 2 and n == 3) {
		if(k == 1) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[1][1] = 1;
			a[0][1] = 1;
			f = true;
			a[2][1] = 1;
			a[2][0] = 1;
		}
	}else if(n == 3 and m == 3){
		if(k == 1) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[2][0] = 1;
			a[0][1] = 1;
			a[1][1] = 1;
			f = true;
			a[2][1] = 1;
			a[0][2] = 1;
			a[1][2] = 1;
			a[2][2] = 1;
		}
	}else if(n == 3 and m == 4) {
		if(k == 1) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[2][0] = 1;
			a[0][1] = 1;
			a[1][1] = 1;
			f = true;
			a[2][1] = 1;
			a[0][2] = 1;
			a[1][2] = 1;
			a[2][2] = 1;
			a[0][3] = 1;
			a[1][3] = 1;
			a[2][3] = 1;
		}else if(k == 2) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[2][0] = 1;
			a[0][1] = 1;
			a[1][1] = 1;
			a[2][1] = 1;
			a[0][2] = 2;
			a[1][2] = 2;
			a[2][2] = 2;
			f = true;
			a[0][3] = 2;
			a[1][3] = 2;
			a[2][3] = 2;
		}
	}else if(m == 3 and n == 4) {
		if(k == 1) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[2][0] = 1;
			a[0][1] = 1;
			a[1][1] = 1;
			a[2][1] = 1;
			a[0][2] = 1;
			f = true;
			a[1][2] = 1;
			a[2][2] = 1;
			a[3][0] = 1;
			a[3][1] = 1;
			a[3][2] = 1;
		}else if(k == 2) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[2][0] = 2;
			a[0][1] = 1;
			a[1][1] = 1;
			a[2][1] = 2;
			a[0][2] = 1;
			a[1][2] = 1;
			a[2][2] = 2;
			f = true;
			a[3][0] = 2;
			a[3][1] = 2;
			a[3][2] = 2;
		}
	}else if(n == 4 and m == 4) {
		if(k == 1) {
			a[0][0] = 1;
			a[0][1] = 1;
			a[0][2] = 1;
			a[0][3] = 1;
			a[1][0] = 1;
			a[1][1] = 1;
			a[1][2] = 1;
			a[1][3] = 1;
			a[2][0] = 1;
			a[2][1] = 1;
			a[2][2] = 1;
			a[2][3] = 1;
			a[3][0] = 1;
			a[3][1] = 1;
			f = true;
			a[3][2] = 1;
			a[3][3] = 1;
		}else if(k == 2) {
			a[0][0] = 1;
			a[0][1] = 1;
			a[0][2] = 1;
			a[0][3] = 1;
			a[1][0] = 1;
			a[1][1] = 2;
			a[1][2] = 2;
			a[1][3] = 1;
			a[2][0] = 1;
			a[2][1] = 2;
			a[2][2] = 2;
			a[2][3] = 1;
			a[3][0] = 1;
			a[3][1] = 1;
			f = true;
			a[3][2] = 1;
			a[3][3] = 1;
		}else if(k == 3) {
			a[0][0] = 1;
			a[0][1] = 1;
			a[0][2] = 2;
			a[0][3] = 2;
			a[1][0] = 1;
			a[1][1] = 1;
			a[1][2] = 2;
			a[1][3] = 2;
			a[2][0] = 1;
			a[2][1] = 1;
			a[2][2] = 3;
			a[2][3] = 3;
			f = true;
			a[3][0] = 1;
			a[3][1] = 1;
			a[3][2] = 3;
			a[3][3] = 3;
		}else if(k == 4) {
			a[0][0] = 1;
			a[0][1] = 1;
			a[0][2] = 2;
			a[0][3] = 2;
			a[1][0] = 1;
			a[1][1] = 1;
			a[1][2] = 2;
			a[1][3] = 2;
			a[2][0] = 3;
			a[2][1] = 3;
			a[2][2] = 4;
			a[2][3] = 4;
			a[3][0] = 3;
			a[3][1] = 3;
			a[3][2] = 4;
			f = true;
			a[3][3] = 4;
		}
	}else if(n == 2 and m == 4) {
		if(k == 1) {
			a[0][0] = 1;
			a[0][1] = 1;
			a[0][2] = 1;
			a[0][3] = 1;
			a[1][0] = 1;
			a[1][1] = 1;
			a[1][2] = 1;
			f = true;
			a[1][3] = 1;
		}else if(k == 2) {
			a[0][0] = 1;
			a[0][1] = 1;
			a[0][2] = 2;
			a[0][3] = 2;
			a[1][0] = 1;
			a[1][1] = 1;
			a[1][2] = 2;	
			a[1][3] = 2;
			f = true;
		}
	}else if(n == 4 and m == 2) {
		if(k == 1) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[2][0] = 1;
			a[3][0] = 1;
			a[0][1] = 1;
			a[1][1] = 1;
			a[2][1] = 1;
			a[3][1] = 1;
			f = true;
		}else if(k == 2) {
			a[0][0] = 1;
			a[1][0] = 1;
			a[2][0] = 2;
			a[3][0] = 2;
			a[0][1] = 1;
			a[1][1] = 1;
			a[2][1] = 2;
			a[3][1] = 2;
			f = true;
		}
	}
	if(!f) {
		cout << "NO\n";
		return;
	}	
	cout << "YES\n";
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < m; j ++) cout << a[i][j] << " ";
		cout << endl;
	}
	
	
	
	/*vector <vector <int> > a(n, vector <int> (m, 0));
	function <void(int, int, int)> fill=[&](int i, int j, int k) {
		a[i][j] = k;
		a[i+1][j] = k;
		a[i+1][j+1] = k;
		a[i][j+1] = k;
	};
	for(int k = 1; k <= v; k ++){
		for(int i = 0; i < n - 1; i +=2) {
			for(int j = 0; j < m - 1; j +=2) {
				if(a[i][j] == 0) { 
					fill(i, j, k);
					goto yes;
				}
			}
		}
		yes:;
	}
	cout << "YES\n";
	int have = -1;
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < m; j ++) {
			if(a[i][j] == 0 and i != 0) a[i][j] = a[i - 1][j];
			else if(a[i][j] == 0) a[i][j] = a[i][j - 1];
			cout << a[i][j] << " ";
		}
		if(ism) {
			cout << a[i][m - 2] << " ";
			have = a[i][m- 2];
		}
		cout << "\n";
	}
	if(isn) {
		for(int i = 0; i < m; i ++){
			cout << a[n-2][i] << " ";
		}
		if(ism) {
			cout << have << " ";
		}
		cout << endl;
	}*/
}

int main(void) {
	int t;
	cin >> t;
	cout << endl;
	while(t --) {
		solve();
	}
	
	return 0;
}