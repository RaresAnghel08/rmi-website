/**
* user:  pavic-e27
* fname: Patrick
* lname: Pavić
* task:  Gardening
* score: 5.0
* date:  2021-12-16 07:56:35.541406
*/
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;

const int N = 2e5 + 500;

vector < int > A[N];

bool ok(int n, int m, int k){
	if((n & 1) || (m & 1)) return false;
	if(k > (n * m) / 4) return false;
	if(k < max(n, m ) / 2) return false;
	return true;
}

int cnt = 1;

bool solve(int n, int m, int k, int sx, int sy){
	if(!ok(n, m, k)) return false;
	if(n <= 0 || m <= 0 || k < 0) return false;
	//printf("n = %d m = %d k = %d sx = %d sy = %d\n", n, m, k, sx, sy);
	if((n == 2 || m == 2) && k == (n * m) / 4){
		for(int i = 0;i < n;i += 2){
			for(int j = 0;j < m;j += 2){
				A[sx + i][sy + j] = cnt; A[sx + i + 1][sy + j] = cnt;
				A[sx + i][sy + j + 1] = cnt; A[sx + i + 1][sy + j + 1] = cnt;
				cnt++;
			}
		}
		return true;
	}
	if(ok(n - 2, m, k - (m / 2)) && solve(n - 2, m, k - (n / 2), sx + 2, sy)){
		for(int j = 0;j < m;j += 2){
			A[sx][sy + j] = cnt; A[sx][sy + j + 1] = cnt;
			A[sx + 1][sy + j] = cnt; A[sx + 1][sy + j + 1] = cnt;
			cnt++;
		}
		return true;
	}
	if(ok(n, m - 2, k - (n / 2)) && solve(n, m - 2, k - (m / 2), sx, sy + 2)){
		for(int j = 0;j < n;j += 2){
			A[sx + j][sy] = cnt; A[sx + j][sy + 1] = cnt;
			A[sx + 1 + j][sy] = cnt; A[sx + 1 + j][sy + 1] = cnt;
			cnt++;
		}
		return true;
	}
	if(ok(n - 2, m - 2, k - 1) && solve(n - 2, m - 2, k - 1, sx + 1, sy + 1)){
		for(int j = 0;j < m;j++){
			A[sx][sy + j] = cnt; A[sx + n - 1][sy + j] = cnt;
		}
		for(int i = 0;i < n;i++){
			A[sx + i][sy] = cnt; A[sx + i][sy + m - 1] = cnt;
		}
		cnt++;
		return true;
	}	
	return false;
}

int main(){
	int T; scanf("%d", &T);
	for(;T--;){
		int n, m; scanf("%d%d", &n, &m);
		for(int i = 0;i < n;i++) A[i].resize(m);
		int k; scanf("%d", &k);
		cnt = 1; bool ans = solve(n, m, k, 0, 0);
		if(!ans){
			printf("NO\n"); 
			continue;
		}
		printf("YES\n");
		for(int i = 0;i < n;i++){
			for(int j = 0;j < m;j++){
				printf("%d ", A[i][j]);
			}
			printf("\n");
		}
	}
	/**
	for(int k = 0;k <= n * m;k++){
		if(ok(n, m, k)){
			cnt = 1;
			bool ans = solve(n, m , k, 0, 0);
			printf("k = %d :  %d\n", k, ans);
			if(ans){
				for(int i = 0;i < n;i++){
					for(int j = 0;j < m;j++)
						printf("%2d ", A[i][j]);
					printf("\n");
				}
			}
		}
	}
	**/
	return 0;
}
