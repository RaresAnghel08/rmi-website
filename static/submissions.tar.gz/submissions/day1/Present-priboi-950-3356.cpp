/**
* user:  priboi-950
* fname: Mihai Luca
* lname: Priboi
* task:  Present
* score: 0.0
* date:  2021-12-16 10:58:22.696322
*/
#include <bits/stdc++.h>

using namespace std;

#define numere 26

int gcd[numere + 1][numere + 1];
int v[1000001];
int v2[numere + 1];

int cmmdc( int a, int b ) {
  int r;
  while( b ) {
    r = a % b;
    a = b;
    b = r;
  }

  return a;
}

bool nr_ok( int k ) {
  int i, j, ind;

  ind = 0;
  for( i = 1; i <= numere; i++ ) {
    if( k & (1 << (i - 1)) )
      v2[ind++] = i;
  }

  for( i = 0; i < ind; i++ ) {
    for( j = i + 1; j < ind; j++ ) {
      if( int(k & (1 << (gcd[v2[i]][v2[j]] - 1))) == 0 ) {
        return false;
      }
    }
  }

  return true;
}

int main() {
  int i, j, k, ind, n, x;

  for( i = 1; i <= numere; i++ )
    for( j = 1; j <= numere; j++ )
      gcd[i][j] = cmmdc(i, j);

  ind = 0;
  for( k = 0; k <= 1 << numere; k++ ) {
    if( nr_ok(k) )
      v[ind++] = k;
  }

  scanf( "%d", &n );
  while( n-- ) {
    scanf( "%d", &k );
    x = v[k];
    i = 0;
    while( x ) {
      if( x & 1 )
        i++;
      x /= 2;
    }
    printf( "%d ", i );
    x = v[k];
    i = 1;
    while( x ) {
      if( x & 1 )
        printf( "%d ", i );
      x /= 2;
      i++;
    }
    printf( "\n" );
  }
  return 0;
}
