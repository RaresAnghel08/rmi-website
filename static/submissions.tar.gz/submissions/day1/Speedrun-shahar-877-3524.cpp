/**
* user:  shahar-877
* fname: Tamir
* lname: Shahar
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:14:43.527372
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
#define pb push_back
#define all(x) x.begin(), x.end()

// static map<int, map<int, bool>> mp;
// static int length = -1;
// static int queries = 0;
// static bool length_set = false;
// static int current_node = 0;
// static set<int> viz;
// static map<int, set<int>> neighbours;

// void setHintLen(int l)
// {
//     if (length_set)
//     {
//         cerr << "Cannot call setHintLen twice" << endl;
//         exit(0);
//     }
//     length = l;
//     length_set = true;
// }

// void setHint(int i, int j, bool b)
// {
//     if (!length_set)
//     {
//         cerr << "Must call setHintLen before setHint" << endl;
//         exit(0);
//     }
//     mp[i][j] = b;
// }

// int getLength() { return length; }

// bool getHint(int j) { return mp[current_node][j]; }

// bool goTo(int x)
// {
//     if (neighbours[current_node].find(x) == end(neighbours[current_node]))
//     {
//         ++queries;
//         return false;
//     }
//     else
//     {
//         viz.insert(current_node = x);
//         return true;
//     }
// }

void build(int src, vvi &ni, int parent, int next)
{
    // erase(all(ni[src]), parent));
    auto it = find(all(ni[src]), parent);
    if (it != ni[src].end())
        ni[src].erase(it);
    for (int i = 0; i < ni[src].size(); i++)
    {
        if (ni[src][i] == parent)
            continue;
        if (i == int(ni[src].size()) - 1)
            build(ni[src][i], ni, src, parent), setHint(ni[src][i], 21, 1);
        else
            build(ni[src][i], ni, src, ni[src][i + 1]);
    }
    int son = parent;
    setHint(src, 21, 1);
    if (ni[src].size() != 0)
        son = ni[src][0], setHint(src, 21, 0);
    for (int i = 0; i < 10; i++)
        setHint(src, i + 1, son & (1 << i));
    for (int i = 0; i < 10; i++)
        setHint(src, 10 + i + 1, next & (1 << i));
}
void assignHints(int subtask, int N, int A[], int B[])
{ /* your solution here */
    setHintLen(21);
    vvi ni(N + 1);
    for (int i = 1; i <= N - 1; i++)
    {
        ni[A[i]].pb(B[i]);
        ni[B[i]].pb(A[i]);
    }
    build(1, ni, 0, 0);
}
void find(int src, int parent, vb &visited)
{
    // cout << src << endl;
    goTo(src);
    int son = 0;
    for (int i = 0; i < 10; i++)
        son += getHint(i + 1) * (1 << i);

    int next = 0;
    for (int i = 0; i < 10; i++)
        next += getHint(10 + i + 1) * (1 << i);
    // cout << src << son << next << parent << endl;
    // if (src == 1 && son == 7)
    //     exit(0);

    // if (src == 3)
    // {
    //     exit(0);
    // }
    if (son != 0 && !visited[son])
        visited[son] = 1, find(son, src, visited);
    if (parent != -1 && next != 0)
    {
        goTo(parent);
        if (getHint(21))
            find(next, -1, visited);
        else
            find(next, parent, visited);
    }
}
void speedrun(int subtask, int N, int start)
{ /* your solution here */
    // assumeing start=1
    // vb visited(N + 1);
    // for (int i = 1; i <= N; i++)
    // {
    //     vb visited(N + 1);
    //     find(i, -1, visited);
    // }
    vb visited(N + 1);
    find(start, -1, visited);
}

// int main()
// {

//     int N;
//     cin >> N;

//     int a[N], b[N];
//     for (int i = 1; i < N; ++i)
//     {
//         cin >> a[i] >> b[i];
//         neighbours[a[i]].insert(b[i]);
//         neighbours[b[i]].insert(a[i]);
//     }

//     assignHints(1, N, a, b);
//     cout << "hints are ready\n";
//     if (!length_set)
//     {
//         cerr << "Must call setHintLen at least once" << endl;
//         exit(0);
//     }

//     cin >> current_node;
//     viz.insert(current_node);

//     speedrun(1, N, current_node);

//     if (viz.size() < N)
//     {
//         cerr << "Haven't seen all nodes" << endl;
//         for (auto a : viz)
//             cout << a << " ";
//         exit(0);
//     }

//     cerr << "OK; " << queries << " incorrect goto's" << endl;
//     return 0;
// }
