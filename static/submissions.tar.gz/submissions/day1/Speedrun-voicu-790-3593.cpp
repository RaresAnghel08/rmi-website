/**
* user:  voicu-790
* fname: Tudor
* lname: Voicu
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:20:58.926086
*/
/**
 * Input format:
 *
 * N -- number of nodes
 * a1 b1 -- edge 1
 * ...
 * a(N-1) b(N-1) -- edge N - 1
 * x -- start node
 **/
/**
#include <iostream>
#include <map>
#include <set>

//#include "speedrun.h"
using namespace std;

void assignHints(int subtask, int N, int A[], int B[]);
void speedrun(int subtask, int N, int start);

void setHintLen(int l);
void setHint(int i, int j, bool b);
int getLength();
bool getHint(int j);
bool goTo(int x);

static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;

void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}

int main() {
    int N;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(3, N, a, b);

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(3, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;
    return 0;
} **/
#include "speedrun.h"
/** 3
8
1 2
2 3
3 4
3 5
1 8
6 8
7 8
1
**/
void assignHints ( int subtask, int N, int A[], int B[] ) {

    if ( subtask == 1 ) {
        setHintLen ( N );
        for ( int i = 1; i <= N - 1; i++ ) {
            setHint ( A[i], B[i], 1 );
            setHint ( B[i], A[i], 1 );
        }
    } else if ( subtask == 2 ) {
        int a[2][N + 1];
        for ( int i = 1; i <= N; i++ )
            a[0][i] = a[1][i] = 0;
        for ( int i = 1; i <= N - 1; i++ ) {
            if ( a[0][A[i]] == 0 )
                a[0][A[i]] = B[i];
            else
                a[1][A[i]] = B[i];
            if ( a[0][B[i]] == 0 )
                a[0][B[i]] = A[i];
            else
                a[1][B[i]] = A[i];
        }
        setHintLen ( 11 );
        for ( int i = 1; i <= N; i++ ) {
            if ( a[1][i] != 0 )
                setHint ( i, 11, 1 );
            for ( int j = 0; j < 10; j++ )
                setHint ( i, j + 1, ( a[0][j] & ( 1 << j ) ) > 0 );
        }
    } else if ( subtask == 3 ) {
        setHintLen ( 20 );
        // primii 10 biti = primul vecin
        // ultimii 10 biti = al doilea vecin
        int a[2][N + 1];
        for ( int i = 1; i <= N; i++ )
            a[0][i] = a[1][i] = 0;
        for ( int i = 1; i <= N - 1; i++ ) {
            if ( a[0][A[i]] == 0 )
                a[0][A[i]] = B[i];
            else
                a[1][A[i]] = B[i];
            if ( a[0][B[i]] == 0 )
                a[0][B[i]] = A[i];
            else
                a[1][B[i]] = A[i];
        }
        for ( int i = 1; i <= N; i++ ) {
            for ( int j = 0; j < 10; j++ ) {
                setHint ( i, j + 1, ( ( a[0][i] & ( 1 << j ) ) > 0 ) );
                setHint ( i, j + 11, ( ( a[1][i] & ( 1 << j ) ) > 0 ) );
            }
        }

    }


}





int compute ( int add ) {
    int s = 0;
    for ( int i = 0; i < 10; i++ )
        s += ( 1 << i ) * getHint ( i + add + 1 );
    return s;
}

void dfs1 ( int n, int start, int parent );
void dfs3 (        int start, int parent );
int last;
int vis[1001];
void speedrun ( int subtask, int N, int start ) { /* your solution here */
    int l = getLength ();
    if ( subtask == 1 ) {
        for ( int i = 1; i <= N; i++ )
            vis[i] = 0;
        dfs1 ( N, start, 0 );
    } else if ( subtask == 2 ) {
        goTo ( start = compute ( 0 ) );
        for ( int i = 1; i <= N; i++ )
            if ( i != start ) {
                goTo ( i );
                goTo ( start );
            }
    } else if ( subtask == 3 ) {
        for ( int i = 1; i <= N; i++ )
            vis[i] = 0;
        dfs3 ( start, 0 );
    } else {
    }
}

void dfs1 ( int n, int start, int parent ) {
    vis[start] = 1;
    for ( int i = 1; i <= n; i++ )
        if ( vis[i] == 0 && getHint ( i ) ) {
            goTo ( i );
            dfs1 ( n, i, start );
        }
    if ( parent != 0 )
        goTo ( parent );
}
void dfs3 ( int start, int parent ) {
    vis[start] = 1;
    int vec1 = compute ( 0 );
    int vec2 = compute ( 10 );
    if ( vec1 != 0 && vis[vec1] == 0 ) {
        goTo ( vec1 );
        cout << vec1 << ' ';
        dfs3 ( vec1, start );
    }
    if ( vec2 != 0 && vis[vec2] == 0 ) {
        goTo ( vec2 );
        cout << vec2 << ' ';
        dfs3 ( vec2, start );
    }
    if ( parent != 0 )
        goTo ( parent );
}








