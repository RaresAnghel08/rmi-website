/**
* user:  ismailov-374
* fname: Ferit
* lname: Ismailov
* task:  restore
* score: 0.0
* date:  2019-10-10 08:43:40.482843
*/
#include<bits/stdc++.h>
#define endl "\n"
using namespace std;
const int MAXN=10001;
int n,m,arr[MAXN];
struct query
{
    int l,r,k,val;
} q[MAXN];
void print()
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
}
bool check()
{
    int i,j;
    for(i=0;i<m;i++)
    {
        int br=0;
        for(j=q[i].l;j<=q[i].r;++j)
        {
            br+=(arr[j]==0);
        }
        if(q[i].val==0)
        {
            if(br<q[i].k-1)return false;
        }
        if(q[i].val==1)
        {
            if(br>q[i].k-1)return false;
        }
    }
    return true;
}
bool l;
void solve1(int pos)
{
    if(l==true)return;
    if(pos>n)
    {
        if(check())
        {
            print();
            l=true;
        }
        return;
    }
    arr[pos]=0;
    solve1(pos+1);
    arr[pos]=1;
    solve1(pos+1);
}
int main()
{
   // freopen("in.txt","r",stdin);
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>m;
    //cout << n << m << endl;
    //memset(arr,-1,sizeof(arr));
    int i,j;
    for(int i=0; i<m; i++)
    {
        cin>>q[i].l>>q[i].r>>q[i].k>>q[i].val;
        /*if(q[i].val==1)
        {
            for(j=q[i].l; j<=q[i].r; j++)
            {
                arr[j]=1;
            }
        }
        else
        {
            int l=false;
            for(j=q[i].l; j<=q[i].r; ++j)
            {
                if(arr[j]==-1)
                {
                    l=true;
                }
            }
            if(!l)
            {
                cout<<-1<<"\n";
                return 0;
            }
        }*/
    }
    solve1(0);
    return 0;
    for(i=0; i<n; i++)
    {
        if(arr[i]==-1)arr[i]++;
        cout<<arr[i]<<" ";
    }
    cout<<"\n";
    return 0;
}
