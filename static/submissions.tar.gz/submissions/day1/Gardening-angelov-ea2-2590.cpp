/**
* user:  angelov-ea2
* fname: Dobromir Dobromirov
* lname: Angelov
* task:  Gardening
* score: 11.0
* date:  2021-12-16 09:45:53.738110
*/
#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
int n,m,k;
vector<vector<int> >ans;
void print_2x2_all(int r,int c)
{
    int num;
    for(int i=0;i<r;i+=2)
    {
        for(int h=0;h<2;h++)
        {
            num=(i/2)*(c/2)+1;
            cout<<num<<" "<<num;
            num++;
            for(int j=2;j<c;j+=2)
            {
                cout<<" "<<num<<" "<<num;
                num++;
            }
            cout<<endl;
        }
    }
}
void fill_2lines(int n,int m,int tmp,int x,int y,int curr0)
{
    int curr;
    if(n==2)
    {
        for(int i=x;i<x+2;i++)
        {
            curr=curr0;
            for(int j=y;j<y+m;j+=2){ans[i][j]=ans[i][j+1]=curr;curr++;}
        }
    }
    if(m==2)
    {
        for(int j=y;j<y+2;j++)
        {
            curr=curr0;
            for(int i=x;i<x+n;i+=2){ans[i][j]=ans[i+1][j]=curr;curr++;}
        }
    }
}
void fill_nm(int n,int m,int x,int y,int curr)
{
    for(int i=x;i<x+n;i+=2)
    {
        for(int j=y;j<y+m;j+=2)
        {
            ans[i][j]=ans[i][j+1]=ans[i+1][j]=ans[i+1][j+1]=curr;
            curr++;
        }
    }
}
void print_ans()
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cout<<ans[i][j]<<" ";
        }
        cout<<endl;
    }
}
void solve(int n,int m,int tmp,int x,int y,int curr)
{
    //cout<<": "<<n<<" "<<m<<" "<<tmp<<" "<<x<<" "<<y<<" "<<curr<<endl;
    int rem=n*m-4*tmp;
    if(rem==0)
    {
        fill_nm(n,m,x,y,curr);
        cout<<"YES"<<endl;
        print_ans();
        return;
    }
    if(n==2||m==2)
    {
        if(rem!=0)
        {
            cout<<"NO"<<endl;
            return;
        }
        else
        {
            fill_2lines(n,m,tmp,x,y,curr);
            curr=k+1;
        }
    }
    if(n==4&&m==4)
    {
        if(tmp==2)
        {
            ans[x][y]=ans[x][y+1]=ans[x][y+2]=ans[x][y+3]=curr;
            ans[x+1][y]=ans[x+1][y+3]=curr;
            ans[x+2][y]=ans[x+2][y+3]=curr;
            ans[x+3][y]=ans[x+3][y+1]=ans[x+3][y+2]=ans[x+3][y+3]=curr;
            curr++;
            ans[x+1][y+1]=ans[x+1][y+2]=curr;
            ans[x+2][y+1]=ans[x+2][y+2]=curr;
            curr++;
        }
        else if(tmp==4)
        {
            ans[x][y]=ans[x][y+1]=ans[x+1][y]=ans[x+1][y+1]=curr; curr++;
            ans[x][y+2]=ans[x][y+3]=ans[x+1][y+2]=ans[x+1][y+3]=curr; curr++;
            ans[x+2][y]=ans[x+2][y+1]=ans[x+3][y]=ans[x+3][y+1]=curr; curr++;
            ans[x+2][y+2]=ans[x+2][y+3]=ans[x+3][y+2]=ans[x+3][y+3]=curr; curr++;
        }
        else
        {
            cout<<"NO"<<endl;
            return;
        }
    }
    if(curr==k+1)
    {
        cout<<"YES"<<endl;
        print_ans();
        return;
    }
    if(rem>=2*(n-2)+2*(m-2))
    {
        if(rem-(2*(n-2)+2*(m-2))!=4)
        {
            for(int i=0;i<m;i++)ans[x][y+i]=ans[x+n-1][y+i]=curr;
            for(int i=1;i<=n-2;i++)ans[x+i][y]=ans[x+i][y+m-1]=curr;
            solve(n-2,m-2,tmp-1,x+1,y+1,curr+1);
        }
        else
        {
            if(n>4)
            {
                fill_2lines(2,m,tmp,x,y,curr);
                x+=2;
                n-=2;
                curr=curr+m/2;
                tmp=tmp-m/2;
                for(int i=0;i<m;i++)ans[x][y+i]=ans[x+n-1][y+i]=curr;
                for(int i=1;i<=n-2;i++)ans[x+i][y]=ans[x+i][y+m-1]=curr;
                solve(n-2,m-2,tmp-1,x+1,y+1,curr+1);
            }
            else if(m>4)
            {
                fill_2lines(n,2,tmp,x,y,curr);
                y+=2;
                m-=2;
                curr=curr+n/2;
                tmp=tmp-n/2;
                for(int i=0;i<m;i++)ans[x][y+i]=ans[x+n-1][y+i]=curr;
                for(int i=1;i<=n-2;i++)ans[x+i][y]=ans[x+i][y+m-1]=curr;
                solve(n-2,m-2,tmp-1,x+1,y+1,curr+1);
            }
        }
    }
    else
    {
        int a=4,b=4;
        rem-=8;
        if(rem>0)
        {
            if(n-a>=rem/2){a+=rem/2;rem=0;}
            else
            {
                rem=rem-(n-a)*2;
                a=n;
                if(m-b>=rem/2){b+=rem/2;rem=0;}
            }//cout<<rem<<endl;
        }
        for(int i=0;i<b;i++)ans[x][y+i]=ans[x+a-1][y+i]=curr;
        for(int i=1;i<=a-2;i++)ans[x+i][y]=ans[x+i][y+b-1]=curr;
        curr++;
        fill_nm(a-2,b-2,x+1,y+1,curr);
        curr+=(a-2)*(b-2)/4;
        fill_nm(n,m-b,x,y+b,curr);
        curr+=n*(m-b)/4;
        fill_nm(n-a,b,x+a,y,curr);
        cout<<"YES"<<endl;
        print_ans();
        return;
    }
}
int main()
{
ios::sync_with_stdio(0);
cin.tie(0);
cout.tie(0);
int t;
cin>>t;
while(t--)
{
    cin>>n>>m>>k;
    if((n%2==1||m%2==1) || (n*m<4*k) || (n*m==4*k+4))
    {
        cout<<"NO"<<endl;
        continue;
    }
    if(n*m==4*k)
    {
        cout<<"YES"<<endl;
        print_2x2_all(n,m);
        continue;
    }
    if(n==2||m==2)
    {
        cout<<"NO"<<endl;
        continue;
    }
    ans.resize(n);
    for(int i=0;i<n;i++)ans[i].resize(m);
    solve(n,m,k,0,0,1);
}
return 0;
}
