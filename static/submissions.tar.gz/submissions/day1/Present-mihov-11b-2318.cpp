/**
* user:  mihov-11b
* fname: Rumen
* lname: Mihov
* task:  Present
* score: 29.0
* date:  2021-12-16 09:21:25.419194
*/
# include <bits/stdc++.h>
using namespace std;
const int maxn = 2e6;
const int K = 20;
int dp[maxn], from[maxn];
int sz;
vector <int> a;
int vis[maxn],ids = 1;
int mask[maxn];
int G[30][30];
void solve(int v, int k)
{
    if(k==-1)return ;
     a.push_back(__gcd(v,dp[k]));
     solve(v,from[k]);
}
bool checked(int v, int k)
{
    solve(v,k);
   sort(a.begin(),a.end());
   int idx = a.size()-1;
//cout<<v<<" "<<k<<" && "<<endl;
  // for(int i = 0;i<a.size();i++ )cout<<a[i]<<" ";
  // cout<<endl;
   int pos = k;
   while(pos!=-1)
   {
       while(idx>=0&&a[idx]==dp[pos])idx--;
       if(idx>=0&&a[idx]>dp[pos])return false;
       pos = from[pos];
   }

   return idx<0;

}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;

    dp[0] = 1;
    from[0] = -1;
    mask[0] = 2;
    int i;
    sz = 0;
    int j;
    for(i = 1;i<=29;i++)
        for(j=1;j<=29;j++)
        G[i][j]=__gcd(i,j);
    for(i = 2;sz<=1000000;i++)
    {
        sz++;
        dp[sz] = i;
        from[sz] = -1;
        mask[sz] = (1<<i);
        ids++;
    //  cout<<sz<<" :: "<<dp[sz]<<" "<<from[sz]<<endl;
        int l = sz;
        for(j = 0;j<l;j++)
        {
     //a.clear();
          //  if(checked(i,j))
          if(from[j]!=-1&&vis[from[j]]!=ids)continue;
          int k = G[dp[j]][i];
            if(mask[j]&(1<<k))
            {



                sz++;
                dp[sz] = i;
                from[sz] = j;
                vis[j] = ids;
                mask[sz] = (mask[j]|(1<<i));
           // cout<<sz<<" :: "<<dp[sz]<<" "<<from[sz]<<endl;
            }
        }
    }
    //cout<<sz<<" "<<dp[sz]<<endl;
    int q;
        cin>>N;
    for(i=  1;i<=N;i++)
    {
         a.clear();
         cin>>q;
         if(q==0)
         {
             cout<<0<<endl;continue;
         }
         q--;
         while(q!=-1)
         {
             a.push_back(dp[q]);
             q = from[q];
         }
         cout<<a.size()<<" ";
            for(int j = a.size()-1;j>=0;j--)cout<<a[j]<<" ";
            cout<<endl;
    }

    return 0;
}
