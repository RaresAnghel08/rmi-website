/**
* user:  pakkanen-669
* fname: Mariia
* lname: Pakkanen
* task:  Gardening
* score: 11.0
* date:  2021-12-16 09:17:43.348864
*/
#include <bits/stdc++.h>
using namespace std;

bool solve(int n, int m, int k)
{
    if(n % 2 != 0 || m % 2!= 0)
        return false;
    if(n == 4&& m == 2 && k == 1)
        return false;
    if(n == 2){
        if(4*k != n * m)
            return false;
        cout << "YES\n";
        for(int i = 0; i < m; i += 2)
            cout << i/2+1 << ' ' << i/2+1 << ' ';
        cout << '\n';
        for(int i = 0; i < m; i += 2)
            cout << i/2+1 << ' ' << i/2+1 << ' ';
        cout << '\n';
        return true;
    }
    int ans[4][m];
    for(int i = 0; i < m; ++i){
        ans[0][i] = 1;
        ans[3][i] = 1;
    }
    for(int i = 0; i < 4; ++i){
        ans[i][0] = 1;
        ans[i][m-1] = 1;
    }
    int col = 1;
    for(int i = 2; i < m-1; i += 2){
        ans[1][i-1] = i/2+1;
        ans[1][i] = i/2+1;
        ans[2][i] = i/2+1;
        ans[2][i-1] = i/2+1;
        col = i/2 + 1;
    }
    int gr = 0;
    if(k >= m/2){
        while(col < k){
            if(gr >= m-1)
                return false;
            col++;
            ans[1][gr] = col;
            ans[0][gr] = col;
            ans[0][gr+1] = col;
            ans[1][gr+1] = col;
            ans[3][gr] = ans[2][gr+1];
            ans[3][gr+1] = ans[2][gr+1];
            ans[2][gr] = ans[2][gr+1];

            gr += 2;
            if(gr == m-2 && col == k)
                return false;
            if(gr < m) {
                ans[1][gr] = 1;
                ans[2][gr] = 1;
            }

        }
        if(col != k)
            return false;
        cout << "YES\n";
        for(int i = 0; i < 4; ++i){
            for(int j = 0; j < m; ++j)
                cout << ans[i][j] << ' ';
            cout << '\n';
        }
        return true;
    }
    else
        return false;
    /*else{
        while(col > k){
            if(gr > m - 7)
                return false;
            col++;
            ans[1][gr+1] = col;
            ans[2][gr+1] = col;
            ans[1][gr+2] = col;
            ans[2][gr+2] = col;
            col++;
            ans[0][gr] = col;
            ans[0][gr+1] = col;
            ans[0][gr+2] = col;
            ans[0][gr+3] = col;
            ans[1][gr+3] = col;
            ans[2][gr+3] = col;
            ans[3][gr+3] = col;
            ans[3][gr+2] = col;
            ans[3][gr+1] = col;
            ans[3][gr] = col;
            ans[2][gr] = col;
            ans[1][gr] = col;
        }
        if(col != k)
            return false;

    }*/
}

signed main(){
    /*ios_base::sync_with_stdio(false);
    cin.tie();
    cout.tie();*/
    int t;
    cin >> t;
    while(t--){
        int n, m, k;
        cin >> n >> m >> k;
        if(!solve(n, m, k))
            cout << "NO\n";
    }
}