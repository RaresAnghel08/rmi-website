/**
* user:  almazbekov-a71
* fname: Beksultan
* lname: Almazbekov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:57:00.738804
*/
#include <bits/stdc++.h>
using namespace std;
#define pii pair<int,int>
#define fr first
#define sc second
#define NO puts("NO");
#define YES puts("YES");
#define endi puts("");
const int N = 2e5+12;
int a[7][N+2];

main(){
	int t;
	cin>>t;
	while (t--){
		int n,m,k,i,j;
		cin>>n>>m>>k;
		for (i=1;i<=n;++i)
			for (j=1;j<=m;++j)
				a[i][j] = 0;
		if (n%2 == 1 || m%2 == 1 || n == 2 && m != k*2){
			NO
			continue;
		}
		if (n == 2){
			YES
			for (i=0;i<m;++i){
				cout <<i/2+1<<" ";
			}endi
			for (i=0;i<m;++i){
				cout <<i/2+1<<" ";
			}endi
		}
		else if (n == 4 && k > 1){
			
			int x = m,cnt = 1;
			i = 1;
			while (x > 0){
				
				if (x != k*2 || k == 1){
					x -= 2;
					k -= 2;
					a[2][i] = cnt;
					a[2][i+1] = cnt;
					a[1][i] = cnt;
					a[1][i+1] = cnt;
					cnt++;
					a[4][i] = cnt;
					a[4][i+1] = cnt;
					a[3][i] = cnt;
					a[3][i+1] = cnt;
					cnt++;
					i+=2;
				}
				else {
					for (j=1;j<=n;++j){
						a[j][i] = cnt;
						a[j][m] = cnt;
					}
					while (i<=m){
						a[1][i] = cnt;
						a[4][i] = cnt;
						i++;
					}
					cnt++;
					
					break;
				}
			}
			if (cnt != k && x != k*2){
				NO
				continue;
			}
			YES
			for (i=1;i<=n;++i){
				for (j=1;j<=m;++j){
					if (a[i][j] == 0){
						a[i][j] = cnt;
						a[i][j+1] = cnt;
						a[i+1][j] = cnt;
						a[i+1][j+1] = cnt;
						cnt++;
					}
					cout <<a[i][j]<<" ";
				}
				endi
			}
			
			
		}
		else NO
		
	}
}






