/**
* user:  elenkov-855
* fname: Kaloyan Georgiev
* lname: Elenkov
* task:  Gardening
* score: 11.0
* date:  2021-12-16 08:56:37.872731
*/
#include<bits/stdc++.h>
using namespace std;
int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(NULL);
    cout.tie(NULL);
    int T;
    cin>>T;
    for(int l=0;l<T;l++){
        int N,M,K;
        cin>>N>>M>>K;
        if(N==1 || M==1){
            cout<<"NO\n";
            continue;
        }if(N==2){
            if(M/2==K && M%2==0){
                cout<<"YES\n";
                for(int i=1;i<=K;i++){
                    cout<<i<<" "<<i<<" ";
                }
                cout<<"\n";
                 for(int i=1;i<=K;i++){
                    cout<<i<<" "<<i<<" ";
                }
                cout<<"\n";
            }else{
                cout<<"NO"<<"\n";
            }
            continue;
        }if(N==3){
            cout<<"NO"<<"\n";
            continue;
        }if(N==4){
            if(M%2==1 || K>M || M-K==1 || M/2>K){
                cout<<"NO"<<"\n";
                continue;
            }
            cout<<"YES"<<"\n";
            int y=M-K;
            int x=(M-2*y)/2;
            int koe=1,koe2=(2*x+1),koe3;
            //1
            for(int i=0;i<x;i++){
                cout<<koe<<" "<<koe<<" ";
                koe++;
            }for(int i=0;i<y;i++){
                cout<<koe2<<" "<<koe2<<" ";
            }
            koe=1;
            cout<<"\n";
            //2
            for(int i=0;i<x;i++){
                cout<<koe<<" "<<koe<<" ";
                koe++;
            }
            if(y!=0){
                cout<<koe2<<" ";
                koe3=koe2+1;
                for(int i=0;i<y-1;i++){
                    cout<<koe3<<" "<<koe3<<" ";
                    koe3++;
                }
                cout<<koe2;
            }
            cout<<"\n";
            //3
            for(int i=0;i<x;i++){
                cout<<koe<<" "<<koe<<" ";
                koe++;
            }
            if(y!=0){
                cout<<koe2<<" ";
                koe3=koe2+1;
                for(int i=0;i<y-1;i++){
                    cout<<koe3<<" "<<koe3<<" ";
                    koe3++;
                }
                cout<<koe2;
            }
            koe=x+1;
            cout<<"\n";
            //4
            for(int i=0;i<x;i++){
                cout<<koe<<" "<<koe<<" ";
                koe++;
            }for(int i=0;i<y;i++){
                cout<<koe2<<" "<<koe2<<" ";
            }
            cout<<"\n";
        }
    }
    return 0;
}

