/**
* user:  chertes-cab
* fname: Andrei
* lname: Chertes
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:41:12.504236
*/
#include <bits/stdc++.h>

using namespace std;

int T;


void solve() {
    int N, M, K;
    cin >> N >> M >> K;

    if(N == 2 && M == 2 && K == 1) {
        cout << "YES\n";
        cout << "11\n11\n";
        return;
    }

    if(N == 2 && M == 4 && K == 1) {
        cout << "YES\n";
        cout << "1111\n1111\n";
        return;
    }

    if(N == 4 && M == 2 && K == 1) {
        cout << "YES\n";
        cout << "11\n11\n11\n11\n";
        return;
    }

    if(N == 2 && M == 4 && K == 2) {
        cout << "YES\n";
        cout << "1122\n1122\n";
        return;
    }

    if(N == 4 && M == 2 && K == 2) {
        cout << "YES\n";
        cout << "11\n11\n22\n22\n";
        return;
    }

    if(N == 4 && M == 4 && K == 2) {
        cout << "YES\n";
        cout << "1111\n1221\n1221\n1111\n";
        return;
    }

    if(N == 4 && M == 4 && K == 3) {
        cout << "YES\n";
        cout << "1122\n1122\n3333\n3333\n";
        return;
    }

    if(N == 4 && M == 4 && K == 4) {
        cout << "YES\n";
        cout << "1122\n1122\n3344\n3344\n";
    }

    cout << "NO\n";
}

int main() {
    ios_base :: sync_with_stdio(false); cin.tie(0); cout.tie(0);

    cin >> T;
    while(T--) {
        solve();
    }
    return 0;
}
