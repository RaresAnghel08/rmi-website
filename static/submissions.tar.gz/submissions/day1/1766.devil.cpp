/**
* user:  trisca-vicol-58e
* fname: Cezar
* lname: Trișcă-Vicol
* task:  devil
* score: 0.0
* date:  2019-10-10 07:43:24.734461
*/
#include <bits/stdc++.h>

using namespace std;

int t,k,val,cnt[20],l,r,poz,first_digit,contor_total,contor[2000010];
string strong[2000010],digits[20];

int main()
{
    cin>>t;
    digits[0]="0";
    digits[1]="1";
    digits[2]="2";
    digits[3]="3";
    digits[4]="4";
    digits[5]="5";
    digits[6]="6";
    digits[7]="7";
    digits[8]="8";
    digits[9]="9";
    for(;t;t--){
        cin>>k;
        for(int i=1;i<=9;i++)
            cin>>cnt[i];
        val=0;
        for(int i=9;i>=1&&val<=k-1;i--){
            val+=cnt[i];
            if(val>k-1)
                first_digit=i;
        }
        strong[1]=digits[first_digit];contor[1]=val-(k-1);
        cnt[first_digit]-=contor[1];
        l=r=1;contor_total=contor[1];
        while(contor_total>1){
            poz=r;if(strong[poz].size()>=k)break;
            for(int i=1;i<first_digit&&contor[poz];i++){
                if(cnt[i]>=contor[poz]){
                    strong[++r]=strong[poz]+digits[i];
                    contor[  r]=contor[poz];
                    cnt[i]-=contor[poz];
                    if(strong[r].size()>=k)contor_total-=contor[r];
                    contor[poz]=0;
                }else if(cnt[i]){
                    strong[++r]=strong[poz]+digits[i];
                    contor[  r]=cnt[i];
                    if(strong[r].size()>=k)contor_total-=contor[r];
                    contor[poz]-=cnt[i];
                    cnt[i]=0;
                }
            }
            //if(!contor[poz])continue;
            for(;l<poz&&contor[poz];l++){
                if(!contor[l])continue;
                if(contor[l]>=contor[poz]){
                    strong[++r]=strong[poz]+strong[l];
                    contor[r]=contor[poz];
                    contor[l]-=contor[poz];
                    contor_total-=contor[poz];
                    if(strong[r].size()>=k)contor_total-=contor[r];
                    contor[poz]=0;
                    //break;
                }else{
                    strong[++r]=strong[poz]+strong[l];
                    contor[r]=contor[l];
                    contor[poz]-=contor[l];
                    contor_total-=contor[l];
                    if(strong[r].size()>=k)contor_total-=contor[r];
                    contor[l]=0;
                }
            }
            //if(contor[l])
        }
        for(int i=l;i<=r;i++)
            for(int j=1;j<=contor[i];j++)
                cout<<strong[i];
        for(int i=1;i<=9;i++)
            for(int j=1;j<=cnt[i];j++)
                cout<<i;
        cout<<'\n';
    }
    return 0;
}
