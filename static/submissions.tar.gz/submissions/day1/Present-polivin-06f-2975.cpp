/**
* user:  polivin-06f
* fname: Nikita
* lname: Polivin
* task:  Present
* score: 0.0
* date:  2021-12-16 10:24:37.914266
*/
#include <bits/stdc++.h>

using namespace std;

//#define int long long

char gcd(char a, char b){
    if(a == 0){
        return b;
    }
    if(b == 0){
        return a;
    }

    return gcd(b, a % b);
}

void solve(){
    int t;
    cin >> t;
    vector <int> q(t);
    for(int i = 0; i < t; ++i){
        cin >> q[i];
    }

    int k = 0;
    for(int i = 0; i < t; ++i){
        k = max(k, q[i]);
    }

    vector < set <char> > a(1000001);
    char mx = 1;
    int last = 1;
    while(a.size() <= k){
        int sz = last;
        for(int i = 0; i < sz; ++i){
            bool ok = 1;
            for(auto j : a[i]){
                if(!a[i].count(gcd(mx, j))){
                    ok = 0;
                    break;
                }
            }

            if(ok){
                a[last] = a[i];
                a[last].insert(mx);
                last++;
            }

            if(last > k){
                break;
            }
        }

        ++mx;
    }

    for(auto k : q) {
        cout << a[k].size() << " ";
        for (auto i : a[k]) {
            cout << int(i) << " ";
        }
        cout << '\n';
    }
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    solve();
    /*int tests;
    cin >> tests;
    while(tests--){
        solve();
    }*/
}