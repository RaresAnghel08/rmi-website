/**
* user:  luchianov-9b7
* fname: Alexandru
* lname: Luchianov
* task:  devil
* score: 0.0
* date:  2019-10-10 09:40:44.746480
*/
//#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

ifstream cin ("devil.in");
ofstream cout ("devil.out");

#define ll long long
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) < (b)) ? (b) : (a))

int const nmax = 12;
int d[1 + nmax];
ll p10[1 + nmax];

vector<int> v;

ll extract(int k){
  ll val = 0;
  ll smax = 0;
  for(int i = 0; i < v.size(); i++){
    val = val * 10 + v[i];
    if(k <= i)
      val -= v[i - k] * p10[k];
    smax = MAX(smax, val);
  }
  return smax;
}

void solve(){
  p10[0] = 1;
  for(int i = 1;i <= nmax; i++)
    p10[i] = p10[i - 1] * 10;

  int k;
  cin >> k;
  v.clear();
  vector<int> sol;
  ll smin = p10[12];

  for(int i = 1; i <= 9; i++) {
    cin >> d[i];
    for(int j = 0; j < d[i]; j++)
      v.push_back(i);
  }

  do {
    ll val = extract(k);
    if(val < smin){
      smin = val;
      sol = v;
    }
  } while(next_permutation(v.begin(), v.end()));
}

int main()
{

/*
for subtask 1
*/

  int t;
  cin >> t;
  for(int testcase = 1; testcase <= t; testcase++){
    solve();
  }

  return 0;
}
