/**
* user:  petkov-737
* fname: Georgy
* lname: Petkov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:39:31.715675
*/
#include <bits/stdc++.h>

using namespace std;

int t;
void read()
{
	cin >> t;
}

int k;
int d[10];
void solve()
{
	while (t--)
	{
		cin >> k;
		for (int i = 1; i <= 9; i++)
		   cin >> d[i];

	    int idx;
	    int sum = 0;
		string last; 
	     for (int i = 9; i >= 1; i--)
		 { 
			 if (sum + d[i] > k - 1)
			 {
				 for (int j = 1; j <= k - 1 - sum; j++)
					 last.push_back((char)(i + '0'));

				 for (int j = i + 1; j <= 9; j++)
					 for (int p = 1; p <= d[j]; p++)
						 last.push_back((char)(j + '0'));

				 idx = i; 
				 d[i] -= k - 1 - sum; 
				 break;
			 }

			 sum += d[i]; 
		 }	  
		 vector <string> v;
		 for (int i = 1; i <= d[idx]; i++)
		 {
			 string curr;
			 curr.push_back((char)(idx + '0'));

			 v.push_back(curr);
		 }

		 for (int i = idx; i <= 9; i++)
			 d[i] = 0;

		 vector <string> to_add;

		 for (;;)
		 {
			 int sz = v.size();
				bool is = false;
					int sum = 0, idx1;

					for (int j = 0; j < idx; j++)
					{
						sum += d[j];

						if (sum >= sz)
						{
							is = true;
							idx1 = j; 
							break; 
						}
					}

				
				if (!is)
				{
					for (int j = sz - 1; j >= 0; j--)
						for (int j = 0; j < idx; j++)
							if (d[j])
							{
								v[j].push_back((char)(j + '0'));

								d[j]--;
								break; 
							}

					break; 
				}

				for (int j = 0; j < sz; j++)
					for (int p = idx1; p >= 1; p--)
						if (d[p])
						{
							v[j].push_back((char)(p + '0'));
						   d[p]--;
					       break; 	   
						}

				char first = v[0][v[0].size()-1];

				while (v.back()[v.back().size()-1] != first)
				{
				to_add.push_back(v.back());
				v.pop_back();
				}
		 }

		 while (!v.empty())
		 {
			 to_add.push_back(v.back());
			 v.pop_back();
		 }

		 string ans;

		 int sz = to_add.size();
		 for (auto i = sz - 1; i >= 0; i--)
			 ans += to_add[i];

		 ans += last;

		 cout << endl;
		 cout << ans << endl;
	}
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	read();
	solve();
}
