/**
* user:  oliinyk-809
* fname: Andrii
* lname: Oliinyk
* task:  Present
* score: 8.0
* date:  2021-12-16 11:09:31.260865
*/
#include <bits/stdc++.h>

#define INF 1000000005
#define EPS 1e-6
#define pb push_back
#define pause system("pause")
#define exit exit(0)
#define endl '\n'

using namespace std;
using ull = unsigned long long;
using ll = long long;

typedef pair<int, int> pii;
const int N = 40005, LG = 16;

int t, k;
string ans = "__1_2_12_3_13_123_4_14_24_124_134_1234_5_15_125_135_1235_145_1245_1345_12345_6_16_26_126_36_136_1236_246_1246_12346_156_1256_1356_12356_12456_123456_7_17_127_137_1237_147_1247_1347_12347_157_1257_1357_12357_1457_12457_13457_123457_167_1267_1367_12367_12467_123467_1567_12567_13567_123567_124567_1234567_8_18_28_128_138_1238_48_148_248_1248_1348_12348_158_1258_1358_12358_1458_12458_13458_123458_268_1268_12368_2468_12468_123468_12568_123568_124568_1234568_178_1278_1378_12378_1478_12478_13478_123478_1578_12578_13578_123578_14578_124578_134578_1234578_12678_123678_124678_1234678_125678_1235678_1245678_12345678_";

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	
	cin >> t;
	while (t--) {
		cin >> k;
		++k;
		if (k > 100) return 0;
		int i = 0;
		while (k) {
			if (ans[i++] == '_') {
				--k;
			}
		}

		string dt;
		while (ans[i] != '_') {
			dt += ans[i++];
		}

		cout << dt.size();
		for (auto x : dt) {
			cout << ' ' << x;
		}
		cout << endl;
	}
	//pause;
	return 0;
}
