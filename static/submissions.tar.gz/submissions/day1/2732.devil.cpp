/**
* user:  molnar-2e8
* fname: Bálint
* lname: Molnár
* task:  devil
* score: 13.0
* date:  2019-10-10 09:52:53.667657
*/
#include <bits/stdc++.h>
#define ll long long
#define vi vector<ll>
#define ft(n,i) for(ll i=0;i<n;i++)
#define tft(n,l,i) for(ll i=l;i<n;i++)
#define ftb(n,i) for (ll i=n-1;i>=0;i--)
#define pb push_back
#define mano dp[hely][most][kov][volte][ke]
#define sano su[hely][most][volte][ke]
using namespace std;
const ll md=1e9+7;

int main()
{
    ios::sync_with_stdio(0);
cin.tie(0);
cout.tie(0);
ll t; cin>>t; while (t--)
{
ll k; cin>>k; ll hh=pow(10,k-1);
vi v(9,0);
 ft (9,i) cin>>v[i];
vi a; ft (9,i)
{
    ft (v[i], j) a.pb(i+1);
}
ll mi=md*md; vi mihe(a.size());
do
{

ll s=0;
ft (k,i)
{
    s=10*s+a[i];
}
ll kismi=s;

tft(a.size(), k, i)
{

    s-=(hh*a[i-k]); s=10*s+a[i];
    kismi=max(kismi, s);//cout<<s<<" "<<kismi<<" "<<mi<<endl;
}
if (kismi<=mi)
{
    mi=kismi; mihe=a;
}
} while (next_permutation(a.begin(), a.end()));


for (ll x:mihe) cout<<x;
cout<<endl;
}

return 0;
}
