/**
* user:  todoran-c08
* fname: Alexandru Raul
* lname: Todoran
* task:  devil
* score: 13.0
* date:  2019-10-10 10:08:37.051944
*/
#include <bits/stdc++.h>

using namespace std;

const int S_MAX = 1000002;

int t;

int k;

int cnt[10];

int sum;

string s;

string ans;

string ansmxs;

void bk (int lg)
{
    if(lg == sum)
    {
        string mxs = "";
        char mx = 0;
        for(int i = 0; i < lg - k + 1; i++)
            if(s[i] > mx)
                mx = s[i];
        for(int i = 0; i < lg - k + 1; i++)
            if(s[i] == mx)
            {
                string s1 = "";
                for(int j = i; j <= i + k - 1; j++)
                    s1 += s[j];
                mxs = max(mxs, s1);
            }
        if(ans == "" || mxs < ansmxs)
        {
            ans = s;
            ansmxs = mxs;
        }
        return;
    }
    for(int i = 1; i <= 4; i++)
        if(cnt[i] > 0)
        {
            cnt[i]--;
            s += char('0' + i);
            bk(lg + 1);
            s.pop_back();
            cnt[i]++;
        }
}

int main()
{
    cin >> t;
    while(t--)
    {
        cin >> k;
        sum = 0;
        for(int i = 1; i <= 9; i++)
        {
            cin >> cnt[i];
            sum += cnt[i];
        }
        ans = ansmxs = "";
        bk(0);
        cout << ans << "\n";
    }
    return 0;
}
