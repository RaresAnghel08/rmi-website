/**
* user:  kemanov-48c
* fname: Lachezar
* lname: Kemanov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:38:35.723407
*/
#include<iostream>
using namespace std;
int dig[10],k,t,n;


int main()
{
    cin>>t;
    for(int a=0; a<t; a++)
    {
        cin>>k;
        int j=0;
        for(int b=1; b<10; b++)
        {
            cin>>dig[b];
            n+=dig[b];
            if(dig[b]>0)
                j=b;
        }
        if(dig[2]==0)
        {
            while(dig[1]>0)
                {dig[1]--;
                    cout<<1;}
            cout<<endl;
            continue;
        }
        if(dig[1]==0)
        {
            while(dig[2]>0)
            {
                cout<<2;
                dig[2]--;
            }
            cout<<endl;
            continue;
        }
        bool g=false;
        if(dig[2]>=k-1)
        {
            dig[2]-=(k-1);
            dig[1]--;
            g=true;

        }
        if(dig[1]>dig[2])
        {
            int q=dig[1]/dig[2];
            while(dig[2]>0)
            {
                cout<<2;
                dig[2]--;
                for(int c=0; c<q; c++)
                {
                    cout<<1;
                    dig[1]--;
                }
            }
            while(dig[1]>0)
            {
                cout<<1;
                dig[1]--;
            }
            if(g==true)
            {

            cout<<1;
            for(int c=0; c<k-1; c++)
                cout<<2;
            cout<<endl;
            }
            else cout<<endl;
        }
        else
        {
            int q=dig[2]/dig[1];
            while(dig[1]>0)
            {
                for(int c=0; c<q; c++)
                {
                    cout<<2;
                    dig[2]--;
                }
                cout<<1;
                dig[1]--;
            }
            while(dig[2]>0)
            {
                cout<<2;
                dig[2]--;
            }
                        if(g==true)
            {

            cout<<1;
            for(int c=0; c<k-1; c++)
                cout<<2;
            cout<<endl;
            }
            else cout<<endl;
        }
    }

    return 0;
}
