/**
* user:  yanushevskyi-c2e
* fname: Roman
* lname: Yanushevskyi
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:02:15.806757
*/
#include <cstdio>
#include <cassert>
#include <algorithm>

const int N = 12;
int t, n, m, k, ans[N][N];
bool ok[N + 1][N + 1][N * N / 4 + 1];

void run(int i, int j, int n, int m, int k, int add) 
{
	if (n == 2 && m == 2) {
		ans[i][j] = ans[i + 1][j] = ans[i][j + 1] = ans[i + 1][j + 1] = k + add;
		return;
	}
	if (ok[n - 2][m - 2][k - 1]) {
		for (int x = 0; x < n; ++x) ans[i + x][j] = ans[i + x][j + m - 1] = k + add;
		for (int y = 0; y < m; ++y) ans[i][j + y] = ans[i + n - 1][j + y] = k + add;
		run(i + 1, j + 1, n - 2, m - 2, k - 1, add);
		return;
	}
	for (int x = 2; x < n; x += 2) for (int l = 1; l < k; ++l) if (ok[x][m][l] && ok[n - x][m][k - l]) {
		run(i, j, x, m, l, add);
		run(i + x, j, n - x, m, k - l, add + l);
		return;
	}
	for (int y = 2; y < m; y += 2) for (int l = 1; l < k; ++l) if (ok[n][y][l] && ok[n][m - y][k - l]) {
		run(i, j, n, y, l, add);
		run(i, j + y, n, m - y, k - l, add + l);
		return;
	}
	assert(false);
}

int main() 
{
	ok[2][2][1] = 1;
	for (int i = 2; i <= N; i += 2) for (int j = 2; j <= N; j += 2) if (i != 2 || j != 2) {
		int from = std::max(i, j) >> 1, to = i * j / 4;
		for (int k = 2; k < i; k += 2) {
			for (int l = from; l <= to; ++l) {
				for (int x = 1; x < l; ++x) if (ok[k][j][x] && ok[i - k][j][l - x]) ok[i][j][l] = 1;
			}
		}
		for (int k = 2; k < j; k += 2) {
			for (int l = from; l <= to; ++l) {
				for (int x = 1; x < l; ++x) if (ok[i][k][x] && ok[i][j - k][l - x]) ok[i][j][l] = 1;
			}
		}
		for (int l = from; l <= to; ++l) {
			if (ok[i - 2][j - 2][l - 1]) ok[i][j][l] = 1;
			//if (ok[i][j][l]) printf("%d %d %d\n", i, j, l);
		}
	}
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d%d", &n, &m, &k);
		if (ok[n][m][k]) {
			printf("YES\n");
			run(0, 0, n, m, k, 0);
			for (int i = 0; i < n; ++i) {
				for (int j = 0; j < m; ++j) printf("%d ", ans[i][j]);
				printf("\n");
			}
		} else printf("NO\n");
	}
	return 0;
}
