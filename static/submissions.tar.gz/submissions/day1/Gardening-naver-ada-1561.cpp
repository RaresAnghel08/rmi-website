/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  Gardening
* score: 11.0
* date:  2021-12-16 08:09:13.742061
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define endl '\n'
void solve(){
    int n,m,k;cin>>n>>m>>k;
    if (n%2 || m%2){
        cout<<"NO"<<endl;
        return;
    }
    bool sw=false;
    if (n>m){
        swap(n,m);
        sw=true;
    }
    if (k<m/2){
        cout<<"NO\n";
        return;
    }
    if (k>(n*m)/4){
        cout<<"NO\n";
        return;
    }
    vector<vector<int> >a(n);
    for (int i=0;i<n;i++) a[i].resize(m,0);
    int i=0;
    while (k<=(n-i*2-2)*(m-i*2-2)/4){
        for (int j=i;j<m-i;j++){
            a[i][j]=a[n-i-1][j]=k;
        }
        for (int j=i;j<n-i;j++){
            a[j][i]=a[j][m-i-1]=k;
        }
        i++;
        k--;
    }
//    cout<<k<<" "<<n-i*2<<" "<<m-i*2<<endl;
    int P=(n-i*2)*(m-i*2)-4*(k-1);
//    cout<<P<<endl;
    int A,B;
    A=B=P/4+1;
    if ((A+B)%2 || A+B==6){
        cout<<"NO\n";
        return;
    }
    if (A>n-i*2){
        B+=A-n+i*2;
        A=n;
    }

    if (A%2){
        A--;
        B++;
    }

    for (int x=0;x<A;x++){
        a[i+x][i]=k;

        a[i+x][i+B-1]=k;
    }
    for (int y=0;y<B;y++){
        a[i][i+y]=k;
        a[i+A-1][i+y]=k;
    }
//    for (int i=0;i<n;i++){
//        for (int j=0;j<m;j++) cout<<a[i][j]<<" ";
//        cout<<endl;
//    }
    k--;
    for (int x=i+1;x<i+A-1;x+=2){
        for (int y=i+1;y<i+B-1;y+=2){
            a[x][y]=a[x][y+1]=a[x+1][y]=a[x+1][y+1]=k;
            k--;
        }
    }
//    if (k!=(n-i*2)*(m-i*2)/4){
//        cout<<"NO\n";
//        return;
//    }
    for (int x=i;x<n-i;x+=2){
        for (int y=i;y<m-i;y+=2){
            if (a[x][y]) continue;
            a[x][y]=a[x][y+1]=a[x+1][y]=a[x+1][y+1]=k;
            k--;
        }
    }
    cout<<"YES\n";
    if (sw){
        for (int i=0;i<m;i++){
            for (int j=0;j<n;j++) cout<<a[j][i]<<" ";
            cout<<endl;
        }
    } else {
        for (int i=0;i<n;i++){
            for (int j=0;j<m;j++) cout<<a[i][j]<<" ";
            cout<<endl;
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int tt;cin>>tt;
    while (tt--){
        solve();
    }
    return 0;
}
/**
5
2 2 2
2 2 1
4 4 4
4 4 2
4 6 3

**/
