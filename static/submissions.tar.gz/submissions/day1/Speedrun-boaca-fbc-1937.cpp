/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 08:42:53.589910
*/
#include "speedrun.h"
#include <bits/stdc++.h>
//#include "grader.cpp"
void assignHints(int subtask, int N, int A[], int B[])
{
    int n=N;
    setHintLen(10);
    int nr[1005];
    for(int i=1;i<=n;i++)
        nr[i]=0;
    for(int i=1;i<n;i++)
    {
        nr[A[i]]++;
        nr[B[i]]++;
    }
    int root=0;
    int maxim=0;
    for(int i=1;i<=n;i++)
        if(nr[i]>maxim)
        {
            maxim=nr[i];
            root=i;
        }
    for(int i=1;i<=n;i++)
        if(i!=root)
        {
            int lg=0;
            for(int bit=9;bit>=0;bit--)
            {
                lg++;
                if((root>>bit)&1)
                    setHint(i,lg,1);
                else
                    setHint(i,lg,0);
            }
        }
}
void dfs(int nod,int par,int N)
{
    int nodes[1005];
    int lg=0;
    int nr=0;
    for(int i=1;i<=10;i++)
        nr=nr*2+getHint(i);
    if(nr==0)
    {
        for(int i=1;i<=N;i++)
            if(i!=nod)
                nodes[++lg]=i;
    }
    else
    {
        nodes[++lg]=nr;
    }
    for(int i=1;i<=lg;i++)
        if(nodes[i]!=par)
    {
        goTo(nodes[i]);
        dfs(nodes[i],nod,N);
    }
    if(par!=0)
        goTo(par);
}
void speedrun(int subtask, int N, int start)
{
    int l=getLength();
    dfs(start,0,N);
}
