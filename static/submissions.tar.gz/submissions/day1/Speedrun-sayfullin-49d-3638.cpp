/**
* user:  sayfullin-49d
* fname: Iskandar
* lname: Sayfullin
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:24:27.372971
*/
#include <iostream>
#include <stack>
#include <vector>
#include "speedrun.h"

using namespace std;

void assignHints(int substack, int N, int A[], int B[]) {
    setHintLen(N);

    for (int i = 1; i < N; i++) {
        setHint(A[i], B[i], 1);
        setHint(B[i], A[i], 1);
    }
}

void speedrun(int substack, int N, int start) {
    vector<bool> used(N);
    int l = getLength();

    vector <vector<bool>> g(N, vector<bool>(N));
    stack<int> s;
    vector<int> p(N, -1);

    used[start - 1] = true;
    for (int j = 1; j <= l; j++) {
        g[start - 1][j - 1] = getHint(j);
        if (g[start - 1][j - 1] && !used[j - 1]) {
            s.push(j - 1);
            p[j - 1] = start - 1;
        }
    }

    while (s.size() != 0) {
        bool f = false;

        goTo(s.top() + 1);
        start = s.top() + 1;
        s.pop();

        if (!used[start - 1]) {
            for (int j = 1; j <= l; j++) {
                g[start - 1][j - 1] = getHint(j);
                if (g[start - 1][j - 1] == 1 && !used[j - 1]) {
                    s.push(j - 1);
                    f = true;
                    p[j - 1] = start - 1;
                }
            }
            used[start - 1] = true;
            if (!f) {
                goTo(p[start - 1] + 1);
            }
        }
    }
}