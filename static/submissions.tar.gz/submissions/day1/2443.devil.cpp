/**
* user:  karimov-095
* fname: Renat
* lname: Karimov
* task:  devil
* score: 0.0
* date:  2019-10-10 09:16:37.836641
*/
#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define ld long double
#define ll long long


int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    while(n-- != 0){
        int k;
        cin >> k;
        if (k == 2){
            vector<int> v(10), v1;
            for (int i = 1; i < 10; i++){
                cin >> v[i];
            }
            for (int i = 1; i < 10; i++){
                while(v[i] != 0){
                    v1.pb(i);
                    v[i]--;
                }
            }
            int mid;
            bool x = 0;
            if (!(v1.size() & 1)){
                mid = v1.size() / 2 - 1;
            }
            else{
                mid = v1.size() / 2;
                x = 1;
            }
            cout << mid << endl;
            vector<int> ans;
            for (int i = 1; i <= mid; i++){
                if (!x){
                    ans.pb(v1[i + mid]);
                    ans.pb(v1[mid - i]);
                }
                else{
                    ans.pb(v1[mid - i]);
                    ans.pb(v1[i + mid]);
                }
            }
            cout << v1[mid];
            for (auto to : ans){
                cout << to;
            }
            if (!x)cout << v1[v1.size() - 1];
        }
    }
}
