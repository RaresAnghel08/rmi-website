/**
* user:  stupariu-92e
* fname: Teodor-Mihai
* lname: Stupariu
* task:  Present
* score: 29.0
* date:  2021-12-16 09:07:33.904455
*/
#include <iostream>
#include <cmath>

using namespace std;
//ifstream cin("p.in");
//ofstream cout("p.out");
int v[10005],f[10000005],mat[1005][1005];
int ver(int n)
{
    int cnt=0,nr=1,ok=0;
    while(n>0)
    {
        if(n%2==1)
        {
            v[++cnt]=nr;
            f[nr]=1;
        }
        nr++;
        n/=2;
    }
    for(int i=1; i<=cnt; i++)
    {
        for(int j=1; j<i; j++)
        {
            if(f[mat[v[i]][v[j]]]==0)
            {
                ok=1;
                break;
            }
        }
        if(ok==1)
        {
            break;
        }
    }
    for(int i=1; i<=cnt; i++)
        f[v[i]]=0;
    return ok;
}
int main()
{
    for(int i=1; i<=205; i++)
    {
        for(int j=1; j<=205; j++)
        {
            if(i==j)
                mat[i][j]=i;
            else if(i>j) mat[i][j]=mat[i-j][j];
            else if(j>i) mat[i][j]=mat[i][j-i];
        }
    }
    int t,k;
    cin>>t;
    for(int i=1; i<=t; i++)
    {
        cin>>k;
        int j=1;
        while(j<=k)
        {
            k+=ver(j);
            j++;
        }
        int ck=k,cer1=0,x=1;
        while(ck>0)
        {
            if(ck%2==1)
                cer1++;
            ck/=2;
        }
        cout<<cer1<<" ";
        while(k>0)
        {
            if(k%2==1)
                cout<<x<<" ";
            x++;
            k/=2;
        }
        cout<<'\n';
    }
    return 0;
}
