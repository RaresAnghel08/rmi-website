/**
* user:  perju verzotti-7df
* fname: Luca
* lname: Perju Verzotti
* task:  Present
* score: 29.0
* date:  2021-12-16 10:28:24.336016
*/
#include <bits/stdc++.h>

using namespace std;
int gcd[503][503];
int cmmdc (int a, int b)
{
    int r;
    while(b)
    {
        r=a%b;
        a=b;
        b=r;
    }
    return a;
}
struct ura
{
    int val,pz;
}qs[10];
vector<int>rz[10];
bool cmp (ura a, ura b)
{
    return a.val<b.val;
}
int vc[503],mxc;
void getnxt () /// and here's the whole problem
{
    int i,j,k,ok;
    for(i=1;i<=mxc+1;++i)
        if(!vc[i])
            break;
    vc[i]=1;
    mxc=max(mxc,i);
    for(--i;i>=1;--i)
    {
        ok=0;
        for(j=i+i;j<=mxc&&!ok;++j)
            if(vc[j])
                for(k=j+i;k<=mxc;++k)
                {
                    if(vc[k] && gcd[j][k]==i)
                    {
                        ok=1;
                        break;
                    }
                }
        vc[i]=ok;
    }
}
int main()
{
    int n,i,j,t,k;
    for(i=1;i<=500;++i)
        for(j=1;j<=500;++j)
            gcd[i][j]=cmmdc(i,j);
    cin>>t;
    for(i=1;i<=t;++i)
    {
        cin>>qs[i].val;
        qs[i].pz=i;
    }
    sort(qs+1,qs+t+1,cmp);
    i=1,j=0;
    while(i<=t)
    {
        while(i<=t && qs[i].val==j)
        {
            for(k=1;k<=mxc;++k)
                if(vc[k])
                    rz[qs[i].pz].push_back(k);
            ++i;
        }
        ++j;
        getnxt();
    }
    for(i=1;i<=t;++i)
    {
        cout<<rz[i].size()<<' ';
        for(j=0;j<rz[i].size();++j)
            cout<<rz[i][j]<<' ';
        cout<<'\n';
    }
    return 0;
}
