/**
* user:  wald-761
* fname: Inbar
* lname: Wald
* task:  devil
* score: 0.0
* date:  2019-10-10 06:28:33.301532
*/
#include <iostream>
#include <vector>
#include <utility>
#include <queue>
#include <deque>
#include <stack>
#include <algorithm>
using namespace std;
#define int63 long long
#define make(name) int63 name; cin >> name
#define out(data) cout << data << endl
#define __ << " " <<
#define forf(name,start,end) for(int63 name = start; name < end; name++)
#define forfb(name,start,end) for(int63 name = end-1; name >= start; name--)
#define fort(start,end) forf(i,start,end)
#define fortb(start,end) forf(i,start,end)
#define forto(start,end) forf(j,start,end)
#define fortob(start,end) forf(j,start,end)
#define fortoo(start,end) forf(k,start,end)
#define fortoob(start,end) forf(k,start,end)
#define all(name) name.begin(), name.end()
#define first(name) name[0]
#define last(name) name[name.size() - 1]
int main(){
	make(t);
	fortoo(0,t){
		make(r);
		int63 n = 9,s=0;
		vector<int63> counts(n);
		fort(0,n){
			cin >> counts[i];
			s+=counts[i];
		}
		while(last(counts) == 0){
			counts.pop_back();
			n--;
		}
		if(r == 2){
			while(counts[n-1] > 1){
				cout << n;
				counts[n-1]--;
				fort(0,n-1){
					if(counts[i] > 0){
						cout << i+1;
						counts[i]--;
						break;
					}
				}
			}
			fort(0,n-1){
				while(counts[i] > 0){
					cout << i+1;
					counts[i]--;
				}
			}
			cout << n;
			cout << endl;
			continue;
		}
		vector<vector<int63>> subs;
		if(last(counts) < (s+n - 1)/n){
			subs.resize(last(counts));
		} else {
			subs.resize((s+n - 1)/n);
		}
		fort(0,subs.size()){
			subs[i].push_back(n);
			counts[n-1]--;
		}
		while(last(counts) == 0){
			counts.pop_back();
			n--;
		}
		while(subs.size() <= counts[0]){
			fort(0,subs.size()){
				subs[i].push_back(1);
				counts[0]--;
			}
		}
		fort(0,counts[0]){
			subs[i].push_back(1);
		}
		int63 trash = counts[0];
		counts[0] = 0;

	}
	return 0;
}
