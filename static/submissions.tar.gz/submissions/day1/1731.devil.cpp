/**
* user:  coroian-5c7
* fname: David Nicolae
* lname: Coroian
* task:  devil
* score: 0.0
* date:  2019-10-10 07:38:22.665415
*/
#include <bits/stdc++.h>
//#include <fstream>
//#include <string>


using namespace std;

//ifstream cin("txt.in");
//ofstream cout("txt.out");

int k;
int d[10];

string s;
string b;

int n;

void init()
{
    n = 0;
    for(int i = 1; i <= 9; i ++)
        n += d[i];

    s.resize(n);
    b.resize(n);
}

int a[10];
/*
bool pos(int nr, int pr)
{
    int c1 = nr / 10;
    int c2 = nr % 10;
    for(int i = 1; i <= 9; i ++)
        a[i] = d[i];

    s[n - 1] = b[n - 1];
    a[s[n - 1]] --;

    //cout << nr << " " << pr << " " << a[9] << "\n";

    for(int i = 1; i < n; i ++)
    {
        if(i & 1)
        {
            for(int j = pr; j >= 1; j --)
            {
                if(a[j] > 0)
                {
                    a[j] --;
                    s[i - 1] = j;

                    break;
                }
            }
        }

        else
        {
            int st = 0;
            if(s[i - 1 - 1] == pr)
                st = c2;

            else
                st = pr;

            for(int j = st; j >= 1; j --)
            {
                if(a[j] > 0)
                {
                    a[j] --;
                    s[i - 1] = j;
                        break;
                }
            }
        }

        //if(nr == 91)
       // cout << " PE " << i << " AM PUS " << (char)(s[i - 1] + '0') << "\n";
    }

    for(int i = 0; i + 1 < n; i ++)
    {
        if(s[i] * 10 + s[i + 1] > nr)
            return 0;

    }

    for(int i = 0; i < n; i ++)
    {
        if(s[i] == 0)
            return 0;
    }

    //cout << nr << "++\n";
    //for(int i = 0; i < n; i ++)
   //     cout << s[i]+'0';
   // cout << "\n";

    return 1;
}*/

void afis()
{
    for(int i = 0; i < n; i ++)
        s[i] += '0';

    cout << s << "\n";
}
/*
void solvek2()
{
    int cr = 0;

    for(int i = 1; i <= 9; i ++)
    {
        for(int j = 1; j <= d[i]; j ++)
        {
            b[cr] = i;
            cr ++;
        }
    }

    int mn = b[n - 1 - 1] * 10;

    for(int j = 1; j <= 9; j ++)
    {
        int ok = pos(mn + j, mn / 10);

        if(ok)
        {
           //cout << " MERGE PENTRU " << mn + j << "\n";
            afis();

            return;
        }
    }
}*/

void solve12()
{
    if(d[2] <= k)
    {
        int cr = 0;
        for(int i = 1; i <= 2; i ++)
        {
            for(int j = 1; j <= d[i]; j ++)
            {
                s[cr] = i;
                cr ++;
            }
        }

        if(d[2] == k)
            swap(s[0], s[n - k]);

        afis();

        return;
    }

    int cr = 0;
    int cati = d[2] - (k - 1);
    for(int i = n; i >= 1; i --)
    {
       // cout << i * cati << " " << d[1] << "\n";
        if(1LL * i * cati <= 1LL * d[1])
        {
            for(int x = 1; x <= cati; x ++)
            {
                s[cr] = 2;
                cr ++;
                d[2] --;

                for(int h = 1; h <= i; h ++)
                {
                    s[cr] = 1;
                    d[1] --;
                    cr ++;
                }
            }

            for(int h = 1; h <= d[1]; h ++)
            {
                s[cr] = 1;
                cr ++;
            }

            for(int h = 1; h <= d[2]; h ++)
            {
                s[cr] = 2;
                cr ++;
            }

            afis();

            return;
        }
    }
}

void ansQues()
{
    int q;
    cin >> q;
    while(q > 0)
    {
        q --;

        cin >> k;

        for(int i = 1; i <= 9; i ++)
            cin >> d[i];

        init();

        if(d[1] + d[2] == n)
        {
            solve12();
        }
    }
}

int main()
{
    ansQues();

    return 0;
}
