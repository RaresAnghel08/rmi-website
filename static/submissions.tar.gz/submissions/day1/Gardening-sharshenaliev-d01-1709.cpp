/**
* user:  sharshenaliev-d01
* fname: Nazar
* lname: Sharshenaliev
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:21:09.551385
*/
#include <bits/stdc++.h>
using namespace std;
int a[5000][5000];
int main(){
	int t; cin >> t;
	while(t--){	
	int n , m , k;
		cin >> n >> m >> k;
		if(n == m and m % 2 == 1){
			cout << "NO"<<endl;
			return 0;
		}else if(n == m and n * m / k != 4){
			cout << "NO" << endl;
		}else if(n == m and n * m / k == 4){
			int cnt = 0;
			int r = 0;
			for (int i = 0; i < n; i+=2){
				for (int j = 0; j < m; j++){
					if(cnt % 2 == 0){
						r++;
					}
					cnt ++;
					a[i][j] = r;
					a[i+1][j] = r;
				}
			}
			cout << "YES" << endl;
			for (int i = 0; i < n; i++){
				for (int j = 0; j < m; j++){
					cout << a[i][j]<<" ";
				}
				cout << endl;
			}
		}
	}return 0;
}