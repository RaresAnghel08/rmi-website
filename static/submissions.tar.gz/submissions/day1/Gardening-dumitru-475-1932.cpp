/**
* user:  dumitru-475
* fname: Matei
* lname: Dumitru
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:42:23.530210
*/
#include <bits/stdc++.h>

using namespace std;

unordered_map<int, unordered_map<int, int>> mat;
int i, j, start[200001];

void outp(int n, int m, int caz)
{
    if (caz == 1)
    {
        for (i = 1; i <= n; i++)
        {
            for (j = 1; j <= m; j++)
                cout << mat[1][j] << " ";
            cout << '\n';
        }
    }
    else
    {
        if (m % 2 == 0)
        {
            for (i = 1; i <= n; i++)
            {
                for (j = 1; j <= m; j++)
                {
                    if (mat[i][j] != 0)
                        cout << mat[i][j] << " ";
                    else
                    {
                        mat[i][j] = mat[i - 1][j];
                        cout << mat[i][j] << " ";
                    }
                }
                cout << '\n';
            }
        }
        else
        {
            for (i = 1; i <= n; i++)
            {
                for (j = 1; j < m; j++)
                {
                    if (mat[i][j] != 0)
                        cout << mat[i][j] << " ";
                    else
                    {
                        mat[i][j] = mat[i - 1][j];
                        cout << mat[i][j] << " ";
                    }
                }
                cout << mat[i][m - 1] << '\n';
            }
        }
    }
}

int main()
{
    // cp - cate patrate
    int t, n, m, k, ack, cat, cp, ok = 0;
    cin >> t;
    while (t)
    {
        cin >> n >> m >> k;
        if (n == 1 || m == 1)
            cout << "NO" << '\n';
        else
        {
            if (k <= m / 2)
            {
                cat = int(ceil(double(1.00 * m / k)));
                cout << cat << endl;
                ack = 1;
                for (i = 1; i <= m; i++)
                {
                    if (cat > 0)
                        mat[1][i] = ack, cat--;
                    else
                    {
                        cat = int(ceil(double(1.00 * m / k)));
                        ack++;
                        i--;
                    }
                }
                cout << "YES" << '\n';
                outp(n, m, 1);
            }
            else
            {
                if (m % 2 == 1)
                    m--, ok = 1;
                int tot = n * m, col = 1, cc, cnp;
                cp = tot / (4 * k);
                if (cp >= 1)
                {
                    for (cc = 1; cc <= k; cc++)
                    {
                        for (i = start[col] + 1, cnp = 0; cnp < cp; i += 2, cnp++)
                        {
                            mat[i][col] = mat[i + 1][col] = mat[i][col + 1] = mat[i + 1][col + 1] = cc;
                            start[col] = i + 1;
                        }
                        col = (col + 2) % m;
                        if (col == 0)
                            col++;
                    }
                    cout << "YES" << '\n';
                    if (ok == 1)
                        m++;
                    outp(n, m, 2);
                }
                else
                    cout << "NO" << '\n';
            }
        }
        mat.clear();
        t--;
    }
    return 0;
}