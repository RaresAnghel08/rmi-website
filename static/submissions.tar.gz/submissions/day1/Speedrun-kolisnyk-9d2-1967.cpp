/**
* user:  kolisnyk-9d2
* fname: Illia
* lname: Kolisnyk
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 08:46:36.633280
*/
#include <bits/stdc++.h>
#include "speedrun.h"
#define pb push_back

using namespace std;

const int N = 1e3 + 55;

vector <int> g[N];
int sz[N];
vector <int> order;
int frt;

void dfs(int v, int pr = 0) {
    sz[v] = 1;
    for (auto & to : g[v]) {
        if (to != pr) {
            dfs(to, v);
            sz[v] += sz[to];
            if (g[v][0] == pr || sz[to] > sz[g[v][0]]) swap(to, g[v][0]);
        }
    }
    if (!g[v].empty()) {
        int to = g[v][0];
        if (to != pr) {
            for (int i = 0; i < 10; i ++) {
                setHint(v, i + 1, ((to >> i) & 1));
            }
        }
        for (int i = 0; i < 10; i ++) {
            setHint(v, i + 10 + 1, ((pr >> i) & 1));
        }
    }
}

void set_lazy_hint(int v, int pr = 0) {
    if (g[v].empty()) return;
    int to = g[v][0];
//    cout << "frt " << v << ' ' << to << '\n';
//    if (to == pr && order.empty()) {
//        cout << "EMPTY " << v << '\n';
//    }
    if (to == pr && !order.empty()) {
        int cur = order.back();
        order.pop_back();
        if (cur == v && !order.empty()) {
            int cur1 = cur;
            cur = order.back();
            order.pop_back();
            order.pb(cur1);
        }
        if (cur == v) {
            while (true) {}
            order.pb(cur);
        }
        else {
            if (!frt) frt = v;
            for (int i = 0; i < 10; i ++) {
                setHint(v, i + 1, ((cur >> i) & 1));
            }
//            cout << "| " << v << ' ' << cur << '\n';
        }
    }
    if (to != pr) {
        for (auto to1 : g[v]) {
            if (to1 == pr || to1 == to) continue;
            order.pb(to1);
//            cout << "ADD " << to1 << '\n';
        }
        for (auto to1 : g[v]) {
            if (to1 != pr) set_lazy_hint(to1, v);
        }
    }
}

void assignHints(int subtask, int n, int A[], int B[]) {
    for (int i = 1; i < n; i ++) {
        g[A[i]].pb(B[i]);
        g[B[i]].pb(A[i]);
    }
    setHintLen(20);
    dfs(1);
    set_lazy_hint(1);
    if (!frt) frt = 1;
    for (int i = 0; i < 10; i ++) {
        setHint(1, i + 10 + 1, ((frt >> i) & 1));
    }
}

void speedrun(int subtask, int n, int v) {
    if (n == 1) return;
    set <int> s;
    for (int i = 1; i <= n; i ++) {
        s.insert(i);
    }
    int mgo = 0;
    while (v != 1) {
        int pr = 0;
        for (int i = 19; i >= 10; i --) {
            pr *= 2;
            pr += getHint(i + 1);
        }
        v = pr;
        goTo(v);
    }
    int st = 0;
    for (int i = 19; i >= 10; i --) {
        st *= 2;
        st += getHint(i + 1);
    }
    while (v != st) {
        int to = 0;
        for (int i = 9; i >= 0; i --) {
            to *= 2;
            to += getHint(i + 1);
        }
        v = to;
        goTo(to);
    }
    while (true) {
        if (s.find(v) != s.end()) s.erase(v);
//        cout << v << '\n';
        int to = 0, pr = 0;
        for (int i = 9; i >= 0; i --) {
            to *= 2;
            to += getHint(i + 1);
        }
        for (int i = 19; i >= 10; i --) {
            pr *= 2;
            pr += getHint(i + 1);
        }
        if (v == 1) pr = 0;
//        cout << v << ' ' << to << ' ' << pr << '\n';
        bool can = (to && goTo(to) ? 1 : 0);
        if (can) goTo(v);
        if (to && s.find(to) != s.end() && can) {
//            cout << "down " << v << ' ' << to << '\n';
            v = to;
            goTo(v);
        }
        else if (mgo && goTo(mgo)) {
//            cout << "mgo " << v << ' ' << mgo << '\n';
            v = mgo;
            goTo(v);
            mgo = 0;
        }
        else if (pr == 0) break;
        else if (!can && to) {
//            cout << "smgo " << v << ' ' << to << '\n';
            mgo = to;
            v = pr;
            goTo(v);
        }
        else {v = pr; goTo(pr);}
    }
//    for (auto it : s) {
//        cout << it << ' ';
//    }
}

/*
8
1 2
1 7
2 3
2 6
3 4
4 5
4 8
1

10
1 2
1 3
3 4
3 5
3 6
4 7
4 8
6 9
6 10
6
*/
