/**
* user:  tanevski-dac
* fname: Marko
* lname: Tanevski
* task:  Gardening
* score: 11.0
* date:  2021-12-16 08:31:34.157491
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define pb push_back
#define fr first
#define sc second

vector <int> arr[7];
int vreme;
ll n, m, k;
void color(pair<int,int> start, pair<int,int> kraj)
{
    if (kraj.fr == start.fr or kraj.sc == start.sc)
    {
        return ;
    }
    vreme ++;
    for (int i=start.fr; i<kraj.fr; i++)
    {
        arr[i][start.sc] = vreme;
        arr[i][kraj.sc-1] = vreme;
    }
    for (int j=start.sc; j<kraj.sc; j++)
    {
        arr[start.fr][j] = vreme;
        arr[kraj.fr-1][j] = vreme;
    }
}

void normal(pair<int,int> start, pair<int,int> kraj)
{
    for (int i=start.fr; i<kraj.fr; i+=2)
    {
        for (int j=start.sc; j<kraj.sc; j+=2)
        {
            vreme++;
            arr[i][j] = vreme;
            arr[i+1][j] = vreme;
            arr[i][j+1] = vreme;
            arr[i+1][j+1] = vreme;
        }
    }
}

int main()
{
    int t;
    cin>>t;
    for (int i=0; i<7; i++)
    {
        arr[i].resize(200000);
    }
    while (t>0)
    {
        t--;
        vreme = 0;
        bool ok = false;
        cin>>n>>m>>k;
        if (n%2 ==1 or m%2==1)
        {
            cout<<"NO\n";
            continue;
        }
        if (n*m/4 < k)
        {
            cout<<"NO\n";
            continue;
        }
        if (n==2)
        {
            if (k == m/2)
            {
                normal({0,0},{n,m});
                ok = true;
            }
        }
        if (n==4)
        {
            for (int i=0; i<=m; i+=2)
            {
                if (i==2)
                {
                    continue;
                }
                if (k== i/2 + m - i)
                {
                    color({0,0}, {n, i});
                    normal({1,1}, {n-1,i-1});
                    normal({0, i}, {n, m});
                    ok = true;
                }
            }
        }
        if (ok)
        {
            cout<<"YES\n";
            for (int i =0; i<n; i++)
            {
                for (int j=0; j<m; j++)
                {
                    cout<<arr[i][j]<<" ";
                }
                cout<<"\n";
            }
            continue;
        }
        else
        {
            cout<<"NO\n";
        }
    }
}
