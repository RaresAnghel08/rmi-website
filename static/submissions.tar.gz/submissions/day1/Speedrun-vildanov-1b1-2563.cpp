/**
* user:  vildanov-1b1
* fname: Ruslan
* lname: Vildanov
* task:  Speedrun
* score: 52.0
* date:  2021-12-16 09:43:56.527343
*/
#include "speedrun.h"
#ifdef LOCAL
    //#define _GLIBCXX_DEBUG
#endif // LOCAL
#include <bits/stdc++.h>
using namespace std;

//#define int long long
#define f first
#define s second
#define endl '\n'


int k=31;
vector <int> num;

void sethint(int v, int u)
{
    for (int j=num[v]; j<num[v]+10; j++){
        setHint(v,j,(u>>(j-num[v]))%2);
    }
}

void assignHints(int gg, int n, int a[], int b[])
{

    if (gg==4){
        setHintLen(315);
        vector <vector <int> > g(n+1);
        for (int i=1; i<n; i++){
            int v=a[i];
            int u=b[i];
            g[v].push_back(u);
            g[u].push_back(v);
        }
        num.assign(n+1,2);
        for (int i=1; i<=n; i++){
            if (g[i].size()>k){
                setHint(i,1,1);
                continue;
            }
            for (int u:g[i]){
                sethint(i,u);
                num[i]+=10;
            }
        }
        return;
    }
    if (gg==3){
        setHintLen(20);
        vector <vector <int> > g(n+1);
        for (int i=1; i<n; i++){
            int v=a[i];
            int u=b[i];
            g[v].push_back(u);
            g[u].push_back(v);
        }
        num.assign(n+1,1);
        for (int i=1; i<=n; i++){
            for (int u:g[i]){
                sethint(i,u);
                num[i]+=10;
            }
        }
        return;
    }
    setHintLen(n);
    for (int i=1; i<n; i++){
        int v=a[i];
        int u=b[i];
        setHint(v,u,1);
        setHint(u,v,1);
    }
}
vector <int> used;
int n;
void dfs(int v)
{
    used[v]=1;
    for (int u=1; u<=n; u++){
        if (!getHint(u))continue;
        if (used[u])continue;
        goTo(u);
        dfs(u);
        goTo(v);
    }
}

int get(int l, int r)
{
    int ans=0;
    for (int i=r; i>=l; i--){
        ans*=2;
        ans+=getHint(i);
    }
    return ans;
}

void dfs4(int v)
{
    used[v]=1;
    vector <int> g;
    for (int i=0; i<2; i++){
        int u=get(1+i*10,1+i*10+9);
        if (u==0)break;
        g.push_back(u);
    }
    for (int u:g){
        if (used[u])continue;
        if (goTo(u)){
            dfs4(u);
            goTo(v);
        }
    }
}


void dfsk(int v)
{
    used[v]=1;
    vector <int> g;
    if (getHint(1)){
        for (int u=1; u<=n; u++){
            if (used[u])continue;
            if (goTo(u)){
                dfsk(u);
                goTo(v);
            }
        }
    }
    else {
        for (int i=0; i<k; i++){
            int u=get(2+i*10,2+i*10+9);
            if (u==0)break;
            g.push_back(u);
        }
        for (int u:g){
            //cout << "v,u: " << v << " " << u << endl;
            if (used[u])continue;
            if (goTo(u)){
                dfsk(u);
                goTo(v);
            }
        }
    }
}

void speedrun(int gg, int N, int s)
{
    n=N;
    if (gg==4){
        used.assign(N+1,0);
        dfsk(s);
        return;
    }
    if (gg==3){
        used.assign(N+1,0);
        dfs4(s);
        return;
    }
    used.assign(n+1,0);
    dfs(s);
}

/**
size(n);

1,
2,
3,
6,
9,
16,
29,
54,
87,
138,
317,
404,
1017,
1566,
1971,
4566,
10041,
13732,
33713,
39246,
60383,
149342,
315905,
356036,
684169,
1570362
*/
