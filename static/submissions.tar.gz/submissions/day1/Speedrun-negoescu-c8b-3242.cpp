/**
* user:  negoescu-c8b
* fname: Divia Petra
* lname: Negoescu
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:48:28.722159
*/
#include <fstream>
//#include <iostream>
#include <map>
#include <set>
//#include "speedrun.h"
using namespace std;
ifstream cin("a.in");
ofstream cout("a.out");

static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;

void setHintLen(int l) {
    if (length_set) {
       // cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
       // cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() {
    return length; }

bool getHint(int j) {
    return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    setHintLen(n);
    for(int i=1;i<n;i++){
        setHint(A[i],B[i],1);
        setHint(B[i],A[i],1);
    }
    return;
}

void speedrun(int subtask, int N, int start) { /* your solution here */
    if(viz.size()==n) exit();
    if(queries==2*n) exit();
    for(int i=1;i<=n;i++){
        if(start!=i && viz.find(i)==end(viz) && getHint(i)){
            goTo(i);
            speedrun(subtask, start, i);
            goTo(start);
        }
    }
}


int main(){
    int N;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(1, N, a, b);

    /*if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }*/

    cin >> current_node;
    viz.insert(current_node);

    speedrun(1, N, current_node);

   /* if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;
*/


    return 0;
}
