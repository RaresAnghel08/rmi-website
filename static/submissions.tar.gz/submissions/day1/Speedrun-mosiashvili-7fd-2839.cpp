/**
* user:  mosiashvili-7fd
* fname: Luka
* lname: Mosiashvili
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:10:58.067666
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;
int a,b,c,d,e,i,j,ii,jj,zx,xc,L,fx[1009];
vector <int> v[1009];
void assignHints(int subtask, int NN, int AA[], int BB[]) {
	a=NN;
	for(i=1; i<a; i++){
		v[AA[i]].push_back(BB[i]);
		v[BB[i]].push_back(AA[i]);
	}
	L=a;
	setHintLen(L);
	for(i=1; i<=a; i++){
		for(vector <int>::iterator it=v[i].begin(); it!=v[i].end(); it++){
			fx[(*it)]=i;
		}
		for(j=1; j<=a; j++){
			if(fx[j]==i){
				setHint(i,j,1);
			}else{
				setHint(i,j,0);
			}
		}
	}
}
void dfs(int q, int w){
	for(int h=1; h<=a; h++){
		if(h==w) continue;
		c=getHint(h);
		if(c==1){
			goTo(h);
			dfs(h,q);
		}
	}
	if(w!=0) goTo(w);
}
void speedrun(int subtask, int NN, int start) {
	a=NN;L=getLength();
	dfs(start,0);
}
