/**
* user:  garkov-315
* fname: Velislav Petrov
* lname: Garkov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:59:13.662679
*/
#include <iostream>
using namespace std;
const int MAXN=2e5+10;
int res[4][MAXN];
int main () {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int t;
    cin >> t;
    int n, m, k;
    for (int test=0;test<t;test++) {
        cin >> n >> m >> k;
        if (n%2==1 || m%2==1) {
            cout << "NO\n";
            continue;
        }
        if (min(n,m)==2) {
            if (k!=max(n,m)/2) cout << "NO\n";
            else {
                cout << "YES\n";
                for (int j=1;j<=2;j++) {
                    for (int i=1;i<=max(n,m)/2;i++) cout << i << ' ' << i << ' ';
                    cout << endl;
                }
            }
            continue;
        }
        int ans=-1, s;
        for (int i=0;i<=m;i+=2) {
            if (i==2) continue;
            s=i/2+m-i;
            if (s==k) {
                ans=i;
                break;
            }
        }
        if (ans==-1) cout << "NO\n";
        else {
            cout << "YES\n";
            int maxs=0;
            for (int i=0;i<4;i++) {
                for (int j=0;j<ans;j++) {
                    if (i==0 || i==3) res[i][j]=1;
                    else {
                        if (j==0 || j==ans-1) res[i][j]=1;
                        else res[i][j]=(j+1)/2+1;
                    }
                    maxs=max(maxs,res[i][j]);
                }
            }
            maxs++;
            for (int i=ans;i<m;i+=2) {
                res[0][i]=res[1][i]=res[0][i+1]=res[1][i+1]=maxs;
                maxs++;
            }
            for (int i=ans;i<m;i+=2) {
                res[2][i]=res[3][i]=res[2][i+1]=res[3][i+1]=maxs;
                maxs++;
            }
            for (int i=0;i<n;i++) {
                for (int j=0;j<m;j++) cout << res[i][j] << ' ';
                cout << endl;
            }
        }
    }
    return 0;
}
