/**
* user:  lifar-7f1
* fname: Egor
* lname: Lifar
* task:  restore
* score: 100.0
* date:  2019-10-10 07:12:48.664858
*/
#include <bits/stdc++.h>

using namespace std;
template<class A, class B> inline void chkmin(A &a, B b){ a = (a > b ? b: a);}
template<class A, class B> inline void chkmax(A &a, B b){ a = (a < b ? b: a);}
#define all(c) (c).begin(), (c).end()
#define sz(c) (int)(c).size()
#define pb push_back
#define mp make_pair
using ll = long long;
using ld = long double;
const int MAXN = 5005;


int n, m;
vector<pair<int, int> > g[MAXN], rg[MAXN], f[MAXN], rf[MAXN];
int s[MAXN];
int s1[MAXN];
int ls[MAXN], rs[MAXN];



void addsm(int l, int r, int val) {
	g[l].pb({r, val});
	rg[r].pb({l, val});
}

void addbi(int l, int r, int val) {
	f[l].pb({r, val});
	rf[r].pb({l, val});
}


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	//freopen("input.in", "r", stdin);
	cin >> n >> m;
	for (int it = 0; it < m; it++) {
		int l, r, k, val;
		cin >> l >> r >> k >> val;
		l++;
		r++;
		if (val == 1) {
			addsm(l - 1, r, k - 1);
		} else {
			addbi(l - 1, r, k);
		}
	}
	for (int i = 0; i < n; i++) {
		addsm(i, i + 1, 1);
		addbi(i, i + 1, 0);
	}
	for (int i = 1; i <= n + 1; i++) {
		s1[i] = 1e9;
		rs[i] = 1e9;
		ls[i] = 0;
	}
	ls[0] = 0;
	rs[0] = 0;
	for (int i = 0; i <= n; i++) {
		for (int j = n; j >= i; j--) {
			for (auto x: f[j]) {
				int jj =x.first;
				int val = x.second;
				//j >= i + val;
				//i <= j - val
				chkmin(rs[j], rs[jj] - val);
			}
			for (auto x: g[j]) {
				int jj =x.first;
				int val = x.second;
				//j <= i + val;
				//i >= j - val;
				chkmax(ls[j], ls[jj] - val);
			}
		}
		s1[i] = ls[i];
		rs[i] = ls[i];
		for (int j = i; j <= n; j++) {
			for (auto x: f[j]) {
				int jj =x.first;
				int val = x.second;
				//j >= i + val;
				//i <= j - val
				chkmax(ls[jj], ls[j] + val);
			}
			for (auto x: g[j]) {
				int jj =x.first;
				int val = x.second;
				//j <= i + val;
				//i >= j - val;
				chkmin(rs[jj], rs[j] + val);
			}
		}
	}
	for (int i = 0; i <= n; i++) {
		for (auto x: f[i]) {
			if (s1[x.first] < s1[i] + x.second) {
				cout << -1 << endl;
				exit(0);
			}
		}
		for (auto x: g[i]) {
			if (s1[x.first] > s1[i] + x.second) {
				cout << -1 << endl;
				exit(0);
			}
		}
		if (i < n) {
			if (s1[i + 1] -s1[i] != 1 && s1[i + 1] -s1[i] != 0) {
				cout << -1 << endl;
				exit(0);
			}
		}
	}
	for (int i = 0; i < n; i++) {
		cout << 1 - (s1[i + 1] - s1[i]) << ' ';
	}
	cout << '\n';
	return 0;
}