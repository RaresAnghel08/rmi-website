/**
* user:  gasan-03e
* fname: Carol Luca
* lname: Gasan
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:29:01.173902
*/
#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int q;
    cin>>q;
    cin>>n;
    int cnt=0;
    for(int i=1;i<=n;++i)
    {
        int c=i;
        int last=0;
        bool ok=0;
        while(c>0 and ok==0)
        {
            if(last==1 and c%10==3)
                ok=1;
            last=c%10;
            c/=10;
        }
        if(ok==1)
            cnt++;
    }
    cout<<n-cnt+1;
    return 0;
}
