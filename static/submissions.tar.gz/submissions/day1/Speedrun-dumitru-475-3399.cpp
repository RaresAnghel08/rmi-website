/**
* user:  dumitru-475
* fname: Matei
* lname: Dumitru
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:01:52.554476
*/
#include "speedrun.h"
#include <bits/stdc++.h>

void assignHints(int subtask, int N, int A[], int B[])
{
    if (subtask == 1)
    {
        bool mat[1001][1001];
        int save, cs, i, j;
        for (i = 1; i <= N - 1; i++)
            mat[a[i]][b[i]] = mat[b[i]][a[i]] = 1;
        for (i = 1; i <= N; i++)
            for (j = 1; j <= N; j++)
                setHint(i, j, mat[i][j]);
    }
}

void speedrun(int subtask, int N, int start)
{
    if (subtask == 1)
    {
        int p, ok;
        for (int i = 1; i <= N; i++)
        {
            if (getHint(i) == 1)
            {
                ok = 1;
                goTo(i);
            }
        }
    }
}
