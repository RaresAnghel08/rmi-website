/**
* user:  stoyanov-19a
* fname: Boris
* lname: Stoyanov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:37:53.535309
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,k,x[10],sum=0;
    int a[1000010];
    cin>>n;
    int ind;
    for(int i=0; i<n; i++)
    {
        cin>>k;
        ind =0;
        sum=0;
        memset(a,0,sizeof(a));
        for(int j=1; j<=9; j++)
        {
            cin>>x[j];
            sum+=x[j];
            for(int q=0; q<x[j]; q++)
            {
                a[ind]=j;
                ind++;
            }

        }
        /**cout<<ind<<endl;
        for(int j=0;j<ind;j++)
        {
            cout<<a[j]<<' ';
        }*/
        int s=x[a[ind-2]];
        if(a[ind-2]==a[ind-1])
        {
            if(sum-1>s*2-2 )
            {
                ///cout<<"!\n";
                for(int j=0; j<s-1; j++)
                {
                    cout<<a[ind-2]<<a[j];
                }
                for(int j=s;; j++)
                {
                    if(a[j]==a[ind-2])break;
                    cout<<a[j];
                }
                cout<<a[s-1]<<a[ind-1]<<endl;
            }
            else
            {
                ///cout<<"!!\n";
                for(int j=0; j<sum-s; j++)
                {
                    cout<<a[ind-2]<<a[j];
                }
                for(int j=sum-s; j<ind-sum+s; j++)
                {
                    cout<<a[j];
                }
            }
        }
        else
        {
            if(sum-1>s*2 )
            {
                ///cout<<"!!!\n";
                for(int j=0; j<s; j++)
                {
                    cout<<a[ind-2]<<a[j];
                }
                for(int j=s+1;; j++)
                {
                    if(a[j]==a[ind-2])break;
                    cout<<a[j];
                }
                cout<<a[s]<<a[ind-1]<<endl;
            }
            else
            {
                ///cout<<"!!!!\n";
                for(int j=0; j<sum-2-s; j++)
                {
                    cout<<a[ind-2]<<a[j];
                }
                for(int j=sum-1-s; j<ind-sum+1+s; j++)
                {
                    cout<<a[j];
                }
                cout<<a[sum-2-s]<<a[ind-1]<<endl;
            }
        }
    }
    return 0;
}
/**
2
2
1 1 1 2 2 0 0 4 1
2
1 1 1 1 1 0 0 9 1
*/
