/**
* user:  budnikov-2df
* fname: Mikhail
* lname: Budnikov
* task:  lucky
* score: 28.0
* date:  2019-10-10 08:31:06.619195
*/
#include <bits/stdc++.h>
#define all(x) begin(x), end(x)
typedef long long ll;
typedef long double ld;
using namespace std;

const int N = 1.1e5;
const int M = 1e9 + 7;
int n, q;
ll dp[N][2][2];
int a[N];

int main() {
#ifdef LC
	assert(freopen("input.txt", "r", stdin));
#endif
	ios::sync_with_stdio(0);
	cin.tie(0);
	cin >> n >> q;
	string input;
	cin >> input;
	assert((int)input.size() == n);
	for (int i = 0; i < n; ++i) {
		a[i] = input[i] - '0';
	}
	dp[0][0][0] = 1;
	dp[0][0][1] = 0;
	dp[0][1][0] = 0;
	dp[0][1][1] = 0;
	dp[1][0][0] = a[0] != 1;
	dp[1][0][1] = a[0] == 1;
	dp[1][1][0] = max(0, a[0] - (a[0] != 1));
	dp[1][1][1] = a[0] > 1;
	for (int i = 2; i <= n; ++i) {
		int d = a[i - 1];
		// place 1
		if (d > 1) {
			dp[i][1][1] += dp[i - 1][0][0] + dp[i - 1][0][1] + dp[i - 1][1][0] + dp[i - 1][1][1];
		} else if (d == 1) {
			dp[i][0][1] += dp[i - 1][0][0] + dp[i - 1][0][1];
			dp[i][1][1] += dp[i - 1][1][0] + dp[i - 1][1][1];
		} else {
			dp[i][1][1] += dp[i - 1][1][0] + dp[i - 1][1][1];
		}
		// place 3
		if (d > 3) {
			dp[i][1][0] += dp[i - 1][0][0] + dp[i - 1][1][0];
		} else if (d == 3) {
			dp[i][0][0] += dp[i - 1][0][0];
			dp[i][1][0] += dp[i - 1][1][0];
		} else {
			dp[i][1][0] += dp[i - 1][1][0];
		}
		// place not 1 & not 3
		for (int j = 0; j <= 9; ++j) {
			if (j == 1 || j == 3) {
				continue;
			}
			if (d > j) {
				dp[i][1][0] += dp[i - 1][0][0] + dp[i - 1][0][1] + dp[i - 1][1][0] + dp[i - 1][1][1];
			} else if (d == j) {
				dp[i][0][0] += dp[i - 1][0][0] + dp[i - 1][0][1];
				dp[i][1][0] += dp[i - 1][1][0] + dp[i - 1][1][1];
			} else {
				dp[i][1][0] += dp[i - 1][1][0] + dp[i - 1][1][1];
			}
		}
		dp[i][0][0] %= M;
		dp[i][0][1] %= M;
		dp[i][1][0] %= M;
		dp[i][1][1] %= M;
	}
	ll answer = dp[n][0][0] + dp[n][0][1] + dp[n][1][0] + dp[n][1][1];
	answer %= M;
	cout << answer << "\n";
	return 0;
}
