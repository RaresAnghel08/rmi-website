/**
* user:  dobleaga-e29
* fname: Alexandru
* lname: Dobleaga
* task:  Present
* score: 8.0
* date:  2021-12-16 11:01:20.829256
*/
#include <bits/stdc++.h>

using namespace std;

constexpr int KMAX = 105;
vector <int> V[KMAX];

bool Good (vector <int> aux) {
    map <int, bool> mp;
    for (auto it : aux)
        mp[it] = 1;

    for (int i = 0; i < aux.size(); ++ i ) {
        for (int j = 0; j < aux.size(); ++ j ) {
            int val = __gcd(aux[i], aux[j]);

            if (mp[val] == 0) return 0;
        }
    }

    return 1;
}

void Precalculare () {
    int ind = 0;
    for (int val = 1; val <= KMAX && ind < KMAX-1; ++ val ) {
        int aux_ind = ind;
        for (int i = 0; i <= aux_ind && ind < KMAX-1; ++ i ) {
            vector <int> can;
            for (auto it : V[i])
                can.push_back(it);
            can.push_back(val);

            if (Good(can))
                V[++ind] = can;
        }
    }
}

void Do_Testcase () {
    int K;
    cin >> K;

    cout << V[K].size() << " ";
    for (auto it : V[K])
        cout << it << " ";
    cout << '\n';
}

int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T = 1;
    cin >> T;

    Precalculare();

    for (; T; -- T ) {
        Do_Testcase();
    }

    return 0;
}
