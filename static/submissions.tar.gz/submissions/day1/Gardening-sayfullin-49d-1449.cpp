/**
* user:  sayfullin-49d
* fname: Iskandar
* lname: Sayfullin
* task:  Gardening
* score: 5.0
* date:  2021-12-16 07:57:10.050870
*/
#include <bits/stdc++.h>

using namespace std;

vector <int> f(int n, int k) {
    vector<int> ans(n);

    int cur_val = 1, n2 = n / 2;
    for (int j = 0; j < n2; j++) {
        ans[j] = cur_val;
        if (cur_val < k) cur_val++;
    }

    cur_val = 1;
    for (int j = n - 1; j >= n2; j--) {
        ans[j] = cur_val;
        if (cur_val < k) cur_val++;
    }

    return ans;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int t, n, m, k;
    cin >> t;

    for (int g = 0; g < t; g++) {
        cin >> n >> m >> k;

        if (n % 2 || m % 2) cout << "NO\n";
        else if (n <= 4 && m <= 4) {
            if (n == 2 && m == 2 && k == 1) {
                cout << "YES\n1 1\n1 1\n";
            } else if (n == 2 && m == 4 && k == 2) {
                cout << "YES\n1 1 2 2\n1 1 2 2\n";
            } else if (n == 4 && m == 2 && k == 2) {
                cout << "YES\n1 1\n1 1\n2 2\n2 2\n";
            } else if (n == 4 && m == 4 && k == 4) {
                cout << "YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";
            } else if (n == 4 && m == 4 && k == 2) {
                cout << "YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
            } else {
                cout << "NO\n";
            }
        } else if (n * m == k * 4) {
            cout << "YES\n";
            int f = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    cout << 1 + j / 2 + f << ' ';
                }
                if (i % 2) f += m / 2;
                cout << '\n';
            }
        } else if (n == m && n == 2 * k) {
            cout << "YES\n";

            vector <int> a = f(n, k);
            for (int i = 0; i < n; i++) {
                for (int j : f(n, a[i])) {
                    cout << j << ' ';
                }
                cout << '\n';
            }
        } else {
            cout << "NO\n";
        }
    }

    return 0;
}