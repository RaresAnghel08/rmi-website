/**
* user:  bekkoyonov-7fa
* fname: Tengiz
* lname: Bekkoyonov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:05:04.299316
*/
#include "speedrun.h"
#ifndef EVAL
#include "grader.cpp"
#endif
#include <bits/stdc++.h>
using namespace std;
const int n = 1005;
vector<int> e[n];
int par[n], nxt[n], child[n];

void dfs(int u, int p) {
    par[u] = p;
    int lst = -1;
    for (int v : e[u]) {
        if (v != p) {
            if (lst == -1) {
                child[u] = v;
                lst = v;
            } else {
                nxt[lst] = v;
            }
            dfs(v, u);
        }
    }
}
void assignHints(int subtask, int N, int A[], int B[]) {
    for (int i = 1; i < N; i++) {
        e[A[i]].push_back(B[i]);
        e[B[i]].push_back(A[i]);
    }
    memset(par, -1, sizeof par);
    memset(nxt, -1, sizeof nxt);
    fill(child, child + n, 1);
    dfs(1, -1);
    setHintLen(30);
    for (int i = 1; i <= N; i++) {
        for (int j = 0; j < 10; j++) {
            setHint(i, j, nxt[i] >> j & 1);
            setHint(i, j + 10, child[i] >> j & 1);
            setHint(i, j + 20, par[i] >> j & 1);
        }
    }
    // for (int i = 1; i <= N; i++) {
        // cout << child[i] << " " << nxt[i] << "\n";
    // }
}

int find(int u, int p) {
    // cout << u << " " << p << "\n";
    int v = 0, nxt = 0;
    for (int j = 0; j < 10; j++) {
        v |= getHint(j + 10) << j;
        nxt |= getHint(j) << j;
    }
    // cout << v << " " << nxt << "\n";
    if (v == 1) {
        goTo(p);
        return nxt;
    }
    goTo(v);
    int t = find(v, u);
    while (t != 1023) {
        goTo(t);
        t = find(t, u);
    }
    goTo(p);
    return nxt;
}
void speedrun(int subtask, int N, int start) {
    int s = start;
    while (s != 1) {
        int c = 0;
        for (int j = 0; j < 10; j++) {
            c |= getHint(j + 20) << j;
        }
        assert(goTo(c));
        s = c;
    }
    find(1, 1);
}

/*


5
1 2
1 5
2 3
2 4
2







*/
