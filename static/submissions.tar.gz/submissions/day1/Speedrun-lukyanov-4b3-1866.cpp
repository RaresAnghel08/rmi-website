/**
* user:  lukyanov-4b3
* fname: Igor
* lname: Lukyanov
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 08:35:24.541433
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;

const int NMAX=1e3;
vector<int>g[NMAX+5];

void assignHints(int subtask, int N, int A[], int B[]) {
    // SUBTASK 1
    if(subtask==1){
        //cout<<"IN ASSIGN HINTS"<<endl;
        for(int i=1;i<N;i++){
            int a=A[i];
            int b=B[i];
            //cout<<"EDGE "<<a<<" "<<b<<endl;
            g[a].push_back(b);
            g[b].push_back(a);
        }
        setHintLen(N);
        for(int i=1;i<=N;i++){
            for(auto ii:g[i]){
                setHint(i,ii,1);
            }
        }
        //cout<<"END ASSIGN HINTS"<<endl;
    }
    // SUBTASK 2
    if(subtask==2){
        for(int i=1;i<N;i++){
            int a=A[i];
            int b=B[i];
            g[a].push_back(b);
            g[b].push_back(a);
        }
        setHintLen(15);
        int center=0;
        for(int i=1;i<=N;i++){
            if(g[i].size()==N-1){
                center=i;
                break;
            }
        }
        //cout<<"HINT CENTER="<<center<<"\n";
        for(int i=1;i<=N;i++){
            for(int bit=1;bit<=15;bit++){
                setHint(i,bit,(center>>(bit-1))&1);
            }
        }
    }
    // SUBTASK 3
    if(subtask==3){
        for(int i=1;i<N;i++){
            int a=A[i];
            int b=B[i];
            g[a].push_back(b);
            g[b].push_back(a);
        }
        setHintLen(20);
        for(int i=1;i<=N;i++){
            int left,right;
            if(g[i].size()==1){
                left=g[i][0]-1;
                right=i-1;
            }else{
                left=g[i][0]-1;
                right=g[i][1]-1;
            }
            for(int bit=10;bit>=1;bit--){
                setHint(i,bit+10,(left>>(bit-1))&1);
            }
            for(int bit=10;bit>=1;bit--){
                setHint(i,bit,(right>>(bit-1))&1);
            }
        }
    }
}

void dfs1(int v,int l,int p=-1){
    for(int i=1;i<=l;i++){
        bool bit=getHint(i);
        if(bit&&i!=p){
            goTo(i);
            dfs1(i,l,v);
        }
    }
    if(p!=-1)goTo(p);
}
void dfs2(int v,int p=-1){
    int left=0,right=0;
    for(int bit=10;bit>=1;bit--)left<<=1,left+=getHint(bit+10);
    left++;
    for(int bit=10;bit>=1;bit--)right<<=1,right+=getHint(bit);
    right++;
    if(left!=p&&left!=v){
        goTo(left);
        dfs2(left,v);
    }
    if(right!=p&&right!=v){
        goTo(right);
        dfs2(right,v);
    }
    if(p!=-1)goTo(p);
}
void speedrun(int subtask, int N, int start) {
    // SUBTASK 1
    if(subtask==1){
        int len=getLength();
        dfs1(start,len,-1);
    }
    // SUBTASK 2
    if(subtask==2){
        int len=getLength();
        int center=0;
        for(int i=1;i<=len;i++)center<<=1,center+=getHint(len-i+1);
        if(start!=center)goTo(center);
        //cout<<"START="<<start<<" CENTER="<<center<<"\n";
        for(int i=1;i<=N;i++){
            if(i==center)continue;
            goTo(i);
            goTo(center);
        }
    } 
    // SUBTASK 3
    if(subtask==3){
        dfs2(start,-1);
    }
}
