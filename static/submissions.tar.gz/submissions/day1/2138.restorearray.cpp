/**
* user:  craciun-5f9
* fname: Mihai
* lname: Crăciun
* task:  restore
* score: 0.0
* date:  2019-10-10 08:35:54.151893
*/
#include <bits/stdc++.h>

using namespace std;

struct cer  {
    int l, r, k, val;
};

const int MaxM = 1e4 + 5;

cer v[MaxM];
int n, m;

const int maxn = 5e3 + 5;

int a[maxn];

int main()  {
    cin >> n >> m;
    for(int i = 1;i <= n;i++)
        a[i] = -1;
    for(int i = 1;i <= m;i++)  {
        cin >> v[i].l >> v[i].r >> v[i].k >> v[i].val;
        v[i].l++, v[i].r++;
        if(v[i].k == 1)  {
            if(v[i].val == 1)  {
                for(int j = v[i].l;j <= v[i].r;j++)  {
                    if(a[j] == 0)  {
                        cout << "-1";
                        return;
                    }
                    a[j] = 1;
                }
            }
            else  {
                bool ok = 1;
                for(int j = v[i].l;j <= v[i].r;j++)  {
                    if(a[j] != 1)  {
                        ok = 0;
                    }
                }
                if(ok == 1)  {
                    cout << "-1";
                    return 0;
                }
            }
        }
        else  {
            if(v[i].val == 0)  {
                for(int j = v[i].l;j <= v[i].r;j++)  {
                    if(a[j] == 1)  {
                        cout << "-1";
                        return 0;
                    }
                    a[j] = 0;
                }
            }
            else  {
                bool ok = 1;
                for(int j = v[i].l;j <= v[i].r;j++)  {
                    if(a[j] != 0)  {
                        ok = 0;
                    }
                }
                if(ok == 1)  {
                    cout << "-1";
                    return 0;
                }
            }

        }
    }
    for(int i = 1;i <= n;i++)  {
        if(a[i] == -1)
            cout << "0 ";
        else
            cout << "1 ";
    }
    return 0;
}
