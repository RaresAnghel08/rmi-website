/**
* user:  slanina-aed
* fname: Iulia
* lname: Slănină
* task:  devil
* score: 14.0
* date:  2019-10-10 07:19:28.462700
*/
#include <iostream>

using namespace std;
long long v[10],n,sol[1000005],vv[15],vvv[15],mini=2134567894567,k,put,vc[15];
int v1[5],v2[5],v3[5],v4[5];
int main()
{
    int t,h,tip=0,i,j,p=0,c,r;
    cin>>t;
    for (h=1;h<=t;h++)
    {
        cin>>k;
        n=0;
        for (i=1;i<=9;i++)
        {
            cin>>v[i];
            n+=v[i];
        }
        p=n;
        if (k==2)
        {
            i=1;
            j=9;
            while (p>1)
            {
                while (v[i]==0)
                    i++;
                while (v[j]==0)
                    j--;
                sol[p]=j;
                sol[p-1]=i;
                v[j]--;
                v[i]--;
                p-=2;
            }
            if (p==1)
            {
                while (v[i]==0)
                    i++;
                sol[p]=i;
            }
        }
        else
        {
int         ok=0;
            for (i=5;i<=9&&ok;i++)
                if (v[i]!=0)
                ok=1;
            if (ok==0)
            {
                if (v[3]==0&&v[4]==0)
                    tip=3;
                else
                {
                    for (i=1;i<=4;i++)
                        if (v[i]>3)
                            ok=1;
                    if (ok==0)
                        tip=1;
                }
            }
            if (tip==3)
            {
                if (v[2]<k)
                {
                    for (i=n;i>=n-v[2]+1;i--)
                        sol[i]=2;
                    for (i=1;i<n-v[2]+1;i++)
                        sol[i]=1;
                }
                else
                if (v[2]>=k)
                {
                    for (i=n;i>n-k+1;i--)
                        sol[i]=2;
                    v[2]-=(k-1);
                    if (v[1])
                    {
                        sol[n-k+1]=1;
                        v[1]--;
                        c=v[1]/(v[2]-1);
                        r=v[1]-c*(v[2]-1);
                        i=n-k+1;
                        while (i>=1)
                        {
                            for (j=i;j>i-c;j--)
                                sol[j]=1;
                            i=i-c;
                            if (r)
                            {
                                r--;
                                sol[i]=1;
                                i--;
                            }
                            sol[i]=2;
                            i--;
                        }
                    }
                    else
                    {
                        for (i=1;i<=n-k+1;i++)
                            sol[i]=2;
                    }

                }
            }
        }
        for (i=1;i<=n;i++)
            cout<<sol[i];
        cout<<'\n';
    }
    return 0;
}
