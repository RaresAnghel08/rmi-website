/**
* user:  savkin-047
* fname: Semen
* lname: Savkin
* task:  restore
* score: 7.0
* date:  2019-10-10 08:37:26.964070
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <algorithm>
#include <queue>
#include <deque>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <string>
#include <cstring>
#include <numeric>
#include <cassert>
#include <cmath>
#include <random>
#define ll long long
#define ld long double
#define null NULL
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()

using namespace std;

template<class iterator> void output(iterator begin, iterator end, ostream &out = cerr) {
	while (begin != end) {
		out << (*begin) << " ";
		begin++;
	}
	out << endl;
}

template<class T> void output(const T &x, ostream &out = cerr) {
	output(x.begin(), x.end(), out);
}

template<class T> int chkmin(T &a, const T &b) {
	if (b < a) {
		a = b;
		return 1;
	}
	return 0;
}

template<class T> int chkmax(T &a, const T &b) {
	if (b > a) {
		a = b;
		return 1;
	}
	return 0;
}

void fast_io() {
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
}

const int mx = 20;
const int M = 300;
int n, m, a[mx], pref[mx + 1], l1[M], r1[M], l2[M], r2[M];

signed main() {
	fast_io();
	cin >> n >> m;
	for (int i = 0; i < m; ++i) {
		int l, r, k, value;
		cin >> l >> r >> k >> value;
		l1[i] = l;
		r1[i] = r;
		if (value == 0) {
			l2[i] = 0;
			r2[i] = r - l + 1 - k;
		}
		else {
			l2[i] = r - l + 1 - k + 1;
			r2[i] = r - l + 1;
		}
		//cerr << l1[i] << " " << r1[i] << " " << l2[i] << " " << r2[i] << endl;
	}
	//cerr << "---" << endl;
	for (int sub = 0; sub < (1 << n); ++sub) {
		for (int i = 0; i < n; ++i) {
			a[i] = ((sub >> i) & 1);
		}
		for (int i = 0; i < n; ++i) {
			pref[i + 1] = pref[i] + a[i];
		}
		int ok = 1;
		//cerr << "yo" << endl;
		for (int i = 0; i < m; ++i) {
			int sum = pref[r1[i] + 1] - pref[l1[i]];
			//cerr << "sum = " << sum << endl;
			if (!(l2[i] <= sum && sum <= r2[i])) {
				ok = 0;
				break;
			}
		}
		if (ok) {
			/*for (int j = 0; j <= n; ++j) {
				cerr << pref[j] << " ";
			}
			cerr << endl;*/
			for (int j = 0; j < n; ++j) {
				cout << a[j] << " ";
			}
			cout << endl;
			exit(0);
		}
	}
	cout << -1 << endl;
}
