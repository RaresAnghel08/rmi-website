/**
* user:  casarin-a22
* fname: Filippo
* lname: Casarin
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:48:21.618559
*/
#include "speedrun.h"
#include <functional>
#include <vector>

static void setChild(int v, int s) {
	for (int i{}; i < 10; ++i) setHint(v + 1, 1 + i, s >> i & 1);
}

static void setSibling(int v, int s) {
	for (int i{}; i < 10; ++i) setHint(v + 1, 11 + i, s >> i & 1);
}

static size_t getChild() {
	size_t c{};
	for (int i{}; i < 10; ++i) c |= getHint(1 + i) << i;
	return c;
}

static size_t getSibling() {
	size_t c{};
	for (int i{}; i < 10; ++i) c |= getHint(11 + i) << i;
	return c;
}

void assignHints(int, int N, int A[], int B[]) {
	setHintLen(20);

	std::vector<std::vector<int>> G(N);
	for (int i{1}; i < N; ++i) {
		G[A[i] - 1].push_back(B[i] - 1);
		G[B[i] - 1].push_back(A[i] - 1);
	}

	std::vector<uint8_t> V(N);
	std::function<void(size_t, size_t)> rec = [&](size_t v, size_t p) {
		V[v] = true;

		auto q = p;
		for (auto u : G[v])
			if (!V[u]) {
				rec(u, v);
				setSibling(u, q);
				q = u;
			}
		setChild(v, q);
	};

	rec(0, 0x3ff);
	setSibling(0, 0x3fe);
}

static size_t getParent(size_t v) {
	size_t c = getChild();
	size_t p = c;
	for (;;) {
		auto b = (c != 0x3ff) && goTo(c + 1);
		if (!b) return p;
		p = c;
		c = getSibling();
		goTo(v + 1);
	}
}

static size_t visit(size_t v, size_t p) {
	auto c = getChild();
	while (c != p) {
		goTo(c + 1);
		auto s = visit(c, v);
		c = s;
		goTo(v + 1);
	}
	return getSibling();
}

void speedrun(int, int N, int start) {
	if (N == 1) return;

	size_t v = start - 1;
	while (getSibling() != 0x3fe) {
		auto p = getParent(v);
		goTo(p + 1);
		v = p;
	}

	visit(0, 0x3ff);
}
