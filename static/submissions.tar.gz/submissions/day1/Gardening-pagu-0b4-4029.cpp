/**
* user:  pagu-0b4
* fname: Tudor Stefan
* lname: Pagu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:54:03.118477
*/
#include <bits/stdc++.h>
using namespace std;

ifstream in("in.in");
ofstream out("out.out");

int n,m,k,cnt;
vector<vector<int>> ans;
void input() {
    cin >> n >> m >> k;
    ans.resize(n + 1);
    for (int i = 1; i <= n; i++) ans[i].resize(m + 1);
}
void frame(int y1, int x1, int y2, int x2) {
    if (x1 > x2 || y1 > y2) return;

    cnt++;
    for (int i = y1; i <= y2; i++) {
        ans[i][x1] = ans[i][x2] = cnt;
    }

    for (int j = x1; j <= x2; j++) {
        ans[y1][j] = ans[y2][j] = cnt;
    }
}
void fullTile(int y1, int x1, int y2, int x2) {
    for (int i = y1; i <= y2 - 1; i += 2) {
        for (int j = x1; j <= x2 - 1; j += 2) {
            cnt++;
            ans[i][j] = ans[i + 1][j] = ans[i][j + 1] = ans[i + 1][j + 1] = cnt;
        }
    }
}
void printAns() {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            out << ans[i][j] << " ";
        }out << "\n";
    }
}
void solve4(int y1, int x1, int y2, int x2, int newK) {
 //   n = 4, m = 14;
  //  y1 = 1, y2 = 4, x1 = 1, x2 = 14,newK = 7;

    int len = x2 - x1 + 1,div;
    if (newK == len) div = x2;
    else div = x2 -  ( ( (len - 2) - newK + 1) * 2 + 2 );


    fullTile(y1, x1 , y2, div);
    frame(y1 , div + 1 , y2 , x2);
    fullTile(y1 + 1 , div + 2, y2 - 1, x2 - 1);
  //  printAns();
  //  out << "\n\n";
  //  cout << "\n";
}
bool solve6(int n, int m) {
    if (m == (n / 2) * 3) {

    }
}/*
void solve() {
    cnt = 0;
    //try framing
    if (n % 2 == 1 || m % 2 == 1) {
        out << "NO\n";
        return;
    }

    if (n >= 6) {
        for (int p = 0; p < m; p++) {
            if (checkSolve6(n, p) && checkSolve6(n, m - p)) {
                solve6(y)
            }
        }
    } else {
        if (n == 4) {
            if (m == k || (m / 2 <= k && k <= m - 2)) {
                out << "YES\n";
                solve4(1, 1, n, m, k);
                printAns();
            } else {
                out << "NO\n";
            }
        }
        else if (n == 2) {
            if (m / 2 == k) {
                out << "YES\n";
                fullTile(1,1,n,m);
                printAns();
            } else {
                out << "NO\n";
            }
        }
    }
}*/
void solve() {
    cout << "NO\n";
}
int main() {
    int t;
    //-------
    //ans = vector<vector<int>> (100 , vector<int>(100));
    //---------
   // solve4(0,0,0,0,0);
    cin >> t;
    while (t--) {
        input();
        solve();
    }
}