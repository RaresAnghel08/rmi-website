/**
* user:  mushkatin-6ef
* fname: Shirli
* lname: Mushkatin
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 10:07:46.760537
*/
﻿#include <iostream>
#include <vector>
#include <algorithm>
#include "speedrun.h"
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;

int bToInt() {
    int ans = 0;
    int mul = 1;
    for (int i = 11; i >= 2; i--) {
        ans += getHint(i) * mul;
        mul *= 2;
    }
    return ans;
}

void intToB(int v, int num) {
    for (int i = 11; i >= 2; i--) {
        setHint(v, i, num % 2);
        num /= 2;
    }
}

void adj(int v, int n, vi& visited) {
    visited[v] = 1;
    if (!getHint(1)) {
        int father = bToInt();
        goTo(father);
        adj(father, n, visited);
    }
    else {
        for (int j = 1; j <= n; j++) {
            if (j == v)
                continue;
            if (!visited[j]) {
                goTo(j);
                visited[j] = 1;
                goTo(v);
                //adj(j, n, visited);
                //goTo(v);
            }
        }
    }
}

void assignHints(int subtask, int N, int A[], int B[]) {
    int n = N;
    setHintLen(11);
    vvi adj(n + 1);
    for (int i = 1; i <= n - 1; i++) {
        int v = A[i], u = B[i];
        //setHint(v, u, 1);
        //setHint(u, v, 1);
        adj[A[i]].push_back(B[i]);
        adj[B[i]].push_back(A[i]);
    }
    for (int v = 1; v <= n; v++) {
        if (adj[v].size() == 1)
        {
            setHint(v, 1, 0);
            intToB(v, adj[v][0]);
        }
        else {
            setHint(v, 1, 1);
        }
    }
}

void speedrun(int subtask, int N, int start) {
    vi visited(N + 1);
    adj(start, N, visited);
}