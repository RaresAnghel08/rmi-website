/**
* user:  munduzbaev-bc3
* fname: Aidar
* lname: Munduzbaev
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 09:59:58.377739
*/
#include "speedrun.h"

#include "bits/stdc++.h"
using namespace std;

#ifndef EVAL
#include "grader.cpp"
#endif

void assignHints(int subtask, int n, int a[], int b[]) { /* your solution here */
	setHintLen(10);
	vector<int> nn(n + 1), cc(n + 1);
	for(int i=1;i<n;i++){
		nn[a[i]]++, nn[b[i]]++;
		cc[a[i]] = b[i], cc[b[i]] = a[i];
	}
	
	int star = 1;
	for(int i=1;i<=n;i++){
		if(nn[i] == 1) continue;
		star = i; break;
	} cc[star] = 0;
	
	for(int i=1;i<=n;i++){
		if(i == star) continue;
		for(int j=9;~j;j--){
			setHint(i, j + 1, cc[i] >> j & 1);
		}
	}
}

/*

5
1 2
2 3
3 4
4 5
3

*/

const int N = 1005;
int n;

void speedrun(int subtask, int n, int start) { /* your solution here */
	int star = 0;
	for(int j=0;j<10;j++){
		star |= (getHint(j + 1) << j);
	}
	
	if(!star) star = start;
	goTo(star);
	for(int i=1;i<=n;i++){
		goTo(i), goTo(star);
	}
}
