/**
* user:  ziganshin-48f
* fname: Emir Ramilevich
* lname: Ziganshin
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:51:20.456824
*/
#include <bits/stdc++.h>

using namespace std;

void solve();

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    solve();
}

const int K = 30, N = 2e5 + 100;

int t, n, m, k, dx[] = {-1, 1, 0, 0}, dy[] = {0, 0, -1, 1};
bool used[K][N];

void dfs(int x, int y, vector<vector<int>> &a) {
    used[x][y] = true;
    for (int i = 0; i < 4; i++) {
        int tx = x + dx[i];
        int ty = y + dy[i];
        if (tx >= 0 && tx < n && ty >= 0 && ty < m && !used[tx][ty] && a[x][y] == a[tx][ty]) {
            dfs(tx, ty, a);
        }
    }
}

bool check(vector<vector<int>> &a) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            used[i][j] = false;
        }
    }
    set<int> se;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (!used[i][j]) {
                if (se.count(a[i][j])) return false;
                dfs(i, j, a);
                se.insert(a[i][j]);
            }
            int cnt = 0;
            for (int h = 0; h < 4; h++) {
                int x = i + dx[h], y = j + dy[h];
                if (x >= 0 && x < n && y >= 0 && y < m && a[i][j] == a[x][y]) {
                    cnt++;
                }
            }
            if (cnt != 2) return false;
        }
    }
    return se.size() == k;
}

void solve() {
    vector<vector<int>> r1(K, vector<int>(N)), r2(K, vector<int>(N));
    cin >> t;
    while (t--) {
        cin >> n >> m >> k;
        if (n % 2 == 1 || m % 2 == 1) {
            cout << "NO" << '\n';
            continue;
        }
        if (n == 2) {
            if (m / 2 != k) {
                cout << "NO" << '\n';
            } else {
                cout << "YES" << '\n';
                int timer = 1;
                for (int i = 0; i < n; i += 2) {
                    for (int j = 0; j < m; j += 2) {
                        r1[i][j] = timer;
                        r1[i + 1][j] = timer;
                        r1[i][j + 1] = timer;
                        r1[i + 1][j + 1] = timer;
                        timer++;
                    }
                }
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < m; j++) {
                        cout << r1[i][j] << " ";
                    }
                    cout << '\n';
                }
            }
            continue;
        }
        if (n == 4 && (m < k || m / 2 > k || k == m - 1)) {
            cout << "NO" << '\n';
            continue;
        }
        int cnt = (m - k) * 2;
        cout << cnt << endl;
        int timer = 1;
        for (int j = 0; j < cnt; j++) {
            r1[0][j] = timer;
            r1[n - 1][j] = timer;
        }
        for (int i = 0; i < n; i++) {
            r1[i][0] = timer;
            r1[i][cnt - 1] = timer;
        }
        timer++;
        for (int i = 1; i < n - 1; i += 2) {
            for (int j = 1; j < cnt - 1; j += 2) {
                r1[i][j] = timer;
                r1[i + 1][j] = timer;
                r1[i][j + 1] = timer;
                r1[i + 1][j + 1] = timer;
                timer++;
            }
        }
        for (int i = 0; i < n; i += 2) {
            for (int j = cnt; j < m; j += 2) {
                r1[i][j] = timer;
                r1[i + 1][j] = timer;
                r1[i][j + 1] = timer;
                r1[i + 1][j + 1] = timer;
                timer++;
            }
        }
        cout << "YES" << '\n';
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                cout << r1[i][j] << " ";
            }
            cout << '\n';
        }
    }
}
