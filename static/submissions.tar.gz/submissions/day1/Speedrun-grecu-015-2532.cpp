/**
* user:  grecu-015
* fname: Tudor Stefan
* lname: Grecu
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:40:41.401123
*/

#include <iostream>
#include <vector>
#include <speedrun.h>

void assignHints( int subtask, int N, int A[], int B[] ) {
  if ( subtask == 1 ) {
    setHintLen( N );
    for ( int i = 1; i <= N; ++i ) {
      for ( int j = 1; j < N; ++j ) {
        if ( A[j] == i ) {
          setHint( i, B[j], true );
        } else if ( B[j] == i ) {
          setHint( i, A[j], true );
        }
      }
    }
    return;
  }

  /**
   A   B
    \ /
 F - X - C
    / \
   E   D
  **/

  if ( subtask == 2 ) { /// ai o stea

    return;
  }

  /**
  A - B - C - D
  **/

  if ( subtask == 3 ) { /// ai o linie

    return;
  }
}

const int MAXN = 1005;

bool use[MAXN];

void dfs( int N, int u, int p ) {
  use[u] = true;
  int l = getLength();
  for ( int v = 1; v <= l; ++v ) {
    if ( getHint( v ) == false ) continue;
    if ( !use[v] ) {
      goTo( v );
      dfs( N, v, u );
      goTo( u );
    }
  }
}

void speedrun( int subtask, int N, int start ) {
  if ( subtask == 1 ) {
    for ( int i = 1; i <= N; ++i ) use[i] = false;
    dfs( N, start, 0 );
    return;
  }
}

