/**
* user:  haivas-4ca
* fname: Vlad
* lname: Haivas
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:01:07.098580
*/
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debug(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast", "unroll-loops")
#include "speedrun.h"

using namespace std;
typedef long long ll;
typedef pair <int, int> pii;

const int NMAX = 1001;
const int nr_of_bits = 21;
const int INF = 2e9;
const int MOD = 1000000007;


vector <int> v[NMAX];
int parent[NMAX];
void DFS(int node, int p){
    parent[node] = p;
    for(auto x : v[node]){
        if(x == p)
            continue;
        DFS(x, node);
    }
}

int mat[NMAX][NMAX];

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    for(int i = 1; i < N; i++){
        mat[A[i]][B[i]] = 1;
        mat[B[i]][A[i]] = 1;
    }
    DFS(1, 0);
    setHintLen(N);
    for(int i = 1; i <= N; i++){
        for(int j = 1; j <= N; j++){
            setHint(i, j, mat[i][j]);
        }
    }
}

int vi[NMAX];
int pp[NMAX];

void speedrun(int subtask, int N, int start) { /* your solution here */
    int p = 0, nr = 0;
    int vizite = 0;
    for(int i = 1; i <= N; i++){
        v[i].clear();
    }
    for(int i = 1; i <= N; i++){
        for(int j = 1; j <= N; j++){
            if(mat[i][j]){
                v[i].push_back(j);
                v[j].push_back(i);
            }
        }
    }
    while(nr != N){
        vizite++;
        if(vizite > (2 * N + 1))
            break;
        if(!vi[start])
            nr++;
        if(nr == N)
            break;
        vi[start] = 1;
        int gasit = 0;
        for(auto i : v[start]){
            if(vi[i]) continue;
            pp[i] = start;
            start = i;
            goTo(start);
            gasit = 1;
            break;
        }
        if(gasit)
            continue;
        start = pp[start];
        goTo(start);
    }
}
