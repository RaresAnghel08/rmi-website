/**
* user:  dorde -5ce
* fname: Matei
* lname: Dorde 
* task:  Present
* score: 8.0
* date:  2021-12-16 07:45:43.949585
*/
#include <bits/stdc++.h>

using namespace std;
int const N = 1001;
int sol[N][N] , l , r , viz[N][N];
int gcd(int a , int b){
    int r;
    while(b){
        r = a % b;
        a = b;
        b = r;
    }
    return a;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0x0);
    cout.tie(0x0);
    sol[1][0] = sol[1][1] = 1;
    viz[1][1] = 1;
    r = 1;
    int now = 2;
    while(r <= 100){
        sol[++ r][0] = 1 , sol[r][1] = now;
        viz[r][now] = 1;
        int cr = r;
        for(l = 1 ; l < cr ; ++ l){
            bool p = true;
            for(int j = 1 ; j <= sol[l][0] ; ++ j){
                if(! viz[l][gcd(now , sol[l][j])])
                    p = false;
            }
            if(! p)
                continue;
            ++ r;
            for(int j = 1 ; j <= sol[l][0] ; ++ j){
                sol[r][++ sol[r][0]] = sol[l][j];
                viz[r][sol[l][j]] = 1;
            }
            sol[r][++sol[r][0]] = now;
            viz[r][now] = 1;
        }
        ++ now;
    }
    int t;
    cin >> t;
    while(t --){
        int k;
        cin >> k;
        cout << sol[k][0] << ' ';
        for(int i = 1 ; i <= sol[k][0] ; ++ i)
            cout << sol[k][i] << ' ';
        cout << '\n';
    }
    return 0;
}
