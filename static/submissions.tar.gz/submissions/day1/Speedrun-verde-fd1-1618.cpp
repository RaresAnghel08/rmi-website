/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:13:34.865107
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast","unroll-loops")
#pragma GCC target("avx","avx2","fma")
#include "speedrun.h"
using namespace std;
vector <int> v[1001];
int vec[1001],tata[1001],cnt;
void dfs(int nod,int papa)
{
    tata[nod]=papa;
    vec[++cnt]=nod;
    for(auto it:v[nod])
        if(it!=papa)
            dfs(it,nod);
}
void assignHints(int subtask, int n, int a[], int b[])
{
    int i,j;
    for(i=1; i<n; i++)
    {
        v[a[i]].push_back(b[i]);
        v[b[i]].push_back(a[i]);
    }
    setHintLen(20);
    dfs(1,0);
    for(i=1; i<=n; i++)
        for(j=1; j<=10; j++)
        {
            setHint(i,j,tata[i]%2);
            tata[i]/=2;
        }
    for(i=1; i<n; i++)
    {
        int next=vec[i+1];
        for(j=11; j<=20; j++)
        {
            setHint(vec[i],j,next%2);
            next/=2;
        }
    }
}
int acm;
void up()
{
    tata[acm]=0;
    for(int i=1; i<=10; i++)
        tata[acm]+=(1<<(i-1))*getHint(i);
    if(tata[acm]==0)
        return;
    acm=tata[acm];
    goTo(tata[acm]);
    up();
}
void speedrun(int subtask, int n, int start)
{
    int i,j;
    acm=start;
    for(i=1; i<=n; i++)
        tata[i]=-1;
    up();
    ///acum sunt in radacina
    ///sau nu ca nu merge f*r-ar
    int cate=1,index=0;
    for(j=11; j<=20; j++)
        index+=(1<<(j-11))*getHint(j);
    while(cate<n)
    {
        int ok=goTo(index);
        if(ok==1)///nice m-am dus mai jos
        {
            cate++;
            tata[index]=acm;
            acm=index;
            index=0;
            for(j=11; j<=20; j++)
                index+=(1<<(j-11))*getHint(j);
        }
        else///la n*iba
        {
            goTo(tata[acm]);
            acm=tata[acm];
        }
    }
}
/*int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    return 0;
}*/
