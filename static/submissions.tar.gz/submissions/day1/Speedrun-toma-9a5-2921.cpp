/**
* user:  toma-9a5
* fname: Eliza Maria
* lname: Toma
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:18:50.607118
*/
#include <bits/stdc++.h>

using namespace std;

void setHintLen(int l);
void setHint(int i, int j, bool b);
int getLength();
bool getHint(int j);
bool goTo(int x);
void assignHints(int subtask , int N, int A[], int B[]);
void speedrun(int subtask , int N, int start);

void assignHints(int subtask , int N, int A[], int B[]) {
    setHintLen(20);
    int f[N + 5],x,cnt,y = 0;
    for (int i = 1;i < N;i++) {
        f[A[i]]++;
        f[B[i]]++;
    }
    for (int i = 1;i <= N;i++) {
        if (f[i] > 1)
            y = i;
    }
    for (int i = 1;i <= N;i++) {
        x = y;
        cnt = 1;
        while (x) {
            setHint(i, cnt, (x & 1));
            x >>= 1;
            cnt++;
        }
    }
}
void speedrun(int subtask , int N, int start) {
    int parent[N + 5],x;
    bool k;
    int f[N + 5][N + 5];
    for (int i = 1;i <= N;i++)
        for (int j = 1;j <= N;j++)
            f[i][j] = 0;
    for (int i = 1;i <= N;i++)
        f[i][i] = -1;
    int cnt = 1,node = start,ind = 1;
    for (int i = 1;i <= N;i++)
        parent[i] = 0;
    x = 0;
    for (int i = 20;i > 0;i--)
        x = (x << 1) + getHint(i);
    parent[node] = x;
    if (node != x) {
        if (goTo(x) == 1) {
            f[x][node] = 1;
            f[node][x] = 1;
            parent[x] = node;
            node = x;
            cnt++;
        }
    }
    for (int i = 1;i <= N;i++) {
        if (x != i) {
            f[i][x] = 1;
            f[x][i] = 1;
        }
    }
    for (int i = 1;i <= N;i++) {
        for (int j = 1;j <= N;j++) {
            if (i == j || i == x || j == x)
                continue;
            f[i][j] = -1;
        }
    }
//    while (x) {
//        k = goTo(x, node);
//        if (k) {
//            f[x][node] = 1;
//            f[node][x] = 1;
//            parent[x] = node;
//            node = x;
//            cnt++;
//            x = 0;
//            for (int i = 20;i > 0;i--)
//                x = (x << 1) + getHint(i, node);
//        }
//        else {
//            f[x][node] = -1;
//            f[node][x] = -1;
//            x = 0;
//        }
//    }
    while (cnt < N) {
        while (cnt < N && ind <= N) {
            if (f[ind][node] >= 0 && !parent[ind]) {
                k = goTo(ind);
                if (k == 0) {
                    f[ind][node] = -1;
                    f[node][ind] = -1;
                }
                else {
                    f[ind][node] = 1;
                    f[node][ind] = 1;
                    parent[ind] = node;
                    node = ind;
                    ind = 0;
                    cnt++;
                }
            }
            ind++;
        }
        if (cnt < N) {
            ind = 1;
            if (goTo(parent[node]) == 1)
                node = parent[node];
        }
    }
    return;
}
