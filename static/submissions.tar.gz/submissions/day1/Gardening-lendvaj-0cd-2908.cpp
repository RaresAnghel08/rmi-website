/**
* user:  lendvaj-0cd
* fname: Dorijan
* lname: Lendvaj
* task:  Gardening
* score: 100.0
* date:  2021-12-16 10:17:25.273679
*/
#include <bits/stdc++.h>
#define x first
#define y second
#define pii pair<int,int>
using namespace std;
using ll=long long;
#define pll pair<ll,ll>
#define vi vector<int>
#define vl vector<ll>
#define all(a) begin(a),end(a)
#define pb push_back
#define eb emplace_back

const int N=300010,MOD=1e9+7;
const char en='\n';
const ll LLINF=1ll<<60;

ll t,n,m,k,snm;
vi v[N];

void solve()
{
	cin>>n>>m>>k;
	snm+=n*m;
	assert(snm<=2e5);
	if (n%2 || m%2)
	{
		cout<<"NO\n";
		return;
	}
	int n1=n/2,m1=m/2;
	if (k>n1*m1 || k<min(n1,m1))
	{
		cout<<"NO\n";
		return;
	}
	for (int i=0;i<n;++i) v[i]=vi(m);
	int off=0;
	while (1)
	{
		if (n1==1 || m1==1)
		{
			if (k!=n1*m1)
			{
				cout<<"NO\n";
				return;
			}
			for (int i=0;i<n1;++i) for (int j=0;j<m1;++j)
			{
				v[i*2+off][j*2+off]=k;
				v[i*2+off][j*2+off+1]=k;
				v[i*2+off+1][j*2+off]=k;
				v[i*2+off+1][j*2+off+1]=k;
				--k;
			}
			break;
		}
		if (k==n1*m1 || (k<=n1*m1-2 && k>=n1*m1-(n1/2)*m1 && (k%2==0 || m1>2)))
		{
			vi kol(n1/2);
			int mak=n1*m1-k;
			for (int i=0;i<n1/2;++i) if (mak>=m1) kol[i]=m1,mak-=m1;
			else kol[i]=mak,mak=0;
			mak=n1*m1-k;
			if (mak%m1==1)
			{
				++kol[mak/m1];
				--kol[mak/m1-1];
			}
			for (int i=0;i<n1/2;++i) assert(kol[i]!=1);
			for (int i=0;i<n1/2;++i)
			{
				for (int j=0;j<m1;)
				{
					if (kol[i]==3)
					{
						v[i*4+off][j*2+off]=k;
						v[i*4+off][j*2+off+1]=k;
						v[i*4+off][j*2+off+2]=k;
						v[i*4+off][j*2+off+3]=k;
						v[i*4+off][j*2+off+4]=k;
						v[i*4+off][j*2+off+5]=k;
						v[i*4+off+1][j*2+off+5]=k;
						v[i*4+off+2][j*2+off+5]=k;
						v[i*4+off+3][j*2+off+5]=k;
						v[i*4+off+3][j*2+off+4]=k;
						v[i*4+off+3][j*2+off+3]=k;
						v[i*4+off+3][j*2+off+2]=k;
						v[i*4+off+3][j*2+off+1]=k;
						v[i*4+off+3][j*2+off]=k;
						v[i*4+off+2][j*2+off]=k;
						v[i*4+off+1][j*2+off]=k;
						--k;
						v[i*4+off+1][j*2+off+1]=k;
						v[i*4+off+1][j*2+off+2]=k;
						v[i*4+off+2][j*2+off+1]=k;
						v[i*4+off+2][j*2+off+2]=k;
						--k;
						v[i*4+off+1][j*2+off+3]=k;
						v[i*4+off+1][j*2+off+4]=k;
						v[i*4+off+2][j*2+off+3]=k;
						v[i*4+off+2][j*2+off+4]=k;
						--k;
						kol[i]-=3;
						j+=3;
					}
					else if (kol[i]>=2)
					{
						v[i*4+off][j*2+off]=k;
						v[i*4+off][j*2+off+1]=k;
						v[i*4+off][j*2+off+2]=k;
						v[i*4+off][j*2+off+3]=k;
						v[i*4+off+1][j*2+off+3]=k;
						v[i*4+off+2][j*2+off+3]=k;
						v[i*4+off+3][j*2+off+3]=k;
						v[i*4+off+3][j*2+off+2]=k;
						v[i*4+off+3][j*2+off+1]=k;
						v[i*4+off+3][j*2+off]=k;
						v[i*4+off+2][j*2+off]=k;
						v[i*4+off+1][j*2+off]=k;
						--k;
						v[i*4+off+1][j*2+off+1]=k;
						v[i*4+off+1][j*2+off+2]=k;
						v[i*4+off+2][j*2+off+1]=k;
						v[i*4+off+2][j*2+off+2]=k;
						--k;
						kol[i]-=2;
						j+=2;
					}
					else
					{
						v[i*4+off][j*2+off]=k;
						v[i*4+off][j*2+off+1]=k;
						v[i*4+off+1][j*2+off]=k;
						v[i*4+off+1][j*2+off+1]=k;
						--k;
						v[i*4+off+2][j*2+off]=k;
						v[i*4+off+2][j*2+off+1]=k;
						v[i*4+off+3][j*2+off]=k;
						v[i*4+off+3][j*2+off+1]=k;
						--k;
						++j;
					}
				}
			}
			if (n1%2)
			{
				for (int j=0;j<m1;++j)
				{
					v[n1*2-2+off][j*2+off]=k;
					v[n1*2-1+off][j*2+off]=k;
					v[n1*2-2+off][j*2+1+off]=k;
					v[n1*2-1+off][j*2+1+off]=k;
					--k;
				}
			}
			break;
		}
		if (k==n1*m1 || (k<=n1*m1-2 && k>=n1*m1-(m1/2)*n1 && (k%2==0 || n1>2)))
		{
			vi kol(m1/2);
			int mak=n1*m1-k;
			for (int i=0;i<m1/2;++i) if (mak>=n1) kol[i]=n1,mak-=n1;
			else kol[i]=mak,mak=0;
			mak=n1*m1-k;
			if (mak%n1==1)
			{
				++kol[mak/n1];
				--kol[mak/n1-1];
			}
			for (int i=0;i<m1/2;++i) assert(kol[i]!=1);
			for (int i=0;i<m1/2;++i)
			{
				for (int j=0;j<n1;)
				{
					if (kol[i]==3)
					{
						v[j*2+off][i*4+off]=k;
						v[j*2+off+1][i*4+off]=k;
						v[j*2+off+2][i*4+off]=k;
						v[j*2+off+3][i*4+off]=k;
						v[j*2+off+4][i*4+off]=k;
						v[j*2+off+5][i*4+off]=k;
						v[j*2+off+5][i*4+off+1]=k;
						v[j*2+off+5][i*4+off+2]=k;
						v[j*2+off+5][i*4+off+3]=k;
						v[j*2+off+4][i*4+off+3]=k;
						v[j*2+off+3][i*4+off+3]=k;
						v[j*2+off+2][i*4+off+3]=k;
						v[j*2+off+1][i*4+off+3]=k;
						v[j*2+off][i*4+off+3]=k;
						v[j*2+off][i*4+off+2]=k;
						v[j*2+off][i*4+off+1]=k;
						--k;
						v[j*2+off+1][i*4+off+1]=k;
						v[j*2+off+2][i*4+off+1]=k;
						v[j*2+off+1][i*4+off+2]=k;
						v[j*2+off+2][i*4+off+2]=k;
						--k;
						v[j*2+off+3][i*4+off+1]=k;
						v[j*2+off+4][i*4+off+1]=k;
						v[j*2+off+3][i*4+off+2]=k;
						v[j*2+off+4][i*4+off+2]=k;
						--k;
						kol[i]-=3;
						j+=3;
					}
					else if (kol[i]>=2)
					{
						v[j*2+off][i*4+off]=k;
						v[j*2+off+1][i*4+off]=k;
						v[j*2+off+2][i*4+off]=k;
						v[j*2+off+3][i*4+off]=k;
						v[j*2+off+3][i*4+off+1]=k;
						v[j*2+off+3][i*4+off+2]=k;
						v[j*2+off+3][i*4+off+3]=k;
						v[j*2+off+2][i*4+off+3]=k;
						v[j*2+off+1][i*4+off+3]=k;
						v[j*2+off][i*4+off+3]=k;
						v[j*2+off][i*4+off+2]=k;
						v[j*2+off][i*4+off+1]=k;
						--k;
						v[j*2+off+1][i*4+off+1]=k;
						v[j*2+off+2][i*4+off+1]=k;
						v[j*2+off+1][i*4+off+2]=k;
						v[j*2+off+2][i*4+off+2]=k;
						--k;
						kol[i]-=2;
						j+=2;
					}
					else
					{
						v[j*2+off][i*4+off]=k;
						v[j*2+off+1][i*4+off]=k;
						v[j*2+off][i*4+off+1]=k;
						v[j*2+off+1][i*4+off+1]=k;
						--k;
						v[j*2+off][i*4+off+2]=k;
						v[j*2+off+1][i*4+off+2]=k;
						v[j*2+off][i*4+off+3]=k;
						v[j*2+off+1][i*4+off+3]=k;
						--k;
						++j;
					}
				}
			}
			if (m1%2)
			{
				for (int i=0;i<n1;++i)
				{
					v[i*2+off][m1*2-2+off]=k;
					v[i*2+off][m1*2-1+off]=k;
					v[i*2+1+off][m1*2-2+off]=k;
					v[i*2+1+off][m1*2-1+off]=k;
					--k;
				}
			}
			break;
		}
		if (k>=n1*m1-1)
		{
			cout<<"NO\n";
			return;
		}
		if (n1==3 && m1==5 && k==8)
		{
			vector<string> odg={
			"1111221111",
			"1331221441",
			"1331111441",
			"1556677881",
			"1556677881",
			"1111111111"};
			for (int i=0;i<n1*2;++i) for (int j=0;j<m1*2;++j) v[off+i][off+j]=odg[i][j]-'0';
			k-=8;
			break;
		}
		if (n1==5 && m1==3 && k==8)
		{
			vector<string> odg={
			"1111221111",
			"1331221441",
			"1331111441",
			"1556677881",
			"1556677881",
			"1111111111"};
			for (int i=0;i<n1*2;++i) for (int j=0;j<m1*2;++j) v[off+i][off+j]=odg[j][i]-'0';
			k-=8;
			break;
		}
		for (int i=0;i<m1*2;++i) v[off][i+off]=k;
		for (int i=0;i<n1*2;++i) v[i+off][off]=k;
		for (int i=0;i<m1*2;++i) v[off+n1*2-1][i+off]=k;
		for (int i=0;i<n1*2;++i) v[i+off][off+m1*2-1]=k;
		--k;
		--n1;
		--m1;
		++off;
	}
	if (k) cout<<"STUPID ALERT\n";
	cout<<"YES\n";
	for (int i=0;i<n;++i,cout<<en) for (int j=0;j<m;++j) cout<<v[i][j]<<' ';
	cout<<flush;
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin>>t;
	while (t--)
	{
		solve();
	}
}
