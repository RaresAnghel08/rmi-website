/**
* user:  verzotti-765
* fname: Matteo-Alexandru
* lname: Verzotti
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 08:05:18.553617
*/
#include "speedrun.h"
#include <bits/stdc++.h>
#define dbg(x) cerr << #x << ' ' << x << '\n'
#define dbgsp(x) cerr << #x << ' ' << x << ' '

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(1);
    vector <int> sz(1 + N);

    for (int i = 1; i < N; i++) {
        sz[A[i]]++;
        sz[B[i]]++;
    }

    for (int i = 1; i <= N; i++)
        if (sz[i] > 1)
            setHint(i, 1, true);
    return;
}

void solve(int N, int node) {
    for (int i = 1; i <= N; i++) {
        assert(1 <= i && i <= N);
        assert(1 <= node && node <= N);
        goTo(i);
        goTo(node);
    }
}

void speedrun(int subtask, int N, int start) {
    if (N == 2) {
        goTo(3 - start);
        return;
    }
    // subtask 2
    int centru = 0;
    if (getHint(1) == true) {
        centru = start;
    } else {
        for (int i = 1; i <= N && getHint(1) == false; i++) {
            assert(1 <= i && i <= N);
            goTo(i);
            centru = i;
        }
    }
    
    assert(1 <= centru && centru <= N);
    solve(N, centru);
}
