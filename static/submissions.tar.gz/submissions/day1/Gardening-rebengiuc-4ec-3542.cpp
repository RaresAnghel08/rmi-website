/**
* user:  rebengiuc-4ec
* fname: Mircea Maxim
* lname: Rebengiuc
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:16:18.911103
*/
#include <stdio.h>
#include <ctype.h>

static inline int fgetint(){
	int n = 0, ch;

	while( !isdigit(ch = fgetc(stdin)) );
	do
	  n = n * 10 + ch - '0';
	while( isdigit(ch = fgetc(stdin)) );

	return n;
}

int mat[4][200000];

int main(){
	int t, n, m, k, i, j, dif;

	for( t = fgetint() ; t-- ; ){
		n = fgetint();
		m = fgetint();
		k = fgetint();

		if( (n & 1) || (m & 1) ){
			printf("NO\n");
		}else if( n == 2 ){
			if( k * 2 != m )
				printf("NO\n");
			else{
				printf("YES\n");
				for( i = 0 ; i < 2 ; i++ ){
					printf("%d", 1);
				  for( j = 1 ; j < m ; j++ )
					  printf(" %d", 1 + (j / 2));
					printf("\n");
			  }
			}
		}else if( n == 4 ){
			if( k == m - 1 ){
				printf("NO\n");
			}else{
				printf("YES\n");
				if( k == m ){
			  	for( i = 0 ; i < 4 ; i++ ){
			  		printf("%d", 1 + (i / 2) * (m / 2) + (0 / 2));
			  	  for( j = 1 ; j < m ; j++ )
		  			  printf(" %d", 1 + (i / 2) * (m / 2) + (j / 2));
	  				printf("\n");
  			  }
				}else{
					dif = m - k;
					for( i = 0 ; i < 4 ; i++ )
						mat[i][0] = mat[i][2 * dif - 1] = 1;
					for( i = 0 ; i < 2 * dif ; i++ )
						mat[0][i] = mat[3][i] = 1;

					for( i = 1 ; i + 1 < 2 * dif ; i += 2 )
						mat[1][i] = mat[1][i + 1] = mat[2][i] = mat[2][i + 1] = 2 + (i / 2);
					
					for( i = 2 * dif ; i < m ; i += 2 ){
						mat[0][i] = mat[0][i + 1] = mat[1][i] = mat[1][i + 1] = 1 + dif + i - 2 * dif;
						mat[2][i] = mat[2][i + 1] = mat[3][i] = mat[3][i + 1] = 1 + dif + i - 2 * dif + 1;
					}

					for( i = 0 ; i < 4 ; i++ ){
						printf("%d", mat[i][0]);
						for( j = 1 ; j < m ; j++ )
							printf(" %d", mat[i][j]);
						printf("\n");
					}
				}
			}
		}else
		  printf("NO\n");
	}

	return 0;
}
