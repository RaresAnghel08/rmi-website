/**
* user:  andreescu-216
* fname: Mihnea
* lname: Andreescu
* task:  Present
* score: 0.0
* date:  2021-12-16 11:27:45.125232
*/
#include <bits/stdc++.h>

using namespace std;

int dumbgcd(int a, int b) {
  int sol = 0;
  for (int d = 1; d <= max(a, b); d++) {
    if (a % d == 0 && b % d == 0) {
      sol = d;
    }
  }
  return sol;
}

int gcd(int a, int b) {
  if (b == 0)return a;
  return gcd(b, a % b);
}

typedef long long ll;
typedef long double ld;

bool found;
int k;

const int N = 100 + 7;
int g[N][N];
int lim = (int)5e8;


void bkt(int cure, vector<bool> vis, vector<int> cur) {
  if (found) {
    return;
  }
  k--;
  if (k == 0) {
    found = 1;
    sort(cur.begin(), cur.end());
    cout << (int)cur.size() << " ";
    for (auto& x : cur) {
      cout << x << " ";
    }
    cout << "\n";
    return;
  }
  for (int i = 1; i <= cure; i++) {
    if (vis[i]) {
      continue;
    }
    vector<bool> nwvis = vis;
    vector<int> nwcur = cur;

    nwvis[i] = 1;
    nwcur.push_back(i);

    int pz = (int)nwcur.size() - 1;
    for (int j = pz; j < (int)nwcur.size(); j++) {
      for (int k = 0; k < j; k++) {
        int gcd = g[nwcur[k]][nwcur[j]];
        if (!nwvis[gcd]) {
          nwvis[gcd] = 1;
          nwcur.push_back(gcd);
        }
      }
    }
    bkt(i - 1, nwvis, nwcur);
  }
}

void fndkth(int kk) {
  found = 0;
  k = kk;

  if (k == 0) {
    cout << "0\n";
    return;
  }
  k = 0;
  for (int mx = 1; mx < N && !found; mx++) {

    vector<bool> vis(mx + 1, 0);
    vis[mx] = 1;
    bkt(mx, vis, { mx });
    cout << "after[" << mx << "] = " << -k << ";\n";
    if (-k > lim) {
      exit(0);
    }
  }

  assert(found);
}

int after[N];

void runtimesolve(int kk) {
  found = 0;
  k = kk;

  if (k == 0) {
    cout << "0\n";
    return;
  }
  for (int mx = 1; mx < N && !found; mx++) {
    assert(after[mx]);

    if (k <= after[mx]) {
      k -= after[mx - 1];
      vector<bool> vis(mx + 1, 0);
      vis[mx] = 1;
      bkt(mx, vis, { mx });
      break;
    }

  }

  assert(found);
}

signed main() {
  //ios::sync_with_stdio(0); cin.tie(0);

  freopen ("input", "r", stdin);
  after[1] = 1;
  after[2] = 3;
  after[3] = 6;
  after[4] = 12;
  after[5] = 21;
  after[6] = 37;
  after[7] = 66;
  after[8] = 120;
  after[9] = 207;
  after[10] = 345;
  after[11] = 662;
  after[12] = 1066;
  after[13] = 2083;
  after[14] = 3649;
  after[15] = 5620;
  after[16] = 10186;
  after[17] = 20227;
  after[18] = 33959;
  after[19] = 67672;
  after[20] = 106918;
  after[21] = 167301;
  after[22] = 316643;
  after[23] = 632548;
  after[24] = 988584;
  after[25] = 1672753;
  after[26] = 3243115;
  after[27] = 5502722;
  after[28] = 9032100;
  after[29] = 18060325;
  after[30] = 26876517;
  after[31] = 53747046;
  after[32] = 97409340;
  after[33] = 162001787;
  after[34] = 320354229;
  after[35] = 488138970;
  after[36] = 761529730;

  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      g[i][j] = gcd(i, j);
    }
  }


  int t;
  cin >> t;
  while (t--) {
    int k;
    cin >> k;
    runtimesolve(k);
  }
  return 0;
}
