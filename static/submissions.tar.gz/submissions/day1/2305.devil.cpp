/**
* user:  craciun-5f9
* fname: Mihai
* lname: Crăciun
* task:  devil
* score: 0.0
* date:  2019-10-10 08:58:09.272643
*/
#include <bits/stdc++.h>

using namespace std;

int k;
int d[10];
int s;

const int maxs = 1e6 + 5;

int afis[maxs];
int sz;

int main()  {
    int t;
    cin >> t;
    while(t--)  {
        cin >> k;
        s = 0;
        for(int i = 1;i <= 9;i++)
            cin >> d[i], s += d[i];
        sz = 0;
        for(int j = 0;j < d[1];j++)
            afis[++sz] = 1;
        for(int j = 0;j < d[2];j++)
            afis[++sz] = 2;
        /// In cazul asta d1 != 0 d2 != 0
        if(d[1] == 0)  {
            for(int i = 1;i <= s;i++)  {
                afis[i] = 2;
            }
        }
        else if(d[2] == 0)  {
            for(int i = 1;i <= s;i++)  {
                afis[i] = 1;
            }
        }
        else  {
            int szz = 0;
            for(int poz = 1;poz <= k;poz++)  {
                int nrgr = (s - k) / poz;
                if(d[1] < nrgr + 1)  {
                    continue;
                }
                for(int j = 1;j <= nrgr + 1;j++)  {
                    for(int k = 1;k < poz;k++)
                        if(d[2])
                            afis[++szz] = 2, d[2]--;
                        else
                            afis[++szz] = 1, d[1]--;
                    afis[++szz] = 1, d[1]--;
                }
                while(d[1])
                    afis[++szz] = 1, d[1]--;
                while(d[2])
                    afis[++szz] = 2, d[2]--;
            }
        }
        for(int i = 1;i <= s;i++)
            cout << afis[i] << " ";
        cout << "\n";
    }
    return 0;
}
