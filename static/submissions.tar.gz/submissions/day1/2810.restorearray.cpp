/**
* user:  sanzani-a32
* fname: Filippo
* lname: Sanzani
* task:  restore
* score: 0.0
* date:  2019-10-10 10:02:13.795037
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;

struct query{
	int l, r, k, val;
};

signed main(){
    cin.tie(0); cin.sync_with_stdio(0);

    int N, M;
    cin >> N >> M;

	vector<query> qry;

	while(M--){
		int l, r, k, val;
		cin >> l >> r >> k >> val;
		qry.push_back({l+1, r+1, k, val});
	}
/*
	sort(qry.begin(), qry.end(), [](const query& a, const query& b){
		return a.val > b.val;
	});
*/
	int i=0;
	vector<bool> set1(N+10, false);
	vector<bool> set0(N+10, false);
	vector<int> v1(N+10, 0), prefix1(N+10, 0);
	vector<int> v0(N+10, 0), prefix0(N+10, 0);

	for(; i<qry.size(); i++){
		if(qry[i].val == 1 && qry[i].k == 1){
			v1[qry[i].l] = 1;
			v1[qry[i].r+1] = -1;
		}
		if(qry[i].val == 0 && qry[i].k != 1){
			v0[qry[i].l] = 1;
			v0[qry[i].r+1] = -1;
		}	
	}

	int sum1 = 0, sum0 = 0;
	for(int ii=0; ii<v1.size(); ii++){
		sum1 += v1[ii];
		v1[ii] = min(sum1, 1);
		if(v1[ii] != 0) set1[ii] = 1;
		sum0 += v0[ii];
		v0[ii] = min(sum0, 1);
		if(v0[ii] != 0) set0[ii] = 1;
	}


	for(int i=1; i<prefix1.size(); i++) prefix1[i] = prefix1[i-1] + v1[i];
	for(int i=1; i<prefix0.size(); i++) prefix0[i] = prefix0[i-1] + v0[i];

	for(int i=1; i<=N; i++) if(prefix0[i] == prefix1[i] && prefix1[i] == 1){
		cout << -1 << "\n";
		return 0;
	}


	for(auto q : qry){
		if(qry[i].val == 1 && qry[i].k != 1){
			if(prefix0[q.r] - prefix0[q.l-1] == q.r - q.l + 1){
				cout << -1 << "\n";
				return 0;
			}
		}
		if(qry[i].val == 0 && qry[i].k == 1){
			if(prefix1[q.r] - prefix1[q.l-1] == q.r - q.l + 1){
				cout << -1 << "\n";
				return 0;
			}
		}
	}

	for(int i=1; i<=N; i++) cout << v1[i] << " ";
}

