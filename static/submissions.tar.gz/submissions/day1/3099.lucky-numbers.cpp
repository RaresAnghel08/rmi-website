/**
* user:  bachurski-d21
* fname: Jakub
* lname: Bachurski
* task:  lucky
* score: 100.0
* date:  2019-10-10 10:31:14.832093
*/
#ifdef EVAL
#pragma GCC optimize ("Ofast")
#pragma GCC target ("tune=native")
#endif
#include <bits/stdc++.h>

using namespace std;

using uint = unsigned;
const uint64_t MOD = 1e9 + 7;

struct matrix3
{
    uint64_t t[3][3];
    friend matrix3 operator* (const matrix3& b, const matrix3& a)
    {
        matrix3 c;
        for(size_t i = 0; i < 3; i++)
            for(size_t j = 0; j < 3; j++)
        {
            c.t[i][j] = 0;
            for(size_t k = 0; k < 3; k++)
                c.t[i][j] += a.t[i][k] * b.t[k][j];
            c.t[i][j] %= MOD;
        }
        return c;
    }
    matrix3& operator*= (const matrix3& o) { return *this = *this * o; }
};
const matrix3 IDENTITY = {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}};

matrix3 matt(const vector<uint>& A, size_t i)
{
    return {{
        {9, 8, (A[i] - (A[i-1] == 1 and A[i] > 3) - (A[i] > 1))},
        {1, 1, (A[i] > 1)},
        {0, 0, 1}
    }};
}

matrix3 matt_after13()
{
    return {{
        {9, 8, 0},
        {1, 1, 0},
        {0, 0, 1}
    }};
}

struct segment_tree
{
    size_t w;
    vector<matrix3> T;
    segment_tree(size_t n)
    {
        w = 1 << __lg(2*n-1);
        T.resize(2 * w, IDENTITY);
    }
    
    void set(size_t i, matrix3 m)
    {
        i += w - 1;
        T[i] = m;
        i /= 2;
        while(i)
            T[i] = T[2*i] * T[2*i+1], i /= 2;
    }
    
    matrix3 get(size_t i, size_t nodeL, size_t nodeR, size_t getL, size_t getR)
    {
        if(nodeR < getL or getR < nodeL)
            return IDENTITY;
        else if(getL <= nodeL and nodeR <= getR)
            return T[i];
        else
            return get(2*i, nodeL, (nodeL+nodeR)/2, getL, getR) *
                   get(2*i+1, (nodeL+nodeR)/2+1, nodeR, getL, getR);
    }
    
    matrix3 get(size_t getL, size_t getR)
    {
        return get(1, 0,  w - 1, getL - 1, getR - 1);
    }
};

int main()
{
    ios::sync_with_stdio(false); cin.tie(nullptr);
    
    size_t n, q;
    cin >> n >> q;
    string S;
    cin >> S;
    
    vector<uint> A(n+2);
    for(size_t i = 1; i <= n; i++)
        A[i] = S[i-1] - '0';
    
    segment_tree T(n);
    for(size_t i = 1; i <= n; i++)
        T.set(i, matt(A, i));
    
    vector<matrix3> poww13(n+1, IDENTITY);
    for(size_t i = 1; i <= n; i++)
        poww13[i] = poww13[i-1] * matt_after13();
    
    set<size_t> thirteens;
    for(size_t i = 1; i <= n; i++)
        if(A[i] == 1 and A[i+1] == 3)
            thirteens.insert(i);

    auto get = [&](size_t l, size_t r) {
        auto brk = thirteens.lower_bound(l);
        size_t ap = 0, rt = r; bool has13 = false;
        if(brk != thirteens.end() and *brk < r)
        {
            has13 = true;
            rt = *brk + 1;
            ap = r - rt;
        }
        auto prev = A[l-1];
        A[l-1] = 0;
        T.set(l, matt(A, l));
        auto m = T.get(l, rt);
        m *= poww13[ap];
        A[l-1] = prev;
        T.set(l, matt(A, l));
        return (m.t[0][2] + m.t[1][2] + (not has13)) % MOD;
    };
    
    cout << get(1, n) << '\n';

    while(q --> 0)
    {
        size_t t, l, r;
        cin >> t >> l >> r;
        if(t == 1)
        {
            cout << get(l, r) << '\n';   
        }
        else if(t == 2)
        {
            A[l] = r;
            T.set(l, matt(A, l));
            thirteens.erase(l);
            thirteens.erase(l-1);
            if(A[l-1] == 1 and A[l] == 3)
                thirteens.insert(l-1);
            if(A[l] == 1 and A[l+1] == 3)
                thirteens.insert(l);
            if(l+1 <= n)
                T.set(l+1, matt(A, l+1));
        }
    }
}
