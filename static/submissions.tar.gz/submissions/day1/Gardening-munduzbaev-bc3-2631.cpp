/**
* user:  munduzbaev-bc3
* fname: Aidar
* lname: Munduzbaev
* task:  Gardening
* score: 11.0
* date:  2021-12-16 09:50:09.495717
*/
#include "bits/stdc++.h"
using namespace std;

#define ar array

void solve(){
	int n, m, k; cin>>n>>m>>k;
	bool s = 0;
	if(n > m) swap(n, m), s = 1;
	if(k > m || n & 1 || m & 1){
		cout<<"NO\n";
		return;
	}
	
	if(n == 2){
		if(k != m / 2){
			cout<<"NO\n";
			return;
		}
		cout<<"YES\n";
		if(s){
			for(int i=1;i<=k;i++){
				cout<<i<<" "<<i<<"\n";
				cout<<i<<" "<<i<<"\n";
			} return;
		}
		for(int i=0;i<k;i++){
			cout<<k - i<<" "<<k - i<<" ";
		} cout<<"\n";
		for(int i=0;i<k;i++){
			cout<<k - i<<" "<<k - i<<" ";
		} cout<<"\n";
		return;
	}
	
	ar<int, 2> r = {0, n - 1}, c = {0, m - 1};
	vector<vector<int>> res(n, vector<int>(m));

	auto rev = [&](){ s ^= 1;
		vector<vector<int>> rr(res[0].size(), vector<int>(res.size()));
		for(int i=0;i<(int)res.size();i++){
			for(int j=0;j<(int)res[i].size();j++){
				rr[j][i] = res[i][j];
			}
		} swap(res, rr);
	};


	while(n > 4){
		if(m <= k){
			for(int i=c[0];i<=c[1];i+=2){
				res[r[0]][i] = res[r[0]][i+1] = res[r[0]+1][i] = res[r[0]+1][i+1] = k--;
			} r[0]+=2; n -= 2;
			continue;
		}
		
		if(n == 6 && m == k + 2){
			for(int i=r[0];i<=r[1];i+=2){
				res[i][c[0]] = res[i+1][c[0]] = res[i][c[0]+1] = res[i+1][c[0]+1] = k--;
			} c[0]+=2; m -= 2;
			continue;
		}
		
		n -= 2, m -= 2;
		for(int i=r[0];i<=r[1];i++){
			res[i][c[0]] = res[i][c[1]] = k;
		} for(int j=c[0];j<=c[1];j++){
			res[r[0]][j] = res[r[1]][j] = k;
		} k--;
		r[0]++, r[1]--, c[0]++, c[1]--;
	}

	if(k + 1 == m || m / 2 > k || k > m){
		cout<<"NO\n";
		return;
	}

	int x = 2 * (m - k);
	
	int y = m - x;
	for(int j=c[0];j<c[0] + y;j+=2){
		res[r[0]][j] = res[r[0]][j+1] = k;
		res[r[0]+1][j] = res[r[0]+1][j+1] = k--;
		res[r[1]][j] = res[r[1]][j+1] = k;
		res[r[1]-1][j] = res[r[1]-1][j+1] = k--;
	}
	
	c[0] += y;
	if(x){
		for(int i=r[0];i<=r[1];i++){
			res[i][c[0]] = res[i][c[1]] = k;
		} for(int j=c[0];j<=c[1];j++){
			res[r[0]][j] = res[r[1]][j] = k;
		} k--; r[0]++, r[1]--;
		for(int j=c[0]+1;j<c[1];j+=2){
			res[r[0]][j] = res[r[1]][j] = res[r[0]][j+1] = res[r[1]][j+1] = k;
			k--;
		}
	}
	
	//~ assert(!k);
	
	if(s) rev();
	cout<<"YES\n";
	for(auto v : res){
		for(auto x : v) cout<<x<<" ";
		//~ cout<<endl;
		cout<<"\n";
	}
}

signed main(){
	ios::sync_with_stdio(0); cin.tie(0);
	
	int t; cin>>t;
	while(t--){
		solve();
	}
}
