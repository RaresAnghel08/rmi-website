/**
* user:  moldovan-92d
* fname: Andrei
* lname: Moldovan
* task:  restore
* score: 13.0
* date:  2019-10-10 09:48:07.361671
*/
#include <bits/stdc++.h>
using namespace std;
int v[5005];
struct dd
{
    int l,r,k,val;
};
struct ap
{
    int l,r,val;
};
dd t[10005];
int mars[10005],mars1[10005];
int sp[10005];
int sp1[10005];
ap sol[10005];
bool cmp(ap x,ap y)
{
    if(x.r==y.r)
    {
        if(x.l==y.l)return x.val<y.val;
        return x.l<y.l;
    }
    return x.r<y.r;
}
int main()
{
    //freopen("a.in","r",stdin);
    int n,m,i,j;
    int cnt=0;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>t[i].l>>t[i].r>>t[i].k>>t[i].val;
        t[i].l++;
        t[i].r++;
        if(t[i].k==1&&t[i].val==1)
        {
            mars[t[i].l]++;
            mars[t[i].r+1]--;
        }
        if(t[i].k==0&&t[i].val==(t[i].r-t[i].l+1))
        {
            mars1[t[i].l]++;
            mars1[t[i].r+1]--;
        }
    }
       /* if(n<=18)
    {
        int ns=1<<n;
        int tot=0;
        for(int i=0;i<ns;++i)
        {
            fill(v+1,v+n+1,0);
            fill(sp+1,sp+n+1,0);
            for(j=0;j<n;j++)
                {{if(i&(1<<j))
                v[j+1]=1;sp[j+1]=sp[j]+v[j+1];}
                int ok=0;
            for(int t1=1;t1<=m;t1++)
            {
                int k=t[t1].k;
                int val1=t[t1].r-t[t1].l+1;
                int sp1=sp[t[t1].r]-sp[t[t1].l-1];
                if(t[t1].val==0)
                    if(sp1>(val1-k))
                {
                    ok=1;
                    break;
                }
                if(t[t1].val==1)
                    if(sp1<(val1-k+1))
                {
                    ok=1;
                    break;
                }
            }
            if(ok==0)
            {
                for(i=1;i<=n;i++)
                    cout<<v[i]<<" ";
                cout<<"\n";
                tot=1;
                return 0;
            }
        }
    }
    if(tot==0)
    {
        printf("-1");
        return 0;
    }
    }*/
    int pz=0;
    fill(v+1,v+n+1,2);
    int sum=0;
    for(i=1;i<=n;i++)
    {
        sum+=mars[i];
        if(sum>0)v[i]=1;
        sp[i]=sp[i-1]+(v[i]==1);
    }
    sum=0;
    for(i=1;i<=n;i++)
    {
        sum+=mars1[i];
        if(sum>0)v[i]=0;
        sp1[i]=sp1[i-1]+(v[i]==0);
    }
    for(i=1;i<=m;i++)
    {
        if(t[i].val==0&&t[i].k==1)
        {
            int sp2=sp1[t[i].r]-sp1[t[i].l-1];
            if(sp2)continue;
            sol[++pz].l=t[i].l;
            sol[pz].r=t[i].r;
            sol[pz].val=0;
        }
        if(t[i].val==1&&t[i].k!=1)
        {
            int sp2=sp[t[i].r]-sp[t[i].l-1];
            if(sp2)continue;
                      sol[++pz].l=t[i].l;
            sol[pz].r=t[i].r;
            sol[pz].val=1;
        }
    }
    sort(sol+1,sol+pz+1,cmp);
    for(i=1;i<=pz;i++)
    {
        int x=sol[i].l,y=sol[i].r;
        while(v[x]!=sol[i].val&&x<=y)
        {
            if(v[x]==2)
            {
                v[x]=sol[i].val;
                break;
            }
                if(v[x]==sol[i].val)break;
                ++x;
        }
        if(x==y+1)
        {
            printf("-1");
            return 0;
        }
    }
    for(i=1;i<=n;i++)
        cout<<(v[i]&1)<<" ";
    return 0;
}
