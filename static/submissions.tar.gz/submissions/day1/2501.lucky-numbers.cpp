/**
* user:  savulescu-3de
* fname: Ștefan
* lname: Săvulescu
* task:  lucky
* score: 28.0
* date:  2019-10-10 09:25:07.285738
*/
#include <cstdio>

using namespace std;
int n,q,r,i,j,k,t,l,ri,d[100004][14],d2[100004][14];
char s[100004];
int main()
{
    scanf ("%d %d\n", &n, &q);
    scanf ("%s", &s);
    n--;
    for (i=0; i<(s[0]-'0'); i++)
        d[0][i]=1;
    d2[0][s[0]-'0']=1;
    for (i=1; i<=n; i++)
    {
        for (j=0; j<=9; j++)
        {
            if (d[i-1][j]!=0)
            {
                for (k=0; k<=9; k++)
                {
                    if ((j!=1) || (k!=3))
                    {
                        d[i][k]+=d[i-1][j];
                        if (d[i][k]>=1000000007)
                            d[i][k]-=1000000007;
                    }
                }
            }
        }
        for (j=0; j<(s[i]-'0'); j++)
        {
            if ((j!=3) || (s[i-1]!='1'))
            {
                d[i][j]+=d2[i-1][s[i-1]-'0'];
                if (d[i][j]>=1000000007)
                    d[i][j]-=1000000007;
            }
        }
        if ((s[i]!='3') || (s[i-1]!='1'))
            d2[i][s[i]-'0']=d2[i-1][s[i-1]-'0'];
    }
    r=0;
    for (i=0; i<=9; i++)
    {
        r+=d[n][i];
        r+=d2[n][i];
        if (r>=1000000007)
            r-=1000000007;
    }
    printf ("%d\n", r);
    while (q>=1)
    {
        scanf ("%d %d %d", &t, &l, &ri);
        if (t==1)
        {
            l--;
            ri--;
            for (i=0;i<=9;i++)
            {
                d[l][i]=0;
                d2[l][i]=0;
            }
            for (i=0; i<(s[l]-'0'); i++)
                d[l][i]=1;
            d2[l][s[l]-'0']=1;
            for (i=(l+1); i<=ri; i++)
            {
                for (j=0;j<=9;j++)
                {
                    d[i][j]=0;
                    d2[i][j]=0;
                }
                for (j=0; j<=9; j++)
                {
                    if (d[i-1][j]!=0)
                    {
                        for (k=0; k<=9; k++)
                        {
                            if ((j!=1) || (k!=3))
                            {
                                d[i][k]+=d[i-1][j];
                                if (d[i][k]>=1000000007)
                                    d[i][k]-=1000000007;
                            }
                        }
                    }
                }
                for (j=0; j<(s[i]-'0'); j++)
                {
                    if ((j!=3) || (s[i-1]!='1'))
                    {
                        d[i][j]+=d2[i-1][s[i-1]-'0'];
                        if (d[i][j]>=1000000007)
                            d[i][j]-=1000000007;
                    }
                }
                if ((s[i]!='3') || (s[i-1]!='1'))
                    d2[i][s[i]-'0']=d2[i-1][s[i-1]-'0'];
            }
            r=0;
            for (i=0; i<=9; i++)
            {
                r+=d[ri][i];
                r+=d2[ri][i];
                if (r>=1000000007)
                    r-=1000000007;
            }
            printf ("%d\n", r);
        }
        else
            s[l-1]='0'+ri;
        q--;
    }
    return 0;
}
