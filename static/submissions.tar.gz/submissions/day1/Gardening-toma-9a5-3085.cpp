/**
* user:  toma-9a5
* fname: Eliza Maria
* lname: Toma
* task:  Gardening
* score: 5.0
* date:  2021-12-16 10:35:40.758661
*/
#include <bits/stdc++.h>

using namespace std;

const int NMAX = 2e5;
int v[NMAX + 5];

int main()
{
    int n,m,k,t,ii,jj;
    cin >> t;
    while (t--) {
        cin >> n >> m >> k;
        if (min(n, m) == 2 && max(n, m) == 4 && k == 1) {
            cout << "NO" << '\n';
            continue;
        }
        if (n == 4 && m == 4 && (k == 1 || k == 3)) {
            cout << "NO" << '\n';
            continue;
        }
        if (k > ((n / 2) * (m / 2)) || n == 1 || m == 1 || n % 2 == 1 || m % 2 == 1) {
            cout << "NO" << '\n';
            continue;
        }
        if (n == 2 && k != m / 2) {
            cout << "NO" << '\n';
            continue;
        }
        if (n == 4) {
            if (m / 2 != k && m != k) {
                cout << "NO" << '\n';
                continue;
            }
        }
        cout << "YES" << '\n';
        if (n == 2 && m == 2)
            cout << "1 1" << '\n' << "1 1";
        else if (n == 2 && m == 4 && k == 2)
            cout << "2 2 1 1" << '\n' << "2 2 1 1";
        else if (n == 4 && m == 2 && k == 2)
            cout << "2 2" << '\n' << "2 2" << '\n' << "1 1" << '\n' << "1 1";
        else if (n == 4 && m == 4 && k == 2)
            cout << "1 1 1 1" << '\n' << "1 2 2 1" << '\n' << "1 2 2 1" << '\n' << "1 1 1 1";
        else if (n == 4 && m == 4 && k == 4)
            cout << "1 1 2 2" << '\n' << "1 1 2 2" << '\n' << "3 3 4 4" << '\n' << "3 3 4 4";
        else {
            if (n == 2) {
                while (k) {
                    cout << k << " " << k << " ";
                    k--;
                }
                cout << '\n';
                while (m) {
                    cout << m / 2 << " " << m / 2 << '\n';
                    m -= 2;
                }
            }
            else {
                if (m == k) {
                    while (k > m / 2) {
                        cout << k << " " << k << " ";
                        k--;
                    }
                    cout << '\n';
                    k = m;
                    while (k > m / 2) {
                        cout << k << " " << k << " ";
                        k--;
                    }
                    cout << '\n';
                    k = m / 2;
                    while (k) {
                        cout << k << " " << k << " ";
                        k--;
                    }
                    cout << '\n';
                    k = m / 2;
                    while (k) {
                        cout << k << " " << k << " ";
                        k--;
                    }
                }
                else {
                    for (int i = 0;i < m;i++)
                        cout << k << " ";
                    cout << '\n' << k << ' ';
                    for (int i = 1;i < m / 2;i++)
                        cout << --k << " " << k << " ";
                    k = m / 2;
                    cout << k << '\n';
                    cout << k << " ";
                    for (int i = 1;i < m / 2;i++)
                        cout << --k << " " << k << " ";
                    k = m / 2;
                    cout << k << '\n';
                    for (int i = 0;i < m;i++)
                        cout << k << " ";
                }
            }
        }
    }
    return 0;
}
