/**
* user:  verde-76f
* fname: Flaviu-Cristian
* lname: Verde
* task:  lucky
* score: 28.0
* date:  2019-10-10 07:58:45.194972
*/
#include <iostream>
#include <cstdio>
using namespace std;
const int MOD=1e9+7;
char s[100001];
int v[100001],dp[100001][10],cate[100001],dp1[100001][10],catepref[100001];
bool prefix[100001];
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    int n,q,i,j,sum,t,a,b,rez;
    cin>>n>>q>>ws>>(s+1);
    for(i=1; i<=n; i++)
        v[i]=s[i]-'0';
    for(i=0; i<=9; i++)
        dp[1][i]=1;
    cate[1]=10;
    for(i=2; i<=100000; i++)
    {
        sum=0;
        for(j=0; j<=9; j++)
            sum=(sum+dp[i-1][j])%MOD;
        for(j=0; j<=9; j++)
            dp[i][j]=sum;
        dp[i][3]=(dp[i][3]-dp[i-1][1]+MOD);
        if(dp[i][3]>=MOD)
            dp[i][3]-=MOD;
        cate[i]=(1LL*10*sum-dp[i-1][1]+MOD)%MOD;
    }
    prefix[0]=1;
    for(j=0; j<=v[1]; j++)
        dp1[1][j]=1;
    catepref[1]=v[1];
    for(i=2; i<=n; i++)
    {
        prefix[i-1]=prefix[i-2];
        if(v[i-2]*10+v[i-1]==13)
            prefix[i-1]=0;
        sum=0;
        for(j=0; j<=9; j++)
            sum=(sum+dp1[i-1][j])%MOD;
        for(j=0; j<=v[i]; j++)
            dp1[i][j]=sum;
        for(; j<=9; j++)
            dp1[i][j]=sum-prefix[i-1];
        dp1[i][3]=dp1[i][3]-dp1[i-1][1]+MOD;
        if(dp1[i][3]>=MOD)
            dp1[i][3]-=MOD;
        catepref[i]=(1LL*10*sum-(9-v[i])*prefix[i-1]-dp1[i-1][1]+2*MOD)%MOD;
        //cout<<catepref[i]<<" ";
    }
    cout<<catepref[n]<<'\n';
    for(i=1;i<=q;i++)
    {
     cin>>t>>a>>b;
     rez=catepref[b]-(catepref[a-1]-prefix[a-1])*cate[b-a]+dp[a-1][1]*cate[b-a-1];
     cout<<rez<<'\n';
    }
    return 0;
}
