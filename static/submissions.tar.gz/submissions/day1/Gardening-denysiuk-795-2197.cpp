/**
* user:  denysiuk-795
* fname: Vladyslav
* lname: Denysiuk
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:08:58.904569
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int long long
#define endl '\n'
#define all(var) var.begin(),var.end()
const int NM = 2e5+7;
const int LOG = 20;
#define gp(x,y) int((x-1)*m+(y-1))
int A[NM],dp[NM],n,m;
void solve4(int k){
    if (k==(n>>1)*(m>>1)){
        cout<<"YES\n";
        for(int i = 0;i<n;++i){
            for(int j = 0;j<m;++j){
                cout<<(i>>1)*(m>>1)+(j>>1)+1<<' ';
            }
            cout<<endl;
        }
        return;
    }
    if (n==4 && m==4){
        if (k==2){
            cout<<"YES\n";
            for(int i = 0;i<n;++i){
                for(int j = 0;j<m;++j){
                    if (i==0 || i==n-1 || j==0 || j==m-1){
                        cout<<"1 ";
                    }
                    else cout<<"2 ";
                }
                cout<<endl;
            }
        }
        else{
            cout<<"NO\n";
        }
        return;
    }
    cout<<"NO\n";
    return;
}
void solve(){
    int k;
    cin>>n>>m>>k;
    if (n&1 || m&1){
        cout<<"NO\n";
        return;
    }
    if (n<=4 && m<=4) {
        solve4(k);
        return;
    }
    if (n==2){
        if (k!=m/2){
            cout<<"NO\n";
            return;
        }
        cout<<"YES\n";
        for(int i = 0;i<n;++i){
            for(int j = 0;j<m;++j){
                cout<<((i>>1)*(m>>1))+(j>>1)+1<<' ';
            }
            cout<<endl;
        }
        return;
    }
    int ptr = 0;
    for(int frames = 1;(frames<<1)<=m;++frames){
        int need = k-frames;
        if (need<0)
            continue;
        int left = (need*2-(m-frames*2));
        int taken = m-frames-left;
        if (taken/2<frames || left<0)
            continue;
        cout<<"YES\n";
        for(int j = 1;j<=left;j+=2){
            A[gp(1,j)] = A[gp(1,j+1)] = A[gp(2,j)] = A[gp(2,j+1)] = ++ptr;
            A[gp(3,j)] = A[gp(3,j+1)] = A[gp(4,j)] = A[gp(4,j+1)] = ++ptr;
        }
        int super = taken/2-frames+1;
        assert(super>=1);
        int super_pos = ++ptr;
        A[gp(1,left+1)] = A[gp(2,left+1)] = A[gp(3,left+1)] = A[gp(4,left+1)] = super_pos;
        for(int j = left+2;j<=left+1+super*2;j+=2){
            A[gp(3,j)] = A[gp(3,j+1)] = A[gp(2,j)] = A[gp(2,j+1)] = ++ptr;
            A[gp(1,j)] = A[gp(1,j+1)] = A[gp(4,j)] = A[gp(4,j+1)] = super_pos;
        }
        A[gp(1,left+2+super*2)] = A[gp(2,left+2+super*2)]
                = A[gp(3,left+2+super*2)] = A[gp(4,left+2+super*2)] = super_pos;
        for(int j = left+2+super*2+1;j<=m;j+=4){
            super_pos = ++ptr;
            A[gp(1,j)] = A[gp(2,j)] = A[gp(3,j)] = A[gp(4,j)] = super_pos;
            A[gp(1,j+3)] = A[gp(2,j+3)] = A[gp(3,j+3)] = A[gp(4,j+3)] = super_pos;
            A[gp(1,j+1)] = A[gp(1,j+2)] = A[gp(4,j+1)] = A[gp(4,j+2)] = super_pos;

            A[gp(3,j+1)] = A[gp(3,j+2)] = A[gp(2,j+1)] = A[gp(2,j+2)] = ++ptr;
        }
        assert(ptr==k);
        for(int i = 1;i<=n;++i){
            for(int j = 1;j<=m;++j){
                cout<<A[gp(i,j)]<<' ';
            }
            cout<<endl;
        }
        return;
    }
    cout<<"NO\n";
    return;
}
signed main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    cin>>t;
    while(t--)
        solve();
    return 0;
}