/**
* user:  abramson-f2e
* fname: Carmel
* lname: Abramson
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 07:34:41.304785
*/
#include "speedrun.h"
#include<bits/stdc++.h>

using namespace std;
typedef vector<int> vi;

void assignHints(int subtask, int N, int A[], int B[]) {

    vi a(N),b(N);
    for(int i=0; i<N; i++)
        a[i]=A[i],b[i]=B[i];

    vi deg(N+1);
    for(int i=1; i<N;i ++)
        deg[a[i]]++,deg[b[i]]++;

    int star=0;
    for(int i=1; i<=N; i++)
        if(deg[i]==N-1)
            star=i;
    setHintLen(20);
    for(int i=1; i<=N; i++)
        if(i!=star){
            for(int j=0; j<20; j++)
                if(star&(1<<j))
                    setHint(i,j+1,1);
        }
}

void dfs(int src,int par,int n){

    int h=0;
    for(int j=1; j<=20; j++)
        if(getHint(j))
            h+=1<<(j-1);
    if(!h){
        for(int i=1; i<=n; i++)
            if(i!=par && i!=src)
                goTo(i),dfs(i,src,n);
    }
    else{
        if(h!=par)
            goTo(h),dfs(h,src,n);
    }
    if(par!=-1)
        goTo(par);
}

void speedrun(int subtask, int N, int start) {
    dfs(start,-1,N);
}

/*
 small
 5
 1 2
 2 3
 3 4
 3 5
1

 starred at 2
 6
1 2
2 3
2 4
2 5
2 6

 */