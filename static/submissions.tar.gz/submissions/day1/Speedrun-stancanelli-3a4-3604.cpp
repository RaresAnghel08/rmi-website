/**
* user:  stancanelli-3a4
* fname: Valerio
* lname: Stancanelli
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 11:21:55.476411
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;

#define nl "\n"
#define nf endl
#define ll long long
#define pb push_back
#define _ << ' ' <<

#define INF (ll)1e18
#define mod 998244353
#define maxn 1010

ll i, i1, j, k, k1, t, n, m, res, flag[10], a, b;
ll x[maxn], y[maxn], lf, s, z[maxn], pr[maxn];
bool vis[maxn];
vector<ll> adj[maxn];
set<ll> st;

bool gt(ll x) {
	bool b = goTo(x);
	/* if (!b) cout << "false goto" _ x << nf;
	else cout << "true goto" _ x << nf; */
	return b;
}

void dfs1(ll s, ll p) {
	ll f = 0;
	for (auto u : adj[s]) {
		if (u == p) continue;
		if (f == 0) {
			x[s] = p; y[s] = u; f = 1;
		} else {
			x[lf] = s; y[lf] = u;
		}
		dfs1(u, s);
	}

	if (f == 0) lf = s;
}

void dfs2(ll s) {
	// cout << "dfs2" _ s << nf;

	ll j, k, f = 0;
	st.insert(s);
	if (st.size() == n) return;

	if (x[s] == 0 && z[s] == 0) {
		for (j = 1; j <= 10; j++) {
			x[s] += ((ll)getHint(j) << (j - 1));
			z[s] += ((ll)getHint(j + 10) << (j - 1));
		}
	}

	// cout << "x, z =" _ x[s] _ z[s] << nf;

	if (z[s] != -1 && gt(z[s])) {
		// cout << "z" << nf;
		k = z[s]; z[s] = -1;
		pr[k] = s;
		dfs2(k);
	} else {
		// cout << "p" << nf;
		if (z[s] != -1) z[x[s]] = z[s];
		gt(pr[s]); dfs2(pr[s]);
	}
}

void assignHints(int subtask, int N, int A[], int B[]) {
	n = N;
	for (i = 1; i <= n - 1; i++) {
		a = A[i]; b = B[i];
		adj[a].pb(b); adj[b].pb(a);
	}
	for (i = 1; i <= n; i++) {
		x[i] = 1; y[i] = 1;
	}

	lf = 0;
	dfs1(1, 0);

	// for (i = 1; i <= n; i++) cout << "i, x, y =" _ i _ x[i] _ y[i] << nf;

	setHintLen(20);
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= 10; j++) {
			setHint(i, j, (x[i] >> (j - 1)) & 1);
			setHint(i, j + 10, (y[i] >> (j - 1)) & 1);
		}
	}
}

void speedrun(int subtask, int N, int start) {
	n = N; s = start;

	while (s != 1) {
		x[s] = 0; y[s] = 0;
		for (j = 1; j <= 10; j++) {
			x[s] += ((ll)getHint(j) << (j - 1));
			y[s] += ((ll)getHint(j + 10) << (j - 1));
		}
		// cout << "s, x, y =" _ s _ x[s] _ y[s] << nf;
		if (gt(x[s])) {
			s = x[s];
		} else {
			for (i = 1; i <= n; i++) {
				if (i == s || i == x[s]) continue;
				if (gt(i)) {
					s = i; break;
				}
			}
		}
	}

	for (i = 1; i <= n; i++) x[i] = 0;
	dfs2(1);
}
