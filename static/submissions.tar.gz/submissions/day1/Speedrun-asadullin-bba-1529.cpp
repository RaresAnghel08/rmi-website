/**
* user:  asadullin-bba
* fname: Aidar Ildarovich
* lname: Asadullin
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:05:39.055007
*/
#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
    vector<int> g[N];
    for (int i = 1; i < N; ++i) {
        int a = A[i] - 1;
        int b = B[i] - 1;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    setHintLen(N);
    for (int j = 0; j < N; ++j) {
        for (int i = 0; i < g[j].size(); ++i) {
            int to = g[j][i] + 1;
            setHint(j + 1, to, 1);
        }
    }
}

int n;

void dfs(int v, int p) {
    for (int i = 0; i < n; ++i) {
        if (i == p)continue;
        if (getHint(i + 1) == 1) {
            goTo(i + 1);
            dfs(i, v);
        }
    }
    if (p != -1) {
        goTo(p + 1);
    }
}

void speedrun(int subtask, int N, int start) {
    n = N;
    dfs(start, -1);
}
