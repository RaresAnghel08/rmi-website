/**
* user:  lifar-7f1
* fname: Egor
* lname: Lifar
* task:  devil
* score: 0.0
* date:  2019-10-10 09:52:52.248607
*/
#include <bits/stdc++.h>

using namespace std;
template<class A, class B> inline void chkmin(A &a, B b){ a = (a > b ? b: a);}
template<class A, class B> inline void chkmax(A &a, B b){ a = (a < b ? b: a);}
#define all(c) (c).begin(), (c).end()
#define sz(c) (int)(c).size()
#define pb push_back
#define mp make_pair
using ll = long long;
using ld = long double;
const int MAXN = 100228;

int k;
int d[10];
int val[MAXN];


void solve() {
	cin >> k;
	for (int i = 1; i <= 9; i++) {
		cin >> d[i];
	}
	for (int i = 0; i < d[2]; i++) {
		val[i] = 0;
	}
	if (d[2] < k) {
		for (int i = 0; i < d[1]; i++) {
			cout << 1;
		}
		for (int i = 0; i < d[2]; i++) {
			cout << 2;
		}
		cout << '\n';
	} else {
		ll cur = k;
		vector<int> st;
		for (int it = 0; ; it++) {
			cur--;
			ll g = (d[2] - k + 1 + it) / (it + 1);
			ll t = min(d[1] / g, cur);
			d[1] %= g;
			st.pb(t);
			cur -= t;
			if (cur == 0) {
				break;
			}
		}
		for (int i = 0; i <= d[2] - k; i++) {
			cout << '2';
			for (int j = 0; j < st[i % sz(st)]; j++) {
				cout << '1';
			}
		}
		for (int i = 0; i < d[1]; i++) {
			cout << '1';
		}
		cout << '\n';
	}
}


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	//freopen("input.in", "r", stdin);
	int t;
	cin >> t;
	for (int it = 0; it < t; it++) {
		solve();
	}
	return 0;
}