/**
* user:  handarov-91d
* fname: Radostin Nikolaev
* lname: Handarov
* task:  Present
* score: 8.0
* date:  2021-12-16 11:55:20.449127
*/
#include <bits/stdc++.h>

#pragma GCC optimize "-O3"

#define endl '\n'
#define trace(x) cerr << #x << " = " << x << endl

using namespace std;

void setIO() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
}

int k;

void read() {
    cin >> k;
}

bool check(const vector<int> &perm) {
    set<int> help(perm.begin(), perm.end());
    int n = perm.size();
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (help.find(__gcd(perm[i], perm[j])) == help.end()) {
                return false;
            }
        }
    }

    return true;
}

bool isLess(const vector<int> &a, const vector<int> &b) {
    int aP = a.size() - 1, bP = b.size() - 1;
    while (aP >= 0 && bP >= 0) {
        if (a[aP] > b[bP]) {
            return false;
        }

        if (a[aP] < b[bP]) {
            return true;
        }

        aP--;
        bP--;
    }

    return (a.size() < b.size() ? true : false);
}

vector<vector<int>> perms;

void precompute() {
    for (int mask = 0; mask < (1 << 22); mask++) {
        vector<int> perm;
        for (int i = 0; i < 22; i++) {
            if (mask & (1 << i)) {
                perm.emplace_back(i + 1);
            }
        }

        if (check(perm)) {
            perms.emplace_back(perm);
        }
    }

    sort(perms.begin(), perms.end(), isLess);
}

void solve() {
    cout << perms[k].size() << ' ';
    for (int i : perms[k]) {
        cout << i << ' ';
    }
    cout << endl;
}

int main() {
    setIO();

    precompute();

    int t;
    cin >> t;

    while (t--) {
        read();

        solve();
    }
}
