/**
* user:  idiriz-fcd
* fname: Nermin Hyusmen
* lname: Idiriz
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:04:23.811868
*/
#include<bits/stdc++.h>
#define endl '\n'
typedef long long ll;
using namespace std;
ll n,m,k;
void go5()
{
    if(k==1&&min(n,m)>1)
    {
        cout<<"YES"<<endl;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
                cout<<1<<" ";
            cout<<endl;
        }
        return;
    }
    if(n==1)
    {
        cout<<"NO"<<endl;
        return;
    }
    if(n==2)
    {
        cout<<"NO"<<endl;
    }
    if(n==3)
    {
        if(m<4)cout<<"NO"<<endl;
        else if(m==4)
        {
            if(k==2)
            {
                cout<<"YES"<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                return;
            }
            else cout<<"NO"<<endl;
        }
    }
    if(n==4)
    {
        if(m<=2)cout<<"NO"<<endl;
        else if(m==3)
        {
            if(k==2)
            {
                cout<<"YES"<<endl;
            cout<<1<<" "<<1<<" "<<1<<endl;
            cout<<1<<" "<<1<<" "<<1<<endl;
            cout<<2<<" "<<2<<" "<<2<<endl;
            cout<<2<<" "<<2<<" "<<2<<endl;
            return;
            }
            else cout<<"NO"<<endl;
        }
        else if(m==4)
        {
            if(k==2)
            {
                cout<<"YES"<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
            }
            else if(k==3)
            {
                cout<<"YES"<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<3<<" "<<3<<endl;
                cout<<1<<" "<<1<<" "<<3<<" "<<3<<endl;
            }
            else if(k==4)
            {
                cout<<"YES"<<endl;
                 cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                 cout<<3<<" "<<3<<" "<<4<<" "<<4<<endl;
                cout<<3<<" "<<3<<" "<<4<<" "<<4<<endl;
            }
            else cout<<"NO"<<endl;
        }

    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        cin>>n>>m>>k;
        if(n<=4&&m<=4)go5();
    }
    return 0;
}
