/**
* user:  alexandru-a70
* fname: Andrei
* lname: Alexandru
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:10:01.915441
*/
#include <bits/stdc++.h> //Andrei Alexandru a.k.a Sho
#include "speedrun.h"
#define ll long long int
#define double long double
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define aint(a) (a).begin(), (a).end()
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 998244353
#define PI 3.14159265359
#define INF 1000000005
#define LINF 1000000000000000005ll
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
vector<ll>g[1005];
string s[1005];
ll ss=0;
ll n;
void assignHints(int subtask,int N,int A[],int B[]){
for(ll i=1;i<N;i++)
{
g[A[i]].pb(B[i]);
g[B[i]].pb(A[i]);
}
setHintLen(251);
ll x=0;
for(ll i=1;i<=N;i++)
{
if(g[i].size()>1){
x=i;
}
}
ss=x;
for(ll i=1;i<=N;i++)
{
for(auto it : g[i]){
ll x=it/4;
setHint(i,x+1,true);
}
}
}
map<ll,ll>viz;
void dfs2(ll node,ll par){
if(node==0){
return;
}
vector<ll>v;
viz[node]=1;
for(ll i=0;i<=250;i++)
{
if(getHint(i+1)==1){
if(i*4<=n&&i*4!=0){
v.pb((i)*4);
}
if(i*4+1<=n){
v.pb((i)*4+1);
}
if(i*4+2<=n){
v.pb(i*4+2);
}
if(i*4+3<=n){
v.pb(i*4+3);
}
}
}
for(auto it : v){
if(viz[it]==1){
continue;
}
goTo(it);
vector<ll>g;
for(ll i=0;i<=250;i++)
{
if(getHint(i+1)==1){
if(i*4<=n&&i*4!=0){
g.pb((i)*4);
}
if(i*4+1<=n){
g.pb((i)*4+1);
}
if(i*4+2<=n){
g.pb(i*4+2);
}
if(i*4+3<=n){
g.pb(i*4+3);
}
}
}
//cout<<it<<endl;
if(g==v){
continue;
}
if(viz[it]==0)
dfs2(it,node);
}
goTo(par);
}
void speedrun(int subtask,int N,int start){
n=N;
dfs2(start,0);
}



