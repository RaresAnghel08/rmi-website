/**
* user:  saprykin-5aa
* fname: Maxim
* lname: Saprykin
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:54:53.412215
*/
#include "speedrun.h"
#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
//#define int ll
typedef pair<int, int> pii;
#define all(a) a.begin(), a.end()
#define _ << ' ' <<
#define vec vector
string convert(int x) {
    string ans;
    for (int i = 0; i < 10; ++i) {
        ans += '0' + x % 2;
        x /= 2;
    }
    return ans;
}
const int TEST = 31;
const int MAXN = 2e3;
vec<int> vrt;
vec<pii> edg;
int p[MAXN];
vec<int> g[MAXN];
void dfs_h(int v, int pp) {
    vrt.push_back(v);
    p[v] = pp;
    for (auto to : g[v]) {
        if (to == pp) continue;
        edg.push_back({v, to});
        dfs_h(to, v);
    }
}
struct Node {
    int p, a, b;
    string bits;
    Node(int p, int a, int b) : p(p), a(a), b(b) {
        bits = convert(p) + convert(a) + convert(b);
    }
    Node(string s) : bits(s) {
        for (int i = 0; i < 3; ++i) {
            int x = 0;
            for (int k = 0; k < 10; ++k) {
                if (getHint(j * 10 + k + 2)) {
                    x |= (1 << k);
                }
            }
            if (i == 0) p = x;
            if (i == 1) a = x;
            if (i == 2) b = x;
        }
    }
    Node() {}
};
Node nd[MAXN];
void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    int n = N;
    if (subtask == 1) {

        int n = N;
        vec<vec<int>> g(n);
        setHintLen(n);
        for (int i = 1; i < n; ++i) {
            setHint(A[i], B[i], 1);
            setHint(B[i], A[i], 1);
        }
        return;
    }
    if (subtask == 2) {
        setHintLen(20);
        set<int> st;
        for (int k = 1; k < n; ++k) {
            int x;
            x = A[k];
            if (st.count(x)) {
                for (int i = 1; i <= n; ++i) {
                    string s = convert(x);
                    for (int j = 0; j < 10; ++j) {
                        setHint(i, j + 1, s[j] == '1');
                    }
                }
                return;
            }
            st.insert(x);
            x = B[k];

            if (st.count(x)) {
                for (int i = 1; i <= n; ++i) {
                    string s = convert(x);
                    for (int j = 0; j < 10; ++j) {
                        setHint(i, j + 1, s[j] == '1');
                    }
                }
                return;
            }
            st.insert(B[k]);
        }
    }
    if (subtask == 3) {
        vec<vec<int>> g(n + 1);
        for (int i = 1; i < n; ++i) {
            g[A[i]].push_back(B[i]);
            g[B[i]].push_back(A[i]);
        }
        setHintLen(20);
        for (int i = 1; i <= n; ++i) {
            string ans;
            for (auto to : g[i]) {
                ans += convert(to);
            }
            assert(ans.size() <= 20);
            for (int j = 0; j < ans.size(); ++j) {
                setHint(i, j + 1, ans[j] == '1');
            }
        }
    }
    if (subtask == 4) {
        vec<vec<int>> g(n + 1);
        for (int i = 1; i < n; ++i) {
            g[A[i]].push_back(B[i]);
            g[B[i]].push_back(A[i]);
        }
        setHintLen(TEST * 10 + 1);
        for (int i = 1; i <= n; ++i) {
            string ans;
            ans += '0' + (g[i].size() > TEST);
            sort(all(g[i]));
            for (int j = 0; j < min(TEST, (int) g[i].size()); ++j) {
                ans += convert(g[i][j]);
            }
            assert(ans.size() <= TEST * 10 + 1);
            for (int j = 0; j < ans.size(); ++j) {
                setHint(i, j + 1, ans[j] == '1');
            }
        }
    }
    if (subtask == 5) {
        setHintLen(30);
        for (int i = 1; i < n; ++i) {
            g[A[i]].push_back(B[i]);
            g[B[i]].push_back(A[i]);
        }
        dfs_h(1, -1);
        for (int i = 0; i < n; ++i) {
            int x = vrt[i];
            int a, b;
            if (i + 1 < n) {
                tie(a, b) = edg[i];
            } else {
                a = 0;
                b = 0;
            }
            nd[x] = Node(p[x], a, b);
        }
        for (int i = 1; i <= n; ++i) {
            string s = nd[i].bits;
            for (int j = 0; j < 30; ++j) {
                if (s[j] == '1') {
                    setHint(i, j + 1, 1);
                }
            }
        }
    }
}
int n;
void dfs(int v, int p) {
    for (int i = 1; i <= n; ++i) {
        if (i == p) continue;
        if (getHint(i)) {
            goTo(i);
            dfs(i, v);
        }
    }
    if (p != -1) {
        goTo(p);
    }
}
void dfs2(int v, int p) {
    for (int j = 0; j < 2; ++j) {
        int x = 0;
        for (int k = 0; k < 10; ++k) {
            if (getHint(j * 10 + k + 1)) {
                x |= (1 << k);
            }
        }
        g[v].push_back(x);
    }
    for (auto to : g[v]) {
        if (to == p || to == 0) continue;
        goTo(to);
        dfs2(to, v);
    }
    if (p != -1) goTo(p);
}
void dfs3(int v, int p) {
    for (int j = 0; j < TEST; ++j) {
        int x = 0;
        for (int k = 0; k < 10; ++k) {
            if (getHint(j * 10 + k + 2)) {
                x |= (1 << k);
            }
        }
        g[v].push_back(x);
    }
    for (auto to : g[v]) {
        if (to == p || to == 0) continue;
        goTo(to);
        dfs3(to, v);
    }
    if (getHint(1)) {
        for (int i = g[v].back() + 1; i <= n; ++i) {
            if (i == p) continue;
            if (goTo(i)) {
                dfs3(i, v);
            }
        }
    }
    if (p != -1) goTo(p);
}
string get(int sz) {
    string ans;
    for (int i = 1; i <= sz; ++i) {
        if (getHint(i)) {
            ans += '1';
        } else {
            ans += '0';
        }
    }
    return ans;
}
void mygo(int u, int v) {
    while (p[u] != -1) {
        goTo(p[u]);
        u = p[u];
    }
    vec<int> path;
    while (p[v] != -1) {
        path.push_back(v);
        v = p[v];
    }
    reverse(all(path));
    for (auto to : path) {
        goTo(to);
    }
}
void speedrun(int subtask, int N, int start) { /* your solution here */
    n = N;
    if (subtask == 1) {
        int l = getLength();
        n = N;
        dfs(start, -1);
        return;
    }
    if (subtask == 2) {
        int x = 0;
        for (int i = 1; i <= 20; ++i) {
            x |= (getHint(i) << (i - 1));
        }
        goTo(x);
        for (int i = 1; i <= n; ++i) {
            if (i == start || i == x) continue;
            goTo(i);
            goTo(x);
        }
    }
    if (subtask == 3) {
        dfs2(start, -1);
    }
    if (subtask == 4) {
        dfs3(start, -1);
    }
    if (subtask == 5) {
        while (start != 1) {
            Node nd(get(30));
            start = nd.p;
            goTo(start);
        }
        p[start] = -1;
        int now = start;
        while (1) {
            Node nd(get(30));
            int u = nd.a;
            int v = nd.b;
            if (u == 0) break;
            mygo(now, u);
            goTo(v);
            p[v] = u;
            now = v;
        }
    }
}
