/**
* user:  gamma-a32
* fname: Pascal
* lname: Gamma
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 10:16:51.617870
*/
#include "speedrun.h"
#include <bits/stdc++.h>

#ifndef LOCAL
#define dbg(x)
#else
#define dbg(x) cerr << #x << " = " << x << "\n";
#endif

using namespace std;

void assignHints(int subtask, int N, int A[],
                 int B[]) { /* your solution here */
  setHintLen(20);
  vector<vector<int>> g(N + 1, vector<int>());
  for (int i = 1; i < N; i++) {
    dbg(A[i]);
    dbg(B[i]);
    g[A[i]].push_back(B[i]);
    g[B[i]].push_back(A[i]);
  }
  for (int i = 1; i <= N; i++) {
    int x = g[i][0];
    for (int j = 1; j <= 10; j++) {
      if (x % 2) {
        setHint(i, j, true);
      }
      x /= 2;
    }

    if (g[i].size() == 2) {
      int x = g[i][1];
      for (int j = 11; j <= 20; j++) {
        if (x % 2) {
          setHint(i, j, true);
        }
        x /= 2;
      }
    }
  }
}

int get_a() {
  int a = 0;
  for (int j = 1; j <= 10; j++) {
    if (getHint(j)) {
      a += 1 << (j - 1);
    }
  }
  return a;
}

int get_b() {
  int b = 0;
  for (int j = 11; j <= 20; j++) {
    if (getHint(j)) {
      b += 1 << (j - 11);
    }
  }
  return b;
}

void dfs(int u, int p) {
  dbg(u);
  int a = get_a();
  int b = get_b();
  dbg(a);
  dbg(b);
  if (a != 0 && a != p) {
    goTo(a);
    dfs(a, u);
    goTo(u);
  }
  if (b != 0 && b != p) {
    goTo(b);
    dfs(b, u);
    goTo(u);
  }
}

void speedrun(int subtask, int N, int start) { /* your solution here */
  dfs(start, start);
}
