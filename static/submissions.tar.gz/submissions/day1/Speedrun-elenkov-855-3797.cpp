/**
* user:  elenkov-855
* fname: Kaloyan Georgiev
* lname: Elenkov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:37:15.250954
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;
vector<int> sus[1001];
stack<int> seg;
int len;
void dfs(int wruh,int par){
    int yo=par;
    for(int i=len+1;yo!=0;i++){
            bool u=yo%2;
            setHint(wruh,i,u);
            yo/=2;
    }
    if(sus[wruh].size()==1 && wruh!=1){
        if(!seg.empty()){
            int oi=seg.top();
            seg.pop();
            for(int i=1;oi!=0;i++){
                bool u=oi%2;
                setHint(wruh,i,u);
                oi/=2;
            }
        }
        return ;
    }
    int oi,za;
    if(sus[wruh][0]!=par){
        oi=sus[wruh][0];
        za=sus[wruh][0];
    }else{
        oi=sus[wruh][1];
        za=sus[wruh][1];
    }
    for(int i=1;oi!=0;i++){
        bool u=oi%2;
        setHint(wruh,i,u);
        oi/=2;
    }
    if(sus[wruh].size()>2){
        for(int i=0;i<sus[wruh].size();i++){
            if(sus[wruh][i]!=za && sus[wruh][i]!=par){
                dfs(sus[wruh][i],wruh);
            }
        }
    }
}
void assignHints(int subtask, int N, int A[], int B[]){
    for(int i=1;i<N;i++){
        sus[A[i]].push_back(B[i]);
        sus[B[i]].push_back(A[i]);
    }
    int k=0,kl=N;
    while(kl!=0){
        kl/=2;
        k++;
    }
    setHintLen(k*2);
    len=k;
    dfs(1,0);
}
stack<int> inf;
long long uk;
bool dali[1001];
void df(int wruh){
    dali[wruh]=1;
    int du=0,ot=0,st=1;
    for(int i=1;i<=uk;i++){
        du+=(getHint(i)*st);
        st*=2;
    }
    st=1;
    for(int i=(uk+1);i<=(2*uk);i++){
        ot+=(getHint(i)*st);
        st*=2;
    }
    if(du!=0 && goTo(du)){
        df(du);
        while(!inf.empty()){
            int lok=inf.top();
            if(goTo(lok)){
                inf.pop();
                df(lok);
            }else{
                break;
            }
        }
    }else{
        if(du!=0){
            inf.push(du);
        }
    }
    if(ot!=0){
        goTo(ot);
        if(!dali[ot]){
            df(ot);
        }
    }
}
void speedrun(int subtask, int N, int start){
    uk=getLength()/2;
    df(start);
}
