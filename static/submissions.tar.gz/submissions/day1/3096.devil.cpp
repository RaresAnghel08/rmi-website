/**
* user:  bazac-891
* fname: Tudor
* lname: Bazac
* task:  devil
* score: 0.0
* date:  2019-10-10 10:30:58.268231
*/
#include <bits/stdc++.h>

using namespace std;

int f[100],v[100010];

int cmmdc(int a,int b)
{
    int aux;
    while(b>0)
    {
        aux=b;
        b=a%b;
        a=aux;
    }
    return a;
}

int main()
{
    int t,k,i,s,s1,j,a,x,y,z;
    cin>>t;
    while(t>0)
    {
        t--;
        s=0;
        memset(f,0,400);
        cin>>k;
        for(i=1;i<=9;i++)
        {
            cin>>f[i];
            s=s+f[i];
        }
        x=0;
        for(i=3;i<=9;i++)
            x=x+f[i];
        if(x==0)
        {
            x=f[1];
            y=f[2];
            z=y/x;
            if(z>k)
            {
                for(i=1;i<=x;i++)
                    v[i]=1;
                for(i=x;i<x+y;i++)
                    v[i]=2;
                for(i=1;i<=s;i++)
                    cout<<v[i];
            }
            else
            {
                a=1;
                for(i=1;i<=x+y;i++)
                {
                    if(a==1)
                        v[i]=1;
                    else
                        v[i]=2;
                    a=1-a;
                }
                for(i=1;i<=s;i++)
                    cout<<v[i];
            }
        }
        else
        {
            for(i=9;i>=1;i--)
                if(f[i]!=0)
                {
                    f[i]--;
                    v[s]=i;
                    break;
                }
            for(j=1;j<=9;j++)
                if(f[j]!=0)
                {
                    f[j]--;
                    v[s-1]=j;
                    break;
                }
            for(i=9;i>=1;i--)
                if(f[i]!=0)
                {
                    f[i]--;
                    v[s-2]=i;
                    break;
                }
            s1=s;
            s=s-3;
            while(s>0)
            {
                j=1;
                i=9;
                if(f[j]==0)
                {
                    for(j=1;j<=9;j++)
                        if(f[j]!=0)
                        {
                            v[s]=j;
                            break;
                        }
                }
                else
                    v[s]=j;
                if(f[i]==0)
                {
                    for(i=9;i>=1;i--)
                        if(f[i]!=0)
                        {
                            v[s-1]=i;
                            break;
                        }
                }
                else
                    v[s-1]=i;
                s=s-2;
                f[j]--;
                f[i]--;
            }
            for(i=1;i<=s1;i++)
                cout<<v[i];
        }
    }
    return 0;
}
