/**
* user:  nemeth-0f0
* fname: Márton
* lname: Németh
* task:  Present
* score: 8.0
* date:  2021-12-16 11:02:12.942129
*/
#include <bits/stdc++.h>

using namespace std;

int t;

void solve(int k) {
    if (k==0) {
        cout << 0 << endl;
        return;
    }
    bool ok;
    int c;
    int ans=0;
    for (int i=1;i<pow(2,8);i++) {
        ok=1;
        for (int a=1;a<=8;a++) {
            for (int b=1;b<=8;b++) {
                if (((i>>(a-1))%2==1)&&((i>>(b-1))%2==1)) {
                    c=__gcd(a,b);
                    if ((i>>(c-1))%2!=1) {
                        ok=0;
                        break;
                    }
                }
            }
            if (ok==0) {
                break;
            }
        }
        if (ok==1) {
            k--;
        }
        if (k==0) {
            for (int a=1;a<=8;a++) {
                if ((i>>(a-1))%2==1) {
                    ans++;
                }
            }
            cout << ans << " ";
            for (int a=1;a<=8;a++) {
                if ((i>>(a-1))%2==1) {
                    cout << a << " ";
                }
            }
            cout << endl;
            return;
        }
    }
}

int main()
{
    cin >> t;
    int k;
    for (int i=0;i<t;i++) {
        cin >> k;
        solve(k);
    }
    return 0;
}
