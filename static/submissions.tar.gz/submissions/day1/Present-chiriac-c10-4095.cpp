/**
* user:  chiriac-c10
* fname: Matei
* lname: Chiriac
* task:  Present
* score: 0.0
* date:  2021-12-16 11:56:58.939738
*/
#include <bits/stdc++.h>

using namespace std;

long long t;
bool iesi;

void bkt(int mx, long long &nr, vector<int> &v)
{
    if(iesi)
        return;

    if(mx == 0)
    {
        nr--;

        if(nr == -1)
        {
            cout<<v.size()<<' ';
            for(int it : v)
                cout<<it<<' ';
            iesi=true;
        }

        return;
    }

    bool ok=true;
    for(int i=0;i<(int)v.size();i++)
        for(int j=i+1;j<(int)v.size();j++)
            if(__gcd(v[i], v[j]) == mx)
                ok=false;

    if(ok)
        bkt(mx-1, nr, v);

    if(iesi)
        return;

    v.push_back(mx);
    bkt(mx-1, nr, v);

    if(iesi)
        return;

    v.pop_back();
}

int main()
{
    cin>>t;
    while(t)
    {
        t--;
        long long nr;
        cin>>nr;

        vector<int> ans;
        iesi=false;
        bkt(2, nr, ans);
    }
    return 0;
}
