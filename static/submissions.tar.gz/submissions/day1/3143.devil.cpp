/**
* user:  todoran-c08
* fname: Alexandru Raul
* lname: Todoran
* task:  devil
* score: 0.0
* date:  2019-10-10 10:34:40.831649
*/
#include <bits/stdc++.h>

using namespace std;

const int S_MAX = 1000002;

int t;

int k;

int cnt[10];

string smx[S_MAX];

vector <string> v1, v2;

int main()
{
    cin >> t;
    while(t--)
    {
        cin >> k;
        int mx = 0;
        for(int i = 1; i <= 9; i++)
        {
            cin >> cnt[i];
            if(cnt[i] > 0)
                mx = i;
        }
        string sr = "";
        while(sr.size() + 1 < k)
        {
            sr += char('1' + mx - 1);
            cnt[mx]--;
            while(mx > 0 && cnt[mx] == 0)
                mx--;
        }
        reverse(sr.begin(), sr.end());
        int cntmx = cnt[mx];
        for(int i = 1; i <= cntmx; i++)
            smx[i] = char('1' + mx - 1);
        cnt[mx] = 0;
        int mxlg = 1;
        while(true)
        {
            int sum = 0;
            for(int i = 1; i <= 9; i++)
                sum += cnt[i];
            if(sum == 0)
                break;
            int c = 0;
            for(int i = 1; i <= 9; i++)
            {
                while(c < cntmx && cnt[i] > 0)
                {
                    c++;
                    smx[c] += char('1' + i - 1);
                    mxlg = max(mxlg, (int)smx[c].size());
                    cnt[i]--;
                }
            }
        }
        v1.clear();
        v2.clear();
        for(int i = 1; i <= cntmx; i++)
            if(smx[i].size() == mxlg)
                v2.push_back(smx[i]);
            else
                v1.push_back(smx[i]);
        while(v2.size() > 0 && v1.size() > 0)
        {
            for(int i = 0; i < v1.size(); i++)
                if(v2.size() > 0)
                {
                    v1[i] += v2.back();
                    v2.pop_back();
                }
        }
        while(v2.size() > 0)
        {
            cout << v2.back();
            v2.pop_back();
        }
        for(int i = v1.size() - 1; i >= 0; i -= 2)
            cout << v1[i];
        for(int i = v1.size() - 2; i >= 0; i -= 2)
            cout << v1[i];
        cout << sr << "\n";
    }
    return 0;
}
