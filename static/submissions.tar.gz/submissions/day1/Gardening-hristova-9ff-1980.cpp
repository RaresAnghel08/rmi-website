/**
* user:  hristova-9ff
* fname: Simona Nikolaeva
* lname: Hristova
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:47:58.423852
*/
#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>
#include <cstring>
#include <algorithm>

using namespace std;
int t;
void query()
{
    int n,m,k;
    cin>>n>>m>>k;
    if(k==1)
    {
        cout<<"YES"<<endl;
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
                cout<<1<<" ";
            cout<<endl;
        }
        return;
    }
    if(k==2)
    {
        if(n==2&&m==4)
        {
            cout<<"YES"<<endl;
            cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
            cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
            return;
        }
        if(n==4&&m==2)
        {
            cout<<"YES"<<endl;
            cout<<1<<" "<<1<<endl;
            cout<<1<<" "<<1<<endl;
            cout<<2<<" "<<2<<endl;
            cout<<2<<" "<<2<<endl;
            return;
        }
        if(n==4&&m==4)
        {
            cout<<"YES"<<endl;
            cout<<1<<" "<<1<<" "<<1<<" "<<1<<endl;
            cout<<1<<" "<<2<<" "<<2<<" "<<1<<endl;
            cout<<1<<" "<<2<<" "<<2<<" "<<1<<endl;
            cout<<1<<" "<<1<<" "<<1<<" "<<1<<endl;
            return;
        }
    }
    if(k==4)
    {
        if(n==4&&m==4)
        {
            cout<<"YES"<<endl;
            cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
            cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
            cout<<3<<" "<<3<<" "<<4<<" "<<4<<endl;
            cout<<3<<" "<<3<<" "<<4<<" "<<4<<endl;
            return;
        }
    }
    cout<<"NO"<<endl;
}
void solve()
{
    cin>>t;
    for(int i=0; i<t; i++)
    {
        query();
    }
}
int main()
{
    solve();
    return 0;
}
/*
1 1 1
1 2 1
1 2 2
1 3 1
1 3 2
1 3 3
1 4 1
1 4 2
1 4 3
1 4 4
2 1 1
2 1 2
2 2 1
2 2 2
2 2 3
2 2 4
2 3 1
2 3 2
2 3 3
2 3 4
2 3 5
2 3 6
2 4 1
2 4 2
2 4 3
2 4 4
2 4 5
2 4 6
2 4 7
2 4 8
*/
