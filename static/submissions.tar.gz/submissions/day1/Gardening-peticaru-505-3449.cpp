/**
* user:  peticaru-505
* fname: Alexandru
* lname: Peticaru
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:07:16.798848
*/
#include <bits/stdc++.h>
#define ll long long
#define ld long double

using namespace std;

const ll MOD = 1e9 + 7;
const ll INF = 1e9;

int k, n, m, v[5][200002];

int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  int t;
  cin >> t;
  while (t--) {
    cin >> n >> m >> k; 
    bool ok = 1;
    if (n % 2 != 0 || m % 2 != 0) {
      cout << "NO\n";
      continue;
    }
    if (n == 2) {
      if (k != m / 2) {
        cout << "NO\n";
        ok = 0;
      }
      for (int i = 1; i <= m; i+=2) 
        v[1][i] = v[2][i] = v[2][i + 1] = v[1][i + 1] = k--;
    }
    if (n == 4) {
      if (k >= m && k <= 2 * m && k != 2 * m - 1){
        cout << "YES\n";
        int t = 2 * (k - m);
        for (int i = 1; i <= t; i++) {
          v[1][i] = v[n][i] = k;    
        }
        v[2][1] = v[3][1] = v[2][t] = v[3][t] = k;
        k--;
        for (int i = 2; i < t; i+=2)
          v[2][i] = v[3][i] = v[3][i + 1] = v[2][i + 1] = k--;
        for (int i = t + 1; i <= m; i+=2) {
          v[1][i] = v[2][i] = v[1][i + 1] = v[2][i + 1] = k--;
          v[3][i] = v[4][i] = v[3][i + 1] = v[4][i + 1] = k--;
        }
        for (int i = 1; i <= n; i++, cout << "\n")
          for (int j = 1; j <= m; j++)
            cout << v[i][j] << " ";
      }
      else {
        cout << "NO\n";
      }
    }
  }

  
    
  return 0;
}
