/**
* user:  kitanovski-9bd
* fname: Teo 
* lname: Kitanovski
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:09:51.173372
*/
#include <bits/stdc++.h>
#include "speedrun.h"

typedef long long ll;

#define MS(x,y) memset((x), (y), sizeof((x)))
#define pb push_back
#define MN 1000000000

using namespace std;

void assignHints (int subtask_id, int n, int a[], int b[]) {
    setHintLen(n);

    for (int i = 0; i<n-1; i++) {
        setHint(a[i+1],b[i+1],1);
        setHint(b[i+1],a[i+1],1);
    }
}

bool vis[1001];
int n,s;
bool solv = false;

void dfs (int pos, int parnt, int num) {
    if (solv) return;
    if (num == n) {
        solv = true;
        return;
    }

    for (int i = 0; i<n; i++) {
        if (vis[i]) continue;
        if (i == pos) continue;

        if (getHint(i+1) == 1) {
            vis[i] = true;
            goTo(i+1);
            dfs(i,pos,num+1);
           // vis[i] = false;
        }
    }

    if (pos != s) goTo(parnt+1);
}

void speedrun(int subtask_id, int n2, int s2) {
    n = n2; s = s2;

    vis[s] = true;

    dfs(s,-1,1);
}

//int main() {
//    #ifdef LOCAL_DEBUG
//        fstream cin("in.txt");
//    #endif
//
//    ios_base::sync_with_stdio(false);
//    cin.tie(0);
//    cout.tie(0);
//
//
//}
