/**
* user:  yanev-d24
* fname: Aleksandar
* lname: Yanev
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:31:39.804139
*/
#include<bits/stdc++.h>
using namespace std;
unsigned long long num,br;
int check(int i)
{
    while(i>10)
    {
        if(i%100==13)return 1;
        i/=10;
    }
    return 0;
}
int main()
{
    unsigned long long n,q;
    cin>>n>>q;
    cin>>num;
    for(int i=13;i<=num;i++)
    {
        br+=check(i);
        br%=1000000007;
    }
    cout<<(num-br)%1000000007<<endl;
}
