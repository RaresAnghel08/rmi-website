/**
* user:  volkov-d03
* fname: Ivan
* lname: Volkov
* task:  restore
* score: 0.0
* date:  2019-10-10 08:36:09.672855
*/
#include <iostream>
#include <set>
#include <cstring>
#include <vector>

using namespace std;

const int MAX_N = 1e4 + 7;
set <int> g1[MAX_N];
vector <int> g2[MAX_N];
int ans[MAX_N];
bool ok[MAX_N];

int main() {
    //freopen("Desktop/input.txt", "r", stdin);
    memset(ok, 0, sizeof(ok));
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < n; i++) ans[i] = -1;
    vector <pair <int, int>> zero, one;
    for (int i = 0; i < m; i++) {
        int l, r, k, val;
        cin >> l >> r >> k >> val;
        if (k == 1) {
            if (val == 1) {
                for (int j = l; j <= r; j++) {
                    if (ans[j] == 0) {
                        cout << -1 << endl;
                        return 0;
                    }
                    ans[j] = 1;
                }
            } else {
                zero.push_back({l, r});
            }
        } else {
            if (val == 0) {
                for (int j = l; j <= r; j++) {
                    if (ans[j] == 1) {
                        cout << -1 << endl;
                        return 0;
                    }
                    ans[j] = 0;
                }
            } else {
                zero.push_back({l, r});
            }
        }
    }
    int a = zero.size(), b = one.size();
    for (int i = 0; i < a; i++) {
        int l = zero[i].first, r = zero[i].second;
        for (int j = l; j <= r; j++) {
            if (ans[j] == 0) {
                ok[i] = 1;
                break;
            }
            if (ans[j] == -1) {
                g1[i].insert(j);
                g2[j].push_back(i);
            }
        }
    }
    for (int i = 0; i < b; i++) {
        int l = one[i].first, r = one[i].second;
        for (int j = l; j <= r; j++) {
            if (ans[j] == 1) {
                ok[a + i] = 1;
                break;
            }
            if (ans[j] == -1) {
                g1[a + i].insert(j);
                g2[j].push_back(a + i);
            }
        }
    }
    vector <int> lonely;
    for (int i = 0; i < a + b; i++) {
        if (!ok[i]) {
            if ((int) g1[i].size() == 0) {
                cout << -1 << endl;
                return 0;
            }
            if ((int) g1[i].size() == 0) lonely.push_back(i);
        }
    }
    while (!lonely.empty()) {
        int x = lonely.back();
        lonely.pop_back();
        if (ok[x]) continue;
        if (x < a) {
            int pos = *(g1[x].begin());
            ans[pos] = 0;
            for (int elem : g2[pos]) {
                if (!ok[elem]) {
                    if (elem < a) ok[elem] = 1;
                    else {
                        g1[elem].erase(pos);
                        if ((int) g1[elem].size() == 1) {
                            lonely.push_back(elem);
                        }
                        if ((int) g1[elem].size() == 0) {
                            cout << -1 << endl;
                            return 0;
                        }
                    }
                }
            }
        } else {
            int pos = *(g1[x].begin());
            ans[pos] = 1;
            for (int elem : g2[pos]) {
                if (!ok[elem]) {
                    if (elem >= a) ok[elem] = 1;
                    else {
                        g1[elem].erase(pos);
                        if ((int) g1[elem].size() == 1) {
                            lonely.push_back(elem);
                        }
                        if (g1[elem].empty()) {
                            cout << -1 << endl;
                            return 0;
                        }
                    }
                }
            }
        }
    }
    int lst = 1;
    for (int i = 0; i < n; i++) {
        if (ans[i] == -1) {
            ans[i] = 1 - lst;
            lst = ans[i];
        }
    }
    for (int i = 0; i < n; i++) {
        cout << ans[i] << ' ';
    }
    cout << endl;
    return 0;
}
