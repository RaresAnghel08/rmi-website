/**
* user:  gerasikov-855
* fname: Vladimir
* lname: Gerasikov
* task:  Gardening
* score: 11.0
* date:  2021-12-16 11:54:51.414267
*/
#include <bits/stdc++.h>

using namespace std;

#define vc vector
typedef int ll;

ll ans[10][200005];

int main() {
    ll q;
    cin >> q;
    while (q--) {
        ll n, m, k;
        cin >> n >> m >> k;
        if ((n & 1) || (m & 1)) {
            cout << "NO\n";
        } else {
            if (n == 2) {
                if (n * m / 4 != k) {
                    cout << "NO\n";
                    continue;
                }
                cout << "YES\n";
                for (ll i = 0; i < m / 2; ++i) {
                    cout << i + 1 << ' ' << i + 1 << ' ';
                }
                cout << '\n';
                for (ll i = 0; i < m / 2; ++i) {
                    cout << i + 1 << ' ' << i + 1 << ' ';
                }
                cout << '\n';
            } else {
                if (n * m / 4 < k) {
                    cout << "NO\n";
                    continue;
                }
                if ((k & 1) && k + 1 == m) {
                    cout << "NO\n";
                    continue;
                }
                for (ll i = 0; i < m; ++++i) {
                    ans[0][i] = i + 1;
                    ans[1][i] = i + 1;
                    ans[0][i + 1] = i + 1;
                    ans[1][i + 1] = i + 1;
                }
                for (ll i = 0; i < m; ++++i) {
                    ll c = i;
                    ans[2][i] = c + 2;
                    ans[3][i] = c + 2;
                    ans[2][i + 1] = c + 2;
                    ans[3][i + 1] = c + 2;
                }
                ll c = (k / 2) * 2 + 2;
                ll ind = m - 4;
                ll cnt = m;
                while (k + 1 < cnt) {
                    if (ind < 0) break;
                    ----cnt;
                    c -= 2;
                    ans[0][ind] = c;
                    ans[1][ind] = c;
                    ans[2][ind] = c;
                    ans[3][ind] = c;
                    ans[0][ind + 3] = c;
                    ans[1][ind + 3] = c;
                    ans[2][ind + 3] = c;
                    ans[3][ind + 3] = c;
                    ans[0][ind + 1] = c;
                    ans[0][ind + 2] = c;
                    ans[3][ind + 1] = c;
                    ans[3][ind + 2] = c;
                    --c;
                    ans[1][ind + 1] = c;
                    ans[1][ind + 2] = c;
                    ans[2][ind + 1] = c;
                    ans[2][ind + 2] = c;
                    ++c;
                    ind -= 4;
                }
//                for (ll i = 0; i < n; ++i) {
//                    for (ll j = 0; j < m; ++j) {
//                        cout << ans[i][j] << ' ';
//                    }
//                    cout << '\n';
//                }
                if (k < cnt && k + 1 == cnt) {
                    ind += 2;
                    if (ind < 0) {
                        cout << "NO\n";
                        continue;
                    }
                    --cnt;
                    ans[0][ind] = c;
                    ans[0][ind + 1] = c;
                    ans[1][ind] = c;
                    ans[2][ind] = c;
                    ans[3][ind] = c;
                    ans[3][ind + 1] = c;
                    ans[1][ind + 1] = k;
                    ans[1][ind + 2] = k;
                    ans[2][ind + 2] = k;
                    ans[2][ind + 1] = k;
                }
                if (k < cnt) {
                    cout << "NO\n";
                    continue;
                }
                cout << "YES\n";
                for (ll i = 0; i < n; ++i) {
                    for (ll j = 0; j < m; ++j) {
                        cout << ans[i][j] << ' ';
                    }
                    cout << '\n';
                }

            }
        }
    }
}