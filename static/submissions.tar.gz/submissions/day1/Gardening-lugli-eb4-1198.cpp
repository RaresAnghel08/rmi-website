/**
* user:  lugli-eb4
* fname: Francesco
* lname: Lugli
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:16:47.040660
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve()
{
	ll N, M, K;
	cin >> N >> M >> K;
	if (N == 1 || M == 1)
	{
		cout << "No\n";
		return;
	}
	if (N == 4)
	{
		if (K > M)
		{
			cout << "No\n";
			return;
		}
		cout << "Yes\n";

		for (ll i = 0; i < M - (M%2); i++)
		{
			cout << min(i/2, K-1) << " ";
		}
		if (M%2) cout << min((M-2)/2, K-1) << " ";
		cout << "\n";

		for (ll i = 0; i < M - (M%2); i++)
		{
			cout << min(i/2, K-1) << " ";
		}
		if (M%2) cout << min((M-2)/2, K-1) << " ";
		cout << "\n";

		for (ll i = 0; i < M - (M%2); i++)
		{
			cout << min((i+M)/2, K-1) << " ";
		}
		if (M%2) cout << min(M-1, K-1) << " ";
		cout << "\n";

		for (ll i = 0; i < M - (M%2); i++)
		{
			cout << min((i+M)/2, K-1) << " ";
		}
		if (M%2) cout << min(M-1, K-1) << " ";
		cout << "\n";

		return;
	}
	if (K*2 > M)
	{
		cout << "No\n";
		return;
	}
	cout << "Yes\n";
	for (int r = 0; r < N; r++)
	{
		for (int i = 0; i < K; i++)
		{
			if (i != K-1)
			{
				cout << (i+1) << " ";
				cout << (i+1) << " ";
			}
			else
			{
				for (int c = K*2-2; c < M; c++) cout << (i+1) << " ";
			}
		}
		cout << "\n";
	}
}
int main()
{
	ll T;
	cin >> T;
	while(T--)
	{
		solve();
	}
}
