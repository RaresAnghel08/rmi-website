/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  lucky
* score: 14.0
* date:  2019-10-10 07:31:59.083863
*/
#include<bits/stdc++.h>
using namespace std;
#define ll long long
string x;
ll k;
ll q;
ll ans=0;
bool ok(string s1,string s2,ll t)
{
	for(ll i=s2.size()-1;i>=0;i--)
	{
		if(s2[i]=='o')
		{
			s2[i]=t%10+'0';
			t/=10;
		}
	}
	if(s1>s2)return 1;
	return 0;
}
void gen(ll i,ll count,string s)
{
	if(i==x.size())
	{
		ll mid,ans1=0,l1=0,r1=pow(10,x.size()-count*2)-1;
		while(l1<=r1)
		{
			mid=(l1+r1)/2;
			if(ok(x,s,mid))
			{
				ans1=mid;l1=mid+1;
			}
			else r1=mid-1;
		}
		ans1++;
		if(count%2==1){/*cout<<s<<" "<<ans1<<endl;*/ans+=ans1;}
		else {ans-=ans1;/*cout<<s<<" "<<-ans1<<endl;*/}
		return;
	}
	gen(i+1,count,s+"o");
	if(i+2<=x.size())gen(i+2,count+1,s+"13");
	
}
int main()
{
	ll n,q;cin>>n>>q;
	cin>>x;
	for(ll i=0;i<n;i++)
	{
		k*=10;k+=x[i]-'0';
	}
	gen(0,0,"");
	cout<<-ans+1<<endl;
return 0;
}
