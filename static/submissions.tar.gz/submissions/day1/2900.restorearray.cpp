/**
* user:  gasan-03e
* fname: Carol Luca
* lname: Gasan
* task:  restore
* score: 0.0
* date:  2019-10-10 10:12:10.161817
*/
#include <iostream>
using namespace std;
struct ee
{
    int l,r,k,minn;
}v[500];
bool f[500];
int main()
{
    int n,m,aa;
    cin>>n>>m;
    if(n<=18)
    {
        for(int i=1;i<=m;++i)
        cin>>v[i].l>>v[i].r>>v[i].k>>v[i].minn,v[i].l++,v[i].r++;
        int p=1;
        for(int i=1;i<=18;++i)
            p*=2;
        p*=4;
        bool ok=0;
        while(p>0)
        {
            for(int i=1;i<=n;++i)
                f[i]=p%2,p/=2;
                bool kk=0;
            for(int i=1;i<=m and kk==0;++i)
            {
                int xw;
                int t=0;for(int j=v[i].l;j<=v[i].r;++j)
                {
                    if(f[j]==0)
                        t++;
                }
                                        if(t<v[i].k)
                                            xw=1;
                                        else xw=0;
                    if(xw!=v[i].minn)
                        kk=1;
            }
            if(kk==0)
            {
                for(int i=1;i<=n;++i)
                    cout<<f[i]<<" ";
                return 0;
            }
            --p;

        }
        cout<<-1;
    }
    return 0;
}
