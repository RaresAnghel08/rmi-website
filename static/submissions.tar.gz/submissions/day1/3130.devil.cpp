/**
* user:  tinca-6db
* fname: Matei
* lname: Tinca
* task:  devil
* score: 14.0
* date:  2019-10-10 10:33:37.573562
*/
#include <bits/stdc++.h>

using namespace std;

void solvetest() {
	int S = 0, K, d[10];
	scanf("%d", &K);
	for(int i = 1; i <= 9; ++i) {
		scanf("%d", &d[i]);
		S += d[i];
	}
	
	// K == 2
	int trashdig = 9;
	while(trashdig >= 0 && d[trashdig] == 0)
		--trashdig;
	d[trashdig]--;

	string rez(S, '0');

	if((S - 1) % 2 == 0) {
		for(int i = S - 3; i >= 0; i -= 2) {
			int dig = 9;
			while(d[dig] == 0)
				--dig;

			rez[i] = dig + '0';
			--d[dig];
		}
		for(int i = 1; i < S - 1; i += 2) {
			int dig = 9;
			while(d[dig] == 0)
				--dig;
			rez[i] = dig + '0';
			--d[dig];
		}
	} else {
		for(int i = S - 3; i >= 0; i -= 2) {
			int dig = 9;
			while(d[dig] == 0)
				--dig;
			rez[i] = dig + '0';
			--d[dig];
		}
		for(int i = 0; i < S - 1; i += 2) {
			int dig = 9;
			while(d[dig] == 0)
				--dig;
			rez[i] = dig + '0';
			--d[dig];
		}
	}

	rez[S - 1] = trashdig + '0';
	printf("%s\n", rez.c_str());

	// d[1], d[2] != 0
	/*int d1 = d[1], d2 = d[2], S = d1 + d2;
	if(d2 >= K) {
		d2 -= K;
		for(int i = 0; i < K - 1; ++i)
			printf("2");
	} else {
		for(int i = 0; i < d1; ++i)
			printf("1");
		for(int i = 0; i < d2; ++i)
			printf("2");
		printf("\n");
	}*/
}

int main() {
	int t;
	scanf("%d", &t);
	while(t--)
		solvetest();
	return 0;
}


