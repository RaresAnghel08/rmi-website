/**
* user:  sandulescu-a1f
* fname: Alexandru Nicolae
* lname: Săndulescu
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 10:42:41.277360
*/
#include "speedrun.h"
#include <unordered_map>
#include <vector>
#include <iostream>


std::unordered_map<int, std::vector<int>> nodes;
std::unordered_map<int, int> lastidx;

int subtask = 1;

void df_1(int node, int from = -1)
{
    if(subtask == 1)
    {
        for(auto it : nodes[node])
            if(it != from)
            {
                setHint( node, it, 1);
                setHint( it, node, 1);
                df_1(it, node);
            }
    }
    else
    {
        for(auto it : nodes[node])
        {
            if(it != from)
            {
                for(int i = lastidx[node] + 1; i <= lastidx[node] + 10; i++)
                {
                    setHint(node, i, it & (1 << (i - lastidx[node] - 1)));
                }
                lastidx[node] += 10;

                for(int i = lastidx[it] + 1; i <= lastidx[it] + 10; i++)
                {
                    setHint(it, i, node & (1 << (i - lastidx[it] - 1)));
                }
                lastidx[it] += 10;
                df_1(it, node);
            }
        }
    }


}
void assignHints(int sb, int N, int A[], int B[])   /* your solution here */
{
    subtask = sb;
    for(int i = 1; i < N; i++)
    {
        nodes[A[i]].push_back(B[i]);
        nodes[B[i]].push_back(A[i]);
    }
    if(subtask == 1)
    {
        setHintLen(N);
        df_1(1);
    }
    else if(subtask == 2)
    {
        setHintLen(1);
        for(auto& v : nodes)
        {
            if(v.second.size() == N - 1)
            {
                setHint(v.first, 1, true);
                break;
            }
        }
    }
    else
    {
        setHintLen(20);
        df_1(1);
    }

}

void df_2(int N, int node, int from = -1)
{
    if(subtask == 3)
    {

        int gt = 0;
        for(int i = 1; i <= 10; i++)
            gt |= getHint(i) << (i - 1);
        if(gt != 0 && gt != from)
        {
            goTo(gt);
            df_2(N, gt, node);
            goTo(node);
        }


        gt = 0;
        for(int i = 11; i <= 20; i++)
            gt |= getHint(i) << (i - 11);

        if(gt != 0 && gt != from)
        {
            goTo(gt);
            df_2(N, gt, node);
            goTo(node);
        }
    }
    else
    {
        for(int i = 1; i <= N; i++)
            if(getHint(i) && i != from && i != node)
            {
                goTo(i);
                df_2(N, i, node);
                goTo(node);
            }
    }
}


void speedrun(int sb, int N, int start)
{
    subtask = sb;
    if(subtask == 1 || subtask == 3)
    {
        df_2(N, start);
    }
    else if(subtask == 2)
    {
        for(int i = 1; i <= N; i++)
        {
            if(goTo(i) == true)
            {
                if(getHint(1) == true)
                {
                    for(int j = 1; j <= N; j++)
                    {
                        if(i == j) continue;
                        goTo(j);
                        goTo(i);
                    }
                }
                else
                {
                    goTo(start);
                }
            }
        }
    }
}

