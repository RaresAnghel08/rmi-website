/**
* user:  asamidinov-40d
* fname: Temirlan
* lname: Asamidinov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:12:03.082637
*/
#include<bits/stdc++.h>;
using namespace std;
int o, n, m, k;
int arr[10][200001];

void get(){
	cin>>n>>m>>k;
	if(k*3 > n*m){
		cout<<"NO"<<endl;
		return;
	}
	cout<<"YES"<<endl;
	int ok = 0;
	if(n < m){
		swap(n,m);
		ok = 1;
	}
	int l = 0;
	for(int i=1; i<=n; i++){
		for(int j=1; j<=m-3; j+=3){
			for(int l=j; l<j+3; l++){
				arr[i][l] = (k == 0 ? 1 : k);
			}
			k--;
		}
		if(m % 3 == 1){
			arr[i][m] = (i % 3 == 1 ? k : arr[i-1][m]);
			if(i % 3 == 1)k--;
		}
		else if(m % 3 == 2){
			arr[i][m-1] = (i % 3 == 1 ? k : arr[i-1][m-1]);
			if(i % 3 == 1)k--;
			
			arr[i][m] = (i % 3 == 1 ? k : arr[i-1][m]);
			if(i % 3 == 1)k--;
		}
	}
	if(!ok){
		for(int i=1; i<=n; i++){
			for(int j=1; j<=m; j++){
				if(arr[i][j] > 0)cout<<arr[i][j]<<" ";	
				else{
					cout<<(arr[i-1][j] == 0 ? 1 : arr[i-1][j])<<" ";
					arr[i][j] = arr[i-1][j];
				}
			}
			cout<<endl;
		}
	}
	else{
		for(int j=1; j<=m; j++){
			for(int i=1; i<=n; i++){
			
				if(arr[i][j] > 0)cout<<arr[i][j]<<" ";	
				else{
					cout<<(arr[i-1][j] == 0 ? 1 : arr[i-1][j])<<" ";
					arr[i][j] = arr[i-1][j];
				}
			}
			cout<<endl;
		}
	}
}
main(){
	
	cin>>o;
	while(o--){
		get();
	}
}

