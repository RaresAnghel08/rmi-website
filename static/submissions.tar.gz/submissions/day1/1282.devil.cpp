/**
* user:  mavrodiev-b5b
* fname: Tsvetoslav
* lname: Mavrodiev
* task:  devil
* score: 14.0
* date:  2019-10-10 06:07:48.331854
*/
#include<bits/stdc++.h>
using namespace std;
int c[16],m[100001];
void solve2()
{
    int x,s=0;
    for(int i=9;i>0;i--) s+=c[i];
    for(int i=9;i>0;i--)
    {
        if(c[i]>0){x=i; c[i]--; break;}
    }
    m[s-1]=x;
    int y=9,z=0;
    for(int i=0;1;i++)
    {
        if(i&1)
        {
            while(y>=0&&!c[y]) y--;
            if(y==-1) break;
            c[y]--;
            m[s-i-2]=y;
        }
        else
        {
            while(z<10&&!c[z]) z++;
            if(z==10) break;
            c[z]--;
            m[s-i-2]=z;
        }
        //cout<<z<<" "<<y<<" "<<c[z]<<" "<<c[y]<<endl;
    }
    for(int i=0;i<s;i++) cout<<m[i]; cout<<endl;
}
int main()
{
    ios_base::sync_with_stdio(0);
    int n;
    cin>>n;
    while(n--)
    {
        int k;
        cin>>k;
        for(int i=1;i<10;i++) cin>>c[i];
        if(k==2) solve2();
    }
    return 0;
}
