/**
* user:  piscu-24c
* fname: Stefan Constantin
* lname: Piscu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:09:34.021005
*/
#include <bits/stdc++.h>
using namespace std;

int main(){
	int t;
	cin>>t;
	while(t--){
		int n, m, k;
		cin>>n>>m>>k;
		if((n%2)||(m%2)){
			cout<<"NO\n";
		}
		if(n==2){
			if(k!=(m/2)){
				cout<<"NO\n";
			}
			else{
				for(int i=1;i<=m/2;++i) cout<<i<<" "<<i<<" ";
				cout<<"\n";
				for(int i=1;i<=m/2;++i) cout<<i<<" "<<i<<" ";
				cout<<"\n";
			}
		}
		if(n==4){
			if(k==m){
				for(int i=1;i<=m/2;++i) cout<<i<<" "<<i<<" ";
				cout<<"\n";
				for(int i=1;i<=m/2;++i) cout<<i<<" "<<i<<" ";
				cout<<"\n";
				for(int i=m/2+1;i<=m;++i) cout<<i<<" "<<i<<" ";
				cout<<"\n";
				for(int i=m/2+1;i<=m;++i) cout<<i<<" "<<i<<" ";
				cout<<"\n";
			}
			else if(k==m/2){
				int nr=2;
				for(int i=1;i<=m;++i) cout<<1<<" ";
				cout<<"\n";
				cout<<1<<" ";
				for(int j=2;j<m;j+=2){
					cout<<nr<<" "<<nr<<" ";
					nr++;
				}
				cout<<1<<" ";
				cout<<"\n";
				nr=2;
				cout<<1<<" ";
				for(int j=2;j<m;j+=2){
					cout<<nr<<" "<<nr<<" ";
					nr++;
				}
				cout<<1<<" ";
				cout<<"\n";
				for(int i=1;i<=m;++i) cout<<1<<" ";
				cout<<"\n";
			}
			else{
				cout<<"NO\n";
			}
			
		}
	}
}
