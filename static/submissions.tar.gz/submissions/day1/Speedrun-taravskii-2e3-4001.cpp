/**
* user:  taravskii-2e3
* fname: Denys
* lname: Taravskii
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 11:52:47.845602
*/
#include "speedrun.h"

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll DIM = 1e3 + 7 ;

ll vis[DIM],h[DIM];

ll n;

void bit_conect(ll v1,ll v2){

    if(h[v1]>=2)return;

    ll p,mask;

    mask=v2;

    for(int j=1;j<=10;j++){

     p=h[v1]*10+j;

     if(mask%2==1)setHint(v1,p,true);

     mask/=2;
    }

    h[v1]++;
}

void assignHints(int subtask, int N, int A[], int B[]) {

    if(subtask==1){

     setHintLen(N);

     for(int i=1;i<=N-1;i++){
      setHint(A[i],B[i],true);
      setHint(B[i],A[i],true);
     }

     return;
    }

    if(subtask==2 || subtask==3){

     setHintLen(20);

     for(int i=1;i<=N-1;i++){
      bit_conect(A[i],B[i]);
      bit_conect(B[i],A[i]);
     }

    }

    return;
}

ll fto(ll s){
    ll to=0;

    for(int i=s;i>(s-10);i--){
     if(getHint(i))to++;
     to*=2;
    }

    to/=2;

    return to;
}

void dfs(ll v,ll sub){

    ll to;

    vis[v]=1;

    if(sub==1){

     for(int i=1;i<=n;i++){

      if(i==v || vis[i]!=0)continue;

      if(getHint(i)){
       goTo(i);
       dfs(i,sub);
       goTo(v);
      }

     }

    }

    if(sub==2){

     if(h[v]>1){

      for(int i=1;i<=n;i++){

       if(i==v || vis[i]!=0)continue;

       goTo(i);
       goTo(v);
      }

     }
     else{

      to=fto(10);

      goTo(to);
      dfs(to,sub);
     }

    }

    if(sub==3){

      to=fto(10);

      if(vis[to]==0){
       goTo(to);
       dfs(to,sub);
       goTo(v);
      }

      to=fto(20);

      if(vis[to]==0){
       goTo(to);
       dfs(to,sub);
       goTo(v);
      }

    }

    return;
}

void speedrun(int subtask, int N, int start) {

    n=N;
    dfs(start,subtask);
    return;
}

/*

5
1 2
2 3
3 4
3 5
1

5
3 1
3 2
3 4
3 5
1

*/
