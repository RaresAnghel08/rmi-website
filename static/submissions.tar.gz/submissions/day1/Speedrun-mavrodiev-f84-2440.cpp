/**
* user:  mavrodiev-f84
* fname: Tsvetoslav Valentinov
* lname: Mavrodiev
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 09:33:14.818742
*/
#include<bits/stdc++.h>
#define pb push_back
using namespace std;

void assignHints(int subtask, int N, int A[], int B[]);
void speedrun(int subtask, int N, int start);

void setHintLen(int l);
void setHint(int i, int j, bool b);
int getLength();
bool getHint(int j);
bool goTo(int x);

int deg[1024];

void setBinHint(int x,int h,int st=1)
{
    for(int i=0;i<10;i++)
        setHint(x,i+st,h&(1<<i));
}

int getBinHint(int st=1)
{
    int x=0;
    for(int i=0;i<10;i++)
        x+=(getHint(i+st)<<i);
    return x;
}

bool f[1024];

vector<int> v[1024];
void _dfs3(int x)
{
    f[x]=1;
    int st=1;
    for(int i:v[x])
    {
        setBinHint(x,i,st); st+=10;
        if(!f[i]) _dfs3(i);
    }
}

void assignHints(int subtask, int N, int A[], int B[])
{
    if(subtask==1)
    {
        setHintLen(N);
        for(int i=1;i<N;i++)
        {
            setHint(A[i],B[i],1);
            setHint(B[i],A[i],1);
        }
    }
    else if(subtask==2)
    {
        setHintLen(10);
        for(int i=1;i<N;i++)
        {
            deg[A[i]]++;
            deg[B[i]]++;
        }
        int x=0;
        for(int i=1;i<=N;i++)
            if(deg[i]==N-1) x=i;
        for(int i=1;i<=N;i++)
        {
            setBinHint(i,x);
        }
    }
    else if(subtask==3)
    {
        setHintLen(20);
        for(int i=1;i<N;i++)
        {
            v[A[i]].pb(B[i]);
            v[B[i]].pb(A[i]);
        }
        _dfs3(1);
    }
}

void dfs1(int x, int N, int pr=0)
{
    f[x]=1;
    for(int i=1;i<=N;i++)
    {
        if(!f[i]&&getHint(i))
        {
            goTo(i);
            dfs1(i,N,x);
        }
    }
    if(pr) goTo(pr);
}

void dfs3(int x)
{
    f[x]=1;
    int y=getBinHint();
    if(y&&!f[y])
    {
        goTo(y);
        dfs3(y);
        goTo(x);
    }
    y=getBinHint(11);
    if(y&&!f[y])
    {
        goTo(y);
        dfs3(y);
        goTo(x);
    }
}

void speedrun(int subtask, int N, int start)
{
    memset(f,0,sizeof(f));
    if(subtask==1) dfs1(start, N);
    else if(subtask==2)
    {
        int x=getBinHint();
        if(x!=start) goTo(x);
        for(int i=1;i<=N;i++)
        {
            if(i!=x)
            {
                goTo(i);
                goTo(x);
            }
        }
    }
    else if(subtask==3) dfs3(start);
}
