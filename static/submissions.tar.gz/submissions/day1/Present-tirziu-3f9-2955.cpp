/**
* user:  tirziu-3f9
* fname: Petre
* lname: Tirziu
* task:  Present
* score: 29.0
* date:  2021-12-16 10:22:26.064873
*/
#include <iostream>
#include <algorithm>

using namespace std;
//ifstream cin("present.in");
//ofstream cout("present.out");
int mat[1000005][100];
int f[5005];
int main()
{
    int t, i, j, cnt = 0;
    cin >> t;
    int ct = t;
    mat[1][0] = 1;
    mat[1][1] = 1;
    f[1] = 1;
    cnt = 1;
    for(i = 2; i <= 100; i++){
        if(cnt >= 1000005)
            break;
        mat[++cnt][1] = i;
        mat[cnt][0] = 1;
        int cnti = cnt;
        for(int x = 1; x < cnti; x++){
            if(cnt >= 1000005)
                break;
            for(j = 1; j <= mat[x][0]; j++)
                f[mat[x][j]]++;
            bool ok = true;
            for(j = 1; j <= mat[x][0]; j++)
                if(!f[__gcd(i, mat[x][j])]){
                    ok = false;
                    break;
                }
            if(ok == true){
                mat[++cnt][0] = mat[x][0] + 1;
                for(j = 1; j <= mat[x][0]; j++)
                    mat[cnt][j] = mat[x][j];
                mat[cnt][j] = i;
            }
            for(j = 1; j <= i; j++)
                f[j] = 0;
        }
    }
    while(t--){
        int a;
        cin >> a;
        if(a == 0){
            cout << "0\n";
            continue;
        }
        for(i = 0; i <= mat[a][0]; i++)
            cout << mat[a][i] << " ";
        cout << "\n";
    }
    return 0;
}
