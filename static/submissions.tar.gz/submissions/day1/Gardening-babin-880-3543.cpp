/**
* user:  babin-880
* fname: Aleksandr
* lname: Babin
* task:  Gardening
* score: 11.0
* date:  2021-12-16 11:16:19.531411
*/
#include <bits/stdc++.h>

using namespace std;

// WHY DOES THAT SHIT WORKS!?

int ncol = 0;

vector<int> nm;

bool check(int n, int m, int k) {
    if (n % 2 || m % 2) return false;
    if (n * m % 2) return false;
    if (n * m / 4 < k) return false;
    if (n * m / 4 - 1 == k) return false;
    if (k < max(n, m) / 2) return false;
    return true;
}

mt19937 rng(1337228);

bool solve(int n, int m, int k, int i0, int j0, vector<vector<int>>& v) {
    if (4 * k == n * m) {
        for (int i = i0; i < i0 + n; i += 2)
        for (int j = j0; j < j0 + m; j += 2) {
            v[i][j] = v[i+1][j] = v[i][j+1] = v[i+1][j+1] = ++ncol;
        }
        return true;
    }

    assert(n > 2 && m > 2);
    int sav = ncol;

    if (check(n-2, m-2, k-1)) {
        ++ncol;
        for (int i = i0; i < i0 + n; ++i) v[i][j0] = v[i][j0+m-1] = ncol;
        for (int j = j0; j < j0 + m; ++j) v[i0][j] = v[i0+n-1][j] = ncol;
        if (solve(n-2, m-2, k-1, i0+1, j0+1, v)) return true;
        ncol = sav;
    }

    for (int a = 4; a < n; a += 2) {
        if ((a-2)*(m-2)/4 + 1 + (n-a)*m/4 == k) {
            if (solve(a, m,   (a-2)*(m-2)/4 + 1, i0, j0, v) && solve(n-a, m, (n-a)*m/4, i0+a, j0, v)) return true;
            ncol = sav;
        }
    }

    for (int a = 4; a < m; a += 2) {
        if ((a-2)*(n-2)/4 + 1 + (m-a)*n/4 == k) {
            if (solve(n, a, (a-2)*(n-2)/4 + 1, i0, j0, v) && solve(n, m-a, (m-a)*n/4, i0, j0+a, v)) return true;
            ncol = sav;
        }
    }

    for (int s = 0; s < 4; s++)
    for (int a = 4; a < m; a += 2) {
        int r = rng() % ((m-a)*n/4);
        if (check(n, a, k - (m-a)*n/4 + r) && check(n, m-a, (m-a)*n/4 - r)) {
            if (solve(n, a, k - (m-a)*n/4 + r, i0, j0, v) && solve(n, m-a, (m-a)*n/4 - r, i0, j0+a, v)) return true;
            ncol = sav;
        }
    }

    for (int s = 0; s < 4; s++)
    for (int a = 4; a < n; a += 2) {
        int r = rng() % ((n-a)*m/4);
        if (check(a, m, k - (n-a)*m/4 + r) == k && check(n-a, m, (n-a)*m/4 - r)) {
            if (solve(a, m,   k-(n-a)*m/4 + r, i0, j0, v) && solve(n-a, m, (n-a)*m/4 - r,   i0+a, j0, v)) return true;
            ncol = sav;
        }
    }

    return false;
}

int main() {
    ios::sync_with_stdio(0); cin.tie(0);

    long long s = 2e5;

    int t; cin >> t;
    while (t--) {
        int n, m, k; cin >> n >> m >> k;
        ncol = 0;
        if ((long long) n * m <= s && check(n, m, k)) {
            vector<vector<int>> v(n, vector<int>(m));
            if (solve(n, m, k, 0, 0, v)) {
                cout << "YES\n";
                s -= n * m;
                for (auto& u : v) {
                    for (int x : u) cout << x << ' ';
                    cout << '\n';
                }
            } else {
                cout << "NO\n";
            }
        } else {
            cout << "NO\n";
        }
        // cout.flush();
    }
}