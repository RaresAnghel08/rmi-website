/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Present
* score: 29.0
* date:  2021-12-16 08:51:38.273503
*/
#include <bits/stdc++.h>

#define pb push_back

using namespace std;

const int N = 25, M = 1e6 + 10;
int ans[M], correct[(1 << 25)], gcd[N + 1][N + 1];

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++)
            gcd[i][j] = __gcd(i, j);
    }
    correct[0] = 1;
    int last_ans = 0;
    for (int mask = 1; mask < (1 << N); mask++) {
        int last = 0;
        for (int j = N - 1; j >= 0; j--) {
            if ((1 << j) & mask) {
                last = j;
                break;
            }
        }
        if (correct[mask ^ (1 << last)]) {
            bool bl = 1;
            for (int i = 0; i < last; i++) {
                if ((1 << i) & mask) {
                    if (!(mask & (1 << (gcd[i + 1][last + 1] - 1)))) {
                        bl = 0;
                        break;
                    }
                }
            }
            correct[mask] = bl;
            if (bl) {
                if (last_ans < M) {
                    ans[last_ans++] = mask;
                }
            }
        }
    }
    int t, num;
    cin >> t;
    while (t--) {
        cin >> num;
        num--;
        if (num == -1) {
            cout << 0 << endl;
            continue;
        }
        vector<int> answer;
        for (int i = 0; i < N; i++) {
            if ((1 << i) & ans[num]) {
                answer.pb(i + 1);
            }
        }
        cout << answer.size() << ' ';
        for (auto u: answer)
            cout << u << ' ';
        cout << endl;
    }
}