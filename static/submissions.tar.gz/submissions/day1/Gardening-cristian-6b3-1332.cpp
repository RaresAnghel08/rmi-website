/**
* user:  cristian-6b3
* fname: Cristea
* lname: Cristian
* task:  Gardening
* score: 5.0
* date:  2021-12-16 07:43:39.726828
*/
#include <iostream>
#include <vector>
#include <cstring>

using namespace std;
vector < vector <int> > v;
int solve(int x1, int y1, int x2, int y2, int flower, int k)
{
    if(flower > k)
        return 0;
    int cnt = flower, i , j;
    if((x2 - x1 + 1) % 2 == 0 && (y2 - y1 + 1) % 2 == 0 && (x2 - x1 + 1) / 2 * (y2 - y1 + 1) / 2 <= k - flower + 1)
    {
        for(i = x1; i <= x2; i += 2)
        {
            for(j = y1; j <= y2; j += 2)
            {
                v[i][j] = v[i+1][j] = v[i][j+1] = v[i+1][j+1] = cnt;
                cnt++;
            }
        }
        if(cnt  - 1 != k)
            return 0;
        return 1;
    }
    else
    {
        for(i = x1; i <= x2; i++)
            v[i][y1] = v[i][y2] = cnt;
        for(j = y1; j <= y2; j++)
            v[x1][j] = v[x2][j] = cnt;
        cnt++;
        solve(x1+1, y1+1, x2-1, y2-1, cnt, k);
    }
}
int main()
{
    int t, n, m, k, i, j;
    cin >> t;
    while(t--)
    {
        cin >> n >> m >> k;
        v.resize(n+1);
        for(i = 1; i <= n; i++)
        {
            for(j = 0; j <= m; j++)
                v[i].push_back(0);
        }
        if(solve(1, 1, n, m, 1, k))
        {
            cout << "YES\n";
            for(i = 1; i <= n; i++)
            {
                for(j = 1; j <= m; j++)
                    cout << v[i][j] << ' ';
                cout << '\n';
            }
        }
        else
            cout << "NO\n";

    }
    return 0;
}
