/**
* user:  gainullin-e22
* fname: Ildar
* lname: Gainullin
* task:  lucky
* score: 100.0
* date:  2019-10-10 05:56:54.713255
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int N = 1e5 + 7;
const int M = 1e9 + 7;

int add(int a, int b) {
	int c = a + b;
	if (c < 0) c += M;
	if (c >= M) c -= M;
	return c;
}

int mul(int a, int b) {
	return (a * (ll) b) % M;
}

struct data {
	int a[4][4];
};

data operator + (const data &a, const data &b) {
	data c;
	for (int i= 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			c.a[i][j] = 0;
			for (int k = 0; k < 4; k++) {
				c.a[i][j] = add(c.a[i][j], mul(a.a[i][k], b.a[k][j]));
			}
		}
	}
	return c;
};

data t[4 * N];

data gen_digit(int c) {
	data ans;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			ans.a[i][j] = 0;
		}
	}
	for (int small = 0; small < 2; small++) {
		for (int ed = 0; ed < 2; ed++) {
			for (int cur = 0; cur < 10; cur++) {
				if (!small && cur > c) {
					continue;
				}
				if (ed && cur == 3) {
					continue;
				}
				int new_small = small | (cur < c);
				int new_ed = (cur == 1);
				ans.a[small * 2 + ed][new_small * 2 + new_ed]++;
			}
		}
	}
	return ans;
}

void build(int v, int l, int r, string &s) {
	if (r - l == 1) {
		t[v] = gen_digit(s[l] - '0');
	} else {
		int m = (l + r) / 2;
		build(v * 2 + 1, l, m, s);
		build(v * 2 + 2, m, r, s);
		t[v] = t[v * 2 + 1] + t[v * 2 + 2];
	}
}

void upd(int v, int l, int r, int i, int c) {
	if (r - l == 1) {
		t[v] = gen_digit(c);
	} else {
		int m = (l + r) / 2;
		if (i < m) {
			upd(v * 2 + 1, l, m, i, c);
		} else {
			upd(v * 2 + 2, m, r, i, c);
		}
		t[v] = t[v * 2 + 1] + t[v * 2 + 2];
	}
}

data ed;

data get(int v, int l, int r, int tl, int tr) {
	if (tl >= r || tr <= l) {
		return ed;
	}
	if (tl >= l && tr <= r) {
		return t[v];
	} else {
		int tm = (tl + tr) / 2;
		return get(v * 2 + 1, l, r, tl, tm) + get(v * 2 + 2, l, r, tm, tr);
	}
}

int ret(data a) {
	int sum = 0;
	for (int i = 0; i < 4; i++) {
		sum = add(sum, a.a[0][i]);
	}
	return sum;
}

int main() {
#ifdef iq
	freopen("a.in", "r", stdin);
#endif
	ios::sync_with_stdio(0);
	cin.tie(0);
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			ed.a[i][j] = (i == j);
		}
	}
	int n, q;
	cin >> n >> q;
	string s;
	cin >> s;
	build(0, 0, n, s);
	cout << ret(t[0]) << '\n';
	for (int i = 0; i < q; i++) {
		int t;
		cin >> t;
		if (t == 1) {
			int l, r;
			cin >> l >> r;
			l--, r--;
			data ans = get(0, l, r + 1, 0, n);
			cout << ret(ans) << '\n';
		} else {
			int i, c;
			cin >> i >> c;
			i--;
			upd(0, 0, n, i, c);
		}
	}
}
