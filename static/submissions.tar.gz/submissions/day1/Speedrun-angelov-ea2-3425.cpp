/**
* user:  angelov-ea2
* fname: Dobromir Dobromirov
* lname: Angelov
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 11:04:22.416313
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;
void setnext(int u,int v,int br)
{
    string s="";
    while(v)
    {
        s=(char)(v%2)+s;
        v/=2;
    }
    int ptr=s.size()-1;
    for(int i=br;;i--)
    {
        if(ptr<0)break;
        setHint(u,i,(s[ptr]=='1' ? 1 : 0));
        ptr--;
    }
}
void assignHints(int subtask, int N, int A[], int B[])
{
    if(subtask==2)
    {
        setHintLen(1);
        bool used[1005]={0};
        for(int i=1;i<N;i++)
        {
            if(used[A[i]])
            {
                setHint(A[i],1,1);
                break;
            }
            if(used[B[i]])
            {
                setHint(B[i],1,1);
                break;
            }
            used[A[i]]=used[B[i]]=1;
        }
    }
    if(subtask==3)
    {
        int st=1,br=0;
        while(st<=N){st<<=1;br++;}
        setHintLen(2*br);
        vector<int>adj[1005];
        for(int i=1;i<N;i++)
        {
            adj[A[i]].push_back(B[i]);
            adj[B[i]].push_back(A[i]);
        }
        int prev;
        int used[1005];
        for(int i=1;i<=N;i++)
        {
            if(adj[i].size()==1)
            {
                setnext(i,adj[i][0],br);
                prev=i;
                used[i]++;
                int next;
                i=adj[i][0];
                while(used[adj[i][0]]<2||used[adj[i][1]]<2)
                {
                    if(adj[i][0]!=prev)next=adj[i][0];
                    else next=adj[i][1];
                    if(!used[next])setnext(i,next,br);
                    else setnext(i,next,2*br);
                    used[i]++;
                    prev=i;
                    i=next;
                }
                break;
            }
        }
    }
}
int getnext(int u,int br,bool fl)
{
    int res=0;
    int st=1;
    if(fl)
    {
        for(int i=br;i>br/2;i--)
        {
            if(getHint(i))res+=st;
            st<<=1;
        }
    }
    else
        for(int i=br;i>0;i--)
    {
        if(getHint(i))res+=st;
        st<<=1;
    }
    return res;
}
void speedrun(int subtask, int N, int start)
{
    if(subtask==2)
    {
        if(getHint(1)==1)
        {
            for(int i=1;i<=N;i++)
            {
                if(i==start)continue;
                goTo(i);
                goTo(start);
            }
            return;
        }
        int c;
        for(int i=1;i<=N;i++)
        {
            if(goTo(i))
            {
                c=i;
                break;
            }
        }
        for(int i=1;i<=N;i++)
        {
            if(i==c)continue;
            goTo(i);
            goTo(c);
        }
        return;
    }
    if(subtask==3)
    {
        int used[1005];
        int curr=start;
        int br=getLength()/2;
        while(1)
        {
            int next;
            if(!used[curr])next=getnext(curr,br,0);
            else next=getnext(curr,2*br,1);
            goTo(next);
            used[curr]++;
            curr=next;
            if(curr==start&&used[start]==2)break;
        }
        return;
    }
}
