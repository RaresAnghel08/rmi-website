/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:03:11.170479
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)


using namespace std;
typedef long long ll;
typedef pair<int,int> pii;

#include "speedrun.h"

int n;

vector<int> g[1001];

int par[1001];

vector<int> euler;
void dfs(int u, int p){
	euler.pb(u);
	par[u] = p;
	for(auto e : g[u]){
		if(e == p) continue;
		dfs(e, u);
	}
}
const int b = 20;
void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
		n = N;
		fr(i, 1, n){
			A[i] --;
			B[i] --;
			g[A[i]].pb(B[i]);
			g[B[i]].pb(A[i]);
		}
		dfs(0, 0);
		setHintLen(40);
		
		fr(i, 0, n){
			fr(j, 0, b){
				if((par[i] + 1) & (1<<j)){
					setHint(i+1, j+1, 1);
				}
				else{
					setHint(i+1, j+1, 0);
				}
			}
		}
		
		fr(i, 0, n-1){
			fr(j, b, b+b){
				if((euler[i+1]+1) & (1<<(j-b))) setHint(euler[i]+1, j+1, 1);
				else setHint(euler[i]+1, j+1, 0);
			}	
		}
		fr(j, b, b+b) setHint(N, j+1, 0);
	
}
int L;
bool vis[1001];

bool fst[1001];

int cnt = 0;
bool ok[1001][1001];


int getx(int i){
	int num = 0;
	fr(j, i, i+b){
		if(getHint(j)) num |= (1<<(j-i));
	}
	return num;
} 

int p[1001];

int gotoroot(int s){
	
	p[s] = getx(1);
	if(s != p[s]){
		goTo(p[s]);
		return gotoroot(p[s]);
	}
	else return s;
}

int NXT[1001];


void _dfs(int u, int nxt){
	
	if(u == nxt){
		NXT[u] = getx(b+1);
		
		if(NXT[u] == 0){
			return;
		}
		_dfs(u, NXT[u]);
		return;
	}
	else{
		bool ok = goTo(nxt);
		if(ok){
			p[nxt] = u;
			_dfs(nxt, nxt);
		}
		else{
			goTo(p[u]);
			_dfs(p[u], nxt);
		}
	}
}





void speedrun(int subtask, int N, int start) { /* your solution here */
	fr(i, 0, N+1){
		p[i] = -1;
		NXT[i] = -1;
	}
	L = getLength();
	n = N;
	int r = gotoroot(start);

	
	NXT[r] = getx(b+1);
	_dfs(r, NXT[r]);
}

/*
int main(){

	return 0;
}
*/
