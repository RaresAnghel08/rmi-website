/**
* user:  popovici-d76
* fname: Robert-Adrian
* lname: Popovici
* task:  restore
* score: 20.0
* date:  2019-10-10 10:15:40.719106
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 5000;

struct Query {
	int l, val, k;
};

vector <Query> qry[MAXN + 1];
int sp[MAXN + 1];

void bkt(int pos, int n) {
	for(auto it : qry[pos - 1]) {
		if(it.val == 0) {
			if(sp[pos - 1] - sp[it.l - 1] < it.k) {
				return ;
			}
		}
		else {
			if(sp[pos - 1] - sp[it.l - 1] >= it.k) {
				return ;
			}
		}
	}
	if(pos == n + 1) {
		int i;
		for(i = 1; i <= n; i++) {
			cout << 1 - (sp[i] - sp[i - 1]) << " ";
		}
		exit(0);
	}
	else {
		sp[pos] = sp[pos - 1];
		bkt(pos + 1, n);
		sp[pos] = sp[pos - 1] + 1;
		bkt(pos + 1, n);
	}
}

int main() {
	//ifstream cin("A.in");
	//ofstream cout("A.out");
	int n, m, i, j;
	cin >> n >> m;
	for(i = 1; i <= m; i++) {
		int l, r, k, val;
		cin >> l >> r >> k >> val;
		l++, r++;
		qry[r].push_back({l, val, k});
	}
	if(n <= 18) {
		bkt(1, n);
		cout << -1;
		return 0;
	}

	auto bad = [&](int l, int r, int k, int val) -> bool {
		if(val == 0) {
			if(k == 1) return sp[r] - sp[l - 1] > 0;
			return sp[r] - sp[l - 1] == r - l + 1;
		}
		if(k == 1) return sp[r] - sp[l - 1] == 0;
		return sp[r] - sp[l - 1] < r - l + 1;
	};

	for(i = 1; i <= n; i++) {
		sp[i] = 1;
		for(auto it : qry[i]) {
			if(it.val == 1) {
				for(j = it.l; j <= i; j++) {
					sp[j] = 0;
				}
			}
		}
	}

	for(i = 1; i <= n; i++) {
		sp[i] += sp[i - 1];
	}
	for(i = 1; i <= n; i++) {
		for(auto it : qry[i]) {
			if(it.val == 0 && sp[i] - sp[it.l - 1] == 0) {
				cout << -1;
				exit(0);
			}
		}
	}
	for(i = 1; i <= n; i++) {
		cout << 1 - (sp[i] - sp[i - 1]) << " ";
	}

	return 0;
}
