/**
* user:  khargelia-6b3
* fname: Sergei
* lname: Khargelia
* task:  restore
* score: 20.0
* date:  2019-10-10 08:29:28.584425
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
#define F first
#define S second
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define SZ(x) (int)x.size()

struct T {
	int l, r, num, vl;
	T() {};
	T(int l, int r, int num, int vl) : l(l), r(r), num(num), vl(vl) {};
};

mt19937 rnd(228);

const int N = 5010;
int pref[N], ans[N];

int get_sum(int l, int r) {
	return pref[r] - pref[l - 1];
}

signed main() {
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int n, m;
	cin >> n >> m;
	vector<T> que;
	for (int i = 0; i < m; i++) {
		int l, r, num, vl;
		cin >> l >> r >> num >> vl;
		l++;
		r++;
		que.pb(T(l, r, num, vl));
		if (num == 1 && vl == 1) {
			for (int j = l; j <= r; j++) {
				ans[j] = 1;
			}
		}
	}
	shuffle(all(que), rnd);
	int all = (1 << n) - 1;
	if (n <= 18) {
		for (int i = 0; i < (1 << n); i++) {
			bool ok = true;
			pref[0] = 0;
			for (int j = 1; j <= n; j++) {
				pref[j] = pref[j - 1] + ((i >> (j - 1)) & 1);
			}
			for (auto it : que) {
				if (it.vl == 1) {
					if (get_sum(it.l, it.r) < it.r - it.l + 1 - (it.num - 1)) {
						ok = false;
						break;
					}
				}
				else {
					if (get_sum(it.l, it.r) > it.r - it.l + 1 - it.num) {
						ok = false;
						break;
					}
				}
			}
			if (ok) {
				for (int j =0 ; j < n; j++) {
					cout << ((i >> j) & 1) << ' ';
				}
				cout << '\n';
				exit(0);
			}
		}
		cout << -1 << '\n';
	}
	else {
		for (int i = 1; i <= n; i++) {
			pref[i] = pref[i - 1] + ans[i];
		}
		bool ok = true;
		for (auto it : que) {
			if (it.vl == 1) {
					if (get_sum(it.l, it.r) < it.r - it.l + 1 - (it.num - 1)) {
						ok = false;
						break;
					}
				}
				else {
					if (get_sum(it.l, it.r) > it.r - it.l + 1 - it.num) {
						ok = false;
						break;
					}
				}
		}
		if (ok) {
			for (int i = 1; i <= n; i++) {
				cout << ans[i] << ' ';
			}
			cout << '\n';	
		}
		else {
			cout << -1 << '\n';
		}
		
	}
}