/**
* user:  todoran-200
* fname: Alexandru Raul
* lname: Todoran
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 10:42:46.611279
*/
/**
 ____ ____ ____ ____ ____
||a |||t |||o |||d |||o ||
||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|

**/

#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

typedef long long ll;

const int N_MAX = 1000;

int N;

vector <int> adj[N_MAX + 2];

void setHintLen (int l);
void setHint (int i, int j, bool b);

void assignHints (int subtask, int _N, int A[], int B[]) {
    N = _N;
    for (int i = 1; i <= N - 1; i++) {
        adj[A[i]].push_back(B[i]);
        adj[B[i]].push_back(A[i]);
    }
    setHintLen(20);
    for (int u = 1; u <= N; u++) {
        int x = ((int) adj[u].size() >= 1 ? adj[u][0] : 0);
        int y = ((int) adj[u].size() >= 2 ? adj[u][1] : 0);
        for (int b = 0; b < 10; b++) {
            setHint(u, b + 1, ((x >> b) & 1));
        }
        for (int b = 0; b < 10; b++) {
            setHint(u, 10 + b + 1, ((y >> b) & 1));
        }
    }
}

int getLength ();
bool getHint (int j);
bool goTo (int x);

bool seen[N_MAX + 2];

void decrypt (int u) {
    int x = 0, y = 0;
    for (int b = 0; b < 10; b++) {
        x |= (getHint(b + 1) << b);
    }
    for (int b = 0; b < 10; b++) {
        y |= (getHint(10 + b + 1) << b);
    }
    if (x != 0) {
        adj[u].push_back(x);
    }
    if (y != 0) {
        adj[u].push_back(y);
    }
}

void dfs (int u) {
    decrypt(u);
    seen[u] = true;
    for (int v : adj[u]) {
        if (seen[v] == false) {
            goTo(v);
            dfs(v);
            goTo(u);
        }
    }
}

void speedrun (int subtask, int _N, int start) {
    N = _N;
    int L = getLength();
    dfs(start);
}
