/**
* user:  donciu-262
* fname: Mircea
* lname: Donciu
* task:  devil
* score: 13.0
* date:  2019-10-10 09:35:12.778408
*/
#include <iostream>

using namespace std;
long long t,k,n,i,j,l,m,mod,ap[15],v[100005],val[100005],st[100005],dr[100005],vdr[100005],vst[100005],h[100005],p[100005];
//ifstream cin("rmi.in");
//ofstream cout("rmi.out");
void mrg(long long x, long long y)
{
    dr[vdr[x]]=vst[y];
    st[vst[y]]=vdr[x];
    vdr[x]=vdr[y];
    h[x]*=p[y];
    h[x]+=h[y];
    p[x]*=p[y];
    h[x]%=mod;
    p[x]%=mod;
}
int main()
{
    cin>>t;
    mod=1000000123;
    while(t)
    {
        t--;
        cin>>k;
        for(i=1; i<=9; i++)
        {
            cin>>ap[i];
            n+=ap[i];
        }
        j=9;
        for(i=n; i>=n-k+2; i--)
        {
            while(ap[j]==0) j--;
            v[i]=j;
            ap[j]--;
        }
        j=9;
        m=0;
        while(ap[j]==0) j--;
        l=ap[j];
        while(j)
        {
            while(ap[j])
            {
                m++;
                val[m]=j;
                st[m]=m;
                dr[m]=m;
                vst[m]=m;
                vdr[m]=m;
                h[m]=j;
                p[m]=10;
                ap[j]--;
            }
            j--;
        }
        while(m>1)
        {
            if(l==m) l=(m+1)/2;
            for(i=l; i>=1&&m+i-l>l; i--)
            {
                mrg(i,m-l+i);
            }
            m=max(l,m-l);
            while(h[l]!=h[1]) l--;
        }
        long long x=1;
        while(x!=dr[x])
        {
            cout<<val[x];
            x=dr[x];
        }
        cout<<val[x];
        for(i=n-k+2; i<=n; i++) cout<<v[i];
        cout<<'\n';
    }
    return 0;
}
