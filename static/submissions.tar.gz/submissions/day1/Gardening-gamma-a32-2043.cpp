/**
* user:  gamma-a32
* fname: Pascal
* lname: Gamma
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:54:10.655816
*/
#ifndef LOCAL
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,avx,avx2")
#define dbg(x)
#else
#define dbg(x) cerr << #x << " = " << x << "\n";
#endif

#include <bits/stdc++.h>

using namespace std;

#define int int64_t

signed main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);

  int t;
  cin >> t;
  while (t--) {
    int n, m, k;
    cin >> n >> m >> k;
    vector<vector<int>> garden(n, vector<int>(m));
    int flower = 1;
    if (n % 2 == 1 || m % 2 == 1 || n * m < 4 * k) {
      cout << "NO\n";
      continue;
    }

    if (n == 4) {
      if (k > m || k < m / 2 || k == m - 1) {
        cout << "NO\n";
        break;
      }

      int w = (m - k) * 2;
      if (w) {
        dbg(w);
        for (int i = 0; i < w; i++) {
          garden[0][i] = flower;
          garden[3][i] = flower;
        }
        for (int i = 0; i < 4; i++) {
          garden[i][0] = flower;
          garden[i][w - 1] = flower;
        }

        flower++;
        for (int i = 1; i < w - 1; i += 2) {
          garden[1][i] = flower;
          garden[2][i] = flower;
          garden[1][i + 1] = flower;
          garden[2][i + 1] = flower;
          flower++;
        }
      }
      for (int i = w; i < m; i += 2) {
        garden[0][i] = flower;
        garden[1][i] = flower;
        garden[0][i + 1] = flower;
        garden[1][i + 1] = flower;
        flower++;
        garden[2][i] = flower;
        garden[3][i] = flower;
        garden[2][i + 1] = flower;
        garden[3][i + 1] = flower;
        flower++;
      }
    } else {

      while (n * m > 4 * k && n > 2 && m > 2 && k > 1) {
        for (int i = 0; i < n; i++) {
          garden[flower - 1 + i][flower - 1] = flower;
          garden[flower - 1 + i][m - 2 + flower] = flower;
        }
        for (int j = 0; j < m; j++) {
          garden[flower - 1][flower - 1 + j] = flower;
          garden[n - 2 + flower][flower - 1 + j] = flower;
        }
        flower++;
        n -= 2;
        m -= 2;
        k--;
      }

      if (n * m == 4 * k) {
        for (int i = 0; i < n; i++) {
          for (int j = 0; j < m; j++) {
            garden[flower - 1 + i][flower - 1 + j] =
                flower + j / 2 + m / 2 * (i / 2);
          }
        }
      } else {
        cout << "NO\n";
        continue;
      }
    }
    cout << "YES\n";
    for (auto column : garden) {
      for (auto e : column) {
        cout << e << " ";
      }
      cout << "\n";
    }
  }
}
