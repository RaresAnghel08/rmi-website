/**
* user:  kitanovski-9bd
* fname: Teo 
* lname: Kitanovski
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:14:47.299320
*/
#include <bits/stdc++.h>
#include "speedrun.h"

typedef long long ll;

#define MS(x,y) memset((x), (y), sizeof((x)))
#define pb push_back
#define MN 1000000000

using namespace std;

void assignHints (int subtask_id, int n, int a[], int b[]) {
    setHintLen(1);
}

void speedrun(int subtask_id, int n2, int s2) {
    int megic = 0;

    for (int i = 1; i<=n2; i++) {
        if (i == s2) continue;

        if (goTo(i)) { megic = i; break; }
    }

    for (int i = 1; i<=n2; i++) {
        if (i == s2 || i == megic) continue;

        goTo(i);
        goTo(megic);
    }
}

//int main() {
//    #ifdef LOCAL_DEBUG
//        fstream cin("in.txt");
//    #endif
//
//    ios_base::sync_with_stdio(false);
//    cin.tie(0);
//    cout.tie(0);
//
//
//}
