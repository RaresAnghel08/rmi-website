/**
* user:  florescu-0a6
* fname: Cella
* lname: Florescu
* task:  restore
* score: 13.0
* date:  2019-10-10 07:22:08.979038
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 5e3;
const int MAXM = 1e4;

struct Req {
  int l, r, k, val;
} op[MAXM];

int v[MAXN + 2], unu[MAXN + 2], zero[MAXN + 2], sp[MAXN + 2];

int main()
{
//    ifstream cin(".in");
//    ofstream cout(".out");
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
      v[i] = -1;
    for (int i = 0; i < m; ++i) {
      cin >> op[i].l >> op[i].r >> op[i].k >> op[i].val;
      ++op[i].l; ++op[i].r;
      if (op[i].k == 1 && op[i].val == 1) {
        ++unu[op[i].l];
        --unu[op[i].r + 1];
      }
    }
    for (int i = 1; i <= n; ++i) {
      unu[i] += unu[i - 1];
      if (unu[i])
        v[i] = 1;
      else
        v[i] = 0;
      sp[i] = sp[i - 1] + v[i];
    }
    for (int i = 0; i < m; ++i) {
      if (op[i].val == 0 && sp[op[i].r] - sp[op[i].l - 1] == op[i].r - op[i].l + 1) {
        cout << -1;
        return 0;
      }
    }
    for (int i = 1; i <= n; ++i)
      cout << v[i] << " ";
    return 0;
}
