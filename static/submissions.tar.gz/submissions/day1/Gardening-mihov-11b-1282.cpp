/**
* user:  mihov-11b
* fname: Rumen
* lname: Mihov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:38:09.264230
*/
# include <bits/stdc++.h>
using namespace std;
void solve()
{
    int n,m,k;
    cin>>n>>m>>k;
    if(n==1||n==3)
    {
        cout<<"NO"<<endl;
        return ;
    }
    if(n==2)
    {
        if(m/2==k)
        {
            cout<<"YES"<<endl;
            int i,j;
            for(i=1;i<=k;i++)
            {
                cout<<i<<" "<<i<<" ";
            }
            cout<<endl;
            for(i=1;i<=k;i++)
            {
                cout<<i<<" "<<i<<" ";
            }
            cout<<endl;
            return ;
        }
        else
        {
            cout<<"NO"<<endl;
            return ;
        }
    }
    if(n==4)
    {
        if(m==k&&m%2==0)
        {

            cout<<"YES"<<endl;
            int i,j;
            for(i=1;i<=k/2;i++)
            {
                cout<<i<<" "<<i<<" ";
            }
            cout<<endl;
            for(i=1;i<=k/2;i++)
            {
                cout<<i<<" "<<i<<" ";
            }
            cout<<endl;
            for(i=1;i<=k/2;i++)
            {
                cout<<k/2+i<<" "<<k/2+i<<" ";
            }
            cout<<endl;
            for(i=1;i<=k/2;i++)
            {
                cout<<k/2+i<<" "<<k/2+i<<" ";
            }
            cout<<endl;
            return ;
        }else
        if((m-2)/2+1==k)
        {
            cout<<"YES"<<endl;
            int i,j;
            for(i=1;i<=m;i++)
            {
                cout<<1<<" ";//<<i<<" ";
            }
            cout<<endl;
            cout<<1<<" ";
            for(i=2;i<=k;i++)
            {
                cout<<i<<" "<<i<<" ";
            }
            cout<<1;
            cout<<endl;
            cout<<1<<" ";
            for(i=2;i<=k;i++)
            {
                cout<<i<<" "<<i<<" ";
            }
            cout<<1;
            cout<<endl;
            for(i=1;i<=m;i++)
            {
                cout<<1<<" ";
            }
            cout<<endl;
            return ;
        }
        else
        {
            cout<<"NO"<<endl;
            return ;
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin>>t;
    while(t--)solve();

    return 0;
}
