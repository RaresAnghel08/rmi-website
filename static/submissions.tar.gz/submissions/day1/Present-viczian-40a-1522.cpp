/**
* user:  viczian-40a
* fname: András
* lname: Viczián
* task:  Present
* score: 29.0
* date:  2021-12-16 08:04:40.658536
*/
#include <bits/stdc++.h>
using namespace std;

#define pb push_back

int main(){
	vector<int> v;
	v.pb(0);

	for(int i = 1; i <= 25; ++i){
		vector<int> nv;

		for(int s : v){
			bool ok = 1;
			s |= (1<<(i-1));

			for(int j = 0; j < 26; ++j){
				if(s & (1<<j) && !(s&(1<<(__gcd(j+1, i)-1)))) ok = 0;
			}
			if(!ok) continue;

			nv.pb(s);

			if(v.size() + nv.size() >= 1000001) break;
		}

		for(int s : nv) v.pb(s);

		if(v.size() >= 1000001) break;
	}

	int tc; cin >> tc;
	while(tc--){
		int x; cin >> x;
		vector<int> ans;

		for(int j = 0; j < 25; ++j){
			if(v[x] & (1<<j)) ans.pb(j+1);
		}
		
		cout << ans.size() << ' ';
		for(int i : ans) cout << i << ' ';
		cout << '\n';
	}

	return 0;
}
