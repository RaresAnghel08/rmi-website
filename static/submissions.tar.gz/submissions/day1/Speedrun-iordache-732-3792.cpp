/**
* user:  iordache-732
* fname: Rares Mihai
* lname: Iordache
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:36:37.269371
*/
#include "speedrun.h"

void assignHints(int subtask, int N, int A[], int B[]) {
    int i;

    setHintLen(N);
    for ( i = 1; i < N; i++ ) {
        setHint(i, A[i], true);
        setHint(i, B[i], true);
    }
}

void speedrun(int subtask, int N, int start) {
    int i, l, a, b, nodes, loc;

    nodes = 1;
    loc = start;
    l = getLength();
    while ( nodes < n ) {
        a = b = -1;
        for ( i = 1; i <= l; i++ ) {
            if ( getHint(i) == true ) {
                if ( a == -1 )
                    a = i;
                else
                    b = i;
            }
        }
        if ( a == loc ) {
            goTo(b);
            loc = b;
        } else {
            goTo(a);
            loc = a;
        }
        nodes++;
    }
}
