/**
* user:  bartoli-2aa
* fname: Davide
* lname: Bartoli
* task:  devil
* score: 14.0
* date:  2019-10-10 06:26:46.777623
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<int>a(10);
int prossimo(){
    for(int i=9;i>0;i--){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int primo(){
    for(int i=1;i<10;i++){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int T;
    cin>>T;
    while(T--){
        int K;
        cin>>K;
        fill(a.begin(),a.end(),0);
        int tot=0;
        for(int i=1;i<10;i++){
            cin>>a[i];
            tot+=a[i];
        }
        vector<int>sol(tot,0);
        for(int i=0;i<K;i+=2){
            int y;
            for(int j=i;j<tot;j+=K){
                sol[j]=prossimo();
                y=j;
            }
            if(i==K-1)break;
            for(int j=i+1;j<tot;j+=K){
                sol[j]=primo();
            }
        }
        for(int i=sol.size()-1;i>=0;i--){
            cout<<sol[i];
        }
        cout<<endl;
    }
    return 0;
}
