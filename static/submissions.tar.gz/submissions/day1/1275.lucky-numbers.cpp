/**
* user:  moldovan-92d
* fname: Andrei
* lname: Moldovan
* task:  lucky
* score: 0.0
* date:  2019-10-10 06:04:19.989177
*/
#include <bits/stdc++.h>
using namespace std;
int fr[10];
int main()
{
    //freopen("input.in","r",stdin);
    //freopen("output.out","w",stdout);
    int t,k,i,j;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        cin>>k;
        int cmax=0,sum=0;
        for(j=1;j<=9;j++)
            {scanf("%d",&fr[j]);
            if(fr[j])cmax=j;sum+=fr[j];}
        if(k==2)
        {
            int val=sum+1-2*fr[cmax];
            for(j=cmax-1;j>0;--j)
                if(fr[j])
            {
                if(val<=0)break;
                while(fr[j]&&val>0)
                {
                    cout<<j;
                    --fr[j];
                    --val;
                }
            }
                while(fr[cmax])
                {
                    cout<<cmax;
                    --fr[cmax];
                    for(int t=1;t<cmax;++t)
                    {
                        if(fr[t])
                        {
                            cout<<t;
                            --fr[t];
                            break;
                        }
                    }
                }
            cout<<"\n";
            continue;
        }
        if(cmax==2)
        {
            if(fr[2]<k)
            {
                for(int j=1;j<=fr[1];++j)cout<<1;
                for(int j=1;j<=fr[2];++j)cout<<2;
                cout<<"\n";
                continue;
            }

        }
    }
    return 0;
}
