/**
* user:  nikolov-3ed
* fname: Zdravko Svetlozarov
* lname: Nikolov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:41:06.277423
*/
#include <bits/stdc++.h>

using namespace std;
int t;
int n[1000],m[1000],k[1000];
void read()
{
    cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>n[i]>>m[i]>>k[i];
        if(n[i]%2==1||m[i]%2==1)
        {
            cout<<"NO"<<endl;
        }
        else if(n[i]==m[i]&&m[i]==2)
        {
            if(k[i]==1)
            {
                cout<<"YES"<<endl;
                cout<<"1 1"<<'\n'<<"1 1"<<endl;
            }
            else cout<<"NO"<<endl;
        }
        else if(n[i]==2&&m[i]==4)
        {
            if(k[i]==2)
            {
                cout<<"YES"<<endl;
                cout<<"1 1"<<endl;
                cout<<"1 1"<<endl;
                cout<<"2 2"<<endl;
                cout<<"2 2"<<endl;
            }
            else cout<<"NO"<<endl;
        }
        else if(n[i]==4&&m[i]==2)
        {
            if(k[i]==2)
            {
                cout<<"YES"<<endl;
                cout<<"1 1 2 2"<<endl;
                cout<<"1 1 2 2"<<endl;
            }
            else cout<<"NO"<<endl;
        }
        else if(n[i]==4&&m[i]==4)
        {
            if(k[i]==2)
            {
                cout<<"YES"<<endl;
                cout<<"1 1 1 1"<<endl;
                cout<<"1 2 2 1"<<endl;
                cout<<"1 2 2 1"<<endl;
                cout<<"1 1 1 1"<<endl;
            }
            else if(k[i]==4)
            {
                cout<<"YES"<<endl;
                cout<<"1 1 2 2"<<endl;
                cout<<"1 1 2 2"<<endl;
                cout<<"3 3 4 4"<<endl;
                cout<<"3 3 4 4"<<endl;
            }

        }
    }

}
int main()
{
	read();
    return 0;
}
