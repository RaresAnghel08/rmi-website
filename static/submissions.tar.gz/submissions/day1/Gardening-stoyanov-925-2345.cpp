/**
* user:  stoyanov-925
* fname: Stefan Ivaylov
* lname: Stoyanov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:24:17.353189
*/
#include<iostream>
#include<cstdio>
using namespace std;
int n,m,k;
int main()
{
    /*ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);*/
    int T;
    scanf("%d",&T);
    for(int test=0; test<T; test++)
    {
        scanf("%d%d%d",&n,&m,&k);
        if(n!=m)
        {
            //This is not true but what to do?!
            printf("NO\n");
            return 0;
        }
        if(n%2)
        {
            printf("NO\n");
            return 0;
        }
        if(n/2<k||n/2>k)
        {
            printf("NO\n");
            return 0;
        }
        int i,j;
        for(i=1; i<=n/2; ++i,printf("\n"))
        {
            for(j=1; j<i; j++)
                printf("%d ",j);
            for(; j<=n-i+1; j++)
                printf("%d ",i);
            for(; j<=n; j++)
                printf("%d ",n-j+1);
        }
        for(i=n/2; i>=1; i--,printf("\n"))
        {
            for(j=1; j<i; j++)
                printf("%d ",j);
            for(; j<=n-i+1; j++)
                printf("%d ",i);
            for(; j<=n; j++)
                printf("%d ",n-j+1);
        }
    }
    return 0;
}
