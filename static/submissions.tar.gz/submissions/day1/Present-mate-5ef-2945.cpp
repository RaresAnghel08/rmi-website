/**
* user:  mate-5ef
* fname: Lőrinc
* lname: Máté
* task:  Present
* score: 0.0
* date:  2021-12-16 10:21:24.108014
*/
#include <bits/stdc++.h>

using namespace std;

bool jo (int mask){
    for (int i = 0; i < 32 - __builtin_clz(mask); i++){
        if (!(mask & (1 << i))) continue;
        for (int j = 0; j < i; j++) {
            if (mask & (1 << j) && !(mask & (1 << (__gcd(i + 1, j + 1) - 1)))) {
                // cout << mask << ": " << i << " " << j << " " << __gcd(i + 1, j + 1) << endl;
                return false;
            }
        }
    }
    return true;
}


int main()
{
    int t;
    cin >> t;

    vector<int> mo;

    for (int mask = 1; mask < (1 << 14); mask++){
        if (jo(mask)) mo.push_back(mask);
    }

    cout << mo.size() << endl;

    for (int i = 0; i < t; i++){
        int a;
        cin >> a;

        cout << __builtin_popcount(mo[a - 1]) << " ";
        for (int i = 0; i < 30; i++){
            if (mo[a - 1] & (1 << i)) cout << i + 1 << " ";
        }
        cout << endl;

    }

    return 0;
}
