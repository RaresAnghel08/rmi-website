/**
* user:  marciuc-b16
* fname: Andrei
* lname: Marciuc
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:30:18.573842
*/
#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;

vector<int> v;
int n, m, k;

int main()
{
    int q;
    cin >> q;
    while( q-- ) {
        cin >> n >> m >> k;

        int lin = n >> 1;
        int col = m >> 1;
        int maxx = lin * col;

        if( k > maxx || n == 1 || m == 1 )
            cout << "NO\n";
        else {
            cout << "YES\n";
            int l = 0;
            int c = 0, culoare = 0;
            int a[ n + 10 ][ m + 10 ];
            for( ; l + 1 < n; l += 2 )
                for( c = 0; c + 1 < m; c += 2, culoare++ ){
                    a[ l ][ c ] = culoare;
                    a[ l + 1 ][ c ] = culoare;
                    a[ l ][ c + 1 ] = culoare;
                    a[ l + 1 ][ c + 1 ] = culoare;

                }
            if( m & 1 )
                for( l = 0 ; l < n; l++ )
                    a[ l ][ m - 1 ] = a[ l ][ m - 2 ];
            if( n & 1 )
                for( int c = 0; c < m; c++ )
                    a[ n - 1 ][ c ] = a[ n - 2 ][ c ];
                   /* for( int l = 0; l < n; l++ ) {
                        for( int c = 0; c < m; c++ )
                            cout << a[ l ][ c ] + 1 << ' ';
                        cout << '\n';
                    }
                    cout << '\n';*/
            int cnt = culoare - k, set_col = 0, coll;
            for( l = 2; l + 1 < n && cnt; l += 2 )
                for( c = m - ( m & 1 ) - 2; c >= 0 && cnt; c -= 2 ) {
                    set_col = a[ l - 1 ][ c ];
                    coll = a[ l ][ c ];
                    a[ l ][ c ] = set_col;
                    a[ l + 1 ][ c ] = set_col;
                    a[ l ][ c + 1 ] = set_col;
                    a[ l + 1 ][ c + 1 ] = set_col;
                    cnt -= ( set_col != coll );
                   /* printf( "cnt = %d\n", cnt );
                    for( int l = 0; l < n; l++ ) {
                        for( int c = 0; c < m; c++ )
                            cout << a[ l ][ c ] + 1 << ' ';
                        cout << '\n';
                    }
                    cout << '\n';*/

                }

            if( ( m & 1 ) )
                for( l = 0 ; l < n; l++ )
                    a[ l ][ m - 1 ] = a[ l ][ m - 2 ];
            if( ( n & 1 ) )
                for( int c = 0; c < m; c++ )
                    a[ n - 1 ][ c ] = a[ n - 2 ][ c ];
            printf( "" );
            for( c = 0; c + 1 < m && cnt; c += 2 ) {
                set_col = a[ 0 ][ c - 1 ];
                coll = a[ 0 ][ c ];
                for( l = 0; l <= n; l++ )
                    a[ l ][ c ] = a[ l ][ c + 1 ] = set_col;
                cnt -= ( coll != set_col );
            }
         //   printf( "----------->          cnt = %d\n", cnt );
           /* for( int l = 0; l < n; l++ ) {
                for( int c = 0; c < m; c++ )
                    cout << a[ l ][ c ] + 1 << ' ';
                cout << '\n';
            }
            cout << '\n';
            */if( ( m & 1 ) )
                for( l = 0; l < n; l++ )
                    a[ l ][ m - 1 ] = a[ l ][ m - 2 ];

            int *f = new int[n * m + 100]();

            for( int l = 0; l < n; l++ )
                for( int c = 0; c < m; c++ )
                    if( f[ a[ l ][ c ] ] == 0 ) {
                        v.push_back( a[ l ][ c ] );
                        f[ a[ l ][ c ] ] = 1;
                    }
            sort( v.begin(), v.end() );
            for( int i = 0; i < v.size(); i++ )
                f[ v[ i ] ] = i + 1;
           // cout << "\tfinal " << cnt << "\n";
            for( int l = 0; l < n; l++ ) {
                for( int c = 0; c < m; c++ )
                    cout << f[ a[ l ][ c ] ] << ' ';
                cout << '\n';
            }
            //cout << '\n';
            delete( f );
            v.clear();
        }
    }
    //6 7 4 ( par impar )
    return 0;
}
