/**
* user:  saitov-09b
* fname: Damir
* lname: Saitov
* task:  Gardening
* score: 11.0
* date:  2021-12-16 10:49:20.561226
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;

signed main()
{
    int mem1, mem2, mem;
    int t;
    cin >> t;
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    for(int ti = 0; ti < t; ++ti)
    {
        int n,m,k;
        cin >> n >> m >> k;
        if(n % 2 != 0 || m % 2 != 0)
        {
            cout << "NO" << '\n';
            continue;
        }
        n/=2;
        m/=2;
        if(k < max(n,m))
        {
            cout << "NO\n";
            continue;
        }
        if(n == 3)
        {
            int pull = 1;
            int a = (k - m - 1) / 2;
            int p = k - m - 2 * a;
            int ke = m - a - p;
            vector <int> row1;
            vector <int> row2;
            vector <int> row3;
            vector <int> row4;
            vector <int> row5;
            vector <int> row6;
            if(ke >= 3 && p >= 2)
            {
                cout << "YES\n";

                for(int i = 0; i < a; ++i)
                {
                    row1.push_back(pull);
                    row1.push_back(pull);
                    row2.push_back(pull);
                    row2.push_back(pull);
                    pull++;

                    row3.push_back(pull);
                    row3.push_back(pull);
                    row4.push_back(pull);
                    row4.push_back(pull);
                    pull++;

                    row5.push_back(pull);
                    row5.push_back(pull);
                    row6.push_back(pull);
                    row6.push_back(pull);
                    pull++;

                }
                for(int i = 0; i < p; ++i)
                {
                    row1.push_back(pull);
                    row1.push_back(pull);
                    row2.push_back(pull);
                    row2.push_back(pull);
                    pull++;
                }
                for(int i = 0; i < p; ++i)
                {
                    row3.push_back(pull);
                    row3.push_back(pull);
                    row6.push_back(pull);
                    row6.push_back(pull);

                }
                mem = pull;
                if(p != 0)
                {
                    row4.push_back(pull);
                    row5.push_back(pull);
                    pull++;
                }

                for(int i = 0; i < p - 1; ++i)
                {
                    row4.push_back(pull);
                    row4.push_back(pull);
                    row5.push_back(pull);
                    row5.push_back(pull);
                    pull++;
                }
                if(p != 0)
                {
                    row4.push_back(mem);
                    row5.push_back(mem);
                }

                for(int i = 0; i < ke; ++i)
                {
                    row1.push_back(pull);
                    row1.push_back(pull);
                    row6.push_back(pull);
                    row6.push_back(pull);
                }
                mem1 = pull;
                row2.push_back(pull);
                row3.push_back(pull);
                row4.push_back(pull);
                row5.push_back(pull);
                pull++;
                for(int i = 0; i < ke - 1; ++i)
                {
                    row2.push_back(pull);
                    row2.push_back(pull);
                    row5.push_back(pull);
                    row5.push_back(pull);
                }
                row3.push_back(pull);
                row4.push_back(pull);
                mem2 = pull;
                pull++;
                for(int i = 0; i < ke - 2; ++i)
                {
                    row3.push_back(pull);
                    row3.push_back(pull);
                    row4.push_back(pull);
                    row4.push_back(pull);
                    pull++;
                }
                row3.push_back(mem2);
                row4.push_back(mem2);

                row2.push_back(mem1);
                row3.push_back(mem1);
                row4.push_back(mem1);
                row5.push_back(mem1);

                for(int i : row1)
                    cout << i << " ";
                cout << '\n';
                for(int i : row2)
                    cout << i << " ";
                cout << '\n';
                for(int i : row3)
                    cout << i << " ";
                cout << '\n';
                for(int i : row4)
                    cout << i << " ";
                cout << '\n';
                for(int i : row5)
                    cout << i << " ";
                cout << '\n';
                for(int i : row6)
                    cout << i << " ";
                cout << '\n';
                continue;
            }
            // Try to solve when p equals zero
            if(k % 2 == m % 2)
            {
             a = (k - m) / 2;
             ke = m - a;
             p = 0;
             if(ke >= 3)
             {
                 cout << "YES\n";
                 for(int i = 0; i < a; ++i)
                 {
                     row1.push_back(pull);
                     row1.push_back(pull);
                     row2.push_back(pull);
                     row2.push_back(pull);
                     pull++;

                     row3.push_back(pull);
                     row3.push_back(pull);
                     row4.push_back(pull);
                     row4.push_back(pull);
                     pull++;

                     row5.push_back(pull);
                     row5.push_back(pull);
                     row6.push_back(pull);
                     row6.push_back(pull);
                     pull++;

                 }
                 for(int i = 0; i < p; ++i)
                 {
                     row1.push_back(pull);
                     row1.push_back(pull);
                     row2.push_back(pull);
                     row2.push_back(pull);
                     pull++;
                 }
                 for(int i = 0; i < p; ++i)
                 {
                     row3.push_back(pull);
                     row3.push_back(pull);
                     row6.push_back(pull);
                     row6.push_back(pull);

                 }
                 mem = pull;
                 if(p != 0)
                 {
                     row4.push_back(pull);
                     row5.push_back(pull);
                     pull++;
                 }

                 for(int i = 0; i < p - 1; ++i)
                 {
                     row4.push_back(pull);
                     row4.push_back(pull);
                     row5.push_back(pull);
                     row5.push_back(pull);
                     pull++;
                 }
                 if(p != 0)
                 {
                     row4.push_back(mem);
                     row5.push_back(mem);
                 }

                 for(int i = 0; i < ke; ++i)
                 {
                     row1.push_back(pull);
                     row1.push_back(pull);
                     row6.push_back(pull);
                     row6.push_back(pull);
                 }
                 mem1 = pull;
                 row2.push_back(pull);
                 row3.push_back(pull);
                 row4.push_back(pull);
                 row5.push_back(pull);
                 pull++;
                 for(int i = 0; i < ke - 1; ++i)
                 {
                     row2.push_back(pull);
                     row2.push_back(pull);
                     row5.push_back(pull);
                     row5.push_back(pull);
                 }
                 row3.push_back(pull);
                 row4.push_back(pull);
                 mem2 = pull;
                 pull++;
                 for(int i = 0; i < ke - 2; ++i)
                 {
                     row3.push_back(pull);
                     row3.push_back(pull);
                     row4.push_back(pull);
                     row4.push_back(pull);
                     pull++;
                 }

                 row3.push_back(mem2);
                 row4.push_back(mem2);

                 row2.push_back(mem1);
                 row3.push_back(mem1);
                 row4.push_back(mem1);
                 row5.push_back(mem1);

                 for(int i : row1)
                     cout << i << " ";
                 cout << '\n';
                 for(int i : row2)
                     cout << i << " ";
                 cout << '\n';
                 for(int i : row3)
                     cout << i << " ";
                 cout << '\n';
                 for(int i : row4)
                     cout << i << " ";
                 cout << '\n';
                 for(int i : row5)
                     cout << i << " ";
                 cout << '\n';
                 for(int i : row6)
                     cout << i << " ";
                 cout << '\n';
                 continue;
             }

            }
            //Try to solve when ke equals zero
            if(k - 2 * m >= 0 && 3 * m - k >= 2)
            {
                a = k - 2 * m;
                p = 3 * m - k;
                ke = 0;
                cout << "YES\n";
                for(int i = 0; i < a; ++i)
                {
                    row1.push_back(pull);
                    row1.push_back(pull);
                    row2.push_back(pull);
                    row2.push_back(pull);
                    pull++;

                    row3.push_back(pull);
                    row3.push_back(pull);
                    row4.push_back(pull);
                    row4.push_back(pull);
                    pull++;

                    row5.push_back(pull);
                    row5.push_back(pull);
                    row6.push_back(pull);
                    row6.push_back(pull);
                    pull++;

                }
                for(int i = 0; i < p; ++i)
                {
                    row1.push_back(pull);
                    row1.push_back(pull);
                    row2.push_back(pull);
                    row2.push_back(pull);
                    pull++;
                }
                for(int i = 0; i < p; ++i)
                {
                    row3.push_back(pull);
                    row3.push_back(pull);
                    row6.push_back(pull);
                    row6.push_back(pull);

                }
                mem = pull;
                if(p != 0)
                {
                    row4.push_back(pull);
                    row5.push_back(pull);
                    pull++;
                }

                for(int i = 0; i < p - 1; ++i)
                {
                    row4.push_back(pull);
                    row4.push_back(pull);
                    row5.push_back(pull);
                    row5.push_back(pull);
                    pull++;
                }
                if(p != 0)
                {
                    row4.push_back(mem);
                    row5.push_back(mem);
                }


                for(int i : row1)
                    cout << i << " ";
                cout << '\n';
                for(int i : row2)
                    cout << i << " ";
                cout << '\n';
                for(int i : row3)
                    cout << i << " ";
                cout << '\n';
                for(int i : row4)
                    cout << i << " ";
                cout << '\n';
                for(int i : row5)
                    cout << i << " ";
                cout << '\n';
                for(int i : row6)
                    cout << i << " ";
                cout << '\n';
                continue;
            }
            //If ke & p both are equal to zero
            if(k == 3 * m)
            {
                a = m;
                p = 0;
                ke = 0;
                cout << "YES\n";
                for(int i = 0; i < a; ++i)
                {
                    row1.push_back(pull);
                    row1.push_back(pull);
                    row2.push_back(pull);
                    row2.push_back(pull);
                    pull++;

                    row3.push_back(pull);
                    row3.push_back(pull);
                    row4.push_back(pull);
                    row4.push_back(pull);
                    pull++;

                    row5.push_back(pull);
                    row5.push_back(pull);
                    row6.push_back(pull);
                    row6.push_back(pull);
                    pull++;

                }

                for(int i : row1)
                    cout << i << " ";
                cout << '\n';
                for(int i : row2)
                    cout << i << " ";
                cout << '\n';
                for(int i : row3)
                    cout << i << " ";
                cout << '\n';
                for(int i : row4)
                    cout << i << " ";
                cout << '\n';
                for(int i : row5)
                    cout << i << " ";
                cout << '\n';
                for(int i : row6)
                    cout << i << " ";
                cout << '\n';
                continue;
            }
            cout << "NO\n";

        }
        if(n == 2)
        {
            int a = k - m;
            int b = 2 * m - k;
            if(b < 0 || b == 1 || a < 0)
            {
                cout << "NO\n";
                continue;
            }
            cout << "YES\n";
            vector <int> row1;
            vector <int> row2;
            vector <int> row3;
            vector <int> row4;
            int pull = 1;
            for(int i = 0; i < a; ++i)
            {
                row1.push_back(pull);
                row1.push_back(pull);
                row2.push_back(pull);
                row2.push_back(pull);
                pull++;

                row3.push_back(pull);
                row3.push_back(pull);
                row4.push_back(pull);
                row4.push_back(pull);
                pull++;
            }

            for(int i = 0; i < b; ++i)
            {
                row1.push_back(pull);
                row1.push_back(pull);
                row4.push_back(pull);
                row4.push_back(pull);
            }
            mem = pull;
            if(b != 0)
            {
                row2.push_back(pull);
                row3.push_back(pull);
                pull++;
            }

            for(int i = 0; i < b - 1; ++i)
            {
                row2.push_back(pull);
                row2.push_back(pull);
                row3.push_back(pull);
                row3.push_back(pull);
                pull++;
            }
            if(b != 0)
            {
                row2.push_back(mem);
                row3.push_back(mem);
            }

            for(int i : row1)
                cout << i << " ";
            cout << '\n';
            for(int i : row2)
                cout << i << " ";
            cout << '\n';
            for(int i : row3)
                cout << i << " ";
            cout << '\n';
            for(int i : row4)
                cout << i << " ";
            cout << '\n';
        }
        if(n == 1)
        {
            if(k != m)
            {
                cout << "NO\n";
                continue;
            }
            vector <int> row1;
            vector <int> row2;
            int pull = 1;
            for(int i = 0; i < k; ++i)
            {
                row1.push_back(pull);
                row1.push_back(pull);
                row2.push_back(pull);
                row2.push_back(pull);
                pull++;
            }
            cout << "YES\n";
            for(int i : row1)
                cout << i << " ";
            cout << '\n';
            for(int i : row2)
                cout << i << " ";
            cout << '\n';
        }



    }
}