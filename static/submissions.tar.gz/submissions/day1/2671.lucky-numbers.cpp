/**
* user:  bortolin-a96
* fname: Alessandro
* lname: Bortolin
* task:  lucky
* score: 46.0
* date:  2019-10-10 09:46:24.271324
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
#define fi first
#define se second

constexpr int MAXN = 1 << 18, MOD = 1e9 + 7;

int N, Q;
int S[MAXN];

void calc(int L, int R) {
	ll a=1, b=1, c=1;
	int tmp = S[L-1];
	S[L-1] = 0;
	for (int i=R-1; i>=L-1; i--) {
		ll a1 = (9 * a + b) % MOD;
		ll b1 = (8 * a + b) % MOD;
		ll c1 = 0;
		if (S[i] == 1) {
			if (S[i+1] == 0) {
				c1 = c;
			} else if (S[i+1] == 1) {
				c1 = (a + c) % MOD;
			} else if (S[i+1] == 2) {
				c1 = (a + b + c) % MOD;
			} else if (S[i+1] == 3) {
				c1 = (2 * a + b) % MOD;
			} else {
				c1 = ((S[i+1] - 2) * a + b + c) % MOD;
			}
		} else {
			if (S[i+1] == 0) {
				c1 = c;
			} else if (S[i+1] == 1) {
				c1 = (a + c) % MOD;
			} else {
				c1 = ((S[i+1] - 1) * a + b + c) % MOD;
			}
		}
		a = a1;
		b = b1;
		c = c1;
	}
	cout << c << '\n';
	S[L-1] = tmp;
}

int main() {
	ios::sync_with_stdio(false);
	
	cin >> N >> Q;
	for (int i=1; i<=N; i++) {
		char c;
		cin >> c;
		S[i] = c - '0';
	}
	calc(1, N);
	for (int i=0; i<Q; i++) {
		int t, a, b;
		cin >> t >> a >> b;
		if (t == 1) {
			calc(a, b);
		} else {
			S[a] = b;
		}
	}
	
	return 0;
}
