/**
* user:  beliaev-6a5
* fname: Vladislav
* lname: Beliaev
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:11:25.453671
*/
#include <iostream>
#include <vector>
#include <set>
#include <queue>

using namespace std;

typedef long long ll;

int main() {
	ll tt;
	cin >> tt;
	for (int t = 0; t < tt; t++) {
		ll n, m, k;
		ll x, y;
		cin >> n >> m >> k;
		x = n, y = m;
		vector<vector<ll>> d(n);
		for (int i = 0; i < n; i++) {
			d[i].resize(m);
		}	
		ll cnt = 1;
		if (k > (n / 2) * (m / 2) || n % 2 == 1 || m % 2 == 1) {
			cout << "NO" << endl;
			continue;
		}
		else {
			while (k != (n / 2) * (m / 2)) {
				if (n < 2 || m < 2) {
					break;
				}
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < m; j++) {
						if (i == 0 || j == 0 || i == n - 1 || j == m - 1) {
							d[i][j] = cnt;
						}
					}
				}
				cnt++;
				k--;
				n -= 2;
				m -= 2;
			}
			if (k != (n / 2) * (m / 2)) {
				cout << "NO" << endl;
				continue;
			}
		}
		ll l = (x - n) / 2;
		for (int i = l; i < x - l; i+=2) {
			for (int j = l; j < y - l; j+= 2) {
				if (i + 1 < x - l && j + 1 < y - l) {
					d[i][j] = cnt;
					d[i + 1][j] = cnt;
					d[i][j + 1] = cnt;
					d[i + 1][j + 1] = cnt;
					cnt++;
				}
			}
		}
		cout << "YES" << endl;
		for (int i = 0; i < x; i++) {
			for (int j = 0; j < y; j++) {
				cout << d[i][j] << " ";
			}
			cout << endl;
		}
		queue<ll> q;
	}
	return 0;
}