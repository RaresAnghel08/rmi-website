/**
* user:  nikolov-3ed
* fname: Zdravko Svetlozarov
* lname: Nikolov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:48:25.231093
*/
#include <bits/stdc++.h>
#include "speedrun.h"
using namespace std;
string tobin(int num)
{
    string ans="";
    do
    {
        int mod=num%2;
        ans=ans+(char)(mod+'0');
        num/=2;
    }while(n!=0);
    return ans;

}
void assignHints(int subtask, int N, int A[], int B[])
{
    if(subtask==2)
    {
        setHintLen(15);
        int used[1001];
        for(int i=1;i<N;i++)
        {
            used[A[i]]++;
            used[B[i]]++;
        }
        int i=1;
        for(;i<=N;i++)
        {
            if(used[i]>1)break;
        }
        string ans=tobin(i);
        for(int i=1;i<=N;i++)
        {
            for(int j=0;j<ans.size();j++)
            {
                setHint(i,j+1,(ans[j]-'0'));
            }
        }
    }
}
int toDec(string num)
{
    int nnew=0;
    for(int i=0;i<num.size();i++)
    {
        int add=1;
        for(int j=0;j<i;j++)
        {
            add*=2;
        }
        nnew=num+((num[i]-'0')*add);
    }
    return nnew;
}
void speedrun(int subtask, int N, int start);
{
    if(subtask==2)
    {
        string s="";
        for(int i=1;i<=getLength();i++)
        {
            s=s+(char)(getHint(i)+'0');
        }
        int star=toDec(s);
        if(start==star)
        {
            for(int i=1;i<=N;i++)
            {
                if(i!=star)
                {
                    goTo(i);
                    goTo(star);
                }
            }
        }
        else
        {
            goTo(star);
            for(int i=1;i<=N;i++)
            {
                if(i!=star)
                {
                    goTo(i);
                    goTo(star);
                }
            }
        }
    }
}

