/**
* user:  smutchak-ea1
* fname: Andrii
* lname: Smutchak
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 10:21:10.739510
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
bool G[1007][1007];
int sz[1007];
vector<int> GG[1007];
vector<int> euler;
int timer;
int tout[1007];
int tin[1007];
int P[1007];
int C[1007];
int level[1007];
int n = 0;
void add_hint(int v,int a,int b){
	//cout << " " << v << " add " << a << "," << b << "," << c << "\n";
	int T = a;
	int j = 10;
	while(T) setHint(v,j--,(T&1)),T>>=1;
	T = b;
	j = 20;
	while(T) setHint(v,j--,(T&1)),T>>=1;
}
pair<int,int> decode_hint(){
	int a = 0;
	int b = 0;
	for (int i = 0; i < 10; ++i)
	{
		a = (a<<1)|(getHint(i+1));
	}
	for (int i = 10; i < 20; ++i)
	{
		b = (b<<1)|(getHint(i+1));
	}
	//cout << " decode " << a << " " << b << "\n"; 
	return {a,b};
}
void dfsE(int v,int p){
	tin[v] = euler.size();
	euler.push_back(v);
	for (int i = 0; i < GG[v].size(); ++i)
	{
		if(GG[v][i] == p) continue;
		if(C[v] == 0) C[v] = GG[v][i];
		dfsE(GG[v][i],v);
		euler.push_back(v);
	}
	tout[v] = euler.size()-1;
	P[v] = p;
}
void assignHints(int subtask, int N, int A[], int B[]) { 
	if(subtask == 1){
		setHintLen(N);
		for (int i = 1; i < N; ++i)
		{
			setHint(A[i],B[i],1);
			setHint(B[i],A[i],1);
		}
	}
	if(subtask == 2){
		bool array[10] = {0,0,0,0,0,0,0,0,0,0};
		setHintLen(10);
		for (int i = 1; i < N; ++i)
		{
			sz[A[i]]++;
			sz[B[i]]++;
		}
		int c = 0;
		for (int i = 1; i <=N; ++i)
		{
			if(sz[i] == N-1){
				int j = 9;
				int T = i;
				while(T) array[j--] = (T&1),T>>=1;
			}
		}
		for (int i = 1; i <= N; ++i)
		{
			for (int j = 1; j <= 10; ++j)
			{
				setHint(i,j,array[j-1]);
			}
		}
	}
	if(subtask == 3){
		setHintLen(20);
		for (int i = 1; i < N; ++i)
		{
			GG[A[i]].push_back(B[i]);
			GG[B[i]].push_back(A[i]);
		}
		for (int i = 1; i <= N; ++i)
		{
			if(GG[i].size() == 0) break;
			if(GG[i].size() == 1){
				int T = GG[i][0];
				int j = 10;
				while(T) setHint(i,j--,(T&1)),T>>=1;
			}
			if(GG[i].size() == 2){
				int T = GG[i][0];
				int j = 10;
				while(T) setHint(i,j--,(T&1)),T>>=1;
				T = GG[i][1];
				j = 20;
				while(T) setHint(i,j--,(T&1)),T>>=1;
			}
		}
	}
	if(subtask == 4 or subtask == 5){
		setHintLen(20);
		for (int i = 1; i < N; ++i)
		{
			GG[A[i]].push_back(B[i]);
			GG[B[i]].push_back(A[i]);
		}
		dfsE(1,0);
		euler.push_back(0);
		euler.push_back(0);
		euler.push_back(0);
		for (int i = 1; i <= N; ++i)
		{
			add_hint(i,C[i],euler[tout[i]+2]);
		}
	}
}
void dfs1(int v,int p){
	for (int i = 1; i <= n; ++i)
		{
			if(i == v or i == p) continue;
			if(getHint(i)) goTo(i),dfs1(i,v);
		}
	if(p) goTo(p);
}
void dfs3(int v,int p){
	vector<int> G;
	int t = 0;
	for (int i = 0; i < 10; ++i)
	{
		t = (t<<1)|(getHint(i+1));
	}
	if(t) G.push_back(t);
	t = 0;
	for (int i = 10; i < 20; ++i)
	{
		t = (t<<1)|(getHint(i+1));
	}
	if(t) G.push_back(t);

	for (int i = 0; i < G.size(); ++i)
	{
		if(G[i] == p) continue;
		else goTo(G[i]),dfs3(G[i],v);
	}
	if(p) goTo(p);

}
int dfsE2(int v,int p){
	pair<int,int> Hint = decode_hint();
	int c = Hint.first;
	//int p = Hint.second.first;
	int next = Hint.second;
	while(1){
		if (c == 0 or c == p) break;
		goTo(c);
		int new_c = dfsE2(c,v);
			//if(new_c == 0 or new_c == p) break;
		c = new_c;
	}
	if(p) goTo(p);
	return next;
}
bool found1 = 0;
bool GoTo(int v){
	if(v == 0) return false;
	else return goTo(v);
}
void up(int v){
	if(v == 1) return;
	int c = decode_hint().first;
	int last_c = c;
	while(GoTo(c)){
		last_c = c;
		c = decode_hint().second;
		goTo(v);
	}
	//cout << "AAAA" << "\n";
	int p = last_c;
	goTo(p);
	up(p);
}
void speedrun(int subtask, int N, int start) {
	n = N;
	if (subtask == 1)
	{
		dfs1(start,0);
		return;
	}
	if(subtask == 2){
		int v = 0;
		for (int i = 0; i < 10; ++i)
		{
			v = (v<<1)|(getHint(i+1));
		}
		if(v == start){
			for (int i = 1; i <= N; ++i)
			{
				if(i == start) continue;
				goTo(i);
				goTo(v);
			}
		}
		else{
			goTo(v);
			for (int i = 1; i <= N; ++i)
			{
				if(i == start or i == v) continue;
				goTo(i);
				goTo(v);
			}
		}
		return;
	}
	if(subtask == 3){
		dfs3(start,0);
		return;
	}
	if(subtask == 4 or subtask == 5){
		pair<int,int> Hint = decode_hint();
		int c = Hint.first;
		int next = Hint.second;

		if(c == 0){
			for (int i = 1; i <= N; ++i)
			{
				if(goTo(i)){
					start = i;
					break;
				}
			}
		}
		up(start);
		dfsE2(1,0);
	}
}
