/**
* user:  kryvoviaz-45e
* fname: Illia
* lname: Kryvoviaz
* task:  Gardening
* score: 5.0
* date:  2021-12-16 10:43:51.801645
*/
#include <bits/stdc++.h>

using namespace std;

int n, m, k;

/*int can[10][10][10];
int dfs(int n, int m, int k) {
    if (can[n][m][k] != -1)return can[n][m][k];

    if (k <= 0 && n <= 0 && m <= 0)return can[n][m][k] = true;
    if (n <= 1 || m <= 1)return can[n][m][k] = false;
    if (k == 1)return can[n][m][k] = (n == 2 && m == 2);

    if (n == 2)return can[n][m][k] = dfs(n, m - 2, k - 1);
    if (m == 2)return can[n][m][k] = dfs(n - 2, m, k - 1);


    can[n][m][k] = dfs(n - 2, m - 2, k - 1);
    if (n % 2 == 0 && k >= n/2)can[n][m][k] |= dfs(n, m - 2, k - (n / 2));
    if (m % 2 == 0 && k >= m/2)can[n][m][k] |= dfs(n - 2, m, k - (m / 2));
    return can[n][m][k];
}*/

void solve() {
    cin >> n >> m >> k;
    if (n % 2 != 0 || m % 2 != 0){cout << "NO\n";return;}
    /*if ((n / 2) * (m / 2) == k) {
        cout << "YES\n";
        vector<vector<int> > ans(n + 3, vector<int>(m + 3));
        int id = 1;
        for (int i = 1; i <= n; i += 2) {
            for (int j = 1; j <= m; j += 2) {
                ans[i][j] = id;
                ans[i+1][j] = id;
                ans[i][j+1] = id;
                ans[i+1][j+1] = id;
                id++;
            }
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++)
                cout << ans[i][j] << " ";
            cout << '\n';
        }
        return;
    }*/
    //if (n > 2 && m > 2) {
        int MX = (n / 2) * (m / 2), MN = ((n - 2) / 2) * ((m - 2) / 2) + 1;
        if (MN <= k && k <= MX && k != MX - 1) {
            cout << "YES\n";
            vector<vector<int> > ans(n + 3, vector<int>(m + 3, 0));
            int cnt = k - MN;
            int id = 1;
            int From = 1;
            for (int i = 1; i <= n; i += 2) {
                for (int j = 1; j <= 2*cnt - (cnt % 2); j += 2, From = j) {
                    ans[i][j] = id;
                    ans[i+1][j] = id;
                    ans[i][j+1] = id;
                    ans[i+1][j+1] = id;
                    id++;
                }
            }
            if (From <= m) {
                for (int i = 1; i <= n; i++) {ans[i][From] = id;ans[i][m] = id;}
                for (int i = From; i <= m; i++) {ans[1][i] = id;ans[n][i] = id;}
                id++;
                for (int i = 2; i < n; i += 2) {
                    for (int j = From + 1; j < m; j += 2) {
                        ans[i][j] = id;
                        ans[i+1][j] = id;
                        ans[i][j+1] = id;
                        ans[i+1][j+1] = id;
                        id++;
                    }
                }
            }
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= m; j++)
                    cout << ans[i][j] << " ";
                cout << '\n';
            }
            return;
        }
    //}

    cout << "NO\n";
    return;
    //cout << (dfs(n, m, k) ? "YES\n" : "NO\n");
}

int T;
int main()
{
    //memset(can, -1, sizeof(can));

    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
    /*
    int cnt = 0;
    for (int i = 1; i <= 4; i++) {
        for (int j = 1; j <= 4; j++) {
            for (int k = 1; k <= i*j; k++) {
                cout << i << " " << j << " " << k << endl;
                cnt++;
            }
        }
    }cout << cnt;*/
}

/**
100
1 1 1
1 2 1
1 2 2
1 3 1
1 3 2
1 3 3
1 4 1
1 4 2
1 4 3
1 4 4
2 1 1
2 1 2
2 2 1
2 2 2
2 2 3
2 2 4
2 3 1
2 3 2
2 3 3
2 3 4
2 3 5
2 3 6
2 4 1
2 4 2
2 4 3
2 4 4
2 4 5
2 4 6
2 4 7
2 4 8
3 1 1
3 1 2
3 1 3
3 2 1
3 2 2
3 2 3
3 2 4
3 2 5
3 2 6
3 3 1
3 3 2
3 3 3
3 3 4
3 3 5
3 3 6
3 3 7
3 3 8
3 3 9
3 4 1
3 4 2
3 4 3
3 4 4
3 4 5
3 4 6
3 4 7
3 4 8
3 4 9
3 4 10
3 4 11
3 4 12
4 1 1
4 1 2
4 1 3
4 1 4
4 2 1
4 2 2
4 2 3
4 2 4
4 2 5
4 2 6
4 2 7
4 2 8
4 3 1
4 3 2
4 3 3
4 3 4
4 3 5
4 3 6
4 3 7
4 3 8
4 3 9
4 3 10
4 3 11
4 3 12
4 4 1
4 4 2
4 4 3
4 4 4
4 4 5
4 4 6
4 4 7
4 4 8
4 4 9
4 4 10
4 4 11
4 4 12
4 4 13
4 4 14
4 4 15
4 4 16
*/
