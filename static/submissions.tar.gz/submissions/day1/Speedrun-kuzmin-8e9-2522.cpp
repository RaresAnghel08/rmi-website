/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  Speedrun
* score: 48.0
* date:  2021-12-16 09:39:37.385279
*/
#include <bits/stdc++.h>
#include "speedrun.h"

using namespace std;

typedef long long ll;
typedef long double ld;

// #define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back


const int maxn = 1100;
vi r[maxn];

void assignHints(int subtask, int N, int A[], int B[]) {
	if (subtask == 1) {
		setHintLen(N);
		for (int j = 1; j < N; ++j) {
			r[A[j]].pb(B[j]);
			r[B[j]].pb(A[j]);
		}
		for (int i = 1; i <= N; ++i) {
			for (auto &u : r[i]) {
				setHint(i, u, 1);
			}
		}
	} else if (subtask == 2) {
		setHintLen(20);
		for (int j = 1; j < N; ++j) {
			r[A[j]].pb(B[j]);
			r[B[j]].pb(A[j]);
		}
		int ans = 0;
		for (int k = 1; k <= N; ++k) {
			if (r[k].size() + 1 == N) {
				ans = k;
			}
		}
		for (int k = 1; k <= N; ++k) {
			if (r[k].size() + 1 == N)  {
				setHint(k, 1, 1);
			} else {
				for (int j = 0; j < 10; ++j) {
					if ((1 << j) & ans) {
						setHint(k, j + 2, 1);
					}
				}
			}
		}
	} else if (subtask == 3) {
		setHintLen(20);
		for (int j = 1; j < N; ++j) {
			r[A[j]].pb(B[j]);
			r[B[j]].pb(A[j]);
		}
		int ans = 0;
		for (int k = 1; k <= N; ++k) {
			for (int j = 0; j < r[k].size(); ++j) {
				for (int d = 0; d < 10; ++d) {
					if ((1 << d) & r[k][j]) {
						setHint(k, j * 10 + d + 1, 1);
					}
				}
			}
		}
	} else {
		// setHintLen(30);
		// for (int j = 1; j < N; ++j) {
		// 	r[A[j]].pb(B[j]);
		// 	r[B[j]].pb(A[j]);
		// }
		// int p[N];
		// memset(p, 0, sizeof(p));
		// int used[N + 1];
		// memset(used, 0, sizeof(used));
		
		// function<void(int)> dfs = [&] (int v) {
		// 	used[v] = 1;
		// 	for (auto &u : r[v]) {
		// 		if (!used[u]) {
		// 			p[u] = v;
		// 			dfs(u);
		// 		}
		// 	}
		// };
		// for (int i = 0; i < n; ++i) {
			
		// }
	}
}

void speedrun(int subtask, int N, int start) {
	if (subtask == 1) {
		int used[N + 1];
		memset(used, 0, sizeof(used));
		
		function<void(int)> dfs = [&] (int v) {
			used[v] = 1;
			for (int j = 1; j <= N; ++j) {
				if (!used[j] && getHint(j)) {
					goTo(j);
					dfs(j);
					goTo(v);
				}
			}
		};
		dfs(start);
	} else if (subtask == 2) {
		int now = start;
		int l = getLength();
		int x = getHint(1);
		if (x == 0) {
			int lol = 0;
			for (int j = 0; j < 10; ++j) {
				if (getHint(j + 2)) {
					lol |= (1 << j);
				}
			}
			goTo(lol);
			now = lol;
		}
		for (int i = 1; i <= N; ++i) {
			if (i != now) {
				goTo(i);
				goTo(now);
			}
		}
	} else if (subtask == 3) {
		int used[N + 1];
		memset(used, 0, sizeof(used));
		used[0] = 1;

		function<void(int)> dfs = [&] (int v) {
			used[v] = 1;
			vi rc;
			rc.pb(0);
			rc.pb(0);
			for (int k = 1; k <= 10; ++k) {
				if (getHint(k)) {
					rc[0] |= (1 << k - 1);
				}
			}
			for (int k = 11; k <= 20; ++k) {
				if (getHint(k)) {
					rc[1] |= (1 << k - 11);
				}
			}
			for (auto &j : rc) {
				if (!used[j]) {
					goTo(j);
					dfs(j);
					goTo(v);
				}
			}
		};
		dfs(start);
	}
}