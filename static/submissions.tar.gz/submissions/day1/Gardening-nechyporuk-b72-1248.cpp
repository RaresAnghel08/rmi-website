/**
* user:  nechyporuk-b72
* fname: Vladyslav
* lname: Nechyporuk
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:32:09.693225
*/
#include <bits/stdc++.h>

using namespace std;
void solve()
{
    int n,m,k;
    cin>>n>>m>>k;
    if((n/2)*(m/2)<k)
    {
        cout<<"NO\n";
        return;
    }
    cout<<"YES\n";
    int c=1;
    vector<int> ans[n];
    for(int i=0;i<n;i++)ans[i].resize(m);
    for(int i=0;i<n;i+=2)
    {
        for(int j=0;j<m;j+=2)
        {
            //cout<<i<<' '<<j<<'\n';
            if(j+1==m)
            {
                ans[i][j]=ans[i][j-1];
                return;
            }
            if(i+1==n)
            {
                ans[i][j]=ans[i-1][j];
                return;
            }
            ans[i][j]=c;
            ans[i+1][j]=c;
            ans[i][j+1]=c;
            ans[i+1][j+1]=c;
            if(c<k)c++;
        }
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cout<<ans[i][j]<<' ';
        }
        cout<<'\n';
    }
}
signed main()
{
    int t=1;
    cin>>t;
    while(t--)solve();
}
