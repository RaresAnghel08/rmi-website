/**
* user:  stancu-88b
* fname: Sergiu Nicolae
* lname: Stancu
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:34:24.735376
*/
#include "speedrun.h"
#include <vector>
#define pb push_back
#define nl '\n'
#include <iostream>
using namespace std;
const int NMAX = 2003;
vector<int>G1[NMAX];
bool viz[NMAX];
void assignHints ( int subtask, int N, int A[], int B[] )
{
    int stea = 0;
    setHintLen ( 20 );

    for ( int i = 1; i < N; i++ )
    {
        G1[A[i]].pb ( B[i] );
        G1[B[i]].pb ( A[i] );
    }

    int stanga = 0;

    for ( int i = 1; i <= N; i++ )
    {
        if ( G1[i].size() == 1 )
        {
            stanga = i;
            break;
        }
    }

    int crt = stanga;
    viz[crt] = 1;

    for ( int i = 1; i <= N; i++ )
    {
        for ( auto j : G1[i] )
            if ( viz[j] == 0 )
            {
                //cout<<j<<nl;
                viz[j] = 1;

                for ( int bit = 0; bit < 10; bit++ )
                    if ( ( 1 << bit ) &j )
                        setHint ( crt, 10 + bit + 1, 1 );///il fac pe dreapta lui crt

                int numar = crt;

                for ( int bit = 0; bit < 10; bit++ ) ///il fac pe stanga lui j
                    if ( ( 1 << bit ) &crt )
                        setHint ( j, bit + 1, 1 );

                crt = j;
            }
    }
}
vector<int>G[NMAX];
void DFS ( int x, int tata, int N )
{
    viz[x] = 1;

    for ( int j = 1; j <= N; j++ )
    {
        if ( getHint ( j ) == 1 )
            G[x].pb ( j );
    }

    for ( auto i : G[x] )
        if ( viz[i] == 0 )
        {
            goTo ( i );
            DFS ( i, x, N );
        }

    if ( tata != 0 )
        goTo ( tata );
}
void speedrun ( int subtask, int N, int start ) /* your solution here */
{
    int dreapta = 0;

    for ( int i = 1; i <= 10; i++ )
        if ( getHint ( 10 + i ) == 1 )
            dreapta += ( 1 << ( i - 1 ) );

//    {
//     cout<<start<<' '<<dreapta;
//     return;
//    }
    while ( dreapta != 0 )
    {
        goTo ( dreapta );
        int cdr = 0;

        for ( int i = 1; i <= 10; i++ )
            if ( getHint ( 10 + i ) == 1 )
                cdr += ( 1 << ( i - 1 ) );

        dreapta = cdr;
    }

    int stanga = 0;

    for ( int i = 1; i <= 10; i++ )
        if ( getHint ( i ) == 1 )
            stanga += ( 1 << ( i - 1 ) );

    while ( stanga != 0 )
    {
        goTo ( stanga );
        int cdr = 0;

        for ( int i = 1; i <= 10; i++ )
            if ( getHint ( i ) == 1 )
                cdr += ( 1 << ( i - 1 ) );

        stanga = cdr;
    }
}
