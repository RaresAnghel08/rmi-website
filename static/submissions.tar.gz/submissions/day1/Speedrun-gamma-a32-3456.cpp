/**
* user:  gamma-a32
* fname: Pascal
* lname: Gamma
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:08:00.001907
*/
#include "speedrun.h"
#include <bits/stdc++.h>

#ifndef LOCAL
#define dbg(x)
#else
#define dbg(x) cerr << #x << " = " << x << "\n";
#endif

using namespace std;

int log2(int n) {
  int logn = 1;
  while (n > 1 << logn)
    logn++;
  return logn;
}

void assignHints(int subtask, int N, int A[],
                 int B[]) { /* your solution here */
  int l = 316;
  setHintLen(l);
  vector<vector<int>> g(N + 1, vector<int>());
  for (int i = 1; i < N; i++) {
    dbg(A[i]);
    dbg(B[i]);
    g[A[i]].push_back(B[i]);
    g[B[i]].push_back(A[i]);
  }
  for (int i = 1; i <= N; i++) {
    int x = g[i].size();
    for (int j = 1; j <= log2(N); j++) {
      if (x % 2) {
        setHint(i, j, true);
      }
      x /= 2;
    }

    for (int j = 0; j < min(l / log2(N) - 1, (int)g[i].size()); j++) {
      int x = g[i][j] - 1;
      for (int k = 1; k <= log2(N); k++) {
        if (x % 2) {
          setHint(i, (j + 1) * log2(N) + k, true);
        }
        x /= 2;
      }
    }
  }
}

vector<int> decode(int n, int logn) {
  int l = getLength();
  int a = 0;
  for (int j = 1; j <= logn; j++) {
    if (getHint(j)) {
      a += 1 << (j - 1);
    }
  }
  dbg(a);
  vector<int> neighbours;
  neighbours.push_back(a);
  for (int i = 0; i < min(l / logn - 1, a); i++) {
    int x = 0;
    for (int j = 1; j <= logn; j++) {
      if (getHint(j + (i + 1) * logn)) {
        x += 1 << (j - 1);
      }
    }
    neighbours.push_back(x + 1);
  }
  return neighbours;
}

void dfs(int u, vector<int> &visited, int n, int logn) {
  dbg(u);
  visited[u] = true;
  vector<int> a = decode(n, logn);
  for (int i = 1; i < a.size(); i++) {
    if (!visited[a[i]]) {
      goTo(a[i]);
      dfs(a[i], visited, n, logn);
      goTo(u);
    }
  }
  for (int i = 0; i < a[0] - a.size() + 1; i++) {
    for (int j = 1; j <= n; j++) {
      if (!visited[j]) {
        if (goTo(j)) {
          dfs(j, visited, n, logn);
          goTo(u);
          break;
        }
      }
    }
  }
}

void speedrun(int subtask, int N, int start) { /* your solution here */
  dbg(start);
  vector<int> neighbours = decode(N, log2(N));
  for (int e : neighbours) {
    cout << e << " ";
  }
  cout << "\n";
  vector<int> visited(N + 1);
  dfs(start, visited, N, log2(N));
}
