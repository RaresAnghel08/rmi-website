/**
* user:  ivan-e65
* fname: Tudor
* lname: Ivan
* task:  Present
* score: 0.0
* date:  2021-12-16 11:51:17.893526
*/
#include <iostream>
#include<bits/stdc++.h>
using namespace std;
const int N = 34;
long long nr1[N];
vector<set<int>> all;
set<int> aux;
void bkt(int k){
  if(k == 0){
    for(int i :aux){
      for(int j:aux){
        if(aux.count(__gcd(i, j)) == false)
          return;
      }
    }
    all.push_back(aux);
    return;
  }
  bkt(k - 1);

  aux.insert(k);
  bkt(k - 1);
  aux.erase(k);
}
bool cmp(set<int> a, set<int> b){
  auto itra = a.rbegin(), itrb = b.rbegin();
  while(itra != a.rend() && itrb != b.rend()){
    if((*itra) < (*itrb))
      return true;
    if((*itra) > (*itrb))
      return false;
    itra++;
    itrb++;
  }
  return a.size() < b.size();
}
void solve(long long n){
  if(n == 0){
    cout<<"0\n";
    return;
  }
  int i;
  for(i = 1; i <N; i++){
    if(n > nr1[i])
      n -= nr1[i];
    else
      break;
  }
  aux.clear();
  all.clear();
  aux.insert(i);
  bkt(i - 1);
  sort(all.begin(), all.end(), cmp);
  cout<<all[n  - 1].size()<<" ";
  for(auto x:all[n - 1])
    cout<<x<<" ";
  cout<<"\n";
}
int main()
{
  nr1[1] = 1;
  for(int i = 2; i < N; i++){
    nr1[i] = (1LL<<(i - 2));
    nr1[i] ++;
    for(int d = 2; d < i; d++){
      if(i%d == 0)
        nr1[i] += (1LL<<(d - 2));
    }
  }
  int t;
  cin>>t;
  while(t--){
    long long n;
    cin>>n;
    solve(n);
  }
  return 0;
}
