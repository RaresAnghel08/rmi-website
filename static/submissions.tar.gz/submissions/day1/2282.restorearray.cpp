/**
* user:  perju-verzotti-a3f
* fname: Luca
* lname: Perju-Verzotti
* task:  restore
* score: 7.0
* date:  2019-10-10 08:54:48.653112
*/
#include <iostream>

using namespace std;
struct ura
{
    int l,r,k,val;
}v[202];
int vc[20],sp[20],n,m;
void frm (int msk)
{
    int i=1;
    for(i=1;i<=n;++i)
    {
        vc[i]=msk&1;
        msk>>=1;
    }
    for(i=1;i<=n;++i)
        sp[i]=sp[i-1]+vc[i];
}
bool verif ()
{
    for(int i=1;i<=m;++i)
    {
        int l=v[i].l,r=v[i].r,k=v[i].k,val=v[i].val;
        int a=sp[r]-sp[l-1];
        if(val==1)
        {
            if((r-l+1)-a>=k)
                return false;
        }
        else
        {
            if((r-l+1)-a<k)
                return false;
        }
    }
    return true;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin>>n>>m;
    for(int i=1;i<=m;++i)
    {
        cin>>v[i].l>>v[i].r>>v[i].k>>v[i].val;
        ++v[i].l;
        ++v[i].r;
    }
    int msk;
    for(msk=0;msk<(1<<n);++msk)
    {
        frm(msk);
        if(verif())
        {
            for(int i=1;i<=n;++i)
                cout<<vc[i]<<' ';
            break;
        }
    }
    if(msk==(1<<n))
    {
        cout<<-1;
    }
    return 0;
}
