/**
* user:  nicolae-502
* fname: Radu Mihai
* lname: Nicolae
* task:  devil
* score: 0.0
* date:  2019-10-10 08:45:13.710981
*/
//#include<fstream>
#include<iostream>
using namespace std;
//ifstream fin("test.in");
//ofstream fout("tes.out");
int n,m,l,r,k,val,i;
int sol[50010];
int main()
{
    cin>>n>>m;
    for(;m--;)
    {
        cin>>l>>r>>k>>val;
        if(val==0)
        if(k==1)
        {
            if(val==1)
            {
                for(i=l;i<=r;i++)
                {
                    if(sol[i]==1)
                    {
                        cout<<"-1"; return 0;
                    }
                    sol[i]=2;
                }
            }
        }
    }
    for(i=0;i<n;i++) cout<<max(sol[i]-1,0);
    return 0;
}

