/**
* user:  abramson-f2e
* fname: Carmel
* lname: Abramson
* task:  Present
* score: 8.0
* date:  2021-12-16 09:37:13.348846
*/
#include<bits/stdc++.h>

using namespace std;
typedef vector<int> vi;
typedef vector<vi>vvi;
typedef long long ll;

#define pb push_back
#define all(x) x.begin(),x.end()
#define out(x) {cout << x << "\n"; return;}

void solve();
int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int t;
    cin >> t;
    while(t--)
        solve();
}

vvi ans;
void preprocess(){
    int mx=20;

    for(int i=1; i<(1<<mx); i++){

        vi cur;
        for(int j=0; j<mx; j++)
            if(i&(1<<j))
                cur.pb(j+1);

        bool ok=1;
        for(int j=0; j<cur.size(); j++)
            for(int j1=j+1; j1<cur.size(); j1++)
                if(!binary_search(all(cur),__gcd(cur[j],cur[j1])))
                    ok=0;
        if(ok){
            reverse(all(cur));
            ans.pb(cur);
        }
    }
    sort(all(ans));
    for(int i=0; i<ans.size(); i++)
        reverse(all(ans[i]));
}

void solve(){
    if(!ans.size())
        preprocess();
    ll k;
    cin >> k;

    if(k==0){
        cout << "0\n";
        return;
    }
    k--;
    cout << ans[k].size() << " ";
    for(int x:ans[k])
        cout << x << " ";
    cout << "\n";
}