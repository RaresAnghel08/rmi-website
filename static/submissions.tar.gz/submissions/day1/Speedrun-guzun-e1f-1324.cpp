/**
* user:  guzun-e1f
* fname: Veaceslav
* lname: Guzun
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 07:42:56.170561
*/
#include <bits/stdc++.h>
#include "floppy.h"
using namespace std;

void read_array(int subtask_id, const std::vector<int> &v){
    int n = v.size();
    string bits = "";
    stack<int> s;

    for(int i = 0;i < n; ++i){
        while(!s.empty() && v[s.top()] < v[i]){
            s.pop();
            bits += '0';
        }
        s.push(i);
        bits += '1';
    }
    save_to_floppy(bits);
}

std::vector<int> solve_queries(int subtask_id, int n, const std::string &bits, const std::vector<int> &a, const std::vector<int> &b) {
    stack<int> s;
    vector<vector<int>> jump((int)2e5 + 5, vector<int>(16, 0));

    int j = 0;
    vector<int> l((int)1e5 + 10, 0);
    for(int i = 1;i <= n; ++i){
        while(j < bits.size() && bits[j] == '0'){
            assert(!s.empty());
            s.pop();
            ++j;
        }
        ++j;
        if(s.empty()){
            l[i] = 0;
        }else l[i] = s.top();
        s.push(i);
    }

    for(int i = 1;i <= n; ++i)jump[i][0] = i;

    for(int j = 1;j <= 15; ++j){
        for(int i = 1;i <= n; ++i){
            if(l[jump[i][j - 1]] < l[jump[i + (1 << (j - 1))][j - 1]]){
                jump[i][j] = jump[i][j - 1];
            }else jump[i][j] = jump[i + (1 << (j - 1))][j - 1];
        }
    }
    int q = a.size();
    vector<int> answers;
    for(int i = 0;i < q; ++i){
        int ll = a[i] + 1, r = b[i] + 1;

        int k = floor(log2(r - ll + 1));
        int mx;
        if(l[jump[ll][k]] < l[jump[r - (1 << k) + 1][k]]){
            mx = jump[ll][k];
        }else mx = jump[r - (1 << k) + 1][k];
        answers.push_back(mx - 1);
    }
    return answers;
}

