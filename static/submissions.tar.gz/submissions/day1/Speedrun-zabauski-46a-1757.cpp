/**
* user:  zabauski-46a
* fname: Daniil
* lname: Zabauski
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:24:30.759194
*/
#include<bits/stdc++.h>
using namespace std;


void solve(int n , int m , int k){

    if((n & 1) || (m & 1)){
        cout << "NO\n";
        return;
    }

    int prv = 0;
    vector < vector < int > > answer(n , vector < int > (m));
    int cur = 1;
    bool done = 0;


    int times = min(n / 2, m / 2);


    times--;


    if(k < times){
        cout << "NO\n";
        return;
    }
    int clr = 1;
    for(int i = 0; i < times; ++i){
        for(int fj = i; fj < m - i; ++fj){
            answer[i][fj] = clr;
        }

        for(int fj = i; fj < m - i; ++fj){
            answer[n - 1 - i][fj] = clr;
        }

        for(int fi = i; fi < n - i; ++fi){
            answer[fi][m - 1 - i] = clr;
        }

        for(int fi = i; fi < n - i; ++fi){
            answer[fi][i] = clr;
        }
    }



    if(!done || (n == 1) || (m == 1)){
        cout << "NO\n";
    }else{
        cout << "YES\n";
        for(int i = 0 ; i < n; ++i){
            for(int j = 0;  j < m; ++j){
                cout << answer[i][j] << ' ';
            }
            cout << '\n';
        }
    }
}
int main()
{

    return 0;
}
