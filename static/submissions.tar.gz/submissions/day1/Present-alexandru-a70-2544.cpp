/**
* user:  alexandru-a70
* fname: Andrei
* lname: Alexandru
* task:  Present
* score: 0.0
* date:  2021-12-16 09:42:24.821214
*/
#include <bits/stdc++.h> //Andrei Alexandru a.k.a Sho
#define ll long long int
#define double long double
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define aint(a) (a).begin(), (a).end()
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 998244353
#define PI 3.14159265359
#define INF 1000000005
#define LINF 1000000000000000005ll
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
ll t,k;
set<ll>s;
vector<set<ll>>v;
void add(ll mx){
ll n=v.size();
set<ll>ss;
ss.insert(mx);
v.pb(ss);
for(ll i=0;i<n;i++)
{
ll check=1;
for(auto it : v[i]){
ll x=__gcd(it,mx);
if(v[i].find(x)==v[i].end()){
check=0;
break;
}
}
if(check==1){
set<ll>nw=v[i];
nw.insert(mx);
v.pb(nw);
}
if(v.size()>=1000000){
return;
}
}
}

int32_t main(){
cin>>t;
set<ll>idk;
idk.insert(1);
v.pb(idk);
for(ll i=2;i<=100;i++)
{
add(i);
if(v.size()>=1000000){
break;
}
}
cout<<v[100].size()<<endl;
for(auto it : v[100]){
cout<<it<<' ';
}
while(t--){
ll k;
cin>>k;
if(k==0){
cout<<0<<endl;
}else {
cout<<v[k-1].size()<<' ';
for(auto it : v[k-1]){
cout<<it<<' ';
}
cout<<endl;
}
}
}
