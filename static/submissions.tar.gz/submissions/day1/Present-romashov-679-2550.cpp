/**
* user:  romashov-679
* fname: Fedor
* lname: Romashov
* task:  Present
* score: 29.0
* date:  2021-12-16 09:42:50.524737
*/
#include <bits/stdc++.h>

#define rep(i, n) for(int i = 0; i < (n); ++i)
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()
#define ar array

using namespace std;

typedef long long ll;


using vi = vector<int>;

const int maxN = 38;
const int md = 1e9 + 7;

bool used[maxN];
int cnt[maxN];
int ct[maxN] = {0, 1, 2, 3, 6, 9, 16, 29, 54, 87, 138, 317, 404, 1017, 1566, 1971, 4566, 10041, 13732,
                33713, 39246, 60383, 149342, 315905, 356036, 684169, 1570362, 2259607, 3529378,
                9028225, 26870529, 43662294, 64592447, 158352442, 167784741, 273390760};
int g[maxN][maxN];

int cur = 0;
int need = 0;

void dfs(int last) {
    need--;
    if (need == 0) return;
    for (int nxt = 1; nxt < last; ++nxt) {
        if (used[nxt]) continue;
        used[nxt] = true;
        vector<int> nw = {nxt};
        for (int v = 1; v <= cur; ++v) {
            if (!used[v]) continue;
            int x = g[v][nxt];
            if (used[x]) continue;
            nw.push_back(x);
            used[x] = true;
        }
        dfs(nxt);
        if (need == 0) return;
        for (auto &y : nw) {
            used[y] = false;
        }
    }
}

void precalc() {
    for (int i = 1; i < maxN; ++i) {
        for (int j = 1; j < maxN; ++j) {
            g[i][j] = __gcd(i, j);
        }
    }
}

void solve() {
    cin >> need;
    if (need == 0) {
        cout << "0\n";
        return;
    }
    cur = 1;
    while(ct[cur] < need) {
        need -= ct[cur];
        cur++;
    }
    used[cur] = true;
    dfs(cur);
    vector<int> ans;
    for(int i = 1; i <= cur; ++i) {
        if (used[i]) {
            ans.push_back(i);
            used[i] = false;
        }
    }
    cout << ans.size() << ' ';
    for(auto &x : ans) cout << x << ' ';
    cout << '\n';
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int tests = 1;
    precalc();
    cin >> tests;
    rep(_, tests) {
        solve();
    }
    return 0;
}