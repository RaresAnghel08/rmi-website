/**
* user:  tanay-683
* fname: Alon
* lname: Tanay
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:33:18.346413
*/
#include <bits/stdc++.h>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    while(t--) {
        int n, m, k;
        cin >> n >> m >> k;
        if((n%2) || (m%2) || k * 4 > n * m) {
            cout << "NO\n";
            continue;
        }
        bool flip = false;
        if(n > m) {
            swap(n,m);
            flip = true;
        }
        vector<vector<int>> garden(n,vector<int>(m));
        
        if(n == 2) {
            if(k == n / 2) {
                for(int i = 0; i < m; i += 2) {
                   garden[0][i] = garden[1][i] = garden[0][i+1] = garden[1][i+1] = (i/2 + 1);
                }
            }
        } else if(n == 4) {
            if(m == 4) {
                cout << "1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
                continue;
            }
        }
        if(flip) {
            for(int mi = 0; mi < m; mi ++) {
                for(int ni = 0; ni < n; ni ++) {
                    cout << garden[ni][mi] << " ";
                }
                cout << "\n";
            }
        } else {
            for(int ni = 0; ni < n; ni ++) {
                for(int mi = 0; mi < m; mi ++) {
                    cout << garden[ni][mi] << " ";
                }
                cout << "\n";
            }
        }
    }
    return 0;
}