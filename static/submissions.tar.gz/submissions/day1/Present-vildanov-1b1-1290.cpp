/**
* user:  vildanov-1b1
* fname: Ruslan
* lname: Vildanov
* task:  Present
* score: 29.0
* date:  2021-12-16 07:39:54.885703
*/
#ifdef LOCAL
    //#define _GLIBCXX_DEBUG
#endif // LOCAL
#include <bits/stdc++.h>
using namespace std;

//#define int long long
#define f first
#define s second

vector <int> a;

const int maxa=26;
vector <int> need(maxa+1,0);
vector <int> used(maxa+1,0);

bool good()
{
    for (int i=1; i<=maxa; i++){
        if (used[i])continue;
        if (need[i])return 0;
    }
    return 1;
}
vector <vector <int> > ans;
void gen(int n, int mx)
{
    vector <int> X;
    for (int i:a){
        int x=__gcd(i,n);
        if (!used[x]){
            X.push_back(x);
            mx=max(mx,x);
            need[x]++;
        }
    }
    a.push_back(n);
    used[n]=1;
    while (1){
        if (mx==1)break;
        if (!used[mx] && need[mx])break;
        mx--;
    }
    if (good())ans.push_back(a);
    for (int i=mx; i<n; i++){
        gen(i,mx);
    }
    a.pop_back();
    for (int x:X){
        need[x]--;
    }
    used[n]=0;
    while (!X.empty())X.pop_back();
}

signed main()
{
    for (int i=1; i<=maxa; i++){
        gen(i,1);
        if (ans.size()>=1000000)break;
    }
    //cout << ans.size() << endl;
    int t;
    cin >> t;
    for (int i=0; i<ans.size(); i++){
        reverse(ans[i].begin(),ans[i].end());
    }
    while (t--){
        int k;
        cin >> k;
        if (k==0){
            cout << 0 << endl;
            continue;
        }
        cout << ans[k-1].size() << " ";
        for (int i:ans[k-1])cout << i << " ";
        cout << endl;
    }
}
