/**
* user:  bashev-75b
* fname: Dobrin
* lname: Bashev
* task:  devil
* score: 0.0
* date:  2019-10-10 08:28:09.507617
*/
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int t;
    cin >> t;

    while (t--)
    {
        int k;
        cin >> k;

        string s = "";
        for (int i = 1; i < 10; ++ i)
        {
            int x;
            cin >> x;
            while (x--)
            {
                s += (char)(i + '0');
            }
        }

        string mins = "999999999999", ans = "";
        do
        {
            string ta = "";
            for (int i = 0; i <= s.size() - k; ++ i)
            {
                ta = max(ta, s.substr(i, i + k));
            }

            if (ta < mins)
            {
                mins = ta;
                ans = s;
            }

        }
        while (next_permutation(s.begin(), s.end()));

        // cout << mins << endl;
        cout << ans << endl;
    }



}

