/**
* user:  klishch-92b
* fname: Danil
* lname: Klishch
* task:  devil
* score: 0.0
* date:  2019-10-10 07:33:51.578113
*/
#include <bits/stdc++.h>
using namespace std;

int64_t bestCurrent = 1ll << 62;
int64_t bestAns = -1;

int k;
int ds[10];

void getNumber(int64_t number) {
	string x = to_string(number);
	int64_t ans = -1;
	for (int i = 0; i <= int(x.size()) - k; ++i) {
		ans = max(stol(x.substr(i, k).c_str()), ans);
	}
	if (bestCurrent > ans)
		bestCurrent = ans,
		bestAns = number;
}

int64_t getBest(int64_t curr = 0) {
	bool tried = false;
	for (int i = 0; i <= 4; ++i) {
		if (ds[i] != 0) {
			--ds[i];
			getBest(curr * 10 + i + 1);
			++ds[i];
			tried = true;
		}
	}
	if (!tried)
		getNumber(curr);
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t;
	cin >> t;
	while (t--) {
		cin >> k;
		for (int i = 0; i < 9; ++i)
			cin >> ds[i];
		bestCurrent = 1ll << 62;
		bestAns = -1;
		getBest();
		cout << bestAns << "\n";
	}
	return 0;
}