/**
* user:  vukelic-2d0
* fname: Mateja
* lname: Vukelic
* task:  devil
* score: 0.0
* date:  2019-10-10 08:33:47.781775
*/
#include <bits/stdc++.h>
#define pb push_back
using namespace std;
int t;
int k;
int m;
int dig[15];
vector<int>cif;
void solve(){
    m = 0;
    cif.clear();
    cin >> k;
    for(int i=1; i<10; i++){
        cin >> dig[i];
        m += dig[i];
        for(int j=0; j<dig[i]; j++)cif.pb(i);
    }
    if(k == 2){
        sort(cif.begin(), cif.end());
        if(m == 1)cout << cif[0] << endl;
        else if(m == 2)cout << cif[0] << cif[1] << endl;
        int l = 0;
        int r = m - 2;
        while(r >= l){
            cout << cif[r];
            if(l != r)cout << cif[l];
            r--;
            l++;
        }
        cout << cif[m-1] << endl;
        return;
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin >> t;
    while(t--)solve();
    return 0;
}
