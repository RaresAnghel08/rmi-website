/**
* user:  gavra-4b2
* fname: Bogdan
* lname: Gavra
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:12:21.790199
*/
#include "speedrun.h"

void dfs(int node, int last, int N) {
    for(int i=1;i<=N;i++) if(i!=last and getHint(i) == 1) {
        goTo(i);
        dfs(i, node, N);
        goTo(node);
    }
    goTo(last);
}

void assignHints(int subtask, int N, int A[], int B[]) {
    if(subtask == 1) {
        setHintLen(N);
        for(int i=1;i<N;i++) {
            setHint(A[i], B[i], 1);
            setHint(B[i], A[i], 1);
        }
        return;
    }
}

void speedrun(int subtask, int N, int start) {
    if(subtask == 1) {
        dfs(start, 0, N);
        return;
    }
}