/**
* user:  gospodinov-b8b
* fname: Antani
* lname: Gospodinov
* task:  restore
* score: 0.0
* date:  2019-10-10 10:22:08.279183
*/
#include <bits/stdc++.h>
#define ll long long
#define mp make_pair
#define pb push_back
using namespace std;
const short N = 19;
const short M = 205;

short n, m;
short a[N];
struct constrashort{

    short l, r, k, val;

}c[M];

short want[M];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    cin >> n >> m;
    for(short i = 1; i <= m; i++)
    {
        cin >> c[i].l >> c[i].r >> c[i].k >> c[i].val;
        c[i].l++; c[i].r++;

        if(c[i].val == 1)
            c[i].k = (c[i].r - c[i].l - c[i].k + 2);
    }

    for(int mask = 0; mask < (1 << n); mask++)
    {
        for(short k = 1; k <= m; k++)
            want[k] = c[k].k;

        for(short j = 0; j < n; j++)
        {
            short val = ((mask & (1 << j)) > 0);

            for(short k = 1; k <= m; k++)
                if(c[k].val == val && j + 1 >= c[k].l && j + 1 <= c[k].r)
                    want[k]--;
        }

        bool cool = true;
        for(short k = 1; k <= m; k++)
            if(want[k] > 0)
            {
                cool = false;
                break;
            }

        if(cool)
        {
            for(short j = 0; j < n; j++)
            {
                short val = ((mask & (1 << j)) > 0);
                cout << val << " ";
            }
            cout << endl;
            return 0;
        }
    }


    cout << -1 << endl;
    return 0;

}

/*

4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0

*/
