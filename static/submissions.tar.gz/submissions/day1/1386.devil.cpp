/**
* user:  sanzani-a32
* fname: Filippo
* lname: Sanzani
* task:  devil
* score: 0.0
* date:  2019-10-10 06:32:25.997468
*/
#include <bits/stdc++.h>

using namespace std;

#define int long long

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;

int K, N;
string sol;

bool check(int number, vi cont){
	int mini = min(number/10, number%10);
	int u = accumulate(cont.begin()+mini+1, cont.end(), 0);
	int d = accumulate(cont.begin()+number/10+1, cont.end(), 0);
	if(u > 2 || d > 1)
		return false;

	sol = "";

	int idxA = number/10;
	int idxB = number%10;

	while(idxA > 0 && cont[idxA] == 0) idxA--;
	//decine
	sol = (char)'0'+idxA;
	cont[idxA]--;

	while(idxB > 0 && cont[idxB] == 0) idxB--;
	//unita
	sol += (char)'0'+idxB;
	cont[idxB]--;

	while(idxB > 0){
		while(idxB > 0 && cont[idxB] == 0) idxB--;
		sol += (char)'0'+idxB;
		cont[idxB]--;
	}	

	if(sol.size() == N-1){
		for(int i=1; i<10; i++) if(cont[i] == 1)
			sol += (char)'0'+i;
	}

	assert(sol.size() == N);
	return true;
} 

void solve(){
 	cin >> K;

	vi cont(15, 0);
 	if(K != 2) return;

 	N = 0;
 	for(int i=1; i<10; i++) cin >> cont[i];
	for(auto i : cont) N += i;

	for(int i=10; i<100; i++) if(check(i, cont)){
		cout << sol << "\n";
		return;
	}
}

signed main(){
    cin.tie(0); cin.sync_with_stdio(0);
    int T;
    cin >> T;
    while(T--) solve();
}
