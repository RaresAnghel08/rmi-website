/**
* user:  todoran-c08
* fname: Alexandru Raul
* lname: Todoran
* task:  restore
* score: 0.0
* date:  2019-10-10 06:54:56.636827
*/
#include <bits/stdc++.h>

using namespace std;

const int N_MAX = 5002;
const int M_MAX = 10002;

int n, m;

int l[M_MAX], r[M_MAX], k[M_MAX];
bool val[M_MAX];

int cnt0[M_MAX];

int x[N_MAX];

priority_queue <pair <int, int> > pq;

bool a[N_MAX];

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        cin >> l[i] >> r[i] >> k[i] >> val[i];
        l[i]++;
        r[i]++;
        if(val[i] == 0)
            for(int i = 1; i <= n; i++)
                x[i]++;
        else
            for(int i = 1; i <= n; i++)
                x[i]--;
    }
    for(int i = 1; i <= n; i++)
        pq.push(make_pair(x[i], i));
    memset(a, 1, sizeof(a));
    while(!pq.empty())
    {
        pair <int, int> t = pq.top();
        pq.pop();
        a[t.second] = 0;
        bool ok = true;
        for(int i = 1; i <= m; i++)
            if(l[i] <= t.second && t.second <= r[i] && val[i] == 1)
            {
                cnt0[i]++;
                if(cnt0[i] >= k[i])
                {
                    ok = false;
                    break;
                }
            }
        if(ok == false)
        {
            a[t.second] = 1;
            break;
        }
        for(int i = 1; i <= m; i++)
            if(l[i] <= t.second && t.second <= r[i] && val[i] == 0)
                cnt0[i]++;
    }
    for(int i = 1; i <= m; i++)
        if(val[i] == 0 && cnt0[i] < k[i])
        {
            cout << "-1\n";
            return 0;
        }
    for(int i = 1; i <= n; i++)
        cout << a[i] << " ";
    cout << "\n";
    return 0;
}
