/**
* user:  linhart-f5e
* fname: Yoav
* lname: Linhart
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:39:37.728791
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <queue>

#define upmin(a, b) if(a > b) a = b
#define upmax(a, b) if(a < b) a = b
#define pr(x) cout << x << endl
#define spr(x) cout << x << " "
#define wpr(x) cout << #x << ": " << x << endl
#define wprv(x) cout << #x << ": " << endl; for(auto it : x) cout << it << " "; cout << endl;
#define wprvv(x) cout << #x << ": " << endl; for(auto it : x) { for(auto it2 : it) cout << it2 << " "; cout << endl;}
#define rep(i, s, e) for(ll i = s; i < e; i++)
#define repr(i, s, e) for(ll i = e - (ll)1; i >= s; i--)


using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vvvll = vector<vvll>;
using pll = pair<ll, ll>;
using vpll = vector<pll>;
using vvpll = vector<vpll>;
using vb = vector<bool>;
using vi = vector<int>;


void no()
{
	pr("NO");
}


void yes(vvll& mat) {
	pr("YES");
	rep(i, 0, mat.size()) {
		rep(j, 0, mat[i].size()) {
			cout << mat[i][j] << " ";
		}
		cout << endl;
	}
}

void solve_small(ll n, ll m, ll k) {
}

/*

n is the smaller one

*/
vvll solve_axis(ll n, ll m, ll k) {
	vvll mat;
	if (n % 2 == 1 || m % 2 == 1) return mat;
	if (n == 2) {
		if (m % 2 == 1) return mat;
		if (m / 2 != k) return mat;
		mat.resize(n, vll(m));
		ll col = 1;
		for (ll j = 0; j < m; j += 2) {
			mat[0][j] = mat[0][j + 1] = col;
			col++;
		}
		for (ll j = 0; j < m; j += 2) {
			mat[1][j] = mat[1][j + 1] = mat[0][j];
			col++;
		}

	}
	return mat;
}

void solve_44(ll k)
{
	vvll mat;
	if (k == 4) {
		mat = { {1, 1, 2, 2}, {1, 1, 2, 2}, {3, 3, 4, 4}, {3, 3, 4, 4} };
	}
	/*
	if (k == 1) {
		mat.resize(4, vll(4));
		rep(i, 0, 4) {
			rep(j, 0, 4) {
				mat[i][j] = 1;
			}
		}
	}
	*/
	if (k == 2) {
		mat = { {1, 1, 1, 1}, {1, 2, 2, 1}, {1, 2, 2, 1}, {1, 1, 1, 1} };
	}
	if (mat.size() == 0) return no();
	yes(mat);
}
void solve()
{
	ll n, m, k;
	cin >> n >> m >> k;
	if (n == 4 && m == 4) {
		solve_44(k);
		return;
	}
	vvll mat = solve_axis(n, m, k);
	if (mat.size() > 0) {
		return yes(mat);
	}

	mat = solve_axis(m, n, k);

	if (mat.size() > 0) {
		vvll mat2(n, vll(m));
		rep(i, 0, n) {
			rep(j, 0, m) {
				mat2[i][j] = mat[j][i];
			}
		}
		return yes(mat2);
	}

	return no();
	// now n is the smaller one
	
}


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	ll test;
	cin >> test;
	while (test--) {
		solve();
	}
}


/*


10
1 1 1
2 2 0
2 2 2
2 2 1
2 4 1
4 2 1
2 4 2
4 2 2

*/