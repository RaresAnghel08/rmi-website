/**
* user:  daminov-9d1
* fname: Kamil
* lname: Daminov
* task:  Present
* score: 29.0
* date:  2021-12-16 09:36:56.381633
*/
#include <bits/stdc++.h>
using namespace std;
const int maxn = 26;

vector<bitset<maxn>> B;

void solve() {
    int k; cin >> k;

    cout << B[k].count() << " ";
    for (int i = 1; i < maxn; i++) {
        if (B[k][i]) {
            cout << i << " ";
        }
    }
    cout << "\n";
}

signed main() {
    int t = 0; cin >> t;

    B.emplace_back();
    for (int i = 1; i < maxn; i++){
        int sz = (int)B.size();
        for (int I = 0; I < sz; I++){
            auto j = B[I];
            bool f = true;
            for (int k = 1; k < i && f; k++){
                if (j[k]){
                    if (!j[__gcd(i, k)]) {
                        f = false;
                    }
                }
            }

            if (f) {
                B.emplace_back(j);
                B.back()[i] = true;
            }
        }
    }

//    cout << B.size();
    while (t--) {
        solve();
    }
}