/**
* user:  negoescu-c8b
* fname: Divia Petra
* lname: Negoescu
* task:  Present
* score: 8.0
* date:  2021-12-16 11:35:16.664002
*/
#include <iostream>
using namespace std;
//ifstream cin("a.in");
//ofstream cout("a.out");
int g[10],aux[10],t,i,k,n;
int gcd(int a,int b){
    while(b){
        int r=a%b;
        a=b;
        b=r;
    }
    return a;
}
int main(){
    cin>>t;
    for(;t--;){
        cin>>n;
        if(n==0)cout<<"0\n";
        else{
            g[9]=0;
            int cnt=0;
            while(g[9]==0){
                int k=0;
                int i=0;
                for(i=0;i<=8;i++)
                    if(g[i]==1)g[i]=0;
                    else break;
                g[i]=1;
                if(i==9)break;

                for(int x=0;x<=8;x++){
                    if(g[x]==1){
                        aux[++k]=x+1;

                    }
                }
                int ok=1;
                for(int i=1;i<=k;i++){
                    for(int j=i+1;j<=k;j++){
                        int gc=gcd(aux[i],aux[j]);
                        int este=0;
                        for(int x=1;x<=k;x++){
                            if(aux[x]==gc){
                                este=1; break;
                            }
                        }
                        if(este==0){
                            ok=0; break;
                        }
                    }
                    if(ok==0)break;
                }
                if(ok){
                    cnt++;
                    if(cnt==n){
                        cout<<k<<" ";
                        for(int i=1;i<=k;i++)
                            cout<<aux[i]<<" ";
                        cout<<"\n";
                    }
                }

            }


        }
    }
    return 0;
}
