/**
* user:  greaca-04d
* fname: Albert Antoniu
* lname: Greaca
* task:  Gardening
* score: 5.0
* date:  2021-12-16 07:23:48.309163
*/
#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    int t,n,m,k,i1;
    scanf("%d",&t);
    for(i1=1;i1<=t;i1++){
        scanf("%d%d%d",&n,&m,&k);
        if (n==2 && m==2 && k==1){
            printf("YES\n1 1\n1 1\n");
            continue;
        }
        if (n==2 && m==4 && k==2){
            printf("YES\n1 1 2 2\n1 1 2 2\n");
            continue;
        }
        if (n==4 && m==2 && k==2){
            printf("YES\n1 1\n1 1\n2 2\n2 2\n");
            continue;
        }
        if (n==4 && m==4 && k==2){
            printf("YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n");
            continue;
        }
        if (n==4 && m==4 && k==4){
            printf("YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n");
            continue;
        }
        printf("NO\n");
    }
return 0;
}
