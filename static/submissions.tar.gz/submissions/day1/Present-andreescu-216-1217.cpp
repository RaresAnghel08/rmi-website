/**
* user:  andreescu-216
* fname: Mihnea
* lname: Andreescu
* task:  Present
* score: 29.0
* date:  2021-12-16 07:22:40.796862
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

bool found;
int k;

const int N = 100 + 7;
int g[N][N];



void bkt(int cure, vector<bool> vis, vector<int> cur) {
  if (found) {
    return;
  }
  k--;
  if (k == 0) {
    found = 1;
    sort(cur.begin(), cur.end());
    cout << (int) cur.size() << " ";
    for (auto &x : cur) {
      cout << x << " ";
    }
    cout << "\n";
    return;
  }
  for (int i = 1; i <= cure; i++) {
    if (vis[i]) {
      continue;
    }
    vector<bool> nwvis = vis;
    vector<int> nwcur = cur;

    nwvis[i] = 1;
    nwcur.push_back(i);

    int pz = (int) nwcur.size() - 1;
    for (int j = pz; j < (int) nwcur.size(); j++) {
      for (int k = 0; k < j; k++) {
        int gcd = g[nwcur[k]][nwcur[j]];
        if (!nwvis[gcd]) {
          nwvis[gcd] = 1;
          nwcur.push_back(gcd);
        }
      }
    }
    bkt(i - 1, nwvis, nwcur);
  }
}

void fndkth(int kk) {
  found = 0;
  k = kk;

  if (k == 0) {
    cout << "0\n";
    return;
  }

  for (int mx = 1; mx < N && !found; mx++) {
    vector<bool> vis(mx + 1, 0);
    vis[mx] = 1;
    bkt(mx, vis, {mx});
  }

  assert(found);
}

signed main() {
  ios::sync_with_stdio(0); cin.tie(0);

 // freopen ("input", "r", stdin);


  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      g[i][j] = __gcd(i, j);
    }
  }


  int t;
  cin >> t;
  while (t--) {
    int k;
    cin >> k;
    fndkth(k);
  }
  return 0;
}
