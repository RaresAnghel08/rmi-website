/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 10:18:30.630711
*/
#include "speedrun.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef vector<vb> vvb;

inline int Log(int n) {
    return 32 - __builtin_clz(n);
}

inline vb Convert(int n, int block) {
    vb ans(block + 1);
    for (int i = 0; i < block; i++) {
        if ((n >> i) & 1) {
            ans[block - i] = true;
        }
    }
    return ans;
}

void assignHints(int subtask, int n, int A[], int B[]) {
    int sz = 2 * (Log(n + 1));
    int block = sz / 2;
    setHintLen(sz);
    vvi tree(n + 1);
    for (int i = 1; i < n; i++) {
        tree[A[i]].push_back(B[i]);
        tree[B[i]].push_back(A[i]);
    }
    int up = 0, last = 0;
    stack<int> stk;
    stk.push(1);
    vi parent(n + 1);
    vb visited(n + 1);
    while (!stk.empty()) {
        int node = stk.top();
        if (!visited[node]) {
            last = node, up = 0;
            vb par = Convert(parent[node], block);
            for (int i = 1; i <= block; i++) if (par[i]) setHint(node, i, par[i]);
        }
        if (tree[node].empty()) {
            stk.pop();
            up++;
            continue;
        }
        visited[node] = true;
        int neighbor = tree[node].back();
        tree[node].pop_back();
        if (neighbor == parent[node]) continue;
        vb next = Convert(neighbor, block);
        for (int i = block + 1; i <= 2 * block; i++) {
            if (next[i - block]) setHint(last, i, next[i - block]);
        }
        stk.push(neighbor);
        parent[neighbor] = node;
    }
}

void speedrun(int subtask, int n, int start) {
    int node = start;
    int block = getLength() / 2;
    while (node != 1) {
        int parent = 0;
        for (int i = 1; i <= block; i++) {
            parent <<= 1;
            parent += getHint(i);
        }
        goTo(parent);
        node = parent;
    }
    for (int i = 0; i < n - 1; i++) {
        int next = 0;
        for (int j = block + 1; j <= 2 * block; j++) {
            next <<= 1;
            next += getHint(j);
        }
        while (!goTo(next)) {
            int parent = 0;
            for (int j = 1; j <= block; j++) {
                parent <<= 1;
                parent += getHint(j);
            }
            goTo(parent);
        }
        goTo(next);
    }
}
//5
//1 2
//2 3
//3 4
//3 5
//1

//6
//5 1
//5 2
//5 3
//5 4
//5 6
//5

//6
//2 3
//3 1
//1 4
//4 5
//5 6
//1