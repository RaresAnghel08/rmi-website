/**
* user:  ilie-942
* fname: Luca Mihai
* lname: Ilie
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 07:32:38.764493
*/
#include <iostream>
//#include "speedrun.h"

using namespace std;

int viz[1001];

void assignHints( int subtask, int n, int a[], int b[] ) {
    int i;

    setHintLen( n );
    for ( i = 0; i < n - 1; i++ )
        setHint( a[i], b[i], 1 );
}

void dfs( int crt ) {
    viz[crt] = 1;

    for ( i = 1; i <= n; i++ ) {
        if ( getHint( i ) && !viz[i] ) {
            goTo( i );
            dfs( i );
        }
    }
}

void speedrun ( int subtask, int n, int start ) {
    dfs( start );
}

/*int main() {
    cout << "Hello world!" << endl;
    return 0;
}*/
