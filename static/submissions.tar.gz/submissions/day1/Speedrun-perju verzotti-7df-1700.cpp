/**
* user:  perju verzotti-7df
* fname: Luca
* lname: Perju Verzotti
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 08:20:22.959725
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
/*static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;

void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}*/

vector<int>v[1003];
int t[1003],nxt[1003];
void dfsinit (int pz, int vlc)
{
    int cnt=0;
    for(int i=0;i<v[pz].size();++i)
    {
        if(v[pz][i]==t[pz])
            continue;
        ++cnt;
        t[v[pz][i]]=pz;
        dfsinit(v[pz][i],vlc);
        vlc=v[pz][i];
    }
    nxt[pz]=vlc;
}
void assignHints(int subtask, int N, int A[], int B[])
{
    int n,i,j;
    for(i=1;i<N;++i)
    {
        v[A[i]].push_back(B[i]);
        v[B[i]].push_back(A[i]);
    }
    t[1]=0;
    dfsinit(1,0);
    setHintLen(20);
    for(i=1;i<=N;++i)
    {
        for(j=0;j<=9;++j)
        {
            if((1<<j)&(t[i]))
                setHint(i,j+1,true);
            else
                setHint(i,j+1,false);
        }
        for(j=0;j<=9;++j)
        {
            if((1<<j)&(nxt[i]))
                setHint(i,j+11,true);
            else
                setHint(i,j+11,false);
        }
    }
}
int gett()
{
    int rz=0;
    for(int j=0;j<=9;++j)
    {
        if(getHint(j+1))
            rz=(rz|(1<<j));
    }
    return rz;
}
int getnxt ()
{
    int rz=0;
    for(int j=0;j<=9;++j)
    {
        if(getHint(j+11))
            rz=(rz|(1<<j));
    }
    return rz;
}
int st[1003];
int nrelem=0;
void speedrun(int subtask, int N, int start)
{
    int pz=start,tc,nxtc;
    while(tc=gett())
    {
        assert(goTo(tc));
        pz=tc;
    }
    st[++nrelem]=pz;
    while(nxtc=getnxt())
    {
        while(!goTo(nxtc))
        {
            goTo(st[--nrelem]);
            pz=st[nrelem];
        }
        pz=nxtc;
        st[++nrelem]=pz;
    }
}

/*
int main() {
    int N,i;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(1, N, a, b);
    for(i=1;i<=N;++i)
    {
        cout<<i<<' '<<t[i]<<' '<<nxt[i]<<'\n';
    }

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(1, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;
    return 0;
}
*/
