/**
* user:  bem-c1d
* fname: Andrei
* lname: Bem
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:08:03.760446
*/
#include <bits/stdc++.h>

using namespace std;
vector<int>v[200003];
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n, m, k;
        cin>>n>>m>>k;
        int cnt=1;
        bool exista=false;
        for(int i=0; i<n/2; i++)
        {
            for(int j=0; j<m/2; j++)
            {
                v[2*i].push_back(cnt);
                v[2*i+1].push_back(cnt);
                v[2*i].push_back(cnt);
                v[2*i+1].push_back(cnt);
                if(cnt<k)
                {
                    cnt++;
                }
                else{
                    exista=true;
                }
            }
        }
        if(m%2==1 && n%2==1){
            for(int i=0;i<m-1;i++){
                v[n-1].push_back(v[n-2][i]);
            }
            for(int i=0;i<n;i++){
                v[i].push_back(v[i].back());
            }
        }
        else if(n%2==1){
            for(int i=0;i<m;i++){
                v[n-1].push_back(v[n-2][i]);
            }
        }
        else if(m%2==1){
            for(int i=0;i<n;i++){
                v[i].push_back(v[i].back());
            }
        }
        if(exista==false){
            cout<<"NO\n";
            continue;
        }
        cout<<"YES\n";
        for(int i=0;i<n;i++){
                for(int j=0;j<m;j++){
                    cout<<v[i][j]<<" ";
                }
                cout<<"\n";
                v[i].clear();
        }
    }
    return 0;
}
