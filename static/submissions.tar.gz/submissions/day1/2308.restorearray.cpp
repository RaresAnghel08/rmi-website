/**
* user:  udristoiu-a44
* fname: Alexandra Maria
* lname: Udriștoiu
* task:  restore
* score: 7.0
* date:  2019-10-10 08:58:35.168441
*/
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int n, m, i, j, ii, x, jj;
int sol[5005], sum[5005], ok[5005];
struct str{
    int p, u, k, t;
};
str w[10005];
vector<short> v[5005];
//ifstream cin("date.in");
//ofstream cout("date.out");
int cmp(str a, str b){
    return a.u < b.u;
}
int main(){
    cin>> n >> m;
    for(i = 1; i <= m; i++){
        cin>> w[i].p >> w[i].u >> w[i].k >> w[i].t;
        w[i].p++;
        w[i].u++;
        w[i].k = w[i].u - w[i].p + 1 - w[i].k + 1;
        if(w[i].t == 0){
            w[i].k--;
        }
    }
    sort(w + 1, w + m + 1, cmp);
    for(ii = 1; ii <= m; ii++){
        if(w[ii].t == 0){
            for(i = w[ii].p; i <= w[ii].u; i++){
                v[i].push_back(ii);
            }
            if(w[ii].k == 0){
                for(i = w[ii].p; i <= w[ii].u; i++){
                    ok[i] = 1;
                }
            }
        }
    }
    for(ii = 1; ii <= m; ii++){
        if(w[ii].t == 0){
           continue;
        }
        w[ii].k -= sum[ w[ii].u ] - sum[ w[ii].p - 1];
        for(i = w[ii].u; i >= w[ii].p; i--){
            if(w[ii].k <= 0){
                break;
            }
            if(ok[i] == 0){
                sol[i] = 1;
                w[ii].k--;
                for(j = i; j <= n; j++){
                    sum[j]++;
                }
                for(j = 0; j < v[i].size(); j++){
                    x = v[i][j];
                    if(sum[ w[x].u ] - sum[ w[x].p - 1] == w[x].k){
                        for(jj = w[x].p; jj <= w[x].u; jj++){
                            ok[jj] = 1;
                        }
                    }
                }
            }
        }
        if(w[ii].k > 0){
            cout<< -1;
            return 0;
        }
    }
    for(i = 1; i <= n; i++){
        cout<< sol[i] <<" ";
    }
    return 0;
}
