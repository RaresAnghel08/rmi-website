/**
* user:  ardelean-f07
* fname: Alexandru Petru
* lname: Ardelean
* task:  Gardening
* score: 21.0
* date:  2021-12-16 10:54:52.254150
*/
#include <bits/stdc++.h>

using namespace std;

const int N = 2e5 + 7;

vector < int > ans[N];

vector < int > aux[N];

int d;

bool solve(int n, int m, int k) {
//    if (1LL * n * m > 2e5 || (n & 1) || (m & 1) || 1LL * n * m < 4 * k || max(n, m) > 2 * k || (min(n, m) >= 6 && k == max(n, m) - min(n, m) / 2 + 1) || k == n * m / 4 - 1 || (min(n, m) == 2 && k != max(n, m) / 2))
//        return cout << 0 / 0, 0;
    if (1LL * n * m > 2e5 || (n & 1) || (m & 1) || 1LL * n * m < 4 * k || max(n, m) > 2 * k || k == n * m / 4 - 1 || (min(n, m) == 2 && k != max(n, m) / 2) || (n == 6 && m == 6 && k == 4))
        return 0;
    if (n == 2) {
        if (k != m / 2)
            return 0;
        for (int i = 1; i < m; i += 2)
            ans[d + 1][d + i] = ans[d + 2][d + i] = ans[d + 1][d + i + 1] = ans[d + 2][d + i + 1] = i / 2 + 1;
        return 1;
    }
    if (n == 4) {
        int t = 2 * (m - k);
        ans[d + 2][d + 1] = ans[d + 3][d + 1] = ans[d + 2][d + t] = ans[d + 3][d + t] = 1;
        for (int i = 1; i <= t; ++i)
            ans[d + 1][d + i] = ans[d + 4][d + i] = 1;
        for (int i = 2; i < t; i += 2)
            ans[d + 2][d + i] = ans[d + 3][d + i] = ans[d + 2][d + i + 1] = ans[d + 3][d + i + 1] = i / 2 + 1;
        for (int i = t + 1; i < m; i += 2) {
            ans[d + 1][d + i] = ans[d + 2][d + i] = ans[d + 1][d + i + 1] = ans[d + 2][d + i + 1] = k - i + t + 1;
            ans[d + 3][d + i] = ans[d + 4][d + i] = ans[d + 3][d + i + 1] = ans[d + 4][d + i + 1] = k - i + t;
        }
        return 1;
    }
    if (k >= m) {
        bool ok = solve(n - 2, m, k - m / 2);
        if (ok) {
            for (int i = k; i > k - m / 2; --i)
                ans[d + n - 1][d + (k - i) * 2 + 1] = ans[d + n - 1][d + (k - i) * 2 + 2] = ans[d + n][d + (k - i) * 2 + 1] = ans[d + n][d + (k - i) * 2 + 2] = i;
            return ok;
        }
    }
    if (k >= n / 2 + max(m - 2, n) / 2) {
        bool ok = solve(n, m - 2, k - n / 2);
        if (ok) {
            for (int i = k; i > k - n / 2; --i)
                ans[d + (k - i) * 2 + 1][d + m - 1] = ans[d + (k - i) * 2 + 2][d + m - 1] = ans[d + (k - i) * 2 + 1][d + m] = ans[d + (k - i) * 2 + 2][d + m] = i;
            return ok;
        }
    }
    d++;
    bool ok = solve(n - 2, m - 2, k - 1);
    --d;
    if (!ok)
        return ok;
    for (int i = 2; i < n; ++i)
        ans[d + i][d + 1] = ans[d + i][d + m] = k;
    for (int i = 1; i <= m; ++i)
        ans[d + 1][d + i] = ans[d + n][d + i] = k;
    return ok;
}

int main()
{
    ios_base::sync_with_stdio(NULL);
    cin.tie(0);
    cout.tie(0);
    int t, n, m, k;
    cin >> t;
    while (t--) {
        cin >> n >> m >> k;
//        if (1LL * n * m > 2e5 || (n & 1) || (m & 1) || 1LL * n * m < 4 * k || max(n, m) > 2 * k || (min(n, m) >= 6 && k == max(n, m) - min(n, m) / 2 + 1) || k == n * m / 4 - 1 || (min(n, m) == 2 && k != max(n, m) / 2)) {
//            cout << "NO\n";
//            continue;
//        }
        if (1LL * n * m > 2e5 || (n & 1) || (m & 1) || 1LL * n * m < 4 * k || max(n, m) > 2 * k || k == n * m / 4 - 1 || (min(n, m) == 2 && k != max(n, m) / 2) || (n == 6 && m == 6 && k == 4)) {
            cout << "NO\n";
            continue;
        }
        if (n > m) {
            for (int i = 1; i <= m; ++i)
                ans[i].resize(n + 1);
            bool ok = solve(m, n, k);
            if (!ok)
                cout << "NO\n";
            for (int i = 1; i <= m; ++i)
                aux[i] = ans[i];
            for (int i = 1; i <= n; ++i)
                ans[i].resize(m + 1);
            for (int i = 1; i <= n; ++i)
                for (int j = 1; j <= m; ++j)
                    ans[i][j] = aux[j][i];
            cout << "YES\n";
            for (int i = 1; i <= n; ++i)
                for (int j = 1; j <= m; ++j)
                    cout << ans[i][j] << " \n"[j == m];
            continue;
        }
        for (int i = 1; i <= n; ++i)
            ans[i].resize(m + 1);
        bool ok = solve(n, m, k);
        if (!ok)
            cout << "NO\n";
        cout << "YES\n";
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= m; ++j)
                cout << ans[i][j] << " \n"[j == m];
    }
    return 0;
}

