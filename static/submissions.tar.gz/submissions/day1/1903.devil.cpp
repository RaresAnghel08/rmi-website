/**
* user:  dobleaga-573
* fname: Alexandru
* lname: Dobleaga
* task:  devil
* score: 14.0
* date:  2019-10-10 08:06:19.482873
*/
#include <iostream>

using namespace std;

const int NMAX = 1e6 + 4;

int t, k;

int nrap[12];

int n;

int sol[NMAX];

void read()
{
    cin >> k;

    n = 0;

    for (int i=1; i<=9; ++i)
    {
        cin >> nrap[i];
        n += nrap[i];
    }
}

int reducM (int val)
{
    while (nrap[val] == 0 && val > 0) val--;
    return val;
}

int reducm (int val)
{
    while (nrap[val] == 0 && val < 10) val++;
    return val;
}

bool subtask3()
{
    for (int i=3; i<=9; ++i)
        if (nrap[i] > 0) return false;

    return true;
}

void do_testcase()
{
    read();

    if (k == 2)
    {
        int Max=9;
        int Min=1;

        for (int i=n; i>=1; --i)
        {
            if (i % 2 == n % 2)
            {
                Max = reducM(Max);
                sol[i] = Max;
                nrap[Max]--;
            }
            else
            {
                Min = reducm(Min);
                sol[i] = Min;
                nrap[Min]--;
            }
        }

        for (int i=1; i<=n; ++i)
            cout << sol[i];
    }
    else if (subtask3())
    {
        if (nrap[2] < k)
        {
            for (int i=1; i<=nrap[1]; ++i)
                cout << 1;
            for (int i=1; i<=nrap[2]; ++i)
                cout << 2;
        }
        else if (nrap[2] == k)
        {
            cout << 2;

            for (int i=1; i<=nrap[1]; ++i)
                cout << 1;
            for (int i=1; i<k; ++i)
                cout << 2;
        }
        else
        {
            for (int i=n; i>=n-k+2; --i)
                sol[i] = 2;
            nrap[2] -= (k-1);

            int imp = nrap[1] / nrap[2];
            int aux = 1;
            for (int i=1; i<=nrap[2]; ++i)
            {
                sol[aux] = 2;
                aux++;

                for (int j=aux; j<=aux+imp-1; ++j)
                    sol[j]=1;

                aux = aux + imp;
            }

            for (int j=aux; j<n-k+2; ++j)
                sol[j]=1;

            for (int i=1; i<=n; ++i)
                cout << sol[i] << " ";
        }
    }

    for (int i=1; i<=n; ++i)
        sol[i] = 0;
    for (int i=1; i<=9; ++i)
        nrap[i] = 0;
}
int main()
{
    cin >> t;

    for (; t; --t)
    {
        do_testcase();
    }
    return 0;
}
