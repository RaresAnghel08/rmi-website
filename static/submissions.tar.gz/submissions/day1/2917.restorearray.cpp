/**
* user:  melnyk-1f2
* fname: Sofiia
* lname: Melnyk
* task:  restore
* score: 13.0
* date:  2019-10-10 10:13:24.163507
*/
#include<bits/stdc++.h>
using namespace std;

#define mp make_pair
#define ff first
#define ss second
#define pb push_back

const int N = 1e6 + 11;

int a[N],b[N],c[N],k0[N],k1[N],pus[N];
int l1[N],r1[N],t1[N],kk[N];

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n,m;
    cin>>n>>m;
    vector<int> num;
    for (int i=1; i<=n; i++)
        a[i]=-1;
    int mm=0;
    for (int i=1; i<=m; i++)
    {
        int l,r,k,t;
        cin>>l>>r>>k>>t;
        l++;
        r++;
        l1[i]=l;
        r1[i]=r;
        t1[i]=t;
        kk[i]=k;
        if (r-l+1==1)
        {
            if (a[l]!=-1&&a[l]!=t) return cout<<-1,0;
            a[l]=t;
        } else
        if (k==r-l+1&&t==0)
        {
            for (int j=l; j<=r; j++)
                if (a[j]==-1||a[j]==0) a[j]=0; else return cout<<-1,0;
        } else
        if (k==1&&t==1)
        {
            for (int j=l; j<=r; j++)
                if (a[j]==-1||a[j]==1) a[j]=1; else return cout<<-1,0;
        } else
        {
            if (t==1) kk[i]=(r-l+1)-k+1;
            num.pb(i);
        }
    }
    while (num.size()>0)
    {
        for (int i=1; i<=n; i++)
        {
            k0[i]=k0[i-1]+(a[i]==0);
            k1[i]=k1[i-1]+(a[i]==1);
            pus[i]=pus[i-1]+(a[i]==-1);
        }
        vector<int> nexnum,ob;
        for (int j=0; j<num.size(); j++)
        {
            int l=l1[num[j]];
            int r=r1[num[j]];
            int k=kk[num[j]];
            int t=t1[num[j]];
            if (t==0&&(k0[r]-k0[l-1])>=k) {} else
            if (t==1&&(k1[r]-k1[l-1])>=k) {} else
            if (t==0&&(k0[r]-k0[l-1]+pus[r]-pus[l-1])<=k) ob.pb(num[j]); else
            if (t==1&&(k1[r]-k1[l-1]+pus[r]-pus[l-1])<=k) ob.pb(num[j]); else nexnum.pb(num[j]);
        }
        for (int j=0; j<ob.size(); j++)
        {
            int l=l1[num[j]];
            int r=r1[num[j]];
            int k=kk[num[j]];
            int t=t1[num[j]];
            for (int j=l; j<=r; j++)
            if (a[j]==-1) {a[j]=t; k--;} else
            if (a[j]==t) k--;
            if (k>0) return cout<<-1,0;
        }
        if (ob.size()==0)
        {
            for (int i=1; i<=n; i++)
            if (a[i]==-1) {a[i]=0; break;}
        }
        num=nexnum;
    }
    for (int i=1; i<=n; i++)
        cout<<max(a[i],0)<<" ";
}
/**
4 4
0 1 2 1
2 2 1 0
0 1 1 0
1 2 1 0
**/
