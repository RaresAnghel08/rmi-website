/**
* user:  ismailov-374
* fname: Ferit
* lname: Ismailov
* task:  restore
* score: 0.0
* date:  2019-10-10 10:23:51.798086
*/
#include<bits/stdc++.h>
#define endl "\n"
using namespace std;
//ifstream fin("in.txt");
const int MAXN=10001;
int n,m,arr[MAXN],seg[MAXN],temp[MAXN];
struct query
{
    int l,r,k,val;
} q[MAXN];
void print()
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
}
bool check()
{
    int i,j;
    for(i=0;i<m;i++)
    {
        int br=0;
        for(j=q[i].l;j<=q[i].r;++j)
        {
            br+=(arr[j]==0);
        }
        if(q[i].val==0)
        {
            if(br<q[i].k)return false;
        }
        if(q[i].val==1)
        {
            if(br>=q[i].k)return false;
        }
    }
    return true;
}
bool l;
void solve1(int pos)
{
    if(l==true)return;
    if(pos>n)
    {
        if(check())
        {
            print();
            l=true;
        }
        return;
    }
    arr[pos]=0;
    solve1(pos+1);
    arr[pos]=1;
    solve1(pos+1);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>m;
    memset(arr,-1,sizeof(arr));
    int i,j;
    for(int i=0; i<m; i++)
    {
        cin>>q[i].l>>q[i].r>>q[i].k>>q[i].val;
        if(q[i].val==1)
        {
            if(q[i].k==1)
            {
                for(j=q[i].l; j<=q[i].r; j++)
                {
                    arr[j]=1;
                }
            }
            else
            {
                for(j=q[i].l;j<=q[i].r;j++)
                {
                    seg[j]=i;
                    temp[j]=1;
                    arr[j]=1;
                }
            }

        }
        else
        {
            if(q[i].k!=1)
            {
                int l=false;
                for(j=q[i].l; j<=q[i].r; ++j)
                {
                    if(arr[j]==-1)
                    {
                        l=true;
                    }
                }
                if(!l)
                {
                    cout<<-1<<"\n";
                    return 0;
                }
            }
            else
            {
                for(j=q[i].l;j<q[i].r;j++)
                {
                    if(seg[j]==seg[j+1])
                    {
                        seg[j+1]=i;
                        temp[j+1]=0;
                        arr[j+1]=0;
                        break;
                    }
                }
            }

        }
    }
    //solve1(0);
   // if(l==false)cout<<-1<<endl;
    //return 0;
    for(i=0; i<n; i++)
    {
        if(arr[i]==-1)arr[i]++;
        cout<<arr[i]<<" ";
    }
    cout<<"\n";
    return 0;
}
