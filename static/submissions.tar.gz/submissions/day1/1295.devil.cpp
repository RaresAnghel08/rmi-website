/**
* user:  petkov-737
* fname: Georgy
* lname: Petkov
* task:  devil
* score: 13.0
* date:  2019-10-10 06:09:53.688956
*/
#include <bits/stdc++.h>

using namespace std;

int t;
void read()
{
	cin >> t;
}

int k, d[10];

long long find_max(string s)
{
	long long ans = -1;

	int sz = s.size();
	for (int i = 0; i < sz - k + 1; i++)
	{
		long long curr = 0; 
		for (int j = i; j < i + k; j++)
			curr = curr * 10 + s[j] - '0';

		ans = max(ans, curr);
	}	

	return ans; 
}

string ans;
long long best;
void brute_force(int dig, int all, string curr)
{
	if (dig == all + 1)
	{
		long long f = find_max(curr);

		if (f < best)
			best = f, ans = curr;

		return ;
	}

	for (int i = 1; i <= 4; i++)
		if (d[i] > 0)
		{
			string nxt = curr;
			nxt.push_back((char)(i + '0'));

			d[i]--;

			brute_force(dig + 1, all, nxt);

			d[i]++;
		}
}

void solve()
{
	while (t--)
	{
		cin >> k;

		for (int i = 1; i <= 9; i++)
			cin >> d[i];

		int sum = 0;
		for (int i = 1; i <= 9; i++)
			sum += d[i];

		if (sum <= 12)
		{
			best = 1000000000000000000;
			ans = "";

			brute_force(1, sum, "");

			cout << ans << endl; 
		}

		else 
			if (k <= 2)
			{

			}
	}
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	read();
	solve();
}
