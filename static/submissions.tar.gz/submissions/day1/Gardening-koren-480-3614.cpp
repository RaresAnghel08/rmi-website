/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:22:33.265375
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> pii;
typedef vector<pii> vii;

set<pair<int, pii>> visited;

vvi Solve(int n, int m, int k) {
    if (visited.count({n, {m, k}})) return {};
    if (n * m / 4 < k || k < 0) {
        visited.insert({n, {m, k}});
        visited.insert({m, {n, k}});
        return {};
    }
    if (n * m / 4 == k) {
        vvi rows(n, vi(m));
        int cnt = 1;
        for (int i = 0; i < n; i += 2) {
            for (int j = 0; j < m; j += 2) {
                rows[i][j] = rows[i][j + 1] = rows[i + 1][j] = rows[i + 1][j + 1] = cnt++;
            }
        }
        return rows;
    }
    if (n == 2 || m == 2) {
        visited.insert({n, {m, k}});
        visited.insert({m, {n, k}});
        return {};
    }
    int squares_row = m / 2;
    int squares_col = n / 2;
    for (int i = 2; i < n; i += 2) {
        vvi r = Solve(i, m, k - squares_row * (n - i));
        if (r.empty()) continue;
        vvi rows(n, vi(m));
        for (int j = 0; j < i; j++) rows[j] = r[j];
        int cnt = k - squares_row * (n - i) + 1;
        for (int l = i; l < n; l += 2) {
            for (int j = 0; j < m; j += 2) {
                rows[l][j] = rows[l][j + 1] = rows[l + 1][j] = rows[l + 1][j + 1] = cnt++;
            }
        }
        return rows;
    }
    for (int i = 2; i < m; i += 2) {
        vvi r = Solve(n, i, k - squares_col * (m - i));
        if (r.empty()) continue;
        int cnt = k - squares_row * (n - i) + 1;
        vvi rows(n, vi(m));
        for (int l = 0; l < n; l += 2) {
            for (int j = 0; j < i; j++) rows[l][j] = r[l][j];
            for (int j = i; j < m; j += 2) {
                rows[l][j] = rows[l][j + 1] = rows[l + 1][j] = rows[l + 1][j + 1] = cnt++;
            }
        }
        return rows;
    }
    vvi r = Solve(n - 2, m - 2, k - 1);
    if (r.empty()) {
        visited.insert({n, {m, k}});
        visited.insert({m, {n, k}});
        return {};
    }
    vvi rows(n, vi(m));
    for (int i = 1; i < n - 1; i++) {
        for (int j = 1; j < m - 1; j++) {
            rows[i][j] = r[i - 1][j - 1];
        }
    }
    for (int i = 0; i < n; i++) rows[i][0] = rows[i][m - 1] = k;
    for (int i = 0; i < m; i++) rows[0][i] = rows[n - 1][i] = k;
    return rows;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) {
        int n, m, k;
        cin >> n >> m >> k;
        if (n & 1 || m & 1) {
            cout << "NO\n";
            continue;
        }
        vvi rows = Solve(n, m, k);
        if (rows.empty()) cout << "NO\n";
        else {
            cout << "YES\n";
            for (vi &row : rows) {
                for (int x : row) cout << x << ' ';
                cout << '\n';
            }
        }
    }
}
