/**
* user:  penchev-2b7
* fname: Jasen
* lname: Penchev
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:01:51.598105
*/
#include <iostream>
#include <cstring>
#define endl '\n'
using namespace std;

const int MOD = 1000000007;

int dp[16][32];

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n, q;
    cin >> n >> q;

    string x;
    cin >> x;

    unsigned long long ans = 0;
    for (int p = 1; p <= n; ++ p)
    {
        memset(dp, 0, sizeof(dp));

        for (int i = 0; i < x[p - 1] - '0'; ++ i)
            dp[i][p] = 1;

        for (int k = p + 1; k <= n; ++ k)
        {
            for (int i = 0; i <= 9; ++ i)
            {
                for (int j = 0; j <= 9; ++ j)
                {
                    if (j == 1 and i == 3) continue;
                    dp[i][k] += dp[j][k - 1];
                }
            }
        }

        for (int i = 0; i <= 9; ++ i)
            ans += dp[i][n];
        ans %= MOD;
    }

    int k = x.find("13");
    if (!(0 <= k and k < x.size())) ans++;

    cout << ans << endl;

    return 0;
}
