/**
* user:  baliukonis-9a4
* fname: Tsimafei
* lname: Baliukonis
* task:  Present
* score: 8.0
* date:  2021-12-16 10:08:34.373613
*/
#include<bits/stdc++.h>

#define ll long long
#define f first
#define s second
#define pb push_back

using namespace std;

const ll max_n = 100000;

ll gcd[32][32];
bool bad[200000000];
int32_t main() {
cin.tie(0);
cout.tie(0);
ios_base::sync_with_stdio(0);
#ifdef LOCAL
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif // LOCAL

vector<ll> a;

ll k = -1, ma_mask;
for(int j = 0; j < 32; j++)
for(int q = 0;q < 32; q++) {
 gcd[j][q] = __gcd(j + 1, q + 1) - 1;
}


for(int e = 1; e <= 32; e++) {

}

for(int mask = 0; k < max_n; mask++) {

       vector<ll> v;
       ll e = 0;
   for(int i = 0; i < 32; i++) {
         if((mask >> i) & 1) v.pb(i);
         e += (((mask >> i) & 1) << i);
         if(bad[e]) {e = -1; break;}
   }
   if(e == -1) continue;
   bool f = 1;
   ll mask2 = mask;
   for(int j = 0; j < v.size() && f; j++)
   for(int q = j + 1; q < v.size(); q++) {
       if(!((mask >> gcd[v[j]][v[q]]) & 1)) {
            f = 0; break;
       }
   }
   k += f;
   if(f) a.pb({mask});
   bad[mask] = (f ^ 1);
   ma_mask = mask;
}

ll q;
cin >> q;
while(q--) {
    ll x;
    cin >> x;
    ll kol = 0;
    for(int j = 0; j < 32; j++) {
        if((a[x] >> j) & 1) kol++;
    }
    cout << kol << ' ';
    for(int j = 0; j < 32; j++) {
        if((a[x] >> j) & 1) cout << j + 1 << ' ';
    }
    cout << '\n';
}


}
