/**
* user:  trisca-vicol-58e
* fname: Cezar
* lname: Trișcă-Vicol
* task:  restore
* score: 0.0
* date:  2019-10-10 09:36:42.677930
*/
#include <bits/stdc++.h>

using namespace std;

int n,m,S[5010],uan[5010],fixx[5010],zer[5010],aib[5010],val[5010],l[10010],r[10010],k[10010],value[10010];
vector<int> v[5010];
priority_queue<pair<int,int> > q;

void upd(int poz){
    for(;poz<=n;poz+=poz&-poz)
        aib[poz]++;
    return ;
}

int get(int poz){
    int ret=0;
    for(;poz;poz-=poz&-poz)
        ret+=aib[poz];
    return ret;
}

bool check(){
    for(int i=1;i<=m;i++)
        if(value[i]){
            if(get(r[i])-get(l[i]-1)<=(r[i]-(l[i]-1))-k[i])
                return 0;
        }else{
            if(get(r[i])-get(l[i]-1)> (r[i]-(l[i]-1))-k[i])
                return 0;
        }
    return 1;
}

bool check(int i){
        if(value[i]){
            if(get(r[i])-get(l[i]-1)<=(r[i]-(l[i]-1))-k[i])
                return 0;
        }else{
            if(get(r[i])-get(l[i]-1)> (r[i]-(l[i]-1))-k[i])
                return 0;
        }
    return 1;
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
        cin>>l[i]>>r[i]>>k[i]>>value[i],l[i]++,r[i]++;
    if(n<=18){
        for(int mask=0;mask<(1<<n);mask++){
            for(int i=1;i<=n;i++)
                val[i]=((mask&(1<<(i-1)))>=1);
                if(val[i])upd(i);
//            for(int i=1;i<=n;i++)cout<<val[i]<<' ';cout<<'\n';
            if(check()){
                for(int i=1;i<=n;i++)
                    cout<<val[i]<<' ';
                cout<<'\n';
                return 0;
            }
        }
        cout<<-1;
        return 0;
    }
    for(int i=1;i<=m;i++){
        if(k[i]==1)
            if(value[i]==1)
                uan[l[i]]++,uan[r[i]+1]--;
        if(k[i]==r[i]-(l[i]-1))
            if(value[i]==0)
                zer[l[i]]++,zer[r[i]+1]--;
        if(k[i]==1)
            if(value[i]==0)
                v[l[i]].push_back(i);
        if(k[i]==r[i]-(l[i]-1))
            if(value[i]==1)
                v[l[i]].push_back(i);
    }
    int uann=0,zerr=0;

    for(int i=1;i<=n;i++){
        uann+=uan[i];
        zerr+=zer[i];
        if(uann&&zerr){
            cout<<-1;
            return 0;
        }
        val[i]=0;
        if(uann)fixx[i]=1,val[i]=1,upd(i);
        if(zerr)fixx[i]=1,val[i]=0;
    }
    if(check()){
        for(int i=1;i<=n;i++)
            cout<<val[i]<<' ';
    }else{
//        for(int i=1;i<=n;i++){
//                cout<<fixx[i]<<' ';
//            cout<<i<<": ";
//            for(auto it:v[i])
//                cout<<it<<' ';
//            cout<<'\n';
//        }
        for(int i=1;i<=n;i++){
            for(auto it:v[i])
                if(!check(it))
                    q.push({-r[it],it});
            if(fixx[i])continue;
            while(q.size())
                if(check(q.top().second))
                    q.pop();
                else
                    break;
            if(q.size()){
                if(r[q.top().second]<i){
                    cout<<-1;
                    return 0;
                }
                val[i]=value[q.top().second];
                upd(i);
            }
        }
        if(check()){
            for(int i=1;i<=n;i++)
                cout<<val[i]<<' ';
        }else
            cout<<-1;
    }
    return 0;
}
