/**
* user:  zibnickij-103
* fname: Nikita
* lname: Zibnickij
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:30:14.937946
*/
#include <bits/stdc++.h>

using namespace std;

typedef pair<int, int> pt;

vector<vector<int>> ans;

bool check(int n, int m, int k){
    if (n > m)
        swap(n, m);
    if (k < m / 2 || k > m * n / 4)
        return false;
    if (n == m && k == n / 2 + 1)
        return false;
    if (k == n * m / 4 - 1)
        return false;
    return true;
}

inline bool point_in_seg(int k, int n, int m){
    int l = m / 2, r = m * n / 4;
    if (k < l || k > r)
        return false;
    if (k == r - 1)
        return false;
    if ((n == m) && (k == l + 1))
        return false;
    return true;
}

pt div(int k, int n1, int m1, int n2, int m2){
    if (n1 > m1)
        swap(n1, m1);
    if (n2 > m2)
        swap(n2, m2);
    int l1 = m1 / 2;
    int r1 = n1 * m1 / 4 - 2;
    int l2 = m2 / 2;
    int r2 = n2 * m2 / 4 - 2;
    if (n1 == m1)
        l1 += 2;
    if (n2 == m2)
        l2 += 2;
    if (l1 <= r1 && l2 <= r2){
        int r = k - r1;
        if (r >= l2 && r <= r2)
            return {r1, r};
        r = k - l2;
        if (r >= l1 && r <= r1)
            return {r, l2};
    }
    int r = k - m1 / 2;
    if (point_in_seg(r, n2, m2))
        return {m1 / 2, r};
    r = k - m2 / 2;
    if (point_in_seg(r, n1, m1))
        return {r, m2 / 2};
    r = k - (r2 + 2);
    if (point_in_seg(r, n1, m1))
        return {r, r2 + 2};
    r = k - (r1 + 2);
    if (point_in_seg(r, n2, m2))
        return {r1 + 2, r};
    if (n1 != m1){
        r = k - (l1 + 1);
        if (point_in_seg(r, n2, m2))
            return {l1 + 1, r};
    }
    if (n2 != m2){
        r = k - (l2 + 1);
        if (point_in_seg(r, n1, m1))
            return {r, l2 + 1};
    }
    return {-1, -1};
}

int color;

void calc(int i1, int j1, int i2, int j2, int k){
    int n = i2 - i1 + 1, m = j2 - j1 + 1;
    if (min(n, m) == 2){
        assert(max(n, m) == 2 * k);
        if (m == 2){
            for (int cnt = 0; cnt < (i2 - i1 + 1) / 2; cnt++){
                for (int i = i1 + 2 * cnt; i <= i1 + 2 * cnt + 1; i++){
                    for (int j = j1; j <= j2; j++)
                        ans[i][j] = color;
                }
                color++;
            }
        } else {
            for (int cnt = 0; cnt < (j2 - j1 + 1) / 2; cnt++){
                for (int j = j1 + 2 * cnt; j <= j1 + 2 * cnt + 1; j++){
                    for (int i = i1; i <= i2; i++)
                        ans[i][j] = color;
                }
                color++;
            }
        }
        return;
    }
    if (check(n - 2, m - 2, k - 1)){
        for (int j = j1; j <= j2; j++){
            ans[i1][j] = color;
            ans[i2][j] = color;
        }
        for (int i = i1; i <= i2; i++){
            ans[i][j1] = color;
            ans[i][j2] = color;
        }
        color++;
        calc(i1 + 1, j1 + 1, i2 - 1, j2 - 1, k - 1);
        return;
    }
    int k1 = n / 2;
    int k2 = m / 2;
    if (k1 % 2 == 0){
        pt d = div(k, k1, m, k1, m);
        if (d.first != -1){
            calc(i1, j1, i1 + k1 - 1, j2, d.first);
            calc(i1 + k1, j1, i2, j2, d.second);
            return;
        }
    }
    if (k2 % 2 == 0){
        pt d = div(k, n, k2, n, k2);
        if (d.first != -1){
            calc(i1, j1, i2, j1 + k2 - 1, d.first);
            calc(i1, j1 + k2, i2, j2, d.second);
            return;
        }
    }
    int mn;
    if (k1 % 2 == 0){
        mn = 2;
    } else
        mn = 1;
    int n1 = k1 - mn, n2 = k1 + mn;
    pt d = div(k, n1, m, n2, m);
    if (d.first != -1){
        calc(i1, j1, i1 + n1 - 1, j2, d.first);
        calc(i1 + n1, j1, i2, j2, d.second);
        return;
    }
    if (k2 % 2 == 0)
        mn = 2;
    else
        mn = 1;
    int m1 = k2 - mn, m2 = k2 + mn;
    d = div(k, n, m1, n, m2);
    if (d.first != -1){
        calc(i1, j1, i2, j1 + m1 - 1, d.first);
        calc(i1 + m1 - 1, j1, i2, j2, d.second);
        return;
    }
}

void solve(){
    int n, m, k;
    cin >> n >> m >> k;
    if (n % 2 == 1 || m % 2 == 1){
        cout << "NO\n";
        return;
    }
    if (k < m / 2 || k * 4 > m * n || (k + 1) * 4 == m * n){
        cout << "NO\n";
        return;
    }
    if (n == m && k == m / 2 + 1){
        cout << "NO\n";
        return;
    }
    ans = vector<vector<int>> (n, vector<int> (m, 0));
    color = 1;
    calc(0, 0, n - 1, m - 1, k);
    cout << "YES\n";
    for (int i = 0; i < n; i++){
        for (int j = 0; j < m; j++)
            cout << ans[i][j] << " ";
        cout << '\n';
    }
}

int main(){
    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}