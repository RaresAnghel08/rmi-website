/**
* user:  trisca-vicol-58e
* fname: Cezar
* lname: Trișcă-Vicol
* task:  lucky
* score: 64.0
* date:  2019-10-10 10:27:35.029413
*/
#include <bits/stdc++.h>

using namespace std;

const int mod=1000000007;

int n,q,val[100010];
int ans,dyn[100010][20];
string s;

int main()
{
    cin>>n>>q>>s;
    for(int i=0; i<=9; i++)
        dyn[1][i]=1;
    for(int i=2; i<=n; i++)
    {
        int sum=0;
        for(int j=0; j<=9; j++)
            sum=(sum+dyn[i-1][j])%mod;
        for(int j=0; j<=9; j++)
            dyn[i][j]=(dyn[i][j]+sum)%mod;
        dyn[i][1]-=dyn[i-1][3];
        dyn[i][1]=(dyn[i][1]+mod)%mod;
    }
    for(int i=0; i<n; i++)
        val[i]=s[i]-'0';
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<val[i]; j++)
            ans=(ans+dyn[n-i][j])%mod;
        if(i)if(val[i-1]==1)
            {
                if(val[i]>3)
                    ans-=dyn[n-i][3];
                ans=(ans+mod)%mod;
                if(val[i]==3)break;
            }
        if(i==n-1)ans=(ans+1)%mod;
    }
    cout<<ans<<'\n';
    for(; q; q--)
    {
        int L,R;
        cin>>L>>L>>R;
        ans=0;
        for(int i=L-1; i<R; i++)
        {
            for(int j=0; j<val[i]; j++)
                ans=(ans+dyn[n-i-(n-R)][j])%mod;
            if(i>=L)if(val[i-1]==1)
                {
                    if(val[i]>3)
                        ans-=dyn[n-i-(n-R)][3];
                    ans=(ans+mod)%mod;
                    if(val[i]==3)break;
                }
            if(i==R-1)ans=(ans+1)%mod;
        }
        cout<<ans<<'\n';
    }
//    for(int i=0;i<n;i++)
//        ajj=ajj*10+val[i];
//    for(int i=0;i<=ajj;i++)
    return 0;
}
