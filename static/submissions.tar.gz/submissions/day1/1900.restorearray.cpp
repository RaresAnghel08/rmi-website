/**
* user:  bashev-75b
* fname: Dobrin
* lname: Bashev
* task:  restore
* score: 7.0
* date:  2019-10-10 08:05:25.346991
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

const int MAXN = 5003;
const int MAXM = 10004;

struct condition
{
    int l, r, k, v;
};

int n, m, a[MAXN];
condition b[MAXM];

int main()
{
    cin >> n >> m;

    for (int i = 1; i <= m; ++ i)
    {
        cin >> b[i].l >> b[i].r >> b[i].k >> b[i].v;
    }

    for (int i = 0; i < (1 << n); ++ i)
    {
        bool f = 1;
        for (int j = 1; j <= m; ++ j)
        {
            int zero = 0;
            for (int k = b[j].l; k <= b[j].r; ++ k)
            {
                if ((i & (1 << k)) == 0) zero++;
            }

            if ((b[j].v == 0 and b[j].k > zero) or (b[j].v == 1 and b[j].k <= zero))
            {
                f = 0;
                break;
            }
        }

        if (f == 1)
        {
            for (int k = 0; k < n; ++ k)
            {
                if (i & (1 << k)) cout << 1 << ' ';
                else cout << 0 << ' ';
            }
            cout << endl;
            return 0;
        }
    }

    cout << -1 << endl;
    return 0;
}

/*
4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0
*/
