/**
* user:  mavrodiev-f84
* fname: Tsvetoslav Valentinov
* lname: Mavrodiev
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:42:39.711245
*/
#include<bits/stdc++.h>
using namespace std;

void assignHints(int subtask, int N, int A[], int B[]);
void speedrun(int subtask, int N, int start);

void setHintLen(int l);
void setHint(int i, int j, bool b);
int getLength();
bool getHint(int j);
bool goTo(int x);

void assignHints(int subtask, int N, int A[], int B[])
{
    setHintLen(N);
    for(int i=1;i<N;i++)
    {
        setHint(A[i],B[i],1);
        setHint(B[i],A[i],1);
    }
}

bool f[1024];

void dfs(int x, int N, int pr=0)
{
    if(f[x]) return;
    f[x]=1;
    for(int i=1;i<=N;i++)
    {
        if(getHint(i))
        {
            goTo(i);
            dfs(i,N,x);
        }
    }
    if(pr) goTo(pr);
}

void speedrun(int subtask, int N, int start)
{
    dfs(start, N);
}
