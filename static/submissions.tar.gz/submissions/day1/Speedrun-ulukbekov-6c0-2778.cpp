/**
* user:  ulukbekov-6c0
* fname: Erzhan
* lname: Ulukbekov
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 10:06:03.615527
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
   ios::sync_with_stdio(0);
   cin.tie(0); cout.tie(0);
   //assert(N <= 100);
   setHintLen(20);
   if (N == 1) return;
   vector<int> cnt(N + 1, 0);
   for (int i = 1; i < N; i++) {
      cnt[A[i]]++;
      cnt[B[i]]++;
   }
   int root = 0;
   for (int i = 1; i <= N; i++) {
      if (cnt[i] >= 2) {
         root = i;
         break;
      }
   }
   assert(root != 0);
   for (int i = 1; i <= N; i++) {
      for (int j = 0; j < 20; j++) {
         if (root & (1 << j)) setHint(i, j + 1, 1);
         else setHint(i, j + 1, 0);
      }
   }
}

void speedrun(int subtask, int N, int start) {
   ios::sync_with_stdio(0);
   cin.tie(0); cout.tie(0);
   int L = getLength();

   if (N == 1) return;
   if (N == 2) {
      if (start == 1) goTo(2);
      else goTo(1);
      return;
   }
   int root = 0;
   for (int j = 0; j < 20; j++) {
      if (getHint(j + 1)) root += (1 << j);
   }
   goTo(root);
   for (int i = 1; i <= N; i++) {
      if (i != root) {
         goTo(i);
         goTo(root);
      }
   }
}
