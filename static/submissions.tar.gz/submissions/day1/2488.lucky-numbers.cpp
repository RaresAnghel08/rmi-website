/**
* user:  musat-50e
* fname: Tiberiu Ioan
* lname: Mușat
* task:  lucky
* score: 28.0
* date:  2019-10-10 09:23:46.910726
*/
#include <iostream>
#include <cstdio>

using namespace std;

const int MOD = 1e9 + 7;

const int MAX_N = 1e5;
long long dp[MAX_N + 1], sp[MAX_N + 1];

long long calc_sol(char* v, int n) {
    long long ans = 0, th = 1;
    for (int i = 1; i <= n; i++) {
        if (i > 1 && v[i - 1] == 1 && v[i] == 3)
            th = 0;

        ans += dp[n - i] * (v[i] - (v[i] > 1) - (i > 1 && v[i - 1] == 1 && v[i] > 3));
        if (v[i] > 1)
            ans += (i < n ? sp[n - i - 1] : 1);
        ans %= MOD;
    }
    return ans + th;
}

char v[MAX_N + 1];

int main() {
//    freopen("input.txt", "r", stdin);

    dp[0] = 1;
    sp[0] = 9;
    long long p10 = 1, dec = 0;

    for (int i = 1; i <= MAX_N; i++) {
        p10 = p10 * 10 % MOD;
        if (i >= 2)
            dec = (dec * 10 + dp[i - 2]) % MOD;
        dp[i] = (p10 - dec + MOD) % MOD;
        sp[i] = (sp[i - 1] + dp[i] * 8) % MOD;
    }

//    for (int i = 0; i < 10; i++)
//        cout << i << ' ' << dp[i] << endl;

    int n, q;
    cin >> n >> q;
    cin >> v + 1;

    for (int i = 1; i <= n; i++)
        v[i] -= '0';

    cout << calc_sol(v, n) << '\n';

    for (int i = 0; i < q; i++) {
        int t, a, b;
        cin >> t >> a >> b;

        if (t == 1)
            cout << calc_sol(v + a - 1, b - a + 1) << '\n';
        else
            v[a] = b;
    }
    return 0;
}
