/**
* user:  gasan-ebd
* fname: Luca Carol
* lname: Gasan
* task:  Present
* score: 8.0
* date:  2021-12-16 11:31:24.705677
*/
#include <bits/stdc++.h>
using namespace std;
ofstream out("present.out");
bool ok[(1<<19)+5];
const int dp[]={
1,
1,
2,
3,
6,
9,
16,
29,
54,
87,
138,
317,
404,
1017,
1566,
1971,
4566,
10041,
13732,
33713,
39246,
60383,
149342,
315905,
356036,
684169};
bool viz[27];
vector<int> v;
int main()
{
    ios_base::sync_with_stdio(false);
    cout.tie(0);
    ok[0]=true;
    v.push_back(0);
    for(int mask=1;mask<(1<<19);++mask)
    {
        vector<int> used;
        used.clear();
        for(int i=0;i<19;++i)
        {
            if(mask&(1<<i))
                used.push_back(i+1),
                viz[i+1]=true;
            else viz[i+1]=false;
        }
        int maxim=used.back();
        if(ok[mask-(1<<(maxim-1))]==false)
            continue;
        bool found=false;
        for(int x:used)
        if(viz[__gcd(x,maxim)]==false)
        {
            found=true;
            break;
        }
        if(!found)
            ok[mask]=true,
            v.push_back(mask);
    }
    int tst;
    cin>>tst;
    while(tst--)
    {
        int k;
        cin>>k;
        if(k<v.size())
        {
            int ord=v[k];
            cout<<__builtin_popcount(ord)<<' ';
            for(int i=0;i<20;++i)
            if(ord&(1<<i))
                cout<<i+1<<' ';
            cout<<'\n';
            continue;
        }
        int maxim=0,sum=0;
        while(sum+dp[maxim]<k)
            sum+=dp[maxim],++maxim;
        int remain=k-sum;
        int gasit=-1;
        for(int mask:v)
        {
            vector<int> used;
            used.clear();
            for(int i=0;i<maxim-1;++i)
            {
                if(mask&(1<<i))
                    used.push_back(i+1),
                    viz[i+1]=true;
                else viz[i+1]=false;
            }
            bool found=false;
            for(int x:used)
            if(viz[__gcd(x,maxim)]==false)
            {
                found=true;
                break;
            }
            if(!found)
                remain--;
            if(remain==0)
            {
                gasit=mask;
                break;
            }
        }
        if(gasit!=-1)
        {
            cout<<__builtin_popcount(gasit)+1<<' ';
            for(int i=0;i<maxim-1;++i)
            if(gasit&(1<<i))
                cout<<i+1<<' ';
            cout<<maxim<<'\n';
            continue;
        }
        for(int mask=(1<<19);;++mask)
        {
            vector<int> used;
            used.clear();
            for(int i=0;i<maxim-1;++i)
            {
                if(mask&(1<<i))
                    used.push_back(i+1),
                    viz[i+1]=true;
                else viz[i+1]=false;
            }
            bool found=false;
            for(int b=20;b<=maxim;++b) if(viz[b])
            for(int x:used)
            if(viz[__gcd(x,maxim)]==false)
            {
                found=true;
                break;
            }
            if(!found)
                remain--;
            if(remain==0)
            {
                gasit=mask;
                break;
            }
        }
        cout<<__builtin_popcount(gasit)+1<<' ';
        for(int i=0;i<maxim-1;++i)
        if(gasit&(1<<i))
            cout<<i+1<<' ';
        cout<<maxim<<'\n';
    }
    return 0;
}

