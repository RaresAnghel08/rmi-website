/**
* user:  ralnikov-364
* fname: Paul
* lname: Ralnikov
* task:  Gardening
* score: 11.0
* date:  2021-12-16 11:59:18.388520
*/
#include<bits/stdc++.h>
#define f first
#define s second
#define _ << ' ' <<
#define all(x) x.begin(), x.end()
#define sz(x) (int)x.size()
#define mp make_pair
#define Time() clock() / (ld) CLOCKS_PER_SEC

#ifdef LOCAL
	#define cerr cout
#else
	#define cerr if(0) cout
#endif

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;

void myFill(vector<vector<int> > &a, int il, int jl, int ir, int jr, int &nxt) {
	int n = sz(a), m = sz(a[0]);
	if (ir >= n || jr >= m) return;
	//cout << "myfill" _ il + 1 _ jl + 1 _ ir + 1 _ jr + 1 _ nxt<< endl;
	int nnxt = 0;
	for (int i = il; i <= ir; i++) {
		for (int j = jl; j <= jr; j++) {
			a[i][j] = nxt + (j - jl) / 2 + (i - il) / 2 * (jr - jl + 1) / 2;
			nnxt = max(nnxt, a[i][j]);
		}
	}
	nxt = nnxt + 1;
}

void solve() {
	int n, m, k;
	cin >> n >> m >> k;
	if (n & 1 || m & 1) {
		cout << "NO\n";
		return;
	}	
	if (n == 2) {
		if (k == 1ll * n * m / 4) {
			cout << "YES\n";
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < m; j++) {
					cout << (m / 2) * (i / 2) + j / 2 + 1 << ' ';
				}
				cout << '\n';
			}
		} else {
			cout << "NO\n";
		}
	} else if (n == 4) {
		if (m == 2) {
			if (k != 2) {
				cout << "NO\n";
			} else {
				cout << "YES\n";
				cout << "1 1\n1 1\n2 2\n2 2\n";
			}
			return;
		}
		if (k < m / 2) {
			cout << "NO\n";
			return;
		}
		if (k > m) {
			cout << "NO\n";
			return;
		}
		int c = 1ll * n * m / 4 - k;
		if (c == 1) {
			cout << "NO\n";
			return;
		}
		vector<vector<int> > a(n, vector<int> (m, 0));
		int len = c * 2;
		int nxt = 1;
		if (len > 0) {
				for (int j = 0; j < len; j++) {
				a[0][j] = 1;
				a[3][j] = 1;
			}
			a[1][0] = a[2][0] = 1;
			a[1][len - 1] = a[2][len - 1] = 1;
			for (int j = 1; j < len - 1; j++) {
				a[1][j] = a[2][j] = 0 + (j - 1) / 2 + 2;
				nxt = max(nxt, a[1][j] - 0 + 1);
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = len; j < m; j++) {
				a[i][j] = (j - len) / 2 + nxt + (i / 2) * (m - len) / 2;
			}
		}
		cout << "YES\n";
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cout << a[i][j] << ' ';
			}
			cout << '\n';
		}
	} else {
		bool fl = 0;
		if (n > m) {
			swap(n, m);
			fl = 1;
		}
		int lc = 1, rc = min(n, m) / 2, c;
		while (rc - lc > 1) {
			c = (lc + rc) / 2;
			int l = c, r = m / 2, len, mid;
			len = l * 2 + 2;
			if (c + 1ll * (n - c * 2) * (len - c * 2) / 4 + 1ll * n * (m - len) / 4 < k) {
				lc = c;
				continue;
			}
			len = r * 2;
			if (c + 1ll * (n - c * 2) * (len - c * 2) / 4 + 1ll * n * (m - len) / 4 > k) {
				rc = c;
				continue;
			}
			while (r - l > 1) {
				mid = (r + l) / 2;
				len = mid * 2;
				if (c + 1ll * (n - c * 2) * (len - c * 2) / 4 + 1ll * n * (m - len) / 4 > k) {
					l = mid;
				} else r = mid;
			}
			len = r * 2;
			//cout << c _ len _ (c + 1ll * (n - c * 2) * (len - c * 2) / 4 + 1ll * n * (m - len) / 4) << endl;
			if ((c + 1ll * (n - c * 2) * (len - c * 2) / 4 + 1ll * n * (m - len) / 4) == k) {
				vector<vector<int> > a(n, vector<int> (m, 0));
				int nxt = 1;
				for (int i = 0; i < c; i++) {
					for (int j = i; j < len - i; j++) {
						a[i][j] = nxt;
						a[n - i - 1][j] = nxt;
					}
					for (int j = i; j < n - i; j++) {
						a[j][i] = nxt;
						a[j][len - i - 1] = nxt;
					}
					nxt++;
				}
				myFill(a, c, c, n - c - 1, len - c - 1, nxt);
				myFill(a, 0, len, n - 1, m - 1, nxt);
				cout << "YES\n";
				if (fl) {
					 for (int j = 0; j < m; j++)  {
						 for (int i = 0; i < n; i++) cout << a[i][j] << ' ';
					cout << '\n';
					}
					return;
				}
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < m; j++) cout << a[i][j] << ' ';
					cout << '\n';
				}
				return;
			}
		}
		cout << "NO\n";
	}
}

signed main() {
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int tests = 1;
	cin >> tests;
	while (tests--) {
		solve();
	}
	return 0;
}