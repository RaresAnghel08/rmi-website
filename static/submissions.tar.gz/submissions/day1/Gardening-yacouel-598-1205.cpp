/**
* user:  yacouel-598
* fname: Assaf
* lname: Yacouel
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:19:18.948083
*/
#include <iostream>
using namespace std;
int main()
{
	int t, n, m, k;
	cin >> t;
	for (int i = 0; i < t; i++) {
		cin >> n >> m >> k;
		if (n == m && n == 2) {
			if (k == 1) {
				cout << "YES\n";
				cout << 1 << " " << 1 << "\n";
				cout << 1 << " " << 1 << "\n";
			}
			else cout << "NO\n";
		}
		else if (n == 2 && m == 4) {
			if (k == 2) {
				cout << "YES\n";
				cout << 1 << " " << 1 << " " << 2 << " " << 2 << "\n";
				cout << 1 << " " << 1 << " " << 2 << " " << 2 << "\n";
			}
			else cout << "NO\n";
		}
		else if (n == 4 && m == 2) {
			if (k == 2) {
				cout << "YES\n";
				cout << 1 << " " << 1 << "\n" << 2 << " " << 2 << "\n";
				cout << 1 << " " << 1 << "\n" << 2 << " " << 2 << "\n";
			}
			else cout << "NO\n";
		}
		else if (n == 4 && m == 4) {
			if (k == 2) {
				cout << "YES\n";
				cout << 1 << " " << 1 << " " << 1 << " " << 1 << "\n";
				cout << 1 << " " << 2 << " " << 2 << " " << 1 << "\n";
				cout << 1 << " " << 2 << " " << 2 << " " << 1 << "\n";
				cout << 1 << " " << 1 << " " << 1 << " " << 1 << "\n";
			}
			else if (k == 4) {
				cout << "YES\n";
				cout << 1 << " " << 1 << " " << 2 << " " << 2 << "\n";
				cout << 1 << " " << 1 << " " << 2 << " " << 2 << "\n";
				cout << 4 << " " << 4 << " " << 3 << " " << 3 << "\n";
				cout << 4 << " " << 4 << " " << 3 << " " << 3 << "\n";
			}
			else cout << "NO\n";
		}
		else cout << "NO\n";
	}

}