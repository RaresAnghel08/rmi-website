/**
* user:  zabauski-46a
* fname: Daniil
* lname: Zabauski
* task:  Present
* score: 0.0
* date:  2021-12-16 11:43:45.026079
*/
#include<bits/stdc++.h>
#define fi first
#define se second
#define pb push_back
#define sz(x) (int)(x).size()
typedef long long ll;
typedef long double ld;

using namespace std;
const int N = (int)1e6 + 1;
set < int > now;
int k;

bool Have[N];
vector < int > save[N];

int id = 0;
vector < int > want;

const int F = 20;

int gc[50][50];
void brute(){

    vector < int > now ( 50);
    int time = 0;
    int vals = 15;

    for(int msk = 0; msk < (1 << vals); ++msk){
            vector < int > have;
            time++;
            for(int j = 1; j <= vals; ++j){
                if((1 << (j - 1)) & msk){
                    have.pb(j);
                    now[j] = time;
                }
            }
            bool bad = 0;
           for(int f =0 ; f < sz(have); ++f){
            for(int f1 = 0; f1< sz(have); ++f1){
                if(now[gc[have[f]][have[f1]]] != time){
                    bad = 1;
                    break;
                }
            }
            if(bad)break;
           }
            if(!bad){
                if(Have[id + 1]){
                    save[id + 1] = have;
                }
                id++;
                if(id == (int)1e6){
                    cerr << "DONE\n";
                    break;
                }
            }
    }


}


int main(){
for(int i = 0;  i< 50; ++i)
for(int j = 0 ; j < 50; ++j)
    gc[i][j] = __gcd(i , j);
    int t;
    cin >> t;
    want.resize(t);
    for(auto &i : want)
        cin >> i, Have[i] = 1;
    brute();
//    cout << " LL " << id << endl;
    for(int i : want){
        cout << sz(save[i]) << ' ';
        for(auto &u : save[i]){
            cout << u << ' ';
        }
        cout << endl;
    }
    return 0;
}
