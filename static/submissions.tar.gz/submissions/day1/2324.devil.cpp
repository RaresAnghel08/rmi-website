/**
* user:  bartoli-2aa
* fname: Davide
* lname: Bartoli
* task:  devil
* score: 0.0
* date:  2019-10-10 09:00:21.380937
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<int>a(10);
vector<int> ordine;
int prossimo(){
    for(int i=9;i>0;i--){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int primo(){
    for(int i=1;i<10;i++){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int T;
    cin>>T;
    while(T--){
        int K;
        cin>>K;
        fill(a.begin(),a.end(),0);
        int tot=0;
        for(int i=1;i<10;i++){
            cin>>a[i];
            tot+=a[i];
        }
        vector<int>sol(tot,0);
        for(int i=tot-1;i>tot-K;i--){
            sol[i]=prossimo();
        }
        sol[tot-K]=primo();
        tot-=K;
        bool p=0;
        if(a[1]<a[2]){
            p=1;
        }
        if(p==0){
            int o=(int)(ceil((float)(tot)/a[2]));
            for(int i=0;i<K;i+=o){
                for(int j=i;j<tot;j+=K)sol[j]=prossimo();
            }
            for(int i=0;i<sol.size();i++){
                if(sol[i]==0)sol[i]=primo();
                cout<<sol[i];
            }
            cout<<endl;
        }else{
            int o=(int)(ceil((float)(tot)/(a[1]+1)))-1;
            for(int i=o;i<K;i+=o){
                for(int j=i;j<tot;j+=K)sol[j]=primo();
            }
            for(int i=0;i<sol.size();i++){
                if(sol[i]==0)sol[i]=prossimo();
                cout<<sol[i];
            }
            cout<<endl;
        }
    }
    return 0;
}
