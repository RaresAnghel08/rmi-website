/**
* user:  tamyarov-797
* fname: Ilya
* lname: Tamyarov
* task:  restore
* score: 0.0
* date:  2019-10-10 10:32:11.656774
*/
#define ll long long
#include<bits/stdc++.h>
using namespace std;
ll MOD=1e9+7;
void solve();
int main(){
    solve();
    return 0;
}

void solve()
{

    ll e,ee,n;

    cin>>e>>ee>>n;

    ll nt=0;
    ll pw=1;
    ll cnt=0;
    ll ans=0;
    while(n)
    {
        if(n%100>13)
        {
            ans+=n/100*(((pw-nt)%MOD+MOD)%MOD);
            ans%=MOD;
        }
        n/=10;
        nt*=10;
        nt++;
    }
    cout<<ans;
    return;
}
