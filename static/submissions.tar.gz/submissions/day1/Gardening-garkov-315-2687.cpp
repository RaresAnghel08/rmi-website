/**
* user:  garkov-315
* fname: Velislav Petrov
* lname: Garkov
* task:  Gardening
* score: 11.0
* date:  2021-12-16 09:57:34.835452
*/
#include <iostream>
using namespace std;
#define endl '\n'
const int MAXN=2e5+10;
int res[6][MAXN];
int main () {
    /**
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    **/
    int t;
    cin >> t;
    int n, m, k;
    for (int test=0;test<t;test++) {
        cin >> n >> m >> k;
        if (n%2==1 || m%2==1) {
            cout << "NO\n";
            continue;
        }
        if (min(n,m)==2) {
            if (k!=max(n,m)/2) cout << "NO\n";
            else {
                cout << "YES\n";
                for (int j=0;j<=1;j++) {
                    for (int i=0;i<max(n,m)/2;i++) res[j][i*2]=res[j][i*2+1]=i+1;
                }
                for (int i=0;i<n;i++) {
                    for (int j=0;j<m;j++) {
                        if (m>n) cout << res[i][j] << ' ';
                        else cout << res[j][i] << ' ';
                    }
                    cout << endl;
                }
            }
            continue;
        }
        if (n<=4) {
            int ans=-1, s;
            for (int i=0;i<=m;i+=2) {
                if (i==2) continue;
                s=i/2+m-i;
                if (s==k) {
                    ans=i;
                    break;
                }
            }
            if (ans==-1) cout << "NO\n";
            else {
                cout << "YES\n";
                int maxs=0;
                for (int i=0;i<4;i++) {
                    for (int j=0;j<ans;j++) {
                        if (i==0 || i==3) res[i][j]=1;
                        else {
                            if (j==0 || j==ans-1) res[i][j]=1;
                            else res[i][j]=(j+1)/2+1;
                        }
                        maxs=max(maxs,res[i][j]);
                    }
                }
                maxs++;
                for (int i=ans;i<m;i+=2) {
                    res[0][i]=res[1][i]=res[0][i+1]=res[1][i+1]=maxs;
                    maxs++;
                }
                for (int i=ans;i<m;i+=2) {
                    res[2][i]=res[3][i]=res[2][i+1]=res[3][i+1]=maxs;
                    maxs++;
                }
                for (int i=0;i<n;i++) {
                    for (int j=0;j<m;j++) cout << res[i][j] << ' ';
                    cout << endl;
                }
            }
        } else {
            int full=3*(m/2), s, cur;
            pair <int,int> ans;
            ans={-1,-1};
            for (int i=0;i<=m;i+=2) {
                if (i==2) continue;
                s=full-((i/2)+(i>0));
                cur=max(i-2,m-i);
                ///cout << i << ' ' << s << ' ' << cur << ' ' << (s==k) << endl;
                if (s==k) {
                    ans={i,0};
                    break;
                }
                if (s-k>1 && s-k<=cur/2) {
                    ans={i,(s-k)*2};
                    break;
                }
            }
            if (ans.first==-1) {
                cout << "NO\n";
                continue;
            }
            cout << "YES\n";
            int cnt=1;
            if (ans.first!=0) cnt++;
            if (ans.second!=0) cnt++;
            for (int i=0;i<6;i++) {
                if (ans.first!=0) res[i][0]=res[i][ans.first-1]=1;
            }
            for (int j=1;j<ans.first;j++) res[0][j]=res[5][j]=1;
            if (ans.second!=0) {
                if (m-ans.first<ans.second) {
                    for (int i=1;i<5;i++) res[i][1]=res[i][ans.second]=2;
                    for (int j=2;j<ans.second+1;j++) res[1][j]=res[4][j]=2;
                } else {
                    for (int i=0;i<4;i++) res[i][ans.first]=res[i][ans.first+ans.second-1]=2;
                    for (int j=ans.first+1;j<=ans.first+ans.second;j++) res[0][j]=res[3][j]=2;
                }
            }
            for (int i=0;i<6;i++) {
                for (int j=0;j<m;j++) {
                    if (res[i][j]==0) {
                        res[i][j]=res[i][j+1]=cnt;
                        res[i+1][j]=res[i+1][j+1]=cnt;
                        cnt++;
                    }
                }
            }
            for (int i=0;i<n;i++) {
                for (int j=0;j<m;j++) cout << res[i][j] << ' ';
                cout << endl;
            }
        }
    }
    return 0;
}
