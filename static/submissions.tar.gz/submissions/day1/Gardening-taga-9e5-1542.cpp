/**
* user:  taga-9e5
* fname: Ștefan
* lname: Țaga
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:07:09.022534
*/
#include <bits/stdc++.h>

using namespace std;
int t,n,m,k;
int invers,i,j;
vector <vector <int>> sol;
vector <vector <map <int,int>>> din;
int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(0);
#ifdef HOME
    ifstream cin("date.in");
    ofstream cout("date.out");
#endif // HOME
    cin>>t;
    for (; t--;)
    {
        cin>>n>>m>>k;
        /// am trei operatii : pot ori (n-2,m,k-m/2), (n,m-2,k-n/2) sau (n-2,m-2,k-1)
        if (n%2==1||m%2==1)
        {
            cout<<"NO"<<'\n';
            continue;
        }
        sol.resize(n+1);
        for (i=1; i<=n; i++)
        {
            sol[i].resize(m+1);
        }
        din.resize(n+2);
        for (i=1;i<=n;i++)
        {
            din[i].resize(m+2);
        }
        for (i=2;i<=n;i+=2)
        {
            din[i][2][i/2]=1;
        }
        for (i=2;i<=m;i+=2)
        {
            din[2][i][i/2]=2;
        }
        for (i=4;i<=n;i+=2)
        {
            for (j=4;j<=m;j+=2)
            {
                for (auto ind : din[i-2][j])
                {
                    din[i][j][ind.first+j/2]=1;
                }
                for (auto ind : din[i][j-2])
                {
                    din[i][j][ind.first+i/2]=2;
                }
                for (auto ind : din[i-2][j-2])
                {
                    din[i][j][ind.first+1]=3;
                }
            }
        }
        if (din[n][m][k]!=0)
        {
            cout<<"YES"<<'\n';
            int copn=n,copm=m,stl=1,drl=n,stc=1,drc=m;
            while (n!=0&&m!=0)
            {
                if (din[n][m][k]==1)
                {
                    for (j=stc;j<=drc;j+=2)
                    {
                        sol[drl-1][j]=sol[drl-1][j+1]=sol[drl][j]=sol[drl][j+1]=k;
                        k--;
                    }
                    drl-=2;
                    n-=2;
                }
                else
                if (din[n][m][k]==2)
                {
                    for (i=stl;i<=drl;i+=2)
                    {
                        sol[i][drc-1]=sol[i][drc]=sol[i+1][drc-1]=sol[i+1][drc]=k;
                        k--;
                    }
                    drc-=2;
                    m-=2;
                }
                else
                {
                    for (i=stl;i<=drl;i++)
                    {
                        sol[i][drc]=k;
                        sol[i][stc]=k;
                    }
                    for (i=stc;i<=drc;i++)
                    {
                        sol[stl][i]=k;
                        sol[drl][i]=k;
                    }
                    stc++;stl++;
                    drc--;drl--;
                    k--;
                    n-=2;
                    m-=2;
                }
            }
            for (i=1;i<=copn;i++)
            {
                for (j=1;j<=copm;j++)
                {
                    cout<<sol[i][j]<<" ";
                }
                cout<<'\n';
            }
        }
        else
        {
            cout<<"NO"<<'\n';
        }
    }
    return 0;
}
