/**
* user:  bicu-c00
* fname: Eduard Codruț
* lname: Bicu
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:09:23.160779
*/
#include <bits/stdc++.h>
#define f cin
#define g cout

using namespace std;


// se pot face numai patrate 2x2 sau laturile unui dreptunghi/patrat
// la fiecare pas de completare am 2 modalitati sa umplu un cadran: fie umplu marginea sa si fac fill(n - 2, n - 2, k)
int n, m, t, k;

int main()
{
    f >> t;

    for (int i = 1; i <= t; i++)
    {
        f >> n >> m >> k;

        if (n % 2 == 1 || m % 2 == 1 || k > min(n, m))
        {
            g << "NO\n";
            continue;
        }

        if (n <= 4 && m <= 4)
        {
            if (n == 2 && m == 2)
            {
                if (k != 1)
                {
                    g << "NO\n";
                    continue;
                }
                else
                {
                    g << "YES\n";
                    g << "1 1\n" << "1 1\n";
                    continue;
                }
            }
            if (n == 2 && m == 4)
            {
                 if (k != 2)
                {
                    g << "NO\n";
                    continue;
                }
                else
                {
                    g << "YES\n";
                    g << "1 1 2 2\n" << "1 1 2 2\n";
                    continue;
                }
            }
            if (n == 4 && m == 2)
            {
                if (k != 2)
                {
                    g << "NO\n";
                    continue;
                }
                else
                {
                    g << "YES\n";
                    g << "1 1\n" << "1 1\n" << "2 2\n" << "2 2\n";
                    continue;
                }
            }
            if (n == 4 && m == 4)
            {
                if (k != 2 && k != 4)
                {
                    g << "NO\n";
                    continue;
                }
                else
                {
                    g << "YES\n";
                    if (k == 2)
                    {
                        g << "1 1 1 1\n" << "1 2 2 1\n" << "1 2 2 1\n" << "1 1 1 1\n";
                        continue;
                    }
                    else
                    {
                        g << "1 1 2 2\n" << "1 1 2 2\n" << "3 3 4 4\n" << "3 3 4 4\n";
                        continue;
                    }
                }
            }
        }
    }

    return 0;
}
