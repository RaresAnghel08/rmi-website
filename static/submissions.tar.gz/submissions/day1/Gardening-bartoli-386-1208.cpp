/**
* user:  bartoli-386
* fname: Davide
* lname: Bartoli
* task:  Gardening
* score: 5.0
* date:  2021-12-16 07:20:10.105043
*/
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define pb push_back
int N,M,K;
void solve() {
    cin>>N>>M>>K;
    if(K>N*M/4 || N*M>200000 || N%2==1 || M%2==1) {
        cout<<"NO\n";
        return;
    }
    int giri=0;
    while(1) {
        if(K-giri==(N-2*giri)*(M-2*giri)/4) {
            if(K-giri==0 && M!=N){
                cout<<"NO\n";
                return;
            }
            cout<<"YES\n";
            for(int i=0; i<N; i++) {
                for(int j=0; j<M; j++) {
                    if(i<giri || j<giri || i>=N-giri || j>=M-giri) {
                        cout<<min({i,j,N-i-1,M-j-1})+1<<" ";
                    } else {
                        cout<<(i-giri)/2*(M-giri)/2+(j-giri)/2+1+giri<<" ";
                    }
                }
                cout<<'\n';
            }
            return;
        }
        giri++;
        if(giri>N/2)
            break;
    }
    cout<<"NO\n";


}
signed main() {
ios_base::sync_with_stdio(0);cin.tie(0);
    int T;
    cin>>T;
    while(T--)
        solve();
}
