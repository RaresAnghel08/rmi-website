/**
* user:  asadullin-bba
* fname: Aidar Ildarovich
* lname: Asadullin
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:59:21.326842
*/
#include <bits/stdc++.h>

using namespace std;

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
    cout.tie();
#ifdef foo
    freopen("input.txt", "r", stdin);
#endif
    int T;
    cin >> T;
    for (int i = 0; i < T; ++i) {
        int n, m, k;
        cin >> n >> m >> k;
        if (n % 2 == 1 || m % 2 == 1) {
            cout << "NO\n";
            continue;
        }
        int a[n][m];

        for (int i1 = 0; i1 < n; ++i1) {
            for (int j = 0; j < m; ++j) {
                a[i1][j] = -1;
            }
        }
        if (n == 2) {
            if (k != m / 2) {
                cout << "NO\n";
                continue;
            }
            cout << "YES\n";
            int it = 1;
            for (int j = 0; j < n / 2; ++j) {
                for (int l = 0; l < m / 2; ++l) {
                    a[j * 2][l * 2] = it;
                    a[j * 2 + 1][l * 2] = it;
                    a[j * 2][l * 2 + 1] = it;
                    a[j * 2 + 1][l * 2 + 1] = it;
                    it++;
                }
            }
            for (int k1 = 0; k1 < n; ++k1) {
                for (int j = 0; j < m; ++j) {
                    cout << a[k1][j] << " ";
                }
                cout << "\n";
            }
            continue;
        }

        if (k == n * m / 4 - 1) {
            cout << "NO\n";
            continue;
        }
        if (k < m / 2) {
            cout << "NO\n";
            continue;
        }
        cout << "YES\n";
        int it = 1;
        if (k == n * m / 4) {
            for (int j = 0; j < n / 2; ++j) {
                for (int l = 0; l < m / 2; ++l) {
                    a[j * 2][l * 2] = it;
                    a[j * 2 + 1][l * 2] = it;
                    a[j * 2][l * 2 + 1] = it;
                    a[j * 2 + 1][l * 2 + 1] = it;
                    it++;
                }
            }
        } else {
            int need = n * m / 4 - 1 - k;
            for (int j = 0; j <= need - 1; ++j) {
                a[1][j * 2 + 1] = it;
                a[1][j * 2 + 2] = it;
                a[2][j * 2 + 1] = it;
                a[2][j * 2 + 2] = it;
                it++;
            }
            for (int j = 0; j < n / 2; ++j) {
                for (int l = need + 1; l < m / 2; ++l) {
                    a[j * 2][l * 2] = it;
                    a[j * 2 + 1][l * 2] = it;
                    a[j * 2][l * 2 + 1] = it;
                    a[j * 2 + 1][l * 2 + 1] = it;
                    it++;
                }
            }
            for (int i1 = 0; i1 < n; ++i1) {
                for (int j = 0; j < m; ++j) {
                    if (a[i1][j] == -1) {
                        a[i1][j] = it;
                    }
                }
            }
        }
        for (int k1 = 0; k1 < n; ++k1) {
            for (int j = 0; j < m; ++j) {
                cout << a[k1][j] << " ";
            }
            cout << "\n";
        }
    }
}