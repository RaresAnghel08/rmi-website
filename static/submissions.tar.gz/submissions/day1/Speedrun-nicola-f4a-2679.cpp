/**
* user:  nicola-f4a
* fname: Alexandra Mihaela
* lname: Nicola
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 09:56:15.739097
*/
#include <bits/stdc++.h>
#include "speedrun.h"
#define DIM 1010
using namespace std;

/*
static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;


void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}


*/


int mrk[DIM],g[DIM],fth[DIM],tata[DIM],E[DIM];
vector <int> L[DIM];

int k;


void dfs_euler (int nod, int tata){

    E[++k] = nod;
    fth[nod] = tata;
    for (auto vecin : L[nod])
        if (vecin != tata)
            dfs_euler (vecin,nod);

    //poz[nod].second = k;
}

void assignHints (int subtask, int n, int a[], int b[]){

    int i;
    if (subtask == 1){
        setHintLen(n);

        for (i=1;i<n;i++){
            int x = a[i], y = b[i];
            setHint(x,y,1);
            setHint(y,x,1);
        }
    }

    if (subtask == 2){

        for (i=1;i<=n;i++){
            g[a[i]]++;
            g[b[i]]++;
        }

        setHintLen(20);

        int val = 0;
        for (i=1;i<=n;i++)
            if (g[i] == n-1)
                val = i;

        for (i=1;i<=n;i++){
            if (i != val){
                for (int bit=0;bit<20;bit++){
                    if (val & (1<<bit))
                        setHint(i,bit+1,1);
                }
            }
        }
    }

    if (subtask == 3){

        //vector <int> L[n+1];
        for (i=1;i<n;i++){
            L[a[i]].push_back(b[i]);
            L[b[i]].push_back(a[i]);
        }

        setHintLen(20);

        for (i=1;i<=n;i++){
            int add = 0;
            for (int j=0;j<L[i].size();j++){
                int vecin = L[i][j];
                for (int bit=0;bit<20;bit++)
                    if (vecin & (1<<bit))
                        setHint(i,bit+1+add,1);

                add += 10;
            }
        }

    }

    if (subtask == 4 || subtask == 5){

        //vector <int> L[n+1];
        for (i=1;i<n;i++){
            L[a[i]].push_back(b[i]);
            L[b[i]].push_back(a[i]);
        }

        setHintLen(20);

        dfs_euler (1,0);

        for (i=1;i<=n;i++){

            int nod = E[i];
            int val = fth[nod];
            for (int bit=0;bit<10;bit++)
                if (val & (1<<bit))
                    setHint(nod,bit+1,1);

            val = E[i+1];

            for (int bit=0;bit<10;bit++)
                if (val & (1<<bit))
                    setHint(nod,bit+11,1);

        }

    }

}

void dfs (int nod, int n){
    mrk[nod] = 1;
    for (int i=1;i<=n;i++){
        if (!mrk[i] && getHint(i)){
            goTo(i);
            dfs (i,n);
            goTo(nod);
        }
    }
}

void dfs2 (int nod, int n){

    mrk[nod] = 1;

    int val = 0, val2 = 0;
    for (int bit=1;bit<=10;bit++)
        if (getHint(bit))
            val += (1<<(bit-1));

    for (int bit=11;bit<=20;bit++)
        if (getHint(bit))
            val2 += (1<<(bit-11));

    for (int i=1;i<=n;i++){
        if (mrk[i])
            continue;

        if (i == val || i == val2){
            goTo(i);
            dfs2 (i,n);
            goTo(nod);
        }


    }


}

int get_fth(){

    int sol = 0;
    for (int bit=1;bit<=10;bit++)
        if (getHint(bit))
            sol += (1<<(bit-1));
    return sol;
}

int get_nxt(){

    int sol = 0;
    for (int bit=11;bit<=20;bit++)
        if (getHint(bit))
            sol += (1<<(bit-11));
    return sol;
}

void speedrun (int subtask, int n, int start ){

    int i;
    if (subtask == 1){
        dfs (start,n);
    }
    if (subtask == 2){

        /// start e centrul sau nu
        int val = 0;
        for (i=1;i<=20;i++)
            if (getHint(i))
                val += (1<<(i-1));

        if (!val){ /// e centru

            val = start;
            for (i=1;i<=n;i++){
                if (i == val)
                    continue;

                goTo(i);
                goTo(val);
            }

        } else {

            int aux = start;
            goTo(val);


            for (i=1;i<=n;i++){
                if (i == val || i == aux)
                    continue;
                goTo(i);
                goTo(val);
            }

        }


    }

    if (subtask == 3){

        dfs2 (start,n);

    }

    if (subtask == 4 || subtask == 5){

        /// mai intai ajung in 1
        int nod = start;
        while (nod != 1){

            nod = get_fth ();
            goTo(nod);
        }


        /// sunt in 1

        for (;;){

            int vecin = get_nxt();

            if (!vecin)
                break;

            if (goTo(vecin)){ /// am avut muchie directa
                tata[vecin] = nod;
                nod = vecin;
            } else {

                /// vreau sa ma duc in vecin
                for (;;){

                    goTo(tata[nod]);
                    nod = tata[nod];

                    if (goTo(vecin)){
                        tata[vecin] = nod;
                        nod = vecin;
                        break;
                    }


                }

                //goTo(tata[nod]);
                //nod = tata[nod];

            }


        }


    }

}

/*
int main (){

    ifstream cin ("date.in");
    ofstream cout ("date.out");

    int N, subtask;
    cin >> subtask >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(subtask, N, a, b);

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(subtask, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;



    return 0;
}
*/
