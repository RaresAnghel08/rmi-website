/**
* user:  molnar-2e8
* fname: Bálint
* lname: Molnár
* task:  devil
* score: 0.0
* date:  2019-10-10 08:41:23.966475
*/
#include <bits/stdc++.h>
#define ll long long
#define vi vector<ll>
#define ft(n,i) for(ll i=0;i<n;i++)
#define tft(n,l,i) for(ll i=l;i<n;i++)
#define ftb(n,i) for (ll i=n-1;i>=0;i--)
#define pb push_back
#define mano dp[hely][most][kov][volte][ke]
#define sano su[hely][most][volte][ke]
using namespace std;
const ll md=1e9+7;
int main()
{
    ios::sync_with_stdio(0);
cin.tie(0);

ll n,q; cin>>n>>q; ll tt=0;
string s; cin>>s; vi v(n); ft(n,i) v[i]=(ll) (s[i]-'0'); ft (n,i) tt=10*tt+v[i];

if (n==1)
{
    cout<<v[0]<<endl; return 0;
}


}
