/**
* user:  draganov-16d
* fname: Krastan Asenov
* lname: Draganov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:13:51.442379
*/
#include <iostream>
#include <vector>

#include "speedrun.h"

using namespace std;

const int MAXN = 1e3 + 3;
bool visited[MAXN];

void assignHints(int subtask, int n, int from[], int to[]) {
    setHintLen(n + 1);

    for (int i = 1; i < n; ++i) {
        setHint(from[i], to[i], 1);
        setHint(to[i], from[i], 1);
    }
}

void dfs(int currv, int parent, int n) {
    visited[currv] = true;

    for (int nextv = 1; nextv <= n; ++nextv) {
        if (nextv == currv or nextv == parent) {
            continue;
        }

        if (!getHint(nextv) or visited[nextv]) {
            continue;
        }

        goTo(nextv);
        dfs(nextv, currv, n);
    }

    if (parent != -1) {
        goTo(parent);
    }
}

void speedrun(int subtask, int n, int start) {
    dfs(start, -1, n);
}
