/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Present
* score: 29.0
* date:  2021-12-16 10:14:25.661230
*/
#include <bits/stdc++.h>

#define pb push_back
#define f first
#define s second

using namespace std;

const int N = 30;
bitset<(1 << N)> correct;
int gcd[N + 1][N + 1];

bool comp(pair<pair<int, int>, int> a, pair<pair<int, int>, int> b) {
    return a.f.s < b.f.s;
}

inline int step(int a) {
    if (a == 1) {
        return 0;
    }
    if (a == 2) {
        return 1;
    }
    if (a == 4) {
        return 2;
    }
    if (a == 8) {
        return 3;
    }
    if (a == 16) {
        return 4;
    }
    if (a == 32) {
        return 5;
    }
    if (a == 64) {
        return 6;
    }
    if (a == 128) {
        return 7;
    }
    if (a == 256) {
        return 8;
    }
    if (a == 512) {
        return 9;
    }
    if (a == 1024) {
        return 10;
    }
    if (a == 2048) {
        return 11;
    }
    if (a == 4096) {
        return 12;
    }
    if (a == 8192) {
        return 13;
    }
    if (a == 16384) {
        return 14;
    }
    if (a == 32768) {
        return 15;
    }
    if (a == 65536) {
        return 16;
    }
    if (a == 131072) {
        return 17;
    }
    if (a == 262144) {
        return 18;
    }
    if (a == 524288) {
        return 19;
    }
    if (a == 1048576) {
        return 20;
    }
    if (a == 2097152) {
        return 21;
    }
    if (a == 4194304) {
        return 22;
    }
    if (a == 8388608) {
        return 23;
    }
    if (a == 16777216) {
        return 24;
    }
    if (a == 33554432) {
        return 25;
    }
    if (a == 67108864) {
        return 26;
    }
    if (a == 134217728) {
        return 27;
    }
    if (a == 268435456) {
        return 28;
    }
    if (a == 536870912) {
        return 29;
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    for (int i = 1; i <= N; ++i) {
        for (int j = 1; j <= N; j++)
            gcd[i][j] = __gcd(i, j);
    }
    int t, num, it = 0;
    cin >> t;
    vector<pair<pair<int, int>, int>> vec;
    while (t--) {
        cin >> num;
        num--;
        vec.pb({{num, it}, 0});
        it++;
    }
    sort(vec.begin(), vec.end());
    int need_to_ans = 0;
    if (vec[0].f.f == -1) {
        vec[0].s = 0;
        need_to_ans++;
    }
    correct[0] = 1;
    int number = 0, last, mask1;
    int super_last = 1;
    int need = 1, old = 1;
    for (int mask = 1; mask < (1 << N); mask++) {
        if (need == 0) {
            old *= 2;
            need = old;
            super_last++;
        }
        mask1 = mask ^ (1 << (super_last - 1));
        need--;
        if (!correct[mask1])
            continue;
        bool bl = 1;
        while (mask1 && bl) {
            last = step(mask1 & (-mask1)) + 1;
            if (!(mask & (1 << (gcd[last][super_last] - 1))))
                bl = 0;
            mask1 -= (mask1 & (-mask1));
        }
        correct[mask] = bl;
        if (bl == 1) {
            if (number == vec[need_to_ans].f.f) {
                vec[need_to_ans].s = mask;
                need_to_ans++;
                if (need_to_ans == int(vec.size()))
                    break;
            }
            number++;
        }
    }
    sort(vec.begin(), vec.end(), comp);
    for (auto u: vec) {
        vector<int> ans;
        for (int i = 0; i < N; ++i) {
            if ((1 << i) & u.s) {
                ans.pb(i + 1);
            }
        }
        cout << ans.size() << ' ';
        for (auto v: ans)
            cout << v << ' ';
        cout << endl;
    }
}