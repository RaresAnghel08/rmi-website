/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  restore
* score: 0.0
* date:  2019-10-10 09:28:05.035163
*/
#include <iostream>
#include <vector>

using namespace std;

const int NMAX = 5e3 + 5, MMAX = 1e4 + 5;

struct Query
{
    int Left, Right, K, Val;
};

Query V[MMAX];

int N, M;

int Must_ONE[NMAX], Must_ZERO[NMAX];

vector < int > G[MMAX];
bool Marked[MMAX];
int Left[MMAX], Right[MMAX];

int dp0[NMAX], dp1[NMAX];

static inline void Read ()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> N >> M;

    for(int i = 1; i <= M; ++i)
    {
        cin >> V[i].Left >> V[i].Right >> V[i].K >> V[i].Val;

        ++V[i].Left;
        ++V[i].Right;
    }

    return;
}

static inline void First ()
{
    for(int i = 1; i <= M; ++i)
    {
        int Left = V[i].Left;
        int Right = V[i].Right;
        int K = V[i].K;
        int X = V[i].Val;

        if(K == 1)
        {
            if(X == 1)
                for(int j = Left; j <= Right; ++j)
                    Must_ONE[j] = true;
        }
        else
        {
            if(X == 0)
                for(int j = Left; j <= Right; ++j)
                    Must_ZERO[j] = true;
        }
    }

    return;
}

static inline bool Check1 ()
{
    for(int i = 1; i <= N; ++i)
        if(Must_ONE[i] && Must_ZERO[i])
            return false;

    return true;
}

static inline void Build_dp ()
{
    dp0[0] = dp1[0] = 0;

    for(int i = 1; i <= N; ++i)
    {
        dp0[i] = dp0[i - 1] + Must_ZERO[i];

        dp1[i] = dp1[i - 1] + Must_ONE[i];
    }

    return;
}

static inline void Second ()
{
    for(int i = 1; i <= M; ++i)
    {
        int Left = V[i].Left;
        int Right = V[i].Right;

        int K = V[i].K;
        int X = V[i].Val;

        if(K == 1)
        {
            if(X == 0)
            {
                if(dp0[Right] - dp0[Left - 1])
                    continue;

                for(int j = Left; j <= Right; ++j)
                    if(!Must_ONE[j])
                        G[i].push_back(j);
            }
        }
        else
        {
            if(X == 1)
            {
                if(dp1[Right] - dp1[Left - 1])
                    continue;

                for(int j = Left; j <= Right; ++j)
                    if(!Must_ZERO[j])
                        G[i].push_back(j);
            }
        }
    }

    return;
}

static inline bool Cupleaza (int Node)
{
    Marked[Node] = true;

    for(auto it : G[Node])
        if(!Right[it])
        {
            Left[Node] = it;
            Right[it] = Node;

            return true;
        }

    for(auto it : G[Node])
        if(!Marked[Right[it]] && Cupleaza(Right[it]))
        {
            Left[Node] = it;
            Right[it] = Node;

            return true;
        }

    return false;
}

static inline void Cuplaj ()
{
    bool done = true;

    while(done)
    {
        done = false;

        for(int i = 1; i <= M; ++i)
            Marked[i] = false;

        for(int i = 1; i <= M; ++i)
            if(!Marked[i] && !Left[i])
                done = done | Cupleaza(i);
    }

    return;
}

int main()
{
    cout << -1 << '\n';

    return 0;

    Read();

    First();

    if(!Check1())
    {
        cout << -1 << '\n';

        return 0;
    }

    Build_dp();

    Second();

    Cuplaj();

    int Defecte = 0;

    for(int i = 1; i <= M; ++i)
        if(!G[i].empty())
            ++Defecte;

    int Reparate = 0;

    for(int i = 1; i <= M; ++i)
        if(Left[i])
            ++Reparate;

    if(Defecte != Reparate)
    {
        cout << -1 << '\n';

        return 0;
    }

    for(int i = 1; i <= M; ++i)
        if(Left[i])
        {
            if(V[i].K != 1 && V[i].Val == 1)
                Must_ONE[Left[i]] = true;
        }

    for(int i = 1; i <= N; ++i)
        if(Must_ONE[i])
            cout << 1 << ' ';
        else cout << 0 << ' ';

    cout << '\n';

    return 0;
}
