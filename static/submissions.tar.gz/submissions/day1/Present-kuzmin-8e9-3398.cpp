/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  Present
* score: 29.0
* date:  2021-12-16 11:01:47.538861
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

void solve() {
	int k;
	cin >> k;
	if (k == 0) {
		cout << 0 << endl;
		return;
	}
	int take[40];
	memset(take, 0, sizeof(take));
	vector<int> now;
	vector<vi> gcd(40, vi(40));
	for (int i = 0; i < 40; ++i) {
		for (int j = 0; j < 40; ++j) {
			gcd[i][j] = __gcd(i, j);
		}
	}
	function<int(int)> dfs = [&] (int mx) {
		k--;
		if (k == 0) {
			sort(now.begin(), now.end());
			cout << now.size() << ' ';
			for (auto &i : now)
				cout << i << ' ';
			cout << endl;
			return 1;
		}
		for (int k = 1; k < mx; ++k) {
			if (take[k])
				continue;
			now.pb(k);
			take[k] = 1;
			vi dop;
			for (auto &j : now) {
				int g = gcd[j][k];
				if (take[g] == 0) {
					dop.pb(g);
					take[g] = 1;
				}
			}

			for (auto &i : dop) {
				now.pb(i);
			}
			if (dfs(k))
				return 1;

			for (auto &i : dop) {
				take[i] = 0;
				now.pop_back();
			}
			now.pop_back();
			take[k] = 0;
		}

		return 0;
	};
	for (int i = 1; i <= 500; ++i) {
		now.pb(i);
		take[i] = 1;
		if (dfs(i)) {
			return;
		}
		take[i] = 0;
		now.pop_back();
	}
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t;
	cin >> t;
	while (t--)
		solve();
}