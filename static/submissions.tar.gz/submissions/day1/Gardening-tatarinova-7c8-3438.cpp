/**
* user:  tatarinova-7c8
* fname: Yuliia
* lname: Tatarinova
* task:  Gardening
* score: 18.0
* date:  2021-12-16 11:06:33.269547
*/
#include <bits/stdc++.h>

using namespace std;
long long mas[2000][2000];
int main()
{
    long long t;
    cin>>t;
    for(int step=0; step<t; step++)
    {
        long long n,m,k;
        cin>>n>>m>>k;
        if(n!=m) return 0;

        if(n % 2 == 1 || k == n / 2 +1 || k<n/2 || k>n*n/4 || k == n * n / 4 - 1)
        {
            cout<<"NO\n";
            continue;
        }

        long long l = 0, r = n, p = 1;
        while(l != r)
        {
            if((r - l != 8 || (k != 9 && k!=11)) && (r-l != 6 || k!=6) )
            {
                if(k != (r-l - 2)* (r-l-2) / 4 && k-1 != (r-l-2)/2+1&& k-1 <= (r-l - 2)* (r-l-2) / 4 )
                {

                    for(int i=l; i<r; i++)
                    {
                        mas[i][l]=p;
                        mas[i][r-1]=p;
                        mas[l][i]=p;
                        mas[r-1][i]=p;

                    }
                    p++;
                    l++;
                    r--;
                    k--;
                } else
                {
                    for(int i=l; i<r; i+=2)
                    {
                        mas[i][l]=p;
                        mas[i][l+1]=p;
                        mas[i+1][l]=p;
                        mas[i+1][l+1]=p;
                      k--;
                      p++;
                    }
                     for(int i=l+2; i<r; i+=2)
                    {
                        mas[l][i]=p;
                        mas[l+1][i]=p;
                        mas[l][i+1]=p;
                        mas[l+1][i+1]=p;
                      k--;
                      p++;
                    }
                    l+=2;
                }

            } else if(k==9)
            {
                for(int i=l; i<r; i+=2)
                {
                    mas[l][i]=p;
                    mas[l+1][i]=p;
                    mas[l][i+1]=p;
                    mas[l+1][i+1]=p;
                    p++;
                }
                for(int i=l; i<r; i++)
                {
                    mas[l+2][i]=p;
                    mas[r-1][i]=p;

                }

                for(int i=l+2; i<r; i++)
                {
                    mas[i][l]=p;
                    mas[i][r-1]=p;
                }
                p++;


                    mas[l+3][l+1]=p;
                    mas[l+4][l+1]=p;
                    mas[l+5][l+1]=p+1;
                    mas[l+6][l+1]=p+1;
                    //p+=2;

                     mas[l+3][l+1+1]=p;
                    mas[l+4][l+1+1]=p;
                    mas[l+5][l+1+1]=p+1;
                    mas[l+6][l+1+1]=p+1;
                    p+=2;

                    mas[l+3][l+3]=p;
                    mas[l+3][l+4]=p;
                    mas[l+3][l+5]=p;
                    mas[l+3][l+6]=p;
                    mas[l+4][l+3]=p;
                    mas[l+5][l+3]=p;
                    mas[l+6][l+3]=p;
                    mas[l+6][l+4]=p;
                    mas[l+6][l+5]=p;
                    mas[l+6][l+6]=p;
                    mas[l+5][l+6]=p;
                    mas[l+4][l+6]=p;
                    p++;
                    mas[l+4][l+4]=p;
                    mas[l+4][l+5]=p;
                    mas[l+5][l+4]=p;
                    mas[l+5][l+5]=p;

                 l=r;
            } else if(k==11)
            {
                 for(int i=l; i<r; i+=2)
                {
                    mas[l][i]=p;
                    mas[l+1][i]=p;
                    mas[l][i+1]=p;
                    mas[l+1][i+1]=p;
                    p++;
                }
                for(int i=l; i<r; i++)
                {
                    mas[l+2][i]=p;
                    mas[r-1][i]=p;

                }

                for(int i=l+2; i<r; i++)
                {
                    mas[i][l]=p;
                    mas[i][r-1]=p;
                }
                p++;


                    mas[l+3][l+1]=p;
                    mas[l+4][l+1]=p;
                    mas[l+5][l+1]=p+1;
                    mas[l+6][l+1]=p+1;
                    //p+=2;

                     mas[l+3][l+1+1]=p;
                    mas[l+4][l+1+1]=p;
                    mas[l+5][l+1+1]=p+1;
                    mas[l+6][l+1+1]=p+1;
                    p+=2;

                     mas[l+3][l+3]=p;
                    mas[l+4][l+3]=p;
                    mas[l+5][l+3]=p+1;
                    mas[l+6][l+3]=p+1;
                  //  p+=2;

                     mas[l+3][l+3+1]=p;
                    mas[l+4][l+3+1]=p;
                    mas[l+5][l+3+1]=p+1;
                    mas[l+6][l+3+1]=p+1;
                    p+=2;

                     mas[l+3][l+5]=p;
                    mas[l+4][l+5]=p;
                    mas[l+5][l+5]=p+1;
                    mas[l+6][l+5]=p+1;
                    //p+=2;

                     mas[l+3][l+5+1]=p;
                    mas[l+4][l+5+1]=p;
                    mas[l+5][l+5+1]=p+1;
                    mas[l+6][l+5+1]=p+1;

                 l=r;
            } else if(k==6)
            {
                 for(int i=l; i<r; i+=2)
                {
                    mas[l][i]=p;
                    mas[l+1][i]=p;
                    mas[l][i+1]=p;
                    mas[l+1][i+1]=p;
                    p++;
                }
                for(int i=l; i<r; i++)
                {
                    mas[l+2][i]=p;
                    mas[r-1][i]=p;

                }

                for(int i=l+2; i<r; i++)
                {
                    mas[i][l]=p;
                    mas[i][r-1]=p;
                }
                p++;


                    mas[l+3][l+1]=p;
                    mas[l+4][l+1]=p;

                    //p+=2;

                     mas[l+3][l+1+1]=p;
                    mas[l+4][l+1+1]=p;

                    p++;

                     mas[l+3][l+3]=p;
                    mas[l+4][l+3]=p;

                  //  p+=2;

                     mas[l+3][l+3+1]=p;
                    mas[l+4][l+3+1]=p;

                    l=r;
            }


        }

        cout<<"YES\n";
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                cout<<mas[i][j]<<' ';
            }
            cout<<'\n';
        }
    }
    return 0;
}
