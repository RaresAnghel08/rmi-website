/**
* user:  mihov-11b
* fname: Rumen
* lname: Mihov
* task:  Present
* score: 0.0
* date:  2021-12-16 11:35:04.293787
*/
# include <bits/stdc++.h>
using namespace std;
const int maxn = 1e8;
const int K = 20;
short dp[maxn];
int  from[maxn];
int sz;
vector <int> a;
int vis[maxn],ids = 1;
int mask[maxn];
bool have[80];
short G[100][100];
vector <int> cases[32];
int ans;
vector <pair <int,int> > query;
void solve(int v, int k)
{
    if(k==-1)return ;
     a.push_back(G[v][dp[k]]);
     solve(v,from[k]);
}
bool checked(int v, int k)
{
    solve(v,k);
   sort(a.begin(),a.end());
   int idx = a.size()-1;
//cout<<v<<" "<<k<<" && "<<endl;
  // for(int i = 0;i<a.size();i++ )cout<<a[i]<<" ";
  // cout<<endl;
   int pos = k;
   while(pos!=-1)
   {
       while(idx>=0&&a[idx]==dp[pos])idx--;
       if(idx>=0&&a[idx]>dp[pos])return false;
       pos = from[pos];
   }

   return idx<0;

}
int last;
vector <int> l;
int backtrack(int pos)
{
    int i,t,q,k;
   // cout<<"backtrack: ";
   // for(i = 0;i<l.size();i++)
   //     cout<<l[i]<<" ";
   // cout<<endl;
    if(l.size()==1){
    sz++;
    if(sz==pos)return -1;}
    bool fl;    ids++;
    for(int j = 0;j<=last;j++)
    {
         if(from[j]!=-1&&vis[from[j]]!=ids)continue;
           fl = true;
         for(q = 0; q<l.size();q++)
         {
             k = G[dp[j]][l[q]];
              if(!((mask[j]&(1<<k))))fl= false;
         }
       if(fl)
       {
          vis[j] = ids;
       }
         for(t = 0;t<l.size()-1;t++)
            for(q = t+1; q<l.size();q++)
         {
            k = G[l[t]][l[q]];
           // cout<<j<<" "<<k<<" "<<(mask[j]&(1<<k))<<endl;
            if(!((mask[j]&(1<<k))))fl=false;
         }

         if(fl)
         {
             sz++;
             vis[j] = ids;
            // cout<<sz<<" "<<j<<" "<<dp[j]<<endl;
             if(sz==pos)return j;
            }
}
return -2;
}
void nextt()
{
    int i;
    for(i = dp[last]+1;;i++)
    {
        if(!have[i]){

            l.push_back(i);
        while(i<75){
                if(have[i])l.push_back(i);
        i++;}
        return ;
        }
        else
            have[i] = 0;
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;

    dp[0] = 1;
    from[0] = -1;
    mask[0] = 2;
    int i;
    sz = 0;
    int j;
    for(i = 1;i<=99;i++)
        for(j=1;j<=99;j++)
        G[i][j]=__gcd(i,j);
    for(i = 2;i<=32;i++)
    {


        sz++;
        dp[sz] = i;
        from[sz] = -1;
        mask[sz] = (1<<i);
        ids++;
     // cout<<sz<<" :: "<<dp[sz]<<" "<<from[sz]<<endl;
        int l = sz;
        for(j = 0;j<l;j++)
        {
     //a.clear();
          //  if(checked(i,j))
          if(from[j]!=-1&&vis[from[j]]!=ids)continue;
          int k = G[dp[j]][i];
            if(mask[j]&(1<<k))
            {



                sz++;
                dp[sz] = i;
                from[sz] = j;
                vis[j] = ids;
                mask[sz] = (mask[j]|(1<<i));
         //  cout<<sz<<" :: "<<dp[sz]<<" "<<from[sz]<<endl;
            }
        }
    }
    last = sz;
   // cout<<last<<" "<<dp[last]<<endl;
    int q;
        cin>>N;
    query.resize(N);
    for(i=0;i<N;i++)
    {
     //   cin>>query[i].first;
        query[i].second = i;
    }
   // sort(query.begin(),query.end());
    for(i=  0;i<N;i++)
    {
         a.clear();
         cin>>q;
         //q=  query[i].first;
         if(q==0)
         {
             cout<<0<<endl;continue;
         }
         q--;
         if(q<=last){
         while(q!=-1)
         {
             a.push_back(dp[q]);
             q = from[q];
         }
         cout<<a.size()<<" ";
            for(int j = a.size()-1;j>=0;j--)cout<<a[j]<<" ";
            cout<<endl;
            continue;
         }
         else
         {
             sz = last;
             l.clear();
             while(1)
             {
                 for(j = 0;j<l.size();j++)
                 {
                    have[l[j]] = 1;

            }
            l.clear();
                     nextt();

                     int k = backtrack(q);
                     if(k!=-2)
                     {
                         a.clear();
                         for(j = 0;j<l.size();j++)a.push_back(l[j]);
                         while(k!=-1)
                         {
                             a.push_back(dp[k]);
                             k = from[k];
                         }

                     sort(a.begin(),a.end());
                     cout<<a.size()<<" ";
                     for(j = 0;j<a.size();j++)
                        cout<<a[j]<<" ";
                     cout<<endl;
                     break;}
             }
         }

    }

    return 0;
}
