/**
* user:  koynov-034
* fname: Daniel
* lname: Koynov
* task:  restore
* score: 20.0
* date:  2019-10-10 06:43:18.504814
*/
#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N_max = 5010;

int a[N_max], n, m;
bool used[N_max];
bool update(int l, int r)
{
    int i;
    for (i = l; i <= r; i ++)
        a[i] = 1;
}

struct seg
{
    int l, r;
};
vector < seg > v;

struct segment
{
    int l, r, k, val;
};
vector < segment > s;
int p[N_max];
bool is;
void check()
{
    int i, sz = s.size(), j;

    for (i = 0; i < sz; i ++)
    {
        int zero = 0;
        for (j = s[i].l; j <= s[i].r; j ++)
            if (p[j] == 0)
                zero ++;
        if (s[i].val == 0)
        {
            if (zero < s[i].k)
                return;
        }
        else
        {
            if (s[i].k <= zero)
                return;
        }
    }
    is = 1;
    for (i = 0; i < n; i ++)
        cout << p[i] << " ";
    cout << endl;

}

void gen(int pos)
{
    if (is == 0)
    {
        if (pos == n)
            check();
        else
        {
            p[pos] = 1;
            gen(pos + 1);
            p[pos] = 0;
            gen(pos + 1);
        }
    }
}
int main()
{
    ios_base::sync_with_stdio();
    cin.tie();
    cout.tie();

    cin >> n >> m;
    if (n > 18)
    {
        int i, l, r, k, val;
        for (i = 0; i < m; i ++)
        {
            cin >> l >> r >> k >> val;
            if (val == 0)
                v.push_back({l, r});
            else
                update(l, r);
        }

        int j;
        for (i = 0; i < v.size(); i ++)
        {
            bool p = 0;
            for (j = v[i].l; j <= v[i].r; j ++)
                if (a[j] == 0)
                    p = 1;
            if (p == 0)
            {
                cout << "-1" << endl;
                return 0;
            }
        }
        for (i = 0; i < n - 1; i ++)
            cout << a[i] << " ";
        cout << a[n - 1] << endl;
    }
    else
    {
        int i, fr, to, d, v;
        for (i = 0; i < m; i ++)
        {
            cin >> fr >> to >> d >> v;
            s.push_back({fr, to, d, v});
        }
        /**cout << "----------------" << endl;
        for (i = 0; i < s.size(); i ++)
            cout << s[i].l << " " << s[i].r << " " << s[i].k << " " << s[i].val << endl;*/
        gen(0);
        if (is == 0)
            cout << "-1" << endl;
    }
    return 0;
}
