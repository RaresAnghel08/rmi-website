/**
* user:  chiriac-c10
* fname: Matei
* lname: Chiriac
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 11:27:09.854288
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;

vector<int> v[1005];

int readInt(int st, int dr)
{
    int ans=0;
    for(int b=st;b<=dr;b++)
        ans += (1<<(b-st))*getHint(b);

    return ans;
}

void assignHints(int sub, int n, int a[], int b[])
{
    for(int i=1;i<=n-1;i++)
    {
        v[a[i]].push_back(b[i]);
        v[b[i]].push_back(a[i]);

        cout<<a[i]<<' '<<b[i]<<'\n';
    }

    if(sub == 1)
    {
        setHintLen(n);

        for(int i=1;i<=n;i++)
            for(int it : v[i])
                setHint(i, it, 1);
    }
    if(sub == 2)
    {
        setHintLen(20);

        int rad=0;
        for(int i=1;i<=n;i++)
        {
            if(v[i].size() > v[rad].size())
                rad=i;
        }

        for(int i=1;i<=n;i++)
        {
            for(int b=0;b<20;b++)
                setHint(i, b+1, ((rad>>b)&1));
        }
    }
    if(sub == 3)
    {

    }
}

void dfs(int p, int par, int n)
{
    for(int i=1;i<=n;i++)
    {
        if(i==p || i==par)
            continue;

        if(getHint(i))
        {
            goTo(i);
            dfs(i, p, n);
        }
    }

    if(par)
        goTo(par);
}

void speedrun(int sub, int n, int start)
{
    if(sub == 1)
    {
        dfs(start, 0, n);
    }
    if(sub == 2)
    {
        int rad = readInt(1, 20);

        if(start != rad)
            goTo(rad);

        for(int i=1;i<=n;i++)
        {
            if(i != rad)
            {
                goTo(i);
                goTo(rad);
            }
        }
    }
}
