/**
* user:  slanina-c40
* fname: Iulia
* lname: Slanina
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:14:19.338210
*/
#include <bits/stdc++.h>

using namespace std;
void no()
{
    cout << "NO" << '\n';
}
void yes()
{
    cout << "YES" << '\n';
}
int a[10][200005];
int b[200005][10];

void solve()
{
    int n, m, k, p = 0;
    cin >> n >> m >> k;
    if (n > m)
    {
        swap(n, m);
        p = 1;
    }
    if (n == 1 || n == 3)
    {
        no();
        return;
    }
    if (n == 2)
    {
        if (m % 2 || (m % 2 == 0 && k != m / 2))
        {
            no();
            return;
        }
        yes();
        for (int i = 1; i <= m; i += 2)
            a[1][i] = a[1][i + 1] = a[2][i] = a[2][i + 1] = (i + 1) / 2;
        if (p)
        {
            for (int j = 1; j <= m; j++)
            {
                for (int i = 1; i <= n; i++)
                    cout << a[j][i] << " ";
                cout << '\n';
            }
        }
        else
        {
            for (int j = 1; j <= n; j++)
            {
                for (int i = 1; i <= m; i++)
                    cout << a[j][i] << " ";
                cout << '\n';
            }
        }
        return;
    }
    if (n == 4)
    {
        if (m % 2)
            no();
        int col = 0, c = 0, minit = m;
        while (m)
        {
            if (m > 2 && col + (m - 2) / 2 + 1 == k)
            {
                col++;
                for (int i = c + 1; i <= minit; i++)
                    a[1][i] = a[4][i] = col;
                a[2][c + 1] = a[3][c + 1] = a[2][minit] = a[3][minit] = col;

                for (int i = c + 2; i < minit; i += 2)
                    a[2][i] = a[3][i] = a[2][i + 1] = a[3][i + 1] = ++col;
                m = 0;
            }
            else
            {
                a[1][c + 1] = a[2][c + 1] = a[1][c + 2] = a[2][c + 2] = ++col;
                a[3][c + 1] = a[4][c + 1] = a[3][c + 2] = a[4][c + 2] = ++col;
                c += 2;
                m -= 2;
            }
        }
        if (col != k)
            no();
        else
        {
            yes();
            if (p)
            {
                for (int j = 1; j <= minit; j++)
                {
                    for (int i = 1; i <= n; i++)
                        cout << a[j][i] << " ";
                    cout << '\n';
                }
            }
            else
            {
                for (int j = 1; j <= n; j++)
                {
                    for (int i = 1; i <= minit; i++)
                        cout << a[j][i] << " ";
                    cout << '\n';
                }
            }
        }
    }
}
int main()
{
    int t;
    cin >> t;
    while(t--)
        solve();
    return 0;
}
