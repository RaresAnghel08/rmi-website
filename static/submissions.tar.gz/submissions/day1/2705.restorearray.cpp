/**
* user:  smilenov-5e5
* fname: Ivan
* lname: Smilenov
* task:  restore
* score: 0.0
* date:  2019-10-10 09:49:48.732647
*/
#include<bits/stdc++.h>
using namespace std;
vector<pair<int,int> >v,v1;
int a,m;
int ans[8192];
int used[8192*4],mt[8192*4];
vector<int>g[8192*4];
bool try_kuhn(int x,int p=-1)
{
    used[x]=true;
    int i,nb,sz=g[x].size();
    for(i=0;i<sz;i++)
    {
        nb=g[x][i];
        if(!used[nb]&&(mt[nb]==-1||try_kuhn(nb,x)))
        {
            mt[nb]=x;
            return true;
        }
    }
    return false;
}
int main()
{
    cin>>a>>m;
    int x,y,k,t,i,j,cnt;
    for(i=0;i<m;i++)
    {
        //cout<<i<<endl;
        cin>>x>>y>>k>>t;
        if(k==1)
        {
            if(t==1)
            {
                for(j=x;j<=y;j++)
                {
                    ans[j]=1;
                    used[j]=1;
                }
            }
            else
            {
                v.push_back({x,y});
            }
        }
        else
        {
            if(t==0)
            {
                for(j=x;j<=y;j++)
                {
                    ans[j]=0;
                    used[j]=1;
                }
            }
            else
            {
                v1.push_back({x,y});
            }
        }
    }
    for(i=0;i<v.size();i++)
    {
        for(j=v[i].first;j<=v[i].second;j++)
        {
            if(!used[j])
            {
                g[m+i+1].push_back(j);
                g[j].push_back(m+i+1);
            }
        }
    }
    for(i=0;i<v1.size();i++)
    {
        for(j=v1[i].first;j<=v1[i].second;j++)
        {
            if(!used[j])
            {
                g[m+v.size()+i+1].push_back(j);
                g[j].push_back(m+v.size()+i+1);
            }
        }
    }
    memset(mt,-1,sizeof(mt));
    for(i=0;i<m;i++)
    {
        memset(used,0,sizeof(used));
        try_kuhn(i);
    }
    for(i=m+1;i<=m+v.size()+v1.size();i++)
    {
        //cout<<i<<" "<<mt[i]<<endl;
        if(mt[i]==-1)
        {
            cout<<-1<<endl;
            return 0;
        }
        else
        {
            if(i<=m+v.size())
                ans[mt[i]]=0;
            else ans[mt[i]]=1;
        }
    }
    for(i=0;i<a;i++)cout<<ans[i]<<" ";cout<<endl;
    return 0;
}
