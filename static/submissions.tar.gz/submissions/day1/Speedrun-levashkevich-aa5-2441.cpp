/**
* user:  levashkevich-aa5
* fname: Stanislau
* lname: Levashkevich
* task:  Speedrun
* score: 27.0
* date:  2021-12-16 09:33:22.504184
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    vector<vector<int>> have(N + 1,vector<int> (N + 1));
    for(int i = 1;i <= N - 1; ++i) {
        have[A[i]][B[i]] = 1;
        have[B[i]][A[i]] = 1;
    }
    if(subtask == 1) {
        setHintLen(N);
        for(int i = 1;i <= N; ++i) {
            for(int j = 1;j <= N; ++j) {
                setHint(i,j,have[i][j]);
            }
        }
        return;
    }
    if(subtask == 2) {
        setHintLen(20);
        int best = 0,id = 1;
        for(int i = 1;i <= N; ++i) {
            int cnt = 0;
            for(int j = 1;j <= N; ++j) {
                cnt += have[i][j];
            }
            if(cnt > best) {
                best = cnt;
                id = i;
            }
        }
        for(int i = 1;i <= N; ++i) {
            for(int j = 0;j < 20; ++j) {
                if(id & (1 << j)) {
                    setHint(i,j + 1,1);
                } else {
                    setHint(i,j + 1,0);
                }
            }
        }
        return;
    }
    if(subtask == 3) {
        setHintLen(20);
        for(int i = 1;i <= N; ++i) {
            int f = 0,s = 0;
            for(int j = 1;j <= N; ++j) {
                if(have[i][j]) {
                    if(f == 0) f = j;
                    else s = j;
                }
            }
            for(int j = 0;j < 10; ++j) {
                if(f & (1 << j)) {
                    setHint(i,j + 1,1);
                } else {
                    setHint(i,j + 1,0);
                }
            }
            for(int j = 0;j < 10; ++j) {
                if(s & (1 << j)) {
                    setHint(i,j + 1 + 10,1);
                } else {
                    setHint(i,j + 1 + 10,0);
                }
            }
        }
        return;
    }
}

bool was[1007];

void dfs1(int v,int p,int N) {
    was[v] = 1;
    for(int i = 1;i <= N; ++i) {
        if(!was[i]) {
            bool b = getHint(i);
            if(b) {
                goTo(i);
                dfs1(i,v,N);
            }
        }
    }
    if(p != -1) {
        goTo(p);
    }
}

void dfs3(int v,int p,int N) {
    vector<int> can(21);
    for(int i = 1;i <= 20; ++i) {
        can[i] = getHint(i);
    }
    int f = 0,s = 0;
    for(int i = 1;i <= 10; ++i) {
        if(can[i]) {
            f += (1 << (i - 1));
        }
    }
    for(int i = 11;i <= 20; ++i) {
        if(can[i]) {
            s += (1 << (i - 11));
        }
    }
    if(f != 0 && f != p) {
        goTo(f);
        dfs3(f,v,N);
    }
    if(s != 0 && s != p) {
        goTo(s);
        dfs3(s,v,N);
    }
    if(p != -1) {
        goTo(p);
    }
}

void speedrun(int subtask, int N, int start) { /* your solution here */
    int l = getLength();
    if(subtask == 1) {
        dfs1(start,-1,N);
        return;
    }
    if(subtask == 2) {
        vector<bool> ch(l);
        for(int i = 1;i <= l; ++i) {
            ch[i - 1] = getHint(i);
        }
        int kor = 0;
        for(int i = 0;i < l; ++i) {
            if(ch[i]) {
                kor += (1 << i);
            }
        }
        if(start == kor) {
            for(int i = 1;i <= N; ++i) {
                if(kor == i) {
                    continue;
                }
                goTo(i);
                goTo(kor);
            }
            return;
        }
        if(start != kor) {
            goTo(kor);
            for(int i = 1;i <= N; ++i) {
                if(kor == i || start == i) {
                    continue;
                }
                goTo(i);
                goTo(kor);
            }
            return;
        }
    }
    if(subtask == 3) {
        dfs3(start,-1,N);
        return;
    }
}

