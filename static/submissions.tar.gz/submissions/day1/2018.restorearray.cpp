/**
* user:  savulescu-3de
* fname: Ștefan
* lname: Săvulescu
* task:  restore
* score: 0.0
* date:  2019-10-10 08:21:03.657019
*/
#include <cstdio>
#include <algorithm>
using namespace std;
int n,m,i,x,y,j,q,nr,h,s,b[5004],l[10004],r[10004],k[10004],va[10004],a[10004],nrs[10004],ai[10004];
bool ok,v[10004];
void up (int poz, int val)
{
    int i;
    for (i=poz; i<=n; i+=(i&(-i)))
    {
        nrs[i]++;
        ai[i]+=val;
    }
    return;
}
int qu (int poz)
{
    int i;
    int s=0;
    for (i=poz;i>=1;i-=(i&(-i)))
        s+=nrs[i];
    return s;
}
int qu2 (int poz)
{
    int i;
    int s=0;
    for (i=poz;i>=1;i-=(i&(-i)))
        s+=ai[i];
    return s;
}
int main()
{
    scanf ("%d %d", &n, &m);
    for (i=1; i<=m; i++)
        scanf ("%d %d %d %d", &l[i], &r[i], &k[i], &va[i]);
    if (n<=8)
    {
        for (i=0; i<(1<<n); i++)
        {
            x=i;
            for (j=0; j<n; j++)
            {
                a[j]=x%2;
                x/=2;
            }
            ok=true;
            for (j=1; j<=m; j++)
            {
                nr=0;
                for (h=l[j]; h<=r[j]; h++)
                    b[++nr]=a[h];
                sort (b+1,b+nr+1);
                if (b[k[j]]!=va[j])
                {
                    ok=false;
                    break;
                }
            }
            if (ok==true)
                break;
        }
        if (ok==true)
        {
            for (i=0; i<=(n-1); i++)
                printf ("%d ", a[i]);
            printf ("\n");
        }
        else
            printf ("%d\n", -1);
    }
    else
    {
        for (j=1; j<=n; j++)
            a[j]=-1;
        ok=true;
        for (j=1; j<=m; j++)
        {
            v[j]=true;
            if ((k[j]==1) && (va[j]==1))
            {
                for (h=l[j]; h<=r[j]; h++)
                {
                    up(h,1);
                    if (a[h]==0)
                    {
                        ok=false;
                        break;
                    }
                    a[h]=1;
                }
                v[j]=false;
            }
            else if ((k[j]==(r[j]-l[j]+1)) && (va[j]==0))
            {
                for (h=l[j]; h<=r[j]; h++)
                {
                    up(h,0);
                    if (a[h]==1)
                    {
                        ok=false;
                        break;
                    }
                    a[h]=0;
                }
                v[j]=false;
            }
            if (ok==false)
                break;
        }
        if (ok==false)
            printf ("%d\n", -1);
        else
        {
            ok=true;
            while (ok==true)
            {
                ok=false;
                for (i=1; i<=m; i++)
                {
                    if ((k[i]==1) && (va[i]==0) && (v[i]==true))
                    {
                        x=qu(r[i])-qu(l[i]-1);
                        y=qu2(r[i])-qu2(l[i]-1);
                        if (x!=y)
                        {
                            ok=true;
                            v[i]=false;
                        }
                        else if (x==(r[i]-l[i]))
                        {
                            for (q=l[i];q<=r[i];q++)
                            {
                                if (a[q]==-1)
                                {
                                    a[q]=0;
                                    up(q,0);
                                    break;
                                }
                            }
                            ok=true;
                            v[i]=false;
                        }
                    }
                    else if ((k[i]==(r[i]-l[i]+1)) && (va[i]==1) && (v[i]==true))
                    {
                        x=qu(r[i])-qu(l[i]-1);
                        y=qu2(r[i])-qu2(l[i]-1);
                        if (y==1)
                        {
                            ok=true;
                            v[i]=false;
                        }
                        else if (x==(r[i]-l[i]))
                        {
                            for (q=l[i];q<=r[i];q++)
                            {
                                if (a[q]==-1)
                                {
                                    a[q]=1;
                                    up(q,1);
                                    break;
                                }
                            }
                            ok=true;
                            v[i]=false;
                        }
                    }
                }
            }
            s=1;
            for (i=1;i<=n;i++)
            {
                if (a[i]==-1)
                {
                    a[i]=s;
                    s=(s+1)%2;
                }
            }
            ok=true;
            for (i=1;i<=m;i++)
            {
                x=qu2(r[i])-qu2(l[i]-1);
                y=r[i]-l[i]+1;
                if ((k[i]==1) && (va[i]==0) && (x==y))
                {
                    ok=false;
                    break;
                }
                else if ((k[i]==1) && (va[i]==1) && (x!=y))
                {
                    ok=false;
                    break;
                }
                else if ((k[i]==y) && (va[i]==0) && (x!=0))
                {
                    ok=false;
                    break;
                }
                else if ((k[i]==y) && (va[i]==1) && (x==0))
                {
                    ok=false;
                    break;
                }
            }
            if (ok==true)
            {
                for (i=1;i<=n;i++)
                    printf ("%d ", a[i]);
                printf ("\n");
            }
            else
                printf ("%d\n", -1);
        }
    }
    return 0;
}
