/**
* user:  taga-9e5
* fname: Ștefan
* lname: Țaga
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 08:48:25.056601
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;
int gr[1005];
void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(20);
    int i,poz,j,k;
    for (int i=1;i<N;i++)
    {
        gr[A[i]]++;
        gr[B[i]]++;
    }
    for (i=1;i<=N;i++)
    {
        if (gr[i]==N-1)
        {
            poz=i;
            break;
        }
    }
    for (j=1;j<=N;j++)
    {
        if (j!=poz)
        {
            for (k=1;k<=20;k++)
            {
                if (poz&(1<<(k-1)))
                {
                    setHint(j,k,1);
                }
            }
        }
    }
}
void dfs(int x,int n,int tata)
{
    for (int i=1;i<=n;i++)
    {
        if (i!=tata&&getHint(i)==1)
        {
            goTo(i);
            dfs(i,n,x);
            goTo(x);
        }
    }
}
void speedrun(int subtask, int N, int start) {
    int ceau=getLength();
    int sum=0,i,n=N;
    for (int t=1;t<=ceau;t++)
    {
        if (getHint(t)==1)
        {
            sum=sum+(1<<(t-1));
        }
    }
    int rad;
    if (sum==0)
    {
        rad=start;
    }
    else
    {
        rad=sum;
    }
    if (start!=rad)
    {
        goTo(rad);
    }
        for (i=1;i<=n;i++)
        {
            if (i!=rad)
            {
                goTo(i);
                goTo(rad);
            }
        }

}

/* Input format:
 *
 * N -- number of nodes
 * a1 b1 -- edge 1
 * ...
 * a(N-1) b(N-1) -- edge N - 1
 * x -- start node
 */
#ifdef HOME
static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;

void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}

int main() {
    int N;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(1, N, a, b);

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(1, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;
    return 0;
}
#endif // HOME
