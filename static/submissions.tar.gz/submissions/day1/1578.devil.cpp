/**
* user:  bashev-75b
* fname: Dobrin
* lname: Bashev
* task:  devil
* score: 0.0
* date:  2019-10-10 07:10:03.875832
*/
#include <iostream>
#include <vector>
using namespace std;

int a[10], b[10], s, k;

string solve1()
{
    string ans = "";
    ans.resize(s);
    for (int i = 0; i < ans.size(); ++ i)
    {
        ans[i] = ' ';
    }


    int x = 9;
    while (true)
    {
        if (a[x] != 0)
        {
            ans[s - 1] = x + '0';
            a[x]--;
            break;
        }
        else x--;
    }

    int m = 1, g = 9;
    for (int i = 0; i < s - 1; ++ i)
    {
        while (a[m] == 0 and m < 10) m++;
        while (a[g] == 0 and g > 0) g--;

        //cout << m << ' ' << g << endl;

        if (i % 2 == 0) {ans[i] = m + '0'; a[m]--;}
        else {ans[i] = g + '0'; a[g]--;}
    }

    //cout << ans  << endl;
    return ans;
}

string solve2()
{
    string ans = "";
    ans.resize(s);
    for (int i = 0; i < ans.size(); ++ i)
    {
        ans[i] = ' ';
    }

    int x = 9;
    while (true)
    {
        if (b[x] != 0)
        {
            ans[s - 1] = x + '0';
            b[x]--;
            break;
        }
        else x--;
    }

    int m = 1, g = 9;
    for (int i = 0; i < s - 1; ++ i)
    {
        while (b[m] == 0 and m < 10) m++;
        while (b[g] == 0 and g > 0) g--;

       // cout << m << ' ' << g << endl;

        if (i % 2 == 1) {ans[i] = m + '0'; b[m]--;}
        else {ans[i] = g + '0'; b[g]--;}
    }

    //cout << ans << endl;

    return ans;
}

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int t;
    cin >> t;

    while (t--)
    {
        cin >> k;
        s = 0;
        for (int i = 1; i <= 9; ++ i)
        {
            cin >> a[i];
            s += a[i];
            b[i] = a[i];
        }

        string ans1 = "", ans2 = "";
        ans1 = solve1();
        ans2 = solve2();

        int x = 0, y = 0;
        for (int i = 0; i < s - 1; ++ i)
        {
            x = max(x, (int)(ans1[i] - '0') * 10 + (int)(ans1[i + 1] - '0'));
        }
        for (int i = 0; i < s - 1; ++ i)
        {
            y = max(y, (int)(ans2[i] - '0') * 10 + (int)(ans2[i + 1] - '0'));
        }


        if (x < y) cout << ans1 << endl;
        else cout << ans2 << endl;
    }

    return 0;
}

