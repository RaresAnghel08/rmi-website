/**
* user:  babin-880
* fname: Aleksandr
* lname: Babin
* task:  Present
* score: 29.0
* date:  2021-12-16 07:32:12.399682
*/
#include <bits/stdc++.h>

using namespace std;

const int N = 50;

vector<int> s;

int cnt = 0, total;
int score[N+1];

bool build(int t) {
    if (t == 0) {
        if (cnt == total) {
            cout << s.size();
            for (int i = s.size(); i--; ) cout << ' ' << s[i];
            cout << endl;
            return true;
        }
        ++cnt;
    } else {
        if (score[t] == 0) if(build(t-1)) return true;

        for (int x : s) score[__gcd(x, t)]++;
        s.push_back(t);
        if(build(t-1)) return true;
        s.pop_back();
        for (int x : s) score[__gcd(x, t)]--;
    }

    return false;
}

int main() {
    int t; cin >> t;
    while (t--) {
        cin >> total;
        cnt = 0;
        s.clear();
        fill(score, score+N+1, 0);
        build(N);
    }
}