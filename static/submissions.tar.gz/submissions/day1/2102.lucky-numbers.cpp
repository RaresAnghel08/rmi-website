/**
* user:  nezmah-c8c
* fname: Krešimir
* lname: Nežmah
* task:  lucky
* score: 28.0
* date:  2019-10-10 08:31:11.622412
*/
#include<bits/stdc++.h>

using namespace std;

typedef long long llint;

const int MAXN = 100005;
const int MOD = 1000000007;

int n, q;
string s;
int dp[MAXN][2][2];

int add (int x, int y) {
	x += y;
	if (x >= MOD) return x - MOD; return x;
}

int calc (int pos, int tip, int last) {
	if (dp[pos][tip][last] != -1) return dp[pos][tip][last];
	if (pos == n) return 1;
	int res = 0;
	if (tip == 0) {
		for (int i=0; i<10; i++) {
			if (last && i == 3) continue;
			res = add(res, calc(pos + 1, 0, i == 1));
		}
	} else {
		int lim = s[pos] - '0';
		for (int i=0; i<lim; i++) {
			if (last && i == 3) continue;
			res = add(res, calc(pos + 1, 0, i == 1));
		}
		if (!(last && lim == 3)) res = add(res, calc(pos + 1, 1, lim == 1));
	}
	return dp[pos][tip][last] = res;
}

int main () {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cin >> n >> q >> s;
	memset(dp, -1, sizeof dp);
	cout << calc(0, 1, 0) << endl;
	for (int i=0; i<q; i++) {
	}
	return 0;
}

