/**
* user:  lupov-261
* fname: Ivan Stiliyanov
* lname: Lupov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:38:22.277301
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>

#define de(x) cout << #x << " = " << x << endl;
#define pb push_back
#define fr first
#define sc second
#define bit(x) x&(-x)
#define ll long long
#define ld long double

using namespace __gnu_pbds;
using namespace std;

template<class T> using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<class T> using matrix = vector<vector<T>>;

void s(){
	int n, m, k, T = 1; cin >> n >> m >> k;
	if(n % 2 == 1 || m % 2 == 1){ cout << "NO\n"; return; }
	if(n == 2 && m == 2){
		if(k == 1){
			cout << "YES\n";
			cout << "1 1\n1 1\n";
		}
		else{
			cout << "NO\n";
		}
		return;
	}
	if((n == 2 || m == 2) && k == 1){ cout << "NO\n"; return; }
	
	int a = 4;
	int b = 2 * (2 - n - m);
	int c = (n * m - 4 * k);
	int D = b * b - 4 * a * c;
	if(D < 0 || (-b + (int)sqrt(D)) % (2 * a) != 0 || (-b - (int)sqrt(D)) % (2 * a) || sqrt(D) != (int)sqrt(D)){ cout << "NO\n"; return; } 
	
	int x1 = (-b + sqrt(D)) / (2 * a);
	int x2 = (-b - sqrt(D)) / (2 * a);
	
	int x = -1;
	if(x1 < 0 && x2 >= 0) x = x2;
	else if(x2 < 0 && x1 >= 0) x = x1;
	else x = min(x1, x2);
	
	if(x < 0){ cout << "NO\n"; return; }
	
	matrix<int> ans(n + 5, vector<int>(m + 5));
	
	for(int I = 0; I < x; I ++){
		int i = I, j = I, stage = 0;
		while(ans[i][j] == 0){
			ans[i][j] = T;
			if((i == T - 1 && j == m - T) || (i == n - T && j == m - T) || (i == n - T && j == T - 1)) ++ stage;
			if(stage == 0) ++ j;
			if(stage == 1) ++ i;
			if(stage == 2) -- j;
			if(stage == 3) -- i;
		}
		++ T;
	}
	for(int i = 0; i < n; i ++){
		for(int j = 0; j < m; j ++){
			if(ans[i][j] == 0){
				if((i + 1 < n && ans[i + 1][j] == 0) && (j + 1 < m && ans[i][j + 1] == 0) && (i + 1 < n && j + 1 < m && ans[i + 1][j + 1] == 0)){
					ans[i][j] = ans[i + 1][j] = ans[i][j + 1] = ans[i + 1][j + 1] = T;
					++ T;
				}
				else{ cout << "NO\n"; return; }
			}
		}
	}
	for(int i = 0; i < n; i ++){
		for(int j = 0; j < m; j ++){
			cout << ans[i][j] << " ";
		}
		cout << endl;
	}
}

void s1(){
	int n, m, k; cin >> n >> m >> k;
	if(n == 2 && m == 2){
		if(k == 1){
			cout << "YES\n1 1\n1 1\n";
			return;
		}
	}
	if(n == 2 && m == 4){
		if(k == 2){
			cout << "YES\n";
			cout << "1 1 2 2\n";
			cout << "1 1 2 2\n";
			return;
		}
	}
	if(n == 4 && m == 2){
		if(k == 2){
			cout << "YES\n";
			cout << "1 1\n";
			cout << "1 1\n";
			cout << "2 2\n";
			cout << "2 2\n";
			return;
		}
	}
	if(n == 4 && m == 4){
		if(k == 2){
			cout << "YES\n";
			cout << "1 1 1 1\n";
			cout << "1 2 2 1\n";
			cout << "1 2 2 1\n";
			cout << "1 1 1 1\n";
			return;
		}
		if(k == 4){
			cout << "YES\n";
			cout << "1 1 2 2\n";
			cout << "1 1 2 2\n";
			cout << "3 3 4 4\n";
			cout << "3 3 4 4\n";
			return;
		}
	}
	cout << "NO\n";
}

int main(){
	int t; cin >> t; while(t --) s();
}
/*
5
2 2 2
2 2 1
4 4 4
4 4 2
4 6 3
6 8 4

((n - 2x) / 2) * ((m - 2x) / 2) = k - x
(n - 2x) * (m - 2x) = 4k - 4x
n * m - 2xn - 2xm + 4x^2 = 4k - 4x
n * m - 2xn - 2xm + 4x + 4x^2 = 4k
nm - 2x(n + m - 2) + 4x^2 = 4k
4x^2 - 2x(n + m - 2) + nm - 4k


4*4 + 
4x^2 + x * 2(2 - n - m) + (nm - 4k) = 0
*/
