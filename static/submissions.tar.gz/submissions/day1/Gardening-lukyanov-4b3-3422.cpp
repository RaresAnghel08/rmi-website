/**
* user:  lukyanov-4b3
* fname: Igor
* lname: Lukyanov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:04:03.523190
*/
#include<bits/stdc++.h>
using namespace std;

signed main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int t;
    cin>>t;
    while(t--){
        int n,m,k;
        cin>>n>>m>>k;
        bool swapped=0;
        if(n>m)swapped=1,swap(n,m);
        vector<vector<int>>ans;
        if(n==2&&m==2*k){
            cout<<"YES\n";
            /*for(int i=1;i<=k;i++)cout<<i<<" "<<i<<" ";cout<<"\n";
            for(int i=1;i<=k;i++)cout<<i<<" "<<i<<" ";cout<<"\n"; */
            ans.resize(2);
            for(int i=1;i<=k;i++)ans[0].push_back(i),ans[0].push_back(i);
            for(int i=1;i<=k;i++)ans[1].push_back(i),ans[1].push_back(i);
        }else if(n==4&&m==2*k){
            cout<<"YES\n";
            /*for(int i=1;i<=m;i++)cout<<1<<" ";cout<<"\n";
            cout<<1<<" ";for(int i=1;i<=k-1;i++)cout<<i+1<<" "<<i+1<<" ";cout<<1<<" "<<"\n";
            cout<<1<<" ";for(int i=1;i<=k-1;i++)cout<<i+1<<" "<<i+1<<" ";cout<<1<<" "<<"\n";
            for(int i=1;i<=m;i++)cout<<1<<" ";cout<<"\n";*/
            ans.resize(4);
            for(int i=0;i<m;i++)ans[0].push_back(1);
            ans[1].push_back(1);
            for(int i=1;i<k;i++)ans[1].push_back(i+1),ans[1].push_back(i+1);
            ans[1].push_back(1);

            ans[2].push_back(1);
            for(int i=1;i<k;i++)ans[2].push_back(i+1),ans[2].push_back(i+1);
            ans[2].push_back(1);

            for(int i=0;i<m;i++)ans[3].push_back(1);

        }else if(n==4&&m*n==4*k&&k%2==0){
            cout<<"YES\n";
            /*for(int i=1;i<=k/2;i++)cout<<i<<" "<<i<<" ";cout<<"\n";
            for(int i=1;i<=k/2;i++)cout<<i<<" "<<i<<" ";cout<<"\n";
            for(int i=k/2+1;i<=k;i++)cout<<i<<" "<<i<<" ";cout<<"\n";
            for(int i=k/2+1;i<=k;i++)cout<<i<<" "<<i<<" ";cout<<"\n";*/
            ans.resize(4);
            for(int i=1;i<=k/2;i++)ans[0].push_back(i),ans[0].push_back(i);
            for(int i=1;i<=k/2;i++)ans[1].push_back(i),ans[1].push_back(i);
            for(int i=k/2+1;i<=k;i++)ans[2].push_back(i),ans[2].push_back(i);
            for(int i=k/2+1;i<=k;i++)ans[3].push_back(i),ans[3].push_back(i);
        }
        else{
            cout<<"NO\n";
            continue;
        }
        if(!swapped){
            for(int i=0;i<n;i++){
                for(int ii=0;ii<m;ii++)cout<<ans[i][ii]<<" ";cout<<"\n";
            }
        }else{
            for(int ii=0;ii<m;ii++){
                for(int i=0;i<n;i++)cout<<ans[i][ii]<<" ";cout<<"\n";
            }
        }
        
    }
}