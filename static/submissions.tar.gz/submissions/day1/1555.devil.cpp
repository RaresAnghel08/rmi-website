/**
* user:  radoslavov-f96
* fname: Aleksandar
* lname: Radoslavov
* task:  devil
* score: 0.0
* date:  2019-10-10 07:06:51.283230
*/
#include<iostream>
using namespace std;

int main()
{
    long long a, b;
    cin >> a >> b;
    cout << a + b;
}
