/**
* user:  mate-5ef
* fname: Lőrinc
* lname: Máté
* task:  Gardening
* score: 29.0
* date:  2021-12-16 11:39:27.284351
*/
#include <bits/stdc++.h>

using namespace std;

int maxPOS = -1;

void megold(vector<vector<int> > & mo, int l, int r, int bot, int top, int k, int pos){
    int n = r - l + 1, m = top - bot + 1;
    // cout << l << " " << r << " " << bot << " " << top << endl;
    if (n == 2){
        for (int i = bot; i <= top; i += 2){
            mo[l][i] = pos;
            mo[l][i + 1] = pos;
            mo[r][i] = pos;
            mo[r][i + 1] = pos;
            pos++;
            maxPOS = max(maxPOS, pos);
        }
        return;
    }
    // cout << (n - 2) * (m - 2) / 4 + 1 << endl;
    if (k <= (n - 2) * (m - 2) / 4 + 1 && k != (n - 2) * (m - 2) / 4) {
        for (int i = l; i <= r; i++){
            mo[i][bot] = pos;
            mo[i][top] = pos;
        }
        for (int i = bot; i <= top; i++){
            mo[l][i] = pos;
            mo[r][i] = pos;
        }
        pos++;
        maxPOS = max(maxPOS, pos);
        megold(mo, l + 1, r - 1, bot + 1, top - 1, k - 1, pos);
    }
    else {
        int curK = n * m / 4;
        if (n * m / 4 % 2 != k % 2) {
            megold(mo, l, l + 3, bot, bot + 5, 3, pos);
            curK -= 3;
            pos += 3;
            maxPOS = max(maxPOS, pos);
            for (int j = bot + 6; j + 3 <= top; j += 4){
                if (curK == k) break;
                megold(mo, l, l + 3, j, j + 3, 2, pos);
                pos += 2;
                maxPOS = max(maxPOS, pos);
                curK -= 2;
                if (curK == k) break;
            }
            for (int j = bot; j <= top; j+= 2){
                if (mo[l][j] == -1){
                    mo[l][j] = pos;
                    mo[l][j + 1] = pos;
                    mo[l + 1][j] = pos;
                    mo[l + 1][j + 1] = pos;
                    pos++;
                    maxPOS = max(maxPOS, pos);

                    mo[l + 2][j] = pos;
                    mo[l + 2][j + 1] = pos;
                    mo[l + 3][j] = pos;
                    mo[l + 3][j + 1] = pos;
                    pos++;
                    maxPOS = max(maxPOS, pos);
                }
            }

            l += 4;
        }
        for (int i = l; i + 3 <= r; i+=4){
            if (curK == k) break;
            for (int j = bot; j + 3 <= top; j += 4){
                if (curK == k) break;
                megold(mo, i, i + 3, j, j + 3, 2, pos);
                pos += 2;
                maxPOS = max(maxPOS, pos);
                curK -= 2;
                if (curK == k) break;
            }
            if (curK == k) break;
        }
        for (int i = l; i <= r; i += 2){
            for (int j = bot; j <= top; j+= 2){
                if (mo[i][j] == -1){
                    mo[i][j] = pos;
                    mo[i][j + 1] = pos;
                    mo[i + 1][j] = pos;
                    mo[i + 1][j + 1] = pos;
                    pos++;
                    maxPOS = max(maxPOS, pos);
                }
            }
        }
    }
    return;
}

int main()
{
    int t;
    cin >> t;

    for (int i = 0; i < t; i++){
        int n, m, k;
        cin >> n >> m >> k;

        maxPOS = -1;

        bool volt = false;

        if (n > m) swap(n, m), volt = true;

        if (n % 2 == 1 || m % 2 == 1 || k > n * m / 4 || k < n / 2 - 1 + (m - (n / 2 - 1) * 2) / 2 || n * m / 4 - 1 == k) {
            // cout << (n * m / 4) << " " << (n / 2 - 1 + (m - (n / 2 - 1) * 2) / 2) << endl;
            cout << "NO" << endl;
            continue;
        }

        vector<vector<int> > mo(n, vector<int> (m, -1));

        megold(mo, 0, n - 1, 0, m - 1, k, 1);

        if (maxPOS - 1 > k){
            cout << "NO" << endl;
            continue;
        }

        cout << "YES" << endl;
        if (volt == false){
            for (int i = 0; i < n; i++){
                for (int j = 0; j < m; j++){
                    cout << mo[i][j] << " ";
                }
                cout << endl;
            }
            cout << endl;
        }
        else {
            for (int j = 0; j < m; j++){
                for (int i = 0; i < n; i++){
                    cout << mo[i][j] << " ";
                }
                cout << endl;
            }
            cout << endl;
        }
    }

    return 0;
}

/*

5
2 2 2
2 2 1
4 4 4
4 4 2
4 6 3


*/

