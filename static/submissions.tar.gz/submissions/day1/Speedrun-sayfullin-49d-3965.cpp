/**
* user:  sayfullin-49d
* fname: Iskandar
* lname: Sayfullin
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:50:35.605389
*/
#include <iostream>
#include <stack>
#include <vector>
#include "speedrun.h"
#include <unordered_map>

using namespace std;

void assignHints(int substack, int N, int A[], int B[]) {
    if (substack == 1) {
        setHintLen(N);

        for (int i = 1; i < N; i++) {
            setHint(A[i], B[i], 1);
            setHint(B[i], A[i], 1);
        }
    } else if (substack == 2) {
        setHintLen(1);
        unordered_map<int, int> g;
        for (int i = 0; i < N; i++) {
            g[A[i]]++;
            g[B[i]]++;
        }
        for (pair<int, int> i : g) {
            if (i.second == N - 1) setHint(i.first, 1, 1);
        }
    }
}

void speedrun(int substack, int N, int start) {
    if (substack == 1) {
        vector<bool> used(N);
        int l = getLength();

        vector<vector<bool>> g(N, vector<bool>(N));
        stack<int> s;
        vector<int> p(N, -1);

        used[start - 1] = true;
        for (int j = 1; j <= l; j++) {
            g[start - 1][j - 1] = getHint(j);
            if (g[start - 1][j - 1] && !used[j - 1]) {
                s.push(j - 1);
                p[j - 1] = start - 1;
            }
        }

        while (s.size() != 0) {
            bool f = false;

            goTo(s.top() + 1);
            start = s.top() + 1;

            s.pop();

            if (!used[start - 1]) {
                for (int j = 1; j <= l; j++) {
                    g[start - 1][j - 1] = getHint(j);
                    if (g[start - 1][j - 1] == 1 && !used[j - 1]) {
                        s.push(j - 1);
                        f = true;
                        p[j - 1] = start - 1;
                    }
                }
                used[start - 1] = true;
                if (!f) {
                    while (p[start - 1] != -1 && used[start - 1]) {
                        goTo(p[start - 1] + 1);
                        start = p[start - 1] + 1;
                    }
                }
            }
        }
    } else if (substack == 2) {
        if (getHint(1)) {
            for (int i = 1; i <= N; i++) {
                if (i == start) continue;
                goTo(i);
                goTo(start);
            }
        }
    }
}