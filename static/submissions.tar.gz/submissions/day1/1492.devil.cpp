/**
* user:  volkov-d03
* fname: Ivan
* lname: Volkov
* task:  devil
* score: 0.0
* date:  2019-10-10 06:56:29.592282
*/
#include <iostream>

using namespace std;

void solve() {
    int k;
    int cnt[10];
    cin >> k;
    for (int i = 1; i <= 9; i++) cin >> cnt[i];
    int a = cnt[1], b = cnt[2], n = a + b;
    if (a == 0) {
        for (int i = 0; i < b; i++) cout << "2";
        cout << "\n";
        return;
    }
    if (b == 0) {
        for (int i = 0; i < a; i++) cout << "1";
        cout << "\n";
        return;
    }
    string res = "";
    for (int i = 0; i < n; i++) res += "0";
    res[n - k] = '1';
    a--;
    for (int i = n - k + 1; i < n; i++) {
        if (b > 0) {
            res[i] = '2';
            b--;
        } else {
            res[i] = '1';
            a--;
        }
    }
    n -= k;
    int maxi = b / (a + 1);
    if (b % (a + 1) != 0) maxi++;
    int tail = 0;
    for (int i = 0; i < n; i++) {
        if (tail == maxi) {
            res[i] = '1';
            tail = 0;
            a--;
            continue;
        }
        if (b > 0) {
            res[i] = '2';
            b--;
            tail++;
        } else {
            res[i] = '1';
            a--;
            tail = 0;
        }
    }
    cout << res << "\n";
}

int main() {
    //freopen("Desktop/input.txt", "r", stdin);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) {
        solve();
    }
    return 0;
}
