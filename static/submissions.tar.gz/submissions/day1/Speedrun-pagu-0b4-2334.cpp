/**
* user:  pagu-0b4
* fname: Tudor Stefan
* lname: Pagu
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 09:23:36.928313
*/
#include <bits/stdc++.h>
#include "speedrun.h"
using namespace std;

ifstream in("in.in");
ofstream out("out.out");
const int nmax = 1005;

//---------
/*
int curNode;
int hint[nmax][nmax],realad[nmax][nmax];
int LNOTATHING;

void setHintLen(int l) {
    LNOTATHING = l;
}
void setHint(int i, int j, bool b) {
    hint[i][j] = b;
}
int getLength() {
    return LNOTATHING;
}
bool goTo(int node) {
    out << "WE GO FROM " << curNode << " TO " << node << "\n";
    if (realad[curNode][node]) {
        curNode = node;
        return true;
    } else {
        return false;
    }
}
bool getHint(int j) {
    return hint[curNode][j];
}*/
//------------

int deg[nmax];

void assignHints(int subtask, int N, int A[], int B[]) {
    if (subtask == 2) {
        setHintLen(20);
        for (int i = 1; i < N; i++) {
            deg[A[i]]++;
            deg[B[i]]++;
        }
        int starc;
        for (int i = 1; i <= N; i++) if (deg[i] > 1) starc = i;
        for (int i = 1; i <= N; i++) {
            if (starc != i) {
                for (int j = 0; j < 20; j++) {
                    if (starc & (1 << j)) {
                        setHint(i , j + 1 , true);
                    }
                }
            }
        }
    }
    else {
        setHintLen(N);
        for (int i = 1; i < N; i++) {
            //hint[A[i]] , B[i] = 1
            setHint(A[i], B[i], true);
            setHint(B[i], A[i], true);
        }
    }
}

int l,viz[nmax],n;
void dfs(int node, int parent) {
    viz[node] = 1;
    for (int i = 1; i <= n; i++) {
        if (i != parent && viz[i] == 0 && getHint(i)) {
            goTo(i);
            dfs(i , node);
        }
    }
    if (parent != 0) {
        goTo(parent);
    }
}
int getHintVal() {
    int val = 0;
    for (int i = 1; i <= 20; i++) {
        if (getHint(i)) {
            val += ( 1 << (i - 1) );
        }
    }
    return val;
}
int center;
void speedrun(int subtask, int N, int start) {
    if (subtask == 2) {
        l = getLength();
        n = N;
        int val = getHintVal();
        if (val != 0) {
            center = val;
            goTo(center);
        } else {
            center = start;
        }
        for (int i = 1; i <= N; i++) {
            if (center == i) continue;

            goTo(i);
            goTo(center);
        }
    } else {
        l = getLength();
        n = N;
        dfs(start , 0);
    }
}
/*
int A[nmax],B[nmax];
int main() {
    int start,n;
    in >> n >> start;
    curNode = start;
    for (int i = 1; i < n; i++) {
        in >> A[i] >> B[i];
        realad[A[i]][B[i]] = 1;
        realad[B[i]][A[i]] = 1;
    }
    assignHints(2 , n , A , B);
    speedrun(2 , n , start);
}*/