/**
* user:  asgari-a0b
* fname: Armin
* lname: Asgari
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 09:11:01.582848
*/
/* Input format:
 *
 * N -- number of nodes
 * a1 b1 -- edge 1
 * ...
 * a(N-1) b(N-1) -- edge N - 1
 * x -- start node
 */

#include <bits/stdc++.h>
#include <map>
#include <set>

#include "speedrun.h"
using namespace std;
/*
static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;

void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }
*/
const int NMAX = 1000;
vector <int> g[NMAX + 2];
bool vizitat[NMAX + 2];
int f[NMAX + 2];

void assignHints(int subtask, int n, int a[], int b[]) { /* your solution here */
  int i, j;
  for( i = 1; i < n; ++i ) {
    ++f[a[i]];
    ++f[b[i]];
  }
  int ok = -1;
  for( i = 1; i <= n; ++i )
    if( f[i] == n - 1 )
      ok = i;

  if( ok == -1 ) {

    setHintLen(n);
    for( i = 1; i < n; ++i ) {
      int x = a[i];
      int y = b[i];
      setHint(x, y, 1);
      setHint(y, x, 1);
    }
  }
  else {
    int l = 20;
    if( n == 20 )
      l = 19;

    setHintLen(l);
    for( j = 1; j <= l; ++j )
      setHint(ok, j, 1);

    for( i = 1; i <= n; ++i ){
      if( i != ok ) {
        for( j = 1; j <= l; ++j )
          if( ok & (1 << (j - 1)) )
            setHint(i, j, 1);
          else
            setHint(i, j, 0);
      }
    }
  }
}
/*
bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}*/

//ofstream fout( ".out" );

void dfs( int node, int n ) {
  int i;
  vizitat[node] = 1;
  for( i = 1; i <= n; ++i )
    if( !vizitat[i] && getHint(i) == 1 ) {
      //fout << "goto " << i << "\n";
      goTo(i);
      dfs(i, n);
      goTo(node);
      //fout << "goto " << node << "\n";
    }
}

void speedrun(int subtask, int n, int start) { /* your solution here */
  int i;
  int l;

  if( n == 20 && getLength() == 19 ) {
    l = 19;
    goTo(start);
    int ok = 1;
    for( i = 1; i <= l; ++i )
      if( getHint(i) == 0 )
        ok = 0;

    if( ok == 1 ) {
      for( i = 1; i <= n; ++i ) {
        if( i != start ) {
          goTo(i);
          goTo(start);
        }
      }
    }
    else {
      int nr = 0;
      for( i = 1; i <= l; ++i )
        nr += (1 << (i - 1)) * getHint(i);
      goTo(nr);
      for( i = 1; i <= n; ++i ) {
        if( i != nr && i != start ) {
          goTo(i);
          goTo(nr);
        }
      }
    }
    return ;
  }
  else if( getLength() == 20 && n != 20 ) {
    l = 20;
    goTo(start);
    int ok = 1;
    for( i = 1; i <= l; ++i )
      if( getHint(i) == 0 )
        ok = 0;

    if( ok == 1 ) {
      for( i = 1; i <= n; ++i ) {
        if( i != start ) {
          goTo(i);
          goTo(start);
        }
      }
    }
    else {
      int nr = 0;
      for( i = 1; i <= l; ++i )
        nr += (1 << (i - 1)) * getHint(i);
      goTo(nr);
      for( i = 1; i <= n; ++i ) {
        if( i != nr && i != start ) {
          goTo(i);
          goTo(nr);
        }
      }
    }
    return ;

  }
  goTo(start);
  dfs(start, n);
}

/*
int main() {
    int N;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(1, N, a, b);

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(1, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;
    return 0;
}*/
