/**
* user:  dzheentaev-018
* fname: Bektur
* lname: Dzheentaev
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:26:37.915692
*/
﻿
#include <iostream>
#include<vector>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
using namespace std;
typedef long long ll;
int main()
{
    ll t;
    cin >> t;
    
    while (t > 0) {
        ll n, m, k;
        cin >> n >> m >> k;
        
        ll x = n / 2;
        ll y = m / 2;
        if ((n == 2 || m == 2) && k == 1) {
            cout << "NO" << endl;
        }
        else {
            if (x * y == k && n % 2 == 0 && m % 2 == 0) {
                cout << "YES" << endl;
                ll cnt = 1;
                for (ll i = 0; i < n; i++) {
                    if (i % 2 == 0 && i != 0) {
                        cnt += m / 2;
                    }
                    if (cnt > k) {
                        break;
                    }
                    ll cnt1 = cnt;
                    for (ll j = 0; j < m; j++) {
                        if (j % 2 == 0 && j != 0) {
                            cnt1++;
                        }
                        cout << cnt1 << " ";
                    }
                    cout << endl;
                }
            }
            else {
                if ((2 - n - m) * (2 - n - m) - 4 * (n * m - 4 * k) >= 0) {
                    ll a = (n + m - 2 + sqrt((2 - n - m) * (2 - n - m) - 4 * (n * m - 4 * k))) / 4;
                    ll b = (n + m - 2 - sqrt((2 - n - m) * (2 - n - m) - 4 * (n * m - 4 * k))) / 4;
                    ll x1 = (n - 2 * a) / 2;
                    ll y1 = (m - 2 * a) / 2;
                    ll x2 = (n - 2 * b) / 2;
                    ll y2 = (m - 2 * b) / 2;
                    //cout << a << " " << b << endl;
                    if (a >= 0 && b >= 0) {

                        if (x1 * y1 == k - a && k >= a && a <= min(n, m) / 2) {
                            cout << "YES" << endl;
                            ll cnt = a + 1;
                            for (ll i = 0; i < n; i++) {
                                ll cnt1;
                                if (i >= a && i <= n - a - 1) {
                                    if ((i - a) % 2 == 0 && i != a) {
                                        cnt += (m - 2 * a) / 2;
                                    }
                                    cnt1 = cnt;
                                }
                                for (ll j = 0; j < m; j++) {
                                    if (i >= a && i <= n - a - 1 && j >= a && j <= m - a - 1)
                                    {
                                        cout << cnt1 << " ";
                                        if ((j - a + 1) % 2 == 0 && j != a) {
                                            cnt1++;
                                        }
                                    }
                                    else {
                                        cout << min(min(i, n - i - 1), min(j, m - j - 1)) + 1 << " ";
                                    }
                                }
                                cout << endl;
                            }
                        }
                        else {
                            if (x2 * y2 == k - b && k >= b && b <= min(n, m) / 2) {
                                cout << "YES" << endl;
                                ll cnt = b + 1;
                                for (ll i = 0; i < n; i++) {
                                    ll cnt1;
                                    if (i >= b && i <= n - b - 1) {
                                        if ((i - b) % 2 == 0 && i != b) {
                                            cnt += (m - 2 * b) / 2;
                                        }
                                        cnt1 = cnt;
                                    }
                                    for (ll j = 0; j < m; j++) {
                                        if (i >= b && i <= n - b - 1 && j >= b && j <= m - b - 1)
                                        {
                                            cout << cnt1 << " ";
                                            if ((j - b + 1) % 2 == 0 && j != b) {
                                                cnt1++;
                                            }
                                        }
                                        else {
                                            cout << min(min(i, n - i - 1), min(j, m - j - 1)) + 1 << " ";
                                        }
                                    }
                                    cout << endl;
                                }
                            }
                            else
                                cout << "NO" << endl;
                        }
                    }
                    else {
                        if (x2 * y2 == k - b && k >= b && b <= min(n, m) / 2) {
                            cout << "YES" << endl;
                            ll cnt = b + 1;
                            for (ll i = 0; i < n; i++) {
                                ll cnt1;
                                if (i >= b && i <= n - b - 1) {
                                    if ((i - b) % 2 == 0 && i != b) {
                                        cnt += (m - 2 * b) / 2;
                                    }
                                    cnt1 = cnt;
                                }
                                for (ll j = 0; j < m; j++) {
                                    if (i >= b && i <= n - b - 1 && j >= b && j <= m - b - 1)
                                    {
                                        cout << cnt1 << " ";
                                        if ((j - b + 1) % 2 == 0 && j != b) {
                                            cnt1++;
                                        }
                                    }
                                    else {
                                        cout << min(min(i, n - i - 1), min(j, m - j - 1)) + 1 << " ";
                                    }
                                }
                                cout << endl;
                            }
                        }
                        else {
                            if (x1 * y1 == k - a && k >= a && a <= min(n, m) / 2) {
                                cout << "YES" << endl;
                                ll cnt = a + 1;
                                for (ll i = 0; i < n; i++) {
                                    ll cnt1;
                                    if (i >= a && i <= n - a - 1) {
                                        if ((i - a) % 2 == 0 && i != a) {
                                            cnt += (m - 2 * a) / 2;
                                        }
                                        cnt1 = cnt;
                                    }
                                    for (ll j = 0; j < m; j++) {
                                        if (i >= a && i <= n - a - 1 && j >= a && j <= m - a - 1)
                                        {
                                            cout << cnt1 << " ";
                                            if ((j - a + 1) % 2 == 0 && j != a) {
                                                cnt1++;
                                            }
                                        }
                                        else {
                                            cout << min(min(i, n - i - 1), min(j, m - j - 1)) + 1 << " ";
                                        }
                                    }
                                    cout << endl;
                                }
                            }
                            else
                                cout << "NO" << endl;
                        }
                    }
                }
                else
                    cout << "NO" << endl;
            }
        }
            
        }
        t--;
    
    return 0;
}


                        
                    
