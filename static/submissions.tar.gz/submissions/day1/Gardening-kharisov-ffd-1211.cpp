/**
* user:  kharisov-ffd
* fname: Bulat Rafailevich
* lname: Kharisov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:21:28.651694
*/
#include<bits/stdc++.h>
using namespace std;

const int N = 1e3 + 3;

int n, K;
int a[N][N];

bool solve(int stx, int sty, int n) {
    if (n % 2 == 1) return false;
    if (K > n * n / 4) return false;
    if (K < n / 2) return false;
    if (n == 0) return true;
    if (K <= (n-2)*(n-2)/4 + 1) {
        for (int i = stx; i < stx+n; ++i)
            a[i][sty] = a[i][sty+n-1] = K;
        for (int i = sty; i < sty+n; ++i)
            a[stx][i] = a[stx+n-1][i] = K;
        --K;
        return solve(stx+1, sty+1, n - 2);
    }
    for (int i = stx; i < stx+n; i += 2) {
        a[i][sty+n-1] = a[i][sty+n-2] = a[i+1][sty+n-1] = a[i+1][sty+n-2] = K;
        --K;
    }
    for (int i = sty; i < sty+n-2; i += 2) {
        a[stx+n-1][i] = a[stx+n-2][i] = a[stx+n-1][i+1] = a[stx+n-2][i+1] = K;
        --K;
    }
    return solve(stx, sty, n - 2);
}

void run() {
    cin >> n >> n >> K;
    if (!solve(0, 0, n)) cout << "NO" << endl;
    else {
        cout << "YES" << endl;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                cout << a[i][j] << " ";
            }
            cout << endl;
        }
    }
}

signed main() {
	cin.tie(0), cout.tie(0), ios_base::sync_with_stdio(0);

    int t;
    cin >> t;
    while (t--) {
        run();
    }
}