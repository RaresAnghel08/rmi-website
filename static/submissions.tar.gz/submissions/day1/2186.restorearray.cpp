/**
* user:  taga-e6c
* fname: Ștefan
* lname: Țaga
* task:  restore
* score: 13.0
* date:  2019-10-10 08:40:43.303510
*/
#include <bits/stdc++.h>

using namespace std;
int n,m,sol[5005],i,j,ok,caz,caz1,caz2,aib[5005];
int ub (int x)
{
    return x&(-x);
}
struct wow
{
    int st,dr,nr,elem;
}v[10005];
void update (int poz,int val)
{
    for (int i=poz;i<=n;i+=ub(i))
    {
        aib[i]+=val;
    }
}
int query(int poz)
{
    int sum=0;
    for (int i=poz;i>0;i-=ub(i))
    {
        sum=sum+aib[i];
    }
    return sum;
}
bool ok1[100005];
int poz,lim,sum0[10005],sum1[10005],nr1,nr0;
struct wow2
{
    int st,dr,val;
}v3[10005];
bool compare (wow2 a,wow2 b)
{
    return a.st<b.st||(a.st==b.st&&a.dr<b.dr);
}
int main()
{
    ios_base :: sync_with_stdio(false);
    cin>>n>>m;
    caz=0;
    for (i=0;i<n;i++)
    {
        sol[i]=2;
    }
    for (i=1;i<=m;i++)
    {
        cin>>v[i].st>>v[i].dr>>v[i].nr>>v[i].elem;
        if (v[i].nr==1)
        {
            caz1++;
        }
        if (v[i].nr==v[i].dr-v[i].st+1)
        {
            caz2++;
        }
    }
    if (caz1==m)
    {
        caz=1;
    }
    else
    {
        caz=2;
    }
    if (caz==1)
    {
        for (i=1;i<=m;i++)
        {
            if (v[i].nr==1&&v[i].elem==1)
        {
            for (j=v[i].st;j<=v[i].dr;j++)
            {
                if (sol[j]==0)
                {
                    cout<<"-1";
                    return 0;
                }
                else
                {
                    sol[j]=1;
                }
            }
        }
        }
        for (i=1;i<=m;i++)
        {
            if (v[i].elem==0)
            {
                ok=0;
                for (j=v[i].st;j<=v[i].dr;j++)
                {
                    if (sol[j]==2||sol[j]==0)
                    {
                        sol[j]=0;
                        ok=1;
                        break;
                    }
                }
                if (ok==0)
                {
                    cout<<"-1";
                    return 0;
                }
            }
        }
        for (i=0;i<n;i++)
        {
            if (sol[i]==2)
            {
                sol[i]=0;
            }
            cout<<sol[i]<<" ";
        }
    }
    else
    {
        if (n<=18)
        {
            lim=(1<<n);
            for (j=0;j<lim;j++)
            {
                for (i=0;i<n;i++)
                {
                    if (((1<<i)&j)!=0)
                    {
                        sol[i]=1;
                    }
                    else
                    {
                        sol[i]=0;
                    }
                }
            sum0[0]=(sol[0]==0);
            sum1[0]=(sol[0]==1);
            for (i=1;i<n;i++)
            {
                sum0[i]=sum0[i-1]+(sol[i]==0);
                sum1[i]=sum1[i-1]+(sol[i]==1);
            }
            ok=1;
            for (i=1;i<=m;i++)
            {

                nr1=sum1[v[i].dr]-sum1[v[i].st-1];
                nr0=sum0[v[i].dr]-sum0[v[i].st-1];
                if (v[i].elem==1)
                {
                    if (nr0!=v[i].nr-1)
                    {
                        ok=0;
                        break;
                    }
                }
                else
                if (v[i].elem==0)
                {
                    if (nr0<v[i].nr)
                    {
                        ok=0;
                        break;
                    }
                }

            }
            if (ok==1)
            {
                for (i=0;i<n;i++)
                {
                    cout<<sol[i]<<" ";
                }
                return 0;
            }
            }
           cout<<"-1";
        }
    }
    return 0;
}
