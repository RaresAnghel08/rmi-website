/**
* user:  patrushava-e4f
* fname: Hanna
* lname: Patrushava
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:14:12.477462
*/
#pragma GCC optimize ("unroll-loops")
#pragma GCC optimize ("Ofast")
#include <bits/stdc++.h>
#include "speedrun.h"

#define f first
#define s second
#define pb push_back
#define pii pair<int, int>
#define ll long long

using namespace std;

using namespace std;
const int N = 1e4;
vector < int > g[N];
void assignHints(int subtask, int N, int A[], int B[]) {

    for (int i = 1; i < N; i++) {
        g[A[i]].pb(B[i]);
        g[B[i]].pb(A[i]);
    }

    if (subtask == 2) {
        setHintLen(20);
        int v = 1;
        for (int i = 2; i <= N; i++)
            if ((int)g[i].size() == N - 1)
                v = i;

        for (int i = 1; i <= N; i++) {
            for (int h = 0; h < 20; h++) {
                if ((v >> h) & 1)
                    setHint(i, h + 1, 1);
            }
        }


        return;
    }

    if (subtask == 1) {
        setHintLen(N);
        for (int i = 1; i <= N; i++) {
            for (auto x: g[i]) {
                setHint(i, x, 1);
            }
        }

        return;
    }


    if (subtask == 3) {
        setHintLen(20);
        for (int i = 1; i <= N; i++) {
            int k = 0;
            for (auto x: g[i]) {
                for (int h = 0; h < 10; h++) {
                    if ((x >> h) & 1)
                        setHint(i, h + 10 * k + 1, 1);
                }
                k++;
            }
        }
        return;
    }
}

int kol;
void go(int v, int pred, int n) {
    kol++;
    for (int i = 1; i <= n; i++) {
        if (i != v && i != pred && getHint(i) == 1) {
            goTo(i);
            go(i, v, n);
            if (kol == n)
                return;
            goTo(v);
        }
    }

    return;
}


void go1(int v, int pred, int n) {

    int v1, v2;
    v1 = 0;
    v2 = 0;
    for (int i = 0; i < 10; i++) {
        if (getHint(v, i + 1) == 1)
            v1 += (1ll << i);
    }
    for (int i = 10; i < 20; i++) {
        if (getHint(v, i + 1) == 1)
            v2 += (1ll << (i - 10));
    }


    kol++;

    if (v1 > 0 && v1 != pred) {
        goTo(v1);
        go1(v1, v, n);
        if (kol == n)
            return;
        goTo(v);
    }

    if (v2 > 0 && v2 != pred) {
        goTo(v2);
        go1(v2, v, n);
        if (kol == n)
            return;
        goTo(v);
    }

    return;
}

void speedrun(int subtask, int N, int start) { /* your solution here */

    if (subtask == 2) {
        int l = getLength();
        int v = 0;
        for (int i = 1; i <= l; i++) {
            if (getHint(i) == 1)
                v += (1 << (i - 1));
        }
        if (start != v) {
            goTo(v);
        }
        for (int i = 1; i <= N; i++) {
            if (i == v || i == start)
                continue;
            goTo(i);
            goTo(v);
        }
        return;
    }

    if (subtask == 1) {
        go(start, 0, N);
        return;
    }

    if (subtask == 3) {
        go1(start, 0, N);
        return;
    }

}

