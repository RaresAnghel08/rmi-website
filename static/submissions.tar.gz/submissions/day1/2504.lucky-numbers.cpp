/**
* user:  gospodinov-b8b
* fname: Antani
* lname: Gospodinov
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:25:24.567834
*/
#include <bits/stdc++.h>
#define ll long long
#define mp make_pair
#define pb push_back
using namespace std;



int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);




    return 0;
}

