/**
* user:  ivan-6a1
* fname: Tudor
* lname: Ivan
* task:  devil
* score: 0.0
* date:  2019-10-10 10:23:26.625598
*/
#include <iostream>
#include<cstdio>
#include<vector>
#include<cstring>
#include<map>
using namespace std;
int frv[10];
const int N=100005;
string fnl;
struct strings{
  string s;
};
vector<strings>v;
int frvlbl[5];
string mini;
string aux;
void bkt(int k,int ramas){
  if(k==ramas){
    mini=min(mini,aux);
    return;
  }
}
bool frvempty(int cf){
  for(int i=cf;i<=10;i++){
    if(frv[i]>0)
      return false;
  }
  return true;
}
void solve(){
  v.clear();
  fnl="";
  int k,s=0;
  scanf("%d",&k);
  for(int i=1;i<=9;i++){
    scanf("%d",&frv[i]);
    s+=frv[i];
  }
  int sum=0;
  int cff;
  for(cff=9;cff>=1;cff--){
    while(frv[cff]>0 && sum<k-1){
      char c=('0'+cff);
      fnl=c+fnl;
      frv[cff]--;
      sum++;
    }
    if(sum==k-1)
      break;
  }
  cff=9;
  while(frv[cff]==0)
    cff--;
  int ramas=frv[cff];
  frv[cff]=0;
  for(int i=1;i<=ramas;i++){
    char c=('0'+cff);
    string aux;
    aux="";
    aux+=c;
    v.push_back({aux});
  }
  int j=0;
  for(int cf=1;cf<cff;cf++){
    //j prima pozitie pe care nu pun nimic
    if(frvempty(cf+1)){
        j=ramas-1;
        for(int i=0;i<frv[cf];i++){
          char c=('0'+cf);
          v[j].s+=c;
          j--;
          if(j<0)
            j=ramas-1;
        }
    }
    else{
        for(int i=0;i<frv[cf];i++){
          char c=('0'+cf);
          v[j].s+=c;
          j++;
          if(j>=ramas)
            j=0;
        }
    }
   // start=j;
  }
  for(int i=0;i<5;i++)
    frvlbl[i]=0;
  int dif=1;

  for(int i=0;i<ramas;i++){
    if(i>0 && v[i].s.size()!=v[i-1].s.size())
      dif++;
    frvlbl[dif]++;
  }
  string minim="";
  if(dif==1){
    for(int i=ramas-1;i>=0;i--)
      cout<<v[i].s;
  }
  else{
    int indlen1=0,indlen2=frvlbl[1];
    int per=frvlbl[1]/frvlbl[2],rperechi=frvlbl[1]%frvlbl[2];
    for(int i=0;i<rperechi;i++){
      cout<<v[indlen1].s;
      indlen1++;
    }
    for(int i=rperechi;i<ramas;i++){
      for(int j=0;j<per;j++){
        cout<<v[indlen1].s;
        indlen1++;
      }
      cout<<v[indlen2].s;
      indlen2++;
    }
  }
  cout<<fnl;
}
int main()
{
    int nrt;
    scanf("%d",&nrt);
    while(nrt--){
        solve();
    }
    return 0;
}
