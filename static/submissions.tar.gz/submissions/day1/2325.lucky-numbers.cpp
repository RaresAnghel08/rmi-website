/**
* user:  danailov-cda
* fname: Daniel
* lname: Danailov
* task:  lucky
* score: 14.0
* date:  2019-10-10 09:00:33.942492
*/
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector <int> v;

int main()
{

ios::sync_with_stdio(false);
cin.tie(nullptr);

int n,q,x,i,z,num,ans,sz;
bool fl;

cin>>n>>q;
cin>>x;

ans=0;
 for(z=0;z<=x;z++)
 {
  num=z;
  v.clear();

   while(num!=0)
   {
    v.push_back(num%10);
    num/=10;
   }

  reverse(v.begin(),v.end());

  fl=true;
  sz=(int)v.size();
   for(i=0;i<sz-1;i++)
   {
    if(v[i]==1 && v[i+1]==3)
    {
     fl=false;
     break;
    }
   }

   if(fl)
    ans++;
 }

cout<<ans<<"\n";

return 0;
}
