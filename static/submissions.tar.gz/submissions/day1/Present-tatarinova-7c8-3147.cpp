/**
* user:  tatarinova-7c8
* fname: Yuliia
* lname: Tatarinova
* task:  Present
* score: 8.0
* date:  2021-12-16 10:40:07.210610
*/
#include <bits/stdc++.h>

using namespace std;
bool used[100000];
int main()
{
    long long t;
    cin>>t;
    for(int step=0; step<t; step++)
    {
        long long t;
        cin>>t;
        if(t==0)
        {
            cout<<0<<'\n';
            continue;
        }

        long long s=0, a=0, a1=a, k=0;
        while(s!=t)
        {
            a++;
            a1=a;
            k=0;
            while(a1!=0)
            {
                if(a1%2==1) used[k]=true; else used[k]=false;
                k++;
                a1/=2;
            }
          //  cout<<k<<"lalala\n";
            bool f=true;
            for(int i=0; i<k; i++)
                for(int j=i+1; j<k; j++)
                if(used[i]==true && used[j]==true)
            {
                if(used[__gcd(i+1, j+1)-1]==false) f=false;
            }

            if(f==true) {s++;}
        }

        k=0;
        long long u=0;
        while(a!=0)
            {
                if(a%2==1) {u++;used[k]=true;} else used[k]=false;
                k++;
                a/=2;
            }

    cout<<u<<' ';
    for(int i=0; i<k; i++)
        if(used[i]==true) cout<<i+1<<' ';
    cout<<'\n';
    }
    return 0;
}
