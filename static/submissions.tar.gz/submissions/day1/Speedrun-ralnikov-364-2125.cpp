/**
* user:  ralnikov-364
* fname: Paul
* lname: Ralnikov
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 09:02:34.119608
*/
#include "speedrun.h"
#include<bits/stdc++.h>
#define f first
#define s second
#define _ << ' ' <<
#define all(x) x.begin(), x.end()
#define sz(x) (int)x.size()
#define Time() clock() / (ld) CLOCK_PER_SEC

#ifdef LOCAL
	#define cerr cout
#else
	#define cerr if(0) cout
#endif

using namespace std;

const int MAXN = 1100, C = 10;

vector<int> g[MAXN];

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
	int n = N;
	for (int i = 1; i < N; i++) {
		A[i]--, B[i]--;
		g[A[i]].push_back(B[i]);
		g[B[i]].push_back(A[i]);
	}
	int len;
	if (subtask == 2) {
		len = C;
		setHintLen(len);
		int star = -1;
		for (int i = 0; i < n; i++) {
			if (sz(g[i]) == n - 1) {
				star = i;
				break;
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < C; j++) {
				setHint(i + 1, j + 1, ((star >> j) & 1));
			}
		}
	} else {
		len = C * 2;
		setHintLen(len);
		for (int i = 0; i < n; i++) {
			if (sz(g[i]) == 1) {
				g[i].push_back(i);
			}
			for (int j = 0; j < C; j++) {
				setHint(i + 1, j + 1, ((g[i][0] >> j) & 1));
			}
			for (int j = 0; j < C; j++) {
				setHint(i + 1, j + C + 1, ((g[i][1] >> j) & 1));
			}
		}
	}
}

int getStar() {
	int ans = 0;
	for (int i = 0; i < C; i++) {
		if (getHint(i + 1)) ans += (1 << i);
	}
	return ans;
}

int gr[2][MAXN];

int getFirstEdge() {
	int ans = 0;
	for (int i = 0; i < C; i++) {
		if (getHint(i + 1)) ans += (1 << i);
	}
	return ans;
}

int getSecondEdge() {
	int ans = 0;
	for (int i = 0; i < C; i++) {
		if (getHint(i + C + 1)) ans += (1 << i);
	}
	return ans;
}

int used[MAXN];

void dfs(int v) {
	used[v] = 1;
	gr[v][0] = getFirstEdge();
	gr[v][1] = getSecondEdge();
	for (int i = 0; i < 2; i++) {
		if (!used[gr[v][i]]) {
			assert(goTo(gr[v][i] + 1));
			dfs(gr[v][i]);
			assert(goTo(v + 1));
		}
	}
}

void speedrun(int subtask, int N, int start) { /* your solution here */
	int v = start - 1;
	if (subtask == 2) {
		int star = getStar();
		if (v != star) {
			assert(goTo(star + 1));
		}
		for (int i = 0; i < N; i++) {
			if (star != i) {
				assert(goTo(i + 1));
				assert(goTo(star + 1));
			}
		}
	} else if (subtask == 3) {
		dfs(v);
	}
}
