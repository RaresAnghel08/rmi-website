/**
* user:  bozhkov-3b7
* fname: Denis Petrov
* lname: Bozhkov
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 09:11:47.662210
*/
#include "speedrun.h"
#include<vector>
#include<iostream>

std::vector<int> A;
std::vector<int> B;
int N;
std::vector<int> count;
std::vector<int> rand1;
std::vector<bool> used;

void dfs(int start)
{
	used[start]=true;
	int last;
	int next;
	for(int i=1;i<=N;i++)
		if(A[i]==start||B[i]==start)
		{
			if(A[i]==start)next=B[i];
			else next=A[i];
			last=next;
			count[start]++;
			if(rand1[next]==0)rand1[start]=next;
			if(!used[next])dfs(next);
		}
	if(rand1[start]==0)rand1[start]=last;

}

void assignHints(int subtask, int N, int A[], int B[])
{
	::A.assign(A,A+N+1);
	::B.assign(B,B+N+1);
	::N=N;
	count.resize(N+1,0);
	rand1.resize(N+1,0);
	used.resize(N+1,false);
	setHintLen(20);

	dfs(1);

	for(int i=1;i<=N;i++)
	{
//		std::cout<<i<<':'<<count[i]<<','<<rand1[i]<<std::endl;
		for(int j=0;j<10;j++)
		{
			setHint(i,10-j,count[i]%2);
			setHint(i,20-j,rand1[i]%2);
			count[i]/=2;
			rand1[i]/=2;
		}
	}
}

#define lastel (*path.rbegin())

void speedrun(int subtask, int N, int start)
{
	used.clear();
	used.resize(N+1,false);
	std::vector<int> path;
	std::vector<int> nexts[N+1];
	std::vector<int> count(N+1,0);
	int v;
	int visited=0;
	used[start]=true;
	visited++;
	path.push_back(start);
	while(visited<N)
	{
		if(count[lastel]==0)
		{
			count[lastel]=v=0;
			for(int i=1;i<=10;i++)
			{
				count[lastel]=count[lastel]*2+getHint(i);
				v=v*2+getHint(i+10);
			}
			nexts[lastel].resize(count[lastel],0);
			nexts[lastel][0]=v;
		}
		bool f;
		for(int i=0;i<nexts[lastel].size();i++)
		{
			f=false;
			if(nexts[lastel][i]==0)
				for(int j=1;j<=N;j++)
					if(!used[j]&&goTo(j))
					{
						nexts[lastel][i]=j;
						visited++;
						path.push_back(j);
						used[j]=true;
						f=true;
						break;
					}
			if(f)break;
			if(!used[nexts[lastel][i]])
			{
				used[nexts[lastel][i]]=true;
				goTo(nexts[lastel][i]);
				path.push_back(nexts[lastel][i]);
				visited++;
				f=true;
				break;
			}
		}
		if(f)continue;
		if(path.size()>1)
		{
			path.pop_back();
			goTo(lastel);
		}
	}
}
