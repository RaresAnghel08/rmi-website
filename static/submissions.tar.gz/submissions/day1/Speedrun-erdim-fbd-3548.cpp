/**
* user:  erdim-fbd
* fname: Yasmin Behich
* lname: Erdim
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 11:16:51.088367
*/
#include "speedrun.h"
#include <vector>
//#include <iostream>
//using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
	int i, j;
	setHintLen(20);
	bool fl[N+1];
	for(i=1;i<=N;i++) fl[i] = 0;
	for(i=1;i<N;i++) {
		int a = A[i];
		int b = B[i];
		std::vector<int> help;
		while(a > 0) {
			help.push_back(a%2);
			a/=2;
		}
		while(help.size() < 10) help.push_back(0);
		int pp = 0;
		if(fl[B[i]] == 0) fl[B[i]] = 1;
		else
			pp = 10;
		for(j=1;j<=help.size();j++)
			setHint(B[i], j+pp, help[j-1]);
		help.erase(help.begin(), help.end());
		while(b > 0) {
			help.push_back(b%2);
			b/=2;
		}
		while(help.size() < 10) help.push_back(0);
		pp = 0;
		if(fl[A[i]] == 0) fl[A[i]] = 1;
		else
			pp = 10;
		for(j=1;j<=help.size();j++)
			setHint(A[i], j+pp, help[j-1]);

	}
}

void speedrun(int subtask, int N, int start) {
	int i, tek = start;
	int rod[N+1];
	bool fl[N+1];
	int br = 1;
	for(i=1;i<=N;i++) fl[i] = 0;
	fl[start] = 1;
	fl[0] = 1;
	while(br < N) {
		//cout<<tek<<endl;
		int arg = 0, step = 1;
		for(i=1;i<=10;i++) {
			arg+= step*getHint(i);
			//cout<<getHint(i);
			step*=2;
		}
		//cout<<endl;
		int arg2 = 0;  step = 1;
		for(i=11;i<=20;i++) {
			arg2+= step*getHint(i);
			//cout<<getHint(i);
			step*=2;
		}
		//cout<<endl;
		//cout<<arg<<" "<<arg2<<endl;
		if(fl[arg] == 0)  {
			fl[arg] = 1; br++;
			rod[arg] = tek;
			tek = arg;
			goTo(tek);
		}
		else
		if(fl[arg2] == 0) {
			fl[arg2] = 1; br++;
			rod[arg2] = tek;
			tek = arg2;
			goTo(tek);
		}
		else
			goTo(rod[tek]), tek = rod[tek];
	}

}
