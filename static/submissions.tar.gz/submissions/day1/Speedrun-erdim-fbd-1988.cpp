/**
* user:  erdim-fbd
* fname: Yasmin Behich
* lname: Erdim
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 08:48:18.275741
*/
#include "speedrun.h"


void assignHints(int subtask, int N, int A[], int B[]) {
	setHintLen(N);
	int i;
	for(i=1;i<N;i++) {
		setHint(A[i], B[i], 1);
		setHint(B[i], A[i], 1);
	}
}

void speedrun(int subtask, int N, int start) {
	int rod[N+1];
	bool fl[N+1];
	int i, tek = start, br = 1;
	for(i=1;i<=N;i++) fl[i] = 0;
	fl[start] = 1;
	while(br < N) {
		for(i=1;i<=N;i++) {
			if(fl[i] == 0)  {
				if(getHint(i) == 1)  {
					fl[i] = 1; br++;
					rod[i] = tek;
					tek = i;
					goTo(i);
					break;
				}
			}
		}
		if(i == N+1) goTo(rod[tek]), tek = rod[tek];
	}

}
