/**
* user:  cristian-6b3
* fname: Cristea
* lname: Cristian
* task:  Gardening
* score: 11.0
* date:  2021-12-16 11:42:23.910794
*/
#include <iostream>
#include <vector>
#include <cstring>

using namespace std;
vector < vector <int> > v;
int lin, col;
int solve(int x1, int y1, int x2, int y2, int flower, int k)
{
    if(flower > k)
        return 0;
    int cnt = flower, i , j;
    if((x2 - x1 + 1) % 2 == 0 && (y2 - y1 + 1) % 2 == 0 && (x2 - x1 + 1) / 2 * (y2 - y1 + 1) / 2 <= k - flower + 1)
    {
        for(i = x1; i <= x2; i += 2)
        {
            for(j = y1; j <= y2; j += 2)
            {
                v[i][j] = v[i+1][j] = v[i][j+1] = v[i+1][j+1] = cnt;
                cnt++;
            }
        }
        lin = (x2 - x1 + 1) / 2;
        col = (y2 - y1 + 1) / 2;
        if(cnt  - 1 != k)
            return 0;
        return 1;
    }
    else
    {
        for(i = x1; i <= x2; i++)
            v[i][y1] = v[i][y2] = cnt;
        for(j = y1; j <= y2; j++)
            v[x1][j] = v[x2][j] = cnt;
        cnt++;
        solve(x1+1, y1+1, x2-1, y2-1, cnt, k);
    }
}
int main()
{
    int t, n, m, k, i, j, cnt;
    cin >> t;
    while(t--)
    {
        cin >> n >> m >> k;
        if(n % 2 || m % 2 || k > n * m)
        {
            cout << "NO\n";
            continue;
        }
        v.resize(n+1);
        for(i = 1; i <= n; i++)
        {
            for(j = 0; j <= m; j++)
                v[i].push_back(0);
            if(v[i].size() <= m)
                cout << 1/ 0;
        }
        if(n == 4)
        {
            if(2 * (m - k) > m || k > m)
            {
                cout << "NO\n";
                continue;
            }
            if(1 <= n && 1 <= 2 * (m - k) && !solve(1, 1, n, 2 * (m - k), 1, m - k))
            {
                cout << "NO\n";
                continue;
            }
            cnt = m - k + 1;
            for(i = 1; i <= n; i += 2)
            {
                for(j = 2 * (m - k) + 1; j <= m; j += 2)
                {
                    v[i][j] =  v[i+1][j] = v[i][j+1] = v[i+1][j+1] = cnt;
                    cnt++;
                }
            }
            cout << "YES\n";
            for(i = 1; i <= n; i++)
            {
                for(j = 1; j <= m; j++)
                    cout << v[i][j] << ' ';
                cout << '\n';
            }
            continue;
        }
        if(n == 6)
        {
            int check = 1;
            for(i = 2; i <= m && check; i++)
            {
                for(j = 1; j <= k && check; j++)
                {
                    if(solve(1, 1, n, i, 1, j) && solve(1, i + 1, n, m, j + 1, k))
                    {
                        cout << "YES\n";
                        for(int i1 = 1; i1 <= n; i1++)
                        {
                            for(int j1 = 1; j1 <= m; j1++)
                                cout << v[i1][j1] << ' ';
                            cout << '\n';
                        }
                        check = 0;
                    }
                }
            }
            if(check)
            {
                    if(solve(1, 1, n, m, 1, k))
                    {
                         cout << "YES\n";
                        for(i = 1; i <= n; i++)
                        {
                            for(j = 1; j <= m; j++)
                                cout << v[i][j] << ' ';
                            cout << '\n';
                        }
                        continue;
                    }
                    if(k > m / 2)
                        k -= m / 2;
                    else
                    {
                        cout << "NO\n";
                        continue;
                    }
                    if(2 * (m - k) > m || k > m)
                    {
                        cout << "NO\n";
                        continue;
                    }
                    if(1 <= n - 2 && 1 <= 2 * (m - k) && !solve(1, 1, n - 2, 2 * (m - k), 1, m - k))
                    {
                        cout << "NO\n";
                        continue;
                    }
                    cnt = m - k + 1;
                    for(i = 1; i <= n - 2; i += 2)
                    {
                        for(j = 2 * (m - k) + 1; j <= m; j += 2)
                        {
                            v[i][j] =  v[i+1][j] = v[i][j+1] = v[i+1][j+1] = cnt;
                            cnt++;
                        }
                    }
                    for(j = 1; j <= m; j += 2)
                    {
                        v[n-1][j] = v[n][j] = v[n][j+1] = v[n-1][j+1] = cnt;
                        cnt++;
                    }
                    cout << "YES\n";
                    for(i = 1; i <= n; i++)
                    {
                        for(j = 1; j <= m; j++)
                            cout << v[i][j] << ' ';
                        cout << '\n';
                    }
            }
            continue;
        }
        if(solve(1, 1, n, m, 1, k))
        {
            cout << "YES\n";
            for(i = 1; i <= n; i++)
            {
                for(j = 1; j <= m; j++)
                    cout << v[i][j] << ' ';
                cout << '\n';
            }
        }
        else
            cout << "NO\n";

    }
    return 0;
}
/*
1 1 1 1 1 1 6 6 6 6
1 2 2 3 3 1 6 7 7 6
1 2 2 3 3 1 6 7 7 6
1 4 4 5 5 1 6 8 8 6
1 4 4 5 5 1 6 8 8 6
1 1 1 1 1 1 6 6 6 6
*/
