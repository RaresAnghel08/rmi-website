/**
* user:  kozhuharov-9a5
* fname: Viktor
* lname: Kozhuharov
* task:  restore
* score: 38.0
* date:  2019-10-10 06:12:04.322346
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXM = 1e4 + 7;

array<int, 4> c[MAXM];//l, r, k, value
int ans[MAXM];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;

    cin >> n >> m;

    for(int i = 0; i < n; ++i){
        ans[i] = 2;
    }

    for(int i = 0; i < m; ++i){
        cin >> c[i][0] >> c[i][1] >> c[i][2] >> c[i][3];
    }

    sort(c, c + m);

    for(int i = 0; i < m; ++i){
        if(c[i][2] == 1){
            if(c[i][3] == 1){
                for(int j = c[i][0]; j <= c[i][1]; ++j){
                    if(!ans[j]){
                        cout << "-1\n";
                        return 0;
                    }
                    ans[j] = 1;
                }
            }
            continue;
        }
        if(c[i][2] == c[i][1] - c[i][0] + 1){
            if(c[i][3] == 0){
                for(int j = c[i][0]; j <= c[i][1]; ++j){
                    if(ans[j] == 1){
                        cout << "-1\n";
                        return 0;
                    }
                    ans[j] = 0;
                }
            }
            continue;
        }
    }

    for(int i = 0; i < m; ++i){
        if(c[i][2] == 1){
            if(c[i][3] == 0){
                bool ok = false;
                for(int j = c[i][0]; j <= c[i][1]; ++j){
                    if(ans[j] == 0){
                        ok = true;
                        break;
                    }
                }
                if(ok){
                    continue;
                }
                for(int j = c[i][0]; j <= c[i][1]; ++j){
                    if(ans[j] == 2){
                        ans[j] = 0;
                        ok = true;
                        break;
                    }
                }
                if(!ok){
                    cout << "-1\n";
                    return 0;
                }
            }
            continue;
        }
        if(c[i][2] == c[i][1]- c[i][0] + 1){
            if(c[i][3] == 1){
                bool ok = false;
                for(int j = c[i][0]; j <= c[i][1]; ++j){
                    if(ans[j] == 1){
                        ok = true;
                        break;
                    }
                }
                if(ok){
                    continue;
                }
                for(int j = c[i][0]; j <= c[i][1]; ++j){
                    if(ans[j] == 2){
                        ans[j] = 1;
                        ok = true;
                        break;
                    }
                }
                if(!ok){
                    cout << "-1\n";
                    return 0;
                }
            }
        }
    }

    for(int i = 0; i < n; ++i){
        if(ans[i] == 2){
            ans[i] = 0;
        }
    }

    for(int i = 0; i < n; ++i){
        cout << ans[i] << " ";
    }

    return 0;
}
