/**
* user:  taga-9e5
* fname: Ștefan
* lname: Țaga
* task:  Speedrun
* score: 63.0
* date:  2021-12-16 09:19:29.238736
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;
int gr[1005],tata[1005];
vector <int> vec[1005];
void dfs(int x,int dad)
{
    tata[x]=dad;
    for (int i=0;i<vec[x].size();i++)
    {
        if (vec[x][i]!=dad)
        {
            dfs(vec[x][i],x);
        }
    }
}
void update(int st,int dr,int x,int y)
{
    int i;
    for (i=st;i<=dr;i++)
    {
        if (y&(1<<(i-st)))
        {
            setHint(x,i,1);
        }
    }
}
void assignHints(int subtask, int n, int A[], int B[]) {
    setHintLen(30);
    int i,poz,j,k;
    for (i=1;i<n;i++)
    {
        vec[A[i]].push_back(B[i]);
        vec[B[i]].push_back(A[i]);
    }
    dfs(1,0);
    for (i=2;i<=n;i++)
    {
        update(1,10,i,tata[i]);
    }
    for (i=2;i<=n;i++)
    {
        for (j=0;j<vec[i].size();j++)
        {
            if (vec[i][j]==tata[i])
            {
                poz=j;
            }
        }
        vec[i].erase(vec[i].begin()+poz);
    }
    for (i=1;i<=n;i++)
    {
        if (vec[i].size()>0)
        {
            update(11,20,i,vec[i][0]);
        }
        int lim=(int)vec[i].size();
        for (j=0;j<lim-1;j++)
        {
            update(21,30,vec[i][j],vec[i][j+1]);
        }
    }
}
int tatasped()
{
    int sum=0,j;
    for (j=1;j<=10;j++)
    {
        if (getHint(j)==1)
        {
            sum=sum+(1<<(j-1));
        }
    }
    return sum;
}
int subpr()
{
    int sum=0,j;
    for (j=11;j<=20;j++)
    {
        if (getHint(j)==1)
        {
            sum=sum+(1<<(j-11));
        }
    }
    return sum;
}
int urm()
{
    int sum=0,j;
    for (j=21;j<=30;j++)
    {
        if (getHint(j)==1)
        {
            sum=sum+(1<<(j-21));
        }
    }
    return sum;
}
void dfssped(int x)
{
    int val=subpr();
    vector <int> ceau;
    if (val!=0)
    {
        while (val)
        {
            ceau.push_back(val);
            goTo(val);
            int urmatorul=urm();
            goTo(x);
            val=urmatorul;
        }
    }
    for (int i=0;i<ceau.size();i++)
    {
        goTo(ceau[i]);
        dfssped(ceau[i]);
        goTo(x);
    }
}
void speedrun(int subtask, int N, int start) {
    int ceau=getLength();
    while (start!=1)
    {
        int val= tatasped();
        start=tatasped();
        goTo(start);
    }
    dfssped(start);
}

/* Input format:
 *
 * N -- number of nodes
 * a1 b1 -- edge 1
 * ...
 * a(N-1) b(N-1) -- edge N - 1
 * x -- start node
 */
#ifdef HOME
static map<int, map<int, bool>> mp;
static int length = -1;
static int queries = 0;
static bool length_set = false;
static int current_node = 0;
static set<int> viz;
static map<int, set<int>> neighbours;

void setHintLen(int l) {
    if (length_set) {
        cerr << "Cannot call setHintLen twice" << endl;
        exit(0);
    }
    length = l;
    length_set = true;
}

void setHint(int i, int j, bool b) {
    if (!length_set) {
        cerr << "Must call setHintLen before setHint" << endl;
        exit(0);
    }
    mp[i][j] = b;
}

int getLength() { return length; }

bool getHint(int j) { return mp[current_node][j]; }

bool goTo(int x) {
    if (neighbours[current_node].find(x) == end(neighbours[current_node])) {
        ++queries;
        return false;
    } else {
        viz.insert(current_node = x);
        return true;
    }
}

int main() {
    int N;
    cin >> N;

    int a[N], b[N];
    for (int i = 1; i < N; ++i) {
        cin >> a[i] >> b[i];
        neighbours[a[i]].insert(b[i]);
        neighbours[b[i]].insert(a[i]);
    }

    assignHints(1, N, a, b);

    if (!length_set) {
        cerr << "Must call setHintLen at least once" << endl;
        exit(0);
    }

    cin >> current_node;
    viz.insert(current_node);

    speedrun(1, N, current_node);

    if (viz.size() < N) {
        cerr << "Haven't seen all nodes" << endl;
        exit(0);
    }

    cerr << "OK; " << queries << " incorrect goto's" << endl;
    return 0;
}
#endif // HOME
