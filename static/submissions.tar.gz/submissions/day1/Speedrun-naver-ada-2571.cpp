/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 09:44:28.787235
*/
#include "speedrun.h"
#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
const int N=2010;
vector<int>g[N];
int p[N];
vector<int>order;
void dfs(int v,int pr){
    p[v]=pr;
    order.push_back(v);
    for (int to:g[v]){
        if (to!=pr){
            dfs(to,v);
        }
    }
}
void assignHints(int subtask, int n, int A[], int B[]) { /* your solution here */
    for (int i=1;i<n;i++){
        g[A[i]].push_back(B[i]);
        g[B[i]].push_back(A[i]);
    }
    dfs(1,0);
    setHintLen(20);
    order.push_back(0);
    for (int i=0;i+1<order.size();i++){
        for (int j=0;j<10;j++){
            if (p[order[i]]&(1<<j)){
                setHint(order[i],j+1,1);
            } else {
                setHint(order[i],j+1,0);
            }
        }
        for (int j=0;j<10;j++){
            if (order[i+1]&(1<<j)){
                setHint(order[i],j+11,1);
            } else {
                setHint(order[i],j+11,0);
            }
        }
    }
}

vector<int>g1[N];
int get_nxt(){
    int nxt=0;
    for (int i=0;i<10;i++){
        nxt^=(getHint(i+11)<<i);
    }
    return nxt;
}
int get_pr(){
    int pr=0;
    for (int i=0;i<10;i++){
        pr^=(getHint(i+1)<<i);
    }
    return pr;
}
void speedrun(int subtask, int n, int start) { /* your solution here */
    int l=getLength();
    while (start!=1){
        start=get_pr();
        goTo(start);
    }
    while (true){
        int nxt=get_nxt();
        if (nxt==0) return;
        while (true){
            bool cur=goTo(nxt);
            if (cur){
                start=nxt;
                break;
            }
            start=get_pr();
            goTo(start);
        }
    }

}
