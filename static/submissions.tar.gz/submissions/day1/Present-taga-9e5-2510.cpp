/**
* user:  taga-9e5
* fname: Ștefan
* lname: Țaga
* task:  Present
* score: 8.0
* date:  2021-12-16 09:38:50.896786
*/
#include <bits/stdc++.h>

using namespace std;
vector <vector <int>> ceau;
vector <int> sol;
int n;
void back1(int k)
{
    if (k>n)
    {
        int fr[11],i,j;
        for (i=0;i<=10;i++)
        {
            fr[i]=0;
        }
        for (j=0;j<sol.size();j++)
        {
            fr[sol[j]]++;
        }
        bool ok=1;
        for (i=0;i<sol.size();i++)
        {
            for (j=i+1;j<sol.size();j++)
            {
                if (fr[__gcd(sol[i],sol[j])]==0)
                {
                    ok=0;
                    break;
                }
            }
            if (ok==0)
            {
                break;
            }
        }
        if (ok==1)
        {
            ceau.push_back(sol);
        }
    }
    else
    {
        int start=1;
        if (k!=1)
        {
            start=sol[sol.size()-1]+1;
        }
        for (int i=start;i<=10;i++)
        {
            sol.push_back(i);
            back1(k+1);
            sol.pop_back();
        }
    }
}
bool compare (vector <int> &a,vector <int> &b)
{
    vector <int> copa,copb;
    if (a.size()==0)
    {
        return 1;
    }
    if (b.size()==0)
    {
        return 0;
    }
    if (a[a.size()-1]<b[b.size()-1])
    {
        return 1;
    }
    if (a[a.size()-1]>b[b.size()-1])
    {
        return 0;
    }
    copa=a;
    copb=b;
    copa.pop_back();
    copb.pop_back();
    return compare(copa,copb);
}
int i,j,t;
int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(0);
    #ifdef HOME
    ifstream cin("date.in");
    ofstream cout("date.out");
    #endif // HOME
    for (n=1;n<=8;n++)
    {
         sol.clear();
         back1(1);
    }
    sort (ceau.begin(),ceau.end(),compare);
    cin>>t;
    for (;t--;)
    {
        cin>>n;
        if (n>100)
        {
            cout<<"0"<<'\n';
            continue;
        }
        if (n==0)
        {
            cout<<"0"<<'\n';
            continue;
        }
        cout<<ceau[n-1].size()<<" ";
        for (int i=0;i<ceau[n-1].size();i++)
        {
            cout<<ceau[n-1][i]<<" ";
        }
        cout<<'\n';
    }
    return 0;
}
