/**
* user:  georgiev-51d
* fname: Aleksandar Petrov
* lname: Georgiev
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 10:27:50.859062
*/
#include<bits/stdc++.h>
#include "speedrun.h"

using namespace std;
int a[1010][1010];
int used[1010];
vector<int> g[1010];
int p[1010];
string tobin(int a)
{
    string res="";
    while(a)
    {
        if(a&1)res='1'+res;
        else res='0'+res;
        a/=2;
    }
    return res;
}
int todec(string s)
{
    int a=0;
    int pow=1<<s.size()-1;
    for(int i=0;i<s.size();i++)
    {
       a+=(s[i]-'0')*pow;
       pow>>=1;
    }
    return a;
}
void assignHints(int subtask, int N, int A[], int B[])
{
    if(subtask==1)
    {
    setHintLen(N);
    for(int i=1;i<N;i++)
    {
        a[A[i]][B[i]]=1;
        a[B[i]][A[i]]=1;
    }
    /*for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=N;j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<endl;
    }*/
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=N;j++)
        {
            if(a[i][j]==1)setHint(i,j,1);
        }
    }
    }
    if(subtask==2)
    {
        for(int i=1;i<N;i++)
        {
            g[A[i]].push_back(B[i]);
            g[B[i]].push_back(A[i]);
        }
        string p;
        if(g[1].size()==1)
        {
            p=tobin(g[1][0]);
            setHintLen(p.size());
        }
        else
        {
            p=tobin(1);
            setHintLen(p.size());
        }
        for(int i=1;i<=N;i++)
        {
            if(g[i].size()==1)
            {
                for(int j=0;j<p.size();j++)
                {
                    if(p[j]=='1')setHint(i,j+1,1);
                }
            }
        }
    }
}
void speedrun(int subtask, int N, int start)
{
    int n=getLength();
    int br=N;
    int vr=start;
    if(subtask==1)
    {
        while(br>=1)
        {
            bool t=0;
            //cout<<vr<<" "<<br<<endl;
            if(!used[vr])
            {
                used[vr]=1;
                br--;
                if(br==0)break;
                for(int i=1;i<=n;i++)
                {
                    a[vr][i]=getHint(i);
                }
            }
            for(int i=1;i<=n;i++)
            {
                if(a[vr][i]==1&&i!=p[vr])
                {
                    a[vr][i]=0;
                    p[i]=vr;
                    goTo(i);
                    vr=i;
                    t=1;
                    break;
                }
            }
            if(t==1)continue;
            //if(br==0||p[])break;
            goTo(p[vr]);
            vr=p[vr];
        }
    }
    else if(subtask==2)
    {
            if(getHint(1))
            {
                string s="";
                for(int i=1;i<=n;i++)
                {
                    s+=char(getHint(i)+'0');
                }
                int nvr=todec(s);
                goTo(nvr);
                for(int i=1;i<=N;i++)
                {
                    if(i!=nvr){goTo(i);goTo(nvr);}
                }
                //cout<<nvr<<endl;
            }
            else
            {
                for(int i=1;i<=N;i++)
                {
                    if(i!=vr){goTo(i);goTo(vr);}
                }
            }
    }
}
