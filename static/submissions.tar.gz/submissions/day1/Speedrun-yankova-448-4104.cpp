/**
* user:  yankova-448
* fname: Denitsa Marinova
* lname: Yankova
* task:  Speedrun
* score: 29.0
* date:  2021-12-16 11:57:16.840484
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;

pair<int,int> nboor[1010];

void from10to2(int edge, int x, int pos)
{
    string s="";
    while(x!=0)
    {
        s+=(x%2+'0');
        x/=2;
    }
    int sz=s.size();
    for(int i=1;i<=10-sz;i++)
    {
        s+='0';
    }
    for(int i=s.size()-1;i>=0;i--)
    {
        if(s[i]=='1') setHint(edge,pos,true);
        pos++;
    }
}

void from2to10(int edge)
{
    int x=0, d=1;
    for(int i=20;i>=11;i--)
    {
        if(getHint(i)==true) x+=d;
        d*=2;
    }
    int y=0;
    d=1;
    for(int i=10;i>=1;i--)
    {
        if(getHint(i)==true) y+=d;
        d*=2;
    }
    nboor[edge].first=x;
    nboor[edge].second=y;
}

void assignHints(int subtask, int N, int A[], int B[])
{
    if(subtask==2)
    {
        int v;
        if(A[1]==A[2]) v=A[1];
        else if(A[1]==B[2]) v=A[1];
        else if(B[1]==B[2]) v=B[1];
        else if(B[1]==A[2]) v=B[1];
        setHintLen(1);
        setHint(v,1,1);
    }
    else if(subtask==1)
    {
        setHintLen(N);
        for(int i=1;i<N;i++)
        {
            setHint(A[i],B[i],1);
            setHint(B[i],A[i],1);
        }
    }
    else
    {
        int us[1010];
        setHintLen(20);
        for(int i=1;i<N;i++)
        {
            if(!us[B[i]])
            {
                from10to2(B[i], A[i], 1);
            }
            else
            {
                from10to2(B[i], A[i], 11);
            }
            if(!us[A[i]])
            {
                from10to2(A[i], B[i], 1);
            }
            else
            {
                from10to2(A[i], B[i], 11);
            }
            us[A[i]]=1;
            us[B[i]]=1;
        }
    }
}

int used[1010];

void DFS(int i, int n)
{
    used[i]=1;
    for(int j=1;j<=n;j++)
    {
        if(getHint(j)==true)
        {
            if(!used[j])
            {
                goTo(j);
                used[j]=1;
                DFS(j,n);
                goTo(i);
            }
        }
    }
}

void DFS(int i)
{
    used[i]=1;
    from2to10(i);
    if(!used[nboor[i].first])
    {
        goTo(nboor[i].first);
        DFS(nboor[i].first);
        goTo(i);
    }
    else if(nboor[i].second!=0)
    {
        goTo(nboor[i].second);
        DFS(nboor[i].second);
        goTo(i);
    }
}

void speedrun(int subtask, int N, int start)
{
    if(subtask==2)
    {
        int length=getLength();
        int v;
        if(getHint(1))
        {
            v=start;
        }
        else
        {
            for(int i=1;i<=N;i++)
            {
                if(i!=start&&goTo(i)==true)
                {
                    v=i;
                    break;
                }
            }
        }
        for(int i=1;i<=N;i++)
        {
            if(i!=v)
            {
                goTo(i);
                goTo(v);
            }
        }
    }
    else if(subtask==1)
    {
        int length=getLength();
        DFS(start,N);
    }
    else
    {
        int legth=getLength();
        DFS(start);
    }
}
