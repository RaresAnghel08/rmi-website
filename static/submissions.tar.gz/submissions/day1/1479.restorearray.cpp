/**
* user:  casarin-262
* fname: Filippo
* lname: Casarin
* task:  restore
* score: 13.0
* date:  2019-10-10 06:54:51.288771
*/
#include "bits/stdc++.h"

#define MAXN 5000
#define MXAM 10000

typedef std::pair<int, int> ii;
typedef std::vector<int> vi;
typedef std::vector<ii> vii;

bool A[MAXN];

int main() {
	int N, M;
	scanf("%d %d", &N, &M);

	for (int i=0; i<N; i++)
		A[i] = 0;

	for (int i=0; i<M; i++) {
		int L, R, K, V;
		scanf("%d %d %d %d", &L, &R, &K, &V);

		if (V) {
			for (int j=L; j<=R; j++)
				A[j] = 1;
		} else {
			bool ok = false;
			for (int j=L; j<=R && !ok; j++)
				if (!A[j])
					ok = true;

			if (!ok) {
				printf("-1\n");
				exit(0);
			}
		}
	}

	for (int i=0; i<N; i++)
		printf("%d ", A[i]);
	printf("\n");
}

