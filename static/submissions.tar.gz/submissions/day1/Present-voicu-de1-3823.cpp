/**
* user:  voicu-de1
* fname: Mihai Valeriu
* lname: Voicu
* task:  Present
* score: 0.0
* date:  2021-12-16 11:39:38.080077
*/
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>

using namespace std;
//#ifdef LOCAL
//const int nbit=15;
//#else
const int nbit=25;
//#endif
bool dp[(1<<nbit)+1];
int resp[5];

static int popcount(int k) {
  int cnt=0;
  while(k) {
    cnt++;
    k&=k-1;
  }
  return cnt;
} 
int index=0;

static void testcase() {
  int temp=resp[index++];
  cout << popcount(temp) <<' ';
  
  for(int i=0; i<nbit; i++) {
    if((1<<i)&temp)
      cout << i+1 << ' ';
  }
  cout << '\n';
  //cout << "teapa";
}
//int bit[21]={1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,20,21,22,24,25};
int main() {
  int t,cnt=0;
  cin >> t;
  int k[5];
  for(int i=0; i<t; i++)
    cin >> k[i];
  dp[0]=1;
  //list.push_back(0);
  for(int i=1; i<(1<<nbit); i++) {
    int last=0,ok=1;
    for(int j=0; j<nbit; j++) {
      if(i&(1<<j))
        last=j;
    }
    for(int j=0; j<nbit; j++) {
      if(!((1<<(__gcd(j+1,last+1)-1))&i) && ((1<<j)&i))
        ok=0;
    }
    dp[i]=(dp[i^(1<<last)]&ok);
    if(dp[i]) {
      cnt++;
      for(int j=0; j<5; j++)
        if(k[j]==cnt)
          resp[j]=i;
    }
  }
  while(t--)
    testcase();
}
