/**
* user:  asadullin-bba
* fname: Aidar Ildarovich
* lname: Asadullin
* task:  Gardening
* score: 100.0
* date:  2021-12-16 10:49:53.381226
*/
#include <bits/stdc++.h>

using namespace std;

vector<vector<int>> f(int n, int m, int k) {
    if (n * m / 4 - 1 == k || n * m / 4 < k || k <= 0) {
        return {};
    }
    if (m == 2) {
        if (k != n / 2) {
            return {};
        }
        vector<vector<int>> ans(n, vector<int>(m));
        for (int i = 0; i < n / 2; ++i) {
            ans[i * 2][0] = i + 1;
            ans[i * 2 + 1][0] = i + 1;
            ans[i * 2][1] = i + 1;
            ans[i * 2 + 1][1] = i + 1;
        }
        return ans;
    }
    if (n == 2) {
        if (k != m / 2) {
            return {};
        }
        vector<vector<int>> ans(n, vector<int>(m));
        for (int i = 0; i < m / 2; ++i) {
            ans[0][i * 2] = i + 1;
            ans[0][i * 2 + 1] = i + 1;
            ans[1][i * 2] = i + 1;
            ans[1][i * 2 + 1] = i + 1;
        }
        return ans;
    }

    vector<vector<int>> op = f(n - 2, m - 2, k - 1);
    if (op.size() != 0) {
        vector<vector<int>> ans(n, vector<int>(m, 1));
        for (int i = 0; i < op.size(); ++i) {
            for (int j = 0; j < op[i].size(); ++j) {
                ans[i + 1][j + 1] = op[i][j] + 1;
            }
        }
        return ans;
    }
    op = f(n - 2, m, k - m / 2);
    if (op.size() != 0) {
        vector<vector<int>> ans(n, vector<int>(m, -1));
        for (int i = 0; i < op.size(); ++i) {
            for (int j = 0; j < op[i].size(); ++j) {
                ans[i][j] = op[i][j] + m / 2;
            }
        }
        for (int l = 0; l < m / 2; ++l) {
            ans[n - 2][l * 2] = l + 1;
            ans[n - 2][l * 2 + 1] = l + 1;
            ans[n - 1][l * 2] = l + 1;
            ans[n - 1][l * 2 + 1] = l + 1;
        }
        return ans;
    }
    op = f(n, m - 2, k - n / 2);
    if (op.size() != 0) {
        vector<vector<int>> ans(n, vector<int>(m, -1));
        for (int i = 0; i < op.size(); ++i) {
            for (int j = 0; j < op[i].size(); ++j) {
                ans[i][j] = op[i][j] + n / 2;
            }
        }
        for (int l = 0; l < n / 2; ++l) {
            ans[l * 2][m - 2] = l + 1;
            ans[l * 2 + 1][m - 2] = l + 1;
            ans[l * 2][m - 1] = l + 1;
            ans[l * 2 + 1][m - 1] = l + 1;
        }
        return ans;
    }
    return {};
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
    cout.tie();
#ifdef foo
    freopen("input.txt", "r", stdin);
#endif
    int T;
    cin >> T;
    for (int i = 0; i < T; ++i) {
        int n, m, k;
        cin >> n >> m >> k;
        if (n % 2 == 1 || m % 2 == 1) {
            cout << "NO\n";
            continue;
        }
        auto x = f(n, m, k);
        if (x.size() == 0) {
            cout << "NO\n";
        } else {
            cout << "YES\n";
            for (int j = 0; j < x.size(); ++j) {
                for (int l = 0; l < x[j].size(); ++l) {
                    cout << x[j][l] << " ";
                }
                cout << "\n";
            }
        }
    }
}