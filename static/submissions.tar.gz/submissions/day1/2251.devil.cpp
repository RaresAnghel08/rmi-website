/**
* user:  shekhovtsov-1b3
* fname: Alexandar
* lname: Shekhovtsov
* task:  devil
* score: 14.0
* date:  2019-10-10 08:49:14.527278
*/
#include "bits/stdc++.h"

#define pb push_back
#define mp make_pair
#define mt make_tuple
#define x first
#define y second
#define len(v) ((int)v.size())

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;


template<class T>
ostream &operator<<(ostream &os, const vector<T> &v) {
	for (const T &x : v) {
		os << x << " ";
	}
	return os;
}

template<class A, class B>
ostream &operator<<(ostream &os, const pair<A, B> &p) {
	os << p.x << " " << p.y;
	return os;
}

string append(string s, char c) {
	s.pb(c);
	return s;
}

void solve() {
	int k;
	cin >> k;
	vector<int> c(9);
	for (int i = 0; i < 9; i++)
		cin >> c[i];	
	string s;
	for (int i = 0; i < 9; i++) {
		for (int j = 0; j < c[i]; j++) {
			s.pb((char)i + '1');
		}
	}
	sort(s.begin(), s.end());
	string final(len(s), '.');
	int i = 0;
	int j = len(s) - 1;
	for (int p = 0; p < len(final); p += 2) {
		final[p] = s[j--];
		if (p + 1 < len(final)) {
			final[p + 1] = s[i++];
		}
	}	
	reverse(final.begin(), final.end());
	cout << final << endl;
}

signed main(int argc, char const *argv[]) {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int tests;
	cin >> tests;
	for (int test = 0; test < tests; test++) 
		solve();
}