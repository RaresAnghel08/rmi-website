/**
* user:  linhart-f5e
* fname: Yoav
* lname: Linhart
* task:  Present
* score: 0.0
* date:  2021-12-16 10:43:09.749674
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <queue>

#define upmin(a, b) if(a > b) a = b
#define upmax(a, b) if(a < b) a = b
#define pr(x) cout << x << endl
#define spr(x) cout << x << " "
#define wpr(x) cout << #x << ": " << x << endl
#define wprv(x) cout << #x << ": " << endl; for(auto it : x) cout << it << " "; cout << endl;
#define wprvv(x) cout << #x << ": " << endl; for(auto it : x) { for(auto it2 : it) cout << it2 << " "; cout << endl;}
#define rep(i, s, e) for(ll i = s; i < e; i++)
#define repr(i, s, e) for(ll i = e - (ll)1; i >= s; i--)


using namespace std;

using ll = int;
using vll = vector<ll>;
using vvll = vector<vll>;
using vvvll = vector<vvll>;
using pll = pair<ll, ll>;
using vpll = vector<pll>;
using vvpll = vector<vpll>;
using vb = vector<bool>;
using vi = vector<int>;

/*

{},
{1},
{2}, {1, 2},
{3}, {1, 3}, {1, 2, 3},
{4}, {1, 4}, {2, 4}, {1, 2, 4}, {1, 2, 3, 4}
{5}, {1, 5}, {1, 2, 5}, {1, 3, 5}, {1, 4, 5}, {1, 2, 3, 5}, {1, 3, 4, 5}, {1, 2, 3, 4, 5}
{6},
{1, 6}, {2, 6}, {3, 6},
{1, 2, 6}, {1, 3, 6}, {1, 5, 6}, {2, 4, 6},
{1, 2, 3, 6}, {1, 2, 4, 6}, {1, 2, 5, 6}
{1, 2, 3, 4, 6}, {1, 2, 3, 5, 6}, {1, 2, 4, 5, 6},
{1, 2, 3, 4, 5, 6}

0: 1
1: 1
2: 2
3: 3
4: 5
5: 8
6: 15

Fibonnaci?!
No :(


If the first is not 1, we can divide by it and get something we've already calculated.
Otherwise:
Take the next number.
If it
*/

/*

Solution:
A set is valid iff after sorting values:
each
*/


const ll sz = 24;
ll mgcd[sz + 1][sz + 1];

ll gcd(ll a, ll b)
{
	if (a < b) swap(a, b);
	if (b == 0) return a;
	return gcd(a % b, b);
}
void prec_gcd()
{
	rep(i, 0, sz + 1) {
		rep(j, 0, sz + 1) {
			mgcd[i][j] = gcd(i, j);
		}
	}
}

vll done;

void prec()
{
	prec_gcd();
	vb have(sz, 0);

	rep(mask, 0, 1 << sz) {
		rep(j, 0, sz) {
			if ((mask >> j) & 1) have[j] = 1;
			else have[j] = false;
		}
		bool ok = true;
		rep(j1, 0, sz) {
			if (!ok) break;
			rep(j2, 0, sz) {
				if (have[j1] && have[j2] && (!have[mgcd[j1 + 1][j2 + 1] - 1])) {
					ok = false;
					break;
				}
			}
		}
		if (ok) {
			done.push_back(mask);
		}
	}
}

void solve()
{
	ll k;
	cin >> k;
	vll nums;
	rep(j, 0, sz) {
		if ((done[k] >> j) & 1) {
			nums.push_back(j + 1);
		}
	}
	//if (nums.size() == 0) nums.push_back(0);
	//wpr(nums.size());
	//wprv(nums);
	cout << nums.size() << " ";
	for (auto& v : nums) {
		cout << v << " ";
	}
	cout << endl;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	prec();
	ll test;
	cin >> test;
	while (test--) {
		solve();
	}

}