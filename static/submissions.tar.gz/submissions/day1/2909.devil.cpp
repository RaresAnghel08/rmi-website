/**
* user:  bartoli-2aa
* fname: Davide
* lname: Bartoli
* task:  devil
* score: 0.0
* date:  2019-10-10 10:12:46.857241
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<int>a(10);
int prossimo(){
    for(int i=9;i>0;i--){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
    return 0;
}
int primo(){
    for(int i=1;i<10;i++){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int T;
    cin>>T;
    while(T--){
        int K;
        cin>>K;
        fill(a.begin(),a.end(),0);
        int tot=0;
        for(int i=1;i<10;i++){
            cin>>a[i];
            tot+=a[i];
        }
        vector<int>sol(tot,0);
        for(int i=tot-1;i>tot-K;i--){
            sol[i]=prossimo();
        }
        sol[tot-K]=primo();
        tot-=K;
        bool p=0;
        if(a[1]<a[2]){
            p=1;
        }
        if(p==0){
            if(a[2]==0){
                for(int i=0;i<sol.size();i++){
                    if(sol[i]==0)sol[i]=primo();
                    cout<<sol[i];
                }
                cout<<'\n';
                continue;
            }
            int o=(int)(ceil((float)(tot)/a[2]));
            for(int i=0;i<tot;i+=o){
                sol[i]=prossimo();
            }
            for(int i=0;i<sol.size();i++){
                if(sol[i]==0)sol[i]=primo();
                cout<<sol[i];
            }
            cout<<'\n';
        }else{
            if(a[1]==0){
                for(int i=0;i<sol.size();i++){
                    if(sol[i]==0)sol[i]=prossimo();
                    cout<<sol[i];
                }
                cout<<'\n';
                continue;
            }
            int o=(int)(ceil((float)(tot)/(a[1])));
            for(int i=o/2;i<tot;i+=o){
                sol[i]=primo();
            }
            for(int i=0;i<sol.size();i++){
                if(sol[i]==0)sol[i]=prossimo();
                cout<<sol[i];
            }
            cout<<'\n';
        }
    }
    return 0;
}
