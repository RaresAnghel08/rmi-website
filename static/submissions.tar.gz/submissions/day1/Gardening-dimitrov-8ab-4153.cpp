/**
* user:  dimitrov-8ab
* fname: Atanas
* lname: Dimitrov
* task:  Gardening
* score: 21.0
* date:  2021-12-16 11:59:19.624607
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl "\n"
template<class T, class T2> bool chkmin(T &a, const T2 &b) {return (a > b) ? a = b, 1 : 0;}
template<class T, class T2> bool chkmax(T &a, const T2 &b) {return (a < b) ? a = b, 1 : 0;}
#ifndef LOCAL
#define cerr if(false)cerr
#endif // LOCAL

const int MAX_N = 2e5 + 10;
vector<int> tab[MAX_N];
int cnt = 0;

bool output(int startx, int starty, int n, int m, int k) {
    if(n * m == 0 && k == 0) {
        return true;
    }
    if(n * m == 0 && k != 0) {
        return false;
    }
    if(k < 0) {
        return false;
    }
    if(n != 2 && m != 2 && k >= (n + m - 4) / 2) {
        cnt ++;
        for(int i = 0; i < n; i ++) {
            tab[startx + i][starty] = tab[startx + i][starty + m - 1] = cnt;
        }
        for(int i = 0; i < m; i ++) {
            tab[startx][starty + i] = tab[startx + n - 1][starty + i] = cnt;
        }
        return output(startx + 1, starty + 1, n - 2, m - 2, k - (n + m - 4) / 2);
    } else {
        for(int i = 0; i < n; i += 2) {
            cnt ++;
            tab[startx + i][starty] = tab[startx + i][starty + 1] = tab[startx + i + 1][starty] = tab[startx + i + 1][starty + 1] = cnt;
        }
        return output(startx, starty + 2, n, m - 2, k);
    }
}

bool solvable4(int m, int x) {
    m /= 2;
    return x != (2 * x - 1);
}

bool solvable6(int m, int x) {
    return x != (3 * m - 1) && x != (2 * x - 2);
}

int n, m, k;

void solveLol() {

}

void solve() {
    if(n & 1 || m & 1) {
        cout << "NO" << endl;
        return;
    }
    if(n * m / 4 < k) {
        cout << "NO" << endl;
        return;
    }
    for(int i = 0; i < n; i ++) {
        tab[i].resize(m);
    }
    k = n * m / 4 - k;
    cnt = 0;
    if(n > 4 && m > 4 && output(1, 3, n - 2, m - 4, k - (n + m - 6) / 2)) {
        cout << "YES" << endl;
        cnt ++;
        for(int i = 0; i < n; i ++) {
            tab[i][2] = tab[i][m - 1] = cnt;
        }
        for(int i = 0; i < m; i ++) {
            tab[0][i] = tab[n - 1][i] = cnt;
        }
        for(int i = 0; i < n; i += 2) {
            cnt ++;
            tab[i][0] = tab[i + 1][0] = tab[i][1] = tab[i + 1][1] = cnt;
        }
        for(int i = 0; i < n; i ++) {
            for(int j = 0; j < m; j ++) {
                cout << tab[i][j] << " ";
            }
            cout << endl;
        }
        return;
    }
    cnt = 0;
    if(n != 2 && m != 2 && output(1, 1, n - 2, m - 2, k - (n + m - 4) / 2)) {
        cout << "YES" << endl;
        cnt ++;
        for(int i = 0; i < n; i ++) {
            tab[i][0] = tab[i][m - 1] = cnt;
        }
        for(int i = 0; i < m; i ++) {
            tab[0][i] = tab[n - 1][i] = cnt;
        }
        for(int i = 0; i < n; i ++) {
            for(int j = 0; j < m; j ++) {
                cout << tab[i][j] << " ";
            }
            cout << endl;
        }
        return;
    }
    cnt = 0;
    if(output(2, 0, n - 2, m, k)) {
        cout << "YES" << endl;
        for(int i = 0; i < m; i += 2) {
            cnt ++;
            tab[0][i] = tab[1][i] = tab[0][i + 1] = tab[1][i + 1] = cnt;
        }
        for(int i = 0; i < n; i ++) {
            for(int j = 0; j < m; j ++) {
                cout << tab[i][j] << " ";
            }
            cout << endl;
        }
        return;
    }
    cnt = 0;
    if(!output(0, 0, n, m, k)) {
        cout << "NO" << endl;
        return;
    }
    cout << "YES" << endl;
    for(int i = 0; i < n; i ++) {
        for(int j = 0; j < m; j ++) {
            cout << tab[i][j] << " ";
        }
        cout << endl;
    }
}

signed main() {
    //ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

    int t;
    cin >> t;
    while(t --) {
        cnt = 0;
        cin >> n >> m >> k;
        solve();
    }

    return 0;
}
