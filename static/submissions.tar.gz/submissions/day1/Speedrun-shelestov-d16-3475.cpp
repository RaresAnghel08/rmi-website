/**
* user:  shelestov-d16
* fname: Artem
* lname: Shelestov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:09:39.753208
*/
#include "speedrun.h"

void assignHints(int subtask , int n, int a[], int b[])
{
    if(subtask==1)
    {
        setHintLen(n);
        for(int i=0; i<n; i++)
        {
            setHint(a[i], b[i], 1);
            setHint(b[i], a[i], 1);
        }
    }
    else
    {
        int stepv[n]={0};
        setHintLen(1);
        for(int i=0; i<n; i++)
        {
            stepv[a[i]-1]++;
            stepv[b[i]-1]++;
        }
        for(int i=0; i<n; i++)
        {
            if(stepv[i]>1)  setHint(1, i+1, 1);
        }
    }
}

void dfs(int n, int v, bool *used)
{
    used[v-1]=true;
    for(int i=0; i<n; i++)
    {
        if(!(used[i]) && getHint(i+1))
        {
            goTo(i+1);
            dfs(n, i+1, used);
        }
    }
}

void speedrun(int subtask, int n, int start)
{
    bool used[n]={0};
    if(subtask==1)
    {
        dfs(n, start, used);
    }
    else
    {
        int ver;
        used[start-1]=true;
        if(getHint(1))
        {
            ver=start;
        }
        else
        {
            for(int i=0; i<n; i++)
            {
                if(i==start-1)    continue;
                goTo(i+1);
                if(getHint(1))
                {
                    ver=i+1;
                    break;
                }
            }
        }
        used[ver-1]=true;
        for(int i=0; i<n; i++)
        {
            if(!used[i+1])
            {
                goTo(i+1);
                used[i+1]=true;
                goTo(ver);
            }
        }
    }
}
