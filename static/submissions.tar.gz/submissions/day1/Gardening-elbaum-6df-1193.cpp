/**
* user:  elbaum-6df
* fname: Eitan
* lname: Elbaum
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:14:23.542056
*/
#include <iostream>
using namespace std;
int main(){
    int t,n,m,k; cin>>t;
    while(t--){
        cin>>n>>m>>k; //lines, columns, colors
        if(k > (n/2)*(m/2)) cout<<"NO\n";
        else{
            cout<<"YES\n";
            int arr[n][m];
            for(int i=0;i<n;i++){
                for(int j=0;j<m;j++){
                    arr[i][j] = 1;
                }
            }
            int p = 2;
            for(int i=0;2*i +1 < n && p<=k; i++){
                for(int j=0;2*j +1 < m && p<=k; j++){
                    arr[2*i][2*j] = arr[2*i +1][2*j] = arr[2*i][2*j +1]=arr[2*i +1][2*j +1]=p;
                    p++;
                }
            }
            if(n%2){
                for(int i=0;i<m;i++){
                    arr[n-1][i] = arr[n-2][i];
                }
            }
            if(m%2){
                for(int i=0;i<n;i++){
                    arr[i][m-1] = arr[i][m-2];
                }
            }
            for(int i=0;i<n;i++){
                for(int j=0;j<m;j++){
                    cout<<arr[i][j]<<' ';
                }cout<<'\n';
            }
        }
    }
    return 0;
}