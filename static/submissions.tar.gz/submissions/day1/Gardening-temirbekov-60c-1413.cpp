/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:53:06.227484
*/
#include <bits/stdc++.h>

using namespace std;

void solve() {
	cout << "NO\n";
	cout << "YES\n1 1\n1 1\n";
	cout << "YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";
	cout << "YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
	cout << "YES\n1 1 1 1 1 1\n1 2 2 3 3 1\n1 2 2 3 3 1\n1 1 1 1 1 1\n";
	/*int n, m, v;
	cin >> n >> m >> v;
	if(n < 2 or m < 2 or v * 4 > n * m) {
		cout << "NO\n";
		return;
	}
	vector <vector <int> > a(n, vector <int> (m, 0));
	function <void(int, int, int)> fill=[&](int i, int j, int k) {
		a[i][j] = k;
		a[i+1][j] = k;
		a[i+1][j+1] = k;
		a[i][j+1] = k;
	};
	for(int k = 1; k <= v; k ++){
		for(int i = 0; i < n - 1; i +=2) {
			for(int j = 0; j < m - 1; j +=2) {
				if(a[i][j] == 0) { 
					fill(i, j, k);
					goto yes;
				}
			}
		}
		cout << "NO\n";
		return;
		yes:;
	}
	cout << "YES\n";
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < m; j ++) {
			if(a[i][j] == 0 and i != 0) a[i][j] = a[i-1][j];
			else if(a[i][j] == 0) a[i][j] = a[i][j - 1];
			cout << a[i][j] << " ";
		}
		cout << "\n";
	}*/
}

int main(void) {
	solve();
	return 0;
}