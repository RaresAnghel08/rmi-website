/**
* user:  bachurski-d21
* fname: Jakub
* lname: Bachurski
* task:  lucky
* score: 28.0
* date:  2019-10-10 09:47:15.046590
*/
#ifdef EVAL
#pragma GCC optimize ("Ofast")
#pragma GCC target ("tune=native")
#endif
#include <bits/stdc++.h>

using namespace std;

using uint = unsigned;
const uint64_t MOD = 1e9 + 7;

struct matrix3
{
    uint64_t t[3][3];
    friend matrix3 operator* (const matrix3& b, const matrix3& a)
    {
        matrix3 c;
        for(size_t i = 0; i < 3; i++)
            for(size_t j = 0; j < 3; j++)
        {
            c.t[i][j] = 0;
            for(size_t k = 0; k < 3; k++)
                c.t[i][j] += a.t[i][k] * b.t[k][j];
            c.t[i][j] %= MOD;
        }
        return c;
    }
    matrix3& operator*= (const matrix3& o) { return *this = *this * o; }
};
const matrix3 IDENTITY = {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}};

matrix3 matt(const vector<uint>& A, size_t i)
{
    return {{
        {9, 8, (A[i] - (A[i-1] == 1 and A[i] > 3) - (A[i] > 1))},
        {1, 1, (A[i] > 1)},
        {0, 0, 1}
    }};
}

matrix3 matt_after13()
{
    return {{
        {9, 8, 0},
        {1, 1, 0},
        {0, 0, 1}
    }};
}

uint64_t calc(vector<uint> S)
{
    const size_t n = S.size() - 1;
    bool no13 = true;
    vector<pair<uint64_t, uint64_t>> W(n + 1);
    
    for(size_t i = 1; i <= n; i++)
    {
        W[i] = {
            (9*W[i-1].first + 8*W[i-1].second + no13*(S[i] - (S[i-1] == 1 and S[i] > 3) - (S[i] > 1))) % MOD,
            (W[i-1].first + W[i-1].second + no13*(S[i] > 1)) % MOD
        };
        cerr << i << ": " << W[i].first << "/" << W[i].second << endl;
        if(S[i-1] == 1 and S[i] == 3)
            no13 = false;
    }

    return (W.back().first + W.back().second + no13) % MOD;
}

uint64_t calc2(vector<uint> S)
{
    const size_t n = S.size() - 1;
    bool no13 = true;
    
    matrix3 M = IDENTITY;
    
    for(size_t i = 1; i <= n; i++)
    {
        if(no13)
            M *= matt(S, i);
        else
            M *= matt_after13();
        if(S[i-1] == 1 and S[i] == 3)
            no13 = false;
    }

    return (M.t[0][2] + M.t[1][2] + no13) % MOD;
}

struct segment_tree
{
    size_t w;
    vector<matrix3> T;
    segment_tree(size_t n)
    {
        w = 1 << __lg(2*n-1);
        T.resize(2 * w, IDENTITY);
    }
    
    void set(size_t i, matrix3 m)
    {
        i += w - 1;
        T[i] = m;
        i /= 2;
        while(i)
            T[i] = T[2*i] * T[2*i+1], i /= 2;
    }
    
    matrix3 get(size_t i, size_t nodeL, size_t nodeR, size_t getL, size_t getR)
    {
        if(nodeR < getL or getR < nodeL)
            return IDENTITY;
        else if(getL <= nodeL and nodeR <= getR)
            return T[i];
        else
            return get(2*i, nodeL, (nodeL+nodeR)/2, getL, getR) *
                   get(2*i+1, (nodeL+nodeR)/2+1, nodeR, getL, getR);
    }
    
    matrix3 get(size_t getL, size_t getR)
    {
        return get(1, 0,  w - 1, getL - 1, getR - 1);
    }
};

int main()
{
    ios::sync_with_stdio(false); cin.tie(nullptr);
    
    size_t n, q;
    cin >> n >> q;
    string S;
    cin >> S;
    
    vector<uint> A(n+2);
    for(size_t i = 1; i <= n; i++)
        A[i] = S[i-1] - '0';
    
    segment_tree T(n);
    for(size_t i = 1; i <= n; i++)
        T.set(i, matt(A, i));
    
    set<size_t> thirteens;

    auto get = [&](size_t l, size_t r) {
        auto m = T.get(l, r);
        return (m.t[0][2] + m.t[1][2] + 1) % MOD;
    };
    
    cout << get(1, n) << '\n';

    while(q --> 0)
    {
        size_t t, l, r;
        cin >> t >> l >> r;
        if(t == 1)
        {
            cout << get(l, r) << '\n';
        }
        else if(t == 2)
        {
            A[l] = r;
            T.set(l, matt(A, l));
            thirteens.erase(l);
            thirteens.erase(l-1);
            if(A[l-1] == 1 and A[l] == 3)
                thirteens.insert(l-1);
            if(A[l] == 1 and A[l+1] == 3)
                thirteens.insert(l);
        }
    }
}
