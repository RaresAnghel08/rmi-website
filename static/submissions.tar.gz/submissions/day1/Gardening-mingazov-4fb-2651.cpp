/**
* user:  mingazov-4fb
* fname: Artem
* lname: Mingazov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:52:54.314724
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;
void solve() {
    int n, m, k;
    cin >> n >> m >> k;
    int w = min(n, m), g = max(n, m);
    if (n % 2 || m % 2 || k * 4 > n * m || w == g && w / 2 > k || w != g && w / 2 - 1 + (g - w + 2) / 2 > k) {
        cout << "NO";
        return;
    }
    int ans[n][m], q = 1;
    if (n == 2) {
        if (m / 2 == k) {
            for (int j = 0; j < m; j += 2, q++) {
                ans[0][j] = q;
                ans[1][j] = q;
                ans[0][j + 1] = q;
                ans[1][j + 1] = q;
            }
        }
        else {
            cout << "NO";
            return;
        }
    }
    if (n == 4) {
        if (m == k) {
            for (int i = 0; i < n; i += 2) {
                for (int j = 0; j < m; j+= 2, q++) {
                    ans[i][j] = q;
                    ans[i + 1][j] = q;
                    ans[i][j + 1] = q;
                    ans[i + 1][j + 1] = q;
                }
            }
        }
        else if (m / 2 == k) {
            q = 2;
            for (int j = 1; j + 1 < m; j+= 2, q++) {
                ans[1][j] = q;
                ans[2][j] = q;
                ans[1][j + 1] = q;
                ans[2][j + 1] = q;
            }
            for (int j = 0; j < m; j++) {
                ans[0][j] = 1;
                ans[3][j] = 1;
            }
            ans[1][0] = 1;
            ans[2][0] = 1;
            ans[1][m - 1] = 1;
            ans[2][m - 1] = 1;
        }
        else {
            cout << "NO";
            return;
        }
    }
    cout << "YES\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << ans[i][j] << " ";
        }
        if (i != n - 1) {
            cout << "\n";
        }
    }
}
signed main() {
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    int t;
    cin >> t;
    while (t--) {
        solve();
        if (t) {
            cout << "\n";
        }
    }
}