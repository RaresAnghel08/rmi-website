/**
* user:  nagy-e76
* fname: Nándor
* lname: Nagy
* task:  devil
* score: 14.0
* date:  2019-10-10 08:41:12.202576
*/
#include <bits/stdc++.h>
using namespace std;

char ge(int x) {
    return x + '0';
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int test;
    cin>>test;
    for(int tc=0;tc<test;tc++) {
        int k;
        int d[10];
        cin>>k;
        int bigd = 0;
        for(int i=1;i<=9;i++) {
            cin>>d[i];
            if(d[i]>0) {
                bigd = i;
            }
        }
        string hat;
        int ld = 9;
        for(int i=0;i<k-1;i++) {
            while(d[ld]==0) {
                ld--;
            }
            hat.push_back(ge(ld));
            d[ld]--;
            while(d[ld]==0) {
                ld--;
            }
        }
        reverse(hat.begin(),hat.end());

        if(bigd < 3) {
            if(ld == 1) {
                for(int i=0;i<d[1];i++) {
                    cout<<1;
                }
                cout<<hat<<endl;
            }
            else {
                string kis="1";
                int k_db = d[1];
                string nagy="2";
                int n_db = d[2];
                while(k_db > 0) {
                    int u_db = min(n_db,k_db);
                    if(k_db <= n_db) {
                        swap(kis,nagy);
                        nagy = kis + nagy;
                        k_db = n_db-u_db;
                        n_db = u_db;
                    }
                    else {
                        nagy += kis;
                        k_db -= n_db;
                    }
                    if(kis > nagy) {
                        swap(kis,nagy);
                        swap(k_db,n_db);
                    }
                }
                for(int i=0;i<n_db;i++)  {
                    cout<<nagy;
                }
                cout<<hat<<endl;
            }

            continue;
        }

        while(d[ld]==0) {
            ld--;
        }
        string alap;
        alap.push_back(ge(ld));
        vector<string> tab(d[ld],alap);
        d[ld] = 0;
        int nd = 1;
        int st = 0;
        int nst = 0;
        int li;
        while(nd < 10) {
            for(int i = st; i < tab.size();i++) {
                while(nd < 10 && d[nd] == 0) {
                    nd++;
                    nst = i;
                }
                if(nd < 10)  {
                    tab[i].push_back(ge(nd));
                    d[nd]--;
                    li = i;
                }
            }
            while(nd < 10 && d[nd] == 0) {
                nd++;
            }
            st = nst;
        }

        if(k == 2) {
            for(int i=tab.size()-1;i>=0;i--) {
                cout<<tab[i];
            }
            cout<<hat<<endl;
            continue;
        }


        vector<string> veg;
        multiset<string> add;
        int lim = li + 1;
        if(li == tab.size()-1) {
            lim = st;
        }
        for(int i=0;i<tab.size();i++) {
            if(i < lim) {
                add.insert(tab[i]);
            }
            else {
                veg.push_back(tab[i]);
            }
        }
        while(add.size() > 0) {
            for(int i=0;i<veg.size();i++) {
                if(!add.empty()) {
                    auto it = add.begin();
                    veg[i] += (string)*it;
                    add.erase(it);

                }
            }
            sort(veg.begin(),veg.end());
            vector<string> uveg;
            for(string g:veg) {
                if(g != veg[veg.size()-1]) {
                    add.insert(g);
                }
                else {
                    uveg.push_back(g);
                }
            }
            swap(veg,uveg);
        }
        string sol;
        for(string g:veg) {
            sol += g;
        }
        sol+=hat;
        cout<<sol<<endl;
    }
    return 0;
}
