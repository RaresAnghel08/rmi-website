/**
* user:  salomon-bcd
* fname: Mayan
* lname: Salomon
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:02:48.609379
*/
#include "speedrun.h"
#include <bits/stdc++.h> 

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef pair<int, int> pii;
typedef vector<pii> vp;

vvi graph;
vp prehint;
int lastleaf = -1;
void dfs(int v, int p) {
	prehint[v].first = p;
	bool flag = true;
	for (int i = 0; i < graph[v].size(); i++) {
		int u = graph[v][i];
		if (u != p) {
			if (flag){
				flag = false;
				prehint[v].second = u;
			}
			else {
				prehint[lastleaf].second = u;
			}
			dfs(u,v);
		}
	}
	if (flag) {
		prehint[v].first = p;
		lastleaf = v;
	}
}

vb tobin(int x) {
	vb ans(10);
	vi pows = { 1,2,4,8,16,32,64,128,256,512 };
	for (int i = 9; i >= 0; i--) {
		if (x - pows[i] >= 0) {
			ans[i] = true;
			x -= pows[i];
		}
	}
	return ans;
}

// void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */

void assignHints(int subtask, int N, int A[], int B[]) {

	graph.resize(N+1);
	prehint.resize(N + 1);
	for (int i = 1; i <= N-1; i++) {
		graph[A[i]].push_back(B[i]);
		graph[B[i]].push_back(A[i]);
	}
	dfs(1,0);
	prehint[lastleaf].second = 1;
	setHintLen(20);
	for (int i = 1; i <= N; i++) {
		vb bin = tobin(prehint[i].first);
		for (int j = 0; j < 10; j++) {
			setHint(i, j, bin[j]);
		}
		bin = tobin(prehint[i].second);
		for (int j = 0; j < 10; j++) {
			setHint(i, 10+j, bin[j]);
		}
	}

}

int frombin(vb bin) {
	int ans = 0;
	vi pows = { 1,2,4,8,16,32,64,128,256,512 };
	for (int i = 9; i >= 0; i--) {
		if (bin[i]) {
			ans += pows[i];
		}
	}
	return ans;
}

pii currhint() {
	pii ans;
	vb bin(10);
	for (int j = 0; j < 10; j++) {
		bin[j] = getHint(j);
	}
	ans.first = frombin(bin);
	bin.clear();
	bin.resize(10);
	for (int j = 0; j < 10; j++) {
		bin[j] = getHint(10+j);
	}
	ans.second = frombin(bin);
	return ans;
}


void speedrun(int subtask, int N, int start) { /* your solution here */
	vb visited(N+1,false);
	vp hints(N+1,{-1,-1});
	// p,d
	int v = start;
	visited[v] = true;
	hints[v] = currhint();
	int u = hints[v].second;
	int counter = 1;
	while (counter!=N)
	{
		if (hints[v].first ==-1) {
			hints[v] = currhint();
		}
		if (!goTo(u)) {
			goTo(hints[v].first);
			v = hints[v].first;
		}
		else {
			v = u;
			if (hints[v].first == -1) {
				hints[v] = currhint();
			}
			u = hints[v].second;
		}
		if (!visited[v]) {
			visited[v] = true;
			counter++;
		}
	}


}
