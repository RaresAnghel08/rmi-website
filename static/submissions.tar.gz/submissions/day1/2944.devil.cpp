/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  devil
* score: 0.0
* date:  2019-10-10 10:17:10.686085
*/
#include <iostream>

using namespace std;

const int NMAX = 1e6 + 5;

int T, K, N, A[15], ans[NMAX], S[NMAX];

static inline bool Try (int d1, int d2)
{
    S[0] = 0;

    for(int i = 1; i <= 9; ++i)
        for(int j = 1; j <= A[i]; ++j)
            S[++S[0]] = i;

    int Mid = S[0] / 2;
    int Left = Mid - 1;
    int Right = Mid + 1;

    ans[1] = S[Mid];

    for(int i = 2; i <= N; ++i)
    {
        if(Left < 1)
        {
            ans[i] = S[Right];

            ++Right;

            continue;
        }

        if(Right > N)
        {
            ans[i] = S[Left];

            --Left;

            continue;
        }

        if(ans[i - 1] * 10 + S[Left] <= d1 * 10 + d2 && ans[i - 1] * 10 + S[Right] <= d1 * 10 + d2)
        {
            if(ans[i - 1] * 10 + S[Left] > ans[i - 1] * 10 + S[Right])
            {
                ans[i] = S[Left];

                --Left;
            }
            else
            {
                ans[i] = S[Right];

                ++Right;
            }
        }
        else
        {
            if(ans[i - 1] * 10 + S[Left] <= d1 * 10 + d2)
            {
                ans[i] = S[Left];

                --Left;
            }
            else
            {
                ans[i] = S[Right];

                ++Right;
            }
        }
    }

    for(int i = 2; i <= N; ++i)
        if(ans[i - 1] * 10 + ans[i] > d1 * 10 + d2)
            return false;

    return true;
}

int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> T;

    while(T--)
    {
        cin >> K;

        for(int i = 1; i <= 9; ++i)
        {
            cin >> A[i];

            N += A[i];
        }

        for(int d1 = 1; d1 <= 9; ++d1)
            for(int d2 = 1; d2 <= 9; ++d2)
            {
                if(!A[d1] || !A[d2])
                    continue;

                if(d1 == d2 && A[d1] == 1)
                    continue;

                if(Try(d1, d2))
                {
                    for(int i = 1; i <= N; ++i)
                        cout << ans[i];

                    cout << '\n';

                    d1 = d2 = 15;
                }
            }
    }

    return 0;
}
