/**
* user:  petkov-c95
* fname: Georgi Martinov
* lname: Petkov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:26:48.029909
*/
#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

const int MAXN = 6;

bool found = false;
int n, m, k;

int a[MAXN][MAXN];
int used[MAXN];

bool check()
{
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m; j++)
        {
            int s = 0;
            s += (a[i][j] == a[i-1][j]);
            s += (a[i][j] == a[i+1][j]);
            s += (a[i][j] == a[i][j-1]);
            s += (a[i][j] == a[i][j+1]);
            if (s != 2) return 0;
        }
    }

    return 1;
}

void rec(int r, int c)
{
    if (c == m+1) c = 1, r++;
    if (r == n+1)
    {
        for (int i = 1; i <= k; i++)
        {
            if (used[i] < 3) return;
        }
        bool ch = check();
        if (ch)
        {
            found = true;
        }
        return;
    }

    if (found) return;

    if (r > n || c > m) return;

    for (int i = 1; i <= k; i++)
    {
        if (used[i] > n*m-3*(k-1)) continue;

        int s = (a[r][c-1] == i) + (a[r-1][c] == i);

        if (used[i] && !s) continue;

        if (a[r][c-1] == i && a[r-1][c-1] == i && a[r][c-2] == i) continue;

        s = 0;

        s += (a[r-1][c-1] == i);
        s += (a[r-1][c+1] == i);
        s += (r > 2 && a[r-2][c] == i);

        if (a[r-1][c] == i && s >= 2) continue;

        used[i] += 1;

        a[r][c] = i;
        rec(r, c+1);

        used[i] -= 1;

        if (found) return;
    }
}

void solve()
{
    cin >> n >> m >> k;
    found = false;
    memset(a, 0, sizeof(a));
    memset(used, 0, sizeof(used));

    if (3*k <= n*m) rec(1, 1);

    if (!found) cout << "NO" << endl;
    else
    {
        cout << "YES" << endl;
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                cout << a[i][j] << " ";
            }
            cout << endl;
        }
    }
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t;
    cin >> t;
    while (t--) solve();

    return 0;
}
/**
5
2 2 2
2 2 1
4 4 4
4 4 2
4 6 3

*/
