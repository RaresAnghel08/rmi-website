/**
* user:  andreescu-960
* fname: Mihnea
* lname: Andreescu
* task:  devil
* score: 14.0
* date:  2019-10-10 06:13:25.738973
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

int f[11];

char cc(int i)
{
       return i+'0';
}

int main()
{
        ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

       /// freopen("input","r",stdin);

        int t;
        cin>>t;

        while(t--)
        {
                int k;
                cin>>k;
                /// k==2
                string sol;
                for(int i=1;i<=9;i++)
                        cin>>f[i];
                for(int i=9;i>=1;i--)
                        if(f[i])
                        {
                                sol+=cc(i);
                                f[i]--;
                                break;
                        }
                for(int i=9;i>=1;i--)
                        if(f[i])
                        {
                                /// i...cif, rev = cif...i
                                for(int cif=1;cif<i;cif++)
                                        while(f[cif] && f[i])
                                        {
                                                f[cif]--;
                                                f[i]--;
                                                sol+=cc(cif);
                                                sol+=cc(i);
                                        }
                        }
                for(int i=1;i<=9;i++)
                        while(f[i])
                        {
                                f[i]--;
                                sol+=cc(i);
                        }
                reverse(sol.begin(),sol.end());
                cout<<sol<<"\n";
        }


        return 0;
}
