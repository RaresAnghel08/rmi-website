/**
* user:  melnyk-1f2
* fname: Sofiia
* lname: Melnyk
* task:  restore
* score: 0.0
* date:  2019-10-10 06:25:04.029705
*/
#include<bits/stdc++.h>
using namespace std;

#define mp make_pair
#define ff first
#define ss second
#define pb push_back

const int N = 1e6 + 11;

int a[N],b[N],c[N];

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n,m;
    cin>>n>>m;
    vector<pair<int,pair<int,int> > > vv;
    for (int i=1; i<=n; i++)
        a[i]=-1;
    int mm=0;
    for (int i=1; i<=m; i++)
    {
        int l,r,k,t;
        cin>>l>>r>>k>>t;
        l++;
        r++;
        if (r-l+1==1)
        {
            if (a[l]!=-1&&a[l]!=t) return cout<<-1,0;
            a[l]=t;
        } else
        if (k==r-l+1&&t==0)
        {
            for (int j=l; j<=r; j++)
                if (a[j]==-1||a[j]==0) a[j]=0; else return cout<<-1,0;
        } else
        if (k==1&&t==1)
        {
            for (int j=l; j<=r; j++)
                if (a[j]==-1||a[j]==1) a[j]=1; else return cout<<-1,0;
        } else
        vv.pb(mp(l,mp(r,t)));
    }
    for (int i=0; i<vv.size(); i++)
    {
        int l=vv[i].ff;
        int r=vv[i].ss.ff;
        int t=vv[i].ss.ss;
        int tt=0,minpos=n+1;
        for (int p=l; p<=r; p++)
            if (a[p]==t) tt=1; else
            if (a[p]==-1) minpos=min(minpos,p);
        if (tt==0&&minpos==n+1) return cout<<-1,0; else
        if (tt==0) a[minpos]=tt;
    }
    for (int i=1; i<=n; i++)
        if (a[i]==-1) cout<<0; else cout<<a[i];

}
/**
4 4
0 1 2 1
2 2 1 0
0 1 1 0
1 2 1 0
**/
