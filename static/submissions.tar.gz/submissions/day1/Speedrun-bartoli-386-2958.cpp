/**
* user:  bartoli-386
* fname: Davide
* lname: Bartoli
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 10:22:55.948847
*/
#include <bits/stdc++.h>
#include "speedrun.h"
using namespace std;
#define ll long long
#define fi first
#define se second
#define pb push_back

void setNum(int pos,int val) {
    for(int i=0;; i++) {
        if((1<<i)>val)
            break;
        setHint( pos,  i+1, (val&(1<<i))>0);
    }
}
int L;
int readNum() {
    int ans=0;
    for(int i=0; i<L; i++) {
        if(getHint(i+1))
            ans+=(1<<i);
    }
    return ans;
}
vector<int> v[1010];
vector<int> par(1009);
vector<int> figli[1010];
void dfs(int pos,int prec) {
    for(int x:v[pos]) {
        if(x==prec)
            continue;
        figli[pos].pb(x);
        par[x]=pos;
        dfs(x,pos);
    }

}
void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    setHintLen(316);
    for(int i=1; i<N; i++) {
        v[A[i]].pb(B[i]);
        v[B[i]].pb(A[i]);
    }
    for(int i=1;i<=N;i++){
        for(int x:v[i]){
            if(x>316)continue;
            setHint(i,x,1);
        }
    }
}
bool vis[1010];
void dfs1(int pos,int prec) {
    vis[pos]=1;
    for(int i=1;i<=L;i++){
        if(i==prec || vis[i])continue;
        if(i<=316 && getHint(i)==0)continue;

        bool k=goTo(i);
        if(k==0)continue;
        dfs1(i,pos);
        goTo(pos);
    }

}
void speedrun(int subtask, int N, int start) { /* your solution here */
    L=getLength();
    dfs1(start,0);
}

