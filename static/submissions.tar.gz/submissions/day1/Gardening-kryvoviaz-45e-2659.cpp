/**
* user:  kryvoviaz-45e
* fname: Illia
* lname: Kryvoviaz
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:53:54.728474
*/
#include <bits/stdc++.h>

using namespace std;

int n, m, k;

/*int can[10][10][10];
int dfs(int n, int m, int k) {
    if (can[n][m][k] != -1)return can[n][m][k];

    if (k <= 0 && n <= 0 && m <= 0)return can[n][m][k] = true;
    if (n <= 1 || m <= 1)return can[n][m][k] = false;
    if (k == 1)return can[n][m][k] = (n == 2 && m == 2);

    if (n == 2)return can[n][m][k] = dfs(n, m - 2, k - 1);
    if (m == 2)return can[n][m][k] = dfs(n - 2, m, k - 1);


    can[n][m][k] = dfs(n - 2, m - 2, k - 1);
    if (n % 2 == 0 && k >= n/2)can[n][m][k] |= dfs(n, m - 2, k - (n / 2));
    if (m % 2 == 0 && k >= m/2)can[n][m][k] |= dfs(n - 2, m, k - (m / 2));
    return can[n][m][k];
}*/
void solve() {
    cin >> n >> m >> k;
    if (n % 2 != 0 || m % 2 != 0){cout << "NO\n";return;}
    if ((n / 2) * (m / 2) == k) {
        cout << "YES\n";
        vector<vector<int> > ans(n + 1, vector<int>(m + 1));
        int id = 1;
        for (int i = 1; i <= n; i += 2) {
            for (int j = 1; j <= m; j += 2) {
                ans[i][j] = id;
                ans[i+1][j] = id;
                ans[i][j+1] = id;
                ans[i+1][j+1] = id;
                id++;
            }
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++)
                cout << ans[i][j] << " ";
            cout << '\n';
        }
        return;
    }
    if (((n - 2) / 2) * ((m - 2) / 2) + 1 == k) {
        cout << "YES\n";
        vector<vector<int> > ans(n + 1, vector<int>(m + 1));
        for (int i = 1; i <= n; i++) {ans[i][1] = 1;ans[i][m] = 1;}
        for (int i = 1; i <= m; i++) {ans[1][i] = 1;ans[n][i] = 1;}
        int id = 2;
        for (int i = 2; i < n; i += 2) {
            for (int j = 2; j < m; j += 2) {
                ans[i][j] = id;
                ans[i+1][j] = id;
                ans[i][j+1] = id;
                ans[i+1][j+1] = id;
                id++;
            }
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++)
                cout << ans[i][j] << " ";
            cout << '\n';
        }
        return;
    }
    cout << "NO\n";
    //cout << (dfs(n, m, k) ? "YES\n" : "NO\n");
}

int T;
int main()
{
    //memset(can, -1, sizeof(can));
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}
