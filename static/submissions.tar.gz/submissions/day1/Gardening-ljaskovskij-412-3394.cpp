/**
* user:  ljaskovskij-412
* fname: Alexander
* lname: Ljaskovskij
* task:  Gardening
* score: 11.0
* date:  2021-12-16 11:01:24.751928
*/
#include<bits/stdc++.h>

using namespace std;

#define int ll

typedef long long ll;
typedef long double ld;

int cnt = 1;
int n, m, k;

bool check(vector<vector<int> > &sp, int i, int j, int sz) {
    sz *= 2;
    if (i + sz - 1 < n && j + sz - 1 < m) {
        if (sp[i][j] == 0 && sp[i + sz - 1][j] == 0 && sp[i][j + sz - 1] == 0 && sp[i + sz - 1][j + sz - 1] == 0) {
            return true;
        }
    }
    return false;
}

void color(vector<vector<int> > &sp, int ii, int jj, int di, int dj) {
    if (di == 2) {
        ///on many blocks!
        for (int j = jj; j + 1 < jj + dj; j += 2) {
            //cout << "color: " << ii << " " << jj << endl;
            sp[ii][j] = cnt;
            sp[ii + 1][j] = cnt;
            sp[ii][j + 1] = cnt;
            sp[ii + 1][j + 1] = cnt;
            ++cnt;
        }
    }
    else {
        for (int i = ii; i < ii + di; ++i) {
            sp[i][jj] = cnt;
            sp[i][jj + dj - 1] = cnt;
        }
        for (int j = jj; j < jj + dj; ++j) {
            sp[ii][j] = cnt;
            sp[ii + di - 1][j] = cnt;
        }
        ++cnt;
    }
}

void update(vector<vector<int> > &sp, int i, int j, int di, int dj) {
    for (int d = 0; d < di; ++d) {
        color(sp, i + d, j + d, (di - d) * 2, (dj - d) * 2);
    }
}

void solve() {
    cnt = 1;
    cin >> n >> m >> k;
    if (n % 2 == 1 || m % 2 == 1) {
        cout << "NO\n";
        return;
    }
    if (n * m / 4 - 1 == k) {
        cout << "NO\n";
        return;
    }
    bool sw = false;
    if (n > m) {
        sw = true;
        swap(n, m);
    }
    int j = 0;
    int now = n * m / 4 - k;
    //cout << "NOW = " << now << "\n";
    vector<vector<int> > sp(n, vector<int>(m));
    for (int di = n / 2; di >= 2; --di) {
        if (di > m / 2 - j) {
            //cout << "CONTINUE WITH: " << j << " " << di << "\n";
            continue;
        }
        int tmp;
        int dj = di;
        tmp = (di * di - di);
        if (tmp <= now) {
            ///try to extand!
            while(j + dj < m / 2 && tmp + di - 1 <= now) {
                ++dj;
                tmp += di - 1;
            }
        }
        if (tmp <= now) {
            update(sp, 0, j, di, dj);
            now -= tmp;
            j += dj;
        }
    }
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (sp[i][j] == 0) {
                sp[i][j] = cnt;
                sp[i][j + 1] = cnt;
                sp[i + 1][j] = cnt;
                sp[i + 1][j + 1] = cnt;
                ++cnt;
            }
        }
    }
    //cout << "NOW = " << now << "\n";
    if (now != 0) {
        cout << "NO\n";
        return;
    }
    cout << "YES\n";
    if (sw) {
        for (int j = 0; j < m; ++j) {
            for (int i = 0; i < n; ++i) {
                cout << sp[i][j] << " ";
            }
            cout << "\n";
        }
    }
    else {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                cout << sp[i][j] << " ";
            }
            cout << "\n";
        }
    }
    /*
    vector<int> d;
    vector<vector<int> > sp(n, vector<int>(m));
    for (int x = 1; x * x - x <= now; ++x) {
        d.push_back(x * x - x);
    }
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (sp[i][j] != 0) {
                continue;
            }
            for (int sz = d.size() - 1; sz >= 0; --sz) {
                if (now - d[sz] < 0) {
                    continue;
                }
                cout << "IN: " << i << " " << j << "\n";
                if (check(sp, i, j, sz + 1)) {
                    cout << "OK!" << "\n";
                    update(sp, i, j, sz + 1);
                    now -= d[sz];
                }
            }
        }
    }
    if (now == 0) {
        cout << "YES\n";
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                cout << sp[i][j] << " ";
            }
            cout << "\n";
        }
    }
    else {
        cout << "NO\n";
    }
    */
    return;
}


int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int tests = 1;
    cin >> tests;
    while(tests--) {
        solve();
    }
}
