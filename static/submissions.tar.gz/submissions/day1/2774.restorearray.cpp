/**
* user:  kuts-04f
* fname: Andiy
* lname: Kuts
* task:  restore
* score: 45.0
* date:  2019-10-10 09:57:16.324801
*/
#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define ld long double
#define fi first
#define se second
#define ull unsigned long long
#define db double

const int MAXN = 5005;

int sum[MAXN*2], len[MAXN*2];
bool used[MAXN*2];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int n, m; cin >> n >> m;
    vector<pair<pair<int, int>, pair<int, int> > > vc(m);
    for(int i = 0; i < m; i++)
    {
        int l, r, k, x; cin >> l >> r >> k >> x;
        vc[i] = {{l, r}, {k, x}};
    }
//    if(n <= 18)
//    {
//        for(int msk = 0; msk < (1 << n); msk++)
//        {
//            int pr[n+1]; pr[0] = 0;
//            for(int i = 0; i < n; i++)
//            {
//                int x = 0;
//                if(msk & (1 << i))
//                    x = 1;
//                pr[i+1] = pr[i]+x;
//            }
//            bool good = 1;
//            for(int i = 0; i < m; i++)
//            {
//                int sm = pr[vc[i].fi.se+1] - pr[vc[i].fi.fi];
//                if(vc[i].se.se)
//                {
//                    if(sm <= vc[i].fi.se-vc[i].fi.fi+1-vc[i].se.fi)
//                    {
//                        good = 0; break;
//                    }
//                }
//                else
//                {
//                    if(sm > vc[i].fi.se-vc[i].fi.fi+1-vc[i].se.fi)
//                    {
//                        good = 0; break;
//                    }
//                }
//            }
//            if(!good)
//                continue;
//            for(int i = 0; i < n; i++)
//            {
//                if(msk & (1 << i))
//                    cout << 1 << ' ';
//                else
//                    cout << 0 << ' ';
//            }
//            return 0;
//        }
//        cout << -1;
//    }
//    else
//    {
        int dat[n];
        for(int i = 0; i < n; i++)
        {
            dat[i] = 2;
        }
        for(int i = 0; i < m; i++)
        {
            len[i] = vc[i].fi.se-vc[i].fi.fi+1;
        }
        for(int i = 0; i < m; i++)
        {
            if(vc[i].se.se)
            {
                sum[i] = vc[i].se.fi;
            }
            else
            {
                sum[i] = vc[i].fi.se-vc[i].fi.fi+1-vc[i].se.fi+1;
            }
        }
        for(int j = 0; j < m; j++)
        {
            int v = -1, mn = 1e9;
            for(int i = 0; i < m; i++)
            {
                if(!used[i] && sum[i] < mn)
                {
                    v = i; mn = sum[i];
                }
            }
//            cout << v << ' ';
            used[v] = 1;
            if(vc[v].se.se)
            {
                for(int i = vc[v].fi.fi; i <= vc[v].fi.se; i++)
                {
                    if(dat[i] != 2)
                        continue;
                    int d = 1;
                    if(sum[v]-1)
                        d = 0;
                    dat[i] = d;
                    for(int to = 0; to < m; to++)
                    {
                        if(used[to] || vc[to].fi.fi > i || i > vc[to].fi.se)
                            continue;
                        len[to]--;

                        if(vc[to].se.se != d)
                        {
                            sum[to]--;
                        }
                    }
                    if(sum[v]-1)
                        sum[v]--;
                    len[v]--;
                }
            }
            else
            {
                for(int i = vc[v].fi.fi; i <= vc[v].fi.se; i++)
                {
                    if(dat[i] != 2)
                        continue;
                    int d = 0;
                    if(sum[v]-1)
                        d = 1;
                    dat[i] = d;
                    for(int to = 0; to < m; to++)
                    {
                        if(used[to] || vc[to].fi.fi > i || i > vc[to].fi.se)
                            continue;
                        len[to]--;

                        if(vc[to].se.se != d)
                        {
                            sum[to]--;
                        }
                    }
                    if(sum[v]-1)
                        sum[v]--;
                    len[v]--;
                }
            }
        }
        for(int i = 0; i < m; i++)
        {
            if(sum[i] <= 0)
            {
                cout << -1; return 0;
            }
        }
        int ind = 0;
        for(int i = 0; i < n; i++)
        {
            if(dat[i] == 2) dat[i] = (ind++) % 2;
        }
        for(int i = 0; i < n; i++)
        {
            cout << dat[i] << ' ';
        }
//    }
}


































/// Slava Ykraini i Roky
