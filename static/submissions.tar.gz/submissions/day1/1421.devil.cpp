/**
* user:  nicola-706
* fname: Alexandra Mihaela
* lname: Nicola
* task:  devil
* score: 13.0
* date:  2019-10-10 06:43:25.947549
*/
#include <iostream>
#include <cstring>
#define INF 2000000000000000000LL
#define DIM 1000010
using namespace std;

//ifstream cin ("date.in");
//ofstream cout ("date.out");

int f[11],x[100],sol[100],frecv[100],v[DIM];
int t,n,i,k,cif,j;
long long putere,sol_mini;
void back (int pas){
    if (pas == n+1){
        long long nr = 0;
        for (int i=1;i<=k;i++)
            nr = nr*10+x[i];
        long long maxi = nr;
        for (i=k+1;i<=n;i++){
            nr = nr%putere;
            nr = nr*10 + x[i];
            maxi = max (maxi,nr);
        }
        if (maxi < sol_mini){
            sol_mini = maxi;
            for (int i=1;i<=n;i++)
                sol[i] = x[i];
        }

        return;
    }
    for (int i=1;i<=4;i++){
        if (frecv[i]){
            x[pas] = i;
            frecv[i]--;
            back(pas+1);
            frecv[i]++;
        }}}
int main (){
    /// nu uita de fisiere
    cin>>t;
    for (;t--;){
        /// initializari
        memset (f,0,sizeof f);
        cin>>k;
        int sum = 0, ok = 0, maxi = 0;
        for (i=1;i<=9;i++){
            cin>>f[i];
            if (i > 4)
                ok += f[i];
            sum += f[i];

            maxi = max (maxi,f[i]);
        }
        n = sum;
        if (maxi <= 3 && ok == 0){
            /// dupa cifra maxima trb sa pun cifra minima
            for (i=1;i<=4;i++)
                frecv[i] = f[i];

            putere = 1;
            for (i=1;i<k;i++)
                putere = putere*10;
            sol_mini = INF;
            back(1);
            for (i=1;i<=n;i++)
                cout<<sol[i];
            cout<<"\n";
            continue;
        }
        if (k == 2){

            /// obs: nr minim maxim trb sa inceapa cu cifra cu maxima cu frecventa mai mare sau egala cu 2
            /// pot sa fixez acel nr de 2 cifre si sa vad daca pot construi dupa sirul
            /// mai intai vad cu ce cifra imi incepe numarul
            memset (v,0,sizeof v);
            for (i=9;i;i--)
                if (f[i]){
                    maxi = i;
                    break;
                }
            if (f[maxi] == 1){
                v[n] = maxi;
                f[maxi] = 0;
                for (i=maxi-1;i;i--){
                    if (f[i]){
                        cif = i;
                        break;
                    }}
                /// pe v[n-1] trb sa pun o cifra mai mica decat cif
                ok = 0;
                for (i=cif-1;i;i--){
                    if (f[i]){
                        v[n-1] = i;
                        f[i]--;
                        ok = 1;
                        break;
                    }}
                if (!ok){
                    v[n-1] = cif;
                    f[cif]--;
                }

            } else {
                cif = maxi;
                /// o pun pe ultima pozitie ca sa mai reduc nr de caractere
                v[n] = cif;
                f[cif]--;
            }

            /// mai intai vad daca pot sa pun dupa cif, cifre mai mici decat el
            /// completez succesiv cu cif si cea mai mica valoare disponibila
            i = 1;
            while (i <= n){
                if (v[i])
                    continue;
                if (!f[cif])
                    break;
                v[i] = cif;
                f[cif]--;
                i++;
                if (!v[i]){
                    for (int j=1;j<cif;j++){
                        if (f[j]){
                            v[i] = j;
                            f[j]--;
                            break;
                        }}}
            }
            /// acum pun ce cifre mi au mai ramas cum o fi
            for (i=1;i<=n;i++){
                if (v[i])
                    continue;
                for (j=1;j<=9;j++){
                    if (f[j]){
                        v[i] = j;
                        f[j]--;
                        break;
                    }}}
            for (i=1;i<=n;i++)
                cout<<v[i];
            cout<<"\n";

            continue;
        }


    }






    return 0;
}
