/**
* user:  dorde -5ce
* fname: Matei
* lname: Dorde 
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:25:59.526503
*/
#include <iostream>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0x0);
    cout.tie(0x0);
    int t , n , m , k;
    cin >> t;
    while(t --){
        cin >> n >> m >> k;
        if(n == 1){
            cout << "NO\n";
            continue;
        }
        if(n == 2){
            if(m != k * 2){
                cout << "NO\n";
                continue;
            }
            cout << "YES\n";
            for(int j = 0 ; j < 2 ; ++ j){
                for(int i = 1 ;i <= k ; ++ i)
                    cout << i << ' ' << i << ' ';
                cout << '\n';
            }
            continue;
        }
        if(n == 3){
            cout << "NO\n";
            continue;
        }
        if(n == 4){
            if(m == k){
                cout << "YES\n";
                for(int j = 0 ; j < 2 ; ++ j){
                    for(int c = 0 ; c < 2 ; ++ c){
                        for(int i = k / 2 * j + 1 ; i <= k / 2 *(j + 1) ; ++ i)
                            cout << i << ' ' << i << ' ';
                        cout << '\n';
                    }
                }
                continue;
            }
            if(m == 2 * k){
                cout << "YES\n";
                for(int i = 1 ; i <= m ; ++ i)
                    cout << k << ' ';
                cout << '\n';
                for(int j = 0 ; j < 2 ; ++ j){
                    cout << k << ' ';
                    for(int c = 1 ; c < k ; ++ c)
                        cout << c << ' ' << c << ' ';
                    cout << k << '\n';
                }
                for(int i = 1 ; i <= m ; ++ i)
                    cout << k << ' ';
                cout << '\n';
                continue;
            }
        }
        cout << "NO\n";
    }
    return 0;
}
