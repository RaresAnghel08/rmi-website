/**
* user:  nicola-f4a
* fname: Alexandra Mihaela
* lname: Nicola
* task:  Gardening
* score: 5.0
* date:  2021-12-16 08:10:04.503963
*/
#include <bits/stdc++.h>
#define DIM 200010
using namespace std;

int t,n,m,k,i,j,cul,ok;
int a[5][DIM];

int main (){

    //ifstream cin ("date.in");
    //ofstream cout ("date.out");

    cin>>t;
    for (;t--;){
        cin>>n>>m>>k;
        if (n % 2 || m % 2){
            cout<<"NO\n";
            continue;
        }

        if (n == 2){

            if (m % 2 || m / 2 != k){
                cout<<"NO\n";
                continue;
            }

            cout<<"YES\n";

            for (i=1;i<=n;i++){
                for (j=1;j<=m;j++)
                    cout<<(j+1)/2<<" ";
                cout<<"\n";
            }

            continue;
        }

        if (n == 4){

            if (m == 2){

                if (k != 2)
                    cout<<"NO\n";
                else cout<<"YES\n1 1\n1 1\n2 2\n2 2\n";

                continue;
            }

            if (m == 4){

                if (k == 2){
                    cout<<"YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
                } else {
                    if (k == 4){
                        cout<<"YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";

                    } else cout<<"NO\n";
                }

                continue;
            }


            if (k > m){
                cout<<"NO\n";
                continue;
            }


            int dif = m - k; /// trb sa scap de atatea culori
            if (dif == 1){
                cout<<"NO\n";
                continue;
            }

            if (dif % 2){

                dif -= 3;

                a[1][1] = a[1][2] = a[1][3] = a[1][4] = a[1][5] = a[1][6] = 1;
                a[4][1] = a[4][2] = a[4][3] = a[4][4] = a[4][5] = a[4][6] = 1;
                a[2][1] = a[3][1] = a[2][6] = a[3][6] = 1;
                a[2][2] = a[2][3] = a[3][2] = a[3][3] = 2;
                a[2][4] = a[2][5] = a[3][4] = a[3][5] = 3;

                cul = 3;
                j = 7;
            } else j = 1;

            ok = 0;
            while (dif){

                if (j + 3 > m){
                    ok = 1;
                    break;
                }

                ++cul;
                a[1][j] = a[1][j+1] = a[1][j+2] = a[1][j+3] = cul;
                a[2][j] = a[3][j] = a[2][j+3] = a[3][j+3] = cul;
                a[4][j] = a[4][j+1] = a[4][j+2] = a[4][j+3] = cul;
                a[2][j+1] = a[2][j+2] = a[3][j+1] = a[3][j+2] = ++cul;

                j += 4;
                dif -= 2;
            }

            if (ok){
                cout<<"NO\n";
                continue;
            }

            for (;j<=m;j+=2){
                a[1][j] = a[1][j+1] = a[2][j] = a[2][j+1] = ++cul;
                a[3][j] = a[3][j+1] = a[4][j] = a[4][j+1] = ++cul;
            }

            if (cul > k){
                cout<<"NO\n";
                continue;
            }

            cout<<"YES\n";
            for (i=1;i<=n;i++,cout<<"\n")
                for (j=1;j<=m;j++)
                    cout<<a[i][j]<<" ";

        }

    }


    return 0;
}
