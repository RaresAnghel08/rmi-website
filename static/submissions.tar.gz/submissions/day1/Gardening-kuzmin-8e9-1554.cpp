/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:08:30.378100
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

void solve() {
	int n, m, k;
	cin >> n >> m >> k;
	vector<vi> ans(n, vi(m));
	if (n % 2 || m % 2) {
		cout << "NO\n";
		return;
	} else {
		int d1 = (n * m) / 4;
		int d2 = ((n - 2) * (m - 2)) / 4 + 1;
		int it = 1;
		if (d1 == k) {
			for (int j = 0; j < n; j += 2) {
				for (int k = 0; k < m; k += 2) {
					ans[j][k] = ans[j + 1][k + 1] = ans[j + 1][k] = ans[j][k + 1] = it;
					it++;
				}
			}
			cout << "YES\n";
			for (auto &i : ans) {
				for (auto &j : i) {
					cout << j << ' ';
				}
				cout << endl;
			}
		} else if (d2 == k) {
			for (int j = 1; j < n - 1; j += 2) {
				for (int k = 1; k < m - 1; k += 2) {
					ans[j][k] = ans[j + 1][k + 1] = ans[j + 1][k] = ans[j][k + 1] = it;
					it++;
				}
			}
			for (int i = 0; i < n; ++i) {
				for (int j = 0; j < m; ++j) {
					if (i == 0 || j == 0 || i == n - 1 || j == m - 1)
						ans[i][j] = it;
				}
			}
			cout << "YES\n";
			for (auto &i : ans) {
				for (auto &j : i) {
					cout << j << ' ';
				}
				cout << endl;
			}
		} else {
			cout << "NO\n";
		}
	}
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	cin >> t;
	while (t--)
		solve();
}