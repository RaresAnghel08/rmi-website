/**
* user:  handarov-0db
* fname: Radostin
* lname: Handarov
* task:  restore
* score: 0.0
* date:  2019-10-10 10:32:19.664126
*/
#include <bits/stdc++.h>

#pragma GCC optimize "-O3"

#define endl "\n"
#define trace(x) cerr << #x << " = " << x << endl
#define sz(x) ((int)x.size())
#define all(x) x.begin(), x.end()

using namespace std;

template<class T, class T1> inline bool chkmax(T &x, const T1 &y) { return x < y ? x = y, true : false; }
template<class T, class T1> inline bool chkmin(T &x, const T1 &y) { return x > y ? x = y, true : false; }

struct Restriction {
	int l;
	int r;
	int k;
	int value;
};

int n, m;
vector<Restriction> rest;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m;

	rest.resize(m);
	for (int i = 0; i < m; i++) {
		cin >> rest[i].l >> rest[i].r >> rest[i].k >> rest[i].value;
	}

	vector<int> arr(n, -1);
	for (int i = 0; i < m; i++) {
		int minValue = 2;
		for (int j = rest[i].l; j <= rest[i].r; j++) {
			chkmin(minValue, arr[j]);
		}
		if (minValue == -1) {
			arr[rest[i].l] = rest[i].value;
		} else if (minValue != rest[i].value) {
			cout << -1 << endl;
			return EXIT_SUCCESS;
		}
	}

	for (int i = 0; i < n; i++) {
		cout << (arr[i] == -1 ? 1 : arr[i]) << " \n"[i == n - 1];
	}

	return EXIT_SUCCESS;
}