/**
* user:  sharshenaliev-d01
* fname: Nazar
* lname: Sharshenaliev
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:24:08.997903
*/
#include <bits/stdc++.h>
using namespace std;
int a[1001][1001];
int main (){
	int t; cin >> t;
	while(t--){
		int n , m , k;
		cin >> n >> m >> k;
		if(n == 1 and m == 1 and k == 1){
			cout <<"YES"<<endl;
			cout << 1 << endl;
		}else if(n == 1 and m == 1 and k > 1){
			cout << "NO"<<endl;
			return 0;
		}
		if(n == 3 and m == 3 and k > 2){
				cout << "NO"<<endl;
		}else if(n == 3 and m == 3 and k <= 2){
			cout << "1 1 1" << endl;
			cout << "1 2 1" << endl;
			cout << "1 1 1" << endl;
		}
		
	}
	return 0;
}