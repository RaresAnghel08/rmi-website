/**
* user:  mihalev-d38
* fname: Mihail
* lname: Mihalev
* task:  Gardening
* score: 5.0
* date:  2021-12-16 08:17:58.884946
*/
#include<iostream>
using namespace std;
const int MAX_N=2e5+3;
int n,m,k;
int t;
void Solve1()
{
    if(n==2)
    {
        if(m==2)
        {
            if(k>1){cout<<"NO"<<endl;return;}
            cout<<"YES"<<endl;
            cout<<1<<" "<<1<<endl;
            cout<<1<<" "<<1<<endl;
            return;
        }
        if(m==4)
        {
            if(k==2)
            {
                cout<<"YES"<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                return;
            }
            cout<<"NO"<<endl;
            return;
        }
    }
    if(n==4)
    {
        if(m==2)
        {
            if(k==2)
            {
                cout<<"YES"<<endl;
                cout<<1<<" "<<1<<endl;
                cout<<1<<" "<<1<<endl;
                cout<<2<<" "<<2<<endl;
                cout<<2<<" "<<2<<endl;
                return;
            }
            cout<<"NO"<<endl;
            return;
        }
        if(m==4)
        {
            if(k==2)
            {
                cout<<"YES"<<endl;
                cout<<1<<" "<<1<<" "<<1<<" "<<1<<endl;
                cout<<1<<" "<<2<<" "<<2<<" "<<1<<endl;
                cout<<1<<" "<<2<<" "<<2<<" "<<1<<endl;
                cout<<1<<" "<<1<<" "<<1<<" "<<1<<endl;
                return;
            }
            if(k==4)
            {
                cout<<"YES"<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<1<<" "<<1<<" "<<2<<" "<<2<<endl;
                cout<<3<<" "<<3<<" "<<4<<" "<<4<<endl;
                cout<<3<<" "<<3<<" "<<4<<" "<<4<<endl;
                return;
            }
            cout<<"NO"<<endl;
        }
    }
    ////////////////////////////////////////////
    //cout<<"NO"<<endl;
}
//n,m<=4
void Solve2()
{
    if(((n*m)-(2*(m+2)))%4==0 && ((n*m)-(2*(m+2)))/4==k-1)
    {
        cout<<"YES"<<endl;
        cout<<1;
        for(int i=2;i<=m;i++)
        {
            cout<<" "<<1;
        }
        cout<<endl;
        cout<<1<<" ";
        int kw=1;
        for(int i=2;i<m;i++)
        {
            if(i%2==0)kw++;
            cout<<kw<<" ";
        }
        cout<<1<<endl;
        cout<<1<<" ";
        kw=1;
        for(int i=2;i<m;i++)
        {
            if(i%2==0)kw++;
            cout<<kw<<" ";
        }
        cout<<1<<endl;
        cout<<1;
        for(int i=2;i<=m;i++)
        {
            cout<<" "<<1;
        }
        cout<<endl;
        return;
    }
    if(m==k)
    {
        cout<<"YES"<<endl;
        int kw=0;
        for(int i=1;i<=m;i++)
        {
            if(i%2==1)kw++;
            cout<<kw<<" ";
        }
        cout<<endl;
        kw=0;
        for(int i=1;i<=m;i++)
        {
            if(i%2==1)kw++;
            cout<<kw<<" ";
        }
        cout<<endl;
        kw=m/2;
        for(int i=1;i<=m;i++)
        {
            if(i%2==1)kw++;
            cout<<kw<<" ";
        }
        cout<<endl;
        kw=m/2;
        for(int i=1;i<=m;i++)
        {
            if(i%2==1)kw++;
            cout<<kw<<" ";
        }
        cout<<endl;
        return;
    }
    cout<<"NO"<<endl;
}
void Read()
{
    cin>>t;
    while(t--)
    {
        cin>>n>>m>>k;
        if(n<=4 && m<=4)Solve1();
        else if(n<=4 && m>4)
        {
            Solve2();
        }
    }
}
int main ()
{
    Read();




    return 0;
}
