/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:15:21.539475
*/
#include <bits/stdc++.h>

#define pb push_back
#define f first
#define s second

using namespace std;

map<pair<pair<int, int>, int>, int> mp;

bool solve(int n, int m, int k) {
    if (n < 2 || m < 2) {
        mp[{{n, m}, k}] = 0;
    }
    if (n % 2 == 0 && m % 2 == 0 && k == n / 2 * m / 2) {
        mp[{{n, m}, k}] = 1;
    }
    if (mp.count({{n, m}, k}))
        return mp[{{n, m}, k}];
    int kolvo = n + m - 4;
    if (solve(n - 2, m - 2, k - 1)) {
        mp[{{n, m}, k}] = 1;
    } else if (solve(n - 4, m - 4, k - kolvo)) {
        mp[{{n, m}, k}] = 1;
    }
    return mp[{{n, m}, k}];
}

vector<vector<int>> ans;
pair<int, int> it_n, it_m;
int col = 1;

void build(int n, int m, int k) {
    if (n % 2 == 0 && m % 2 == 0 && k == n / 2 * m / 2) {
        for (int i = it_n.f; i < it_n.s; i += 2) {
            for (int j = it_m.f; j < it_m.s; j += 2) {
                ans[i][j] = ans[i + 1][j] = ans[i][j + 1] = ans[i + 1][j + 1] = col++;
            }
        }
        return;
    }
    int kolvo = n + m - 4;
    if (mp[{{n - 2, m - 2}, k - 1}]) {
        for (int i = it_n.f; i <= it_n.s; i++) {
            ans[i][it_m.f] = col;
            ans[i][it_m.s] = col;
        }
        for (int i = it_m.f; i <= it_m.s; i++) {
            ans[it_n.f][i] = col;
            ans[it_n.s][i] = col;
        }
        col++;
        it_n.f++;
        it_n.s--;
        it_m.f++;
        it_m.s--;
        build(n - 2, m - 2, k - 1);
    } else if (mp[{{n - 4, m - 4}, k - kolvo}]) {
        for (int i = it_n.f; i < it_n.s; i += 2) {
            ans[i][it_m.f] = ans[i + 1][it_m.f] = ans[i][it_m.f + 1] = ans[i + 1][it_m.f + 1] = col++;
            ans[i][it_m.s] = ans[i + 1][it_m.s] = ans[i][it_m.s - 1] = ans[i + 1][it_m.s - 1] = col++;
        }
        for (int i = it_m.f + 2; i < it_m.s - 2; i += 2) {
            ans[it_n.f][i] = ans[it_n.f][i + 1] = ans[it_n.f + 1][i] = ans[it_n.f + 1][i + 1] = col++;
            ans[it_n.s][i] = ans[it_n.s][i + 1] = ans[it_n.s - 1][i] = ans[it_n.s - 1][i + 1] = col++;
        }
        it_n.f += 2;
        it_n.s -= 2;
        it_m.f += 2;
        it_m.s -= 2;
        build(n - 4, m - 4, k - kolvo);
    }
}

void solve() {
    int n, m, k;
    cin >> n >> m >> k;
    it_n = {0, n - 1};
    it_m = {0, m - 1};
    col = 1;
    mp.clear();
    solve(n, m, k);
    if (mp[{{n, m}, k}]) {
        cout << "YES" << '\n';
        ans.clear();
        ans.resize(n);
        for (int i = 0; i < n; i++) {
            ans[i].resize(m);
        }
        build(n, m, k);
        for (auto u : ans){
            for (auto v : u)
                cout << v << ' ';
            cout << '\n';
        }
    }else{
        cout << "NO" << '\n';
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
}