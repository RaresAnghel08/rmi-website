/**
* user:  pakkanen-669
* fname: Mariia
* lname: Pakkanen
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 10:06:45.802894
*/
#include "speedrun.h"
#include <bits/stdc++.h>

using namespace std;

void assignHints(int subtask, int N, int A[], int B[]) {
    int n = N;
    int siz[n + 1];
    for(int i = 0; i <= n; ++i)
        siz[i] = 0;
    for(int i = 1; i < n; ++i){
        siz[A[i]]++;
        siz[B[i]]++;
    }
    int ms = 1;
    for(int i = 1; i <= n; ++i){
        if(siz[ms] < siz[i])
            ms = i;
    }
    if(siz[ms] == n - 1){
        vector <bool> a;
        int cpy = ms;
        while(cpy > 0){
            a.push_back(cpy % 2);
            cpy /= 2;
        }
        reverse(a.begin(), a.end());
        setHintLen(a.size());
        for(int i = 1; i <= n; ++i){
            for(int j = 0; j < a.size(); ++j)
                setHint(i, j+1, a[j]);
        }
    }
    else{
        setHintLen(20);
    }
    return;
}

void speedrun(int subtask, int N, int start) {
    int as = getLength();
    vector <int> a(as+1);
    for(int i = 1; i <= as; ++i){
        a[i] = getHint(i);
    }
    int x = 0;
    for(int i = 1; i <= as; ++i){
        x = x * 2 + a[i];
    }
    vector <bool> used(N+1, false);
    used[start] = true;
    int cur = 1;
    if(start != x){
        if(goTo(x))
            start = x;
    }
    used[start] = true;
    for(int i = 1; i <= N; ++i){
        if(used[i])
            continue;
        used[i] = true;
        if(goTo(x))
            start = x;
        if(goTo(i))
            start = i;
    }
    return;

}
