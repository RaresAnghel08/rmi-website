/**
* user:  klishch-92b
* fname: Danil
* lname: Klishch
* task:  lucky
* score: 64.0
* date:  2019-10-10 09:22:20.497867
*/
#include <bits/stdc++.h>
using namespace std;

const int MAX_N = 131072, MAX_TREE = 262144, MOD = 1e9 + 7;

int64_t precalc[MAX_N][2][2];

char number[MAX_N];

set<int> bad_ind;

struct Node {
	int l, r;
	int64_t v[2][2]; // not greater than [l; r)
} tree[MAX_TREE];

bool isBad(int l, int r) {
	return bad_ind.lower_bound(l) != bad_ind.lower_bound(r - 1);
}

Node merge(const Node& a, const Node& b) {
	assert(a.r == b.l);
	Node res{a.l, b.r, 0, 0, 0, 0};
	if (isBad(b.l, b.r) == 1) {
		int startIndex = (number[b.r - 1] == 3) ? 1 : 0;
		int endIndex = (number[b.l] == 1) ? 1 : 0;
		for (int bi = 0; bi < 2; ++bi) {
			for (int bj = 0; bj < 2; ++bj) {
				for (int ai = 0; ai < 2; ++ai) {
					for (int aj = 0; aj < 2; ++aj) {
						if (ai == 1 && bj == 1)
							continue;
						res.v[bi][aj] += b.v[bi][bj] * precalc[a.r - a.l][ai][aj] % MOD;
					}
				}
			}
		}
	} else {
		int startIndex = (number[b.r - 1] == 3) ? 1 : 0;
		int endIndex = (number[b.l] == 1) ? 1 : 0;
		for (int bi = 0; bi < 2; ++bi) {
			for (int bj = 0; bj < 2; ++bj) {
				int add = 0;
				if (startIndex == bi && endIndex == bj)
					add = -1;
				for (int ai = 0; ai < 2; ++ai) {
					for (int aj = 0; aj < 2; ++aj) {
						if (ai == 1 && bj == 1)
							continue;
						res.v[bi][aj] += (b.v[bi][bj] + add) * precalc[a.r - a.l][ai][aj] % MOD;
					}
				}
			}
		}
		for (int ai = 0; ai < 2; ++ai) {
			for (int aj = 0; aj < 2; ++aj) {
				if (endIndex == 1 && ai == 1)
					continue;
				res.v[startIndex][aj] += a.v[ai][aj];
			}
		}
	}
	for (int i = 0; i < 2; ++i)
		for (int j = 0; j < 2; ++j)
			res.v[i][j] %= MOD;
	return res;
}

Node getWith(int index, int x) {
	Node res{index, index + 1, 0, 0, 0, 0};
	for (int i = 0; i <= x; ++i) {
		if (i == 1)
			++res.v[0][1];
		else if (i == 3)
			++res.v[1][0];
		else
			++res.v[0][0];
	}
	return res;
}

void build(int i = 0, int l = 0, int r = MAX_N) {
	if (r - l == 1) {
		tree[i] = getWith(l, number[l]);
		return;
	}
	int mid = (l + r) / 2;
	build(2 * i + 1, l, mid);
	build(2 * i + 2, mid, r);
	tree[i] = merge(tree[2 * i + 1], tree[2 * i + 2]);
}

Node getAnswer(int l, int r, int i = 0, int cl = 0, int cr = MAX_N) {
	//cout << l << " " << r << " " << i << " " << cl << " " << cr << " " << endl;
	if (l <= cl && cr <= r) {
		return tree[i];
	}
	int mid = (cl + cr) / 2;
	if (r <= mid) {
		return getAnswer(l, r, 2 * i + 1, cl, mid);
	} else if (l >= mid) {
		return getAnswer(l, r, 2 * i + 2, mid, cr);
	} else {
		return merge(getAnswer(l, r, 2 * i + 1, cl, mid), getAnswer(l, r, 2 * i + 2, mid, cr));
	}
}

int value(Node x) {
	return (x.v[0][0] + x.v[0][1] + x.v[1][0] + x.v[1][1]) % MOD;
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	precalc[1][0][0] = 8;
	precalc[1][1][0] = 1;
	precalc[1][0][1] = 1;
	for (int i = 2; i < MAX_N; ++i) {
		precalc[i][0][0] = (9 * precalc[i - 1][0][0] + 8 * precalc[i - 1][1][0]) % MOD;
		precalc[i][0][1] = (9 * precalc[i - 1][0][1] + 8 * precalc[i - 1][1][1]) % MOD;
		precalc[i][1][0] = (precalc[i - 1][0][0] + precalc[i - 1][1][0]) % MOD;
		precalc[i][1][1] = (precalc[i - 1][0][1] + precalc[i - 1][1][1]) % MOD;
	}
	int n, q;
	cin >> n >> q;
	for (int i = 0; i < n; ++i)
		cin >> number[i], number[i] -= '0';
	reverse(number, number + n);
	for (int i = 0; i < MAX_N - 1; ++i)
		if (number[i] == 3 && number[i + 1] == 1)
			bad_ind.insert(i);
	build();
	cout << value(tree[0]) << "\n";
	for (int i = 0; i < q; ++i) {
		int type, u, v;
		cin >> type >> u >> v;
		//cout << type << " " << u << " " << v << endl;
		if (type == 1) {
			//cout << n - u << " " << n - v + 1 << endl;
			cout << value(getAnswer(n - v, n - u + 1)) << "\n";
		}
	}
	return 0;
}