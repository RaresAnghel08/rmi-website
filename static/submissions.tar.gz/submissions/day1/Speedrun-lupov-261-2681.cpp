/**
* user:  lupov-261
* fname: Ivan Stiliyanov
* lname: Lupov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:56:58.350241
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include "speedrun.h"

#define de(x) cout << #x << " = " << x << endl;
#define pb push_back
#define fr first
#define sc second
#define bit(x) x&(-x)
#define ll long long
#define ld long double

using namespace __gnu_pbds;
using namespace std;

template<class T> using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<class T> using matrix = vector<vector<T>>;

void assignHints(int subtask, int N, int A[], int B[]){
	if(subtask == 1){
		setHintLen(N);
		for(int i = 1; i < N; i ++){
			setHint(A[i], B[i] - 1, 1);
			setHint(B[i], A[i] - 1, 1);
		}
	}
	/**if(subtask == 2){
		setHintLen(20);
		matrix<int> G(N + 1);
		for(int i = 1; i < N; i ++){
			G[A[i]].pb(B[i]);
			G[B[i]].pb(A[i]);
		}
		for(int u = 1; u <= N; u ++){
			if(G[u].size() == N - 1){
				
			}
		}
	}*/
}

int n;

void dfs(int u, int p){
	for(int v = 1; v <= n; v ++){
		if(getHint(v - 1) && v != p){
			goTo(v);
			dfs(v, u);
		}
	}
	goTo(p);
}

void speedrun(int subtask, int N, int start){
	if(subtask == 1){
		n = N;
		dfs(start, start);
	}
}
