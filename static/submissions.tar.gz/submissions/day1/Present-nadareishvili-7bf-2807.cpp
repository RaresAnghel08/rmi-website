/**
* user:  nadareishvili-7bf
* fname: Giorgi
* lname: Nadareishvili
* task:  Present
* score: 29.0
* date:  2021-12-16 10:08:02.766508
*/
#include <bits/stdc++.h>
using namespace std;



int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    int n = 0;
    vector<int> q;
    for(int i = 0; i < t; ++i) {
        int x;
        cin >> x;
        n = max(n, x);
        q.push_back(x);
    }
    if(n > 1000000) return 0;
    vector<pair<int, int>> v = {{0, 0}, {1, 0}};
    for(int i = 2;; ++i) {
        bool boo = 0;
        for(int j = 0; j < v.size(); ++j) {
            if(v[j].first == i) break;
            set<int> s;
            int z = j;
            for(;z;) {
                s.insert(v[z].first);
                z = v[z].second;
            }
            bool bo = 1;
            for(int y : s) {
                if(s.find(__gcd(y, i)) == s.end()) {
                    bo = 0;
                    break;
                }
            }
            if(bo) {
                v.push_back({i, j});
                if(v.size() > n) {
                    boo = 1;
                    break;
                }
            }
        }
        if(boo) break;
    }
    for(int x : q) {
        vector<int> u;
        int z = x;
        for(;z;) {
            u.push_back(v[z].first);
            z = v[z].second;
        }
        cout << u.size() << " ";
        reverse(u.begin(), u.end());
        for(int y : u) {
            cout << y << " ";
        }
        cout << "\n";
    }
    return 0;
}
