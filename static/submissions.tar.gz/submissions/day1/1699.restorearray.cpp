/**
* user:  bashev-75b
* fname: Dobrin
* lname: Bashev
* task:  restore
* score: 0.0
* date:  2019-10-10 07:33:45.648685
*/
#include <iostream>
using namespace std;

const int MAXN = 5003;
const int MAXM = 10004;

struct condition
{
    int k, l, r, v;
};

int n, m, a[MAXN];
condition b[MAXM];

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; ++ i)
    {
        cin >> b[i].l >> b[i].r >> b[i].k >> b[i].v;
        if (b[i].k == 1 and b[i].v == 1)
        {
            for (int j = b[i].l; j <= b[i].r; ++ j)
            {
                a[j] = 1;
            }
        }
    }

    for (int i = 1; i <= m; ++ i)
    {
        if (b[i].k == 1 and b[i].v == 0)
        {
            bool f = 0;
            for (int j = b[i].l; j <= b[i].r; ++ j)
            {
                if (a[j] == 0)
                {
                    f = 1;
                    break;
                }
            }

            if (f == 0)
            {
                cout << -1 << endl;
                return 0;
            }
        }
    }

    for (int i = 1; i <= n; ++ i)
    {
        cout << a[i] << ' ';
    }
    return 0;
}
