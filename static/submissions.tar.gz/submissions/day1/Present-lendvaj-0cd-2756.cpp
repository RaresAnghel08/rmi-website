/**
* user:  lendvaj-0cd
* fname: Dorijan
* lname: Lendvaj
* task:  Present
* score: 0.0
* date:  2021-12-16 10:04:18.948289
*/
#include <bits/stdc++.h>
#define x first
#define y second
#define pii pair<int,int>
using namespace std;
using ll=long long;
#define pll pair<ll,ll>
#define vi vector<int>
#define vl vector<ll>
#define all(a) begin(a),end(a)
#define pb push_back
#define eb emplace_back

const int N=300010,MOD=1e9+7;
const char en='\n';
const ll LLINF=1ll<<60;

int t,sos[1<<20],ko[1<<20],ko1[1<<20],ko2[1<<20],dop[1<<20];

ll izr(int ma,vi da,vi ne)
{
	vi pda,pne,nda,nne;
	for (auto x: da) if (x%2==0) pda.pb(x);
	else nda.pb(x);
	for (auto x: ne) if (x%2==0) pne.pb(x);
	else nne.pb(x);
	int sr=ma/2;
	for (int b=0;b<(1<<sr);++b)
	{
		bool ok=ko1[b];
		if (ok) for (auto x: pda) if (!(b&(1<<(x/2-1)))) ok=0;
		if (ok) for (auto x: pne) if ((b&(1<<(x/2-1)))) ok=0;
		sos[b]=ok;
		ko[b]=ok;
	}
	for (int bi=0;bi<sr;++bi) for (int b=0;b<(1<<sr);++b) if (b&(1<<bi)) sos[b]+=sos[b^(1<<bi)];
	ll kol=0;
	for (int b=0;b<(1<<(ma-sr));++b)
	{
		bool ok=ko2[b];
		if (ok) for (auto x: nda) if (!(b&(1<<(x/2)))) ok=0;
		if (ok) for (auto x: nne) if ((b&(1<<(x/2)))) ok=0;
		if (ok)
		{
			kol+=sos[dop[b]];
		}
	}
	return kol;
}

vector<vi> solve(vl vn)
{
	double cl=clock(),s=0;
	vector<vi> ann(t);
	for (int ma=1;ma<=37;++ma)
	{
		double cl1=clock();
		int sr=ma/2;
		for (int b=0;b<(1<<sr);++b)
		{
			bool ok=1;
			for (int i=0;i<sr && ok;++i) if (b&(1<<i)) for (int j=0;j<sr && ok;++j) if (b&(1<<j))
			{
				if (!(b&(1<<(gcd(i+1,j+1)-1)))) ok=0;
			}
			ko1[b]=ok;
		}
		for (int b=0;b<(1<<(ma-sr));++b)
		{
			bool ok=1;
			for (int i=0;i<ma-sr && ok;++i) if (b&(1<<i)) for (int j=0;j<ma-sr && ok;++j) if (b&(1<<j))
			{
				if (!(b&(1<<(gcd(i*2+1,j*2+1)/2)))) ok=0;
			}
			ko2[b]=ok;
		}
		for (int b=0;b<(1<<(ma-sr));++b)
		{
			bool ok=ko2[b];
			if (ok)
			{
				dop[b]=(1<<sr)-1;
				for (int i=0;i<ma-sr;++i) if (b&(1<<i)) for (int j=0;j<sr;++j) if (!(b&(1<<(gcd(i*2+1,j+1)/2)))) dop[b]&=((1<<sr)-1-(1<<j));
			}
		}
		s+=clock()-cl1;
		ll kol=izr(ma,{ma},{});
		for (int rr=0;rr<t;++rr)
		{
			if (vn[rr]>kol) vn[rr]-=kol;
			else if (vn[rr])
			{
				vi an={ma};
				vi os={};
				for (int z=ma-1;z>0;--z)
				{
					os.pb(z);
					ll kol1=izr(ma,an,os);
					if (vn[rr]>kol1)
					{
						os.pop_back();
						an.pb(z);
						vn[rr]-=kol1;
					}
				}
				reverse(all(an));
				ann[rr]=an;
				vn[rr]=0;
			}
		}
	}
	//cerr<<(clock()-cl)/CLOCKS_PER_SEC<<" in total."<<endl;
	//cerr<<s/CLOCKS_PER_SEC<<" in gcd stuff."<<endl;
	return ann;
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin>>t;
	vl v;
	for (int i=0;i<t;++i)
	{
		ll x;
		cin>>x;
		v.pb(x);
	}
	auto od=solve(v);
	for (auto x: od)
	{
		cout<<x.size();
		for (auto y: x) cout<<' '<<y;
		cout<<endl;
	}
}
