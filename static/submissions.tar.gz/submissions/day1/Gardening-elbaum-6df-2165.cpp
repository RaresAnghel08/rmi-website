/**
* user:  elbaum-6df
* fname: Eitan
* lname: Elbaum
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:06:42.723413
*/
#include<set>
#include<vector>
#include <iostream>
using namespace std;
int main(){
    int t,n,m,k; cin>>t;
    while(t--){
        cin>>n>>m>>k; //lines, columns, colors
        if(n==4 && m==4){
            if(k==2) cout<<"YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
            else if(k==4) cout<<"YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";
            else cout<<"NO\n";
        }
        else if(n==2 && m==2 && k==1) cout<<"YES\n1 1\n1 1\n";
        else if(n==2 && m==4 && k==2) cout<<"YES\n1 1 2 2\n1 1 2 2\n";
        else if(n==4 && m==2 && k==2) cout<<"YES\n1 1\n1 1\n2 2\n2 2\n";
        else cout<<"NO\n";
        /*int x=n/2,y=m/2,p=0;
        set<int> s;
        while(x && y){
            s.insert(x*y + p);
            p++; x--; y--;
        }
        if(m%2 || n%2) cout<<"NO\n";
        else{
            cout<<"YES\n";
            int arr[n][m];
            for(int i=0;i<n;i++){
                for(int j=0;j<m;j++){
                    arr[i][j] = 1;
                }
            }
            p = 2;
            for(int i=0;2*i +1 < n && p<=k; i++){
                for(int j=0;2*j +1 < m && p<=k; j++){
                    arr[2*i][2*j] = arr[2*i +1][2*j] = arr[2*i][2*j +1]=arr[2*i +1][2*j +1]=p;
                    p++;
                }
            }
            if(n%2){
                for(int i=0;i<m;i++){
                    arr[n-1][i] = arr[n-2][i];
                }
            }
            if(m%2){
                for(int i=0;i<n;i++){
                    arr[i][m-1] = arr[i][m-2];
                }
            }
            for(int i=0;i<n;i++){
                for(int j=0;j<m;j++){
                    cout<<arr[i][j]<<' ';
                }cout<<'\n';
            }
        }*/
    }
    return 0;
}