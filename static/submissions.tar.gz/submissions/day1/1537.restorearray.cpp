/**
* user:  casarin-262
* fname: Filippo
* lname: Casarin
* task:  restore
* score: 13.0
* date:  2019-10-10 07:03:21.610076
*/
#include "bits/stdc++.h"

#define QUIT() printf("-1\n"), exit(0)

#define MAXN 5000
#define MXAM 10000

typedef std::pair<int, int> ii;
typedef std::vector<int> vi;
typedef std::vector<ii> vii;

signed char A[MAXN];

int main() {
	int N, M;
	scanf("%d %d", &N, &M);

	for (int i=0; i<N; i++)
		A[i] = -1;

	for (int i=0; i<M; i++) {
		int L, R, K, V;
		scanf("%d %d %d %d", &L, &R, &K, &V);

		if (K == 1) {
			if (V) {
				for (int j=L; j<=R; j++) {
					if (A[j] == 0) QUIT();
					A[j] = 1;
				}
			} else {
				bool ok = false;
				for (int j=L; j<=R && !ok; j++)
					if (A[j] != 1)
						ok = true;

				if (!ok) QUIT();
			}
		} else {
			if (V) {
				bool ok = false;
				for (int j=L; j<=R && !ok; j++)
					if (A[j] != 0)
						ok = true;

				if (!ok) QUIT();
			} else {
				for (int j=L; j<=R; j++) {
					if (A[j] == 1) QUIT();
					A[j] = 0;
				}
			}
		}
	}

	for (int i=0; i<N; i++)
		printf("%d ", A[i] != -1 ? A[i] : 0);
	printf("\n");
}

