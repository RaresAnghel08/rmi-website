/**
* user:  kruhlikau-b9e
* fname: Ihar
* lname: Kruhlikau
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:02:53.983972
*/
#include <bits/stdc++.h>

#define fi first
#define se second
#define mp make_pair

#define pb push_back
#define pob pop_back

#define ld long double
#define ll long long

#define y1 abc

#define re return
#define cont continue

#define endl '\n'

using namespace std;

int a[5][250001], dp[250001][2][2], n, m, i, j, z, k, t, val, nom, last;

    void solve()
    {
        cin >> n >> m >> k;

        if (n % 2 != 0 || m % 2 != 0) {
            cout << "NO" << endl;

            re;
        }

        if (n == 2) {
            if (k != m / 2) {
                cout << "NO" << endl;

                re;
            }

            cout << "YES" << endl;

            nom = 0;

            for (i = 1; i <= n; i += 2)
                for (j = 1; j <= m; j += 2) {
                    nom++;

                    a[i][j] = a[i + 1][j] = a[i][j + 1] = a[i + 1][j + 1] = nom;
                }

            for (i = 1; i <= n; i++) {
                for (j = 1; j <= m; j++) cout << a[i][j] << " ";

                cout << endl;
            }

            re;
        }

        cout << "NO" << endl;
    }

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin >> t;

    while (t--) solve();

    re 0;
}
