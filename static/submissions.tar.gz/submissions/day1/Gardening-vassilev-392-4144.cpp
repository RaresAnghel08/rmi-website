/**
* user:  vassilev-392
* fname: Yoan Rumenov
* lname: Vassilev
* task:  Gardening
* score: 21.0
* date:  2021-12-16 11:59:08.127045
*/
#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
long long t,N,M,K,cr;
bool fl=false;
vector <long long> a[200005];
struct tel{
    long long n,m,k,st=0;
    pair <long long, long long> p;
};
stack <tel> s;
tel q,q2;
void PUSH(long long n, long long m, long long k, long long st, pair<long long, long long> p){
    q2.n=n;
    q2.m=m;
    q2.k=k;
    q2.p=p;
    q2.st=st;
    s.push(q2);
}
bool solve(){
    long long n,m,k,mn,mx,i,j;
    pair <long long,long long> p;
    //s.push({N,M,K,0,{1,1}});
    PUSH(N,M,K,0,{1,1});
    fl=false;
    while(!s.empty()){
        s.top().st++; q=s.top();
        n=q.n; m=q.m; k=q.k; p=q.p;
        mn=max(n,m)/2; mx=n*m/4;
        //cout<<q.n<<" "<<q.m<<" "<<q.k<<" "<<q.st<<" "<<mn<<" "<<mx<<" ("<<q.p.first<<" "<<q.p.second<<")\n";
        if(n*m==0 || (n+m)%2==1 || mx<k || k<mn){s.pop(); continue;}
        if(n==m && n==2){a[p.first][p.second]=a[p.first][p.second+1]=a[p.first+1][p.second]=a[p.first+1][p.second+1]=1; s.pop(); fl=true; break;}
        /*if(q.st==1){s.push({n-2,m-2,k-1,0,{p.first+1,p.second+1}}); continue;}
        if(q.st==2){s.push({n-2,m,k-m/2,0,p}); continue;}
        if(q.st==3){s.push({n,m-2,k-n/2,0,p}); continue;}*/
        if(q.st==1){PUSH(n-2,m-2,k-1,0,{p.first+1,p.second+1}); continue;}
        if(q.st==2){PUSH(n-2,m,k-m/2,0,p); continue;}
        if(q.st==3){PUSH(n,m-2,k-n/2,0,p); continue;}
        s.pop();
    }
    //k=K;
    while(!s.empty()){
        q=s.top(); s.pop();
        n=q.n; m=q.m; p=q.p; k=q.k;
        mn=max(n,m)/2; mx=n*m/4;
        //cout<<q.n<<" "<<q.m<<" "<<q.k<<" "<<q.st<<" "<<mn<<" "<<mx<<" ("<<q.p.first<<" "<<q.p.second<<")\n";
        if(q.st==1){
            //cout<<"k1="<<k<<endl;
            for(i=0;i<n;i++)a[p.first+i][p.second]=a[p.first+i][p.second+m-1]=k;
            for(i=0;i<m;i++)a[p.first][p.second+i]=a[p.first+n-1][p.second+i]=k;
        }
        else if(q.st==2){
            for(i=p.second;i<=p.second+m-1;i++)a[p.first+n-2][i]=a[p.first+n-1][i]=k-(i-p.second)/2;
        }
        else if(q.st==3){
            for(i=p.first;i<=p.first+n-1;i++)a[i][p.second+m-2]=a[i][p.second+m-1]=k-(i-p.first)/2;
        }
    }
    return fl;
}
void print(){
    int i,j;
    for(i=1;i<=N;i++){
        //for(j=1;j<=M;j++)printf("%lld ",a[i][j]); cout<<endl;
        for(j=1;j<=M;j++)cout<<a[i][j]<<" "; cout<<endl;
    }
}
int main(){
    long long i,j,f;
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    cin>>t;
    for(;t>0;t--){
        cr=0;
        //scanf("%lld %lld %lld",&N,&M,&K);
        cin>>N>>M>>K;
        for(i=1;i<=N;i++) a[i].reserve(M+2);
        /*if(solve()){printf("YES\n"); print();}
        else {printf("NO\n"); continue;}*/
        if(solve()){cout<<"YES\n"; print();}
        else {cout<<"NO\n"; continue;}
    }

    return 0;
}
/*
5
2 2 2
2 2 1
4 4 4
4 4 2
4 6 3

*/
