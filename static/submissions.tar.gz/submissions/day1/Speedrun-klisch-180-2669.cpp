/**
* user:  klisch-180
* fname: Danil
* lname: Klisch
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 09:55:03.747372
*/
//bs:flags:"grader.cpp"
#include <bits/stdc++.h>
using namespace std;

template <typename T>
using normal_queue = priority_queue<T, vector<T>, greater<T>>;

#define x first
#define y second
#define all(x) begin(x), end(x)
#define sz(x) ((int) (x).size())
using ll = long long;
using ld = long double;

#include "speedrun.h"

const int N = 1010;

vector<int> g[N];
vector<int> ch[N];
int parent[N];

void dfs_parent(int u = 1, int p = 0) {
	parent[u] = p;
	for (int v : g[u]) {
		if (v != p) {
			ch[u].push_back(v);
			dfs_parent(v, u);
		}
	}
}

void writeInt(int u, int offset, int value) {
	for (int j = 0; j < 10; ++j) {
		setHint(u, offset + j + 1, value >> j & 1);
	}
}

int readInt(int offset) {
	int ans = 0;
	for (int j = 0; j < 10; ++j) {
		ans |= getHint(offset + j + 1) << j;
	}
	return ans;
}

void assignHints(int, int n, int gu[], int gv[]) {
	for (int i = 1; i < n; ++i) {
		g[gu[i]].push_back(gv[i]);
		g[gv[i]].push_back(gu[i]);
	}
	dfs_parent();
	setHintLen(20);
	for (int i = 1; i <= n; ++i) {
		if (sz(ch[i])) {
			writeInt(i, 0, ch[i][0]);
		}
		if (parent[i]) {
			int m = sz(ch[parent[i]]);
			int j = (int) (find(all(ch[parent[i]]), i) - begin(ch[parent[i]]));
			if (j != m - 1) {
				writeInt(i, 10, ch[parent[i]][j + 1]);
			} else {
				// cout << i << " write " << parent[parent[i]] << endl;
				writeInt(i, 10, parent[parent[i]]);
			}
		}
	}
}

int n;
char used[N];

bool sGoTo(int where) {
	if (where < 1 || where > n) {
		return false;
	}
	return goTo(where);
}

void goTo1(int start) {
	if (start == 1) {
		return;
	}
	int v = readInt(0);
	if (v == 0) {
		for (int i = 1; i <= n; ++i) {
			if (i != v && goTo(i)) {
				// cout << "found " << i << endl;
				start = i;
				break;
			}
		}
	}
	while (start != 1) {
		v = readInt(0);
		// cout << "at " << v << endl;
		assert(v);
		int nxt = v, lst = -1;
		while (sGoTo(nxt)) {
			// cout << "sgoto " << nxt << endl;
			lst = nxt;
			nxt = readInt(10);
			// cout << "nxt " << nxt << endl;
			goTo(start);
		}
		assert(lst != -1);
		goTo(lst);
		// cout << "lst is " << lst << endl;
		start = lst;
	}
}

int dfs(int u = 1, int p = 0) {
	int v = readInt(0);
	while (v != p && v) {
		goTo(v);
		v = dfs(v, u);
	}
	int nxt = readInt(10);
	if (p) {
		goTo(p);
	}
	return nxt;
}

void speedrun(int, int n_, int start) {
	n = n_;
	goTo1(start);
	dfs();
}
