/**
* user:  hosu-b1a
* fname: Iulia
* lname: Hosu
* task:  Present
* score: 0.0
* date:  2021-12-16 11:58:34.197959
*/
#include <iostream>
#include <cstring>

using namespace std;

const int N = 1000;

int dp[N], sum[N], v[N], r[N], poz;
int fixat[N], exista[N];

int cmmdc(int x, int y) {
    int r = x % y;
    while (r)   {
        x = y;
        y = r;
        r = x % y;
    }
    return y;
}

long long lgput(long long b, int e) {
    if (e == 0)
        return 1LL;
    long long ans = lgput(b, e >> 1);
    if (e & 1)
        return ans * ans * b;
    return ans * ans;
}

int nr(int x)   {
    int ans = 0;
    for (int i = 1; i <= x; ++i)    {
        if (fixat[i])
            continue;
        if (fixat[cmmdc(i, x)])
            ++ans;
    }
    return lgput(2, ans);
}

void calc(int &ans, int x)  {
    memset(fixat, 0, sizeof(fixat));
    int nrd = 0;
    for (int i = 1; i < x; ++i)    {
        if (x % i == 0) {
            v[++nrd] = i;
        }
    }
    for (int i = 1; i < (1 << nrd); ++i)    {
        for (int j = 1, s = i; j <= nrd; s >>= 1, ++j) {
            if (s & 1)  {
                fixat[v[j]] = true;
            } else  {
                fixat[v[j]] = false;
            }
        }
        ans += nr(x);
    }
}

void find_vals(int n)    {
    dp[1] = sum[1] = 1;
    int total = 1;
    for (int i = 2; total < n; ++i)  {
        dp[i] = 1;
        calc(dp[i], i);
        total += dp[i];
//        cout << i << ' ' << dp[i] << '\n';
    }
}

int nrMax(int x, int max_value)   {
    int ans = 0;
    memset(exista, 0, sizeof(exista));
    for (int i = 1; i <= poz; ++i)
        exista[r[i]] = true;
    for (int i = 1; i <= poz; ++i)  {
        for (int j = i + 1; j <= poz; ++j)  {
            int gcd = cmmdc(r[i], r[j]);
            if (!exista[gcd] && !fixat[gcd])
                return 0;
        }
    }
    for (int i = 1; i <= max_value; ++i)    {
        for (int j = i + 1; j <= max_value; ++j)    {
            if (fixat[i] && fixat[j] && !fixat[cmmdc(i, j)])
                return 0;
        }
    }
    for (int i = 1; i <= max_value; ++i)    {
        if (fixat[i] || x % i == 0)
            continue;
        if (fixat[cmmdc(i, x)])
            ++ans;
    }
    return lgput(2, ans);
}

bool corect()   {
    memset(exista, 0, sizeof(exista));
    for (int i = 1; i <= poz; ++i)
        exista[r[i]] = true;
    for (int i = 1; i <= poz; ++i)  {
        for (int j = i + 1; j <= poz; ++j)
            if (!exista[cmmdc(r[i], r[j])])
                return false;
    }
    return true;
}

void calcMax(int &ans, int x, int max_value)  {
    max_value = min(max_value, x - 1);
    memset(fixat, 0, sizeof(fixat));
    int nrd = 0;
    for (int i = 1; i <= max_value; ++i)    {
        if (x % i == 0) {
            v[++nrd] = i;
        }
    }
    for (int i = 1; i < (1 << nrd); ++i)    {
        for (int j = 1, s = i; j <= nrd; s >>= 1, ++j) {
            if (s & 1)  {
                fixat[v[j]] = true;
            } else  {
                fixat[v[j]] = false;
            }
        }
        ans += nrMax(x, max_value);
    }
//    if (corect())
//        ++ans;
}

void solve(int n)   {
    int val = 0;
    int aux = 0;
    while (aux < n)
        aux += dp[++val];
    r[++poz] = val;
    if (aux == n)   {
        for (int i = val - 1; i; --i)
            r[++poz] = i;
        return;
    }
    n -= (aux - dp[val]);
    int cmmmc = val;
    while(true) {
        aux = 0;
        val = 0;
        if (n == 1 && corect())
            return;
        if (corect())
            --n;
        while (aux < n) {
            ++val;
            aux = 0;
            calcMax(aux, cmmmc, val);
        }
        if (aux == n)   {
            for (int i = val; i; --i)
                r[++poz] = i;
            return;
        }
        aux = 0;
        calcMax(aux, cmmmc, val - 1);
        n -= aux;
        cmmmc = cmmmc * val / cmmdc(cmmmc, val);
    }
}

int main()  {
    int t, n;
    find_vals(1e8);
    cin >> t;
    while (t--) {
        cin >> n;
        poz = 0;
        solve(n);
        cout << poz << ' ';
        for (int i = poz; i; --i)
            cout << r[i] << ' ';
        cout << '\n';
    }
    return 0;
}
