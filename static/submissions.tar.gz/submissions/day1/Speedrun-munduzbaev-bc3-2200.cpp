/**
* user:  munduzbaev-bc3
* fname: Aidar
* lname: Munduzbaev
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 09:09:10.346579
*/
#include "speedrun.h"

#ifndef EVAL
#include "grader.cpp"
#endif

void assignHints(int subtask, int n, int a[], int b[]) { /* your solution here */
	setHintLen(n);
	for(int i=1;i<n;i++){
		setHint(a[i], b[i], 1);
		setHint(b[i], a[i], 1);
	}
}

const int N = 1005;
int n;

void dfs(int u, int p = -1){
	//~ cout<<u<<"\n";
	for(int i=1;i<=n;i++){
		//~ cout<<i<<" "<<getHint(i)<<"\n";
		if(!getHint(i) || p == i) continue;
		goTo(i);
		dfs(i, u);
	} if(~p) goTo(p);
}

void speedrun(int subtask, int n, int start) { /* your solution here */
	::n = n;
	dfs(start);
}
