/**
* user:  moldovan-92d
* fname: Andrei
* lname: Moldovan
* task:  lucky
* score: 100.0
* date:  2019-10-10 08:39:55.214304
*/
#include <bits/stdc++.h>
using namespace std;
const int mod=1000000007;
char s1[100005];
int v[100005];
long long sol[100005];
long long dp1[100005],dp[100005];
int main()
{
    //freopen("a.in","r",stdin);
    //freopen("a.out","w",stdout);
    int n,p,i;
    scanf("%d%d\n",&n,&p);
    for(int i=1;i<n;i++)
    {
        dp1[0]=dp1[1]=dp1[2]=dp1[3]=dp1[4]=dp1[5]=dp1[6]=dp1[7]=dp1[8]=dp1[9]=0;
        if(i==1)
            for(int  j=0;j<=9;j++)dp1[j]=1;
        else
            for(int j=0;j<=9;j++)
            {

                    for(int t=0;t<=9;t++)
                {
                    if(t!=3){dp1[t]+=dp[j];if(dp1[t]>=mod)dp1[t]-=mod;}
                    if(t==3&&j!=1){dp1[t]+=dp[j];if(dp1[t]>=mod)dp1[t]-=mod;}
                }
            }
        for(int j=0;j<=9;j++)
            dp[j]=dp1[j];
                long long sum=0;
    for(int j=0;j<=9;j++)
        {sum+=dp[j];if(sum>=mod)sum-=mod;}
       // if(i==1)sum++;
        sol[i+1]=sum;
    }sol[1]=1;sol[0]=0;
    long long put2=1;
    long long nr3=0;
    int ok=0;
    int ant=0;
    for(i=1;i<=n;i++)
    {
        char ch;
        scanf("%c",&ch);
        int nr=ch-'0';
        v[i]=nr;
        if(ok)continue;
        if(nr==0){ant=nr;continue;}
        if(nr==1)
        {
            nr3+=sol[n-i+1];
            nr3%=mod;
        }
        else
            {nr3+=(1LL*sol[n-i+1]*nr)%mod,nr3-=sol[n-i],nr3%=mod;if(ant==1&&nr>=4)nr3-=sol[n-i+1];nr3%=mod;}
            if(nr==3&&ant==1)ok=1;
            ant=nr;
    }
    if(nr3<0)nr3+=mod;
    cout<<nr3+1-ok<<"\n";
    for(int t=1;t<=p;t++)
    {
        ant=0;
        nr3=0;
        ok=0;
        int z,x,y;
        scanf("%d%d%d",&z,&x,&y);
        if(z==1)
        {
                for(i=x;i<=y;i++)
    {

        int nr=v[i];
        if(ok)break;
        if(nr==0){ant=nr;continue;}
        if(nr==1)
        {
            nr3+=sol[y-i+1];
            nr3%=mod;
        }
        else
            {nr3+=(1LL*sol[y-i+1]*nr)%mod,nr3-=sol[y-i],nr3%=mod;if(ant==1&&nr>=4)nr3-=sol[y-i+1];nr3%=mod;}
            if(nr==3&&ant==1)ok=1;
            ant=nr;
    }
        if(nr3<0)nr3+=mod;
    cout<<nr3+1-ok<<"\n";
        }
        else
            v[x]=y;
    }
    return 0;
}
