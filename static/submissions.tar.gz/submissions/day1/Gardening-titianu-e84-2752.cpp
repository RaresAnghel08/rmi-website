/**
* user:  titianu-e84
* fname: Mihai-Cezar
* lname: Titianu
* task:  Gardening
* score: 11.0
* date:  2021-12-16 10:03:57.046262
*/
#include <iostream>
#include <cmath>
#include <queue>

int main() {
	std::queue <int> qin, qout;
	int nrt, nrn, nrm, nrk;
	int loops, dif;
	int sizx, sizy;
	int col;
	std::cin >> nrt;
	while (nrt--) {
		std::cin >> nrn >> nrm >> nrk;
		if(!(nrn & 1) && !(nrm & 1) && nrk <= (nrn >> 1) * (nrm >> 1) && nrk >= (std::max(nrn, nrm) >> 1)) {
			loops = (int)(((double)(nrn >> 1) + (nrm >> 1) - 1 - std::sqrt(((nrn >> 1) - (nrm >> 1)) * ((nrn >> 1) - (nrm >> 1)) + 4 * nrk - nrn - nrm + 1)) / 2);
			dif = ((nrn >> 1) - loops) * ((nrm >> 1) - loops) - (nrk - loops);
			if (dif == 1) {
				std::cout << "NO\n";
			}
			else {
				if (dif) {
					dif -= 2;
					dif <<= 1;
					sizx = std::max(4, 8 + dif - nrm + (loops << 1)) - 1;
					sizy = std::min(4 + dif, nrm - (loops << 1)) - 1;
					col = (loops + 2) << 1;
				}
				else {
					sizx = -1;
					sizy = -1;
					col = (loops + 1) << 1;
				}
				std::cout << "YES\n";
				for (int index = 0; index < loops; index++) {
					for (int index2 = 0; index2 < nrm; index2++) {
						std::cout << std::min(index + 1, std::min(nrm - index2, index2 + 1)) << ' ';
					}
					std::cout << '\n';
				}
				for (int index = loops; index < nrn - loops; index++) {
					for (int index2 = 0; index2 < loops; index2++) {
						std::cout << index2 + 1 << ' ';
					}
					for (int index2 = loops; index2 < nrm - loops; index2++) {
						if (index - loops == 0 || index - loops == sizx) {
							if (index2 - loops <= sizy) {
								std::cout << loops + 1 << ' ';
							}
							else {
								if ((index - loops) & 1) {
									std::cout << qout.front() << ' ';
									qout.pop();
								}
								else {
									std::cout << (col >> 1) << ' ';
									qout.push(col >> 1);
									col++;
								}
							}
						}
						else if(index - loops < sizx) {
							if (index2 - loops == 0 || index2 - loops == sizy) {
								std::cout << loops + 1 << ' ';
							}
							else if (index2 - loops < sizy) {
								if ((index - loops) & 1) {
									std::cout << (col >> 1) << ' ';
									qin.push(col >> 1);
									col++;
								}
								else {
									std::cout << qin.front() << ' ';
									qin.pop();
								}
							}
							else {
								if ((index - loops) & 1) {
									std::cout << qout.front() << ' ';
									qout.pop();
								}
								else {
									std::cout << (col >> 1) << ' ';
									qout.push(col >> 1);
									col++;
								}
							}
						}
						else {
							if ((index - loops) & 1) {
								std::cout << qout.front() << ' ';
								qout.pop();
							}
							else {
								std::cout << (col >> 1) << ' ';
								qout.push(col >> 1);
								col++;
							}
						}

					}
					for (int index2 = nrm - loops; index2 < nrm; index2++) {
						std::cout << nrm - index2 << ' ';
					}
					std::cout << '\n';
				}
				for (int index = nrn - loops; index < nrn; index++) {
					for (int index2 = 0; index2 < nrm; index2++) {
						std::cout << std::min(nrn - index, std::min(nrm - index2, index2 + 1)) << ' ';
					}
					std::cout << '\n';
				}
			}
		}
		else {
			std::cout << "NO\n";
		}
	}
}