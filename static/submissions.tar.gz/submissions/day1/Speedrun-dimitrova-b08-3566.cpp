/**
* user:  dimitrova-b08
* fname: Niya Radoslavova
* lname: Dimitrova
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 11:18:29.343831
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;
void assignHints(int subtask, int N, int A[], int B[])
{
    setHintLen(N);
    for(int i=1;i<N;i++)
    {
        int x = A[i];
        int y = B[i];
        setHint(x, y, 1);
        setHint(y, x, 1);
    }
}
int used[100000];
void dfs(int w, int l, int from)
{
    used[w] = 1;
    for(int i=1;i<=l;i++)
    {
        bool lamp1 = getHint(i);
        if( lamp1 == 1 && used[i] == 0 )
        {
            bool lamp2 = goTo(i);
            if( lamp2 == 1 )
            {
                dfs(i,l,w);
            }
        }
    }
    if( w != from )
    {
        bool lamp2 = goTo(from);
        return;
    }
    return;
}
void speedrun(int subtask, int N, int start)
{
    int l = getLength();
    dfs(start,l,start);
}
