/**
* user:  chivu-073
* fname: Andreea
* lname: Chivu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:22:24.554393
*/
#include <iostream>

using namespace std;

int main()
{
    int t;
    cin >> t;
    for(int i = 1; i <= t; i++){
        int n, m, k;
        cin >> n >> m >> k;
        if(n == 1){
            if(m == 1){
                if(k == 1){
                    cout << "YES\n1";
                }else
                    cout << "NO";
            }else if(m == 2){
                if(k == 1){
                    cout << "YES\n";
                    cout << "1 1";
                }else if(k == 2){
                    cout << "YES\n";
                    cout << "1 2";
                }else{
                    cout <<"NO";
                }
            }else if(m == 3){
                if(k == 1){
                    cout << "YES\n1 1 1";
                }else if(k == 3){
                    cout << "YES\n1 2 3";
                }else{
                    cout << "NO";
                }
            }else if(m == 4){
                if(k == 1){
                    cout << "YES\n1 1 1 1";
                }else if(k == 4){
                    cout << "YES\n1 2 3 4";
                }
            }
        }else if(n == 2){
            if(m == 1){
                if(k == 1){
                    cout << "YES\n1\n1";
                }else if(k ==2){
                    cout << "YES\n1\n2";
                }else{
                    cout << "NO";
                }
            }else if(m == 2){
                if(k == 1){
                    cout << "YES\n1 1\n1 1";
                }else if(k == 4){
                    cout << "YES\n1 2\n3 4";
                }else{
                    cout << "NO";
                }
            }else if(m == 3){
                if(k == 1){
                    cout << "YES\n1 1 1\n1 1 1";
                }else if(k == 3){
                    cout << "YES\n1 1 2\n1 1 3";
                }else if(k == 6){
                    cout << "YES\n1 2 3\n4 5 6";
                }else{
                    cout << "NO";
                }
            }else if(m == 4){
                if(k == 1){
                    cout << "YES\n1 1 1 1\n1 1 1 1";
                }else if(k == 2){
                    cout << "YES\n1 1 2 2\n1 1 2 2";
                }else if(k == 5){
                    cout << "YES\n1 1 2 3\n1 1 4 5";
                }else if(k == 8){
                    cout << "YES\n1 2 3 4\n5 6 7 8";
                }
            }
        }else if(n == 3){
            if(m == 1){
                if(k == 1){
                    cout << "YES\n1\n1\n1";
                }else if(k == 3){
                    cout << "YES\n1\n2\n3";
                }
            }else if(m == 2){
                if(k == 1){
                    cout << "YES\n1 1\n1 1\n1 1";
                }else if(k == 3){
                    cout << "YES\n1 1\n1 1\n2 3";
                }else if(k == 6){
                    cout << "YES\n1 2 3\n4 5 6\n7 8 9";
                }
            }else if(m == 3){
                if(k == 1){
                    cout << "YES\n1 1 1\n1 1 1\n1 1 1";
                }else if(k == 2){
                    cout << "YES\n1 1 1\n1 2 1\n1 1 1";
                }else if(k == 6){
                    cout << "YES\n1 1 2\n1 1 3\n4 5 6";
                }else if(k == 9){
                    cout << "YES\n1 2 3\n4 5 6\n7 8 9";
                }else{
                    cout <<"NO";
                }
            }else if(m == 4){
                if(k == 1){
                    cout << "YES\n1 1 1 1\n1 1 1 1\n1 1 1 1";
                }else if(k == 3){
                    cout << "YES\n1 1 1 1\n1 2 3 1\n1 1 1 1";
                }else if(k == 6){
                    cout << "YES\n1 1 2 2\n1 1 2 2\n3 4 5 6";
                }else if(k == 12){
                    cout << "YES\n1 2 3 4\n5 6 7 8\n9 10 11 12";
                }else{
                    cout << "NO";
                }
            }
        }else if(n == 4){
            if(m == 1){
                if(k == 1){
                    cout << "YES\n1\n1\n1\n1";
                }else if(k == 4){
                    cout << "YES\n1\n2\n3\n4";
                }else{
                    cout << "NO";
                }
            }else if(m == 2){
                if(k == 1){
                    cout << "YES1 1\n1 1\n1 1\n1 1";
                }else if(k == 2){
                    cout << "YES1 1\n1 1\n2 2\n2 2";
                }else if(k == 5){
                    cout << "YES1 1\n1 1\n2 3\n4 5";
                }else if(k == 8){
                    cout << "YES1 2\n3 4\n5 6\n7 8";
                }else{
                    cout << "NO";
                }
            }else if(m == 3){
                if(k == 1){
                    cout << "YES\n1 1 1\n1 1 1\n1 1 1\n1 1 1";
                }else if(k == 3){
                    cout << "YES\n1 1 1\n1 2 1\n1 3 1\n1 1 1";
                }else if(k == 6){
                    cout << "YES\n1 1 3\n1 1 4\n2 2 5\n2 2 6";
                }else if(k == 12){
                    cout << "YES\n1 2 3\n4 5 6\n7 8 9\n10 11 12";
                }else{
                    cout << "NO";
                }
            }else if(m == 4){
                if(k == 1){
                    cout << "YES\n1 1 1 1\n1 1 1 1\n1 1 1 1\n1 1 1 1";
                }else if(k == 4){
                    cout << "YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4";
                }else if(k == 5){
                    cout << "YES\n1 1 1 1\n1 2 3 1\n1 4 5 1\n1 1 1 1";
                }else if(k == 10){
                    cout << "YES\n1 1 2 2\n1 1 2 2\n3 4 5 6\n7 8 9 10";
                }else if(k == 13){
                    cout << "YES\n1 1 2 3\n1 1 4 5\n6 7 8 9\n10 11 12 13";
                }else if(k == 16){
                    cout << "YES\n1 2 3 4\n5 6 7 8\n9 10 11 12\n13 14 15 16";
                }else if(k == 2){
                    cout << "YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1";
                }else if(k == 7){
                    cout << "YES\n1 1 3 3\n1 1 3 3\n2 2 4 5\n2 2 6 7";
                }else{
                    cout << "NO";
                }
            }
        }
        cout << "\n";
    }
    return 0;
}
