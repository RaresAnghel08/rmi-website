/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Present
* score: 29.0
* date:  2021-12-16 11:25:22.167253
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)


using namespace std;
typedef long long ll;
typedef pair<int,int> pii;

set <int> ans[1000001];


ll a[1000001];


int main(){
	a[0] = 0;
	a[1] = 2;
	
	
	ans[1] = {1};
	
	int p = 2;
	
	for(int i = 2; p <= 1000000; i ++){
		int tar = p;
		a[p] = (1<<i);
		++p;
		for(int j = 1; j < tar && p <= 1000000; j ++){
			bool ok = true;
			fr(k, 2, i){
				if((a[j]&(1<<k)) && !(a[j]&(1<<__gcd(i, k)))){
					ok = false;
					break;
				}
			}
			if(ok){
				a[p] = a[j] | (1<<i);
				++p;
			}
			
			
			/*for(auto u : ans[j]){
				int g = __gcd(i, u);
				if(ans[j].find(g) == ans[j].end()){
					ok = false;
					break;
				}
			}
			if(ok){
				ans[p] = ans[j];
				ans[p].insert(i);
				
				++p;
				
			}*/
		}
		
	}
	
	
	
	
	
	int t;
	cin >> t;
	while(t--){
		int k;
		cin >> k;
		vector<int> ot;
		fr(i, 0, 30){
			if(a[k] & (1<<i)){
				ot.pb(i);
			}
		}
		
		
		
		cout<<ot.size()<<' ';
		for(auto u : ot){
			cout<<u<<' ';
		}
		cout<<endl;
	}
	

}
