/**
* user:  chkhaidze-a0b
* fname: George
* lname: Chkhaidze
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:41:05.282275
*/
#include <bits/stdc++.h>
using namespace std;

inline void solve() {
	int n, m, k;
	cin >> n >> m >> k;
	if (4 * k > (n - n % 2) * (m - m % 2)) {
		cout << "NO\n";
		return;
	}
		
	cout << "YES\n";
	int col = 0;
	int ans[n + 2][m + 3];
	for (int i = 1; i < n; i += 2) {
		for (int j = 1; j < m; j += 2) {
			bool t1 = (i + 2 == n);
			bool t2 = (j + 2 == m); 
			int sza = 2, szb = 2;
			col = min(col + 1, k);
			if (t2) ++szb;
			if (t1) ++sza; 
			for (int a = 0; a < sza; ++a)
				for (int b = 0; b < szb; ++b) 
					ans[i + a][j + b] = col;
		}
	}
	
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j) 
			cout << ans[i][j] << " ";
		cout << "\n";
	}
}

main () { 
	ios::sync_with_stdio(false);
	cin.tie(NULL), cout.tie(NULL);
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
}
