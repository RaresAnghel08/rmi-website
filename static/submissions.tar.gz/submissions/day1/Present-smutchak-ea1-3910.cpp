/**
* user:  smutchak-ea1
* fname: Andrii
* lname: Smutchak
* task:  Present
* score: 0.0
* date:  2021-12-16 11:47:05.006359
*/
#pragma GCC optimize("Ofast,inline")
#pragma GCC target("avx2,sse2,bmi")

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,m,k;
bool check(int mask){
    vector<int> g;
    for(int i = 0;i < 25;i++){
        if((mask>>i)&1) g.push_back(i+1);
    }
    for(int i =0;i < g.size();i++){
        for(int j = i+1;j < g.size();j++){
            if(lower_bound(g.begin(),g.end(),__gcd(g[i],g[j])) == g.end() or *lower_bound(g.begin(),g.end(),__gcd(g[i],g[j])) != __gcd(g[i],g[j])) return 0;
        }
    }
    return 1;
}
int pre_ans[1000007];
void solve(){
    cin >> k;
    int cnt = 0;
    int mask = 1;
    while(cnt < k){
        if(check(mask++)) cnt++;
    }
    mask--;
    int cnt_of_bit = 0;
    for(int i = 0;i < 25;i++) if((mask>>i)&1) cnt_of_bit++;
    cout << cnt_of_bit << " ";
    for(int i = 0;i < 25;i++) if((mask>>i)&1) cout << i+1 << " ";
    cout << "\n";
}
int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t = 1;
    cin >> t;
    while(t--) solve();
    return 0;
}
