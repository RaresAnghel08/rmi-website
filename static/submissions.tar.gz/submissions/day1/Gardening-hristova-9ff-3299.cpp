/**
* user:  hristova-9ff
* fname: Simona Nikolaeva
* lname: Hristova
* task:  Gardening
* score: 5.0
* date:  2021-12-16 10:53:08.853007
*/
#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>
#include <cstring>
#include <algorithm>

using namespace std;
int t,n,m,k;
void smart_query()
{
    if(n*m!=4&&k==1)
    {
        cout<<"NO"<<endl;
        return;
    }
    if(n%2==0&&m%2==0&&(n/2)*(m/2)==k)
    {
        cout<<"YES"<<endl;
        int num=1;
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                int min_r=i/2;
                if(j==0)cout<<min_r+min_r*((m-1)/2)+j/2+1;
                else cout<<" "<<min_r+min_r*((m-1)/2)+j/2+1;
            }
            cout<<endl;
        }
        return;
    }
    if(n%2==0&&m%2==0&&k-1==((n-2)/2)*((m-2)/2))
    {
        cout<<"YES"<<endl;
        cout<<1;
        for(int i=1; i<m; i++)cout<<" "<<1;
        cout<<endl;
        for(int i=0; i<n-2; i++)
        {
            cout<<1<<" ";
            for(int j=0; j<m-2; j++)
            {
                int min_r=i/2;
                cout<<min_r+min_r*((m-3)/2)+j/2+2<<" ";
            }
            cout<<1<<endl;
        }
        cout<<1;
        for(int i=1; i<m; i++)cout<<" "<<1;
        cout<<endl;
        return;
    }
    cout<<"NO"<<endl;
}
void subtask2()
{
    if(n==1)
    {
        cout<<"NO"<<endl;
        return;
    }
    if(n==2)
    {
        if(m%2==0&&k==m/2)
        {
            for(int i=0; i<m; i++)cout<<i/2+1<<" ";
            cout<<endl;
            for(int i=0; i<m; i++)cout<<i/2+1<<" ";
            cout<<endl;
        }
        else
        {
            cout<<"NO"<<endl;
        }
        return;
    }
    if(n==3)
    {
        cout<<"NO"<<endl;
        return;
    }
    if(n==4)
    {
        if(m%2==1)
        {
            cout<<"NO"<<endl;
            return;
        }
        int c1=m;
        int c2=m/2;
        if(k==c1)
        {
            cout<<"YES"<<endl;
            for(int i=0; i<n; i++)
            {
                for(int j=0; j<m; j++)
                {
                    int min_r=i/2;
                    if(j==0)cout<<min_r+min_r*((m-1)/2)+j/2+1;
                    else cout<<" "<<min_r+min_r*((m-1)/2)+j/2+1;
                }
                cout<<endl;
            }
            return;
        }
        else if(k==c2)
        {
            cout<<"YES"<<endl;
            cout<<1;
            for(int i=1; i<m; i++)cout<<" "<<1;
            cout<<endl;
            for(int i=0; i<n-2; i++)
            {
                cout<<1<<" ";
                for(int j=0; j<m-2; j++)
                {
                    int min_r=i/2;
                    cout<<min_r+min_r*((m-3)/2)+j/2+2<<" ";
                }
                cout<<1<<endl;
            }
            cout<<1;
            for(int i=1; i<m; i++)cout<<" "<<1;
            cout<<endl;
            return;
        }
    }
    cout<<"NO"<<endl;
}
void equal4()
{
    if(n%2!=0)
    {
        cout<<"NO"<<endl;
        return;
    }
    int c1=m/2*n/2;
    int c2=(m-2)/2*(n-2)/2+1;
    cout<<c1<<" "<<c2<<endl;
    if(c1==k)
    {
        cout<<"YES"<<endl;
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                int min_r=i/2;
                if(j==0)cout<<min_r+min_r*((m-1)/2)+j/2+1;
                else cout<<" "<<min_r+min_r*((m-1)/2)+j/2+1;
            }
            cout<<endl;
        }
        return;
    }
    else if(c2==k)
    {
        cout<<"YES"<<endl;
        cout<<1;
        for(int i=1; i<m; i++)cout<<" "<<1;
        cout<<endl;
        for(int i=0; i<n-2; i++)
        {
            cout<<1<<" ";
            for(int j=0; j<m-2; j++)
            {
                int min_r=i/2;
                cout<<min_r+min_r*((m-3)/2)+j/2+2<<" ";
            }
            cout<<1<<endl;
        }
        cout<<1;
        for(int i=1; i<m; i++)cout<<" "<<1;
        cout<<endl;
        return;
    }
}
void solve()
{
    cin>>t;
    for(int i=0; i<t; i++)
    {
        cin>>n>>m>>k;
        if(n<=4&&m<=4)smart_query();
        else if(n==m)equal4();
        else subtask2();
    }
}
int main()
{
    solve();
    return 0;
}
