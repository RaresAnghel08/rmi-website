/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  devil
* score: 0.0
* date:  2019-10-10 08:56:48.187711
*/
#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll d[10],t,k;
void solve()
{
    cin>>k;
    vector<ll>p;
    ll cnt=0;
    vector<ll>v;
    for(int i=1;i<10;i++)
    {
        cin>>d[i];
        while(--d[i]>=0)
        {
            v.push_back(i);
            p.push_back(cnt);cnt++;
        }
    }
    ll mx1=1e17,d=pow(10,k-1);
    vector<ll>p1,p2;
    do
    {
        if(p1==p)continue;
        ll mx=0,x=0;
        for(ll i=p.size()-k;i<p.size();i++)
        {
            x=x*10+v[p[i]];
        }
        mx=x;
        for(ll i=p.size()-k-1;i>=0;i--)
        {
            x/=10;x+=d*v[p[i]];
            mx=max(mx,x);
        }
        if(mx<mx1)
        {
            mx1=mx;
            p2=p;
        }
        p1=p;
    }while(next_permutation(p.begin(),p.end()));
    for(int i=0;i<p2.size();i++)
    {
        cout<<v[p2[i]];
    }
    cout<<endl;
}
void solve1()
{
    cin>>k;
    ll cnt=0;
    for(int i=1;i<10;i++)
    {
        cin>>d[i];cnt+=d[i];
    }
    string s="";
    for(int i=0;i<cnt;i++)
    {
        if(i%2==0)
        {
            for(int j=9;j>=1;j--)
            {
                if(d[j]>0)
                {
                    s+=char('0'+j);
                    d[j]--;
                    break;
                }
            }
        }
        else
        {
            for(int j=1;j<10;j++)
            {
                if(d[j]>0)
                {
                    s+=char('0'+j);
                    d[j]--;
                    break;
                }
            }
        }
    }
    reverse(s.begin(),s.end());
    cout<<s<<endl;
}
void solve2()
{
    cin>>k;
    for(int i=1;i<10;i++)cin>>d[i];
    //cout<<"*\n";
    if(d[2]<k)
    {
        for(int i=0;i<d[1];i++)cout<<"1";
        for(int i=0;i<d[2];i++)cout<<"2";
        cout<<endl;
        return;
    }
    if(d[1]==0)
    {
        for(int i=0;i<d[2];i++)cout<<"2";
        cout<<endl;
        return;
    }
    //cout<<"**\n";
    d[2]-=k-1;
    string ans="";
    for(int i=1;i<k;i++)ans+="2";
    if(d[1]>=d[2])
    {
        //cout<<"***\n";
        ll r=d[1]/d[2],t=d[1]%d[2];
        while(d[1]+d[2]>0)
        {
            for(int i=0;i<r;i++)ans+="1",d[1]--;
            if(t)ans+="1",t--,d[1]--;
            ans+="2",d[2]--;
        }
        reverse(ans.begin(),ans.end());
        cout<<ans<<endl;
    }
    else
    {
        //cout<<"****\n";
        ll r=d[2]/d[1],t=d[2]%d[1];
        string ans1="";
        while(d[1]+d[2]>0)
        {
            if(t)ans1+="2",d[2]--,t--;
            for(int i=0;i<r;i++)ans1+="2",d[2]--;
            ans1+="1",d[1]--;
        }
        reverse(ans.begin(),ans.end());
        ans1+=ans;
        cout<<ans1<<endl;
    }
}
int main()
{
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    //cout.tie(NULL);
    cin>>t;
    while(t--)solve2();
return 0;
}
/*
1
2
1 1 2 0 0 0 0 0 0

*/
