/**
* user:  munzel-765
* fname: Lukas
* lname: Münzel
* task:  Present
* score: 0.0
* date:  2021-12-16 11:13:09.623151
*/
// #ifndef LOCAL
// #pragma GCC optimize("O3")
// #pragma GCC optimize("unroll-loops")
// #pragma GCC target("sse,sse2,sse3,sse4,avx,avx2")
// #endif

#include <bits/stdc++.h>

#define int long long
#define rep(i,n) for(int i = 0; i<n;i++)
#define all(a) a.begin(), a.end()

using namespace std;

bool comp(const vector<int> & a, const vector<int> & b)
{ 
  int i = a.size()-1, j=b.size()-1;
  for(; min(i,j)>=0;) 
  {
      if(a[i]!=b[j]) return a[i] < b[j];
      i--;j--;
  }
  return a.size() < b.size();
}

bool is_valid(vector<int>& v)
{
    rep(i, v.size())
    {
        rep(j, i)
        {
            auto it = lower_bound(all(v), __gcd(v[i], v[j]));
            if(it==v.end()||*it!=__gcd(v[i], v[j])) return false;
        }
    }
    return true;
}
signed main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(false);

    vector<vector<int>>found;
    
    for(int i = 0; i <= 256; i++)
    {
        vector<int>cur;
        rep(j, 8) if((i>>j)&1) cur.push_back(j+1);
        if(is_valid(cur)) found.push_back(cur);
    }
    // found = {{1}, {2}, {1,2}};
    sort(found.begin(), found.end(), comp);
    // rep(i, 101)
    // {
    //     for(int& x : found[i]) cout<<x<<" ";
    //     cout<<"\n";
    // }
    int k;
    cin>>k;

    for(int& x : found[k]) cout<<x<<" ";
    cout<<'\n';
}