/**
* user:  feodorov-90b
* fname: Andrei
* lname: Feodorov
* task:  devil
* score: 0.0
* date:  2019-10-10 06:18:21.125575
*/
#include <iostream>

using namespace std;
int f[10],frec[100005],v[100005];
int main()
{
    int t,k;
    cin>>t;
    while(t){
        t--;
        int k,n=0;
        cin>>k;
        for(int i=1;i<=9;i++){
            cin>>f[i];
            n+=f[i];
        }
        if(k==2){
            for(int i=1;i<=100000;i++)
                frec[i]=0;
            int cur=9;
            while(f[cur]==0){
                cur--;
            }
            f[cur]--;
            v[n]=cur;
            while(f[cur]==0){
                cur--;
            }
            for(int i=1;i<n;i+=2){
                if(f[cur]==0){
                    break;
                }
                v[i]=cur;
                f[cur]--;
                frec[i]=1;
            }
            cur=1;
            for(int i=2;i<n;i+=2){
                while(f[cur]==0){
                    cur++;
                }
                v[i]=cur;
                frec[i]=1;
                f[cur]--;
            }
            for(int i=1;i<n;i++){
                while(f[cur]==0){
                    cur++;
                    if(cur==10)
                        break;
                }
                if(frec[i]==0){
                    v[i]=cur;
                    f[cur]--;
                }
            }
            for(int i=1;i<=n;i++){
                cout<<v[i];
            }
            cout<<"\n";
        }
    }
    return 0;
}
