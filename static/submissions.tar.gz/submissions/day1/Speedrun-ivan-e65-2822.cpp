/**
* user:  ivan-e65
* fname: Tudor
* lname: Ivan
* task:  Speedrun
* score: 27.0
* date:  2021-12-16 10:09:07.873167
*/
#include "speedrun.h"
#include<bits/stdc++.h>
using namespace std;
const int LMAX = 20;
void makehint(int nod, int val, int fs){
  int startb = 1;
  if(fs == 2)
    startb = 11;
  for(int b = 0; b < 10 ; b++){
    setHint(nod, startb, (val>>b)&1);
    startb++;
  }
}

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
  setHintLen(LMAX);
  vector<vector<int>> gr;
  gr.resize(N + 1, vector<int>(0));
  for(int i =1 ; i <N; i++){
    int u, v;
    u = A[i], v = B[i];
    gr[u].push_back(v);
    gr[v].push_back(u);
  }
  if(subtask == 3){
    for(int i = 1; i <=N; i++){
      for(int j = 0; j < gr[i].size(); j++){
        makehint(i, gr[i][j], j + 1);
      }
    }
  }
  else if(subtask == 2){
    int root = 0;
    for(int i = 1; i <=N; i++){
      if(gr[i].size() == N - 1)
        root = i;
    }
    for(int i = 1; i <=N; i++){
      makehint(i, root, 1);
    }
  }

}
int LEN;
int getnr(int tip){
  int ans = 0;
  int startb = 1;
  if(tip == 2)
    startb = 11;
  for(int b = 0; b <10; b++){
    bool val = getHint(startb);
    if(val)
      ans += (1<<b);
    startb++;
  }
  return ans;
}
bool viz[1005];
const int UNK = -1;
void dfs(int nod, int dad){
  for(int i = 0; i <=1; i++){
    int son = getnr(i + 1);
    if(son != 0 && son != dad){
      goTo(son);
      dfs(son, nod);
      goTo(nod);
    }
  }
}
void speedrun(int subtask, int N, int start) { /* your solution here */
  LEN = getLength();
  if(subtask == 3){
    dfs(start, 0);
  }
  else if(subtask == 2){
    int root = getnr(1);
    if(start != root)
      goTo(root);
    for(int i =1 ; i<=N; i++){
      if(i == root)
        continue;
      goTo(i);
      goTo(root);
    }
  }
}
