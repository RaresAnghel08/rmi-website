/**
* user:  chiriac-c10
* fname: Matei
* lname: Chiriac
* task:  Present
* score: 8.0
* date:  2021-12-16 09:43:01.642181
*/
#include <bits/stdc++.h>

using namespace std;

long long t,nr;
long long dp[2400005];

bool check(int mask, int b)
{
    for(int b2=0;b2<b;b2++)
    {
        if((mask>>b2)&1)
        {
            int id = __gcd(b+1, b2+1)-1;

            if(!((mask>>id)&1))
                return false;
        }
    }

    return true;
}

void calcDp()
{
    dp[0]=1;
    for(int mask=0;mask<(1<<21);mask++)
    {
        for(int b=0;b<21;b++)
        {
            if((1<<b) <= mask)
                continue;

            if(dp[mask] && check(mask, b))
                dp[mask + (1<<b)] = true;
        }
    }
}
void calcDp2()
{

}

void bkt(long long nr, int maxi, long long sufP, long long sufI, vector<int> &ans)
{
    for(int mask=0;mask<(1<<21);mask++)
    {
        if(dp[mask])
            nr--;

        if(nr == -1)
        {
            for(int b=0;b<21;b++)
            {
                if((mask>>b)&1)
                    ans.push_back(b+1);
            }

            return;
        }
    }
}
int main()
{
    calcDp();
    calcDp2();

    cin>>t;
    while(t)
    {
        t--;
        cin>>nr;

        long long sufP=0;
        long long sufI=0;
        vector<int> ans;

        bkt(nr, 40, sufP, sufI, ans);

        cout<<ans.size()<<' ';
        for(int it : ans)
            cout<<it<<' ';
        cout<<'\n';
    }
    return 0;
}
