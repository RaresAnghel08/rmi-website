/**
* user:  john-316
* fname: Josia
* lname: John
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:54:13.362011
*/
// #pragma GCC optimize("Ofast")
// #pragma optimize("unroll-loops")
// #pragma target("sse,sse2,sse3,ssse3,sse4,avx,avx2")

// #include <bits/stdc++.h>

#include <iostream>
#include <vector>
#include <assert.h>

#define int int64_t

using namespace std;





// void fillout(int& cnt, vector<vector<int>>& garden, int w, int h, int offset) {
//     for (int a = 0; a<w; a+=2) {
//         for (int i = a/2; i<h-a/2; i++) {
//             garden[offset+i][0+a/2] = cnt;
//             garden[offset+i][w-1-a/2] = cnt;
//         }
//         for (int i = a/2; i<w-a/2; i++) {
//             garden[offset+a/2][i] = cnt;
//             garden[offset+h-1-a/2][i] = cnt;
//         }
//         cnt++;
//     }
//     for (int i = 2; i<h-w+1; i+=2) {
//         garden[offset+i+w/2-1][w/2-1] = cnt;
//         garden[offset+i+w/2][w/2-1] = cnt;
//         garden[offset+i+w/2-1][w/2] = cnt;
//         garden[offset+i+w/2][w/2] = cnt;

//         cnt++;
//     }
// }


// void fillout2(int& cnt, vector<vector<int>>& garden, int w, int h, int offset, int offset2) {
//     for (int i = 0; i<h-w+1; i+=2) {
//         // cerr << offset << " " << i << " " << w << " " << offset2 << "\n";
//         garden[offset+i+w/2-1][w/2-1+offset2] = cnt;
//         garden[offset+i+w/2][w/2-1+offset2] = cnt;
//         garden[offset+i+w/2-1][w/2+offset2] = cnt;
//         garden[offset+i+w/2][w/2+offset2] = cnt;

//         cnt++;
//     }
// }
vector<vector<int>> res;
int cnt;


void fillBoarder(int n, int m, int offset) {
    for (int i = offset; i<n+offset; i++) {
        res[i][offset] = cnt;
        res[i][offset+m-1] = cnt;
    }
    for (int i = offset; i<m+offset; i++) {
        res[offset][i] = cnt;
        res[offset+n-1][i] = cnt;
    }
    cnt++;
}

void fillSmaller(int n, int m, int offset) {
    if (n>=m) {
        for (int i = offset; i<m+offset-1; i+=2) {
            res[n+offset-1][i] = cnt;
            res[n+offset-1][i+1] = cnt;
            res[n+offset-2][i] = cnt;
            res[n+offset-2][i+1] = cnt;
            
            cnt++;
        }   
    }
    else {
        for (int i = offset; i<n+offset-1; i+=2) {
            res[i][m+offset-1] = cnt;
            res[i+1][m+offset-1] = cnt;
            res[i][m+offset-2] = cnt;
            res[i+1][m+offset-2] = cnt;

            cnt++;
        }
    }
}


bool solve(int n, int m, int k) {
    cnt = 1;
    res.clear();
    res.assign(n, vector<int>(m));



    if (n%2 || m%2) return 0;

    if (k > (n*m)/4) return 0;

    if ((n*m)/4 - k == 1) return 0;

    if (k < (n*m/4)/(max(n, m)/2)) return 0;


    int offset = 0;


    while (n != 0 && m != 0) {
        if ((n*2 + (m-2)*2)/4 <= n*m/4 - k + 1) {
            // cout << "Border\n";
            fillBoarder(n, m, offset);
            offset++;
            k--;
            n-=2;
            m-=2;
        }
        else {
            // cout << "Edge\n";
            fillSmaller(n, m, offset);
            k-=min(n, m)/2;
            if (n>=m) n-=2;
            else m-=2;
        }



        // for (auto i: res) {
        //     for (int j: i) {
        //         cout << j << " ";
        //     }
        //     cout << "\n";
        // } cout << "\n";
    }

    return 1;
}






signed main() {
    cin.tie(0);
    ios_base::sync_with_stdio(0);

    int t; cin >> t;

    for (int tc = 0; tc < t; tc++) {
        int n, m, k; cin >> n >> m >> k;


        bool ok = solve(n, m, k);

        if (!ok) {
            cout << "NO\n";
            continue;
        }

        cout << "YES\n";  

        for (auto i: res) {
            for (int j: i) {
                cout << j << " ";
            }
            cout << "\n";
        } 

    }

    // vector<vector<int>> test(8, vector<int>(6));
    // int cnt = 1;
    // fillout(cnt, test, 2, 8, 0);

    // for (auto i: test) {
    //     for (int j: i) {
    //         cerr << j << " ";
    //     }
    //     cerr << "\n";
    // }


    return 0;
}