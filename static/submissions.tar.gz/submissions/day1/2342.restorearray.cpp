/**
* user:  nicolae-502
* fname: Radu Mihai
* lname: Nicolae
* task:  restore
* score: 0.0
* date:  2019-10-10 09:02:46.439307
*/
#include<fstream>
#include<iostream>
#define fin cin
#define fout cout
using namespace std;
//ifstream fin("test.in");
//ofstream fout("tes.out");
int n,m,l[50011],r[50011],k[50011],val[50011],i,L,R,j;
int sol[50011];
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>l[i]>>r[i]>>k[i]>>val[i];
        l[i]++;r[i]++;
        if(k[i]==1)
        {
            if(val[i]==1)
                for(j=l[i];j<=r[i];j++)
                {
                    if(sol[j]==1) {fout<<-1; return 0;}
                    sol[j]=2;
                }
        }
    }
    for(i=1;i<=n;i++) sol[i]=max(sol[i]-1,0);
    for(i=1;i<=n;i++) sol[i]+=sol[i-1];
    for(i=1;i<=m;i++)
    {
        if(k[i]==1&&val[i]==0)
        {
            L=l[i];R=r[i];
            if(sol[R]-sol[L-1]==R-L+1) {fout<<-1; return 0;}
        }
    }
    for(i=1;i<=n;i++) fout<<sol[i]-sol[i-1];
    return 0;
}

