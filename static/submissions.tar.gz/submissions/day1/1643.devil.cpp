/**
* user:  tamyarov-797
* fname: Ilya
* lname: Tamyarov
* task:  devil
* score: 0.0
* date:  2019-10-10 07:23:27.641501
*/
#define ll int
#include<bits/stdc++.h>
using namespace std;
string s[100001];
void solve();
void file()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
}
int main(){
    solve();
    return 0;
}
bool cmp(ll a,ll b)
{
    if(s[a].size()==s[b].size())
        return s[a]>s[b];
    else
        return s[a].size()>s[b].size();
}
void solve()
{
    ll t=1;
    cin>>t;
    for(;t;t--)
    {
        ll n;
        cin>>n;
        string ans="";
        ll a[10];
        for(int i=1;i<=9;i++)
        {
            cin>>a[i];
        }
        ll mx=9,mn=1;
        while(!a[mx])
        {
            mx--;
        }
        while(ans.size()<n-1)
        {
            ans+=mx+'0';
            a[mx]--;
            while(!a[mx])
            {
                mx--;
            }
        }
        ll sz=a[mx];
        fill(s,s+sz,"");
        for(int i=0;i<sz;i++)
            s[i]+=mx+'0';
        a[mx]=0;
        ll start=0;
        bool used[sz];
        fill(used,used+sz,0);
        vector<ll> point;
        point.push_back(0);
        while(mn<mx)
        {
            bool was=0;
            for(int i=start;i<sz;i++)
            {
                while(!a[mn])
                {
                    if(!was)
                    {
                        start=i;
                    }
                    was=1;
                    mn++;
                    if(mn>=mx)
                        break;
                }
                if(mn>=mx)
                    break;
                s[i]+=mn+'0';
                a[mn]--;
            }
        }
        for(int i=0;i<sz-1;i++)
        {
            if(s[i]!=s[i+1])
                point.push_back(i+1);
        }
        sort(point.begin(),point.end(),cmp);
        reverse(ans.begin(),ans.end());
        bool pntused[point.size()];
        fill(pntused,pntused+point.size(),0);
        while(1)
        {
            ll cnt=0;
            for(int i=0;i<point.size();i++)
            {
                if(pntused[i])
                {
                    cnt++;continue;
                }
                cout<<s[point[i]];
                used[point[i]]=1;
                point[i]++;
                if(used[point[i]]||point[i]>=sz)
                    pntused[i]=1;
            }
            if(cnt==point.size())
                break;
        }
        cout<<ans<<'\n';
    }
    return;
}
