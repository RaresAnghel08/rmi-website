/**
* user:  noszaly-f9c
* fname: Áron
* lname: Noszály
* task:  devil
* score: 14.0
* date:  2019-10-10 10:06:43.765068
*/
#include<bits/stdc++.h>
using namespace std;
#define xx first
#define yy second
#define pb push_back
#define sz(x) (int)(x).size()
#define IO ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0)
string akt;
string best;
string ans;
string mx;
int k;
int cnt[10];
int n;

int main() {
	IO;
	int T;
	cin>>T;
	while(T--) {
		cin>>k;
		memset(cnt, 0, sizeof cnt);
		n=0;
		for(int i=1;i<10;++i) {
			cin>>cnt[i];
			n+=cnt[i];
			
		}
		
		string veg;
		int le=k-1;
		for(int i=9;i>=1 && le>=0;i--) {
			while(le>0 && cnt[i]>0) {
				veg+=i+'0';
				cnt[i]--;
				le--;
			}
		}
		reverse(veg.begin(), veg.end());
		
		
		int mx=-1;
		for(int i=9;i>=1 && mx==-1;i--) {
			if(cnt[i]>0) mx=i;
		}
		
		assert(mx!=-1);
		int mx_cnt=cnt[mx];

		vector<char> tobbiek;
		for(int i=1;i<mx;++i) {
			for(int j=0;j<cnt[i];++j) {
				tobbiek.pb(i+'0');
			}
		}
		reverse(tobbiek.begin(), tobbiek.end());
		
		string kozepe;
		for(int i=0;i<mx_cnt;++i) {
			if(!tobbiek.empty()) {
				kozepe.push_back(tobbiek.back());
				tobbiek.pop_back();
			}
			kozepe.push_back(mx+'0');
		}
		
		reverse(kozepe.begin(), kozepe.end());
		
		string eleje;
		while(!tobbiek.empty()) {
			eleje.push_back(tobbiek.back());
			tobbiek.pop_back();
		}
		
		cout<<eleje+kozepe+veg<<"\n";
	}
	return 0;
}
