/**
* user:  myskiv-a26
* fname: Vladyslav
* lname: Myskiv
* task:  Present
* score: 8.0
* date:  2021-12-16 11:36:18.754591
*/
#include <bits/stdc++.h>

using namespace std;

int n, it, bitmask, flag;

int isbit(int b, int n){
    b--;
    b=1<<b;
    return n&b;
}

void solve(){
    cin>>n;
    bitmask=(1<<8)-1;
    it=0;
    if(n==0){
        cout<<0<<endl;
        return;
    }
    for(int k=1; k<=bitmask; k++){
        flag=1;
        for(int i=1; i<=8; i++){
            for(int j=1; j<=8; j++){
                if(!isbit(i, k) || !isbit(j, k)) continue;
                if(!isbit(__gcd(i, j), k)){
                    flag=0;
                    break;
                }
            }
        }
        if(flag) it++;
        if(it==n){
            int cnt=0;
            for(int i=1; i<=8; i++) if(isbit(i, k)) cnt++;
            cout<<cnt<<' ';
            for(int i=1; i<=8; i++) if(isbit(i, k)) cout<<i<<' ';
            cout<<endl;
            break;
        }
    }
    return;
}

int main()
{
    int T;
    cin>>T;
    while(T--) solve();
    return 0;
}
