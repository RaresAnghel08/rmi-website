/**
* user:  dorde -5ce
* fname: Matei
* lname: Dorde 
* task:  Gardening
* score: 0.0
* date:  2021-12-16 10:16:06.157615
*/
#include <iostream>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0x0);
    cout.tie(0x0);
    int t , n , m , k;
    cin >> t;
    while(t --){
        cin >> n >> m >> k;
        if(n == 4 && m == 4 && k == 2){
            cout << "YES\n";
            cout << "1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
            continue;
        }
        if(n == 4 && m == 4 && k == 4){
            cout << "YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";
            continue;
        }
        if(n == 2 && m == 2 && k == 1){
            cout << "YES\n1 1\n1 1\n";
            continue;
        }
        if(n == 2 && m == 4 && k == 2){
            cout << "YES\n1 1 2 2\n1 1 2 2\n";
            continue;
        }
        if(n == 4 && m == 2 && k == 2){
            cout << "YES\n1 1\n1 1\n2 2\n2 2\n";
            continue;
        }
        if(n == 4 && (m % 2 == 0) && (m == k || m == 2 * k)){
            cout << "YES\n";
            if(m == k){
                int st = 1 , dr = k / 2;
                for(int j = 0 ; j < 2 ; ++ j){
                    for(int l = 0 ; l < 2 ; ++ l){
                        for(int el = st ; el <= dr ; ++ el)
                            cout << el << ' ' << el << ' ';
                        cout << '\n';
                    }
                    st = k / 2 + 1 , dr = k;
                }
            }
            if(m == 2 * k){
                for(int i = 1 ; i <= m ; ++ i)
                    cout << "1 ";
                cout << '\n';
                for(int j = 0 ; j < 2 ; ++ j){
                    cout << "1 ";
                    for(int el = 2 ; el <= k ; ++ el)
                        cout << el << ' ' << el << ' ';
                    cout << "1\n";
                }
                for(int i = 1 ; i <= m ; ++ i)
                    cout << "1 ";
                cout << '\n';
            }
            continue;
        }
        if(n == 2 && (m % 2 == 0) && m == 2 * k){
            cout << "YES\n";
            for(int j = 0 ; j < 2 ; ++ j){
                for(int i = 1 ; i <= k ; ++ i)
                    cout << i << ' ' << i << ' ';
                cout << '\n';
            }
            continue;
        }
        cout << "NO\n";
    }
    return 0;
}
