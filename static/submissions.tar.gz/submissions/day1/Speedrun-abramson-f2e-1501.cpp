/**
* user:  abramson-f2e
* fname: Carmel
* lname: Abramson
* task:  Speedrun
* score: 12.0
* date:  2021-12-16 08:02:33.351630
*/
#include "speedrun.h"
#include<bits/stdc++.h>

using namespace std;
typedef vector<int> vi;
typedef vector<vi>vvi;

#define pb push_back

void assignHints(int subtask, int N, int A[], int B[]) {

    vi a(N),b(N);
    for(int i=0; i<N; i++)
        a[i]=A[i],b[i]=B[i];
    setHintLen(300);

    vvi g(N+1);

    for(int i=1; i<N; i++)
        g[A[i]].pb(B[i]),g[B[i]].pb(A[i]);

    for(int i=1; i<=N; i++)
        for(int x:g[i])
            setHint(i,1+(x/4),1);

}

void dfs(int src,int par,int n){

    for(int i=1; i<=251; i++)
        if(getHint(i))
            for(int j=max(4*(i-1),1); j<=4*i;j++)
                if(j!=par && j<=n && goTo(j))
                    dfs(j,src,n);
    if(par!=-1)
        goTo(par);
}

void speedrun(int subtask, int N, int start) {
    dfs(start,-1,N);
}

/*
 small
 5
 1 2
 2 3
 3 4
 3 5
1

 starred at 2
 6
1 2
2 3
2 4
2 5
2 6

 chain 2-3-1-5-6-4
 6
 2 3
 3 1
 1 5
 5 6
 6 4
 */