/**
* user:  volkov-d03
* fname: Ivan
* lname: Volkov
* task:  devil
* score: 0.0
* date:  2019-10-10 09:52:12.810968
*/
#include <iostream>

using namespace std;

void solve() {
    int k;
    int cnt[10];
    cin >> k;
    for (int i = 1; i <= 9; i++) {
        cin >> cnt[i];
        if (i >= 3 && cnt[i] != 0) exit(-1);
    }
    int a = cnt[1], b = cnt[2], n = a + b;
    if (a == 0) {
        for (int i = 0; i < b; i++) cout << "2";
        cout << "\n";
        return;
    }
    if (b == 0) {
        for (int i = 0; i < a; i++) cout << "1";
        cout << "\n";
        return;
    }
    string res = "";
    for (int i = 0; i < n; i++) res += "0";
    if (b < k) {
        for (int i = 0; i < a; i++) res[i] = '1';
        for (int i = 0; i < b; i++) res[a + i] = '2';
        cout << res << "\n";
        return;
    }
    for (int i = 0; i < k - 1; i++) {
        res[n - i - 1] = '2';
    }
    //res[n - k] = '1';
    //a--;
    n -= k - 1;
    b -= (k - 1);
    int maxi = a / b;
    int cnt_vip = b - (a - maxi * b);
    int tail = maxi + 1;
    for (int i = 0; i < n; i++) {
        if ((tail == maxi + 1) || (tail == maxi && cnt_vip != 0)) {
            if (tail == maxi) cnt_vip--;
            tail = 0;
            res[i] = '2';
            b--;
        } else {
            tail++;
            res[i] = '1';
            a--;
        }
    }
    //cout << res << endl;
    //cout << a << ' ' << b << endl;
    if (a != 0 || b != 0) exit(-1);
    cout << res << "\n";
    /*int need_2 = (n - k + 1) - a, need_1 = (n - k + 1) - need_2;
    int maxi = */
}

int main() {
    //freopen("Desktop/input.txt", "r", stdin);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) {
        solve();
    }
    return 0;
}
