/**
* user:  penchev-2b7
* fname: Jasen
* lname: Penchev
* task:  devil
* score: 14.0
* date:  2019-10-10 07:32:44.604007
*/
#include <iostream>
#include <cmath>
#define endl '\n'
using namespace std;

int D[10];
int ans[1000005];

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int T;
    cin >> T;

    int K;
    for (int t = 0; t < T; ++ t)
    {
        cin >> K;

        int S = 0;
        for (int i = 1; i <= 9; ++ i)
        {
            cin >> D[i];
            S += D[i];
        }

        if (K == 1)
        {
            for (int i = 1; i <= 9; ++ i)
            {
                for (int j = 1; j <= D[i]; ++ j)
                    cout << i;
            }
            cout << endl;
        }
        else if (K == 2)
        {
            int i = 1, j = 9;
            for (int p = S; p >= 1; -- p)
            {
                if ((S - p) % 2 == 0)
                {
                    while (D[j] == 0) j--;
                    ans[p] = j;
                    D[j]--;
                }
                else
                {
                    while (D[i] == 0) i++;
                    ans[p] = i;
                    D[i]--;
                }
            }
            for (int p = 1; p <= S; ++ p)
                cout << ans[p];
            cout << endl;
        }
        else
        {
            if (D[2] < K or (D[1] + 1) * (K - 1) < D[2])
            {
                for (int i = 1; i <= 2; ++ i)
                {
                    for (int j = 1; j <= D[i]; ++ j)
                        cout << i;
                }
                cout << endl;
            }
            else
            {
                D[2] -= K - 1;
                int howmany2 = D[2] / (D[1] + 1);
                int bg = D[2] % (D[1] + 1);
                int sm = D[1] - bg;
                for (int i = 1; i <= bg; ++ i)
                {
                    for (int j = 1; j <= howmany2 + 1; ++ j)
                        cout << 2;
                    cout << 1;
                }
                for (int i = 1; i <= bg; ++ i)
                {
                    for (int j = 1; j <= howmany2; ++ j)
                        cout << 2;
                    cout << 1;
                }
                for (int j = 1; j <= K - 1; ++ j)
                    cout << 2;
                cout << endl;
            }
        }
    }

    return 0;
}
