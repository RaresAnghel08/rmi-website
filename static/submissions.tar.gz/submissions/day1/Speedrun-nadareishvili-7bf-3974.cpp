/**
* user:  nadareishvili-7bf
* fname: Giorgi
* lname: Nadareishvili
* task:  Speedrun
* score: 90.0
* date:  2021-12-16 11:51:05.603008
*/
#include <bits/stdc++.h>
using namespace std;
#define grader grader
#ifndef grader
bool xx[1003][1003];
int dg;
void setHintLen(int l) { }
void setHint(int i, int j, bool b) { xx[i][j] = b; }
int getLength() { return 0; }
bool getHint(int j) { return xx[dg][j]; }
bool goTo(int x) { cout << dg << " -> " << x << endl; dg = x; return 1; }
#else
#include "speedrun.h"
#endif

vector<int> mz[1003];
vector<int> stts[1003];
int up[1003];

vector<int> io, ioi;
void dfss(int x, int y = 0) {
    ioi[x] = io.size();
    up[x] = y;
    io.push_back(x);
    for(int z : mz[x]) {
        if(z != y) {
            dfss(z, x);
        }
    }
    io.push_back(-1);
}

void assignHints(int subtask, int n, int a[], int b[]) {
    if(subtask == 1) {
        setHintLen(n);
        for(int i = 1; i < n; ++i) {
            setHint(a[i], b[i], 1);
            setHint(b[i], a[i], 1);
        }
    } else if(subtask == 2) {
        setHintLen(20);
        int x = 0;
        vector<int> c(n + 1);
        for(int i = 1; i < n; ++i) {
            ++c[a[i]];
            ++c[b[i]];
        }
        for(int i = 1; i <= n; ++i) {
            if(c[i] == n - 1) x = i;
        }
        for(int i = 1; i <= n; ++i) {
            for(int j = 0; j < 10; ++j) {
                setHint(i, j + 1, !!(x & 1 << j));
            }
        }
    } else if(subtask == 3) {
        setHintLen(20);
        for(int i = 1; i < n; ++i) {
            mz[a[i]].push_back(b[i]);
            mz[b[i]].push_back(a[i]);
        }
        int x = 0;
        for(int i = 1; i <= n; ++i) {
            if(mz[i].size() == 1) mz[i].push_back(0), x = i;
        }
        int y = 0;
        for(;x;) {
            if(mz[x][0] != y) swap(mz[x][0], mz[x][1]);
            y = x;
            x = mz[x][1];
        }
        for(int i = 1; i <= n; ++i) {
            for(int j = 0; j < 10; ++j) {
                setHint(i, j + 1, !!(mz[i][0] & 1 << j));
            }
            for(int j = 0; j < 10; ++j) {
                setHint(i, j + 11, !!(mz[i][1] & 1 << j));
            }
        }
    } else if(subtask >= 4) {
        setHintLen(30);
        for(int i = 1; i < n; ++i) {
            mz[a[i]].push_back(b[i]);
            mz[b[i]].push_back(a[i]);
        }
        ioi = vector<int>(1003);
        dfss(1);
        #ifndef grader
        for(int i = 0; i < io.size(); ++i) {
            cout << io[i] << " ";
        }
        cout << endl;
        #endif
        for(int i = 1; i <= n; ++i) {
            for(int j = 0; j < 10; ++j) {
                setHint(i, j + 1, !!(up[i] & 1 << j));
            }
            int nx = 0, uc = 0;
            int x = ioi[i];
            for(int j = x + 1; j < io.size(); ++j) {
                if(io[j] == -1) uc += 1;
                else {
                    nx = io[j];
                    break;
                }
            }
            if(!nx) nx = 0;
            for(int j = 0; j < 10; ++j) {
                setHint(i, j + 11, !!(nx & 1 << j));
            }
            for(int j = 0; j < 10; ++j) {
                setHint(i, j + 21, !!(uc & 1 << j));
            }
            #ifndef grader
            cout << i << " " << up[i] << " " << nx << " " << uc << endl;
            #endif
        }
    }
}

int l, n, s;

void dfs1(int x, int y = 0) {
    for(int i = 1; i <= n; ++i) {
        if(i != y && getHint(i)) {
            goTo(i);
            dfs1(i, x);
        }
    }
    if(y) goTo(y);
}

void speedrun(int subtask, int _n, int start) {
    n = _n;
    s = subtask;
    l = getLength();
    if(subtask == 1) {
        dfs1(start);
        return;
    } else if(subtask == 2) {
        int x = 0;
        for(int j = 0; j < 10; ++j) {
            if(getHint(j + 1)) {
                x |= 1 << j;
            }
        }
        if(start != x) goTo(x);
        for(int i = 1; i <= n; ++i) {
            goTo(i);
            goTo(x);
        }
        return;
    } else if(subtask == 3) {
        int x = start;
        for(;;) {
            if(!mz[x].size()) {
                mz[x] = {0, 0};
                for(int j = 0; j < 10; ++j) {
                    if(getHint(j + 1)) {
                        mz[x][0] |= 1 << j;
                    }
                }
                for(int j = 0; j < 10; ++j) {
                    if(getHint(j + 11)) {
                        mz[x][1] |= 1 << j;
                    }
                }
            }
            if(mz[x][0]) x = mz[x][0], goTo(x);
            else break;
        }
        for(;;) {
            if(!mz[x].size()) {
                mz[x] = {0, 0};
                for(int j = 0; j < 10; ++j) {
                    if(getHint(j + 1)) {
                        mz[x][0] |= 1 << j;
                    }
                }
                for(int j = 0; j < 10; ++j) {
                    if(getHint(j + 11)) {
                        mz[x][1] |= 1 << j;
                    }
                }
            }
            if(mz[x][1]) x = mz[x][1], goTo(x);
            else break;
        }
        return;
    } else if(subtask >= 4) {
        int x = start;
        while(x != 1) {
            int y = 0;
            for(int j = 0; j < 10; ++j) {
                if(getHint(j + 1)) y |= 1 << j;
            }
            x = y;
            goTo(x);
        }
        for(;;) {
            int a = 0, b = 0, c = 0;
            for(int j = 0; j < 10; ++j) {
                if(getHint(j + 11)) b |= 1 << j;
            }
            for(int j = 0; j < 10; ++j) {
                if(getHint(j + 21)) c |= 1 << j;
            }
            if(c) {
                if(!b) break;
                for(int cc = 0; cc < c; ++cc) {
                    int y = 0;
                    for(int j = 0; j < 10; ++j) {
                        if(getHint(j + 1)) y |= 1 << j;
                    }
                    x = y;
                    goTo(x);
                }
                x = b;
                goTo(x);
            } else {
                x = b;
                goTo(x);
            }
        }
        return;
    }
}

#ifndef grader
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int _subtask = 4;
    int _n = 5;
    int _a[] = {0, 1, 1, 2, 2};
    int _b[] = {0, 2, 3, 4, 5};
    int _start = 1;
    dg = _start;
    assignHints(_subtask, _n, _a, _b);
    speedrun(_subtask, _n, _start);
    return 0;
}
#endif
