/**
* user:  tolstik-8bb
* fname: Bogdan
* lname: Tolstik
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:54:52.938815
*/
#include <bits/stdc++.h>

#define f first
#define s second
#define vec vector
#define pb push_back
#define all(x) (x).begin(),(x).end();
#define fast_rmi ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);

using namespace std;
//vec<vec<int>>a;

int c=0;
void paint(int x1,int x2,int y1,int y2,vec<vec<int>> &a){
    if(x1>x2 || y1>y2)
        return;
    cout<<"P"<<' '<<x1<<' '<<x2<<' '<<y1<<' '<<y2<<endl;
    for(int i=x1;i+1<=x2;i+=2){
        for(int j=y1;j+1<=y2;j+=2){
            a[i][j]=a[i][j+1]=a[i+1][j]=a[i+1][j+1]=c;
//            cout<<"NEW "<<i<<' '<<j<<endl;
            c++;
        }
    }
//    cout<<c<<endl;
}
vec<vec<int>> solve1(int n,int m,int k){
    vec<vec<int>> a(n,vec<int>(m,-1));
    int rem=n*m-k*4;
    for(int x=0;x<=n-2;x++){
        for(int y=0;y<=m-2;y++){
            if(!((x==0 && y==0) || (x>=2 && y>=2))) continue;

            if(rem-(x+y)*2==0){
                paint(1,x,1,y,a);
                paint(x+2,n-1,0,y+1,a);
                paint(0,x+1,y+2,m-1,a);
                paint(x+2,n-1,y+2,m-1,a);

                for(int i=0;i<=y+1;i++){
                    a[0][i]=a[x+1][i]=c;
                }
                for(int i=0;i<=x+1;i++){
                    a[i][0]=a[i][y+1]=c;
                }
                c++;
//                cout<<"A"<<c<<endl;
                return a;
            }
        }
    }
   return a;
}
void solve(int n,int m,int k){
    if(n%2 || m%2){
        cout<<"NO\n";
        return;
    }
    if(n*m/4<k){
        cout<<"NO\n";
        return;
    }
    int pk=k;
    int nk=n,mk=m;
    vec<vec<int>> a(n,vec<int>(m,-1));
    int al=n*m-k*4;
    c=0;
    ///TODO
    while(n>=4 && m>=4 && al>=2*(n+m-4)){
        for(int i=c;i<mk-c;i++){
            a[c][i]=a[nk-1-c][i]=c;
        }
        for(int i=c;i<nk-c;i++){
            a[i][c]=a[i][mk-1-c]=c;
        }
        c++;
        al-=2*(n+m-4);
        n-=2;
        k--;
        m-=2;
    }
    int nc=c;
    auto me=solve1(n,m,k);
    if(me[0][0]==-1){
        cout<<"NO\n";
        return;
    }
//    cout<<"A"<<' '<<c<<' '<<pk<<' '<<nc<<endl;
    assert(c==pk);
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            a[i+nc][j+nc]=me[i][j];
        }
    }
    cout<<"YES\n";
    for(int i=0;i<nk;i++){
        for(int j=0;j<mk;j++){
            cout<<a[i][j]+1<<' ';
        }
        cout<<'\n';
    }
}
signed main(){
    fast_rmi;
    int t;
    cin>>t;
    while(t--){
        int n,m,k;
        cin>>n>>m>>k;
        solve(n,m,k);
    }
    return 0;
}
