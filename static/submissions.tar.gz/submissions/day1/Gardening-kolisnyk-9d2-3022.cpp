/**
* user:  kolisnyk-9d2
* fname: Illia
* lname: Kolisnyk
* task:  Gardening
* score: 5.0
* date:  2021-12-16 10:28:43.171741
*/
#include <bits/stdc++.h>
#pragma GCC optimize ("O3")
#define ft first
#define sc second
#define pb push_back

using namespace std;

const int N = 10;

bool ok = false;
int a[N][N];
int b[N][N];
vector <pair <int, pair <int, pair <int, int> > > > res;

bool check(int n, int m, vector <pair <int, pair <int, pair <int, int> > > > ans) {
    for (int i = 1; i <= n; i ++) {
        for (int j = 1; j <= m; j ++) {
            b[i][j] = 0;
        }
    }
//    if (ans[0].ft == 1 && ans[0].sc.sc.ft == n && ans[0].sc.ft == 1 && ans[0].sc.sc.sc == m) {
//        for (auto it : ans) cout << it.ft << ' ' << it.sc.ft << ' ' << it.sc.sc.ft << ' ' << it.sc.sc.sc << '\n';
//        cout << "-----\n";
//    }
    int sum = n * m;
    int cnt = 1;
    for (auto it : ans) {
        for (int i = it.ft; i <= it.sc.sc.ft; i ++) {
            if (i == it.ft || i == it.sc.sc.ft) {
                for (int j = it.sc.ft; j <= it.sc.sc.sc; j ++) {
                    if (b[i][j]) return false;
                    b[i][j] = cnt;
                    sum --;
                }
            }
            else {
                for (int j = it.sc.ft; j <= it.sc.sc.sc; j ++) {
                    if (j != it.sc.ft && j != it.sc.sc.sc) continue;
                    if (b[i][j]) return false;
                    b[i][j] = cnt;
                    sum --;
                }
            }
        }
        cnt ++;
    }
    return (sum ? false : true);
}

void rec(int n, int m, int k, vector <pair <int, pair <int, pair <int, int> > > > ans = {}) {
    if (ok) return;
    if (!k) {
        if (check(n, m, ans)) {
            ok = true;
            res = ans;
        }
        return;
    }
    for (int i = 1; i <= n - 1; i ++) {
        for (int j = 1; j <= m - 1; j ++) {
            ans.pb({i, {j, {i + 1, j + 1}}});
//            if (i == 2 && j == 2) {
//                cout << "KEK";
//            }
            rec(n, m, k - 1, ans);
            if (ok) return;
            ans.pop_back();
            for (int i1 = i + 3; i1 <= n; i1 += 2) {
                for (int j1 = j + 3; j1 <= m; j1 += 2) {
                    ans.pb({i, {j, {i1, j1}}});
                    rec(n, m, k - 1, ans);
                    if (ok) return;
                    ans.pop_back();
                }
            }
        }
    }
}

void rec1(int n, int m, int k) {
    if (n == 2) {
        if (k == m / 2) {
            for (int j = 1; j < m; j += 2) {
                res.pb({1, {j, {2, j + 1}}});
            }
            ok = true;
        }
        return;
    }
    if ((n * m) % 4 == 0 && (n * m) / 4 == k) {
        ok = true;
        for (int j = 1; j < m; j += 2) {
            res.pb({1, {j, {2, j + 1}}});
            res.pb({3, {j, {4, j + 1}}});
        }
        return;
    }
    for (int i = 4; i <= m; i += 2) {
        if (k == 1 + (m - i) + (i - 2) / 2) {
            ok = true;
            res.pb({1, {1, {4, i}}});
            for (int j = 2; j < i; j += 2) {
                res.pb({2, {j, {3, j + 1}}});
            }
            for (int j = i + 1; j < m; j += 2) {
                res.pb({1, {j, {2, j + 1}}});
                res.pb({3, {j, {4, j + 1}}});
            }
            return;
        }
    }
}

void solve() {
    ok = false;
    int n, m, k;
    cin >> n >> m >> k;
    if (n % 2 || m % 2 || ((n * m) / 4) < k) {
        cout << "NO\n";
        return;
    }
    if (m <= 4) {
        rec(n, m, k);
    }
    else {
        rec1(n, m, k);
    }
    if (!ok) {
        cout << "NO\n";
        return;
    }
    cout << "YES\n";
    int cnt = 1;
    for (auto it : res) {
        for (int i = it.ft; i <= it.sc.sc.ft; i ++) {
            for (int j = it.sc.ft; j <= it.sc.sc.sc; j ++) {
                a[i][j] = cnt;
            }
        }
        cnt ++;
    }
    for (int i = 1; i <= n; i ++) {
        for (int j = 1; j <= m; j ++) {
            cout << a[i][j] << ' ';
        }
        cout << '\n';
    }
}

main() {
    int test;
    cin >> test;
    while (test --) {
        solve();
    }
}
