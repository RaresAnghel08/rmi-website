/**
* user:  linhart-f5e
* fname: Yoav
* lname: Linhart
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 09:10:30.899797
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <queue>
#include "speedrun.h"

#define upmin(a, b) if(a > b) a = b
#define upmax(a, b) if(a < b) a = b
#define pr(x) cout << x << endl
#define spr(x) cout << x << " "
#define wpr(x) cout << #x << ": " << x << endl
#define wprv(x) cout << #x << ": " << endl; for(auto it : x) cout << it << " "; cout << endl;
#define wprvv(x) cout << #x << ": " << endl; for(auto it : x) { for(auto it2 : it) cout << it2 << " "; cout << endl;}
#define rep(i, s, e) for(ll i = s; i < e; i++)
#define repr(i, s, e) for(ll i = e - (ll)1; i >= s; i--)


using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vvvll = vector<vvll>;
using pll = pair<ll, ll>;
using vpll = vector<pll>;
using vvpll = vector<vpll>;
using vb = vector<bool>;
using vi = vector<int>;

const ll sz = 10;

/*

subtask 2:
enconde the middle 

*/

void assignHints(int subtask, int n, int A[], int B[])
{
	vvll tree(n+1);
	rep(i, 1, n+1) {
		ll xt = A[i], yt = B[i];
		tree[xt].push_back(yt); tree[yt].push_back(xt);
	}
	
	setHintLen(2 * sz);
	rep(i, 1, n + 1) {
		ll nei1 = 0, nei2 = 0;
		if (tree[i].size() > 0) nei1 = tree[i][0];
		if (tree[i].size() > 1) nei2 = tree[i][1];
		rep(j, 1, sz+1) {
			if ((nei1 >> (j-(ll)1)) & 1) {
				setHint(i, j, 1);
			}
		}

		rep(j, 1, sz + 1) {
			if ((nei2 >> (j - (ll)1)) & 1) {
				setHint(i, sz + j, 1);
			}
		}
	}
	
}



void dfs(ll cur, ll papa) {
	ll nei1 = 0, nei2 = 0;
	rep(j, 1, sz + 1) {
		if (getHint(j)) {
			nei1 += (ll)1 << (j - 1);
		}
	}

	rep(j, 1, sz + 1) {
		if (getHint(sz+j)) {
			nei2 += (ll)1 << (j - 1);
		}
	}

	if (nei1 != 0 && nei1 != papa) {
		goTo(nei1);
		dfs(nei1, cur);
	}
	if (nei2 != 0 && nei2 != papa) {
		goTo(nei2);
		dfs(nei2, cur);
	}
	if (papa != -1) goTo(papa);
}


void speedrun(int subtask, int n, int start)
{

	ll l = getLength();
	dfs(start, -1);
	
}

/*




*/