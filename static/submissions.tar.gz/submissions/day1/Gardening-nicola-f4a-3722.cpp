/**
* user:  nicola-f4a
* fname: Alexandra Mihaela
* lname: Nicola
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:30:36.378320
*/
/// greu se mai misca cmsu
#include <bits/stdc++.h>
#define DIM 200010
using namespace std;

int t,n,m,k,i,j,cul,ok;
int a[5][DIM];

int main (){

    //ifstream cin ("date.in");
    //ofstream cout ("date.out");

    cin>>t;
    for (;t--;){
        cin>>n>>m>>k;
        if (n % 2 || m % 2){
            cout<<"NO\n";
            continue;
        }

        if (n == 2){

            if (m % 2 || m / 2 != k){
                cout<<"NO\n";
                continue;
            }

            cout<<"YES\n";

            for (i=1;i<=n;i++){
                for (j=1;j<=m;j++)
                    cout<<(j+1)/2<<" ";
                cout<<"\n";
            }

            continue;
        }

        if (n == 4){

            if (m == 2){

                if (k != 2)
                    cout<<"NO\n";
                else cout<<"YES\n1 1\n1 1\n2 2\n2 2\n";

                continue;
            }

            if (m == 4){

                if (k == 2){
                    cout<<"YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
                } else {
                    if (k == 4){
                        cout<<"YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";

                    } else cout<<"NO\n";
                }

                continue;
            }


            if (k > m){
                cout<<"NO\n";
                continue;
            }


            int dif = m - k; /// trb sa scap de atatea culori
            if (2 * dif > m){
                cout<<"NO\n";
                continue;
            }

            int cul = 0;
            for (i=1;i<=2*dif;i++)
                a[1][i] = a[4][i] = 1;
            a[2][1] = a[3][1] = a[2][2*dif] = a[3][2*dif] = ++cul;

            for (i=2;i<2*dif;i+=2)
                a[2][i] = a[2][i+1] = a[3][i] = a[3][i+1] = ++cul;

            for (i=2*dif+1;i<=m;i+=2){
                a[1][i] = a[1][i+1] = a[2][i] = a[2][i+1] = ++cul;
                a[3][i] = a[3][i+1] = a[4][i] = a[4][i+1] = ++cul;
            }

            cout<<"YES\n";
            for (i=1;i<=n;i++,cout<<"\n")
                for (j=1;j<=m;j++)
                    cout<<a[i][j]<<" ";

        }

    }


    return 0;
}
