/**
* user:  smilenov-5e5
* fname: Ivan
* lname: Smilenov
* task:  devil
* score: 0.0
* date:  2019-10-10 09:01:12.277002
*/
#include<bits/stdc++.h>
#define MAXN 131072
#define endl "\n"
using namespace std;
int a[16];
vector< pair<int,int> >v;
int main()
{
    /*ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);*/
    int t,k,i,l,r,sz,j,cnt,f=0;
    cin>>t;
    while(t--)
    {
        cnt=0;
        cin>>k;
        sz=0;
        for(i=1; i<=9; i++)
        {
            cin>>a[i];
            cnt+=a[i];
        }
        sz=v.size();
        l=1,r=9;
        while(!a[l])l++;
        while(!a[r])r--;
        cnt--;
        f=r;
        a[r]--;
        while(1)
        {

            while(!a[l])l++;
            cout<<l;
            a[l]--;
            cnt--;
            if(!cnt)break;

            while(!a[r])r--;
            cout<<r;
            a[r]--;
            cnt--;
            if(!cnt)break;

        }
        cout<<f<<endl;
    }
    return 0;
}
