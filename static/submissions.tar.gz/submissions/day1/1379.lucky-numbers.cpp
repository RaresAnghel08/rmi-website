/**
* user:  grosman-d16
* fname: Nicole
* lname: Grosman
* task:  lucky
* score: 14.0
* date:  2019-10-10 06:31:06.743691
*/
//============================================================================
// Name        : lucl.cpp
// Author      : nicole
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <string>
#include <iostream>
using namespace std;

int main() {
	long long int n,q,x;
	cin>>n>>q;
	cin>>x;
	//case n<=6 q=0;
	long long int i,c=x+1,t;
	for(i=x; i>12; i--){
		t=i;
		while(t>12){
			if(t%100 == 13){
				c--;
				break;
			}
			t/=10;
		}
		//if(t>12)cout<<x+1-c<<" "<<i<<endl;
	}
	cout<<c<<endl;

	return 0;

}
