/**
* user:  bengin-61a
* fname: Jovan
* lname: Bengin
* task:  devil
* score: 13.0
* date:  2019-10-10 06:52:25.298907
*/
#include <bits/stdc++.h>
using namespace std;

int cnt[10];

int k;
int sum;

typedef long long ll;

ll findmx(string s){
    int n = sum;
    ll str = 0;
    ll p10 = 1;
    for(int i=0; i<k; i++){
        str = (10*str) + (s[i]-'0');
        p10 *= 10;
    }
    ll res = str;
    for(int i=k; i<n; i++){
        str = 10*str + (s[i]-'0');
        str -= p10*(s[i-k]-'0');
        res = max(res, str);
    }
    //cout << s << " " << res << endl;
    return res;
}

pair <ll, string> resi(string s, int b1, int b2, int b3, int b4){
    if(b1 == 0 && b2 == 0 && b3 == 0 && b4 == 0) return {findmx(s), s};
    pair <ll, string> res = {0, ""};
    pair <ll, string> nista = {0, ""};
    if(b1){
        if(res == nista) res = resi(s+'1', b1-1, b2, b3, b4);
        else res = min(res, resi(s+'1', b1-1, b2, b3, b4));
    }
    if(b2){
        if(res == nista) res = resi(s+'2', b1, b2-1, b3, b4);
        else res = min(res, resi(s+'2', b1, b2-1, b3, b4));
    }
    if(b3){
        if(res == nista) res = resi(s+'3', b1, b2, b3-1, b4);
        else res = min(res, resi(s+'3', b1, b2, b3-1, b4));
    }
    if(b4){
        if(res == nista) res = resi(s+'4', b1, b2, b3, b4-1);
        else res = min(res, resi(s+'4', b1, b2, b3, b4-1));
    }
    return res;
}

void solve(){
    cin >> k;
    sum = 0;
    for(int i=1; i<=9; i++){
        cin >> cnt[i];
        sum += cnt[i];
    }
    cout << resi("", cnt[1], cnt[2], cnt[3], cnt[4]).second << "\n";
}

int main(){

    int t;
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
