/**
* user:  karpenko-089
* fname: Daryna
* lname: Karpenko
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:57:44.899164
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll t,n,m,k;

int main()
{
    cin>>t;
    while(t--){
        cin>>n>>m>>k;
        ll d[n+7][m+7];
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                d[i][j]=0;
            }
        }
        if(n<=4 && m<=4){
            if(n%2==1 || m%2==1 || k>n*m/4){
                cout<<"NO"<<endl;
            }else {
                if(n==2){
                    if(k<n*m/4){
                        cout<<"NO"<<endl;
                    }else{
                        cout<<"YES"<<endl;
                        if(m==2){
                            cout<<"1 1\n1 1"<<endl;
                        }else{
                            cout<<"1 1 2 2\n1 1 2 2"<<endl;
                        }
                    }
                }else if(m==2){
                    if(k<n*m/4){
                        cout<<"NO"<<endl;
                    }else{
                        cout<<"YES"<<endl;
                        if(n==2){
                            cout<<"1 1\n1 1"<<endl;
                        }else{
                            cout<<"1 1\n1 1\n2 2\n2 2"<<endl;
                        }
                    }
                }else{
                    if(k==1 || k==3)cout<<"NO"<<endl;
                    else if(k==2){
                        cout<<"YES"<<endl;
                        cout<<"1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1"<<endl;
                    }else {
                        cout<<"YES"<<endl;
                        cout<<"1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4"<<endl;
                    }
                }
            }
        }else{
            if(n==2){
                if(n*m/4!=k || n%2==1 || m%2==1)cout<<"NO"<<endl;
                else {
                    cout<<"YES"<<endl;
                    for(int i=1;i<=m;i++){
                        cout<<(i+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int i=1;i<=m;i++){
                        cout<<(i+1)/2<<" ";
                    }
                    cout<<endl;
                }
            }else{
                if(n*m/4<k || n%2==1 || m%2==1 || (n-2)*(m-2)/4>k-1)cout<<"NO"<<endl;
                if(n*m/4==k){
                    for(int i=1;i<=m;i++){
                        cout<<(i+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int i=1;i<=m;i++){
                        cout<<(i+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int i=1;i<=m;i++){
                        cout<<k/2+(i+1)/2<<" ";
                    }
                    cout<<endl;
                    for(int i=1;i<=m;i++){
                        cout<<k/2+(i+1)/2<<" ";
                    }
                    cout<<endl;
                }else{
                    ll f=0;
                    for(int i=4;i<=m;i+=2){
                        if(k==(i-2)/2+1+m-i)f=i;
                    }
                    if(f==0){
                        cout<<"NO"<<endl;
                        continue;
                    }
                    cout<<"YES"<<endl;
                    cout<<f<<endl;
                    for(int i=1;i<=n;i++){
                        for(int j=1;j<=m;j++){
                            if(((i==1 || i==4) && j<=f) || j==1 || j==f)d[i][j]=1;
                            else if(j%2==0 && j<=f && i%2==0){
                                //cout<<k<<" ";
                                d[i][j]=k;
                                k--;
                            }else if(j%2==1 && i%2==1 && j>f){
                                //cout<<k<<" ";
                                d[i][j]=k;
                                k--;
                            }
                        }
                    }
                    for(int i=1;i<=n;i++){
                        for(int j=1;j<=m;j++){
                            if(d[i][j]==0){
                                if(j<=f && j%2==1){
                                    d[i][j]=d[i][j-1];
                                }else if(j<=f){
                                    d[i][j]=d[i-1][j];
                                }else if(j%2==0){
                                    d[i][j]=d[i][j-1];
                                }else d[i][j]=d[i-1][j];
                            }
                            cout<<d[i][j]<<" ";
                        }
                        cout<<endl;
                    }
                }
            }
        }
    }

    return 0;
}
