/**
* user:  volkov-d03
* fname: Ivan
* lname: Volkov
* task:  restore
* score: 7.0
* date:  2019-10-10 07:56:54.251830
*/
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct restrict{
    int l, r, k, val;
    restrict() {}
    restrict(int l, int r, int k, int val): l(l), r(r), k(k), val(val) {}
    void init() {
        cin >> l >> r >> k >> val;
    }
};

int main() {
    //freopen("Desktop/input.txt", "r", stdin);
    int n, m;
    cin >> n >> m;
    vector <restrict> r(m);
    for (int i = 0; i < m; i++) {
        r[i].init();
    }
    for (int mask = 0; mask < (1 << n); mask++) {
        bool flag = 1;
        vector <int> arr(n);
        for (int i = 0; i < n; i++) {
            if (mask & (1 << i)) arr[i] = 1;
            else arr[i] = 0;
        }
        for (auto elem : r) {
            int cnt = 0;
            for (int i = elem.l; i <= elem.r; i++) cnt += 1 - arr[i];
            if (elem.val == 0 && elem.k > cnt) {
                flag = 0;
                break;
            }
            if (elem.val == 1 && elem.k <= cnt) {
                flag = 0;
                break;
            }
        }
        if (flag) {
            for (int elem : arr) cout << elem << ' ';
            cout << endl;
            return 0;
        }
    }
    cout << -1 << endl;
    return 0;
}
