/**
* user:  metehau-fd8
* fname: Luca
* lname: Metehău
* task:  restore
* score: 0.0
* date:  2019-10-10 08:08:37.949087
*/
#include <iostream>

using namespace std;

int n, m;

int l, r, k, val;

int v[5005];

int main() {
  cin >> n >> m;
  for(int i = 1; i <= n; i++)
    v[i] = -1;
  for(int i = 1; i <= m; i++) {
    cin >> l >> r >> k >> val;
    if(k == 1 && val == 1) {
      for(int j = l; j <= r; j++) {
        if(!v[j]) {
          cout << -1;
          return 0;
        }
        v[j] = 1;
      }
    } else if(k == r - l + 1 && val == 0) {
      for(int j = l; j <= r; j++) {
        if(v[j] == 1) {
          cout << -1;
          return 0;
        }
        v[j] = 0;
      }
    }
  }
  for(int i = 1; i <= n; i++) {
    if(v[i] == -1)
      v[i] = 0;
    cout << v[i] << " ";
  }
  return 0;
}
