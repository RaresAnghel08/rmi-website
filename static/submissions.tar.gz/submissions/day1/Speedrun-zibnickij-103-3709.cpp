/**
* user:  zibnickij-103
* fname: Nikita
* lname: Zibnickij
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:29:25.138223
*/
#include "speedrun.h"
#include <set>

using namespace std;
void assignHints(int subtask, int n, int a[], int b[]) {
    set<int> gr[n];
    for (int i = 1; i < n; i++) {
        gr[a[i]].insert(b[i]);
        gr[b[i]].insert(a[i]);
    }
    if (subtask == 1) {
        setHintLen(n);
        for (int i = 1; i <= n; i++) {
            for (int x: gr[i]) {
                setHint(i, x, true);
            }
        }
    }
    if (subtask == 2) {
        setHintLen(20);
        int root = 0;
        for (int i = 1; i <= n; i++) {
            if (gr[i].size() == n - 1)
                root = i;
        }
        for (int i = 1; i <= n; i++) {
            if (i == root)
                continue;
            for (int j = 0; j < 10; j++) {
                if ((root >> j) & 1)
                    setHint(i, j + 1, true);
            }
        }
    }
    if (subtask == 3) {
        setHintLen(20);
        for (int i = 1; i <= n; i++) {
            int pos = -1;
            for (int v: gr[i]) {
                pos++;
                for (int bit = 0; bit < 10; bit++) {
                    if ((v >> bit) & 1) {
                        setHint(i, 10 * pos + bit + 1, true);
                    }
                }
            }
        }
    }
}

void dfs(int v, int p, int n){
    for (int u = 1; u <= n; u++){
        if (!getHint(u))
            continue;
        if (u != p){
            goTo(u);
            dfs(u, v, n);
            goTo(v);
        }
    }
}

void speedrun(int subtask, int n, int start) {
    if (subtask == 1){
        dfs(start, -1, n);
    } else if (subtask == 2){
        int root = 0;
        for (int j = 0; j < 10; j++){
            if (getHint(j + 1))
                root += (1 << j);
        }
        if (root != start){
            goTo(root);
        }
        for (int i = 1; i <= n; i++){
            if (i == root)
                continue;
            goTo(i);
            goTo(root);
        }
    }
}
