/**
* user:  sayfullin-49d
* fname: Iskandar
* lname: Sayfullin
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:57:57.333487
*/
#include <bits/stdc++.h>

using namespace std;

//int n = 5;
//int a[5] = {0, 1, 2, 3, 3};
//int b[5] = {0, 2, 3, 4, 5};
//int st = 3;
//
//vector<vector<bool>> hints;
//vector<vector<int>> u = {{0, 1, 0, 0, 0},
//                         {1, 0, 1, 0, 0},
//                         {0, 1, 0, 1, 1},
//                         {0, 0, 1, 0, 0},
//                         {0, 0, 1, 0, 0}};
//int cur_v = 3;
//
//void setHintLen(int l) { hints.assign(n, vector<bool>(l)); }
//
//void setHint(int i, int j, bool B) { hints[i - 1][j - 1] = B; }
//
//int getLength() { return hints.front().size(); }
//
//bool getHint(int j) { return hints[cur_v - 1][j - 1]; }
//
//bool goTo(int x) {
//    if (u[cur_v - 1][x - 1]) {
//        cur_v = x;
//        return true;
//    }
//    return false;
//}


void assignHints(int substack, int N, int A[], int B[]) {
    setHintLen(N);

    for (int i = 1; i < N; i++) {
        setHint(A[i], B[i], 1);
        setHint(B[i], A[i], 1);
    }
}

void speedrun(int substack, int N, int start) {
    vector<bool> used(N);
    int l = getLength();

    vector<vector<bool>> g(N, vector<bool>(N));
    stack<int> s;
    vector<int> p(N, -1);

    s.push(start - 1);
    used[start - 1] = true;
    for (int j = 1; j <= l; j++) {
        g[start - 1][j - 1] = getHint(j);
        if (g[start - 1][j - 1] && !used[j - 1]) {
            s.push(j - 1);
        }
    }

    for (vector <bool> i : g) {
        for (bool j : i) {
            cout << j << ' ';
        }
        cout << '\n';
    }
    cout << '\n';

    while (true) {
        if (s.size() == 0) return;
        bool f = false;

        goTo(s.top() + 1);
        p[s.top()] = start - 1;
        start = s.top();
        s.pop();

        if (!used[start - 1]) {
            for (int j = 1; j <= l; j++) {
                g[start - 1][j - 1] = getHint(j);
            }
            for (int j = 0; j < l; j++) {
                if (g[start - 1][j] && !used[j]) {
                    s.push(j);
                    f = true;
                    p[j] = start - 1;
                }
            }
            used[start - 1] = true;
            if (!f) goTo(p[start - 1] + 1);
        }

        for (vector <bool> i : g) {
            for (bool j : i) {
                cout << j << ' ';
            }
            cout << '\n';
        }
        cout << '\n';
    }
}