/**
* user:  malinin-a1f
* fname: Stoyan
* lname: Malinin
* task:  lucky
* score: 64.0
* date:  2019-10-10 07:00:18.631856
*/
#include<iostream>
#include<cstring>
#include<vector>

using namespace std;

const int MAXN = 1e4 + 5;
const long long mod = 1e9 + 7;

int n, Q;
string x;

struct state
{
    long long dp[3][2][2]; // smaller/equal/bigger | first | last

    state()
    {
        memset(this->dp, 0, sizeof(this->dp));
    }

    long long value()
    {
        long long ans = 0;
        for(int sign = 0;sign<2;sign++)
        {
            for(int first = 0;first<2;first++)
            {
                for(int last = 0;last<2;last++)
                {
                    ans += dp[sign][first][last];
                }
            }
        }

        return ans%mod;
    }

    state Merge(state other)
    {
        state output = state();

        for(int sign1 = 0;sign1<3;sign1++)
        {
            for(int last1 = 0;last1<2;last1++)
            {
                for(int sign2 = 0;sign2<3;sign2++)
                {
                    for(int first2 = 0;first2<2;first2++)
                    {
                        if(last1==true && first2==true) continue;

                        for(int last2 = 0;last2<2;last2++)
                        {
                            for(int first1 = 0;first1<2;first1++)
                            {
                                int newSign = 0;
                                if(sign1==2) newSign = 2;
                                else if(sign1==1)
                                {
                                    newSign = sign2;
                                }
                                else
                                {
                                    newSign = sign1;
                                }

                                output.dp[newSign][first1][last2] += this->dp[sign1][first1][last1]*other.dp[sign2][first2][last2];
                                output.dp[newSign][first1][last2] %= mod;
                            }
                        }
                    }
                }
            }
        }

        return output;
    }
};

struct node
{
    state val;

    int l, r;
    node *L, *R;

    node(){}
    node(int l, int r)
    {
        this->l = l;
        this->r = r;
        this->L = nullptr;
        this->R = nullptr;
    }

    void build()
    {
        if(this->l==this->r)
        {
            int d = x[this->l] - '0';
            this->val = state();

            for(int i = 0;i<10;i++)
            {
                int sign;
                if(i<d) sign = 0;
                if(i==d) sign = 1;
                if(i>d) sign = 2;

                bool first = (i==3);
                bool last = (i==1);

                this->val.dp[sign][first][last]++;
            }

            //cout << this->l << " " << this->r << " -> " << this->val.value() << '\n';
            return;
        }

        this->L = new node(this->l, (this->l+this->r)/2);
        this->R = new node((this->l+this->r)/2+1, this->r);

        this->L->build();
        this->R->build();

        this->val = this->L->val.Merge(this->R->val);
        //cout << this->l << " " << this->r << " -> " << this->val.value() << '\n';
    }

    void query(int ql, int qr, vector <node*> &v)
    {
        if(this->l>=ql && this->r<=qr)
        {
            v.push_back(this);
            return;
        }
        if(this->r<ql || this->l>qr) return;

        this->L->query(ql, qr, v);
        this->R->query(ql, qr, v);
    }
};

node *T;
vector <node*> v;

int main()
{
    int n, Q;
    cin >> n >> Q;

    cin >> x;

    T = new node(0, n-1);
    T->build();

    cout << T->val.value() << '\n';

    while(Q--)
    {
        int type;

        cin >> type;
        if(type==1)
        {
            int l, r;
            cin >> l >> r;
            l--;r--;

            v.clear();
            T->query(l, r, v);

            state answer;
            answer = v[0]->val;

            for(int i = 1;i<v.size();i++)
            {
                answer = answer.Merge(v[i]->val);
            }

            cout << answer.value() << '\n';
        }
    }
}
