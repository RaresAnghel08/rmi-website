/**
* user:  mushkatin-6ef
* fname: Shirli
* lname: Mushkatin
* task:  Speedrun
* score: 12.0
* date:  2021-12-16 10:48:54.598926
*/
﻿#include <iostream>
#include <vector>
#include <algorithm>
#include "speedrun.h"
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;

int bToInt(int s, int e) {
    int ans = 0;
    int mul = 1;
    for (int i = e; i >= s; i--) {
        ans += getHint(i) * mul;
        mul *= 2;
    }
    return ans;
}

void intToB(int v, int num, int s, int e) {
    for (int i = e; i >= s; i--) {
        setHint(v, i, num % 2);
        num /= 2;
    }
}

void adj(int v, int n, vi& visited) {
    visited[v] = 1;
    vi nei(4);
    int s = 1, e = 10;
    for (int i = 0; i < 4; i++) {
        nei[i] = bToInt(s, e);
        s += 10; e += 10;
    }
    if (!nei[0]) {
        for (int u = 1; u <= n; u++) {
            if (u == v || visited[u])
                continue;
            if (goTo(u)) {
                adj(u, n, visited);
                goTo(v);
            }
        }
    }
    else {
        for (auto u : nei) {
            if (!u)
                continue;
            if (visited[u])
                continue;
            goTo(u);
            adj(u, n, visited);
            goTo(v);
        }
    }
}

void assignHints(int subtask, int N, int A[], int B[]) {
    int n = N;
    setHintLen(40);
    vvi adj(n + 1);
    for (int i = 1; i <= n - 1; i++) {
        int v = A[i], u = B[i];
        //setHint(v, u, 1);
        //setHint(u, v, 1);
        adj[A[i]].push_back(B[i]);
        adj[B[i]].push_back(A[i]);
    }
    for (int v = 1; v <= n; v++) {
        if (adj[v].size() <= 4) {
            int s = 1, e = 10;
            for (auto u : adj[v]) {
                intToB(v, u, s, e);
                s += 10, e += 10;
            }
        }
    }
}

void speedrun(int subtask, int N, int start) {
    vi visited(N + 1);
    adj(start, N, visited);
}