/**
* user:  arslanov-070
* fname: Askar
* lname: Arslanov
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:51:40.328810
*/
#include <bits/stdc++.h>
// #define int long long
using namespace std;


void setHintLen(int l) {}
void setHint(int i, int j, bool b) {}
int getLength() {}
bool getHint(int j) {}
bool goTo(int x) {}


void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(N);
    for (int i = 1; i < N; i++) {
        setHint(A[i], B[i], true);
        setHint(B[i], A[i], true);
    }
}


void speedrun(int subtask, int N, int start) {
    vector<int> can_go;
    for (int i = 1; i < N; i++) {
        if (getHint(i)) {
            goTo(i);
        }
    }
}


// signed main() {
//     // ifstream cin("input.txt"); ofstream cout("output.txt");
//     ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
// }
