/**
* user:  nicola-706
* fname: Alexandra Mihaela
* lname: Nicola
* task:  restore
* score: 13.0
* date:  2019-10-10 09:11:26.705458
*/
#include <iostream>
#include <cstring>
#define DIMN 5010
#define DIMM 10010
using namespace std;

//ifstream cin ("date.in");
//ofstream cout ("date.out");
struct interval{
    int x,y,val,k;
};
interval qry[DIMM];
int v[DIMN],sp[DIMN],w[DIMN],sol[DIMN];
int n,m,i,j,x,y,val,k,nr,ok;
int main (){

    cin>>n>>m;
    ok = 1;
    for (i=1;i<=m;i++){
        cin>>x>>y>>k>>val;
        qry[i] = {x+1,y+1,val,k};
        if (k == 1)
            nr++;
        if (k != 1 && k != y-x+1)
            ok = 0;
    }

    if (nr == m){
        /// am doar k == 1
        for (i=1;i<=m;i++){
            if (qry[i].val == 1){
                v[qry[i].x]++;
                v[qry[i].y+1]--;
            }}
        for (i=1;i<=n;i++)
            v[i] += v[i-1];
        for (i=1;i<=n;i++)
            if (v[i] > 1)
                v[i] = 1;
        /// acum verific daca am cel putin un 0 in intervalele cu 0
        for (i=1;i<=n;i++)
            sp[i] = sp[i-1]+v[i];
        int ok = 1;
        for (i=1;i<=m;i++){
            if (qry[i].val == 0){
                if (sp[qry[i].y]-sp[qry[i].x-1] == qry[i].y-qry[i].x+1){
                    ok = 0;
                    break;
                }}}
        if (!ok){
            cout<<-1;
            return 0;
        }
        for (i=1;i<=n;i++)
            cout<<v[i]<<" ";
        return 0;
    }
    if (n <= 18){
        int dim_max = (1<<n);
        for (int mask=0;mask<dim_max;mask++){
            for (int bit=0;bit<n;bit++){
                if (mask&(1<<bit))
                    v[bit+1] = 1;
                else v[bit+1] = 0;
            }
            for (i=1;i<=n;i++)
                v[i] += v[i-1];
            int ok = 1;
            for (i=1;i<=m;i++){
                int x = qry[i].x, y = qry[i].y;
                if (qry[i].val == 0){
                    /// cel putin k zerouri
                    if (y-x+1-(v[y]-v[x-1]) < qry[i].k){
                        ok = 0;
                        break;
                    }
                } else {
                    /// maxim k-1 zerouri
                    if (y-x+1-(v[y]-v[x-1]) >= qry[i].k){
                        ok = 0;
                        break;
                    }
                }
            }
            if (ok){
                for (int bit=0;bit<n;bit++){
                    if ((mask&(1<<bit)))
                        cout<<1<<" ";
                    else cout<<0<<" ";
                }
                break;
            }
        }

        return 0;
    }
    if (ok){
        /// mai intai rezolv intervalele k = 1 si val = 1 si k == 1 si val == 0
        /// pt k = lg && val == 0 => tot intervalul 0
        for (i=1;i<=m;i++){
            if (qry[i].k == 1 && qry[i].val == 1){
                v[qry[i].x]++;
                v[qry[i].y+1]--;
            }}
        for (i=1;i<=n;i++)
            v[i] += v[i-1];
        for (i=1;i<=n;i++){
            if (v[i] > 1)
                v[i] = 1;
            else v[i] = -1; /// => nu sunt sigura ce pun
        }
        /*/// acum verific daca am cel putin un 0 in intervalele cu 0
        for (i=1;i<=n;i++)
            sp[i] = sp[i-1]+v[i];
        int ok = 1;
        for (i=1;i<=m;i++){
            if (qry[i].k == 1 && qry[i].val == 0){
                if (sp[qry[i].y]-sp[qry[i].x-1] == qry[i].y-qry[i].x+1){
                    ok = 0;
                    break;
                }}}
        if (!ok){
            cout<<-1;
            return 0;
        }*/

        /// elementele de 1 sunt sigur puse bine acolo
        /// trb sa vad pt k = lg si val = 0, fac alt smen
        for (i=1;i<=m;i++){
            if (qry[i].k == 1)
                continue;
            if (qry[i].val == 0){
                w[qry[i].x]--;
                w[qry[i].y]++;
            }}

        for (i=1;i<=n;i++)
            w[i] += w[i-1];
        for (i=1;i<=n;i++){
            if (w[i] < 0)
                w[i] = 0;
            else w[i] = -1; /// => nu sunt sigura ce pun acolo
        }
        memset (sol,-1,sizeof sol);
        int ok = 1;
        for (i=1;i<=n;i++){
            if ( (v[i] == 1 && w[i] == 0) || (v[i] == 0 && w[i] == 1)){
                ok = 0;
                break;
            }
            if (v[i] == 1 || w[i] == 1)
                sol[i] = 1;
            else sol[i] = 0;
        }
        if (!ok){
            cout<<-1;
            return 0;
        }



        /*for (i=1;i<=m;i++){
            if (qry[i].k == 1)
                continue;
            if (qry[i].val == 0){
                /// trb sa am numai 0 in intervalul asta
                if (sp[qry[i].y]-sp[qry[i].x-1] != 0){
                    ok = 0;
                    break;
                }
            } else {
                /// trb sa am cel putin un 1
                if (sp[qry[i].y]-sp[qry[i].x-1] == 0){
                    ok = 0;
                    break;
                }}}
        if (!ok){
            cout<<-1;
            return 0;
        }
        for (i=1;i<=n;i++)
            cout<<v[i]<<" ";*/
    }



    return 0;
}

