/**
* user:  nurtdinov-d7e
* fname: Artur
* lname: Nurtdinov
* task:  Gardening
* score: 11.0
* date:  2021-12-16 09:32:47.087328
*/
#include <iostream>
using namespace std;
void solve(int n, int m, int k) {
    if (n * m < 4 * k) {
        cout << "NO" << endl;
    } else if (n % 2 or m % 2) {
        cout << "NO" << endl;
    } else {
        int b[n][m];
        int x = n;
        int y = m;
        int a = k;
        int use = 1;
        int off = 0;
        while (x > 0 and y > 0) {
            if (x * y == 4 * a) {
                cout << "YES" << endl;
                for(int i = off + 0; i < x + off; i += 2) {
                    for (int j = off + 0; j < y + off; j += 2) {
                        b[i][j] = use;
                        b[i][j + 1] = use;
                        b[i + 1][j] = use;
                        b[i + 1][j + 1] = use;
                        use++;
                    }
                }
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < m; j++) {
                        cout << b[i][j] << " ";
                    } cout << "\n";
                }
                return;
            } else {
                if ((x - 2) * (y - 2) < (a - 1) * 4 or ((((x - 2) * (y - 2) % 8) == 4) xor ((a - 1) % 2))) {
                    if (x > y) {
                        for (int i = 0; i < y; i+=2) {
                            b[-1 + x + off][i + off] = use;
                            b[-2 + x + off][i + off] = use;
                            b[-1 + x + off][i + 1 + off] = use;
                            b[-2 + x + off][i + 1 + off] = use;
                            use++;
                        } x -= 2; a -= (y / 2);
                    } else {
                        for (int i = 0; i < x; i+=2) {
                            b[i + off][-1 + y + off] = use;
                            b[i + off][-2 + y + off] = use;
                            b[i + 1 + off][-1 + y + off] = use;
                            b[i + 1 + off][-2 + y + off] = use;
                            use++;
                        } y -= 2; a -= (x / 2);
                    }
                } else {
                    for (int i = 0; i < y; i++) {
                        b[0 + off][i + off] = use;
                        b[x - 1 + off][i + off] = use;
                    } for (int i = 0; i < x; i++) {
                        b[i + off][0 + off] = use;
                        b[i + off][-1 + y + off] = use;
                    } use++;
                    a -= 1;
                    x -= 2;
                    y -= 2;
                    off += 1;
                }
            }
        } if (x <= 0 or y <= 0) {cout << "NO" << endl;}
    }
}

int main() {
    int t;
    cin >> t;
    for (int i=0; i<t; i++) {
        int n, m, k;
        cin >> n >> m >> k;
        solve(n, m, k);
    }
}