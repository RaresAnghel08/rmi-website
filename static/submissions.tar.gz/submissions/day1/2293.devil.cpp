/**
* user:  karagyozov-c76
* fname: Ivo
* lname: Karagyozov
* task:  devil
* score: 0.0
* date:  2019-10-10 08:56:44.773758
*/
#include <bits/stdc++.h>

int main() {
	std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);

	int32_t t;
	std::cin >> t;

	for(int32_t cs = 1; cs <= t; cs++) {
		int32_t k;
		std::cin >> k;

		std::vector< int32_t > a(10);
		for(int32_t i = 1; i < 10; i++) {
			std::cin >> a[i];
		}
		
		bool flag = false;
		int32_t bigger = -1;
		for(int32_t i = 9; i >= 1; i--) {
			if(a[i] > 1 || (a[i] == 1 && flag)) {
				bigger = i;
				break;
			}
			if(a[i] == 1) {
				flag = true;
			}
		}

		for(int32_t i = 1; i < 10; i++) {
			std::string res = "";
			std::vector< int32_t > cnt(10, 0);

			int32_t ind = i;
			while(1) {
				if(ind < 1 || cnt[bigger] == a[bigger]) {
					break;
				}
				if(a[ind] == cnt[ind]) {
					ind--;
					continue;
				}

				if(ind == bigger && cnt[ind] + 2 > a[ind]) {
					ind--;
					continue;
				}

				res += (char) (bigger + '0');
				res += (char) (ind + '0');

				cnt[ind]++;
				cnt[bigger]++;
			}

			if(cnt[bigger] == a[bigger] || (!flag && cnt[bigger] == a[bigger] - 1)) {
				for(int32_t j = 1; j < 10; j++) {
					std::string aux(a[j] - cnt[j], (char) (j + '0'));
					res += aux;
				}

				std::cout << res << '\n';
				break;
			}
		}
	}
}
