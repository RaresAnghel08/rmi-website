/**
* user:  badea-bb4
* fname: Lucian Andrei
* lname: Badea
* task:  Gardening
* score: 0.0
* date:  2021-12-16 09:48:08.535009
*/
#include <bits/stdc++.h>
using namespace std;

const int NMAX = 2e5, MMAX = 2e5;

//int a[NMAX][MMAX];
int v[MMAX];

bool verif(long long x) {
    long long rad = sqrtl(x);

    if(rad * rad == x)
        return true;
    return false;
}

void solve() {
    long long n, m, k, x1, y1, z1, len;
    cin >> n >> m >> k;

    if(n % 2 == 1 || m % 2 == 1)
        cout << "NO" << endl;
    else {
        long long delta, nr;
        delta = (m + n) / 2 - 1;
        delta = delta * delta;
        nr = 1LL * m * n - 4LL * k;
        delta = delta - nr;
        if(verif(delta)) {
            long long rad = sqrt(delta);
            nr = (m + n) / 2 - 1;
            long long nr1 = nr + rad, nr2 = nr - rad;
            if(nr1 % 2 == 0) {
                z1 = nr1 / 2;
                x1 = m / 2 - z1;
                y1 = n / 2 - z1;
                if(x1 >= 0 && y1 >= 0 && z1 >= 0) {
                    cout << "YES" << endl; // << x1 << ' ' << y1 << ' ' << z1 << endl;
                    for(int i = 0; i < z1; i++) {
                        len = 0;
                        for(int c = 0; c < i; c++)
                            v[len++] = c + 1;
                        for(int c = i; c < m - i; c++)
                            v[len++] = i + 1;
                        for(int c = m - i; c < m; c++)
                            v[len++] = m - c;
                        for(int l = 0; l < m - 1; l++)
                            cout << v[l] << ' ';
                        cout << v[m - 1] << endl;
                    }
                    int cul = z1 + 1;
                    for(int i = z1; i < n - z1; i += 2) {
                        for(int xxx = 0; xxx < 2; xxx++) {
                            len = 0;
                            for(int x = 0; x < z1; x++)
                                v[len++] = x + 1;
                            for(int c = z1; c < m - z1; c += 2) {
                                int x = cul + (c - z1) / 2;
                                v[len++] = x;
                                v[len++] = x;
                            }
                            for(int x = z1 - 1; x >= 0; x--)
                                v[len++] = x + 1;
                            for(int l = 0; l < m - 1; l++)
                                cout << v[l] << ' ';
                            cout << v[m - 1] << endl;
                        }
                        cul += x1;
                    }
                    for(int i = z1 - 1; i >= 0; i--) {
                        len = 0;
                        for(int c = 0; c < i; c++)
                            v[len++] = c + 1;
                        for(int c = i; c < m - i; c++)
                            v[len++] = i + 1;
                        for(int c = m - i; c < m; c++)
                            v[len++] = m - c;
                        for(int l = 0; l < m - 1; l++)
                            cout << v[l] << ' ';
                        cout << v[m - 1] << endl;
                    }
                } else {
                    z1 = nr2 / 2;
                    x1 = m / 2 - z1;
                    y1 = n / 2 - z1;
                    if(x1 >= 0 && y1 >= 0 && z1 >= 0) {
                        cout << "YES" << endl; //<< x1 << ' ' << y1 << ' ' << z1 << endl;
                        for(int i = 0; i < z1; i++) {
                            len = 0;
                            for(int c = 0; c < i; c++)
                                v[len++] = c + 1;
                            for(int c = i; c < m - i; c++)
                                v[len++] = i + 1;
                            for(int c = m - i; c < m; c++)
                                v[len++] = m - c;
                            for(int l = 0; l < m - 1; l++)
                                cout << v[l] << ' ';
                            cout << v[m - 1] << endl;
                        }
                        int cul = z1 + 1;
                        for(int i = z1; i < n - z1; i += 2) {
                            for(int xxx = 0; xxx < 2; xxx++) {
                                len = 0;
                                for(int x = 0; x < z1; x++)
                                    v[len++] = x + 1;
                                for(int c = z1; c < m - z1; c += 2) {
                                    int x = cul + (c - z1) / 2;
                                    v[len++] = x;
                                    v[len++] = x;
                                }
                                for(int x = z1 - 1; x >= 0; x--)
                                    v[len++] = x + 1;
                                for(int l = 0; l < m - 1; l++)
                                    cout << v[l] << ' ';
                                cout << v[m - 1] << endl;
                            }
                            cul += x1;
                        }
                        for(int i = z1 - 1; i >= 0; i--) {
                            len = 0;
                            for(int c = 0; c < i; c++)
                                v[len++] = c + 1;
                            for(int c = i; c < m - i; c++)
                                v[len++] = i + 1;
                            for(int c = m - i; c < m; c++)
                                v[len++] = m - c;
                            for(int l = 0; l < m - 1; l++)
                                cout << v[l] << ' ';
                            cout << v[m - 1] << endl;
                        }
                    } else
                        cout << "NO" << endl;
                }
            } else
                cout << "NO" << endl;
        } else {
            cout << "NO" << endl;
        }
    }
}

int main() {
    int t;
    cin >> t;
    while(t--) {
        solve();
    }
    return 0;
 }
