/**
* user:  badea-bb4
* fname: Lucian Andrei
* lname: Badea
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:40:09.029496
*/
#include <iostream>
#include <bitset>
using namespace std;

const int MMAX = 2e5;

bitset<6 * 200000 + 1> f;
bitset<6 * 200000 + 1> linSauCol;

int a[6][MMAX], kk;

bool functie(int cul, int n, int m, int k) {
    //cout << cul << ' ' << n << ' ' << m << ' ' << k << endl;
    if(n < 0 || m < 0 || k < 0)
        return false;
    if((n == 0 || m == 0) && k == 0)
        return true;
    if(k * 4 > m * n)
        return false;
    if(functie(cul + 1, n - 2, m - 2, k - 1) == true) {
        //cout << "hatz" << endl;
        f[cul] = 1;
        linSauCol[cul] = 0;
        return true;
    } else if(functie(cul + n / 2, n, m - 2, k - n / 2) == true) {
        //cout << "john" << ' ' << cul << endl;
        for(int i = cul; i < cul + n / 2; i++) {
            f[i] = 0;
            linSauCol[i] = 1;
        }
        return true;
    }else if(functie(cul + m / 2, n, m - 2, k - m / 2) == true) {
        //cout << "johnule" << endl;
        for(int i = cul; i < cul + m / 2; i++) {
            f[i] = 0;
            linSauCol[i] = 0;
        }
        return true;
    }
    return false;
}


void solve() {
    long long n, m, k;
    cin >> n >> m >> k;
    for(int i = 1; i <= k; i++)
        f[i] = linSauCol[i] = 1;
    kk = k;
    if(n % 2 == 1 || m % 2 == 1) {
        cout << "NO" << endl;
        return;
    }
    functie(1, n, m, k);
    //for(int i = 1; i <= k; i++)
        //cout << f[i] << ' ' << linSauCol[i] << endl;
    for(int i = 1; i <= k; i++) {
        if(f[i] == 1 && linSauCol[i] == 1) {
            cout << "NO" << endl;
            return;
        }
    }
    long long nn = n, mm = m, nnn = 0, mmm = 0;
    for(int i = 1; i <= k; i += 0) {
        //cout << nn << ' ' << mm << ' ' << nnn << ' ' << mmm << endl;
        if(f[i] == 1) {
            for(int l = nnn; l < nn; l++)
                a[l][mmm] = a[l][mm - 1] = i;
            for(int c = mmm; c < mm; c++)
                a[nnn][c] = a[nn - 1][c] = i;
            nn--;
            mm--;
            nnn++;
            mmm++;
            i++;
        } else {
            if(linSauCol[i] == 1) {
                for(int l = nnn; l < nn; l += 2) {
                    a[l][mmm] = a[l + 1][mmm] = a[l][mmm + 1] = a[l + 1][mmm + 1] = i++;
                }
                //mm -= 2;
                mmm += 2;
            } else {
                for(int c = mmm; c < mm; c += 2) {
                    a[nnn][c] = a[nnn + 1][c] = a[nnn][c + 1] = a[nnn + 1][c + 1] = i++;
                }
                //nn -= 2;
                nnn += 2;
            }
        }
    }
    cout << "YES" << endl;
    for(int l = 0; l < n; l++) {
        for(int c = 0; c < m; c++)
            cout << a[l][c] << ' ';
        cout << endl;
    }
}

int main() {
    int t;
    cin >> t;
    while(t--)
        solve();
    return 0;
}
