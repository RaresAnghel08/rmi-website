/**
* user:  toma-9a5
* fname: Eliza Maria
* lname: Toma
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:00:15.280968
*/
#include <bits/stdc++.h>

using namespace std;

void setHintLen(int l);
void setHint(int i, int j, bool b);
int getLength();
bool getHint(int j);
bool goTo(int x);
void assignHints(int subtask , int N, int A[], int B[]);
void speedrun(int subtask , int N, int start);

void assignHints(int subtask , int N, int A[], int B[]) {
    setHintLen(N);
    for (int i = 1;i < N;i++) {
        setHint(A[i], B[i], 1);
        setHint(B[i], A[i], 1);
    }
}
void speedrun(int subtask , int N, int start) {
    int parent[N + 5];
    int cnt = 1,node = start,ind = 1;
    for (int i = 1;i <= N;i++)
        parent[i] = 0;
    parent[start] = start;
    while (cnt < N) {
        while (cnt < N && ind <= N) {
            if (!parent[ind] && getHint(ind) == 1) {
                if (goTo(ind) == 1) {
                    parent[ind] = node;
                    node = ind;
                    ind = 0;
                    cnt++;
                }
            }
            ind++;
        }
        if (cnt < N) {
            ind = 1;
            if (goTo(parent[node]);)
                node = parent[node];
        }
    }
    return;
}
