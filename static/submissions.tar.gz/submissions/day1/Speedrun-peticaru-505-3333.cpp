/**
* user:  peticaru-505
* fname: Alexandru
* lname: Peticaru
* task:  Speedrun
* score: 8.0
* date:  2021-12-16 10:55:58.648652
*/
#include <bits/stdc++.h>
#define ll long long
#define ld long double
#include "speedrun.h"

using namespace std;

const ll MOD = 1e9 + 7;
const ll INF = 1e9;



vector<int>G[1002];
int viz1[1002], par[1002], t[1002], nr;

void assignHints (int subtask, int N, int a[], int b[]) {
    setHintLen(20);
    for (int i = 1; i < N; i++) {
      G[a[i]].push_back(b[i]);
      G[b[i]].push_back(a[i]);
    }
    int val = 0;
    for (int i = 1; i <= N; i++) {
      if (G[i].size() == N - 1) {
        val = i;
        break;
      }
    }
  for (int i = 1; i <= N; i++) {
     for (int k = 0; k < 10; k++) 
        setHint(i, k + 1, ((val & (1 << k)) > 0));
  }  
}

int Next () {
  int ans = 0;
  for (int k = 0; k < 10; k++) {
    if (getHint(k + 1))
      ans += (1 << k);
  }
  return ans;
}

int Prev () {
  int ans = 0;
  for (int k = 0; k < 10; k++) {
    if (getHint(k + 11))
      ans += (1 << k);
  }
  return ans;
}


void speedrun (int subtask, int N, int start) {
  int val = Next();
  goTo(val);
  for (int i = 1; i <= N; i++) {
    goTo(i);
    goTo(val);
  }

}


