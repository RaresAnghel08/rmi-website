/**
* user:  ginzburg-8de
* fname: Yael
* lname: Ginzburg
* task:  Present
* score: 29.0
* date:  2021-12-16 11:40:01.603318
*/
// Present.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int gcd(int a, int b)
{
    if (a < b) swap(a, b);
    if (b == 0) return a;
    return gcd(b, a % b);
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int T; cin >> T;
    vector<pair<int, int>> queries(T);
    vector<int> K(T);
    for (int t = 0; t < T; t++)
    {
        cin >> K[t];
        queries[t].second = t; 
        queries[t].first = K[t];
    }
    sort(queries.begin(), queries.end());
    int k= queries.back().first;
        
        vector<vector<int>> pres;
        int i = 1;
        while (pres.size() < k)
        {
            int s = pres.size();
            pres.push_back({ i });
            if (pres.size() == k) break;
            for (int j = 0; j < s; j++)
            {
                vector<bool> been(i + 1, false);
                been[i] = true;
                bool f = true;
                for (int u = 0; u < pres[j].size(); u++)
                {
                    been[pres[j][u]] = true;
                    if (!been[gcd(pres[j][u], i)])
                    {
                        f = false;
                        break;
                    }
                }
                if (f)
                {
                    pres.push_back(pres[j]);
                    pres.back().push_back(i);
                }
                if (pres.size() == k) break;
            }
            i++;
        }
        for (int i = 0; i < T; i++)
        {
            if (K[i] == 0) cout << 0 << endl;
            else
            {
                cout << pres[K[i] - 1].size() << " ";
                for (int k : pres[K[i] - 1]) cout << k << " ";
                cout << endl;
            }
       }
}

