/**
* user:  khargelia-6b3
* fname: Sergei
* lname: Khargelia
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:33:09.134311
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
#define F first
#define S second
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define SZ(x) (int)x.size()

const int N = 1e5 + 10;
const int MOD = 1e9 + 7;

int dp1[N], dp2[N], pw[N], pref[N], dp3[N];
void add(int &a, int b) {
	a += b;
	if (a >= MOD) {
		a -= MOD;
	}
}

int sum(int a, int b) {
	a += b;
	if (a >= MOD) {
		a -= MOD;
	}
	return a;
}

int r(int a, int b) {
	a -= b;
	if (a < 0) {
		a += MOD;
	}
	return a;
}

int mult(int a, int b) {
	return (a * 1ll * b) % MOD;
}

void precalc() {
	pw[0] = 1;
	for (int i = 1; i <= 1e5; i++) {
		pw[i] = mult(pw[i - 1], 10);
	}
	dp1[1] = 0;
	dp2[1] = 1;
	dp3[1] = 1;
	for (int i = 2; i <= 1e5; i++) {
		dp1[i] = sum(mult(dp1[i - 1], 10), dp2[i - 1]);
		dp2[i] = r(mult(pw[i - 2], 9), dp1[i - 1]);
		dp3[i] = sum(pw[i - 1], sum(mult(8, dp1[i - 1]), dp3[i - 1])); 
		pref[i] = sum(pref[i - 1], dp1[i]);
	}
	//cout << dp3[3] << '\n';
	//pref[0] = 1;
	//cout << pref[3] << '\n';
}

int get(string &s) {
	int res = pref[SZ(s) - 1];
	if (SZ(s) == 1) {
		return 0;
	}
	//cout << res << '\n';
	int prv = -1;
	for (int i = 0; i < SZ(s); i++) {
		//cout << "BEGIN " << i << '\n';
		if (i == 0) {
			for (int digit = 1; digit < s[i] - '0'; digit++) {
				if (digit == 1) {
					/*if (SZ(s) - i - 2 >= 0) {
						add(res, pw[SZ(s) - i - 2]);
					}
					add(res, mult(9, pref[SZ(s) - i - 2]));*/
					add(res, dp3[SZ(s) - i - 1]);
				}
				else {
					add(res, pref[SZ(s) - i - 1]);
				}
			}
			//cout << res << '\n';
		}
		else {
			for (int digit = 0; digit < s[i] - '0'; digit++) {
				if (digit == 1) {
					/*add(res, pw[SZ(s) - i - 2]);
					//cout << "CHECK " << res << '\n';
					if (SZ(s) - i - 2 >= 0) {
						add(res, mult(9, pref[SZ(s) - i - 2]));
					}
					cout << res << '\n';*/
					add(res, dp3[SZ(s) - i - 1]);	
				}
				else if (digit == 3 && prv == 1) {
					add(res, pw[SZ(s) - i - 1]);
				}
				else {
					add(res, pref[SZ(s) - i - 1]);
					//cout << res << '\n';	
				}
				
			}
			//cout << res << '\n';
			if (prv == 1 && s[i] - '0' == 3) {
				int kek = 0;
				for (int j = i + 1; j < SZ(s); j++) {
					kek = sum(mult(kek, 10), s[j] - '0');
				}
				add(kek, 1);
				add(res, kek);
				return res;
			}
		}
		prv = s[i] - '0';
		//cout << "END " << i << '\n';
	}

	return res;
}

bool check(int n) {
	vector<int> d;
	while (n) {
		d.pb(n % 10);
		n /= 10;
	}
	reverse(all(d));
	for (int  i= 0; i + 1 < SZ(d); i++) {
		if (d[i] == 1 && d[i + 1] == 3) {
			return true;
		}
	}
	return false;
}

int slow(int n) {
	int res = 0;
	for (int i = 1; i <= n; i++) {
		if (check(i)) {
			res++;
		}
	}
	return res;
}

int f() {
	int res = 0;
	for (int i = 11000; i <= 12000; i++) {
		if (check(i)) {
			res++;
		}
	}
	return res;
}

signed main() {
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	precalc();
	int n, q;
	cin >> n >> q;
	string s;
	cin >> s;
	cout << get(s) << '\n';
}