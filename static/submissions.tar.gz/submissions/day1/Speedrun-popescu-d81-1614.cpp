/**
* user:  popescu-d81
* fname: Paul
* lname: Popescu
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 08:13:17.868635
*/
#include "speedrun.h"

void assignHints(int subtask, int n, int A[], int B[])
{
   setHintLen(n);
   for (int i = 1; i < n; i++)
      setHint(A[i], B[i], true),
      setHint(B[i], A[i], true);
}
#include <bitset>
std::bitset<1001> E;
void F(const int l, int s, int t)
{
   E[t] = true;
   for (int f = 1; f <= l; f++) if (getHint(f) and !E[f])
      goTo(f), F(l, s, f), goTo(t);
}
void speedrun(int subtask, int n, int s)
{
   F(getLength(), s, s);
}
