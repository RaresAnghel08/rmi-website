/**
* user:  almazbekov-a71
* fname: Beksultan
* lname: Almazbekov
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:21:17.244167
*/
#include <bits/stdc++.h>
using namespace std;
#define pii pair<int,int>
#define fr first
#define sc second
#define NO puts("NO");
#define YES puts("YES");
#define endi puts("");
main(){
	int t;
	cin>>t;
	while (t--){
		int n,m,k,i,j;
		cin>>n>>m>>k;
		if (n%2 == 1 || m%2 == 1 || n == 2 && m/2 != k){
			NO
			continue;
		}
		if (n == 2){
			YES
			for (i=0;i<m;++i){
				cout <<i/2+1<<" ";
			}endi
			for (i=0;i<m;++i){
				cout <<i/2+1<<" ";
			}endi
		}
		if (n == 4){
			if (m == k){
				YES
				int c = 1;
				for (i=0;i<n;i++){
					int cnt = c;
					for (j=0;j<m;j+=2){
						cout <<cnt<<" "<<cnt<<" ";
						cnt++;
					}
					if (i %2)c = cnt;
					endi
				}
			}
			else if (m == k*2){
				YES
				for (i=0;i<n;i++){
					for (j=0;j<m;j++){
						if (i == 0 || j == 0 || j == m-1 || i == n-1)cout <<"1 ";
						else cout <<(i-1)/2+(j-1)/2+2+(i-1)/2<<" ";
					}endi
					
				}
			}
			else NO
		}
		
	}
}






