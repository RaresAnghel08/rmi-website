/**
* user:  kharisov-ffd
* fname: Bulat Rafailevich
* lname: Kharisov
* task:  Present
* score: 29.0
* date:  2021-12-16 08:46:29.226831
*/
#include<bits/stdc++.h>
using namespace std;

#define size(a) (int)a.size()
#define pb emplace_back
#define all(a) a.begin(), a.end()

const int N = 1e3 + 3;

int gcd(int a, int b) { return b ? gcd(b, a % b) : a; }

bool check(vector<int> a) {
    int n = size(a);
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            int q = gcd(a[i], a[j]);
            if (*lower_bound(all(a), q) != q) return false;
        }
    }
    return true;
}


int n;

bool rec(int id, vector<bool>& a) {
    if (n == 0) {
        int c = 0;
        for (int i = 0; i < size(a); ++i)
            c += a[i];
        cout << c << " ";
        for (int i = 0; i < size(a); ++i) {
            if (a[i]) cout << i << " ";
        }
        cout << endl;
        return true;
    }
    --n;

    for (int i = 1; i < id; ++i) {
        if (a[i]) continue;
        vector<int> b{i};
        a[i] = true;
        for (int j = 0; j < size(a); ++j) {
            if (!a[j]) continue;
            int q = gcd(i, j);
            if (!a[q])
                a[q] = true, b.pb(q);
        }
        if (rec(i, a)) return true;
        for (int j : b)
            a[j] = false;
    }
    return false;
}

void run() {
    cin >> n;
    vector<bool> a(26);
    rec(26, a);
}


signed main() {
	cin.tie(0), cout.tie(0), ios_base::sync_with_stdio(0);

    clock_t time = clock();
    int t;
    cin >> t;
    while (t--) {
        run();
    }
    //cout << ((double)clock() - time) / CLOCKS_PER_SEC << endl;
}