/**
* user:  pagu-0b4
* fname: Tudor Stefan
* lname: Pagu
* task:  Speedrun
* score: 100.0
* date:  2021-12-16 11:01:35.906206
*/
#include <bits/stdc++.h>
#include "speedrun.h"
using namespace std;

//ifstream in("in.in");
//ofstream out("out.out");
const int nmax = 1005;

//---------
/*
int curNode;
int hint[nmax][nmax],realad[nmax][nmax];
int LNOTATHING;

void setHintLen(int l) {
    LNOTATHING = l;
}
void setHint(int i, int j, bool b) {
    hint[i][j] = b;
}
int getLength() {
    return LNOTATHING;
}
bool goTo(int node) {
    out << "WE GO FROM " << curNode << " TO " << node << " ";
    if (realad[curNode][node]) {
        out << "SUCCES\n";
        curNode = node;
        return true;
    } else {
        out << "\nFAILURE\n\n";
        return false;
    }
}
bool getHint(int j) {
    return hint[curNode][j];
}*/
//------------

vector<vector<int>> g,kids;
int parent[nmax],NextVal[nmax];
int dfs(int node, int par) {
    parent[node] = par;
    for (auto k : g[node]) {
        if (k != par) {
            kids[node].push_back(k);
            parent[k] = node;
            dfs(k , node);
        }
    }
}
void codify(int half, int poz, int val) {
    int pre = half * 10;
    for (int i = 0; i < 10; i++) {
        if (val & (1 << i)) {
            setHint(poz , pre + i + 1 , true);
        }
    }
}
void get_next(int node, int Next) {
    if (kids[node].empty()) {
        NextVal[node] = Next;
        return;
    }

    int foundOne = 0;
    for (int i = 0; i < kids[node].size(); i++) {
        if (foundOne == 0) {
            foundOne = 1;
            NextVal[node] = kids[node][i];
        }
        int ChildNext;
        if (i + 1 == kids[node].size()) {
            ChildNext = Next;
        } else {
            ChildNext = kids[node][i + 1];
        }
        get_next(kids[node][i] , ChildNext);
    }
}
void assignHints(int subtask, int N, int A[], int B[]) {
    setHintLen(20);
    g.resize(N + 1);
    kids.resize(N + 1);
    for (int i = 1; i < N; i++) {
        g[A[i]].push_back(B[i]);
        g[B[i]].push_back(A[i]);
    }
    ///root will be 1
    ///get wayToRoot[i]
    dfs(1 , 0);

    for (int i = 1; i <= N; i++) {
        codify(0 , i , parent[i]);
    }

    int next_1 = 0;
    if (!g[1].empty()) {
        next_1 = g[1][0];
    }
    get_next(1 , 0);

    for (int i = 1; i <= N; i++) {
        codify(1 , i , NextVal[i]);
    }
    //cout << "\n";
}

int l,viz[nmax],n;

int deCode(int half) {
    int l = half * 10, val = 0;
    for (int i = 0; i < 10; i++) {
        if (getHint(i + l + 1)) {
            val += (1 << i);
        }
    }
    return val;
}
int finished = 0;
int Go(int node, int par) {

    int Next = deCode(1);

    if (Next == 0) finished = 1;

    if (finished == 1) return 0;

    bool verdict = goTo(Next);
    while(verdict) {

        Next = Go(Next, node);
        if (finished == 1) return 0;

        verdict = goTo(Next);
    }

    if (par != 0) {
        goTo(par);
    }
    return Next;
}
void speedrun(int subtask, int N, int start) {
    l = getLength();
    //get to root

    int par = deCode(0),node = start;
    while (par != 0) {
        goTo(par);
        node = par;
        par = deCode(0);
    }

    Go(node, 0);

   // cout << "\n";

}

/*
int A[nmax],B[nmax];
int main() {
    int start,n;
    in >> n >> start;
    curNode = start;
    for (int i = 1; i < n; i++) {
        in >> A[i] >> B[i];
        realad[A[i]][B[i]] = 1;
        realad[B[i]][A[i]] = 1;
    }
    assignHints(1 , n , A , B);
    speedrun(1 , n , start);
}*/