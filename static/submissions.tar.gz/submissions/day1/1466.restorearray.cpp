/**
* user:  nezmah-c8c
* fname: Krešimir
* lname: Nežmah
* task:  restore
* score: 7.0
* date:  2019-10-10 06:53:16.493224
*/
#include<bits/stdc++.h>

using namespace std;

typedef long long llint;

const int MAXN = 5005;

int n, m;
int a[MAXN], p[MAXN];
int lef[MAXN], rig[MAXN], br[MAXN], tip[MAXN];

bool check () {
    for (int i=0; i<n; i++) {
        p[i] = (i == 0 ? 0 : p[i-1]) + a[i];
    }
    for (int i=0; i<m; i++) {
        int jen = p[rig[i]] - (lef[i] == 0 ? 0 : p[lef[i] - 1]);
        int nul = rig[i] - lef[i] + 1 - jen;
        //cout << "bla " << i << " " << nul << " " << jen << endl;
        if (tip[i] == 0) {
            if (!(nul >= br[i])) return 0;
        } else {
            if (!(nul < br[i])) return 0;
        }
    }
    return 1;
}

int main () {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cin >> n >> m;
	memset(a, -1, sizeof a);
	for (int i=0; i<m; i++) {
        cin >> lef[i] >> rig[i] >> br[i] >> tip[i];
	}
    if (n <= 18) {
        bool naso = 0;
        for (int mask = 0; mask < (1 << n); mask++) {
            for (int i=0; i<n; i++) {
                a[i] = !!(mask & (1 << i));
            }
            if (check()) {
                naso = 1;
                break;
            }        }
        //a[0] = 0; a[1] = 1; a[2] = 0; a[3] = 0;
        if (naso) {
            for (int i=0; i<n; i++) {
                cout << a[i] << " ";
            }
            cout << endl;
        } else {
            cout << -1 << endl;
        }
        return 0;
    }
	return 0;
}
