/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Present
* score: 8.0
* date:  2021-12-16 07:27:15.649216
*/
#include <bits/stdc++.h>

using namespace std;
/*ifstream fin("date.in");
ofstream fout("date.out");*/
int n,maxi[1000005],t,k;
int last=1000;
set<int> S[1000005];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    maxi[0]=0;
    int cur=1;
    int poz=0;
    for(int i=1;i<=last;i++)
    {
        bool ok=0;
        while(ok==0)
        {
            ok=1;
            if(maxi[poz]==cur)
            {
                poz=0;
                cur++;
            }
            if(S[poz].empty())
            {
                S[i]=S[poz];
                S[i].insert(cur);
                maxi[i]=cur;
                poz++;
                break;
            }
            for(auto j:S[poz])
            {
                int cmmdc=__gcd(j,cur);
                if(S[poz].find(cmmdc)==S[poz].end())
                {
                    ok=0;
                    break;
                }
            }
            if(ok)
            {
                S[i]=S[poz];
                S[i].insert(cur);
                maxi[i]=cur;
            }
            poz++;
        }
    }
    cin>>t;
    while(t--)
    {
        cin>>k;
        cout<<S[k].size()<<' ';
        if(S[k].empty())
        {
            cout<<'\n';
            continue;
        }
        for(auto i:S[k])
            cout<<i<<' ';
        cout<<'\n';
    }
    return 0;
}
