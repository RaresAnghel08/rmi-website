/**
* user:  greaca-04d
* fname: Albert Antoniu
* lname: Greaca
* task:  Gardening
* score: 0.0
* date:  2021-12-16 07:40:03.719343
*/
#include<bits/stdc++.h>
#define ll long long
using namespace std;
int v[7][200005];
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    int t,n,m,k,i1,i,j,nr;
    scanf("%d",&t);
    for(i1=1;i1<=t;i1++){
        scanf("%d%d%d",&n,&m,&k);
        if (n%2==1 || m%2==1){
            printf("NO\n");
            continue;
        }
        if (n==2){
            if (k==m/2){
                nr=1;
                for(i=1;i<=m;i=i+2){
                    v[1][i]=nr;
                    v[1][i+1]=nr;
                    v[2][i]=nr;
                    v[2][i+1]=nr;
                    nr++;
                }
                printf("YES\n");
                for(i=1;i<=2;i++){
                    for(j=1;j<=m;j++)
                        printf("%d ",v[i][j]);
                    printf("\n");
                }
            }
            else{
                printf("NO\n");
            }
        }
        if (n==4){
            if (k==m){
                nr=1;
                for(i=1;i<=m;i=i+2){
                    v[1][i]=nr;
                    v[1][i+1]=nr;
                    v[2][i]=nr;
                    v[2][i+1]=nr;
                    nr++;
                    v[3][i]=nr;
                    v[3][i+1]=nr;
                    v[4][i]=nr;
                    v[4][i+1]=nr;
                    nr++;
                }
                printf("YES\n");
                for(i=1;i<=4;i++){
                    for(j=1;j<=m;j++)
                        printf("%d ",v[i][j]);
                    printf("\n");
                }
            }
            else
                if (k==m/2){
                    for(i=1;i<=m;i++)
                        v[1][i]=v[n][i]=1;
                    for(i=1;i<=n;i++)
                        v[i][1]=v[i][m]=1;
                    nr=2;
                    for(i=2;i<m;i=i+2){
                        v[2][i]=nr;
                        v[2][i+1]=nr;
                        v[3][i]=nr;
                        v[3][i+1]=nr;
                        nr++;
                    }
                    printf("YES\n");
                    for(i=1;i<=4;i++){
                        for(j=1;j<=m;j++)
                            printf("%d ",v[i][j]);
                        printf("\n");
                    }
                }
                else{
                    printf("NO\n");
                }
        }
    }
return 0;
}
