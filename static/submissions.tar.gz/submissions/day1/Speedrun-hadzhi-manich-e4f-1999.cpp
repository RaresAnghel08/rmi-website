/**
* user:  hadzhi-manich-e4f
* fname: Deyan Deyanov
* lname: Hadzhi-Manich
* task:  Speedrun
* score: 63.0
* date:  2021-12-16 08:49:12.576675
*/
#include "speedrun.h"
#include <bits/stdc++.h>
using namespace std;
const int MAXN=1024;
bool edge[MAXN][MAXN];
vector<int>g[MAXN];
vector<int>order,order1;
int par[MAXN];
bool vis[MAXN];
void dfs_order(int u,int p,int N)
{
	par[u]=p;vis[u]=1;
	order.push_back(u);
	order1.push_back(u);
	for(auto xd:g[u])
	{
		if(vis[xd])continue;
		dfs_order(xd,u,N);
		order.push_back(u);
	}
}
void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
	for(int i=1;i<N;i++)
	{
		g[A[i]].push_back(B[i]);
		g[B[i]].push_back(A[i]);
	}
	memset(vis,0,sizeof(vis));
	dfs_order(1,0,N);
	setHintLen(30);
	for(int i=2;i<=N;i++)
	{
		for(int j=0;j<10;j++)
		{
			if(par[i]&(1<<j))
			{
				setHint(i,j+1,1);
			}
		}
	}
	for(int i=0;i<order1.size();i++)
	{
		int k1,k2;
		if(i*2<order.size())k1=order[i*2];
		if(i*2+1<order.size())k2=order[i*2+1];
		for(int j=0;j<10;j++)
		{
			if(k1&(1<<j))
			{
				setHint(order1[i],j+11,1);
			}
			if(k2&(1<<j))
			{
				setHint(order1[i],j+21,1);
			}
		}
	}
}
bool vis1[MAXN];
void dfs(int u,int p,int N)
{
	vis1[u]=1;
	int t=0;
	for(int j=0;j<10;j++)
	{
		if(getHint(j+1)==1)
		{
			t=t+(1<<j);
		}
	}
	if(t!=0)g[u].push_back(t);
	t=0;
	for(int j=0;j<10;j++)
	{
		if(getHint(j+11)==1)
		{
			t=t+(1<<j);
		}
	}
	if(t!=0)g[u].push_back(t);
	for(auto i:g[u])
	{
		if(vis1[i])continue;
		goTo(i);
		dfs(i,u,N);
	}
	if(p==-1)return;
	goTo(p);
	
}
int ptr=0;
vector<int>order2;
bool vis2[MAXN];
set<int>s;
void dfs_from_1(int u,int p,int N)
{
	s.insert(u);
	if(s.size()>=N)return;
	//cerr<<u<<endl;
	if(vis2[u]==0)
	{
		int t=0;
		for(int j=0;j<10;j++)
		{
			if(getHint(j+11))t+=(1<<j);
		}
		if(t>0&&t<=N)order2.push_back(t);
		t=0;
		for(int j=0;j<10;j++)
		{
			if(getHint(j+21))t+=(1<<j);
		}
		if(t>0&&t<=N)order2.push_back(t);
	}
	vis2[u]=1;
	goTo(order2[++ptr]);
	dfs_from_1(order2[ptr],u,N);
}
void speedrun(int subtask, int N, int start) { /* your solution here */
	while(start!=1)
	{
		int p=0;
		for(int j=0;j<10;j++)
		{
			if(getHint(j+1))p+=(1<<j);
		}
		goTo(p);
		start=p;
	}
	//cerr<<"eho\n";
	dfs_from_1(start,0,N);
	return;
}
