/**
* user:  mihov-f9a
* fname: Boris Vladimirov
* lname: Mihov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 08:54:37.616484
*/
// Da-i, d-d-d-da-i, sistemul turbat, ala turbat, cel mai turbat

#include <iostream>
using namespace std;
const int maxn = 7, maxm = 2e5+10;

int t[maxn][maxn];
bool dp[maxn][maxm][maxn];
bool bl[maxn][maxm][maxn];

int f(int n, int m, int k) {

    if (n+m == 0 && k == 0) return 1;
    if (n+m == 0 && k > 0) return 0;
    if (n+m > 0 && min(n, m) == 0 || k < 0) return 0;
    if (bl[n][m][k]) return dp[n][m][k];
    
    bl[n][m][k] = 1;
    return dp[n][m][k] = (f(n-2, m-2, k-1) || f(n-2, m, k - (m/2)) || f(n, m-2, k - (n/2)));

}

int n, m, k;
void reset() {

    for (int i = 1 ; i <= n ; ++i)
        for (int j = 1 ; j <= m ; ++j)
            for (int x = 1 ; x <= k ; ++x)
                bl[i][j][x] = 0;

}

int startX, startY;
int endX, endY;
int cnt;

void fill_left() {

    for (int i = 0 ; i < (endX-startX+1)/2 ; ++i) {

        ++cnt;
        t[startX + 2*i][startY] = cnt;
        t[startX + 2*i][startY + 1] = cnt;
        t[startX + 2*i + 1][startY] = cnt;
        t[startX + 2*i + 1][startY + 1] = cnt;

    }

    startY += 2;

}

void fill_top() {
    
    for (int i = 0 ; i < (endY-startY+1)/2 ; ++i) {

        ++cnt;
        t[startX][startY + 2*i] = cnt;
        t[startX][startY + 2*i + 1] = cnt;
        t[startX + 1][startY + 2*i] = cnt;
        t[startX + 1][startY + 2*i + 1] = cnt;

    }

    startX += 2;

}

void fill_all() {
    
    ++cnt;
    for (int i = startX ; i <= endX ; ++i)
        t[i][startY] = t[i][endY] = cnt;

    for (int i = startY ; i <= endY ; ++i)
        t[startX][i] = t[endX][i] = cnt;

    ++startX;
    ++startY;
    --endX;
    --endY;

}


void solve() {

    cin >> n >> m >> k;
    if (f(n, m, k) == 0) {

        cout << "NO\n";
        return;

    }
    
    cout << "YES\n";

    int ncpy = n;
    int mcpy = m;
    startX = startY = 1;
    endX = n;
    endY = m;
    cnt = 0;

    while (n > 0 && m > 0) {

        if (f(n-2, m-2, k-1)) {

            fill_all();
            n -= 2;
            m -= 2;
            --k;
            continue;

        }

        if (f(n-2, m, k - (m/2))) {
            
            fill_top();
            n -= 2;
            k -= (m/2);
            continue;

        }

        if (f(n, m-2, k - (n/2))) {

            fill_left();
            m -= 2;
            k -= (n/2);
            continue;

        }

    }

    for (int i = 1 ; i <= ncpy ; ++i, cout << '\n')
        for (int j = 1 ; j <= mcpy ; ++j)
            cout << t[i][j] << ' ';

}

void fast_io() {

    ios_base :: sync_with_stdio(0);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cerr.tie(nullptr);

}

int main () {

    fast_io();

    int t;
    cin >> t;

    while (t--) {

        reset();
        solve();

    }

    return 0;

}