/**
* user:  mihov-0af
* fname: Petar Velislavov
* lname: Mihov
* task:  Gardening
* score: 5.0
* date:  2021-12-16 09:41:18.825736
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long t;
    cin>>t;
    for (int q12=0;q12<t;q12++)
    {
        long long n,m,k;
        cin>>n>>m>>k;
        if (n>6) break;
        if (n%2!=0 || m%2!=0) {cout<<"NO\n";continue;}
        if (n==2 && m==2)
        {
            if (k!=1) cout<<"NO\n";
            else
            {
                cout<<"YES\n1 1\n1 1\n";
            }
        }
        if (n==4 && m==4)
        {
            if (k==2)
            {
                cout<<"YES\n1 1 1 1\n1 2 2 1\n1 2 2 1\n1 1 1 1\n";
            }
            else
            {
                if (k==4)
                {
                    cout<<"YES\n1 1 2 2\n1 1 2 2\n3 3 4 4\n3 3 4 4\n";
                }
                else cout<<"NO\n";
            }
        }
        if (n==4 && m==2)
        {
            if (k!=2) cout<<"NO\n";
            else
            {
                cout<<"YES\n1 1\n1 1\n2 2\n2 2\n";
            }
        }
        if (n==2 && m==4)
        {
            if (k!=2) cout<<"NO\n";
            else cout<<"YES\n1 1 2 2\n1 1 2 2\n";
        }
    }
}
