/**
* user:  negoescu-c8b
* fname: Divia Petra
* lname: Negoescu
* task:  Gardening
* score: 0.0
* date:  2021-12-16 08:21:02.980338
*/
#include <iostream>
using namespace std;
//ifstream cin("a.in");
//ofstream cout("a.out");
int n,m,k,i,t,j;
int main(){
    cin>>t;
    for(;t--;){
        cin>>n>>m>>k;
        if(n==1 || m==1)cout<<"NO\n";
        else if(n==2){
            if(k*2<=m){
                cout<<"YES\n";
                for(i=1;i<=k;i++)
                    cout<<i<<" "<<i<<" ";
                for(i=2*k+1;i<=m;i++)
                    cout<<k<<" ";
                cout<<"\n";
                for(i=1;i<=k;i++)
                    cout<<i<<" "<<i<<" ";
                for(i=2*k+1;i<=m;i++)
                    cout<<k<<" ";
                cout<<"\n";
            }
            else cout<<"NO\n";
        }
        else if(m==2){
            if(k*2<=n){
                cout<<"YES\n";
                for(i=1;i<=k;i++)
                    cout<<i<<" "<<i<<"\n"<<i<<" "<<i<<"\n";
                for(i=2*k+1;i<=n;i++)
                    cout<<k<<" "<<k<<"\n";
            }
            else cout<<"NO\n";
        }
        else if(n==3){
            if(k*2<=m){
                cout<<"YES\n";
                for(i=1;i<=k;i++)
                    cout<<i<<" "<<i<<" ";
                for(i=2*k+1;i<=m;i++)
                    cout<<k<<" ";
                cout<<"\n";

                for(i=1;i<=k;i++)
                    cout<<i<<" "<<i<<" ";
                for(i=2*k+1;i<=m;i++)
                    cout<<k<<" ";
                cout<<"\n";

                for(i=1;i<=k;i++)
                    cout<<i<<" "<<i<<" ";
                for(i=2*k+1;i<=m;i++)
                    cout<<k<<" ";
                cout<<"\n";
            }
            else cout<<"NO\n";
        }
        else if(m==3){
            if(k*2<=n){
                cout<<"YES\n";
                for(i=1;i<=k;i++)
                    cout<<i<<" "<<i<<" "<<i<<"\n"<<i<<" "<<i<<" "<<i<<"\n";
                for(i=2*k+1;i<=n;i++)
                    cout<<k<<" "<<k<<" "<<k<<"\n";
            }
            else cout<<"NO\n";
        }
        else if(n==4){
            int kaux=k/2+k%2;
            if(2*kaux<=m){
                cout<<"YES\n";
                for(i=1;i<=kaux;i++)
                    cout<<i<<" "<<i<<" ";
                for(i=2*kaux+1;i<=m;i++)
                    cout<<kaux<<" ";
                cout<<"\n";

                for(i=1;i<=kaux;i++)
                    cout<<i<<" "<<i<<" ";
                for(i=2*kaux+1;i<=m;i++)
                    cout<<kaux<<" ";
                cout<<"\n";

                for(i=1,j=kaux+1;i<=kaux-k%2;i++,j++)
                    cout<<j<<" "<<j<<" ";
                for(i=(kaux-k%2)*2+1; i<=m;i++)
                    cout<<k<<" ";
                cout<<"\n";

                for(i=1,j=kaux+1;i<=kaux-k%2;i++,j++)
                    cout<<j<<" "<<j<<" ";
                for(i=(kaux-k%2)*2+1; i<=m;i++)
                    cout<<k<<" ";
                cout<<"\n";
            }
            else cout<<"NO\n";

        }
        else if(m==4){
            int kaux=k/2+k%2;
            if(2*kaux<=n){
                cout<<"YES\n";
                for(i=1,j=1;i<=k/2;i++,j+=2){
                    cout<<j<<" "<<j<<" "<<j+1<<" "<<j+1<<"\n";
                    cout<<j<<" "<<j<<" "<<j+1<<" "<<j+1<<"\n";
                }
                if(k%2==1){
                    for(i=2*(k/2);i<=n;i++)
                        cout<<k<<" "<<k<<" "<<k<<" "<<k<<"\n";
                }
                else{
                    for(i=2*(k/2);i<=n;i++)
                        cout<<k-1<<" "<<k-1<<" "<<k<<" "<<k<<"\n";
                }
            }
            else cout<<"NO\n";

        }
       /* else if(n==5){

        }
        else if(n==6){


        }*/
    }
    return 0;
}
