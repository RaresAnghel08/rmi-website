/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 08:26:18.709595
*/
#include "speedrun.h"
#include <bits/stdc++.h>
//#include "grader.cpp"
void assignHints(int subtask, int N, int A[], int B[])
{
    setHintLen(N);
    for(int i=1;i<N;i++)
    {
        setHint(A[i],B[i],1);
        setHint(B[i],A[i],1);
    }
}
bool use[1005];
void dfs(int nod,int par,int N)
{
    for(int i=1;i<=N;i++)
        if(getHint(i)==1&&i!=par)
        {
            goTo(i);
            dfs(i,nod,N);
        }
    if(par!=0)
        goTo(par);
}
void speedrun(int subtask, int N, int start)
{
    int l=getLength();
    dfs(start,0,N);

}
