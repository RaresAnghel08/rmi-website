/**
* user:  hecht-9cd
* fname: Yahli
* lname: Hecht
* task:  Speedrun
* score: 19.0
* date:  2021-12-16 07:56:21.996821
*/
#include "speedrun.h"
#include <vector>

using namespace std; 
using pi = pair<int, int>; 

void set_hint_st(int i, int st, int val){
    for (int j = 0; j < 10; ++j){
        setHint(i, st+j, (val >> j)%2); 
    }
}


void assignHints(int subtask, int N, int A[], int B[]) {
    vector<vector<int>> adj(N+1, vector<int>()); 
    for (int i = 1; i < N; ++i){
        adj[A[i]].push_back(B[i]); 
        adj[B[i]].push_back(A[i]); 
    }
    setHintLen(20); 
    for (int i = 1; i <= N; ++i){
        set_hint_st(i, 1, adj[i][0]); 
        if (adj[i].size() > 1) set_hint_st(i, 11,adj[i][1]);
    }
}


pi get_hint(){
    pi hint(0, 0); 
    for (int i = 0; i < 10; ++i){
        hint.first += (1 << i) * getHint(i + 1);
        hint.second += (1 << i) * getHint(i + 11); 
    }
    return hint; 
}

void speedrun(int subtask, int N, int start) { 
    int l = getLength(); 
    pi hint = get_hint(); 
    int lst = hint.first, now = start; 

    for (int t = 0; t < 2; ++t){
        while (hint.second){ 
            if (hint.first != lst) lst = now, now = hint.first; 
            else lst = now, now = hint.second;
            goTo(now);  
            hint = get_hint();
        } 
        swap(now, lst);
        goTo(now);
        hint = get_hint(); 
    }
}
