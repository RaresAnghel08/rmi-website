/**
* user:  dimitrova-b08
* fname: Niya Radoslavova
* lname: Dimitrova
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 11:47:02.947206
*/
#include<bits/stdc++.h>
#include "speedrun.h"
using namespace std;
vector<int>v[100000];
int n;
void fill_hint(int x, int y , int l, int r)
{
    int t = r;
    while( y != 0 )
    {
        int ost = y % 2;
        y /= 2;
        if( ost == 1 ) setHint(x,t,1);
        t += 1;
    }
}
void make_hint(int x)
{
   int sz = v[x].size();
   int l = 1;
   for(int i=0;i<sz;i++)
   {
       int nb = v[x][i];
       fill_hint(x,nb,l,l+10-1);
       l +=10;
   }
}
void assignHints(int subtask, int N, int A[], int B[])
{
    n = N;
    setHintLen(20);
    for(int i=1;i<n;i++)
    {
        int x = A[i];
        int y = B[i];
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        make_hint(i);
    }
}
int pw[1024];
vector<int>v1[100000];
int get_to(int l, int r)
{
    int t = 0;
    int cnt = 9;
    for(int i=l;i<=r;i++)
    {
        bool tb = getHint(i);
        t += ( pw[cnt] * tb);
    }
    return t;
}
int used[100000];
void dfs(int w, int prev )
{
    used[w] = 1;
    int l1 = get_to(1,10);
    int l2 = get_to(11,20);
    if( used[l1] == 0 )
    {
        int lamp1 = goTo(l1);
    }
    if( used[l2] == 0 )
    {
        int lamp1 = goTo(l2);;
    }
    if( w != prev )
    {
        int lamp2 = goTo(prev);
    }
}
void speedrun(int subtask, int N, int start)
{
    pw[0] = 1;
    for(int i=1;i<=11;i++) pw[i] = pw[i-1] * 2;
    dfs(start,start);
}
