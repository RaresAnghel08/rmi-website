/**
* user:  saprykin-5aa
* fname: Maxim
* lname: Saprykin
* task:  Speedrun
* score: 21.0
* date:  2021-12-16 09:11:31.048107
*/
#include "speedrun.h"
#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
//#define int ll
typedef pair<int, int> pii;
#define all(a) a.begin(), a.end()
#define _ << ' ' <<
#define vec vector

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
    int n = N;
    if (subtask == 1) {

        int n = N;
        vec<vec<int>> g(n);
        setHintLen(n);
        for (int i = 1; i < n; ++i) {
            setHint(A[i], B[i], 1);
            setHint(B[i], A[i], 1);
        }
        return;
    }
    if (subtask == 2) {
        setHintLen(20);
        set<int> st;
        for (int k = 1; k < n; ++k) {
            int x;
            x = A[k];
            if (st.count(x)) {
                for (int i = 1; i <= n; ++i) {
                    for (int j = 1; j <= 20; ++j) {
                        setHint(i, j, x & (1 << (j - 1)));
                    }
                }
                return;
            }
            st.insert(x);
            x = B[k];

            if (st.count(x)) {
                for (int i = 1; i <= n; ++i) {
                    for (int j = 0; j < 20; ++j) {
                        setHint(i, j, x & (1 << j));
                    }
                }
                return;
            }
            st.insert(B[k]);
        }
    }
}
const int MAXN = 2e3;
int n;
void dfs(int v, int p) {
    for (int i = 1; i <= n; ++i) {
        if (i == p) continue;
        if (getHint(i)) {
            goTo(i);
            dfs(i, v);
        }
    }
    if (p != -1) {
        goTo(p);
    }
}
void speedrun(int subtask, int N, int start) { /* your solution here */
    n = N;
    if (subtask == 1) {
        int l = getLength();
        n = N;
        dfs(start, -1);
        return;
    }
    if (subtask == 2) {
        int x = 0;
        for (int i = 1; i <= 20; ++i) {
            x |= (getHint(i) << (i - 1));
        }
        goTo(x);
        for (int i = 1; i <= n; ++i) {
            if (i == start || i == x) continue;
            goTo(i);
            goTo(x);
        }
    }
}
