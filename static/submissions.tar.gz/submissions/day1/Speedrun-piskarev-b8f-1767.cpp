/**
* user:  piskarev-b8f
* fname: Ivan
* lname: Piskarev
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 08:25:58.821353
*/
#include "speedrun.h"

#include <bits/stdc++.h>

void setHintVal(int i, int j, int val) {
    for (int k = 0; k < 10; k++) {
        setHint(i + 1, j * 10 + k, (val >> k) & 1);
    }
}

int getHintVal(int j) {
    int res = 0;
    for (int k = 0; k < 10; k++) {
        if (getHint(j * 10 + k)) {
            res |= 1 << k;
        }
    }
    return res;
}

std::vector<std::vector<int>> gr;
std::vector<int> tin, prv, eul;

void dfs(int v, int f) {
    prv[v] = f;
    tin[v] = eul.size();
    eul.push_back(v);
    for (int t : gr[v]) {
        if (t != f) {
            dfs(t, v);
        }
    }
}

void assignHints(int subtask, int n, int A[], int B[]) {
    gr.assign(n, {});
    for (int i = 1; i < n; i++) {
        A[i]--;
        B[i]--;
        gr[A[i]].push_back(B[i]);
        gr[B[i]].push_back(A[i]);
    }

    prv.assign(n, -1);
    tin.assign(n, -1);
    dfs(0, -1);

    setHintLen(20);
    for (int i = 0; i < n; i++) {
        setHintVal(i, 0, prv[i]);
        setHintVal(i, 1, eul[(tin[i] + 1) % eul.size()]);
    }
}

void speedrun(int subtask, int n, int start) {
    start--;
    int v = start;
    while (getHintVal(1) != start) {
        int nd = getHintVal(1);
        while (!goTo(nd + 1)) {
            v = getHintVal(0);
            bool b = goTo(getHintVal(0) + 1);
            assert(b);
        }
        v = nd;
    }
}
