/**
* user:  piskarev-b8f
* fname: Ivan
* lname: Piskarev
* task:  Gardening
* score: 5.0
* date:  2021-12-16 11:57:44.887459
*/
#include <bits/stdc++.h>

bool getAns(int n, int m, int k) {
    if (n % 2 || m % 2) {
        return false;
    }
    if (n > m) {
        std::swap(n, m);
    }
    if (n == 2 && m == 2) {
        return k == 1;
    } else if ((n == 2 && m == 4)) {
        return k == 2;
    } else if (n == 4 && m == 4) {
        return k == 2 || k == 4;
    } else {
        assert(false);
    }
}

std::vector<std::vector<int>> fuckAns(int n, int m, int k) {
    bool rev = false;
    if (n % 2 || m % 2) {
        assert(false);
    }

    if (n > m) {
        std::swap(n, m);
        rev = true;
    }

    std::vector<std::vector<int>> res;
    if (n == 2 && m == 2) {
        res = {{0, 0}, {0, 0}};
    } else if ((n == 2 && m == 4)) {
        res = {{0, 0, 1, 1},
               {0, 0, 1, 1}};
    } else if (n == 4 && m == 4) {
        if (k == 2) {
            res = {{0, 0, 0, 0},
                   {0, 1, 1, 0},
                   {0, 1, 1, 0},
                   {0, 0, 0, 0}};
        } else {
            res = {{0, 0, 1, 1},
                   {0, 0, 1, 1},
                   {3, 3, 2, 2},
                   {3, 3, 2, 2}};
        }
    } else {
        assert(false);
    }
    if (rev) {
        std::vector<std::vector<int>> res2(m, std::vector<int>(n));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                res2[j][i] = res[i][j];
            }
        }
        res = res2;
    }
    return res;
}

void solve() {
    int n, m, k;
    std::cin >> n >> m >> k;

    if (!getAns(n, m, k)) {
        std::cout << "NO\n";
        return;
    }

    std::cout << "YES\n";
    auto ans = fuckAns(n, m, k);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            std::cout << ans[i][j] + 1 << " \n"[j == m - 1];
        }
    }
}

int32_t main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int t;
    std::cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}
