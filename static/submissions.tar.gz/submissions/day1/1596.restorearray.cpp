/**
* user:  apostol-c2d
* fname: Daniel
* lname: Apostol
* task:  restore
* score: 38.0
* date:  2019-10-10 07:13:31.958600
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define pb push_back
#define get_here cerr << "-1\n"
#define dbg(x) cerr << #x << " " << x << "\n"

int n, m;
const int N = 5000, M = 1e4;
int ans[1 + N];
int k[1 + M];
int val[1 + M];
int l[1 + M];
int r[1 + M];
int car[2];
void fail () {
    cout << "-1\n";
    exit (0);
}

void solve_brut () {
    for (int mask = 0; mask < (1 << n); mask++) {
        for (int i = 0; i < n; i++)
            ans[i + 1] = bool (mask & (1 << i));
        bool ok = true;
        for (int i = 1; i <= m; i++) {
            car[0] = car[1] = 0;
            for (int j = l[i]; j <= r[i]; j++)
                car[ans[i]]++;
            if (val[i] == 0 && k[i] <= car[0])
                ;
            else if (val[i] == 1 && k[i] > car[0])
                ;
            else {
                ok = false;
                break;
            }
        }
        if (ok) {
            for (int i = 1; i <= n; i++)
                cout << ans[i] << " ";
            cout << "\n";
            exit (0);
        }
    }
    cout << "-1\n";
    exit (0);
}


int main () {
   // freopen ("restore.in", "r", stdin);
    //freopen ("restore.out", "w", stdout);

    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);

    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        ans[i] = -1;
    for (int i = 1; i <= m; i++) {
        cin >> l[i] >> r[i] >> k[i] >> val[i];
        l[i]++;
        r[i]++;
    }
    if (n <= 18) {
        solve_brut ();
        return 0;
    }
    for (int i = 1; i <= m; i++) {
        if (val[i] == 1 && k[i] == 1) {
            for (int j = l[i]; j <= r[i]; j++) {
                if (ans[j] == 0)
                    fail ();
                ans[j] = 1;
            }
        }
        if (val[i] == 0 && k[i] == r[i] - l[i] + 1) {
            for (int j = l[i]; j <= r[i]; j++) {
                if (ans[j] == 1)
                    fail ();
                ans[j] = 0;
            }
        }
    }

    for (int i = 1; i <= m; i++) {
        if (val[i] == 0 && k[i] == 1) {
            bool ok = false;
            for (int j = l[i]; j <= r[i]; j++)
                if (ans[j] != 1) {
                    ok = true;
                    ans[j] = 0;
                    break;
                }
            if (!ok) {
                fail ();
            }
        }
        if (val[i] == 1 && k[i] == r[i] - l[i] + 1) {
            bool ok = false;
            for (int j = l[i]; j <= r[i]; j++)
                if (ans[j] != 0) {
                    ok = true;
                    ans[j] = 1;
                    break;
                }
            if (!ok) {
                fail ();
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        if (ans[i] == -1)
            ans[i] = 0;
        cout << ans[i] << " ";
    }
    return 0;
}
