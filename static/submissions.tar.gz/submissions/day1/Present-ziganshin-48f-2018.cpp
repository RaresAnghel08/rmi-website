/**
* user:  ziganshin-48f
* fname: Emir Ramilevich
* lname: Ziganshin
* task:  Present
* score: 8.0
* date:  2021-12-16 08:50:54.797112
*/
#include <bits/stdc++.h>

using namespace std;

void solve();

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    solve();
}

#define int long long

const int K = 60;

bool bit(int a, int n) {
    return (a >> n) & 1;
}

int gcd(int a, int b) {
    if (a == 0) return b;
    return gcd(b % a, a);
}

bool good(int mask) {
    vector<int> v;
    for (int i = 0; i < K; i++) {
        if (bit(mask, i)) {
            v.push_back(i + 1);
        }
    }
    for (int i = 0; i < v.size(); i++) {
        for (int j = i + 1; j < v.size(); j++) {
            if (!bit(mask, gcd(v[i], v[j]) - 1)) {
                return false;
            }
        }
    }
    return true;
}

int t, k;

void solve() {
    cin >> t;
    while (t--) {
        cin >> k;
        int mask = 0;
        while (k > 0) {
            mask++;
            if (good(mask)) {
                k--;
            }
        }
        vector<int> ans;
        for (int i = 0; i < K; i++) {
            if (bit(mask, i)) {
                ans.push_back(i + 1);
            }
        }
        cout << ans.size() << " ";
        for (int val : ans) {
            cout << val << " ";
        }
        cout << '\n';
    }
}
