/**
* user:  ljaskovskij-412
* fname: Alexander
* lname: Ljaskovskij
* task:  Gardening
* score: 11.0
* date:  2021-12-16 10:12:46.997873
*/
#include<bits/stdc++.h>

using namespace std;

//#define int ll

typedef long long ll;
typedef long double ld;

void solve() {
    /*
    int n, m, k;
    cin >> n >> m >> k;
    if (n % 2 == 1 || m % 2 == 1) {
        cout << "NO\n";
        return;
    }
    if (n * m / 4 - 1 == k) {
        cout << "NO\n";
        return;
    }
    */
    int n, m, k;
    cin >> n >> m >> k;
    if (n % 2 == 1 || m % 2 == 1) {
        cout << "NO\n";
        return;
    }
    if (n == 4) {
        if (n * m / 4 == k) {
            cout << "YES\n";
            int ans[n][m];
            int cnt = 1;
            for (int i = 0; i + 1 < n; i += 2) {
                for (int j = 0; j + 1 < m; j += 2) {
                    ans[i][j] = cnt;
                    ans[i + 1][j] = cnt;
                    ans[i][j + 1] = cnt;
                    ans[i + 1][j + 1] = cnt;
                    ++cnt;
                }
            }
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << ans[i][j] << " ";
                }
                cout << "\n";
            }
        }
        else if (m / 2 <= k && k <= n * m / 4 - 2) {
            cout << "YES\n";
            int rig = 2 * k - m;
            int cnt = 1;
            int ans[n][m];
            for (int i = 0; i + 1 < n; i += 2) {
                for (int j = 0; j + 1 < rig; j += 2) {
                    ans[i][j] = cnt;
                    ans[i + 1][j] = cnt;
                    ans[i][j + 1] = cnt;
                    ans[i + 1][j + 1] = cnt;
                    ++cnt;
                }
            }
            /*
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << ans[i][j] << " ";
                }
                cout << "\n";
            }
            cout << "** " << cnt << " " << rig << endl;
            */
            for (int j = rig + 1; j + 1 < m; j += 2) {
                ans[1][j] = cnt;
                ans[2][j] = cnt;
                ans[1][j + 1] = cnt;
                ans[2][j + 1] = cnt;
                ++cnt;
            }
            for (int i = 0; i < n; ++i) {
                ans[i][rig] = cnt;
                ans[i][m - 1] = cnt;
            }
            for (int j = rig; j < m; ++j) {
                ans[0][j] = cnt;
                ans[n - 1][j] = cnt;
            }
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << ans[i][j] << " ";
                }
                cout << "\n";
            }
        }
        else {
            cout << "NO\n";
        }
    }
    else if (n == 2) {
        if (m / 2 == k) {
            cout << "YES\n";
            int ans[n][m];
            int cnt = 1;
            for (int i = 0; i + 1 < n; i += 2) {
                for (int j = 0; j + 1 < m; j += 2) {
                    ans[i][j] = cnt;
                    ans[i + 1][j] = cnt;
                    ans[i][j + 1] = cnt;
                    ans[i + 1][j + 1] = cnt;
                    ++cnt;
                }
            }
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < m; ++j) {
                    cout << ans[i][j] << " ";
                }
                cout << "\n";
            }
        }
        else {
            cout << "NO\n";
        }
    }
    else {
        return;
    }
    return;
}

/*
1
4 8 5
*/

int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int tests = 1;
    cin >> tests;
    while(tests--) {
        solve();
    }
}
