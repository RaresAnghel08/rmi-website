/**
* user:  myskiv-a26
* fname: Vladyslav
* lname: Myskiv
* task:  Speedrun
* score: 0.0
* date:  2021-12-16 09:24:36.532101
*/
#include "speedrun.h"

#include <bits/stdc++.h>

string get_s(int v){
    string s="";
    while(v>0){
        char c=v%2+'0';
        v/=2;
        s+=c;
    }
    while(s.length()!=9) s+='0';
    return s;
}

void assignHints(int subtask, int N, int A[], int B[]){
    int vec[N+1];
    if(subtask>=0){
        for(int i=1; i<=N; i++){
            vec[A[i]]++;
            vec[B[i]]++;
        }
        int top=0;
        for(int i=1; i<=N; i++){
            if(vec[i]>1){
                top=i;
                break;
            }
        }
        setHintLen(9);
        string s=get_s(top);
        for(int i=1; i<=N; i++){
            for(int j=0; j<9; j++) setHint(i, j, s[j]-'0');
        }
    }
    return;
}

int get_num(string s){
    int it=1;
    int num=0;
    for(int i=0; i<s.length(); i++){
        if(s[i]=='1') num+=it;
        it*=2;
    }
    return num;
}

void speedrun(int subtask, int N, int start) {
    if(subtask>=0){
        int num=0;
        int len=getLength();
        string s="";
        for(int i=1; i<=len; i++){
            if(getHint(i)) s+='1';
            else s+='0';
        }
        num=get_num(s);
        goTo(num);
        for(int i=1; i<=N; i++){
            goTo(i);
            goTo(num);
        }
        return;
    }
    return;
}
