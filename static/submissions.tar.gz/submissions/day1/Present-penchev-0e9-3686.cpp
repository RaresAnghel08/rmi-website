/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  Present
* score: 0.0
* date:  2021-12-16 11:28:03.706207
*/
#include <algorithm>
#include <iostream>
#include <vector>
#define endl '\n'
using namespace std;

int a[50];

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    vector< vector<int> > v;

    v.push_back({});

    for (int m = 1; m <= 30; ++ m)
    {
        int sz = v.size();
        for (int i = 0; i < sz; ++ i)
        {
            for (int j = 1; j <= 40; ++ j)
            {
                a[j] = 0;
            }

            bool flag = true;
            for (int j = 0; j < v[i].size(); ++ j)
            {
                a[v[i][j]] = 1;
                if (!a[__gcd(v[i][j], m)])
                {
                    flag = false;
                    break;
                }
            }

            if (flag)
            {
                vector<int> x = v[i];
                x.push_back(m);
                v.push_back(x);
            }
        }
    }

    //cout << v.size() << endl;

    /*for (int i = 0; i < v.size(); ++ i)
    {
        cout << v[i].size() << " ";
        for (int j = 0; j < v[i].size(); ++ j)
        {
            cout << v[i][j] << " ";
        }
        cout << endl;
    }*/

    int t;
    cin >> t;

    while (t--)
    {
        int k;
        cin >> k;

        cout << v[k].size() << " ";
        for (int i = 0; i < v[k].size(); ++ i)
        {
            cout << v[k][i] << " ";
        }
        cout << endl;
    }

    return 0;
}
