/**
* user:  hadzhi-manich-e4f
* fname: Deyan Deyanov
* lname: Hadzhi-Manich
* task:  Gardening
* score: 0.0
* date:  2021-12-16 11:28:39.379863
*/
#include<bits/stdc++.h>
using namespace std;
int n,m,k;
bool cmp(pair<int,int> p1,pair<int,int> p2)
{
		return min(min(p1.first-1,p1.second-1),min(n-p1.first,m-p1.second)) < min(min(p2.first-1,p2.second-1),min(n-p2.first,m-p2.second));
}
int t[8][8];
void solve()
{
	cin>>n>>m>>k;
	if(n==1)
	{
		cout<<"NO\n";
		return;
	}
	if(m==1)
	{
		cout<<"NO\n";
		return;
	}
	if(n==4&&m==4)
	{
		if(k>5)
		{
			cout<<"NO\n";
			return;
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				t[i][j]=1;
			}
		}
		vector<pair<int,int> >v;
		v.push_back({2,2});
		v.push_back({2,3});
		v.push_back({3,2});
		v.push_back({3,3});
		for(int j=0;j<k-1;j++)
		{
			t[v[j].first][v[j].second]=j+2;
		}
		cout<<"YES\n";
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cout<<t[i][j]<<" ";
			}
			cout<<endl;
		}
		return;
	}
	if(n==4&&m==3)
	{
		if(k>3)
		{
			cout<<"NO\n";
			return;
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				t[i][j]=1;
			}
		}
		vector<pair<int,int> >v;
		v.push_back({2,2});
		v.push_back({3,2});
		for(int j=0;j<k-1;j++)
		{
			t[v[j].first][v[j].second]=j+2;
		}
		cout<<"YES\n";
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cout<<t[i][j]<<" ";
			}
			cout<<endl;
		}
		return;
	}
	
	
	if(n==3&&m==4)
	{
		if(k>3)
		{
			cout<<"NO\n";
			return;
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				t[i][j]=1;
			}
		}
		vector<pair<int,int> >v;
		v.push_back({2,2});
		v.push_back({2,3});
		for(int j=0;j<k-1;j++)
		{
			t[v[j].first][v[j].second]=j+2;
		}
		cout<<"YES\n";
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cout<<t[i][j]<<" ";
			}
			cout<<endl;
		}
		return;
	}
	if(k==1)
	{
		cout<<"YES\n";
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				cout<<"1 ";
			}
			cout<<endl;
		}
		return;
	}
	if(n==3&&m==3&&k==2)
	{
		cout<<"YES\n";
		cout<<"1 1 1\n";
		cout<<"1 2 1\n";
		cout<<"1 1 1\n";
		return;
	}
	if(n==2&&m==4&&k==2)
	{
		cout<<"YES\n";
		cout<<"1 1 2 2\n";
		cout<<"1 1 2 2\n";
		return;
	}
	if(n==4&&m==2&&k==2)
	{
		cout<<"YES\n";
		cout<<"1 1\n";
		cout<<"1 1\n";
		cout<<"2 2\n";
		cout<<"2 2\n";
		return;
	}
	cout<<"NO\n";
	return;
}
int main()
{
	/*ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);*/
	int t;
	cin>>t;
	while(t--)solve();
return 0;
}
