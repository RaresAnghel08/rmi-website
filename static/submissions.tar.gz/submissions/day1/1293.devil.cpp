/**
* user:  frolov-001
* fname: Konstantin
* lname: Frolov
* task:  devil
* score: 0.0
* date:  2019-10-10 06:09:39.591410
*/
#include <bits/stdc++.h>
#define FOR(i, n) for (int i = 0; i < n; ++i)
#define debug(x) std::cout << #x << ": " << x << '\n';
#define pb push_back
typedef long long ll;
const int N = 1e5;
struct seg_tree
{
	int tree[4 * N], push[4 * N];
	seg_tree() {
		memset(tree, 0, sizeof(tree));
	}
	void doPush(int v, int tl, int tr) {
		tree[v] += push[v] * (tr - tl + 1);
		if (2 * v < 4 * N) {
			push[2 * v] += push[v];
			push[2 * v + 1] += push[v];
		}
		push[v] = 0;
	}
	void upd(int v, int tl, int tr, int i, int x) {
		if (tl == tr) {
			tree[v] = x;
			return;
		}
		int tm = (tl + tr) / 2;
		if (tm >= i) {
			upd(v * 2, tl, tm, i, x);
		}
		else {
			upd(v * 2 + 1, tm + 1, tr, i, x);
		}
		tree[v] = tree[v * 2] + tree[v * 2 + 1];
	}
	int get(int v, int tl, int tr, int l, int r) {
		if (l > r) return 0;
		if (tl == l && tr == r) {
			return tree[v];
		}
		int tm = (tl + tr) / 2;
		return get(v * 2, tl, tm, l, std::min(r, tm)) + get(v * 2 + 1, tm + 1, tr, std::max(tm + 1, l), r);
	}
};
bool check(int x, std::vector<int> a, int k, int sz, bool pr = false) {
	std::vector<int> answ(sz);
	int curSum = 0;
	for (int j = 0; j < k; ++j) {
		for (int q = 8; q >= 0; --q) {
			if (!a[q]) continue;
			int checkPossible = (x - curSum - (q + 1));
			int lastK = (k - j - 1), canGet = 0;
			a[q]--;
			for (int i = 0; i < 9; ++i) {
				if (lastK >= a[i]) {
					lastK -= a[i];
					canGet += a[i] * (i + 1);
				}
				else {
					canGet += lastK * (i + 1);
					break;
				}
			}
			// debug(j << ' ' << q << ' ' << checkPossible << ' ' << canGet)
			if (canGet > checkPossible) {
				a[q]++;
			}
			else {
				curSum += q + 1;
				answ[j] = q + 1;
				break;
			}
		}
	}
	// for (auto e : answ) {
	// 	std::cout << e << ' ';
	// }
	// debug(curSum)
	for (int j = k; j < sz; ++j) {
		curSum -= answ[j - k];
		bool fl = false;
		for (int i = 8; i >= 0; --i) {
			if (curSum + i + 1 <= x && a[i]) {
				answ[j] = i + 1;
				curSum += i + 1;
				fl = true;
				--a[i];
				break;
			}
		}
		if (!fl) return false;
	}
	curSum = 0;
	FOR(j, k) curSum += answ[j];
	if (curSum > x) return false;
	// for (auto e : answ) std::cout << e;
	for (int j = k; j < sz; ++j) {
		curSum = curSum - answ[j - k] + answ[j];
		// debug(j << ' ' << curSum)
		if (curSum > x) return false;
	}
	if (pr) {
		for (auto e : answ) {
			std::cout << e;
		}
		return true;
	}
	return curSum <= x;
}
int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(0); std::cout.tie(0);
	int t;
	std::cin >> t;
	// debug(t)
	while (t--) {
		int k;
		std::cin >> k;
		// debug(k)
		std::vector<int> num(9);
		int s = 0;
		FOR(i, 9) {
			std::cin >> num[i];
			// debug(i << ' ' << num[i])
			s += num[i];
		}
		// std::cout << check(4, num, k, s, 1);
		// debug(s);
		// return 0;
		int l = 0, r = k * 9 + 1;
		while (r - l > 1) {
			int tm = (l + r) / 2;
			if (check(tm, num, k, s)) {
				r = tm;
			}
			else {
				l = tm;
			}
		}
		// debug(r);
		check(r, num, k, s, true);
		std::cout << '\n';
	}
}