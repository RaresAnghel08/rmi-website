/**
* user:  ivan-6a1
* fname: Tudor
* lname: Ivan
* task:  restore
* score: 0.0
* date:  2019-10-10 07:30:29.141273
*/
#include <iostream>
#include<cstdio>
using namespace std;
const int N=5005;
const int INF=1e5;
struct ajutor{
  int mini,maxi;
};
ajutor d[N][N];
int sol[N];
int n;

int main()
{
  int n,m;
  freopen("a.in","r",stdin);
  scanf("%d%d",&n,&m);
  for(int i=0;i<n;i++)
    sol[i]=INF,d[i][1].maxi=INF;
  for(int i=1;i<=m;i++){
    int l,r,k,val;
    scanf("%d%d%d%d",&l,&r,&k,&val);
    int llen=r-l+1;
    if(val==1){
      d[l][llen].maxi=k-1;
    }
    else{
      d[l][llen].mini=k;
    }
  }
  for(int i=0;i<n;i++){
    d[i][1].mini=max(d[i][1].mini,0);
    d[i][1].maxi=min(d[i][1].maxi,1);
  }
  for(int l=2;l<=n;l++){
    for(int i=0;i+l-1<n;i++){
      d[i][l].mini=max(d[i][l-1].mini+d[i+l][1].mini,d[i][1].mini+d[i+1][l-1].mini);
      d[i][l].maxi=min(d[i][l-1].maxi+d[i+l][1].maxi,d[i][1].maxi+d[i+1][l-1].maxi);
    }
  }
  for(int l=1;l<=n;l++){
    for(int i=0;i+l-1<n;i++){
      if(d[i][l].mini==d[i][l].maxi){
        for(int j=i;j<=i+l-1;j++)
          sol[j]=0;
      }
    }
  }
  for(int i=0;i<n;i++){
    if(sol[i]==INF)
      sol[i]=1;
    printf("%d ",sol[i]);
  }
  return 0;
}
