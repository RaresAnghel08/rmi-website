/**
* user:  patrushava-e4f
* fname: Hanna
* lname: Patrushava
* task:  Gardening
* score: 11.0
* date:  2021-12-16 11:30:13.797811
*/
#pragma GCC optimize ("unroll-loops")
#pragma GCC optimize ("Ofast")
#include <bits/stdc++.h>

#define f first
#define s second
#define pb push_back
#define pii pair<int, int>
#define ll long long

using namespace std;

int n, m;

vector < vector < int > > a, ans, rt;
vector < pii > pp = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
bool dfs(int x, int y, int len, int nom, int x1, int y1) {
    a[x][y] = nom;

    if (len > 2) {
        int cnt = 0, o = 0;
        for (int i = 0; i < 4; i++)
            if (x + pp[i].f < n && x + pp[i].f >= 0 && y + pp[i].s < m && y + pp[i].s >= 0 && a[pp[i].f + x][pp[i].s + y] == nom) {
                cnt++;
                if (x + pp[i].f == x1 && y + pp[i].s == y1)
                    o = 1;
            }
        if (cnt == 2 && o == 1)
            return true;
    }


    int cnt = 0;
    for (int i = 0; i < 4; i++) {
        if (x + pp[i].f < n && x + pp[i].f >= 0 && y + pp[i].s >= 0 && y + pp[i].s < m) {
            if (a[x + pp[i].f][y + pp[i].s] == nom)
                cnt++;
        }
    }

    if (cnt >= 2) {
        a[x][y] = 0;
        return false;
    }

    for (int i = 0; i < 4; i++)
        if (x + pp[i].f < n && x + pp[i].f >= 0 && y + pp[i].s < m && y + pp[i].s >= 0 && a[pp[i].f + x][pp[i].s + y] == 0) {
            if (dfs(x + pp[i].f, y + pp[i].s, len + 1, nom, x1, y1) == true)
                return true;
        }

    a[x][y] = 0;
    return false;
}

vector < vector < int > > p;
bool go(int ost) {


    int kol = 0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (p[i][j] == 0)
                kol++;

    if (ost == 0 && kol == 0) {
        ans = p;
        return true;
    } else if (ost == 0)
        return false;

    a = p;
    bool f = 0;
    kol = 0;
    for (int i = 0; i < n; i++) {
        if (f == 1)
            break;
        for (int j = 0; j < m; j++) {
            if (a[i][j] == 0) {
                if (ost == kol) {
                    f = 1;
                    break;
                }

                bool fl = dfs(i, j, 1, ost - kol, i, j);
                kol++;
                if (fl == false)
                    f = 1;

            }
        }
    }

    if (f == 0 && kol == ost) {
        ans = a;
        return true;
    }
    for (int i = 0; i + 1 < n; i++)
        for (int j = 0; j + 1 < m; j++) {
            if (rt[i][j] == 0 && p[i][j] == 0 && p[i + 1][j] == 0 && p[i][j + 1] == 0 && p[i + 1][j + 1] == 0) {
                p[i][j] = ost;
                p[i + 1][j] = ost;
                p[i][j + 1] = ost;
                p[i + 1][j + 1] = ost;
                rt[i][j] = 1;
                if (go(ost - 1) == true)
                    return true;
                p[i][j] = 0;
                p[i + 1][j] = 0;
                p[i][j + 1] = 0;
                p[i + 1][j + 1] = 0;

            }
        }

    return false;
}
void solve() {
    cin >> n >> m;
    if (n * m > 200000) {
        cout << "NO\n";
        return;
    }

    if (n % 2 == 1 && m % 2 == 1) {
        cout << "NO\n";
        return;
    }

    int need;
    cin >> need;

    int ma = (n * m) / 2;

    if (need > ma) {
        cout << "NO\n";
        return;
    }

    if (need < max(n, m) / 2) {
        cout << "NO\n";
        return;
    }

    if (n == 2) {
        if (need != m / 2) {
            cout << "NO\n";
            return;
        }

        cout << "YES\n";

        for (int i = 0; i < m; i+= 2) {
            cout << i / 2 + 1 << ' ' << i / 2 + 1 << ' ';
        }
        cout << "\n";
        for (int i = 0; i < m; i+= 2) {
            cout << i / 2 + 1 << ' ' << i / 2 + 1 << ' ';
        }
        cout << "\n";
        return;

    }

    if (n == 4) {

        if (m == need) {

            cout << "YES\n";

            for (int i = 0; i < m; i+= 2) {
                cout << i / 2 + 1 << ' ' << i / 2 + 1 << ' ';
            }
            cout << "\n";
            for (int i = 0; i < m; i+= 2) {
                cout << i / 2 + 1 << ' ' << i / 2 + 1 << ' ';
            }
            cout << "\n";

            for (int i = 0; i < m; i+= 2) {
                cout << i / 2 + 1 + need / 2 << ' ' << i / 2 + 1 + need / 2 << ' ';
            }
            cout << "\n";
            for (int i = 0; i < m; i+= 2) {
                cout << i / 2 + 1 + need / 2 << ' ' << i / 2 + 1 + need / 2 << ' ';
            }
            cout << "\n";

            return;

        }
        int kol1 = -1, kol2 = -1;
        for (int k2 = 0; k2 <= m / 2; k2++) {
            int k1 = m - k2 * 2;
            if (k1 == 2)
                break;

            if (k2 * 2 + k1 / 2 == need) {
                kol1 = k2;
                kol2 = k1 / 2 - 1;
            }
        }


        if (kol1 == -1 || kol2 == -1)
        {
            cout << "NO\n";
            return;
        }

        cout << "YES\n";
        int res[n][m];
        for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) res[i][j] = 1;

        int now = 2;
        int u = 0;
        for (int c = 0; c < kol1; c++)
        {
            res[0][u] = now;
            res[1][u] = now;
            res[0][u + 1] = now;
            res[1][u + 1] = now;
            now++;
            res[2][u] = now;
            res[3][u] = now;
            res[2][u + 1] = now;
            res[3][u + 1] = now;
            now++;

            u += 2;
        }

        u++;
        for (int c = 0; c < kol2; c++)
        {
            res[1][u] = now;
            res[1][u + 1] = now;
            res[2][u] = now;
            res[2][u + 1] = now;
            now++;
            u += 2;
        }

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
                cout << res[i][j] << ' ';
            cout << "\n";
        }

        return;
    }


    p.resize(n);
    rt.resize(n);
    for (int i = 0; i < n; i++) {
        p[i].resize(m);
        rt[i].resize(m);
    }

    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            p[i][j] = 0, rt[i][j] = 0;

    if (go(need) == false)
        cout << "NO\n";
    else {
        cout << "YES\n";
        for (auto to: ans) {
            for (auto x: to)
                cout << x << ' ';
            cout << "\n";
        }
    }

}
int32_t main() {

#ifdef LOCAL
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
#endif // LOCAL

    ios_base::sync_with_stdio();
    cin.tie(0);
    cout.tie(0);

    int t;
    cin >> t;

    while (t--) {
        solve();
    }

    return 0;
}
