#include <bits/stdc++.h>

using namespace std;

const int MAX_S = 100000;
const int MAX_K = MAX_S;
const int SIGMA = 10;

void score(double pts, string s) {
    fprintf(stdout, "%.5f", pts);
    fprintf(stderr, "%s", s.c_str());
    exit(0);
}

void wa() { score(0, "Wrong Answer!"); }

namespace Checker {
    struct SuffixArray {
        #define rep(i, a, b) for(int i = a; i < (b); ++i)
        #define trav(a, x) for(auto& a : x)
        #define all(x) begin(x), end(x)
        #define sz(x) (int)(x).size()
        typedef long long ll;
        typedef pair<int, int> pii;
        typedef vector<int> vi;

        vi sa, lcp;
        SuffixArray(string& s, int lim=256) { // or basic_string<int>
            int n = s.size() + 1, k = 0, a, b;
            vi x(all(s)+1), y(n), ws(max(n, lim)), rank(n);
            sa = lcp = y, iota(all(sa), 0);
            for (int j = 0, p = 0; p < n; j = max(1, j * 2), lim = p) {
                p = j, iota(all(y), n - j);
                rep(i,0,n) if (sa[i] >= j) y[p++] = sa[i] - j;
                fill(all(ws), 0);
                rep(i,0,n) ws[x[i]]++;
                rep(i,1,lim) ws[i] += ws[i - 1];
                for (int i = n; i--;) sa[--ws[x[y[i]]]] = y[i];
                swap(x, y), p = 1, x[sa[0]] = 0;
                rep(i,1,n) a = sa[i - 1], b = sa[i], x[b] =
                    (y[a] == y[b] && y[a + j] == y[b + j]) ? p - 1 : p++;
            }
            rep(i,1,n) rank[sa[i]] = i;
            for (int i = 0, j; i < n - 1; lcp[rank[i++]] = k)
                for (k && k--, j = sa[rank[i] - 1];
                        s[i + k] == s[j + k]; k++);
        }
    };

    string GetBestKSlidingWindow(const int K, const string& str) {
        const int N = str.size();
        assert(K <= N);
        string str_(str);
        SuffixArray sa(str_);
        int best = N;
        while (sa.sa[best] + K - 1 >= N) {
            --best;
        }
        best = sa.sa[best];
        return str.substr(best, K);
    }
}

bool readFixedLengthString(ifstream& stream, string& s, const int S) {
    s.resize(S);
    stream >> ws >> noskipws;
    for (int i = 0; i < S; ++i) {
        if (!(stream >> s[i])) {
            stream >> skipws;
            return false;
        }
    }
    stream >> skipws;
    return true;
}

int main(int num, char **file) {
  ifstream fIn(file[1]);
  ifstream fOk(file[2]);
  ifstream fOut(file[3]);

  int T;
  assert(fIn >> T);
  assert(1 <= T && T <= 100000);
  bool veryGood = false;
  int sumS = 0;
  for (int z = 0; z < T; z++) {
    int K;
    assert(fIn >> K);
    int S = 0;
    int freq[SIGMA];
    for (int d = 1; d < SIGMA; d++) {
      assert(fIn >> freq[d]);
      S += freq[d];
    }
    assert(1 <= K && K <= S && S <= 100000);
    sumS += S;

    string xSubStrOk;
    assert(readFixedLengthString(fOk, xSubStrOk, K));
    //assert(fOk >> xSubStrOk);
    assert((int)xSubStrOk.size() == K);

    string xOut;
    if (!readFixedLengthString(fOut, xOut, S)) wa();
    //if (!(fOut >> xOut)) wa();
    if ((int)xOut.size() != S) wa();

    for (int i = 0; i < (int)xOut.size(); ++i) {
      if (!('1' <= xOut[i] && xOut[i] <= '9')) wa();
      freq[xOut[i] - '0']--;
    }
    for (int i = 1; i < SIGMA; i++) {
      if (!(freq[i] == 0)) wa();
    }

    string xSubStrOut = Checker::GetBestKSlidingWindow(K, xOut);
    if (xSubStrOut < xSubStrOk) {
      veryGood = true;
    }
    if (xSubStrOut > xSubStrOk) {
      wa();
    }
  }
  assert(sumS <= 1000000);

  if (veryGood) {
    score(1, "Correct! Correct!");
  } else {
    score(1, "Correct!");
  }
  return 0;
}
