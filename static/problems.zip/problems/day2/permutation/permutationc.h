void solve(int N);
int query(int v[]);
void answer(int v[]);
