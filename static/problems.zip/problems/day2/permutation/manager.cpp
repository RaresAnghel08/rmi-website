#include <bits/stdc++.h>

using namespace std;

static FILE *fin, *fout, *fifo_in, *fifo_out;

const int NMAX = 1005;
static int N, p1[NMAX], p2[NMAX], p[NMAX], pos[NMAX];

void score(int n, int q = 0) {
  double pts;
  if (n <= 0) {
    pts = 0;
  } else if (q <= n) {
    pts = 1.0;
  } else if (q <= 2 * n) {
    pts = 1.0 - 0.4 * (q - n) / (2 * n - n);
  } else if (q <= n * n) {
    pts = 0.6 - 0.4 * (q - 2 * n) / (n * n - 2 * n);
  } else {
    pts = 0.2;
  }

  fprintf(stdout, "%lf\n", pts);
  fclose(fin); fclose(fout); fclose(fifo_in); fclose(fifo_out);
  exit(0);
}

void wrong_format() {
  fprintf(fifo_out, "-1\n");
  fprintf(stderr, "Wrong query format!\n");
  score(0);
}

void wrong_answer_format() {
  fprintf(fifo_out, "-1\n");
  fprintf(stderr, "Wrong answer format!\n");
  score(0);
}

void answer_not_called() {
  fprintf(fifo_out, "-1\n");
  fprintf(stderr, "Answer not provided!\n");
  score(0);
}

void answer(int queries) {
  int n;
  if (fscanf(fifo_in, "%d", &n) != 1) wrong_answer_format();

  if (n != N) {
    fprintf(stderr, "Wrong answer!\n");
    score(0);
  }

  int msk = 3;
  for (int i = 1; i <= N; i++) {
    int x;
    if(fscanf(fifo_in, "%d", &x) != 1) wrong_answer_format();

    if(x != p1[i])	msk &= 2;
    if(x != p2[i])	msk &= 1;
  }

  if(msk > 0)	{
    fprintf(stderr, "Correct!\n");
    score(n, queries);
  } else {
    fprintf(stderr, "Wrong answer!\n");
    score(0, queries);
  }
}

int main(int argc, char **argv)
{
  signal(SIGPIPE, SIG_IGN);

  fin = fopen("input.txt", "r");
  fout = fopen("output.txt", "w");
  fifo_out = fopen(argv[1], "w");
  fifo_in = fopen(argv[2], "r");

  fscanf(fin, "%d", &N);
  for(int i = 1; i <= N; i++)	fscanf(fin, "%d", &p1[i]);
  for(int i = 1; i <= N; i++)	p2[i] = N - p1[i] + 1;

  fprintf(fifo_out, "%d\n", N); fflush(fifo_out);

  for(int q=1; true; q++)
  {
    int op = -1;
    if (fscanf(fifo_in, "%d", &op) != 1) answer_not_called();
    if(op == 1)	answer(q - 1);

    if(op != 0) wrong_format();

    int n;
    if (fscanf(fifo_in, "%d", &n) != 1) wrong_format();
    if(n != N) wrong_format();
    for(int i = 1; i <= N; i++)	pos[i] = 0;
    for(int i = 1; i <= N; i++) {
      if(fscanf(fifo_in, "%d", &p[i]) != 1) wrong_format();
      if(p[i] < 1 || N < p[i]) wrong_format();
      if(pos[ p[i] ] != 0)	wrong_format();
      pos[ p[i] ] = i;
    }

    int ans = 0;
    for(int i = 2; i <= N; i++)
      ans += abs(p1[ p[i] ] - p1[ p[i - 1] ]);
    fprintf(fifo_out, "%d\n", ans);	fflush(fifo_out);
  }

  fprintf(stderr, "Too many queries!\n");
  fprintf(fifo_out, "-1\n");
  score(0);
  return 0;
}
