#include <vector>

void solve(int N);
int query(std::vector<int> v);
void answer(std::vector<int> v);
int query(int v[]);
void answer(int v[]);
