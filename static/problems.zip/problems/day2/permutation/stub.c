#include <stdio.h>
#include <stdlib.h>
#include "permutationc.h"

static FILE *fifo_in, *fifo_out;
int N;

int query(int p[]) {
  fprintf(fifo_out, "0\n");
  fprintf(fifo_out, "%d\n", N);
  for(int i = 0; i < N; i++)	fprintf(fifo_out, "%d ", p[i]);
  fprintf(fifo_out, "\n");
  fflush(fifo_out);

  int x;
  fscanf(fifo_in, "%d", &x);
  if(x == -1) {
    fclose(fifo_in); fclose(fifo_out);
    exit(0);
  }
  return x;
}

void answer(int p[]) {
  fprintf(fifo_out, "1\n");
      fprintf(fifo_out, "%d\n", N);
  for(int i = 0; i < N; i++)	fprintf(fifo_out, "%d ", p[i]);
  fprintf(fifo_out, "\n");
  fflush(fifo_out);

  fclose(fifo_in), fclose(fifo_out);
  exit(0);
}

int main(int argc, char **argv) {
	fifo_in = fopen(argv[2], "r");
	fifo_out = fopen(argv[1], "w");
  fscanf(fifo_in, "%d", &N);
  solve(N);
	return 0;
}
