/**
 * Method: naive simulation.
 *
 * Author: Catalin Francu
 *
 * Details: in the general case we can use Dijkstra's algoritm. When all
 * altitudes are distinct, however, then for every interesting climbers'
 * position exactly one of the climbers is in a node; the other one is in the
 * middle of a segment. Therefore, vertices in the graph have degree at most
 * 2, meaning there is a single path and we can simply follow it until the
 * climbers meet.
 **/
#include <stdio.h>
#include <stdlib.h>

#define MAX_N 5000
#define INFINITY (1ull << 63)

int n;
int alt[MAX_N];

/* returns true if the altitudes at i, j and k are in ascending or descending order */
int sequence(int i, int j, int k) {
  return
    (i >= 0 && i < n && j >= 0 && j < n && k >= 0 && k < n) &&
    (
     (alt[i] < alt[j] && alt[j] < alt[k]) ||
     (alt[i] > alt[j] && alt[j] > alt[k])
     );
}

int differentPair(int x1, int y1, int x2, int y2) {
  return (x1 != x2) || (y1 != y2);
}

/* replaces (x1, y1) with (x2, y2) and returns the cost of moving */
int moveTo(int* x1, int* y1, int x2, int y2) {
  int result = abs(alt[*x1] - alt[x2]);
  *x1 = x2;
  *y1 = y2;
  return result;
}

long long greedy() {
  int x, y, prevx, prevy;
  long long cost;

  /* start after move 1 to avoid the special case of the two (equal) zeroes */
  if (alt[1] < alt[n - 2]) {
    x = 1;
    y = n - 2;
    prevx = 0;
    prevy = n - 1;
    cost = alt[1];
  } else {
    x = n - 2;
    y = 0;
    prevx = n - 1;
    prevy = 0;
    cost = alt[n - 2];
  }

  while (x != y && x != y - 1) {
    int curx = x, cury = y;
    if (sequence(y, x + 1, y + 1) && differentPair(prevx, prevy, x + 1, y)) {
      cost += moveTo(&x, &y, x + 1, y);
    } else if (sequence(x + 1, y, x) && differentPair(prevx, prevy, y, x)) {
      cost += moveTo(&x, &y, y, x);
    } else if (sequence(x, y + 1, x + 1) && differentPair(prevx, prevy, y + 1, x)) {
      cost += moveTo(&x, &y, y + 1, x);
    } else if (sequence(y, x - 1, y + 1) && differentPair(prevx, prevy, x - 1, y)) {
      cost += moveTo(&x, &y, x - 1, y);
    } else if (sequence(x - 1, y, x) && differentPair(prevx, prevy, y, x - 1)) {
      cost += moveTo(&x, &y, y, x - 1);
    } else {
      cost += moveTo(&x, &y, y + 1, x - 1);
    }
    prevx = curx;
    prevy = cury;
  }

  if (x == y - 1) {
    cost += moveTo(&x, &y, y, y);
  }

  return cost;
}

int main() {
  int numAlts;

  /* read altitudes, suppressing repeated values and monotonic runs */
  scanf("%d%d%d", &numAlts, &alt[0], &alt[1]);
  n = 2;
  while (numAlts-- > 2) {
    scanf("%d", &alt[n]);
    if (sequence(n - 2, n - 1, n)) {
      alt[n - 1] = alt[n];
    } else {
      n++;
    }
  }

  long long answer = greedy();

  printf("%lld\n", answer);
}
