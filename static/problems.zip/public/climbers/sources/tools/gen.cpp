// Test generator that includes some anti-backtracking sequences.
//
// Author: Catalin Francu
//
// When num_zigzags and zigzag_length are 0, the generator simply outputs
// random altitudes. It ensures that there is a peak of max_altitude between
// n/3 and 2n/3.
//
// When the caller requests num_zigzags zigzags of total length zigzag_length,
// the program:
//
// * Generates two random altitudes alt1 and alt2. Zigzags will have the
//   format alt1 alt2 alt1 alt2...
// * Computes the average zigzag length avg = zigzag_length / num_zigzags.
// * Generates num_zigzags lengths between 2 * avg / 3 and 4 * avg / 3, making
//   sure the lengths sum up to zigzag_length.
// * Outputs remaining altitudes randomly, interspersing zigzags evenly.
//
#include <time.h>
#include "testlib.h"
using namespace std;

#define MIN_N 3
#define MAX_N 5000
#define MAX_ALTITUDE 1000000

int main(int argc, char **argv) {
  // read command line arguments
  if (argc != 6) {
    printf("Usage: %s <n> <max_altitude> <truly_random>\n", argv[0]);
    printf("  <n>: number of altitudes\n");
    printf("  <max_altitude>: range of generated altitudes (inclusive)\n");
    printf("  <num_zigzags>: number of zigzags\n");
    printf("  <zigzag_length>: total length of zigzags\n");
    printf("  <truly_random>: set a time-based random seed, overriding testlib\n");
    quitf(_fail, "syntax error");
  }

  int n = atoi(argv[1]);
  int max = atoi(argv[2]);
  int numZigzags = atoi(argv[3]);
  int zigzagLength = atoi(argv[4]);
  int trulyRandom = atoi(argv[5]);

  // sanity checks
  ensuref(n >= MIN_N && n <= MAX_N,
          "n must be between %d and %d", MIN_N, MAX_N);
  ensuref(max >= 1 && max <= MAX_ALTITUDE,
          "max_altitude must be between 1 and %d", MAX_ALTITUDE);
  ensuref(zigzagLength >= 0 && zigzagLength <= n - 3,
          "zigzag_length must be between 0 and %d", n - 3);
  ensuref((numZigzags && zigzagLength) || (!numZigzags && !zigzagLength),
          "num_zigzags and zigzag_length must be both zero or both nonzero");

  registerGen(argc, argv, 1);
  if (trulyRandom) {
    rnd.setSeed(time(NULL));
  }

  // choose two distinct altitudes for the zigzags
  int alt1, alt2;
  do {
    alt1 = rnd.next(1, max - 1);
    alt2 = rnd.next(1, max - 1);
  } while (alt1 == alt2);

  vector<int> zigzag;
  if (numZigzags) {
    // generate zigzags of average length avg
    int avg = zigzagLength / numZigzags;
    int minLength = avg * 2 / 3;
    int maxLength = avg * 4 / 3;
    int sum = 0;

    for (int i = 0; i < numZigzags; i++) {
      int len = rnd.next(minLength, maxLength);
      zigzag.push_back(len);
      sum += len;
    }

    // adjust lengths to reach the required total
    while (sum != zigzagLength) {
      int i = rnd.next(numZigzags);
      if (sum < zigzagLength && zigzag[i] < maxLength) {
        zigzag[i]++;
        sum++;
      } else if (sum > zigzagLength && zigzag[i] > minLength) {
        zigzag[i]--;
        sum--;
      }
    }
  }

  // count the elements except the zigzags, the peak and the initial and final 0's
  println(n);
  n -= zigzagLength + 3;

  int dir = true; // true = up, false = down
  vector<int> v;

  v.push_back(0);
  int z = 0; // zigzags output so far
  int prevAlt = 1; // last altitude, excluding zigzags
  for (int i = 0; i < n; i++) {
    // add a random altitude, changing direction at every step
    int h = dir
      ? rnd.next(prevAlt + 1, max)
      : rnd.next(1, prevAlt - 1);
    v.push_back(h);
    dir = !dir;
    prevAlt = h;

    // maybe add zigzags; use a modified Bresenham's algorithm to decide.
    // Basically, at position n we should have output numZigzags zigzags, so
    // scale that down to i.
    int ratio = (numZigzags + 1) * (i + 1) / n;
    while (z < ratio && z < numZigzags) {
      for (int j = 0; j < zigzag[z]; j++) {
        v.push_back((j % 2) ? alt1 : alt2);
      }
      z++;
    }
  }
  v.push_back(0);

  // insert the peak
  int peakPos = rnd.next(v.size() / 3, 2 * v.size() / 3);
  v.insert(v.begin() + peakPos, max);

  println(v);
}
