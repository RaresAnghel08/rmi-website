#!/bin/bash

validate_test() {
  echo ==== Validating $2 of group [$1]
  if [ -z "$1" ]; then # empty group
    ./validator < $2
  else
    ./validator --group $1 < $2
  fi
}

validate_test small-nh test/01.in
validate_test small-nh test/02.in
validate_test small-nh test/03.in
validate_test small-nh test/04.in
validate_test small-nh test/05.in
validate_test all-distinct test/06.in
validate_test all-distinct test/07.in
validate_test all-distinct test/08.in
validate_test all-distinct test/09.in
validate_test all-distinct test/10.in
validate_test "" test/11.in
validate_test "" test/12.in
validate_test "" test/13.in
validate_test "" test/14.in
validate_test "" test/15.in
validate_test "" test/16.in
validate_test "" test/17.in
validate_test "" test/18.in
validate_test "" test/19.in
validate_test "" test/20.in
