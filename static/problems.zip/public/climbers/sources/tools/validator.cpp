// Author: Catalin Francu
#include "testlib.h"
using namespace std;

#define MIN_N 3
#define MAX_N 5000
#define MAX_ALTITUDE 1000000
#define MIN_REAL_FRACTION 0.85
#define SMALL_NH_LIMIT 40000

// returns true if the numbers i, j and k are in ascending or descending order
int sequence(int i, int j, int k) {
  return
    (i <= j && j <= k) ||
    (i >= j && j >= k);
}

int main(int argc, char **argv) {
  registerValidation(argc, argv);

  // validate file structure and value ranges
  int n = inf.readInt(MIN_N, MAX_N, "n");
  inf.readEoln();

  vector<int> v;
  v.push_back(inf.readInt(0, 0, "first altitude must be 0"));
  for (int i = 1; i < n - 1; i++) {
    inf.readSpace();
    v.push_back(inf.readInt(1, MAX_ALTITUDE, "v_i"));
  }
  inf.readSpace();
  v.push_back(inf.readInt(0, 0, "last altitude must be 0"));
  inf.readEoln();
  inf.readEof();

  // Consecutive sorted altitudes can be collapsed, e.g. in 10 7 2 we can
  // remove the 7. Therefore, count strictly zigzagging altitudes and complain
  // if it significantly less than N.
  int realN = 2;
  int oldest = v[0], older = v[1];
  for (int i = 2; i < n; i++) {
    if (sequence(oldest, older, v[i])) {
      older = v[i];    // e.g. 7 5 2 -> 7 2
    } else {
      realN++;
      oldest = older;
      older = v[i];
    }
  }

  ensuref(realN >= n * MIN_REAL_FRACTION,
          "Only %d of %d altitudes are real (%.0f%%)",
          realN, n, 100.0 * realN / n);

  if (validator.group() == "all-distinct") {
    // check that all altitudes besides the initial and final 0 are distinct
    sort(v.begin(), v.end());
    int numDistinct = unique(v.begin(), v.end()) - v.begin();
    ensuref(numDistinct == n - 1, "Some altitudes are not distinct");
  }

  if (validator.group() == "small-nh") {
    // check that n x the maximum altitude is small
    int maxAlt = *max_element(v.begin(), v.end());
    long long product = (long long)n * maxAlt;
    ensuref(product <= SMALL_NH_LIMIT,
            "n * max_altitude should be at most %d, is %llu",
            SMALL_NH_LIMIT, product);
  }
}
