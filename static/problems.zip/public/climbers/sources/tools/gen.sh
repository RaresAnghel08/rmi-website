#!/bin/bash

./gen 30 50 2 15 0 > test/01.in
./gen 60 150 3 20 0 > test/02.in
./gen 150 170 3 50 0 > test/03.in
./gen 100 400 3 38 0 > test/04.in
./gen 400 100 4 80 0 > test/05.in
./gen-distinct 100 1000 0 > test/06.in
./gen-distinct 300 5000 0 > test/07.in
./gen-distinct 1000 30000 0 > test/08.in
./gen-distinct 3000 150000 0 > test/09.in
./gen-distinct 5000 1000000 0 > test/10.in
./gen 100 50000 5 80 0 > test/11.in
./gen 300 100000 10 201 0 > test/12.in
./gen 1000 300000 65 902 0 > test/13.in
./gen 3000 500000 101 2001 0 > test/14.in
./gen 3000 800000 102 2702 0 > test/15.in
./gen 4000 800000 51 3000 0 > test/16.in
./gen 4000 1000000 152 3701 0 > test/17.in
./gen 5000 1000000 200 3499 0 > test/18.in
./gen 5000 1000000 200 4002 0 > test/19.in
./gen 5000 1000000 201 4502 0 > test/20.in
