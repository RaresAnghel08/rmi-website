// Test generator for all distinct altitudes
//
// Author: Catalin Francu
//
// Method: We want the sequence to zigzag as much as possible. We start by
// generating n-3 random altitudes (the zeroes and the peak are handled
// separately). If at any point we generate three consecutive sorted altitudes
// a, b and c, we swap b and c.
//
// This can leave the last three numbers sorted (since we cannot swap the
// final zero value). This is unavoidable when n is even.
//
#include <time.h>
#include "testlib.h"
using namespace std;

#define MIN_N 3
#define MAX_N 5000
#define MAX_ALTITUDE 1000000

// returns true if the numbers i, j and k are in ascending or descending order
int sequence(int i, int j, int k) {
  return
    (i <= j && j <= k) ||
    (i >= j && j >= k);
}

int main(int argc, char **argv) {
  // read command line arguments
  if (argc != 4) {
    printf("Usage: %s <n> <max_altitude> <truly_random>\n", argv[0]);
    printf("  <n>: number of altitudes\n");
    printf("  <max_altitude>: range of generated altitudes (inclusive)\n");
    printf("  <truly_random>: set a time-based random seed, overriding testlib\n");
    quitf(_fail, "syntax error");
  }

  int n = atoi(argv[1]);
  int max = atoi(argv[2]);
  int trulyRandom = atoi(argv[3]);

  // sanity checks
  ensuref(n >= MIN_N && n <= MAX_N,
          "n must be between %d and %d", MIN_N, MAX_N);
  ensuref(max >= n - 2 && max <= MAX_ALTITUDE,
          "max_altitude must be between %d and %d", n - 2, MAX_ALTITUDE);

  registerGen(argc, argv, 1);
  if (trulyRandom) {
    rnd.setSeed(time(NULL));
  }

  // Push two zeroes and n-3 random elements. Runs in O(n^2) for simplicity.
  vector<int> v;
  v.push_back(0);
  for (int i = 0; i < n - 3; i++) {
    int h;
    do {
      h = rnd.next(1, max - 1);
    } while (find(v.begin(), v.end(), h) != v.end());
    v.push_back(h);

    if (i >= 2 && sequence(v[i - 2], v[i - 1], v[i])) {
      swap(v[i - 1], v[i]);
    }
  }
  v.push_back(0);

  // insert the peak
  int peakPos = rnd.next(n / 3, 2 * n / 3);
  v.insert(v.begin() + peakPos, max);

  println(n);
  println(v);
}
