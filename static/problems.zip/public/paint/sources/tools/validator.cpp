// Author: Catalin Francu
#include "testlib.h"

#define MAX_N_SMALL 10000
#define MAX_N_MEDIUM 100000
#define MAX_N 1000000
#define SIGMA 26

using namespace std;

int main(int argc, char** argv){
	registerValidation(argc, argv);

  int minN, maxN;
  if (validator.group() == "small") {
    minN = 2;
    maxN = MAX_N_SMALL;
  } else if (validator.group() == "medium") {
    minN = MAX_N_SMALL + 1;
    maxN = MAX_N_MEDIUM;
  } else {
    minN = MAX_N_MEDIUM + 1;
    maxN = MAX_N;
  }

  unsigned numOps = inf.readInt(minN, maxN, "numOps");
  inf.readEoln();

  while (numOps--) {
    int op = inf.readInt(1, 2, "op");
    inf.readSpace();
    char x = inf.readChar();
    ensuref(x >= 'a' && x <= 'z',
            "Invalid paint code %c found.", x);
    if (op == 2) {
      inf.readSpace();
      char y = inf.readChar();
      ensuref(y >= 'a' && y <= 'z',
              "Invalid paint code %c found.", x);
    }
    inf.readEoln();
  }

  inf.readEof();
  return 0;
}
