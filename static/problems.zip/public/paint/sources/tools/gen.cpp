// Author: Catalin Francu
#include <stdio.h>
#include <time.h>
#include "testlib.h"

#define MAX_N 1000000
#define SIGMA 26

int count[SIGMA];

int main(int argc, char **argv) {
  // read command line arguments
  if (argc != 6) {
    fprintf(stderr, "Usage: gen <n> <firstLetter> <lastLetter> <percentRepaint> <truly_random>\n");
    printf("  <n>: number of operations to generate\n");
    printf("  <firstLetter>-<lastLetter>: alphabet to use\n");
    printf("  <percentRepaint>: chance for an operation to be a repaint\n");
    printf("  <truly_random>: set a time-based random seed, overriding testlib\n");
    quitf(_fail, "syntax error");
  }
  int numOps = atoi(argv[1]);
  char fl = argv[2][0] - 'a';
  char ll = argv[3][0] - 'a';
  int percentRepaint = atoi(argv[4]);
  int trulyRandom = atoi(argv[5]);

  // sanity checks
  ensuref(numOps >= 1 && numOps <= MAX_N,
          "n must be between %d and %d", 1, MAX_N);
  ensuref(0 <= fl && fl <= ll && ll < SIGMA,
          "letters must be between a and z");
  ensuref(percentRepaint >= 0 && percentRepaint <= 100,
          "percentRepaint must be between 0 and 100");

  registerGen(argc, argv, 1);
  if (trulyRandom) {
    rnd.setSeed(time(NULL));
  }

  int targetDistinctLetters = (ll - fl + 1) / 2;
  int distinctLetters = 0, totalLetters = 0, x, y;

  printf("%d\n", numOps);
  while (numOps--) {
    if ((distinctLetters < targetDistinctLetters) || (rnd.next(100) >= percentRepaint)) {
      do {
        x = rnd.next(fl, ll);
      } while ((distinctLetters < targetDistinctLetters) && count[x]);
      if (!count[x]) {
        distinctLetters++;
      }
      count[x]++;
      totalLetters++;
      printf("1 %c\n", x + 'a');
    } else {
      do {
        x = rnd.next(fl, ll);
        y = rnd.next(fl, ll);
      } while ((count[x] > totalLetters / (ll - fl + 1)) ||
               (count[y] > totalLetters / (ll - fl + 1)));
      printf("2 %c %c\n", x + 'a', y + 'a');
      count[y] += count[x];
      count[x] = 0;
      distinctLetters--;
    }
  }
}
