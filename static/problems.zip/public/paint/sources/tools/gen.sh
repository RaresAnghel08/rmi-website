#!/bin/bash

./gen 10 a e 89 0 > test/01.in
./gen 100 m q 50 0 > test/02.in
./gen 1000 a z 33 0 > test/03.in
./gen 300 f g 25 0 > test/04.in
./gen 10000 r t 75 0 > test/05.in
./gen 60000 a z 100 0 > test/06.in
./gen 70000 j s 50 0 > test/07.in
./gen 80000 m z 25 0 > test/08.in
./gen 90000 a z 83 0 > test/09.in
./gen 100000 d g 50 0 > test/10.in
./gen 500000 a z 5 0 > test/11.in
./gen 550000 a j 90 0 > test/12.in
./gen 600000 k q 66 0 > test/13.in
./gen 650000 a z 35 0 > test/14.in
./gen 750000 j z 10 0 > test/15.in
./gen 800000 b f 95 0 > test/16.in
./gen 850000 g z 25 0 > test/17.in
./gen 900000 c d 75 0 > test/18.in
./gen 950000 a z 100 0 > test/19.in
./gen 1000000 a z 50 0 > test/20.in
