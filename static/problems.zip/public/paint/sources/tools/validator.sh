#!/bin/bash

validate_test() {
  echo ==== Validating $2 of group [$1]
  if [ -z "$1" ]; then # empty group
    ./validator < $2
  else
    ./validator --group $1 < $2
  fi
}

validate_test small test/01.in
validate_test small test/02.in
validate_test small test/03.in
validate_test small test/04.in
validate_test small test/05.in
validate_test medium test/06.in
validate_test medium test/07.in
validate_test medium test/08.in
validate_test medium test/09.in
validate_test medium test/10.in
validate_test "" test/11.in
validate_test "" test/12.in
validate_test "" test/13.in
validate_test "" test/14.in
validate_test "" test/15.in
validate_test "" test/16.in
validate_test "" test/17.in
validate_test "" test/18.in
validate_test "" test/19.in
validate_test "" test/20.in
