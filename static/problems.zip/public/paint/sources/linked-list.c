/**
 * Linked list approach: at any time, store lists of positions for each color
 *
 * Author: Catalin Francu
 **/
#include <stdio.h>

#define MAX_N 1000000
#define SIGMA 26
#define NIL -1

int next[MAX_N];
int head[SIGMA], tail[SIGMA];

char c[MAX_N + 1];

int main(void) {
  int numOps, op, nRooms = 0, x, y;
  char c1, c2;

  for (int i = 0; i < SIGMA; i++) {
    head[i] = tail[i] = NIL;
  }

  scanf("%d", &numOps);
  for (int i = 0; i < numOps; i++) {
    scanf("%d %c", &op, &c1);
    x = c1 - 'a';
    if (op == 1) {
      /* add the next room to the list of rooms of color x */
      next[nRooms] = NIL;
      if (head[x] == NIL) {
        head[x] = nRooms;
      } else {
        next[tail[x]] = nRooms;
      }
      tail[x] = nRooms++;
    } else {
      /* move all of x's list to y */
      scanf(" %c", &c2);
      y = c2 - 'a';
      if (head[x] != NIL && c1 != c2) {
        next[tail[x]] = head[y];
        head[y] = head[x];
        if (tail[y] == NIL) {
          tail[y] = tail[x];
        }
        head[x] = tail[x] = NIL;
      }
    }
  }

  /* finally, traverse each color's list and paint the rooms */
  for (int x = 0; x < SIGMA; x++) {
    for (int p = head[x]; p != NIL; p = next[p]) {
      c[p] = x + 'a';
    }
  }
  c[nRooms] = '\0';

  puts(c);
}
