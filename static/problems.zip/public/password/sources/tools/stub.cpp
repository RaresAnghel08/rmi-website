// CMS-style stub (compiled with the user's submission).
//
// Author: Catalin Francu
#include <iostream>
#include <string>
#include <signal.h>
#include <stdlib.h>
#include <assert.h>

using namespace std;

#define MAX_QUERIES 50000

int query(string q) {
  // stop after MAX_QUERIES + 1 to give the contestant a chance
  // to terminate the program gracefully (by returning from guess())
  static int numQueries = 0;
  if (++numQueries > MAX_QUERIES) {
    exit(0);
  }

  int result;
  cout << q << endl;
  cout.flush();
  cin >> result;

  return result;
}

string guess(int n, int s);

int main() {
	signal(SIGPIPE, SIG_IGN);

  int n = 0, s = 0;
  cin >> n >> s;
  assert(n && s);

  cout << guess(n, s) << endl;

  return 0;
}
