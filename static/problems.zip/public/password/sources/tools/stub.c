/**
 * CMS-style stub (compiled with the user's submission).
 *
 * Author: Catalin Francu
**/
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define MAX_QUERIES 50000

int query(char* q) {
  /* stop after MAX_QUERIES + 1 to give the contestant a chance */
  /* to terminate the program gracefully (by returning from guess()) */
  static int numQueries = 0;
  if (++numQueries > MAX_QUERIES) {
    exit(0);
  }

  int result;
  puts(q);
  fflush(stdout);
  scanf("%d", &result);

  return result;
}

char* guess(int n, int s);

int main() {
	signal(SIGPIPE, SIG_IGN);

  int n, s;
  assert(scanf("%d %d", &n, &s) == 2);

  puts(guess(n, s));

  return 0;
}
