// Author: Catalin Francu
#include <time.h>
#include "testlib.h"
using namespace std;

#define MIN_N 1
#define MAX_N 5000
#define MIN_SIGMA 2
#define MAX_SIGMA 26

typedef struct {
  char c;
  int f;
} symbol;

bool descFreq(symbol i, symbol j) {
  return i.f > j.f;
}

int main(int argc, char **argv) {
  // read command line arguments
  if (argc != 8) {
    printf("Usage: %s <n> <s> <dice> <shuf_percent> <truly_random>\n", argv[0]);
    printf("  <n>: value of n\n");
    printf("  <s>: value of s (sigma)\n");
    printf("  <dice>: number of dice to roll (1 for uniform, several for Gauss)\n");
    printf("  <guaranteed>: (boolean) 1 to include each symbol at least once\n");
    printf("  <frequent>: give the highest frequencies to these symbols\n");
    printf("  <shuf_percent>: degree of shuffled-ness of symbols within string\n");
    printf("  <truly_random>: set a time-based random seed, overriding testlib\n");
    quitf(_fail, "syntax error");
  }

  int n = atoi(argv[1]);
  int s = atoi(argv[2]);
  int dice = atoi(argv[3]);
  int guaranteed = atoi(argv[4]);
  string frequent(argv[5]);
  int shufPercent = atoi(argv[6]);
  int trulyRandom = atoi(argv[7]);

  // sanity checks
  ensuref(n >= MIN_N && n <= MAX_N,
          "n must be between %d and %d", MIN_N, MAX_N);
  ensuref(s >= MIN_SIGMA && s <= MAX_SIGMA,
          "s must be between %d and %d", MIN_SIGMA, MAX_SIGMA);
  ensuref(dice >= 1, "must use at least one die");
  ensuref(shufPercent >= 0 && shufPercent <= 100,
          "shuf_percent must be between 0 and 100");

  registerGen(argc, argv, 1);
  if (trulyRandom) {
    rnd.setSeed(time(NULL));
  }

  vector<symbol> sym(s);

  if (guaranteed) {
    for (int i = 0; i < s; i++) {
      sym[i].f = 1;
    };
  }

  // generate symbol frequencies by rolling s-sided dice and taking the average
  for (int i = guaranteed ? s : 0; i < n; i++) {
    int sum = 0;
    for (int j = 0; j < dice; j++) {
      sum += rnd.next(s);
    }
    int avg = 1.0 * sum / dice + 0.5;
    sym[avg].f++;
  }

  sort(sym.begin(), sym.end(), descFreq);

  // pad frequent to the entire alphabet; remaining letters are shuffled
  while ((int)frequent.size() < s) {
    char c = 'a' + rnd.next(s);
    if (frequent.find(c) == string::npos) {
      frequent += c;
    }
  }
  for (int i = 0; i < s; i++) {
    sym[i].c = frequent[i];
  }

  // shuffle the letter order, but print each letter contiguously
  shuffle(sym.begin(), sym.end());
  string p;
  for (symbol& pair : sym) {
    p.append(pair.f, pair.c);
  }

  // shuffle the password to the degree indicated by shuf_percent
  for (int i = 0; i < n; i++) {
    if (rnd.next(100) < shufPercent) {
      int j = rnd.next(0, i);
      char tmp = p[i];
      p[i] = p[j];
      p[j] = tmp;
    }
  }

  cout << n << ' ' << s << endl << p << endl;
}
