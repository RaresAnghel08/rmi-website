// Author: Catalin Francu
#include "testlib.h"

#define MAX_N 5000
#define MAX_SIGMA 26

using namespace std;

int main(int argc, char** argv){
	registerValidation(argc, argv);

  unsigned n = inf.readInt(2, MAX_N, "n");
  inf.readSpace();
  int s = inf.readInt(2, MAX_SIGMA, "s");
  inf.readEoln();

  string password = inf.readToken();
  inf.readEoln();
  inf.readEof();

  ensuref(password.size() == n,
          "n is %d but password size is %lu", n, password.size());

  for (char& c : password) {
    ensuref(c >= 'a' && c < 'a' + s, "Illegal character [%c] found.", c);
  }

  // check subtask sizes
  if (validator.group().find("distinct") != string::npos) {
    set<char> checker(password.begin(), password.end());
    ensuref(checker.size() == password.size(), "Password contains duplicates.");
  } else if (validator.group().find("n-log-sigma") != string::npos) {
    ensuref(n > 3500 && s > 20, "Limits too low for n log sigma solution");
  } else if (validator.group().find("n-sigma-over-2") != string::npos) {
    ensuref(n > 2000 && n <= 3500 && s > 20,
            "Incorrect limits for n x sigma / 2 solution");
  } else if (validator.group().find("n-sigma") != string::npos) {
    ensuref(n > 100 && n <= 2000 && s > 4 && s <= 20,
            "Incorrect limits for n x sigma solution");
  } else if (validator.group().find("n2-sigma") != string::npos) {
    ensuref(n <= 100 && s <= 4,
            "Incorrect limits for n^2 x sigma solution");
  }

  return 0;
}
