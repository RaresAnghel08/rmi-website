/**
 * CMS-style manager (separate process for the contestant process).
 *
 * #define DEBUG 1 to log all incoming queries to standard error.
 *
 * stdin:   test data
 * stdout:  outcome
 * stderr:  message for the contestant
 * fin:     input from the contestant process
 * fout:    output to the contestant process
 *
 * Author: Catalin Francu
 **/
#include <assert.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>

#define DEBUG 0

#define MAX_QUERIES 50000
#define MAX_N 5000
#define MAX_SIGMA 26

#define TIMEOUT_SEC 3
#define TIMEOUT_MICROSEC 500000

/* after[i][c] = next occurrence of character c beginning with position i */
int after[MAX_N + 1][MAX_SIGMA];
char password[MAX_N + 1], query[MAX_N + 3]; /* allow room for \r\n\0 */
int sumLen;

void end(double score, const char* format, ...) {
  va_list args;
  va_start(args, format);

  /* print the outcome */
  printf("%0.1lf\n", score);

  /* print the message for the contestant */
  vfprintf(stderr, format, args);
  fprintf(stderr, "\n");

  exit(0);
}

/* Is there anybody out there? There does not seem to be another way */
/* to detect whether the other process closed the pipe. */
int moreInput(int fd) {
  /* build a FD set with just our file descriptor */
  fd_set set;
  FD_ZERO(&set);
  FD_SET(fd, &set);

  /* set the timer */
  struct timeval tv;
  tv.tv_sec = TIMEOUT_SEC;
  tv.tv_usec = TIMEOUT_MICROSEC;

  int result = select(1 + fd, &set, NULL, NULL, &tv);

  return (result >= 0) && FD_ISSET(fd, &set);
}

/* reads a string, trims the trailing \r or \n, and returns the length */
int readLine(char* s, int size, FILE* stream) {
  fgets(s, size, stream);

  int len = strlen(s);
  while (len && (s[len - 1] == '\r' || s[len - 1] == '\n')) {
    s[--len] = '\0';
  }

  return len;
}

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <fin> <fout>\n", argv[0]);
    fprintf(stderr, "  <fin>:  FIFO pipe for input from the user program\n");
    fprintf(stderr, "  <fout>: FIFO pipe for output to the output program\n");
    return 1;
  }

	signal(SIGPIPE, SIG_IGN);
  int fdin = open(argv[1], O_RDWR);
  FILE *fin = fdopen(fdin, "r");
  FILE *fout = fopen(argv[2], "w");
  assert(fin && fout);

  int n, s;
  scanf("%d %d ", &n, &s);
  readLine(password, MAX_N + 2, stdin);
  fprintf(fout, "%d %d\n", n, s);
  fflush(fout);

  /* fill in the after table */
  for (int j = 0; j < s; j++) {
    after[n][j] = n;
  }
  for (int i = n - 1; i >= 0; i--) {
    for (int j = 0; j < s; j++) {
      after[i][j] = after[i + 1][j];
    }
    after[i][password[i] - 'a'] = i;
  }

  int numQueries = 0, found = 0;

  while (numQueries < MAX_QUERIES && !found && moreInput(fdin)) {

    int len = readLine(query, MAX_N + 2, fin);

    /* also handle Windows-style \r\n */
    while (len && (query[len - 1] == '\r' || query[len - 1] == '\n')) {
      query[--len] = '\0';
    }
    sumLen += len;

    /* validation */
    if (len < 1 || len > n) {
      end(0, "Query should have length between 1 and %d characters.",
          n);
    }

    for (int i = 0; i < len; i++) {
      if (query[i] < 'a' || query[i] >= 'a' + s) {
        end(0, "Query should only contain letters from [a,%c].",
            'a' + s - 1);
      }
    }

    int posQ = 0, posP = 0;
    while (posP < n && posQ < len) {
      posP = 1 + after[posP][query[posQ++] - 'a'];
    }
    if (posP > n) {
      posQ--;
    }

    fprintf(fout, "%d\n", posQ);
    fflush(fout);

    found = (posQ == n);
    numQueries++;
    if (DEBUG) {
      fprintf(stderr, "Question #%d [%s] answer %d\n",
              numQueries, query, posQ);
    }
  }

  if (DEBUG) {
    fprintf(stderr, "Sum of query lengths = %d.\n", sumLen);
  }
  if (found) {
    end(1, "Guessed the password with %d queries.", numQueries);
  } else if (numQueries == MAX_QUERIES) {
    end(0, "Could not guess the password with %d queries.", MAX_QUERIES);
  } else {
    end(0, "Returned early from guess() after %d queries.", numQueries);
  }
}
