#!/bin/bash

# Launcher that runs the manager and a contestant program, cross-binding their
# inputs and outputs.
#
# * contestant_binary: program you would like to test
# * input file: file containing n, s, and the lost password

if [ $# -ne 2 ]; then
    echo "Usage: $0 <contestant_binary> <input_file>"
    exit
fi

# hard-coded stuff
FIFO0=/tmp/fifo0
FIFO1=/tmp/fifo1
MANAGER=cms/manager

rm -rf $FIFO0 $FIFO1
mkfifo $FIFO0 $FIFO1

$MANAGER $FIFO0 $FIFO1 < $2 &
$1 < $FIFO1 > $FIFO0
wait
