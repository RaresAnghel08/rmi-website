/**
 * Method: Handles the case of exactly two distinct values.
 *
 * Author: Catalin Francu
 **/
#include <stdio.h>

#define MOD 1000000007

int main() {
  int n, x;
  int v1, v2 = 0, c1 = 1, c2 = 0;
  scanf("%d %d", &n, &v1);
  while (--n) {
    scanf("%d", &x);
    if (x == v1) {
      c1++;
    } else {
      v2 = x;
      c2++;
    }
  }

  if (v1 > v2) {
    int tmp = c1;
    c1 = c2;
    c2 = tmp;
  }

  /**
   * Now we know that the smaller value occurs c1 times and the larger value
   * occurs c2 times.
   **/
  int sol = (long long)(c1 - 1) * (c2 - 1) * (c2 - 2) / 2 % MOD;

  printf("%d\n", sol);
}
