#!/bin/bash

validate_test() {
  echo ==== Validating $2 of group [$1]
  if [ -z "$1" ]; then # empty group
    ./validator < $2
  else
    ./validator --group $1 < $2
  fi
}

validate_test "" test/01.in
validate_test "" test/02.in
validate_test TwoDistinct test/03.in
validate_test AllDistinct test/04.in
validate_test "" test/05.in
validate_test TwoDistinct test/06.in
validate_test "" test/07.in
validate_test AllDistinct test/08.in
validate_test "" test/09.in
validate_test "" test/10.in
validate_test "" test/11.in
validate_test AllDistinct test/12.in
validate_test TwoDistinct test/13.in
validate_test AllDistinct test/14.in
validate_test "" test/15.in
validate_test AllDistinct test/16.in
validate_test "" test/17.in
validate_test TwoDistinct test/18.in
validate_test AllDistinct test/19.in
validate_test "" test/20.in
