// Author: Catalin Francu
#include <time.h>
#include <unordered_set>
#include "testlib.h"
using namespace std;

#define MIN_N 5
#define MAX_N 300000
#define MIN_VALUE 1
#define MAX_VALUE 1000000

int main(int argc, char **argv) {
  // read command line arguments
  if (argc != 7) {
    printf("Usage: %s <n> <min_value> <max_value> <num_distinct> <most_equal> <truly_random>\n",
           argv[0]);
    printf("  <n>: number of numbers to generate\n");
    printf("  <min_value>-<max_value>: range of generated numbers (inclusive)\n");
    printf("  <num_distinct>: number of distinct values among the n numbers\n");
    printf("  <most_equal>: maximum number of equal values\n");
    printf("  <truly_random>: set a time-based random seed, overriding testlib\n");
    quitf(_fail, "syntax error");
  }

  int n = atoi(argv[1]);
  int min = atoi(argv[2]);
  int max = atoi(argv[3]);
  int numDistinct = atoi(argv[4]);
  int mostEqual = atoi(argv[5]);
  int trulyRandom = atoi(argv[6]);

  // sanity checks
  if (n < MIN_N || n > MAX_N) {
    quitf(_fail, "n must be between %d and %d", MIN_N, MAX_N);
  }
  if (min < MIN_VALUE || min > max || max > MAX_VALUE) {
    quitf(_fail, "min and max must be between %d and %d", MIN_VALUE, MAX_VALUE);
  }
  if (numDistinct < 1) {
    quitf(_fail, "there must be at least one distinct value... really!");
  }
  if (numDistinct > max - min + 1) {
    quitf(_fail, "there aren't %d distinct values between %d and %d",
          numDistinct, min, max);
  }
  if (numDistinct > n) {
    quitf(_fail, "cannot have %d distinct values using %d numbers",
          numDistinct, n);
  }
  int minDistinct = (n + numDistinct - 1) / numDistinct;
  int maxDistinct = n - numDistinct + 1;
  if (mostEqual < minDistinct || mostEqual > maxDistinct) {
    quitf(_fail, "with %d numbers and %d distinct values, "
          "most_equal must be between %d and %d",
          n, numDistinct, minDistinct, maxDistinct);
  }

  registerGen(argc, argv, 1);
  if (trulyRandom) {
    rnd.setSeed(time(NULL));
  }

  // set frequency mostEqual for one value, 1 for the other numDistinct - 1
  vector<int> freq(numDistinct, 1);
  freq[0] = mostEqual;

  // distribute remaining numbers randomly, taking care not to exceed mostEqual
  for (int assigned = mostEqual + numDistinct - 1; assigned < n; assigned++) {
    int pos;
    do {
      pos = rnd.next(numDistinct);
    } while (freq[pos] == mostEqual);
    freq[pos]++;
  }

  // choose numDistinct distinct values and generate v
  vector<int> v;
  unordered_set<int> used;
  for (int i = 0; i < numDistinct; i++) {
    int value;
    do {
      value = rnd.next(min, max);
    } while (used.find(value) != used.end());
    used.insert(value);
    v.insert(v.end(), freq[i], value);
  }

  // shuffle v
  shuffle(v.begin(), v.end());

  // output v
  println(n);
  println(v);
}
