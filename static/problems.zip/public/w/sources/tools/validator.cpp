// Author: Catalin Francu
#include "testlib.h"

#include <algorithm>

#define MIN_N 5
#define MAX_N 300000
#define MIN_VALUE 1
#define MAX_VALUE 1000000

int main(int argc, char **argv) {
  registerValidation(argc, argv);

  int n = inf.readInt(MIN_N, MAX_N, "n");
  inf.readEoln();

  std::vector<int> v;
  for (int i = 0; i < n; i++) {
    if (i) {
      inf.readSpace();
    }
    v.push_back(inf.readInt(MIN_VALUE, MAX_VALUE, "v_i"));
  }
  inf.readEoln();
  inf.readEof();
  std::sort(v.begin(), v.end());
  int distinct = std::unique(v.begin(), v.end()) - v.begin();
  if (validator.group() == "TwoDistinct") {
    ensuref(distinct == 2,
            "There have to be exactly 2 distinct values instead of %d.",
            distinct);
  }
  if (validator.group() == "AllDistinct") {
    ensuref(distinct == n,
            "There have to be exactly %d distinct values instead of %d.",
            n, distinct);
  }
}
