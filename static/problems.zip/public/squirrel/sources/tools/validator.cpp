// Author: Catalin Francu
#include "testlib.h"

#include <algorithm>

#define MIN_COORD 2
#define MAX_COORD 50000
#define MIN_F 1
#define MAX_F 1000
#define MIN_FRACTAL_SIZE 1
#define MAX_FRACTAL_SIZE 1024

#define MAX_JUMPS_TINY 40000000
#define MAX_JUMPS_SMALL 65000000
#define MAX_JUMPS_MEDIUM 125000000
#define MAX_JUMPS 300000000

int main(int argc, char **argv) {
  registerValidation(argc, argv);

  int m = inf.readInt(MIN_COORD, MAX_COORD, "m");
  inf.readSpace();
  int n = inf.readInt(MIN_COORD, MAX_COORD, "n");
  inf.readSpace();
  int f = inf.readInt(MIN_F, MAX_F, "f");
  inf.readEoln();

  unsigned jumps = 0;
  while (f--) {
    int l = inf.readInt(1, m, "line");
    inf.readSpace();
    int c = inf.readInt(1, n, "column");
    inf.readSpace();
    int size = inf.readInt(MIN_FRACTAL_SIZE, MAX_FRACTAL_SIZE, "size");
    inf.readEoln();

    ensuref(!(size & (size - 1)),
            "Fractal size %d is not a power of 2.", size);

    // check bounding box
    // south side already covered by readInt() above
    // fractal height is 3 * size - 2
    // fractal width is 2 * size - 2 on either size of the trunk
    ensuref(l - (3 * size - 2) >= 1 ,
            "fractal %d %d %d extends past line 1.", l, c, size);
    ensuref(c - (2 * size - 2) >= 1,
            "fractal %d %d %d extends past column 1.", l, c, size);
    ensuref(c + (2 * size - 2) <= n,
            "fractal %d %d %d extends past the n-th column.", l, c, size);

    // because fractals are dome-shaped, the only fractal that can touch
    // the (1,1) corner is a size 1 fractal
    ensuref(c > 1 || l > 2,
            "fractal %d %d %d touches coordinates (1,1).", l, c, size);

    // determined empirically
    jumps += 3 * size * size - 2 * size + 1;
  }

  unsigned maxJumps;
  if (validator.group() == "tiny") {
    maxJumps = MAX_JUMPS_TINY;
  } else if (validator.group() == "small") {
    maxJumps = MAX_JUMPS_SMALL;
  } else if (validator.group() == "medium") {
    maxJumps = MAX_JUMPS_MEDIUM;
  } else {
    maxJumps = MAX_JUMPS;
  }

  ensuref(jumps <= maxJumps, "total number of jumps is %d, exceeds %d.",
          jumps, maxJumps);

  inf.readEof();
  return 0;
}
