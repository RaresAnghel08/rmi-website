/**
  *  Worg
  */
#include <ctime>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include "testlib.h"

static const int MAX_N = 30000 + 5;
static const int MAX_D = 20;
static const int MAX_K = 100000 + 5;
static const int MAX_Q = 100000 + 5;
static const int MAX_T = 2e9;

/*-------- Data --------*/
int n, k, q, t_max;
int graph_type;
std::vector<int > graph[MAX_N];
/*-------- --------*/

void GenerateLinearGraph() {
  std::pair<int, int > traffickers[MAX_K + MAX_Q];
  bool deleted_trafficker[MAX_K + MAX_Q];
  int total_traffickers = 0;

  //  Generate graph
  std::vector<int > node_order;
  for(int i = 1; i <= n; i++) {
    node_order.push_back(i);
  }
  shuffle(node_order.begin(), node_order.end());

  std::vector<std::pair<int, int > > graph_edges;
  for(int i = 0; i < n - 1; i++) {
    graph_edges.push_back({node_order[i], node_order[i + 1]});
  }
  shuffle(graph_edges.begin(), graph_edges.end());

  printf("%d\n", n);
  for(auto& edge : graph_edges) {
    printf("%d %d\n", edge.first, edge.second);
  }

  //  Generate initial traffickers
  printf("%d\n", k);
  for(int i = 1; i <= k; i++) {
    int dist = rnd.next(0, MAX_D - 1);

    int u = rnd.next(0, n - 1), v;
    if(u >= dist) {
      v = u - dist;
    } else {
      v = u + dist;
    }

    int coin_flip = rnd.next(0, 1);
    if(coin_flip) {
      std::swap(u, v);
    }

    total_traffickers++;
    traffickers[total_traffickers] = std::make_pair(node_order[u], node_order[v]);
    deleted_trafficker[total_traffickers] = false;
    printf("%d %d\n", node_order[u], node_order[v]);
  }

  //  Print operations
  printf("%d\n", q);
  for(int i = 1; i <= q; i++) {
    int random_value = rnd.next(1, 10);

    //  70% chance to be a query -> most expensive operation
    //  20% chance to be a new trafficker
    //  10% chance to delete an existent trafficker
    
    if(random_value <= 7) {  //  Query 
      int node_distance = rnd.next(7 * n / 10, n - 1);  //  We want the distance between the query nodes to be >= 0.7 * n, so no brute solutions pass the test unexpectedly
      int u = rnd.next(0, n - 1 - node_distance);
      int v = u + node_distance;

      int coin_flip = rnd.next(0, 1);
      if(coin_flip) {
        std::swap(u, v);
      }

      int t1 = rnd.next(0, t_max), t2 = rnd.next(0, t_max);

      if(t1 > t2) std::swap(t1, t2);

      printf("3 %d %d %d %d\n", node_order[u], node_order[v], t1, t2);
    } else if(random_value <= 9) {  //  New trafficker
      int dist = rnd.next(0, MAX_D - 1);

      int u = rnd.next(0, n - 1), v;
      if(u >= dist) {
        v = u - dist;
      } else {
        v = u + dist;
      }

      int coin_flip = rnd.next(0, 1);
      if(coin_flip) {
        std::swap(u, v);
      }

      total_traffickers++;
      traffickers[total_traffickers] = std::make_pair(node_order[u], node_order[v]);
      deleted_trafficker[total_traffickers] = false;
      
      printf("1 %d %d\n", node_order[u], node_order[v]);
    } else {  //  Delete existent trafficker
      int trafficker_index = rnd.next(1, total_traffickers);

      while(deleted_trafficker[trafficker_index]) {
        trafficker_index = rnd.next(1, total_traffickers);
      }

      deleted_trafficker[trafficker_index] = true;
      printf("2 %d %d\n", traffickers[trafficker_index].first, traffickers[trafficker_index].second);
    }
  }
}

int main(int argc, char **argv) {
  registerGen(argc, argv, 1);

  //  Get main variables
  n = atoi(argv[1]);
  k = atoi(argv[2]);
  q = atoi(argv[3]);
  t_max = atoi(argv[4]);
  graph_type = atoi(argv[5]);

  //rnd.setSeed(time(NULL));

  if(graph_type == 1) {
    GenerateLinearGraph();
  }
  return 0;
}