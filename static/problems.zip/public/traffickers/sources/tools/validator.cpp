/**
  *  Worg
  */
#include "testlib.h"
#include <map>
#include <vector>
#include <utility>

static const int MAX_N_SMALL = 1000;
static const int MAX_N_MEDIUM = 10000;
static const int MAX_N = 30000;

static const int MAX_KQ_SMALL = 500;
static const int MAX_KQ_MEDIUM = 5000;
static const int MAX_KQ = 50000;

static const int MAX_D = 20;

static const int MAX_T_SMALL = 10;
static const int MAX_T = 2000000000;

std::vector<int > graph[MAX_N + 1];
int father[MAX_N + 1], depth[MAX_N + 1];
bool seen[MAX_N + 1];

std::map<std::pair<int, int >, int > map;

void DFS(int node, int dad) {
  seen[node] = true; father[node] = dad; depth[node] = depth[dad] + 1;

  for(auto& son : graph[node]) {
    if(son == dad) continue;

    DFS(son, node);
  }
}

void CheckDistance(int u, int v) {
  int dist = 0;

  while(u != v) {
    if(depth[u] > depth[v]) {
      dist++; u = father[u];
    } else {
      dist++; v = father[v];
    }
  }
  dist++;

  ensuref(dist <= MAX_D, "Nodes are too far away from each other");
}

int main(int argc, char* argv[]) {
  registerValidation(argc, argv);

  int minN, maxN, minK, maxK, minQ, maxQ, maxT;
  if (validator.group() == "small") {
    minN = 1;
    maxN = MAX_N_SMALL;
    minK = 0;
    maxK = MAX_KQ_SMALL;
    minQ = 1;
    maxQ = MAX_KQ_SMALL;
    maxT = MAX_T_SMALL;
  } else if (validator.group() == "medium") {
    minN = 1 + MAX_N_SMALL;
    maxN = MAX_N_MEDIUM;
    minK = 1 + MAX_KQ_SMALL;
    maxK = MAX_KQ_MEDIUM;
    minQ = 1 + MAX_KQ_SMALL;
    maxQ = MAX_KQ_MEDIUM;
    maxT = MAX_T;
  } else { // large or no group
    minN = 1 + MAX_N_MEDIUM;
    maxN = MAX_N;
    minK = 1 + MAX_KQ_MEDIUM;
    maxK = MAX_KQ;
    minQ = 1 + MAX_KQ_MEDIUM;
    maxQ = MAX_KQ;
    maxT = MAX_T;
  }

  int n = inf.readInt(minN, maxN, "n");
  inf.readEoln();

  for(int i = 1; i < n; i++) {
    int u = inf.readInt(1, n, "u");
    inf.readSpace();
    int v = inf.readInt(1, n, "v");
    inf.readEoln();

    graph[u].push_back(v); graph[v].push_back(u);
  }

  //  Check if we generated a tree
  int comps = 0;
  for(int i = 1; i <= n; i++) {
    if(!seen[i]) {
      DFS(i, 0);
      comps++;
    }
  }
  ensuref(comps == 1, "Graph is not a tree");

  int k = inf.readInt(minK, maxK, "k");
  inf.readEoln();

  for(int i = 1; i <= k; i++) {
    int u = inf.readInt(1, n, "u");
    inf.readSpace();
    int v = inf.readInt(1, n, "v");
    inf.readEoln();

    CheckDistance(u, v);
    map[{u, v}]++;
  }

  int q = inf.readInt(minQ, maxQ, "q");
  inf.readEoln();

  for(int i = 1; i <= q; i++) {
    int type = inf.readInt(1, 3, "type");
    inf.readSpace();
    int u = inf.readInt(1, n, "u");
    inf.readSpace();
    int v = inf.readInt(1, n, "v");

    if(type == 3) {
      inf.readSpace();
      inf.readInt(0, maxT, "t1");
      inf.readSpace();
      inf.readInt(0, maxT, "t2");
    } else if(type == 1){
      CheckDistance(u, v);
      map[{u, v}]++;
    } else {
      ensuref(map[{u, v}] > 0, "Tried to remove an unexisting trafficker.");
      map[{u, v}]--;
    }
    inf.readEoln();
  }

  inf.readEof();

  return 0;
}
