#!/bin/bash

validate_test() {
  echo ==== Validating $2 of group $1
  ./validator --group $1 < $2
}

validate_test small test/01.in
validate_test small test/02.in
validate_test small test/03.in
validate_test medium test/04.in
validate_test medium test/05.in
validate_test medium test/06.in
validate_test medium test/07.in
validate_test medium test/08.in
validate_test medium test/09.in
validate_test medium test/10.in
validate_test medium test/11.in
validate_test medium test/12.in
validate_test large test/13.in
validate_test large test/14.in
validate_test large test/15.in
validate_test large test/16.in
validate_test large test/17.in
validate_test large test/18.in
validate_test large test/19.in
validate_test large test/20.in
