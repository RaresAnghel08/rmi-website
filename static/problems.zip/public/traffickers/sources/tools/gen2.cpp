/**
  *  Worg
  */
#include <ctime>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include "testlib.h"

static const int MAX_N = 30000 + 5;
static const int MAX_D = 20;
static const int MAX_K = 100000 + 5;
static const int MAX_Q = 100000 + 5;
static const int MAX_T = 2e9;

/*-------- Data --------*/
int n, k, q, t_max, min_diameter;

std::vector<int > graph[MAX_N];

std::vector<std::pair<int, int > > potential_pairs[MAX_D + 1];
std::vector<std::pair<int, int > > traffickers;
std::vector<bool > deleted_trafficker;
/*-------- --------*/

std::vector<int > BuildInitialChain() {
  //  We want the tree to have a diameter of length >= min_diameter
  std::vector<int > answer(n + 1, 0);
  std::vector<int > perm;

  for(int i = 1; i <= min_diameter; i++) {
    perm.push_back(i);
  }
  shuffle(perm.begin(), perm.end());

  for(int i = 1; i < perm.size(); i++) {
    answer[perm[i]] = perm[i - 1];
  }

  return answer;
}

std::vector<std::pair<int, int > > GetGraphEdges(const std::vector<int > &father_array) {
  std::vector<std::pair<int, int > > answer;

  for(int i = 1; i <= n; i++) {
    if(father_array[i] != 0) {
      answer.push_back(std::make_pair(father_array[i], i));
    }
  }

  shuffle(answer.begin(), answer.end());
  return answer;
}

void DFS(int node, int dad, int node_count, int starting_node) {
  if(starting_node <= node) {
    if(potential_pairs[node_count].size() > MAX_Q) return;
    potential_pairs[node_count].push_back(std::make_pair(starting_node, node));
  }
  
  for(auto& son : graph[node]) {
    if(son == dad || node_count == MAX_D) continue;

    DFS(son, node, node_count + 1, starting_node);
  }
}

void ObtainPotentialTraffickerPairs() {
  for(int i = 1; i <= n; i++) {
    DFS(i, 0, 1, i);
  }  
}

std::pair<int, int > GenerateTrafficker() {
  int dist = rnd.next(1, MAX_D);
  int size = (int)potential_pairs[dist].size();
  int id = rnd.next(0, size - 1);

  return potential_pairs[dist][id];
}

std::pair<int, int > DeleteTrafficker() {
  int id = rnd.next(0, (int)traffickers.size() - 1);

  while(deleted_trafficker[id]) {
    id = rnd.next(0, (int)traffickers.size() - 1);
  }

  deleted_trafficker[id] = true;
  return traffickers[id];
}

void GenerateGraph() {
  auto father_array = BuildInitialChain();
  //  Generate the remaining edges of the tree randomly
  for(int i = min_diameter + 1; i <= n; i++) {
    int father = rnd.next(1, i - 1);
    father_array[i] = father;
  }

  auto edges = GetGraphEdges(father_array);
  //  Print and save the graph
  printf("%d\n", n);
  for(auto& edge : edges) {
    printf("%d %d\n", edge.first, edge.second);
    graph[edge.first].push_back(edge.second);
    graph[edge.second].push_back(edge.first);
  }

  //  We want to generate each potential pair of nodes for the traffickers
  ObtainPotentialTraffickerPairs();

  //  Generate initial traffickers
  printf("%d\n", k);
  for(int i = 1; i <= k; i++) {
    auto trafficker = GenerateTrafficker();
    traffickers.push_back(trafficker);
    deleted_trafficker.push_back(false);

    printf("%d %d\n", trafficker.first, trafficker.second);
  }

  //  Generate operations
  printf("%d\n", q);
  for(int i = 1; i <= q; i++) {
    int random_value = rnd.next(1, 10);

    //  70% chance to be a query -> most expensive operation
    //  20% chance to be a new trafficker
    //  10% chance to delete an existent trafficker

    if(random_value <= 7) {  //  Query
      int u = rnd.next(1, n);
      int v = rnd.next(1, n);
      int t1 = rnd.next(0, t_max);
      int t2 = rnd.next(0, t_max);

      if(t1 > t2) std::swap(t1, t2);

      printf("3 %d %d %d %d\n", u, v, t1, t2);
    } else if(random_value <= 9) {  //  New trafficker
      auto trafficker = GenerateTrafficker();
      traffickers.push_back(trafficker);
      deleted_trafficker.push_back(false);

      printf("1 %d %d\n", trafficker.first, trafficker.second);
    } else {  //  Delete trafficker
      auto trafficker = DeleteTrafficker();
      printf("2 %d %d\n", trafficker.first, trafficker.second);
    }
  }
}

int main(int argc, char *argv[]) {
  registerGen(argc, argv, 1);

  //  n, k, q, t_max, min_diameter
  if(argc != 6) return 0;

  n = atoi(argv[1]);
  k = atoi(argv[2]);
  q = atoi(argv[3]);
  t_max = atoi(argv[4]);
  min_diameter = atoi(argv[5]);

  //rnd.setSeed(time(NULL));

  GenerateGraph();
}