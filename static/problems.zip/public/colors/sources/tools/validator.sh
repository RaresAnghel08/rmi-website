#!/bin/bash

validate_test() {
  echo ==== Validating $2 of group $1
  ./validator --group $1 < $2
}

validate_test star test/01.in
validate_test star test/02.in
validate_test star test/03.in
validate_test complete test/04.in
validate_test line-small test/05.in
validate_test line-small test/06.in
validate_test line-small test/07.in
validate_test line-large test/08.in
validate_test line-large test/09.in
validate_test line-large test/10.in
validate_test tree-small test/11.in
validate_test tree-small test/12.in
validate_test tree-small test/13.in
validate_test tree-large test/14.in
validate_test tree-large test/15.in
validate_test tree-large test/16.in
validate_test small test/17.in
validate_test small test/18.in
validate_test small test/19.in
validate_test large test/20.in
validate_test large test/21.in
validate_test large test/22.in
