// Authors: Costin Oncescu, Catalin Francu
#include <map>
#include <vector>
#include "testlib.h"

using namespace std;

const int MAX_N = 150000;
const int MAX_M = 200000;
const int MAX_SUM_N = 300000;
const int MAX_SUM_M = 400000;
const int MAX_SUM_N2 = 5000000;

const int MAX_SUM_NM_SMALL = 5000000;
const int MAX_SUM_NM_COMPLETE = 12000000;
const int MAX_N_COMPLETE = 50;

map<pair<int, int>, bool> seen;
vector<int> g[1 + MAX_N];
bool out[1 + MAX_N];
int nodes = 0;

void getMaxDegree(unsigned n, unsigned* u, unsigned *d) {
  *d = *u = 0;
  for (unsigned i = 1; i <= n; i++) {
    if (g[i].size() > *d) {
      *d = g[i].size();
      *u = i;
    }
  }
}

int isPermutation(vector<int>& a, unsigned* duplicate) {
  int result = true;
  vector<bool> seen(1 + MAX_N);

  for (auto& v : a) {
    if (seen[v]) {
      *duplicate = v;
      result = false;
    }
    seen[v] = true;
  }

  return result;
}

void checkTestGroups(unsigned n, unsigned m, vector<int>& a, int test) {
  unsigned u, d, duplicate;
  getMaxDegree(n, &u, &d);
  bool perm = isPermutation(a, &duplicate);

  if (validator.group() == "star") {
    // check that there exists a degree u with |g[u]| = n and m = n - 1;
    // with the above information that G is connected, this suffices
    ensuref(m == n - 1 && d == n - 1,
            "Test %d: The graph is not a star.",
            test);

  } else if (validator.group() == "complete") {
    ensuref(n <= MAX_N_COMPLETE,
            "Test %d: A complete graph should have at most %d vertices.",
            test, MAX_N_COMPLETE);
    ensuref(m == n * (n - 1) / 2,
            "Test %d: The graph is not complete.",
            test);

  } else if (validator.group() == "line-small" ||
             validator.group() == "line-large") {
    ensuref(m == n - 1 && d <= 2,
            "Test %d: The graph is not a line. Node %d has degree %d.",
            test, u, d);

  } else if (validator.group() == "tree-small") {
    ensuref(m == n - 1,
            "Test %d: The graph is not a tree. It has %d nodes and %d edges.",
            test, n, m);

  } else if (validator.group() == "tree-large") {
    ensuref(m == n - 1,
            "Test %d: The graph is not a tree. It has %d nodes and %d edges.",
            test, n, m);
    ensuref(perm,
            "Test %d: The color array A is not a permutation: %d is a duplicate.",
            test, duplicate);

  }
}

void checkGlobalGroups(int sumN, int sumM, long long sumN2, long long sumNM) {
  int maxN = MAX_SUM_N;
  int maxM = MAX_SUM_M;
  long long maxN2 = 1ll << 62;
  long long maxNM = 1ll << 62;

  if (validator.group() == "star" ||
      validator.group() == "line-small" ||
      validator.group() == "tree-small") {
    maxN2 = MAX_SUM_N2;
  } else if (validator.group() == "complete") {
    maxNM = MAX_SUM_NM_COMPLETE;
  } else if (validator.group() == "small") {
    maxNM = MAX_SUM_NM_SMALL;
  }

  ensuref(sumN <= maxN,
          "Sum of N is %d, should be at most %d.", sumN, maxN);
  ensuref(sumM <= maxM,
          "Sum of M is %d, should be at most %d.", sumM, maxM);
  ensuref(sumN2 <= maxN2,
          "Sum of N2 is %lld, should be at most %lld.", sumN2, maxN2);
  ensuref(sumNM <= maxNM,
          "Sum of NxM is %lld, should be at most %lld.", sumNM, maxNM);
}

void DFS(int node) {
  out[node] = true;
  nodes++;
  for (auto &it : g[node])
    if (!out[it])
      DFS(it);
}

int main(int argc, char **argv) {
  registerValidation(argc, argv);

  int sumN = 0, sumM = 0;
  long long sumN2 = 0, sumNM = 0;

  int tests = inf.readInt(1, MAX_N, "tests");
  inf.readEoln();

  for (int test = 1; test <= tests; test++) {
    int n = inf.readInt(1, MAX_N, "n");
    inf.readSpace();
    int m = inf.readInt(0, MAX_M, "m");
    inf.readEoln();

    sumN += n;
    sumM += m;
    sumN2 += (long long)n * n;
    sumNM += (long long)n * m;

    vector<int> a = inf.readInts(n, 1, n, "a[i]");
    inf.readEoln();
    inf.readInts(n, 1, n, "b[i]");
    inf.readEoln();

    for (int i = 0; i < m; i++) {
      int x = inf.readInt(1, MAX_N, "x");
      inf.readSpace();
      int y = inf.readInt(1, MAX_N, "y");
      inf.readEoln();

      ensuref(x != y, "Self loops not allowed (%d, %d).", x, y);
      ensuref(!seen[make_pair(x, y)] && !seen[make_pair(y, x)],
              "Edge %d-%d was seen before.", x, y);
      seen[make_pair(x, y)] = seen[make_pair(y, x)] = true;
      g[x].push_back(y);
      g[y].push_back(x);
    }

    nodes = 0;
    DFS(1);
    ensuref(nodes == n, "Graph is not connected.");

    checkTestGroups(n, m, a, test);

    for (int i = 1; i <= n; i++)
      g[i].clear();
    seen.clear();
    memset(out, false, sizeof(out));
  }
  inf.readEof();

  checkGlobalGroups(sumN, sumM, sumN2, sumNM);

  return 0;
}
