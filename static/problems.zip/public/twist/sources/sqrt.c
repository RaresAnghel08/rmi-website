/**
 * See https://gurmeet.net/puzzles/number-guessing-game-ii/
 *
 * Author: Catalin Francu
 **/
#include <stdio.h>
#include <math.h>

int guess(int x);

void play(int n) {
  int x = n - (int)sqrt(2 * n);
  if (x < 1) {
    x = 1;
  }

  /* loop until the hidden number is above n - sqrt(2n) */
  while (guess(x));

  while (1) {
    guess (++x);
  }
}
