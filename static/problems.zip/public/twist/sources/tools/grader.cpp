/**
 * Sample grader for contestants' use.
 *
 * Usage: place your input data in the file twist.in in the format
 *
 * line 1: N
 *
 * Then compile this grader together with your implementation.
 * Run the binary to see your guessing strategy at work!
 * Set DEBUG to 1 to print all queries.
 **/
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DEBUG 0
#define MAX_GUESSES 500

static int n, hidden, numGuesses;

static void choose() {
  hidden = 1 + rand() % n;
  if (DEBUG) {
    fprintf(stderr, "[GRADER] Randomly chose %d\n", hidden);
  }
}

static void end(int success, const char* format, ...) {
  va_list args;
  va_start(args, format);
  vprintf(format, args);
  printf("\n");

  exit(0);
}

int guess(int x) {
  if (++numGuesses > MAX_GUESSES) {
    end(0, "[GRADER] Could not guess the number in %d tries.", MAX_GUESSES);
  }

  /* validation */
  if (x < 1 || x > n) {
    end(0, "[GRADER] Guess %d is outside the interval [1,%d].", x, n);
  }

  int bigger = (x > hidden);
  if (DEBUG) {
    printf("[GRADER] [#%d] Guess %d answer %d\n", numGuesses, x, bigger);
  }

  if (x == hidden) {
    end(1, "[GRADER] Guessed the number in %d tries.", numGuesses);
  }

  if (bigger) {
    choose();
  }

  return bigger;
}

void play(int n);

int main() {

  FILE *f = fopen("twist.in", "r");
  assert(f);
  assert(fscanf(f, "%d", &n) == 1);
  fclose(f);

  srand(time(NULL));
  choose();
  play(n);

  /* please don't return from play() :-) */
  end(0, "[GRADER] Gave up after %d tries.", numGuesses);

	return 0;
}
