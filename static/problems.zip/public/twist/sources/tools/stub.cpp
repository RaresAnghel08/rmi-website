// Author: Catalin Francu
#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_GUESSES 500

int guess(int n) {
  static int numGuesses = 0;
  if (++numGuesses > MAX_GUESSES) {
    exit(0);
  }

  int result;
  printf("%d\n", n);
  fflush(stdout);
  scanf("%d", &result);

  return result;
}

void play(int n);

int main() {
	signal(SIGPIPE, SIG_IGN);

  int n;
  assert(scanf("%d", &n) == 1);
  play(n);

  fclose(stdout);

  return 0;
}
