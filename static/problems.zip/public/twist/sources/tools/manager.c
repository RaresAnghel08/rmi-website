/**
 * CMS-style manager (separate process from the contestant submission).
 *
 * #define DEBUG 1 to log all incoming queries to standard error.
 *
 * stdin:   test data
 * stdout:  outcome
 * stderr:  message for the contestant
 * fin:     input from the contestant process
 * fout:    output to the contestant process
 *
 * Author: Catalin Francu
 **/
#include <assert.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <time.h>

#define DEBUG 0
#define MAX_GUESSES 500
#define TIMEOUT_SEC 2

int choose(int n) {
  int result = 1 + rand() % n;
  if (DEBUG) {
    fprintf(stderr, "Randomly chose %d\n", result);
    fflush(stderr);
  }
  return result;
}

/* Is there anybody out there? There does not seem to be another way */
/* to detect whether the other process closed the pipe. */
int moreInput(int fd) {
  /* build a FD set with just our file descriptor */
  fd_set set;
  FD_ZERO(&set);
  FD_SET(fd, &set);

  /* set the timer */
  struct timeval tv = (struct timeval) { TIMEOUT_SEC, 0 };

  int result = select(1 + fd, &set, NULL, NULL, &tv);

  return (result >= 0) && FD_ISSET(fd, &set);
}

void end(double score, const char* format, ...) {
  va_list args;
  va_start(args, format);

  /* print the outcome */
  printf("%0.1lf\n", score);

  /* print the message for the contestant */
  vfprintf(stderr, format, args);
  fprintf(stderr, "\n");

  exit(0);
}

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <fin> <fout>\n", argv[0]);
    fprintf(stderr, "  <fin>:  FIFO pipe for input from the user program\n");
    fprintf(stderr, "  <fout>: FIFO pipe for output to the output program\n");
    return 1;
  }

	signal(SIGPIPE, SIG_IGN);
  int fdin = open(argv[1], O_RDWR);
  FILE *fin = fdopen(fdin, "r");
  FILE *fout = fopen(argv[2], "w");
  assert(fin && fout);

  int n;
  scanf("%d", &n);
  fprintf(fout, "%d\n", n);
  fflush(fout);

  srand(time(NULL));
  int hidden = choose(n);
  int numGuesses = 0, found = 0, guess;

  while (numGuesses < MAX_GUESSES && !found && moreInput(fdin)) {
    numGuesses++;
    fscanf(fin, "%d", &guess);

    /* validation */
    if (guess < 1 || guess > n) {
      end(0, "Guess %d is outside the interval [1,%d].", guess, n);
    }

    int bigger = (guess > hidden);
    fprintf(fout, "%d\n", bigger);
    fflush(fout);

    found = (guess == hidden);

    if (DEBUG) {
      fprintf(stderr, "Guess #%d [%d] answer %d\n", numGuesses, guess, bigger);
      fflush(stderr);
    }

    if (bigger) {
      hidden = choose(n);
    }

  }

  if (found) {
    end(1, "Guessed the number in %d tries.", numGuesses);
  } else if (numGuesses == MAX_GUESSES) {
    end(0, "Could not guess the number in %d tries.", MAX_GUESSES);
  } else {
    end(0, "Gave up after %d tries.", numGuesses);
  }
}
