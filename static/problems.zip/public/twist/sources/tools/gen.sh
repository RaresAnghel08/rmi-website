#!/bin/bash

echo 100 > test/01.in
echo 500 > test/02.in
echo 600 > test/03.in
echo 700 > test/04.in
echo 800 > test/05.in
echo 1000 > test/06.in
echo 1200 > test/07.in
echo 1500 > test/08.in
echo 1700 > test/09.in
echo 2000 > test/10.in
echo 2800 > test/11.in
echo 3500 > test/12.in
echo 4300 > test/13.in
echo 5000 > test/14.in
echo 5800 > test/15.in
echo 6600 > test/16.in
echo 7500 > test/17.in
echo 8300 > test/18.in
echo 9100 > test/19.in
echo 10000 > test/20.in
