/**
 * Keep guessing n.
 *
 * Expected number of guesses: n
 *
 * Author: Catalin Francu
 **/

int guess(int x);

void play(int n) {
  while (1) {
    guess(n);
  }
}
