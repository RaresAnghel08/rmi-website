/**
 * Make 7 guesses, then return. Just making sure that the grader and stub
 * don't break.
 *
 * Author: Catalin Francu
 **/

#define SEVEN 7 /* why the hell not */

int guess(int x);

void play(int n) {
  for (int i = 0; i < SEVEN; i++) {
    guess(1);
  }
}
