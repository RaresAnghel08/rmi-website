#include <cstdio>
#include <utility>
#include <algorithm>
#include <vector>
#include <cassert>
#include <string>
#include <signal.h>

const int MAX_N = 1000;

void softassert(bool cond, const char* msg) {
  if (!cond) {
    fprintf(stdout, "0.0\n");
    fprintf(stderr, "%s\n", msg);
    std::exit(0);
  }
}

class Interactor {
public:
  // build the interactor
  Interactor(const char* inputphase1name, const char* outputphase1name, 
             const char* inputphase2name, const char* outputphase2name) {
    // fopen is going to wait until the other end opens its pipe;
    // so, since the stub opens the pipe from itself to the manager
    // we have to open the output pipe first, and then the input pipe
    outputphase1 = fopen(outputphase1name, "w");
    inputphase1  = fopen(inputphase1name, "r");
    outputphase2 = fopen(outputphase2name, "w");
    inputphase2  = fopen(inputphase2name, "r");
    
    // if one of these happens, then CMS is bricked
    // and the manager can't do anything
    softassert(outputphase1 != NULL, "Failed to open FIFO");
    softassert(inputphase1 != NULL, "Failed to open FIFO");
    softassert(outputphase2 != NULL, "Failed to open FIFO");
    softassert(inputphase2 != NULL, "Failed to open FIFO");
    
    /*assert(outputphase1 != NULL);
    assert(outputphase2 != NULL);
    assert(inputphase1 != NULL);
    assert(inputphase1 != NULL);
    */

    score = 0.0;
    errmessage = "Error message not set";
    failed = false;
    readinput();
  
    setK = -1;
  }
  
  // give the final score based on the participants' performance
  void decidescore() {
    if (!failed) {
      if (subtask == 5) {
        if (setK < 20)
          setscore(1.0, "OK");
        else
          setscore((double)(60 - setK) / 40.0, "Partial solution");
      } else
        setscore(1.0, "OK");
    }
  }

  // write the verdict: stdout for the score, stderr for the error message
  void writeverdict() {
    fprintf(stdout, "%lf\n", score);
    fprintf(stderr, "%s\n", errmessage.c_str());
    std::exit(0);
  }
  
  // these are the first two phases. Observe that even if something fails,
  // we still have to do at least one interaction with the process
  // so that we tell him that something failed;
  // therefore, before answering to anything, we check if something failed,
  // in case it did, we close the interaction with the process for graceful exit

  // run the first phase of the problem
  void firstphase() {
    std::vector<std::pair<int, int> > edges;
    for (int i = 0; i < N - 1; ++i) {
      if (a[i] > b[i])
        edges.push_back({b[i], a[i]});
      else
        edges.push_back({a[i], b[i]});
      adjmatrix[a[i]][b[i]] = adjmatrix[b[i]][a[i]] = true;
    }

    std::sort(edges.begin(), edges.end());
    
    fprintf(outputphase1, "1\n");
    fprintf(outputphase1, "%d %d\n", subtask, N);
    for (int i = 0; i < edges.size(); ++i)
      fprintf(outputphase1, "%d %d\n", edges[i].first, edges[i].second);
    fflush(outputphase1);
    int phaseop, op;
    
    int callop2 = 0;

    while (fscanf(inputphase1, "%d%d", &phaseop, &op) == 2) {
      require(phaseop == 1, "assignHints must not call getHint, getLength or goTo");
      require(op == 1 || op == 2, "Unknown operation");
      
      if (op == 1) {
        require(setK == -1, "setHintLen must not be called more than once");
        setK = readnumber(inputphase1, "Failed to read interaction");

        require(1 <= setK, "The length must be non-negative");
        require(setK <= K, "The length is too large");
      
        if (failed) {
          abortinteraction(1);
          return;
        } else {
          labels.resize(N + 1, std::vector<bool>(setK + 1, false));
          fprintf(outputphase1, "1\n");
          fflush(outputphase1);
        }
      } else if (op == 2) {
        require(setK != -1, "You must call setLength before you set anything");
        int i, j, b;

        ++callop2;

        i = readnumber(inputphase1, "Failed to read interaction");
        j = readnumber(inputphase1, "Failed to read interaction");
        b = readnumber(inputphase1, "Failed to read interaction");

        require(1 <= i && i <= N, "Invalid node index for setHint");
        require(1 <= j && j <= setK, "Invalid bit index for setHint");
      
        if (failed) {
          abortinteraction(1);
          return;
        } else {
          if (b != 0)
            labels[i][j] = true;
          else
            labels[i][j] = false;
          fprintf(outputphase1, "1\n");
          fflush(outputphase1);
        }
      } else {
        abortinteraction(1);
        return;
      }
    }
 
    fclose(outputphase1);
    fclose(inputphase1);
    inputphase1 = outputphase1 = NULL;
  
    require(setK != -1, "setHintLen was never called");
  }

  // run the second phase
  void secondphase() {
    fprintf(outputphase2, "2\n");
    fprintf(outputphase2, "%d %d %d\n", subtask, N, init_pos);
    fflush(outputphase2);
  
    marked[init_pos] = true;
  
    int phaseop, op;
    int calls = 0;

    while (fscanf(inputphase2, "%d%d", &phaseop, &op) == 2) {
      require(phaseop == 2, "speedrun must not call setHintLen or setHint");
      require(op == 1 || op == 2 || op == 3, "Unknown operation");
    
      if (op == 1) {
        if (failed) {
          abortinteraction(2);
          return;
        } else {
          fprintf(outputphase2, "%d\n", setK);
          fflush(outputphase2);
        }
      } else if (op == 2) {
        int j;
        j = readnumber(inputphase2, "Failed to read interaction");
        require(1 <= j && j <= setK, "Invalid bit index for getHint");

        if (failed) {
          abortinteraction(2);
          return;
        } else {
          if (labels[init_pos][j])
            fprintf(outputphase2, "1\n");
          else
            fprintf(outputphase2, "0\n");
          fflush(outputphase2);
        }
      } else if (op == 3) {
        int x;
        x = readnumber(inputphase2, "Failed to read interaction");
        require(1 <= x && x <= N, "Invalid node index to goTo");
      
        if (failed) {
          abortinteraction(2);
          return;
        } else if (adjmatrix[init_pos][x]) {
          fprintf(outputphase2, "1\n");
          fflush(outputphase2);
          init_pos = x;
          marked[init_pos] = true;
        } else {
          ++calls;
          require(calls <= Q, "Used too many wrong interactions");

          if (failed) {
            abortinteraction(2);
            return;
          } else {
            fprintf(outputphase2, "0\n");
            fflush(outputphase2);
          }
        }
      } else {
        abortinteraction(2);
        return;
      }
    }
  
    fclose(outputphase2);
    fclose(inputphase2);
    inputphase2 = outputphase2 = NULL;
  
    for (int i = 1; i <= N; ++i)
      require(marked[i], "Solution didn't visit every node");
  }

private:
  // pipes
  FILE *inputphase1, *outputphase1;
  FILE *inputphase2, *outputphase2;

  // scoring data
  double score;
  std::string errmessage;
  bool failed;

  // input data
  int subtask;
  int N, init_pos, K, Q;
  int a[MAX_N - 1], b[MAX_N - 1];

  // tree data
  bool adjmatrix[1+MAX_N][1+MAX_N];
  bool marked[1+MAX_N];

  // participant data
  int setK;
  std::vector<std::vector<bool> > labels;

  // if the condition is false, the test is automatically failed and
  // the error message is set
  void require(bool condition, const char* msg) {
    if (!condition && !failed) {
      failed = true;
      setscore(0.0, msg);
    }
  }
  
  // set the score variables
  void setscore(double _score, std::string _errmessage) {
    score = _score;
    errmessage = _errmessage;
  }

  // read a number safely; if reading fails, the flag is set
  // the function also returns 0
  int readnumber(FILE *fin, const char* err) {
    int value;
    require(fscanf(fin, "%d", &value) == 1, err);
    if (failed)
      return 0;
    return value;
  }

  // Read the test input
  void readinput() {
    subtask = readnumber(stdin, "Failed to read input test");
    
    N        = readnumber(stdin, "Failed to read input test");
    init_pos = readnumber(stdin, "Failed to read input test");
    K        = readnumber(stdin, "Failed to read input test");
    Q        = readnumber(stdin, "Failed to read input test");
    
    for (int i = 0; i < N - 1 && !failed; ++i) {
      a[i] = readnumber(stdin, "Failed to read input test");
      b[i] = readnumber(stdin, "Failed to read input test");
    }

    // If we fail to read the test from the input, we should give
    // the participant at least a test that is correct so that
    // the execution doesn't get killed because of his fault.
    // The score will still be 0 in the end.
    if (failed) {
      N = Q = 1;
      init_pos = 1;
      K = 1;
    }

    for (int i = 1; i <= N; ++i) {
      for (int j = 1; j <= N; ++j)
        adjmatrix[i][j] = false;
      marked[i] = false;
    }
  }
  
  // stop the interaction between a process
  // send a -1, so that the process gracefully exits
  void abortinteraction(int phase) {
    if (phase == 1) { // yanderedev moment
      fprintf(outputphase1, "-1\n");
      fflush(outputphase1);

      fclose(outputphase1);
      fclose(inputphase1);
    } else if (phase == 2) {
      fprintf(outputphase2, "-1\n");
      fflush(outputphase2);

      fclose(outputphase2);
      fclose(inputphase2);
    }
  }
};

int main(int argc, char** argv) {
  signal(SIGPIPE, SIG_IGN);
  softassert(argc >= 5, "Not enough arguments"); // we must have at least 5 arguments
  //assert(argc >= 5);

  Interactor interactor(argv[1], argv[2], argv[3], argv[4]);
  interactor.firstphase();
  interactor.secondphase();
  interactor.decidescore();
  interactor.writeverdict();
  return 0;
}

