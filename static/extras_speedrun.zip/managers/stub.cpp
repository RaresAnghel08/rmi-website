#include <stdio.h>
#include <stdlib.h>
#include "speedrun.h"

static FILE *input, *output;

int readvalue() {
  int val;
  fscanf(input, "%d", &val);
  if (val == -1) {
    fclose(input);
    fclose(output);
    exit(0);
  }
  
  return val;
}

void setHintLen(int K) {
  fprintf(output, "1 1 %d\n", K);
  fflush(output);

  readvalue();
}

void setHint(int i, int j, bool b) {
  if (b)
    fprintf(output, "1 2 %d %d 1\n", i, j);
  else
    fprintf(output, "1 2 %d %d 0\n", i, j);
  fflush(output);

  readvalue();
}

int getLength() {
  int K;
  fprintf(output, "2 1\n");
  fflush(output);
  
  K = readvalue();
  return K;
}

bool getHint(int j) {
  int val;
  fprintf(output, "2 2 %d\n", j);
  fflush(output);

  val = readvalue();
  if (val == 0)
    return false;
  return true;
}

bool goTo(int x) {
  int res;

  fprintf(output, "2 3 %d\n", x);
  fflush(output);

  res = readvalue();
  if (res == 0)
    return false;
  return true;
}

int main(int argc, char** argv) {
  int phase_id;
 
  input = fopen(argv[1], "r");
  output = fopen(argv[2], "w");
  
  phase_id = readvalue();

  if (phase_id == 1) {
    int subtask, n;
    subtask = readvalue();
    n = readvalue();
    int a[n], b[n];
    for (int i = 1; i < n; ++i) {
      a[i] = readvalue();
      b[i] = readvalue();
    }
    assignHints(subtask, n, a, b);    
  } else {
    int subtask, n, start;
    subtask = readvalue();
    n = readvalue();
    start = readvalue();
    speedrun(subtask, n, start);
  }

  fclose(input);
  fclose(output);

  return 0;
}

