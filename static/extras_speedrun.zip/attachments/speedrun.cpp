#include "speedrun.h"

void assignHints(int subtask, int N, int A[], int B[]) { /* your solution here */
}

void speedrun(int subtask, int N, int start) { /* your solution here */
}
