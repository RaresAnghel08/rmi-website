#include <bits/stdc++.h>
#include "speedrun.h"

const int MAX_N = 1000;
int father[1+MAX_N], euler[1+MAX_N], lastId;
std::vector<int> graph[1+MAX_N];

void dfs(int node, int dfsfather = 0) {
  father[node] = dfsfather;
  euler[lastId++] = node;
  
  for (auto it: graph[node])
    if (it != dfsfather) {
      dfs(it, node);
    }
}

void setInteger(int node, int id, int value) {
  int offset = id * 10 + 1;
  for (int b = 0; b < 10; ++b) {
    if ((1 << b) & value)
      setHint(node, offset + b, true);
  }
}

int readInteger(int id) {
  int offset = id * 10 + 1;
  int value = 0;
  for (int b = 0; b < 10; ++b) {
    value = value ^ (getHint(offset + b) << b);
  }
  return value;
}

void assignHints(int subtask, int N, int A[], int B[]) {
  setHintLen(20);
  for (int i = 1; i <= N - 1; ++i) {
    graph[A[i]].push_back(B[i]);
    graph[B[i]].push_back(A[i]);
  }
  dfs(1);
  
  for (int i = 0; i < N; ++i) {
    setInteger(i + 1, 0, father[i + 1]);
    setInteger(euler[i], 1, euler[(i + 1) % N]);
  }
}

void speedrun(int subtask, int N, int start) {
  int node = start;
  do {
    int target = readInteger(1);
    while (!goTo(target)) {
      node = readInteger(0);
      goTo(node);
    }
    node = target;
  } while (node != start);
}

