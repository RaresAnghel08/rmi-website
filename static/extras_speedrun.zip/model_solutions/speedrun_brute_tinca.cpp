#include <bits/stdc++.h>
#include "speedrun.h"

void assignHints(int subtask, int N, int A[], int B[]) {
  setHintLen(N);
  for (int i = 1; i <= N - 1; ++i) {
    setHint(A[i], B[i], true);
    setHint(B[i], A[i], true);
  }
}

void dfs(int node, int l, int father = 0) {
  for (int i = 1; i <= l; ++i) {
    if (i != father && getHint(i)) {
      goTo(i);
      dfs(i, l, node);
      goTo(node);
    }
  }
}

void speedrun(int subtask, int N, int start) {
  dfs(start, getLength());
}

