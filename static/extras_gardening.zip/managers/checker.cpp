#include <bits/stdc++.h>
using namespace std;

static void score(int x, const char *const y) {
    cout << x << endl;
    cerr << y << endl;
    exit(0);
}

static constexpr int dx[] = {0, 1, 0, -1}, dy[] = {1, 0, -1, 0};

static void require(bool b, const char *const y) {
    if (!b) score(0, y);
}

int main(int argc, char **argv) {
    ifstream fin(argv[1]), fok(argv[2]), fout(argv[3]);

    auto get_int = [&]() {
        int ret;
        require((bool)(fout >> ret), "Incomplete or malformed output file.");
        return ret;
    };

    auto get_string = [&]() {
        string ret;
        require((bool)(fout >> ret), "Incomplete or malformed output file.");
        return ret;
    };

    int t;
    fin >> t;

    while (t--) {
        int n, m, k;
        fin >> n >> m >> k;

        string a, b;

        fok >> a;
        b = get_string();

        require(a == b, "Incorrect output");

        if (a == "NO") continue;

        vector<vector<int>> buf(n + 2, vector<int>(m + 2, -1));
        vector<vector<bool>> viz(n + 2, vector<bool>(m + 2, false));
        vector<int> ap(k + 1);

        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= m; ++j) {
                buf[i][j] = get_int();
                int tmp;
                fok >> tmp;
            }

        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= m; ++j) {
                require(buf[i][j] >= 1 && buf[i][j] <= k,
                        "Output contains values not between 1 and k");
                ap[buf[i][j]] += 1;
            }

        require(count(begin(ap), end(ap), 0) == 1,
                "Output does not contain all values between 1 and k");

        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= m; ++j) {
                int nr = 0;
                for (int d = 0; d < 4; ++d) {
                    int ni = i + dx[d], nj = j + dy[d];
                    if (buf[i][j] == buf[ni][nj]) ++nr;
                }
                require(nr == 2,
                        "Output contains flowers without two equal neighbours");
            }

        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= m; ++j) {
                if (!viz[i][j]) {
                    require(ap[buf[i][j]] != 0,
                            "Output contains disconnected flowers of the "
                            "same kind");
                    ap[buf[i][j]] = 0;

                    stack<pair<int, int>, vector<pair<int, int>>> st;

                    viz[i][j] = true;
                    st.emplace(i, j);
                    while (!st.empty()) {
                        int x = st.top().first, y = st.top().second;
                        st.pop();

                        for (int d = 0; d < 4; ++d) {
                            int nx = x + dx[d], ny = y + dy[d];
                            if (nx >= 1 && nx <= n && ny >= 1 && ny <= m &&
                                !viz[nx][ny] && buf[x][y] == buf[nx][ny]) {
                                st.emplace(nx, ny);
                                viz[nx][ny] = true;
                            }
                        }
                    }
                }
            }
    }

    require((fout >> ws).eof(),
            "Output contains non-whitespace text after end of correct format.");

    score(1, "Correct! Azusa and Laika like the garden :)");
    return 0;
}
