#include <bits/stdc++.h>

using namespace std;

const int TMAX = 100000;
const int NMAX = 100000;
const int SUM_NMAX = 1000000;

using Test = pair <vector <int>, int>; // (freq, K)

void ReadTest(Test &t) {
    int& K = t.second;
    cin >> K;
    vector <int>& v = t.first;
    v.resize(10);
    for (int i = 1; i < 10; ++i) {
        cin >> v[i];
    }
}

namespace Checker {
    struct SuffixArray {
        #define rep(i, a, b) for(int i = a; i < (b); ++i)
        #define trav(a, x) for(auto& a : x)
        #define all(x) begin(x), end(x)
        #define sz(x) (int)(x).size()
        typedef long long ll;
        typedef pair<int, int> pii;
        typedef vector<int> vi;

        vi sa, lcp;
        SuffixArray(string& s, int lim=256) { // or basic_string<int>
            int n = s.size() + 1, k = 0, a, b;
            vi x(all(s)+1), y(n), ws(max(n, lim)), rank(n);
            sa = lcp = y, iota(all(sa), 0);
            for (int j = 0, p = 0; p < n; j = max(1, j * 2), lim = p) {
                p = j, iota(all(y), n - j);
                rep(i,0,n) if (sa[i] >= j) y[p++] = sa[i] - j;
                fill(all(ws), 0);
                rep(i,0,n) ws[x[i]]++;
                rep(i,1,lim) ws[i] += ws[i - 1];
                for (int i = n; i--;) sa[--ws[x[y[i]]]] = y[i];
                swap(x, y), p = 1, x[sa[0]] = 0;
                rep(i,1,n) a = sa[i - 1], b = sa[i], x[b] =
                    (y[a] == y[b] && y[a + j] == y[b + j]) ? p - 1 : p++;
            }
            rep(i,1,n) rank[sa[i]] = i;
            for (int i = 0, j; i < n - 1; lcp[rank[i++]] = k)
                for (k && k--, j = sa[rank[i] - 1];
                        s[i + k] == s[j + k]; k++);
        }
    };

    string GetBestKSlidingWindow(const int K, const string& str) {
        const int N = str.size();
        assert(K <= N);
        string str_(str);
        SuffixArray sa(str_);
        int best = N;
        while (sa.sa[best] + K - 1 >= N) {
            --best;
        }
        best = sa.sa[best];
        return str.substr(best, K);
    }

    string GetBestKSlidingWindowBrute(const int K, const string& str) {
        const int N = str.size();
        assert(K <= N);
        string best = str.substr(0, K);
        for (int i = 1; i + K - 1 < N; ++i) {
            best = max(best, str.substr(i, K));
        }
        return best;
    }

    void StressChecker() {
        const int kSeed = 23;
        mt19937 mt(kSeed);
        const auto get_rand = [&mt](const int l, const int r) {
            return uniform_int_distribution <int>(l, r)(mt);
        };
        for (int t = 1; t; ++t) {
            cout << "Test #" << t << endl;
            const int N = get_rand(1, 20);
            string str;
            for (int i = 0; i < N; ++i) {
                str += ('0' + get_rand(1, 4));
            }
            const int K = get_rand(1, N);

            const string sol = GetBestKSlidingWindow(K, str);
            const string sol_brute = GetBestKSlidingWindowBrute(K, str);

            if (sol_brute != sol) {
                cout << "FAILED!!!" << endl;
                cout << "N = " << N << endl;
                cout << "Input: " << str << ' ' << K << endl;
                cout << "Solution printed " << sol << ", while brute said " << sol_brute << endl;
                exit(1);
            } else {
                cout << "OK" << endl;
            }
            cout << endl;
        }
    }
}

namespace Brute {
    string Solve(const Test& t) {
        const vector <int>& freq = t.first;
        const int& K = t.second;

        string str;
        for (int i = 1; i < 10; ++i) {
            for (int j = 0; j < freq[i]; ++j) {
                str += (char)('0' + i);
            }
        }

        string best_window = ":"; // Larger than anything numerical.
        string ans;
        do {
            const string window = Checker::GetBestKSlidingWindowBrute(K, str);//Checker::GetBestKSlidingWindow(K, str);
            if (window < best_window) {
                best_window = window;
                ans = str;
            }
        } while (next_permutation(str.begin(), str.end()));

        return ans;
    }

    void SolveBrute() {
        int T;
        cin >> T;
        while (T--) {
            Test t;
            ReadTest(t);
            cout << Solve(t) << endl;
        }
    }
}

namespace Panaete {

string Solve(Test t) {
    vector <int>& cnt = t.first;
    int& k = t.second;

    string cifraMaxima, cifraMinima, sufix, cif[10]={"0","1","2","3","4","5","6","7","8","9"};
    int nrMaxime = 0, c = 0,lg = 0,lgPlus = 0;
    queue<pair<string,int>> coada;

    /// creez prefixul
    c=9; while(!cnt[c])c--;
    lg=min(k-1,cnt[c]);
    cnt[c]-=lg;
    sufix=string(lg,cif[c][0]);
    while(lg<k-1)
    {
        if(!cnt[c])
            c--;
        else
        {
            lgPlus=min(cnt[c],k-1-lg);
            cnt[c]-=lgPlus;
            lg+=lgPlus;
            sufix=string(lgPlus,cif[c][0])+sufix;
        }
    }

    /// imi izolez "cifra" maxima
    while(cnt[c]==0)c--;
    cifraMaxima=cif[c];nrMaxime=cnt[c];

    /// imi crez coada ordonata din celelalte cifre
    for(int i=1;i<c;i++)coada.push(make_pair(cif[i],cnt[i]));

    /// repet concatenarea cifrei minime la cifra maxima
    while(coada.size())
    {
        /// izolez cifra minima
        string cifraMinima;
        int nrMinime;
        tie(cifraMinima,nrMinime)=coada.front();

        /// O adaug la finalul cifrei maxime de cate ori e posibil
        while(nrMinime>=nrMaxime)
        {
            cifraMaxima=cifraMaxima+cifraMinima;
            nrMinime-=nrMaxime;
        }

        /// daca inca mai am cifre minime atunci transform o parte din cifrlele maxime in "cele mai mari cifre nemaxime"
        if(nrMinime)
        {
            coada.push(make_pair(cifraMaxima+cifraMinima,nrMinime));
            nrMaxime-=nrMinime;
        }
        coada.pop();

    }

    /// afisarea solutiei
    stringstream ss;
    for(;nrMaxime;nrMaxime--)
        ss<<cifraMaxima;
    ss<<sufix;
    return ss.str();
}

vector <string> SolvePanaete(const vector <Test>& tests) {
    const int T = tests.size();
    vector <string> sols(T);
    for (int i = 0; i < T; ++i) {
        sols[i] = Solve(tests[i]);
    }
    return sols;
}

// OKs are just the minimum maximal sliding window of K, not the whole answer.
vector <string> GetOkPanaete(const vector <Test>& tests) {
    const int T = tests.size();
    vector <string> sols(T);
    for (int i = 0; i < T; ++i) {
        const int K = tests[i].second;
        sols[i] = Checker::GetBestKSlidingWindow(K, Solve(tests[i]));
    }
    return sols;
}

void SolvePanaete() {
    int T;
    cin >> T;
    while (T--) {
        Test t;
        ReadTest(t);
        cout << Solve(t) << endl;
    }
}

}

namespace CataFrancu {

#define NIL -1

struct list {
  int next;      /* index of the next digit in this chain */
  int end;       /* index of the last digit in this chain */
  char digit;    /* 0-9 */
  char distinct; /* this list is different from the one to its left */
};

/* print lists in the [from, to) range, limited to max digits */
void print_lists(stringstream &ss, const vector<list>& l, const vector<int>& counts, int from, int to, int max) {
  for (int i = from; i < to; i++) {
    int pos = i;
    while (pos != NIL) {
      if (max) {
        ss << (char)('0' + l[pos].digit);
        max--;
      }
      pos = l[pos].next;
    }
  }
}

string Solve(Test t) {
  vector <int>& counts = t.first;
  int& k = t.second;

  int n = 0, c, i, j;
  for (int i = 1; i < 10; ++i) {
    n += counts[i];
  }

  vector <list> l(n);

  /* initialize N single-digit chains */
  c = 0;
  for (i = 0; i < n; i++) {
    while (!counts[c]) {
      c++;
    }
    l[i].next = NIL;
    l[i].end = i;
    l[i].digit = c;
    l[i].distinct = (!i || (l[i].digit != l[i - 1].digit));
    counts[c]--;
  }

  /* starting index of the rightmost run of identical chains */
  /* (we know the ending index is n - k) */
  int jstart = n - k;
  while (jstart && (l[jstart - 1].digit == l[n - k].digit)) {
    jstart--;
  }

  /* Distribute lists, starting from the left, in round robin fashion, into
     the run of identical chains to the right. In time, the run will shrink
     towards the right. Stop when there are no more elements to distribute to
     the left of the run. */
  i = 0;        /* list currently being distributed */
  j = jstart;   /* list currently being appended to */
  while (i < jstart || j > jstart) { /* stop when i, j and jstart coincide */
    /* append l[i] to l[j] */
    l[l[j].end].next = i;
    l[j].end = l[i].end;

    /* shrink the run if l[i] is distinct from the one before it */
    if (l[i].distinct) {
      l[j].distinct = 1;
      jstart = j;
    }

    i++;
    j++;
    if (j > n - k) {
      j = jstart;
    }
  }

  /* the devil's due is the chain at position n - k, possibly padded to
     length k with larger digits */
  stringstream ss;
  //print_lists(ss, l, counts, n - k, n, k);  /* print the devil's due */
  print_lists(ss, l, counts, jstart, n, n); /* print the complete permutation */
  return ss.str();
}

void SolveCataFrancu() {
    int T;
    cin >> T;
    while (T--) {
        Test t;
        ReadTest(t);
        cout << Solve(t) << endl;
    }
}

}

void StressBruteAgainstSol(function<string(pair <vector <int>, int>)> solve_brute,
                           function<string(pair <vector <int>, int>)> solve) {
    const int kSeed = 23;
    mt19937 mt(kSeed);
    const auto get_rand = [&mt](const int l, const int r) {
        return uniform_int_distribution <int>(l, r)(mt);
    };
    for (int t = 1; t; ++t) {
        cout << "Test #" << t << endl;
        vector <int> freq(10);
        int sum_freq = 0;
        const int MAX_DIGIT = 2;
        for (int i = 1; i <= MAX_DIGIT; ++i) {
            freq[i] = get_rand(0, 40000);
            if (freq[i] == 0 && i == MAX_DIGIT && sum_freq == 0) {
                freq[i] = 1;
            }
            sum_freq += freq[i];
        }
        const int K = get_rand(1, sum_freq);

        const string sol_brute = solve_brute(make_pair(freq, K));
        cout << "Done brute" << endl;

        const string sol_sol = solve(make_pair(freq, K));
        cout << "Done sol" << endl;

        const string window_brute = Checker::GetBestKSlidingWindow(K, sol_brute);
        const string window_sol = Checker::GetBestKSlidingWindow(K, sol_sol);

        if (window_brute != window_sol) {
            cout << "FAILED!!!" << endl;
            cout << "Input: ";
            for (int i = 1; i < 10; ++i) {
                cout << freq[i] << " ";
            }
            cout << "with K = " << K << endl;
            cout << "Sol printed " << endl << sol_sol << endl << "while brute said" << endl << sol_brute << endl;
            cout << "Best window Panaete is " << window_sol << ", while brute achieved " << window_brute << endl;
            exit(1);
        } else {
            cout << "OK" << endl;
        }
        cout << endl;
    }
}

namespace Generator {
    // Utils.
    using TestSuite = vector <Test>;
    const int kSeed = 23;
    mt19937 mt;

    int GetRand(const int l, const int r) {
        return uniform_int_distribution <int>(l, r)(mt);
    };

    vector <int> GetRandComb10(const int k) {
        assert(k <= 9);
        vector <int> perm(9);
        iota(perm.begin(), perm.end(), 1);
        shuffle(perm.begin(), perm.end(), mt);
        perm.resize(k);
        sort(perm.begin(), perm.end());
        return perm;
    }


    // Permute digits in freq such that the maximal nonzero prefix becomes
    // a subsequence, with zeros interleaved.
    // For instance, [1, 2, 3, ...] may become [1, 0, 0, 2, 0, 3, ...].
    vector <int> PickRandomDigits(const vector<int>& freq) {
        assert(freq.size() == 10);
        int last_digit = 9;
        while (last_digit >= 1 && freq[last_digit] == 0) {
            --last_digit;
        }
        if (last_digit >= 1) {
            vector <int> comb = GetRandComb10(last_digit);
            vector <int> ans(10);
            for (int i = 1; i <= last_digit; ++i) {
                ans[comb[i - 1]] = freq[i];
            }
            return ans;
        } else {
            return freq;
        }
    }


    vector <int> MultiplyFreqBy(vector<int> freq, const int by) {
        for (int i = 1; i < 10; ++i) {
            freq[i] *= by;
        }
        return freq;
    }

    // Last argument is subtask specific.
    vector <int> PadByKMinusOne(vector <int> freq, const int K, bool only_pad_at_digit_2) {
        if (only_pad_at_digit_2) {
            freq[2] += K - 1;
            return freq;
        }
        int biggest = 9;
        while (biggest > 0 && freq[biggest] == 0) {
            --biggest;
        }
        assert(biggest > 0);
        for (int i = 1; i < K; ++i) {
            ++freq[GetRand(biggest, 9)];
        }
        return freq;
    }

    vector <int> GenRandFreqByWeights(int N, const vector <int> w, const bool pick_other_digits) {
        assert(!w.empty() && w[0] == 0);
        assert(w.size() <= 10);
        int sum_W = 0;
        for (int i = 1; i < w.size(); ++i) {
            sum_W += w[i];
        }
        auto get_rnd = [&]() {
            int nr = GetRand(1, sum_W);
            for (int j = 1; j < w.size(); ++j) {
                if (nr <= w[j]) {
                    return j;
                } else {
                    nr -= w[j];
                }
            }
            // Shouldn't happen.
            exit(1);
        };

        vector <int> freq(10);
        for (int i = 1; i <= N; ++i) {
            ++freq[get_rnd()];
        }
        if (pick_other_digits) {
            return PickRandomDigits(freq);
        } else {
            return freq;
        }
    }

    // Generates ALL tests of given parameters:
    // Takes total number of digits and how many places in the frequency array to use.
    // exact should only be set to true if precisely N digits need to be generated overall.
    // fixed_K should force a given value of K.
    TestSuite GenAll(const int N, const int digits, const int fixed_K, const bool exact, const bool pick_other_digits) {
        assert(digits <= 9 && digits <= N);
        vector <int> freq(10);
        vector <vector <int>> freqs;
        function<void(int, int)> backtr = [&](int digit, int sum_left) {
            if (sum_left < 0) {
                return ;
            }
            if (digit == digits + 1) {
                if (!exact || sum_left == 0) {
                    freqs.push_back(freq);
                }
                return;
            }
            for (freq[digit] = 1; freq[digit] <= sum_left; ++freq[digit]) {
                backtr(digit + 1, sum_left - freq[digit]);
            }
        };

        backtr(1, N);
        TestSuite tests;
        int sum_N = 0;
        for (const vector <int>& freq : freqs) {
            int sum = 0;
            for (int i = 1; i < 10; ++i) {
                sum += freq[i];
            }
            if (fixed_K == -1) {
                for (int K = 1; K <= sum; ++K) {
                    if (pick_other_digits) {
                        tests.push_back(make_pair(PickRandomDigits(freq), K));
                    } else {
                        tests.push_back(make_pair(freq, K));
                    }
                    sum_N += sum;
                }
            } else {
                if (pick_other_digits) {
                    tests.push_back(make_pair(PickRandomDigits(freq), fixed_K));
                } else {
                    tests.push_back(make_pair(freq, fixed_K));
                }
                sum_N += sum;
            }
        }
        cerr << "Generated by partitions N, digits = " << N << ", " << digits << " with sum N = " << sum_N << " in " << tests.size() << " tests. "<< endl << endl;
        assert(sum_N <= SUM_NMAX);
        assert(tests.size() <= TMAX);
        return tests;
    }

    TestSuite GenRandom(const int N, int cnt, const vector <int>& w, const int k_low, const int k_high, const bool pick_other_digits) {
        assert(1 <= cnt && cnt <= TMAX);
        assert(1 <= k_low && k_low <= k_high && k_high <= N);
        TestSuite test_suite;
        int sum_N = 0;
        for (int t = 0; t < cnt; ++t) {
            // Decrease N slightly.
            const int real_N = GetRand(max(1, 9 * N / 10), N);
            const int real_K = GetRand(min(real_N, k_low), min(real_N, k_high));
            test_suite.emplace_back(GenRandFreqByWeights(real_N, w, pick_other_digits), real_K);
            sum_N += real_N;
        }
        assert(sum_N <= SUM_NMAX);
        return test_suite;
    }

    TestSuite GenGcdPanaete(const int N, int cnt, const vector <int>& w, const int K, const int by, const bool pick_other_digits) {
        assert(1 <= cnt && cnt <= TMAX);
        assert(1 <= K && K <= N);
        assert((N - K + 1) % by == 0);
        TestSuite test_suite;
        int sum_N = 0;
        for (int t = 0; t < cnt; ++t) {
            test_suite.emplace_back(PadByKMinusOne(MultiplyFreqBy(GenRandFreqByWeights(N / by - K + 1, w, pick_other_digits), by), K, !pick_other_digits), K);
            sum_N += N;
        }
        assert(sum_N <= SUM_NMAX);
        return test_suite;
    }

    TestSuite ConcatSuites(const TestSuite& t1, const TestSuite& t2) {
        TestSuite ans(t1);
        for (const auto& t : t2) {
            ans.push_back(t);
        }
        return ans;
    }

    // Tests.
    void ToDisk(const string& stage_name, const int test_index, TestSuite tests) {
        // Shuffle tests before final print.
        shuffle(tests.begin(), tests.end(), mt);

        // File names.
        const string root_name = stage_name + "_" + to_string(test_index);
        const string in_file_name = root_name + ".in";
        const string ok_file_name = root_name + ".ok";

        cerr << "Generating test #" << test_index << " to files " << in_file_name << ", " << ok_file_name << endl;

        // Generate in.
        cerr << "Generating input." << endl;
        ofstream in(in_file_name);
        assert(tests.size() <= TMAX);
        in << tests.size() << endl;
        int sum_N = 0;
        for (const Test& t : tests) {
            const vector <int>& freq = t.first;
            const int K = t.second;

            // Print test input and assert validity.
            assert(1 <= K);
            in << K << endl;
            int N = 0;
            for (int i = 1; i < 10; ++i) {
                N += freq[i];
                in << freq[i] << " \n"[i + 1 == 10];
            }
            assert(K <= N);
            assert(N <= NMAX);
            sum_N += N;
        }

        cerr << "Done generating input, sum is " << sum_N << ", tests are " << tests.size() << endl;
        assert(sum_N <= SUM_NMAX);
        in.close();

        // Generate ok.
        cerr << "Generating oks." << endl;
        ofstream ok(ok_file_name);
        vector <string> answers_panaete = Panaete::GetOkPanaete(tests);

        for (const string& ans : answers_panaete) {
            ok << ans << endl;
        }
        ok.close();
        cerr << "Done generating oks." << endl;
        cerr << endl;
    }

    void GenerateTests() {
        // Subtask 1
        vector <TestSuite> subtask1;
        //   0 <= D1, D2, D3, D4 <= 3
        //   0 <= T <= 1536
        // Test 1
        {
            TestSuite test_suite;
            // Simple enough to generate all by hand.
            vector <int> freq(10);
            for (freq[1] = 0; freq[1] <= 3; ++freq[1]) {
                for (freq[2] = 0; freq[2] <= 3; ++freq[2]) {
                    for (freq[3] = 0; freq[3] <= 3; ++freq[3]) {
                        for (freq[4] = 0; freq[4] <= 3; ++freq[4]) {
                            const int sum_freq = freq[1] + freq[2] + freq[3] + freq[4];
                            for (int K = 1; K <= sum_freq; ++K) {
                                test_suite.emplace_back(freq, K);
                            }
                        }
                    }
                }
            }
            subtask1.push_back(test_suite);
        }

        // Subtask 2
        vector <TestSuite> subtask2;
        // K = 2
        // Test 2
        {
            subtask2.push_back(GenAll(32, 4, 2, false, true));
        }
        // Test 3
        {
            subtask2.push_back(GenAll(53, 3, 2, false, true));
        }
        // Test 4
        {
            subtask2.push_back(GenAll(51, 4, 2, true, true));
        }
        // Test 5
        {
            TestSuite ts = GenAll(21, 5, 2, true, true);
            ts = ConcatSuites(ts,
                           GenAll(21, 6, 2, true, true));
            ts = ConcatSuites(ts,
                           GenAll(22, 4, 2, false, true));
            ts = ConcatSuites(ts,
                           GenAll(43, 3, 2, false, true));
            ts = ConcatSuites(ts,
                           GenAll(21, 2, 2, false, true));
            subtask2.push_back(ts);
        }
        // Test 6
        {
            // Use 3 digits
            TestSuite ts = GenRandom(1000, 1000, {0, 1, 1, 1}, 2, 2, true);
            subtask2.push_back(ts);
        }
        // Test 7
        {
            // Use 4 digits
            TestSuite ts = GenRandom(1000, 1000, {0, 1, 1, 1, 1}, 2, 2, true);
            subtask2.push_back(ts);
        }
        // Test 8
        {
            // Use all digits
            TestSuite ts = GenRandom(1000, 1000, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 2, 2, true);
            subtask2.push_back(ts);
        }
        // Test 9
        {
            // Use all digits
            TestSuite ts = GenRandom(10000, 100, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 2, 2, true);
            subtask2.push_back(ts);
        }
        // Test 10
        {
            // Use all digits
            TestSuite ts = GenRandom(100000, 10, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 2, 2, true);
            subtask2.push_back(ts);
        }

        // Subtask 3
        vector <TestSuite> subtask3;
        // S = D1 + D2
        // Test 11
        {
            subtask3.push_back(GenAll(43, 2, -1, false, false));
        }
        // Test 12
        {
            subtask3.push_back(GenAll(100, 2, -1, true, false));
        }
        // Test 13
        {
            // Use 4 digits
            subtask3.push_back(GenRandom(100000, 10, {0, 1, 1}, 50, 100000, false));
        }
        // Test 14
        {
            // Use all digits
            subtask3.push_back(GenRandom(100000, 10, {0, 1, 1}, 500, 100000, false));
        }
        // Test 15
        {
            TestSuite ts = {};
            for (int i = 1; i <= 10; ++i) {
                int by = GetRand(5, 20);
                const int K = GetRand(10, 50) * by + 1;
                const int N = ((100000 - K + 1)/ by) * by + K - 1;
                ts = ConcatSuites(ts, GenGcdPanaete(N, 1, {0, 1, 1}, K, by, false));
            }
            subtask3.push_back(ts);
        }

        // Subtask 4
        vector <TestSuite> subtask4;
        // No other constraints
        // Test 16
        {
            subtask4.push_back(GenAll(18, 4, -1, false, true));
        }
        // Test 17
        {
            subtask4.push_back(GenAll(25, 3, -1, false, true));
        }
        // Test 18
        {
            subtask4.push_back(GenAll(23, 4, -1, true, true));
        }
        // Test 19
        {
            TestSuite ts = GenAll(16, 5, -1, true, true);
            ts = ConcatSuites(ts,
                           GenAll(14, 6, -1, true, true));
            ts = ConcatSuites(ts,
                           GenAll(14, 4, -1, false, true));
            ts = ConcatSuites(ts,
                           GenAll(18, 3, -1, false, true));
            ts = ConcatSuites(ts,
                           GenAll(20, 2, -1, false, true));
            subtask4.push_back(ts);
        }
        // Test 20
        {
            // Use 4 digits
            TestSuite ts = GenRandom(1000, 1000, {0, 1, 1, 1, 1}, 1, 1000, true);
            subtask4.push_back(ts);
        }
        // Test 21
        {
            // Use all digits
            TestSuite ts = GenRandom(1000, 1000, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 1, 1000, true);
            subtask4.push_back(ts);
        }
        // Test 22
        {
            // Use all digits
            TestSuite ts = GenRandom(10000, 100, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 1, 10000, true);
            subtask4.push_back(ts);
        }
        // Test 23
        {
            // Use all digits
            TestSuite ts = GenRandom(100000, 1, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 75000, 75000, true);
            ts = ConcatSuites(ts, GenRandom(100000, 1, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 25000, 25000, true));
            ts = ConcatSuites(ts, GenRandom(100000, 1, {0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 50000, 50000, true));
            ts = ConcatSuites(ts, GenRandom(100000, 1, {0, 899, 17, 900, 301, 10, 6}, 18, 18, true));
            for (int i = 1; i <= 6; ++i) {
                int by = GetRand(5, 20);
                const int K = GetRand(10, 50) * by + 1;
                const int N = ((100000 - K + 1)/ by) * by + K - 1;
                ts = ConcatSuites(ts, GenGcdPanaete(N, 1, {0, 1, 1, 1, 1, 1}, K, by, true));
            }
            subtask4.push_back(ts);
        }

        int group = 0;
        for (const auto& subtask : {subtask1, subtask2, subtask3, subtask4}) {
            for (int t = 0; t < subtask.size(); ++t) {
                ToDisk("devil_subtask_" + to_string(group + 1), t + 1, subtask[t]);
            }
            ++group;
        }
    }
}

int main() {
    //freopen("devil_subtask_1_1.in", "r", stdin);
    //freopen("ceva.out", "w", stdout);

    //Panaete::SolvePanaete();
    //Brute::SolveBrute();

    //Checker::StressChecker();
    //StressBruteAgainstSol(Brute::Solve, CataFrancu::Solve);
    //StressBruteAgainstSol(CataFrancu::Solve, Panaete::Solve);

    Generator::GenerateTests();

    return 0;
}
