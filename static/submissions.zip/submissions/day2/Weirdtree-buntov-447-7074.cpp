/**
* user:  buntov-447
* fname: Atanas Todorov
* lname: Buntov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:35:13.724688
*/
#include <iostream>
#include<algorithm>
#include "weirdtree.h"

int he[81000],i,n;

void initialise(int N, int Q, int h[]) {
n=N;
	for(i=1;i<=N;i++)he[i]=h[i];
}
void cut(int l, int r, int k) {
	pair<int,int> a[1100];
	for(i=0;i<(r-l+1);i++)a[i] = {he[i+l],i+l};
	sort(a,a+(r-l+1));
	int pp[1100];
	pp[(r-l+1)]=0;
	for(i=(r-l);i>=0;i--)pp[i] = pp[i+1]+a[i].first;
	if(pp[0]>=k){
	int t=r-l,br=0;
	while(t>0)
    {
        if((pp[t+1]-br*a[t].first)>= k)break;
        else {t--;br++;}
    }
    t++;
    for(i=t;i<(r-l+1);i++){k-=(a[i].first-a[t].first);a[i].first=a[t].first;}
    for(i=0;i<(r-l+1);i++)he[a[i].second] = a[i].first;
	for(int j=0;j<k;j++){
    int maxx=-1,pos;
	for(i=l;i<=r;i++)
    {
        if(he[i] > maxx){maxx=he[i];pos=i;}
    }
    //cout<<pos<<endl;
    if(he[pos]>0){he[pos]--;}
    else break;
	}
	}
	else
    {
        for(i=l;i<=r;i++)he[i]=0;
    }
}
void magic(int i, int x) {
	he[i]=x;
}
long long int inspect(int l, int r) {
	long long int sum=0;
	for(i=l;i<=r;i++)sum+=he[i];
	return sum;
}
