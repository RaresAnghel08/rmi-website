/**
* user:  bozhkov-3b7
* fname: Denis Petrov
* lname: Bozhkov
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:59:43.968898
*/
#include<iostream>
#include<cstring>
using namespace std;
#define MOD 1000000007
#define MAXN 4000
int first;
int N2;
int placed[MAXN/2][2];
int M;
int fill(int i)
{
	if(i==N2)return 1;
	for(int n=0;n<N;n++)
	{
		if(placed[i][0]==0&&placed[i][1]==0)
		{
			placed[i][0]=i;
			fill(i+1);
			placed[i][0]=0;
			placed[i][1]=i;
			fill(i+1);
			placed[i][1]=0;
		}
		if(placed[i][0]&&placed[i][1])
			continue;
		if(placed[i][0])
		{
			if(i-placed[i][0])%M!=0)
			{
				placed[i][1]=i;
				fill(i+1);
				placed[i][1]=0;
			}
		}
		else
			if(i-placed[i][1])%M!=0)
			{
				placed[i][0]=i;
				fill(i+1);
				placed[i][0]=0;
			}
	}
}
int main()
{
	int N;
	cin>>N>>M;
	N2=N*2;
	cout<<fill(0);
	return 0;
}