/**
* user:  salomon-bcd
* fname: Mayan
* lname: Salomon
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:08:15.134534
*/
#include <bits/stdc++.h> 

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<bool> vb;
typedef pair<int, int> pii;
typedef vector<pii> vp;

vector<vector<pii>> graph;
vector<vector<pii>> graphr;

vector<vector<pii>> graph2;


vi par;
vi leafs;
vi paredgegindex;
vi costs;
bool findLeaf = true;

vi par2;
vi leafs2;
vi paredgegindex2;
vi costs2;
vb s1l;
vi newc1;
vb s2l;
vi newc2;
vi dist1;
vi dist2;
int kl;
bool findLeaf2 = true;
int root;
void dfs(int v, int p, int c) {
    if (findLeaf && graph[v].size() == 1) {
        leafs.push_back(v);
    }
    costs[v] = c;
    par[v] = p;
    for (int i = 0; i < graph[v].size(); i++) {
        int u = graph[v][i].first;
        int w = graph[v][i].second;
        if (u != p) {
            paredgegindex[u] = i;
            dfs(u, v, c + w);        
        }
    }
}

void dfs2(int v, int p, int c) {
    if (findLeaf2 && graph2[v].size() == 1) {
        leafs2.push_back(v);
    }
    costs2[v] = c;
    par2[v] = p;
    for (int i = 0; i < graph2[v].size(); i++) {
        int u = graph2[v][i].first;
        int w = graph2[v][i].second;
        if (u != p) {
            paredgegindex2[u] = i;
            dfs2(u, v, c + w);
        }
    }
}

int dfs5(int v, int p) {

    int dist=0;
    for (int i = 0; i < graphr[v].size(); i++) {
        int u = graphr[v][i].first;
        int w = graphr[v][i].second;
        if (u != p) {
            dist = max(dist, dfs5(u, v) + w);
        }
    }

    if (s1l[v]) {
        //dist1[v] = 0;
        return 0;
    }
    //dist1[v] = dist;
    return dist;
}

int dfs6(int v, int p) {

    int dist = 0;
    for (int i = 0; i < graphr[v].size(); i++) {
        int u = graphr[v][i].first;
        int w = graphr[v][i].second;
        if (u != p) {
            dist = max(dist, dfs6(u, v) + w);
        }
    }

    if (s2l[v]) {
        //dist2[v] = 0;
        return 0;
    }
    //dist2[v] = dist;
    return dist;
}

int updategraph(int v) {
    int ans = 0;
    if (par[v] == -1) return ans;
    ans += graph[par[v]][paredgegindex[v]].second;
    graph[par[v]][paredgegindex[v]].second = 0;
    ans += updategraph(par[v]);
    return ans;
}

int updategraph2(int v) {
    int ans = 0;
    if (par2[v] == -1) return ans;
    ans += graph2[par2[v]][paredgegindex2[v]].second;
    graph2[par2[v]][paredgegindex2[v]].second = 0;
    ans += updategraph2(par2[v]);
    return ans;
}



int dfs3(int v, int p, int c, bool a) {
    if (a) {
        newc1[v] = c;
    }
    int way = 0;
    for (int i = 0; i < graph[v].size(); i++) {
        int u = graph[v][i].first;
        int w = graph[v][i].second;
        if (u != p) {
            if (w != 0) {
                way += dfs3(u, v, graphr[v][i].second, true);
            }
            else {
                if (dist1[u] > dist1[v]) {
                    way += dfs3(u, v, -graphr[v][i].second, true);

                }
                else {
                    way += dfs3(u, v, 0, true);

                }
                //way += dfs3(u, v, graphr[v][i].second, false);

            }
        }
    }
    if (!a) {
        newc1[v] = -c;
        //if (way != kl) {
            //newc1[v] = 0;
            //return way + s1l[v];
        //}
        //else newc1[v] = -c;
    }
    return way+s1l[v];
}



int dfs4(int v, int p, int c, bool a) {
    if (a) {
        newc2[v] = c;
    }
    int way = 0;
    for (int i = 0; i < graph2[v].size(); i++) {
        int u = graph2[v][i].first;
        int w = graph2[v][i].second;
        if (u != p) {
            if (w != 0) {
                way += dfs4(u, v, graphr[v][i].second, true);
            }
            else {
                if (dist1[u] > dist1[v]) {
                    way += dfs4(u, v, -graphr[v][i].second, true);

                }
                else {
                    way += dfs4(u, v, 0, true);

                }
                //way += dfs4(u, v, graphr[v][i].second, false);
            }
        }
    }
    if (!a) {
        newc2[v] = -c;
        //if (way != kl) {
            //newc2[v] = 0;
            //return way + s2l[v];
        //}
        //else newc2[v] = -c;
    }
    return way+s2l[v];
}


int findchoosenleaf(int n, int k, int root) {
    vi choosenleaf;
    //root = 1;
    leafs.clear();
    findLeaf = true;

    costs.clear();
    costs.resize(n+1);
    dfs(root, -1, 0);
    findLeaf = false;
    vb allc(n + 1, false);
    vb chosen(leafs.size(), false);
    int sum = 0;
    int counter = 0;
    while (counter<k)
    {
        int maxc = 0;
        int maxindex = -1;
        int l = 0;
        for (int i = 0; i < leafs.size(); i++) {
            if (!chosen[i] && costs[leafs[i]] > maxc) {
                maxc = costs[leafs[i]];
                maxindex = leafs[i];
                l = i;
            }
        }
        if (maxc == 0)break;
        sum += maxc;
        chosen[l] = true;
        allc[maxindex] = true;
        choosenleaf.push_back(maxindex);
        updategraph(maxindex);
        dfs(root, -1, 0);

        counter++;
    }

    kl = choosenleaf.size();
    return sum;

    dfs2(choosenleaf[0], -1, 0);
    findLeaf2 = false;
    int sum2 = 0;
    for (int i = 1; i < choosenleaf.size(); i++) {
        sum2+= updategraph2(choosenleaf[i]);
    }

    dfs2(choosenleaf[0], -1, 0);

    int maxc = 0;
    int maxindex = -1;
    for (int i = 0; i < leafs2.size(); i++) {
        if (!allc[leafs2[i]] && costs2[leafs2[i]] > maxc) {
            maxc = costs2[leafs2[i]];
            maxindex = leafs2[i];
        }
    }
    updategraph2(maxindex);
    sum2 += maxc;
    int otheleaf = maxindex;

    for (int i = 0; i < choosenleaf.size(); i++) {
        s1l[choosenleaf[i]] = true;
        s2l[choosenleaf[i]] = true;
    }
    s2l[otheleaf] = true;
    //s2l[choosenleaf[0]] = false;

    //dfs5(root, -1);
    //dfs6(choosenleaf[0], -1);
    for (int i = 1; i <= n; i++) {
        dist1[i]= dfs5(i, -1);
        dist2[i]= dfs6(i, -1);
    }

    dfs3(root, -1, 0, 1);
    dfs4(choosenleaf[0], -1, 0, 1);

    vi ans(n+1);
    for (int i = 1; i <= n; i++) {
        if (!s1l[i]) {
            ans[i] =sum + newc1[i];
        }

        else {
            ans[i] = max(ans[i], sum2 + newc2[i]);
        }
    }
    //return ans;

    int hey = 0;
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int n, k;
    cin >> n >> k;

    vector<vector<pii>> oggraph(n + 1);
    int a, b,w;
    for (int i = 0; i < n-1; i++) {
        cin >>a >>b >>w;
        oggraph[a].push_back({ b ,w});
        oggraph[b].push_back({ a,w });
    }
    graph = oggraph;
    graph2 = oggraph;
    graphr = oggraph;

    par.resize(n+1);
    //leafs.resize(n + 1);
    paredgegindex.resize(n + 1);
    costs.resize(n + 1);

    par2.resize(n + 1);
    //leafs2.resize(n + 1);
    paredgegindex2.resize(n + 1);
    costs2.resize(n + 1);

    s1l.resize(n + 1);
    newc1.resize(n + 1);
    s2l.resize(n + 1);
    newc2.resize(n + 1);
    dist1.resize(n + 1);
    dist2.resize(n + 1);

    vi ans(n+1);
    for (int i = 1; i <= n; i++) {
        graph = oggraph;

        ans[i]= findchoosenleaf(n, k,i);
    }

    for (int i = 1; i <= n; i++) {
        cout << ans[i] << endl;
    }
    return 0;
}
