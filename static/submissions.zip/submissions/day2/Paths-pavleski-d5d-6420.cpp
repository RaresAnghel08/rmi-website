/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Paths
* score: 36.0
* date:  2021-12-17 10:51:42.443825
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)

using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int mxn = 2005;
int n;
vector<pii> g[mxn];
mt19937 _rand(time(NULL));

int par[mxn];
int paw[mxn];
int dep[mxn];

ll sum[mxn];
ll ans[mxn];
ll ANS1;
ll ANS2;

ll submax[mxn];


int D;
ll dis = 0;

void dfs0(int u, int p, ll w){
	if(w > dis){
		dis = w;
		D = u;
	}
	for(auto e : g[u]){
		if(e.st == p) continue;
		dfs0(e.st, u, w + e.nd);
	}
}

void dfs(int u, int p){
	par[u] = p;
	submax[u] = sum[u];
	
	for(auto e : g[u]){
		if(e.st == p) continue;
		sum[e.st] = sum[u] + e.nd;
		paw[e.st] = e.nd;
		dep[e.st] = dep[u] + 1;
		dfs(e.st, u);
		submax[u] = max(submax[u], submax[e.st]);
	}
}
bool isleaf[mxn];
vector<int> G;
vector<int> L;

ll collect(int r, int k){
	G.clear();
	memset(isleaf, false, sizeof(isleaf));
	isleaf[r] = true;
	sum[r] = 0;
	dfs(r,r);
	pq<pair<ll, int> > Q;
	for(auto e : g[r]){
		Q.push({submax[e.st], e.st});
	}
	ll ans = 0;
	int rem = k-1;
	vector<int> v;
	while(!Q.empty()){
		int u = Q.top().nd;
		Q.pop();
		
		if(isleaf[par[u]]){
			isleaf[par[u]] = false;
			isleaf[u] = true;
		}
		else{
			if(rem == 0) continue;
			--rem;
			isleaf[u] = true;
			
		}
		v.pb(u);
		ans += paw[u];
		for(auto e : g[u]){
			if(e.st == par[u]) continue;
			Q.push({submax[e.st] - sum[u], e.st});
		}
	}
	for(auto u : v){
		if(isleaf[u]){
			G.pb(u);
		}
	}
	return ans;
}

bool colored[mxn];
void dfs2(int u, int p){
	for(auto e : g[u]){
		if(e.st == p) continue;
		dfs2(e.st, u);
		if(colored[e.st]){
			colored[u] = true;
		}
	}
}

void dfs3(int u, int p, ll w){
	if(colored[u]) w = 0;
	else{
		ans[u] = ANS1 + w;
	}
	for(auto e : g[u]){
		if(e.st == p) continue;
		dfs3(e.st, u, w + e.nd);
	}
}
int k;
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	
	cin >> n >> k;
	fr(i, 0, n-1){
		int u, v, c;
		cin >> u >> v >> c;
		--u, --v;
		g[u].pb({v, c});
		g[v].pb({u, c});
	}
	if(k <= 2){
		fr(i, 0, n){
			cout<<collect(i, k)<<endl;
		}
		return 0;
	}
	if(n == 1){
		cout<<0<<endl;
		return 0;
	}
	if(n == 2){
		cout<<g[0][0].nd<<endl;
		cout<<g[0][0].nd<<endl;
		return 0;
	}
	dfs0(0, 0, 0);
	
	
	ANS1 = collect(D, k-1);
	G.pb(D);
	L = G;
	ANS2 = collect(D, k);
	
	for(auto u : L) colored[u] = true;
	dfs2(D, D);
	dfs3(D, D, 0);
	fr(i, 0, n){
		if(colored[i]) ans[i] = ANS1;
	}
	
	
	fr(i, 0, n){
		ans[i] = collect(i, k);
	}	
	for(auto u : L){
		ans[u] = ANS2;
	}
	fr(i, 0, n){
			cout<<ans[i]<<endl;
	}
	
	
	/*
	
	
	
	
	int rrr = 0;
	fr(i, 0, n){
		if(g[i].size() > 1){
			rrr = i;
			break;
		}
	}
	
	collect(rrr);
	L = G;
	
	for(auto u : G) colored[u] = true;
	int lc = lca();
	
	
	collect(lc);
	L = G;
	
	memset(colored, false, sizeof(colored));
	for(auto u : G) colored[u] = true;
	int LC = lca();




	
	dfs2(LC, LC);
	dfs3(LC, LC, 0);
	//ll ans2 = collect(L[0]);
	fr(i, 0, n){
		if(colored[i]){
			ans[i] = ANS;
		}
	}
	
	for(auto u : L){
		ans[u] = collect(u);
	}
	
	fr(i, 0, n){
		cout<<ans[i]<<endl;
	}*/
}
