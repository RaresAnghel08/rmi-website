/**
* user:  metehau-bba
* fname: Luca
* lname: Metehau
* task:  Paths
* score: 19.0
* date:  2021-12-17 09:16:41.026856
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
#define ll long long
#define ld long double
#define x first
#define y second
#define pii pair <int, int>

using namespace std;

int n, k, x, y, z;

vector <pii> g[2005];
ll dp[2005][2005];
int sz[2005], t[2005];

void dfs(int nod, int tata = 0) {
  for(int i = 0; i <= k; i++)
    dp[nod][i] = 0;

  sz[nod] = (g[nod].size() == 1 && tata);

  for(auto &i : g[nod]) {
    int fiu = i.x, cost = i.y;
    if(fiu == tata)
      continue;

    dfs(fiu, nod);

    sz[nod] += sz[fiu];

    for(int i = k; i >= 0; i--) {
      if(i && !dp[nod][i])
        continue;

      for(int j = min(sz[fiu], k - i); j >= 1; j--)
        dp[nod][i + j] = max(dp[nod][i + j], dp[nod][i] + dp[fiu][j] + cost);
    }
  }

  /*cout << "nod : " << nod << "\n";
  for(int i = 1; i <= k; i++)
    cout << dp[nod][i] << " ";
  cout << "\n";*/
}

multiset <pair <ll, int>> s;
map <pair <int, int>, bool> marked;
ll sum[200005];

void build(int nod, int tata = 0) {
  t[nod] = tata;
  for(auto &i : g[nod]) {
    int fiu = i.x, cost = i.y;
    if(fiu == tata)
      continue;

    sum[fiu] = sum[nod] + cost;
    build(fiu, nod);
  }

  s.insert({sum[nod], nod});
}

void dfs2(int nod, ll d) {
  for(auto &i : g[nod]) {
    int fiu = i.x, cost = i.y;
    if(fiu == t[nod] || marked[make_pair(nod, fiu)])
      continue;

    dfs2(fiu, d);
  }

  s.erase(s.find({sum[nod], nod}));
  sum[nod] -= d;
  s.insert({sum[nod], nod});
}

int main() {
  cin >> n >> k;

  srand(time(0));
  //n = rand() % 100 + 1, k = rand() % min(n, 10) + 1;
  //cout << n << " " << k << "\n";

  for(int i = 1; i < n; i++) {
    cin >> x >> y >> z;
    //x = rand() % i + 1, y = i + 1, z = rand() % 10;
    //cout << x << " " << y << " " << z << "\n";
    g[x].push_back({y, z});
    g[y].push_back({x, z});
  }

  for(int i = 1; i <= n; i++) {
    s.clear();
    marked.clear();
    sum[i] = 0;
    build(i);

    ll ans = 0;
    for(int j = 1; j <= k; j++) {
      pair <ll, int> p = *prev(s.end());

      /*cout << p.x << " " << p.y << "\n";
      cout << "in set : ";
      for(auto &l : s)
      cout << "(" << l.x << ", " << l.y << "), ";
      cout << "\n";*/

      ans += p.x;
      while(p.y != i && !marked[make_pair(p.y, t[p.y])]) {
        //cout << "updating from " << p.y << " with " << sum[p.y] << "\n";
        dfs2(p.y, sum[p.y]);
        marked[make_pair(p.y, t[p.y])] = marked[make_pair(t[p.y], p.y)] = 1;
        p.y = t[p.y];
      }
    }
    cout << ans << "\n";
    /*dfs(i);

    cout << dp[i][k] << "\n";
    assert(!dp[i][k] || ans == dp[i][k]);*/
  }
  return 0;
}
