/**
* user:  chertes-cab
* fname: Andrei
* lname: Chertes
* task:  Paths
* score: 8.0
* date:  2021-12-17 11:48:19.233230
*/
#include <bits/stdc++.h>

using namespace std;

int N, K;
vector<int> parent;
vector<bool> visited;
vector<vector<int>> edges;
vector<vector<bool>> visited_edge;
vector<vector<int>> edge_cost;
vector<bool> frunza;

void bfs(int start) {
    visited = vector<bool> (N + 1, 0);
    parent = vector<int> (N + 1, 0);

    queue<int> q;

    q.push(start);
    visited[start] = 1;

    while(!q.empty()) {
        int node = q.front();
        q.pop();

        for(auto vecin: edges[node]) {
            if(!visited[vecin]) {
                q.push(vecin);
                visited[vecin] = 1;
                parent[vecin] = node;
            }
        }
    }
}

long long sum_max;
int st[19];

long long calc_sum() {
    visited_edge = vector<vector<bool>> (N + 1, vector<bool> (N + 1));
    long long sum = 0;
    for(int i = 1; i <= K; i++) {
        int fr = st[i];

        while(parent[fr] != 0) {
            if(!visited_edge[fr][parent[fr]]) {
                sum += edge_cost[fr][parent[fr]];
                visited_edge[fr][parent[fr]] = 1;
            }
            fr = parent[fr];
        }
    }
    return sum;
}

void bkt(int p) {
    for(int i = st[p - 1] + 1; i <= N; i++) {
        if(!frunza[i]) {
            continue;
        }

        st[p] = i;

        if(p == K) {
            sum_max = max(sum_max, calc_sum());
        } else {
            bkt(p + 1);
        }
    }
}

int main() {
    cin >> N >> K;

    edges = vector<vector<int>> (N + 1);
    edge_cost = vector<vector<int>> (N + 1, vector<int> (N + 1, 0));

    for(int i = 1; i < N; i++) {
        int a, b, c;
        cin >> a >> b >> c;

        edges[a].push_back(b);
        edges[b].push_back(a);
        edge_cost[a][b] = c;
        edge_cost[b][a] = c;
    }

    for(int root = 1; root <= N; root++) {
        bfs(root);
        frunza = vector<bool> (N + 1, 1);
        for(int i = 1; i <= N; i++) {
            frunza[parent[i]] = 0;
        }
        sum_max = 0;
        bkt(1);

        cout << sum_max << '\n';
    }
    return 0;
}
