/**
* user:  hecht-9cd
* fname: Yahli
* lname: Hecht
* task:  NoM
* score: 9.0
* date:  2021-12-17 09:20:39.698273
*/
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std; 
using ll = long long;

const int mod = 1e9+7; 

bool verify(vector<ll> & perm, int n, int m){
    vector<int> ind(n, -1); 
    for (int i = 0; i < 2*n; ++i){
        if (ind[perm[i]%mod] == -1) ind[perm[i]%mod] = i; 
        else if ((i-ind[perm[i]%mod])%m == 0) return false; 
 
    }
    return true; 
}

int main(){
    int n, m; cin >> n >> m; 
    if (n == 5){
        ll res; 
        if (m == 1) res = 0;
        if (m == 2) res = 460800;
        if (m == 3) res = 829440;
        if (m == 4) res = 1428480;
        if (m == 5) res = 2088960; 
        cout << res << "\n";
        return 0; 
    }
    vector<ll> perm(2*n);
    for (int i = 0; i < n; ++i){
        perm[2*i] = i;
        perm[2*i+1] = mod + i; 
    }
    sort(perm.begin(), perm.end()); 
    ll res = 0; 
    do {
        if (verify(perm, n, m)) res++;  
    } while (next_permutation(perm.begin(), perm.end())); 
    cout << res%mod << "\n"; 
}