/**
* user:  idiriz-fcd
* fname: Nermin Hyusmen
* lname: Idiriz
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 11:23:27.580855
*/
#include<bits/stdc++.h>
#include "weirdtree.h"
const int MAXN=80010;
int n,q,height[MAXN];
void initialise(int N, int Q, int h[])
{
    n=N;
    q=Q;
    for(int i=1; i<=n; i++)
        height[i]=h[i];
}
void cut(int l, int r, int k)
{
    if(l==r)
    {
        if(height[l]>=k)
        {
            height[l]-=k;
        }
        else
        {
            height[l]=0;
        }
        return;
    }
    long long suma=0;
    for(int i=l; i<=r; i++)
        suma+=(long long)(height[i]);
    while(k>0&&suma>0)
    {
        int max1=-1,max2=-1;
        int maxx[MAXN],cnt=0;
        for(int i=l; i<=r; i++)
        {
            if(max1==-1||height[i]>height[max1])
            {

                max2=max1;
                max1=i;
                maxx[1]=i;
                cnt=1;
            }
            else if(max1!=-1&&height[i]==height[max1])
            {
                maxx[cnt+1]=i;
                cnt++;
            }
            else if(max2==-1||height[i]>height[max2]&&height[i]!=height[max2])
            {
                max2=i;
            }
        }
        int diff=height[max1]-height[max2];
        int i=1;
        while(k>0&&i<=cnt)
          {
            if(diff>=k)
            {
                height[maxx[i]]-=k;
                suma-=k;
                k=0;
            }
            else
            {
                height[maxx[i]]-=diff;
                suma-=diff;
                k-=diff;
            }
            i++;
        }
    }
}
void magic(int i, int x)
{
    height[i]=x;
}
long long int inspect(int l, int r)
{
    long long int ans=0;
    for(int i=l; i<=r; i++)
        ans+=height[i];
    return ans;
}
