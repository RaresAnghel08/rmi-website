/**
* user:  savu-e4c
* fname: Ştefan Cătălin
* lname: Savu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:43:36.860839
*/
#include <iostream>
#include "weirdtree.h"
using namespace std;
pair<long long,pair<long long,long long> > ar[3000005];
int n;
pair<long long,pair<long long,long long> > my(pair<long long,pair<long long,long long> > a,pair<long long,pair<long long,long long> > b)
{
    if (a.second.first>b.second.first) return a;
    if (a.second.first<b.second.first) return b;
    if (a.second.second<b.second.second) return a;
    return b;
}
void update (int st,int dr,int nod,int poz,long long val)
{
    if (st==dr)
    {
        ar[nod].first=val;
        ar[nod].second.first=val;
        ar[nod].second.second=st;
        return;
    }
    int mij=(st+dr)/2;
    if (poz<=mij) update(st,mij,nod*2,poz,val);
    else update(mij+1,dr,nod*2+1,poz,val);
    ar[nod].first=ar[nod*2].first+ar[nod*2+1].first;
    ar[nod].second=my(ar[nod*2],ar[nod*2+1]).second;
}
pair<long long,pair<long long,long long> > query(int st,int dr,int nod,int qa,int qb)
{
    if (qa<=st&&dr<=qb)
        return ar[nod];
    int mij=(st+dr)/2;
    pair<long long,pair<long long,long long> > ras1,ras2;
    ras1.first=ras1.second.first=ras1.second.second=ras2.first=ras2.second.first=ras2.second.second=-1;
    if (qa<=mij) ras1=query(st,mij,nod*2,qa,qb);
    if (qb>mij) ras2=query(mij+1,dr,nod*2+1,qa,qb);
    return make_pair(ras1.first+ras2.first,my(ras1,ras2).second);
}
void initialise(int N, int Q, int h[]) {
    n=N;
    for (int i=1;i<=N;++i)
        {update(1,n,1,i,h[i]);}
}
void cut(int l, int r, int k) {
    update(1,n,1,query(1,n,1,l,r).second.second,query(1,n,1,l,r).second.first-1);
}
void magic(int i, int x) {
    update(1,n,1,i,x);
}
long long int inspect(int l, int r) {
	return query(1,n,1,l,r).first;
	return -1;
}
