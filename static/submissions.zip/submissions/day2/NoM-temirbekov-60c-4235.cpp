/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  NoM
* score: 0.0
* date:  2021-12-17 07:23:36.257371
*/
#include <bits/stdc++.h>

using namespace std;

signed main(void) {
	int n, m;
	cin >> n >> m;
	vector <int> a;
	for(int i = 1; i <= n; i ++){
		a.push_back(i);
		a.push_back(i);
	}
	int cnt = 0;
	do{
		vector <int> idx(n + 1);
		for(int i = 0; i < a.size(); i ++) {
			if(idx[a[i]] == 0) {
				idx[a[i]] = i + 1;
			}else if((abs(idx[a[i]]) - (i + 1) + 1) % m == 0){ 
				goto end;
			}
		}
		cnt ++;
		end:;
	}while(next_permutation(a.begin(), a.end()));
	cout << cnt;
	return false;
}