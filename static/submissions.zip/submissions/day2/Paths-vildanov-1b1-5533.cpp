/**
* user:  vildanov-1b1
* fname: Ruslan
* lname: Vildanov
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:39:02.990984
*/
#include "weirdtree.h"
#ifdef LOCAL
    //#define _GLBCXX_DEBUG
#endif // LOCAL
#include <bits/stdc++.h>
using namespace std;

#define int long long
#define f first
#define s second
#define endl '\n'

int k;
int n;
vector <vector <pair <int,int> > > g;
vector <int> used;
vector <int> d;
vector <int> a;
int now=0;
vector <pair <int,int> > pos;
vector <int> par;
vector <int> c;
vector <int> num;
void dfs(int v)
{
    used[v]=1;
    pos[v].f=now;
    pos[v].s=now++;
    a.push_back(d[v]);
    num.push_back(v);
    bool need=0;
    for (auto i:g[v]){
        int u=i.f;
        int w=i.s;
        if (used[u])continue;
        need=1;

        c[u]=w;
        par[u]=v;
        d[u]=d[v]+w;

        dfs(u);
    }
    if (need){
        pos[v].s=now++;
        a.push_back(d[v]);
        num.push_back(v);
    }
}

vector <int> add;
vector <pair <int,int> > t;

void push(int v, int l, int r)
{
    if (add[v]==0)return;
    t[v].f+=add[v];
    if (l==r)return;
    add[v*2]+=add[v];
    add[v*2+1]+=add[v];
    add[v]=0;
}

void build(int v, int l, int r)
{
    if (l==r){
        t[v]={a[l],l};
        return;
    }
    int m=(l+r)>>1;
    build(v*2,l,m);
    build(v*2+1,m+1,r);
    t[v]=max(t[v*2],t[v*2+1]);
}

void update(int v, int l, int r, int A, int B, int x)
{
    //cout << v << " " << l << " " << r << " " << A << " " << B << " " << x << endl;
    push(v,l,r);
    if (r<A || B<l)return;
    if (A<=l && r<=B){
        add[v]+=x;
        push(v,l,r);
        return;
    }
    int m=(l+r)>>1;
    update(v*2,l,m,A,B,x);
    update(v*2+1,m+1,r,A,B,x);
    t[v]=max(t[v*2],t[v*2+1]);
}

pair <int,int> get(int v, int l, int r, int A, int B)
{
    push(v,l,r);
    if(A<=l && r<=B)return t[v];
    if (r<A || B<l)return {-1,-1};
    int m=(l+r)>>1;
    return max(get(v*2,l,m,A,B),get(v*2+1,m+1,r,A,B));
}

int solve(int s)
{
    now=0;
    a.resize(0);
    used.assign(n,0);
    d.assign(n,0);
    c.assign(n,0);
    par.assign(n,s);
    pos.assign(n,{-1,-1});
    num.resize(0);

    dfs(s);

    int m=a.size();
    add.assign(4*m+5,0);
    t.assign(4*m+5,{-1,-1});


    build(1,0,m-1);
    /*for (int i:num)cout << i+1 << " ";
    cout << endl;
    for (int i=0; i<n; i++){
        cout << pos[i].f << " " << pos[i].s << endl;
    }*/

    int ans=0;
    for (int i=0; i<k; i++){
            /*for (int j=0; j<m; j++){
                cout << get(1,0,m-1,j,j).f << " ";
            }
            cout << endl;*/
        auto w=get(1,0,m-1,0,m-1);
        //cout << "!!! " << w.f << " " << w.s << endl;
        //cout << endl;
        int v=num[w.s];
        ans+=w.f;

        //cout << "v: " << v+1 << " " << ans << endl;
        while (v!=s){
            update(1,0,m-1,pos[v].f,pos[v].s,-c[v]);
            c[v]=0;
            v=par[v];
        }
    }
    return ans;
}

signed main()
{
#ifdef LOCAL
#else
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie();
#endif // LOCAL
    cin >> n >> k;
    g.resize(n);
    for (int i=0; i<n-1; i++){
        int v,u,w;
        cin >> v >> u >> w;
        v--;
        u--;
        g[v].push_back({u,w});
        g[u].push_back({v,w});
    }
    for (int v=0; v<n; v++){
        int x=solve(v);
        cout << x << endl;
    }
}
/**
6 10
1 2 3 1 2 3
1 1 6 3
3 1 6
1 1 3 3
3 1 6
1 1 3 1000
3 1 6
2 1 1000
3 1 6
1 1 3 999
3 1 5
*/
