/**
* user:  bozhkov-3b7
* fname: Denis Petrov
* lname: Bozhkov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:13:42.200272
*/
#include "weirdtree.h"
#include<cstdio>
#include<math.h>
#include<cstring>
using namespace std;
#define TREESIZE 524288
long long int sum_tree[TREESIZE];
int max_tree[TREESIZE];
int level;
int int_log(int t)
{
	int n;
	for(n=0;t>0;n++,t>>=1);
	return n;
}
//int h[]={0,1,2,3,1,2,3};
int h[300001];
int n;

void max_tree_build(int* h,int n)
{
	memset(max_tree,0,1<<(level+1));
	for(int i=1;i<=n;i++)
		max_tree[i-1+(1<<level)]=i;
	for(int i=(1<<level)-1;i>=1;i--)
		if(h[max_tree[i*2]]>=h[max_tree[i*2+1]])
			max_tree[i]=max_tree[i*2];
		else max_tree[i]=max_tree[i*2+1];
}
void sum_tree_build(int* h,int n)
{
	memset(sum_tree,0,1<<(level+1));
	for(int i=1;i<=n;i++)
		sum_tree[i-1+(1<<level)]=h[i];
	for(int i=(1<<level)-1;i>=1;i--)
		sum_tree[i]=sum_tree[i*2]+sum_tree[i*2+1];
}

void change(int index,int value)
{
	int dist=h[index]-value;
	h[index]=value;
	int i=(1<<level)+index-1;
	while(i>0)
	{
		sum_tree[i]-=dist;
		if(h[max_tree[i]]<value||(h[max_tree[i]]==value&&max_tree[i]<index))
			max_tree[i]=index;
		i>>=1;
	}
}
int mymax(int i,int j)
{
	if(h[max_tree[i]]>h[max_tree[j]])
		return i;
	if(h[max_tree[i]]==h[max_tree[j]]&&max_tree[i]<max_tree[j])
		return i;
	return j;
}
int max_tree_query(int l,int r)
{
	int max=mymax(l,r);
	while(l!=r)
	{
		if(l%2==0&&l+1!=r)
			max=mymax(max,l+1);
		if(r%2==1&&r-1!=l)
			max=mymax(max,r-1);
		l/=2;
		r/=2;
	}
	return max;
}
long long int sum_tree_query(int l,int r)
{
	long long int sum=sum_tree[l]+sum_tree[r];
	while(l!=r)
	{
		if(l%2==0&&l+1!=r)
			sum+=sum_tree[l+1];
		if(r%2==1&&r-1!=l)
			sum+=sum_tree[r-1];
		l/=2;
		r/=2;
	}
	return sum;
}

void initialise(int N,int Q,int h[])
{
	n=N;
	level=int_log(N);
	memcpy(::h,h,(N+1)*(sizeof(int)));
	sum_tree_build(h,N);
	max_tree_build(h,N);
}
void cut(int l, int r, int k) {
	int tmp;
	while(k--)
	{
		tmp=max_tree[max_tree_query((1<<level)+l-1,(1<<level)+r-1)];
		if(h[tmp]==0)break;
		change(tmp,h[tmp]-1);
	}
}
void magic(int i, int x) {
	change(i,x);
}
long long int inspect(int l, int r) {
	return sum_tree_query((1<<level)+l-1,(1<<level)+r-1);
}