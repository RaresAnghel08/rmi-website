/**
* user:  sharshenaliev-d01
* fname: Nazar
* lname: Sharshenaliev
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:19:16.448706
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;
bool used[1000][1000];
main(){
	int n , m;
	cin >> n >> m;
	int ans = 0;
	vector <pair<int , int>> a;
	if(m == 1){
		cout << 0 << endl;
		return 0;
	}
	for (int i = 1; i <= n; i++){
		a.push_back({i , 0});
		a.push_back({i , 1});
	}
	sort(a.begin() , a.end());
	do{
	int ok  = 0;
	for (int i = 0; i < n * 2 - m; i++){
		for (int j = i + 1; j < n * 2 - m; j++){
			if((m % abs(i - j) == 0 and a[i].first == a[j].first) or 
			a[i].first == a[i+m].first){ok = 1; break;
			}
	    }
	}
	if(!ok){
		ans++;
	}
	ans %= 1000000007;
	}while(next_permutation(a.begin() , a.end()));
	cout << ans << endl;
	return 0;
}