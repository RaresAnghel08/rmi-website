/**
* user:  piskarev-b8f
* fname: Ivan
* lname: Piskarev
* task:  Weirdtree
* score: 52.0
* date:  2021-12-17 09:05:35.694953
*/
#pragma GCC target("avx")
#pragma GCC optimize("O3")
#include <bits/stdc++.h>

#include "weirdtree.h"

struct ST {
    struct Data {
        int max, max2;
        int maxCnt, dlt;
        int64_t sum;

        inline Data(int val = 0) : max(val), max2(-1), maxCnt(1), dlt(-1), sum(val) {
            ;
        }
    };

    inline Data merge(const Data& a, const Data& b) {
        Data res;
        res.max = std::max(a.max, b.max);
        res.maxCnt = a.maxCnt * (a.max == res.max) + b.maxCnt * (b.max == res.max);
        res.max2 = std::max((a.max == res.max) ? a.max2 : a.max, (b.max == res.max) ? b.max2 : b.max);
        res.sum = a.sum + b.sum;
        res.dlt = -1;
        return res;
    }

    std::vector<Data> data;
    int size;

    inline void merge(int i) {
        data[i] = merge(data[2 * i], data[2 * i + 1]);
    }

    ST() {}

    ST(int n, int* h) {
        size = 1 << 32 - __builtin_clz(n - 1);
        data.assign(size * 2, Data());
        for (int i = 0; i < n; i++) {
            data[size + i] = h[i];
        }
        for (int i = size - 1; i > 0; i--) {
            merge(i);
        }
    }

    inline void upd(int i, int dlt) {
        if (dlt >= data[i].max) {
            return;
        }
        // assert(data[i].max2 < dlt);
        data[i].dlt = dlt;
        data[i].sum -= (data[i].max - dlt) * 1LL * data[i].maxCnt;
        data[i].max = dlt;
    }

    inline void push(int i) {
        if (data[i].dlt != -1) {
            upd(2 * i, data[i].dlt);
            upd(2 * i + 1, data[i].dlt);
            data[i].dlt = -1;
        }
    }

    Data _get(int i, int l, int r, int ql, int qr) {
        if (qr <= l || r <= ql) {
            return Data();
        } else if (ql <= l && r <= qr) {
            return data[i];
        } else {
            push(i);
            int m = (l + r) / 2;
            Data res = merge(_get(2 * i, l, m, ql, qr), _get(2 * i + 1, m, r, ql, qr));
            return res;
        }
    }

    void _update(int i, int l, int r, int ql, int qr, int dlt) {
        if (qr <= l || r <= ql) {
            return;
        } else if (ql <= l && r <= qr && data[i].max2 < dlt) {
            upd(i, dlt);
        } else {
            push(i);
            int m = (l + r) / 2;
            _update(2 * i, l, m, ql, qr, dlt);
            _update(2 * i + 1, m, r, ql, qr, dlt);
            merge(i);
        }
    }

    void update(int l, int r, int dlt) {
        _update(1, 0, size, l, r, dlt);
    }

    Data get(int l, int r) {
        return _get(1, 0, size, l, r);
    }

    void magic(int i, int x) {
        static std::vector<int> p;
        p.clear();
        i += size;
        for (; i > 0; i /= 2) {
            p.push_back(i);
        }
        std::reverse(p.begin(), p.end());
        for (int i : p) {
            if (i < size) {
                push(i);
            }
        }
        data[p.back()] = x;
        for (int i = (int)p.size() - 2; i >= 0; i--) {
            merge(p[i]);
        }
    }
};

ST st;

void initialise(int n, int q, int h[]) {
    st = ST(n, h + 1);
}

void magic(int i, int x) {
    i--;
    st.magic(i, x);
}

void cut(int l, int r, int k) {
    l--;
    while (k > 0) {
        auto rs = st.get(l, r);
        if (rs.max == 0) {
            return;
        }
        if (rs.maxCnt <= k) {
            int dlt = std::min({rs.max - rs.max2, rs.max, k / rs.maxCnt});
            k -= dlt * rs.maxCnt;
            st.update(l, r, rs.max - dlt);
        } else {
            break;
        }
    }
    if (k != 0) {
        auto d = st.get(l, r);
        int beg = l, end = r;
        while (beg + 1 < end) {
            int mid = (beg + end) / 2;
            auto rs = st.get(l, mid);
            if (rs.max == d.max && rs.maxCnt > k) {
                end = mid;
            } else {
                beg = mid;
            }
        }
        // auto rs = st.get(l, beg);
        // assert(rs.max == d.max && rs.maxCnt == k);
        st.update(l, beg, d.max - 1);
    }
}

long long int inspect(int l, int r) {
    l--;
    auto rs = st.get(l, r);
    return rs.sum;
}
