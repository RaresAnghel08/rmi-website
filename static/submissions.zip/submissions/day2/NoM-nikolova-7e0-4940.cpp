/**
* user:  nikolova-7e0
* fname: Vesela Georgieva
* lname: Nikolova
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:47:29.612430
*/
#include<bits/stdc++.h>
using namespace std;

const int mod = 1e9+7, maxn = 2048;
int n, m, p[maxn];
bool used[maxn];
long long int ans = 0;

int find_i(int&id)
{
    int i;
    for (i=1; i<=2*n; ++i)
    {
        if (p[id] == p[i]+n) return i;
    }
}

bool check()
{
    int id, k;
    for (id=1; id<=2*n; ++id)
    {
        if (p[id] <= n)
        {
            k = find_i(id);
            if ((k-id) % m == 0) return false;
        }
    }
    return true;
}

void perm(int pos)
{
    if (pos > 2*n)
    {
        if (check()) ++ ans;
        return;
    }
    int i;
    for (i=1; i<=2*n; ++i)
    {
        if (!used[i])
        {
            p[maxn] = i;
            used[maxn] = true;
            perm(pos+1);
            used[maxn] = false;
        }
    }
}

void read()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m ;
    perm(1);
    cout << (ans % mod) << '\n' ;
}

int main()
{
	read();
	return 0;
}
