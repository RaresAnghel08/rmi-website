/**
* user:  yanushevskyi-c2e
* fname: Roman
* lname: Yanushevskyi
* task:  NoM
* score: 100.0
* date:  2021-12-17 08:33:26.007081
*/
#include <cstdio>
#include <cstring>
#include <algorithm>

const int md = 1000000007;

inline int add(int a, int b) 
{
	a += b;
	if (a >= md) a -= md;
	return a;
}
inline int sub(int a, int b) 
{
	a -= b;
	if (a < 0) a += md;
	return a;
}
inline int mul(int a, int b) 
{
	return (long long)a * b % md;
}

const int N = 2005;
int n, m, ncr[2 * N][2 * N], d1[N], d2[N], *cur, *prev, fact[N], ff[N];

int main() 
{
	for (int i = 0; i < 2 * N; ++i) {
		ncr[i][0] = ncr[i][i] = 1;
		for (int j = 1; j < i; ++j) ncr[i][j] = add(ncr[i - 1][j - 1], ncr[i - 1][j]);
	}
	fact[0] = 1;
	for (int i = 1; i < N; ++i) fact[i] = mul(fact[i - 1], i);
	scanf("%d%d", &n, &m);
	cur = d1;
	prev = d2;
	cur[0] = 1;
	ff[0] = 1;
	for (int i = 1; i < N; ++i) ff[i] = mul(ff[i - 1], ncr[2 * i][2]);
	for (int i = 0; i < std::min(m, 2 * n); ++i) {
		std::swap(prev, cur);
		memset(cur, 0, N << 2);
		int amt = (2 * n - 1 - i) / m + 1;
		for (int j = 0; j << 1 <= amt; ++j) {
			int sel = mul(ff[j], ncr[amt][j << 1]);
			for (int k = 0; prev[k]; ++k) cur[k + j] = add(cur[k + j], mul(mul(prev[k], sel), ncr[k + j][j]));
		}
	}
	int ans = 0;
	for (int i = n; i >= 0; --i) {
		cur[i] = mul(cur[i], mul(ff[n - i], ncr[n][i]));
		if (i & 1) ans = sub(ans, cur[i]);
		else ans = add(ans, cur[i]);
	}
	for (int i = 1; i <= n; ++i) ans = add(ans, ans);
	printf("%d\n", ans);
	return 0;
}
