/**
* user:  ziganshin-48f
* fname: Emir Ramilevich
* lname: Ziganshin
* task:  NoM
* score: 9.0
* date:  2021-12-17 08:22:20.875554
*/
#include <bits/stdc++.h>

using namespace std;

void solve();

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    solve();
}

#define int long long

const int N = 101, MOD = 1e9 + 7;

int pw(int a, int n) {
    if (n == 0) return 1;
    if (n % 2 == 0) {
        int b = pw(a, n / 2);
        return b * b % MOD;
    } else {
        return pw(a, n - 1) * a % MOD;
    }
}

int n, m, cnt[N], dp[N][N][N], fc[N], e;

int C(int n, int k) {
    return fc[n] * pw(fc[n - k] * fc[k] % MOD, MOD - 2) % MOD;
}

int stupid() {
    vector<int> a(2 * n);
    iota(a.begin(), a.end(), 0);
    int ans = 0, f, s;
    do {
        bool ok = true;
        for (int i = 0; i < 2 * n; i++) {
            for (int j = i + 1; j < 2 * n; j++) {
                if (a[i] >= n) f = a[i] - n;
                else f = a[i];
                if (a[j] >= n) s = a[j] - n;
                else s = a[j];
                if (f == s && (j - i) % m == 0) {
                    ok = false;
                    break;
                }
            }
            if (!ok) break;
        }
        if (ok) {
            ans++;
        }
    } while (next_permutation(a.begin(), a.end()));
    return ans;

}

int f(int a, int b) {
    return C(a + b, a);
}

void solve() {
    fc[0] = 1;
    for (int i = 1; i < N; i++) {
        fc[i] = fc[i - 1] * i % MOD;
    }
    cin >> n >> m;
    e = n * 2;
    for (int i = 0; i < e; i++) {
        cnt[i % m + 1]++;
    }
    dp[0][0][0] = 1;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j <= n; j++) {
            for (int h = 0; h <= n - j; h++) {
                for (int k = 0; k <= j; k++) {
                    int u = cnt[i + 1] - k;
                    dp[i + 1][j - k + u][h + k] += ((dp[i][j][h] * f(k, u) % MOD) * C(j, k) % MOD) * fc[k] % MOD;
                    dp[i + 1][j - j + u][h + k] %= MOD;
                }
            }
        }
    }
    int bin = 1;
    for (int i = 1; i <= n; i++) {
        bin = bin * 2 % MOD;
    }
    cout << (fc[n] * bin % MOD) * dp[m][0][n] % MOD;
}