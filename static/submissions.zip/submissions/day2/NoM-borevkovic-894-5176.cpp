/**
* user:  borevkovic-894
* fname: Vlatko
* lname: Borevković
* task:  NoM
* score: 34.0
* date:  2021-12-17 09:07:58.163097
*/
#include<bits/stdc++.h>

#define X first
#define Y second
#define MP make_pair
#define PB push_back
#define ll long long

using namespace std;

const int MAXN=2005;
const int MOD=1e9+7;

ll n,m;
ll dp[MAXN],novi[MAXN];
ll br;
ll pom;
ll vrat;
ll a,b;
ll samj;
ll fakt[MAXN];

ll pot(ll x, ll y){
    pom=x;
    vrat=1;
    while(y>0){
        pom%=MOD;
        if(y%2){
            vrat*=pom;
            vrat%=MOD;
        }
        pom*=pom;
        pom%=MOD;
        y/=2;
    }
    return vrat;
}

ll DIV(ll x, ll y){
    return (x*pot(y,MOD-2))%MOD;
}

ll mno(ll x, ll y){
    return (x*y)%MOD;
}

ll zbr(ll x, ll y){
    return (x+y)%MOD;
}

int main () {

    ios_base::sync_with_stdio(false);
    cin.tie(0);

    fakt[0]=1;
    for(int i=1; i<=1000; i++){
        fakt[i]=fakt[i-1]*i;
        fakt[i]%=MOD;
    }
    cin>>n>>m;
    if(m==1){
        cout<<"0\n";
        return 0;
    }
    dp[0]=1;
    for(int i=0; i<m; i++){
        br=(n*2-i-1)/m+1;
        for(int j=0; j<=n; j++){
            samj=j;
            for(int k=0; k<=min(br,samj); k++){
                if(j+br-2*k<=n){
                    novi[j+br-2*k]+=((dp[j]*DIV(DIV(fakt[br],fakt[br-k]),fakt[k]))%MOD*DIV(fakt[j],fakt[j-k]))%MOD;
                    novi[j+br-2*k]%=MOD;
                }
            }
        }
        for(int j=0; j<=n; j++){
            dp[j]=novi[j];
            //cout<<j<<" "<<dp[j]<<"\n";
            novi[j]=0;
        }
    }
    dp[0]*=fakt[n];
    dp[0]%MOD;
    for(int i=0; i<n; i++){
        dp[0]*=2;
        dp[0]%=MOD;
    }
    cout<<dp[0];

    return 0;
}
