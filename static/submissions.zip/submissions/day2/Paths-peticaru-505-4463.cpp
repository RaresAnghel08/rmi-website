/**
* user:  peticaru-505
* fname: Alexandru
* lname: Peticaru
* task:  Paths
* score: 19.0
* date:  2021-12-17 07:56:50.028604
*/
#include <bits/stdc++.h>
#pragma GCC optimize ("O3")
#define ll long long
#define ld long double

using namespace std;

int n;
long long dp[2002][2002];
int x, k, sz[2002];
vector<pair<int, int> >G[2002];

void dfs (int x, int par) {
  sz[x] = 1;
  for (auto it : G[x]) {
    if (it.first != par) {
      dfs(it.first, x);
      sz[x] += sz[it.first];
    }
  }
  for (int i = 0; i <= min(sz[x], k); i++) {
    dp[x][i] = 0;
  }
  int sum = 1;
  for (auto it : G[x]) {
    if (it.first != par) {
      for (int j = sum; j >= 0; j--) 
        for (int t = 1; t <= min(k, sz[it.first]); t++) {
          assert(j + t <= sz[x]);
          if (j + t > k)
            break;
          dp[x][j + t] = max(dp[x][j + t], dp[x][j] + dp[it.first][t] + it.second);
        }
      sum += sz[it.first];
    }
  }
}


int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  cin >> n >> k;
  for (int i = 1; i < n; i++) {
    int x, y, z;
    cin >> x >> y >> z;
    G[x].push_back({y, z});
    G[y].push_back({x, z});
  }
  for(int i = 1; i <= n; i++) {
    dfs(i, 0);
    cout << dp[i][min(k, n)] << "\n";
  }
  
    
  return 0;
}
