/**
* user:  almazbekov-a71
* fname: Beksultan
* lname: Almazbekov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:45:41.146300
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
//#include "grader.cpp"
using namespace std;

#define pb push_back
#define fr first
#define sc second
#define OK puts("OK");
#define endi puts("");
#define ret return
#define all(s) s.begin(),s.end()
#define allr(s) s.rbegin(),s.rend()
#define pii pair<int,int> 
const int N = 3e5+12,INF = 1e9+7;
int der[N*4],a[N],n,pos[4*N];
long long sum[N*4];

void build(int v,int l,int r){
	if (l == r){
		der[v] = a[l];
		sum[v] = a[l];
		pos[v] = l;
		ret ;
	}
	int m = l+r>>1;
	build(v<<1,l,m);
	build((v<<1)+1,m+1,r);
	if (der[v<<1] >= der[(v<<1)+1])
		pos[v] = pos[v<<1];
	else pos[v] = pos[(v<<1)+1];
	
	sum[v] = sum[v<<1]+sum[(v<<1)+1];
	der[v] = max(der[v<<1],der[(v<<1)+1]);
}

pii cutt(int v,int l,int r,int ql,int qr){
	int m = l+r>>1;
	if (ql <= l && r <= qr){
		ret {der[v],pos[v]};
	}
	if (l > qr || r < ql)ret {0,INF};
	pii a = cutt(v<<1,l,m,ql,qr);
	pii b = cutt((v<<1)+1,m+1,r,ql,qr);
	if (a.fr >= b.fr)ret a;
	else ret b;
}

void initialise(int N, int Q, int h[]) {
	for (int i=0;i<=N;++i)a[i] = h[i];
	n = N;
	build(1,1,N);
}

void update(int v,int l,int r,int ps,int x){
	if (l == r){
		der[v] = x;
		sum[v] = x;
		ret ;
	}
	int m = l+r>>1;
	if (m < ps){
		update((v<<1)+1,m+1,r,ps,x);
	}
	else {
		update(v<<1,l,m,ps,x);
	}
	
	if (der[v<<1] >= der[(v<<1)+1])
		pos[v] = pos[v<<1];
	else pos[v] = pos[(v<<1)+1];
	
	der[v] = max(der[v<<1],der[(v<<1)+1]);
	sum[v] = sum[v<<1]+sum[(v<<1)+1];
	
}
long long get_sum(int v,int l,int r,int ql,int qr){
	if (ql <= l && r <= qr)ret sum[v];
	if (l > qr || r < ql)ret 0;
	
	int m = (l+r)>>1;
	ret get_sum(v<<1,l,m,ql,qr)+get_sum((v<<1)+1,m+1,r,ql,qr);
}
void cut(int l, int r, int k) {
	
	while (k--){
		pii x = cutt(1,1,n,l,r);
		if (x.fr == 0)break;
		update(1,1,n,x.sc,x.fr-1);
	}
	
}
void magic(int i, int x) {
	
	update(1,1,n,i,x);
}
long long int inspect(int l, int r) {
	
	
	return get_sum(1,1,n,l,r);
}
