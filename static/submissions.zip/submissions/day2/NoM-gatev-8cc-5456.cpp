/**
* user:  gatev-8cc
* fname: Aleksandar Miroslavov
* lname: Gatev
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:31:55.324243
*/
#include<bits/stdc++.h>
using namespace std;

int n,m;
int p[20],ans;

void check(){
    for(int i=1;i<=2*n;i++){
        for(int f=2;f<=2*n;f++){
            if(p[i]==p[f] and (f-i)%m==0)return;
        }
    }
    ans++;
}

int main(){

    cin>>n>>m;
    for(int i=1;i<2*n;i+=2){
        p[i]=p[i+1]=(i+1)/2;
    }
    do{
        check();
    }while(next_permutation(p+1,p+2*n+1));

    cout<<ans<<"\n";

    return 0;
}