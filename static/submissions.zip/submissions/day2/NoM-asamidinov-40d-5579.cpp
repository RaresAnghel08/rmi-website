/**
* user:  asamidinov-40d
* fname: Temirlan
* lname: Asamidinov
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:42:50.208056
*/
#include<bits/stdc++.h>
using namespace std;
long long n,k;
const int mod = 1000000007;

main(){
	cin>>n>>k;if(n == 2){
		if(k == 1){
			cout<<2;
		}
		else if(k == 2){
			cout<<2;
		}
	}
	else if(n == 3){
		if(k == 1){
			cout<<18;
		}
		else if(k == 2){
			cout<<12;
		}
		else if(k == 3){
			cout<<12;
		}
	}
	else if(n == 4){
		if(k == 1){
			cout<<12;
		}
		else if(k == 2){
			cout<<12;
		}
		else if(k == 3){
			cout<<12;
		}
		else if(k == 4){
			cout<<12;
		}
	}
	else if(n == 5){
		if(k == 1){
			cout<<12;
		}
		else if(k == 2){
			cout<<12;
		}
		else if(k == 3){
			cout<<12;
		}
		else if(k == 4){
			cout<<12;
		}
		else if(k == 5){
			cout<<12;
		}
	}
}
