/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:57:10.051328
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
//#include "grader.cpp"
struct date
{
    long long maxim,pozmax,suma;
} arb[2000005];
long long v[300005];
int n;
void build(long long nod,long long st,long long dr)
{
    if(st==dr)
    {
        arb[nod].pozmax=st;
        return;
    }
    long long mij=(st+dr)/2;
    build(nod*2,st,mij);
    build(nod*2+1,mij+1,dr);
    arb[nod].pozmax=arb[nod*2].pozmax;
}
void update(long long nod,long long st, long long dr, long long poz,long long val)
{
    if(st==poz&&dr==poz)
    {
        arb[nod].maxim+=val;
        arb[nod].suma+=val;
        return;
    }
    long long mij=(st+dr)/2;
    if(poz<=mij)
        update(nod*2,st,mij,poz,val);
    else
        update(nod*2+1,mij+1,dr,poz,val);
    arb[nod].suma=arb[nod*2].suma+arb[nod*2+1].suma;
    arb[nod].maxim=arb[nod*2].maxim;
    arb[nod].pozmax=arb[nod*2].pozmax;
    if(arb[nod*2+1].maxim>arb[nod].maxim)
    {
        arb[nod].maxim=arb[nod*2+1].maxim;
        arb[nod].pozmax=arb[nod*2+1].pozmax;
    }
}
date query(long long nod,long long st, long long dr, long long a,long long b)
{
    if(st>=a&&dr<=b)
        return arb[nod];
    long long mij=(st+dr)/2;
    date rez={-1,0,0};
    if(a<=mij)
    {
        date x=query(nod*2,st,mij,a,b);
        rez.suma+=x.suma;
        if(rez.maxim<x.maxim)
        {
            rez.maxim=x.maxim;
            rez.pozmax=x.pozmax;
        }
    }
    if(b>mij)
    {
        date x=query(nod*2+1,mij+1,dr,a,b);
        rez.suma+=x.suma;
        if(rez.maxim<x.maxim)
        {
            rez.maxim=x.maxim;
            rez.pozmax=x.pozmax;
        }
    }
    return rez;
}
void initialise(int N, int Q, int h[]) {
    n=N;
    build(1,1,n);
    for(int i=1;i<=n;i++)
    {
        update(1,1,n,i,h[i]);
        v[i]=h[i];
    }
}
void cut(int l, int r, int k) {
    date x=query(1,1,n,l,r);
    long long poz=x.pozmax;
    update(1,1,n,poz,-v[poz]);
    if(v[poz]-1>=0)
        v[poz]--;
    update(1,1,n,poz,v[poz]);
}
void magic(int i, int x) {
    update(1,1,n,i,-v[i]);
    v[i]=x;
    update(1,1,n,i,v[i]);
}
long long int inspect(int l, int r) {
    date x=query(1,1,n,l,r);
    return x.suma;
}

