/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:55:51.411978
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)
#include "weirdtree.h"

using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int mxn = 100005;

int n;
ll seg[4*mxn];
int ps[4*mxn];

ll sum[4*mxn];
ll H[mxn];

void update(int k, int l, int r, int pos, ll x){
	if(r < pos || pos < l) return;
	if(l == r){
		seg[k] = x;
		ps[k] = pos;
		sum[k] = x;
		return;
	}
	int mid = (l+r)/2;
	update(k*2, l, mid, pos, x);
	update(k*2+1, mid+1, r, pos, x);
	if(seg[k*2] < seg[k*2+1]){
		ps[k] = ps[k*2+1];
	}
	else{
		ps[k] = ps[k*2];
	}
	seg[k] = max(seg[k*2], seg[k*2+1]);
	sum[k] = sum[k*2] + sum[k*2+1];
}
ll query(int k, int l, int r, int x, int y){
	if(y < l || r < x){
		return 0;
	}
	if(x <= l && r <= y){
		return sum[k];
	}
	int mid = (l+r)/2;
	return query(k*2, l, mid, x, y) + query(k*2+1, mid+1, r, x, y);
}
int POS;
ll MXVAL;
void findpos(int k, int l, int r, int x, int y){
	if(y < l || r < x){
		return;
	}
	if(x <= l && r <= y){
		if(MXVAL < seg[k]){
			MXVAL = seg[k];
			POS = ps[k];
		}
		return;
	}
	int mid = (l+r)/2;
	findpos(k*2, l, mid, x, y);
	findpos(k*2+1, mid+1, r, x, y);
}


void initialise(int N, int Q, int h[]) {
	n = N;
	fr(i, 0, N){
		H[i] = h[i];
		update(1, 0, n-1, i, h[i]);
	}
}
void cut(int l, int r, int k){
	MXVAL = -1;
	findpos(1, 0, n-1, l, r);
	H[POS] = max(H[POS] - 1, 0LL);
	update(1, 0, n-1, POS, H[POS]);
}
void magic(int i, int x) {
	--i;
	update(1, 0, n-1, i, x);
}
long long int inspect(int l, int r) {
	return query(1, 0, n-1, l, r);
}


