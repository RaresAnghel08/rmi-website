/**
* user:  dumitru-475
* fname: Matei
* lname: Dumitru
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:59:50.280698
*/
#include <bits/stdc++.h>
#define inf 1000000000
#include "weirdtree.h"
#pragma GCC optimize("O3")
using namespace std;
struct pereche
{
    long long val, poz;
};
pereche maxp(pereche a, pereche b)
{
    if (a.val == b.val)
    {
        if (a.poz < b.poz)
            return a;
        return b;
    }
    if (a.val > b.val)
        return a;
    return b;
}

struct AINTmax
{
    pereche aint[1200001];
    void build(int ind, int st, int dr, int h[])
    {
        if (st == dr)
            aint[ind] = {h[st], st};
        else
        {
            build(2 * ind, st, (st + dr) / 2, h);
            build(2 * ind + 1, (st + dr) / 2 + 1, dr, h);
            aint[ind] = maxp(aint[2 * ind], aint[2 * ind + 1]);
        }
    }
    void update(int ind, int val, int pos, int st, int dr)
    {
        if (st == dr)
            if (val < aint[ind].val)
                aint[ind] = {aint[ind].val - val, aint[ind].poz};
            else
                aint[ind] = {0LL, aint[ind].poz};
        else
        {
            if (pos <= (st + dr) / 2)
                update(2 * ind, val, pos, st, (st + dr) / 2);
            else
                update(2 * ind + 1, val, pos, (st + dr) / 2 + 1, dr);
            aint[ind] = maxp(aint[2 * ind], aint[2 * ind + 1]);
        }
    }
    pereche query(int ind, int stq, int drq, int st, int dr)
    {
        if (st >= stq && dr <= drq)
            return aint[ind];
        else
        {
            pereche maxx = {0LL, 0LL};
            if (stq <= (st + dr) / 2)
                maxx = maxp(maxx, query(2 * ind, stq, drq, st, (st + dr) / 2));
            if (drq > (st + dr) / 2)
                maxx = maxp(maxx, query(2 * ind + 1, stq, drq, (st + dr) / 2 + 1, dr));
            return maxx;
        }
    }
};
struct AINTsum
{
    long long aint[1200001];
    void build(int ind, int st, int dr, int h[])
    {
        if (st == dr)
            aint[ind] = h[st];
        else
        {
            build(2 * ind, st, (st + dr) / 2, h);
            build(2 * ind + 1, (st + dr) / 2 + 1, dr, h);
            aint[ind] = aint[2 * ind] + aint[2 * ind + 1];
        }
    }
    void update(int ind, int val, int pos, int st, int dr)
    {
        if (st == dr)
            aint[ind] = max(aint[ind] - val, 0LL);
        else
        {
            if (pos <= (st + dr) / 2)
                update(2 * ind, val, pos, st, (st + dr) / 2);
            else
                update(2 * ind + 1, val, pos, (st + dr) / 2 + 1, dr);
            aint[ind] = aint[2 * ind] + aint[2 * ind + 1];
        }
    }
    long long query(int ind, int stq, int drq, int st, int dr)
    {
        if (st >= stq && dr <= drq)
            return aint[ind];
        else
        {
            long long maxx = 0;
            if (stq <= (st + dr) / 2)
                maxx = maxx + query(2 * ind, stq, drq, st, (st + dr) / 2);
            if (drq > (st + dr) / 2)
                maxx = maxx + query(2 * ind + 1, stq, drq, (st + dr) / 2 + 1, dr);
            return maxx;
        }
    }
};
AINTmax maxx;
AINTsum sum;
int n;

void initialise(int N, int Q, int h[])
{
    n = N;
    sum.build(1, 1, N, h);
    maxx.build(1, 1, N, h);
}
void cut(int l, int r, int k)
{
    pereche x = maxx.query(1, l, r, 1, n);
    pereche y = maxp(maxx.query(1, l, x.poz - 1, 1, n), maxx.query(1, x.poz - 1, r, 1, n));
    while (x.val && k)
    {
        maxx.update(1, x.val - y.val, x.poz, 1, n);
        sum.update(1, 1, x.val - y.val, 1, n);
        x = maxx.query(1, l, r, 1, n), k--;
    }
}
void magic(int i, int x)
{
    pereche y = maxx.query(1, i, i, 1, n);
    maxx.update(1, y.val - x, i, 1, n);
    sum.update(1, y.val - x, i, 1, n);
}
long long int inspect(int l, int r)
{
    return sum.query(1, l, r, 1, n);
}

/*signed main()
{
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i)
        cin >> h[i];

    initialise(N, Q, h);

    cout << sum.query(1, 1, 3, 1, N) << endl;
    for (int i = 1; i <= Q; ++i)
    {
        int t;
        cin >> t;

        if (t == 1)
        {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        }
        else if (t == 2)
        {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        }
        else
        {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}*/
