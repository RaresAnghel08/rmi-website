/**
* user:  haivas-4ca
* fname: Vlad
* lname: Haivas
* task:  Paths
* score: 19.0
* date:  2021-12-17 07:28:21.089241
*/
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast", "unroll-loops")

using namespace std;
typedef long long ll;
typedef pair <int, int> pii;

const ll NMAX = 1001;
const ll MOD = 1000000007;
const ll nr_of_bits = 21;
const ll BLOCK = 420;

ll dp[NMAX][NMAX];
int n, k;
int sz[NMAX];

vector <pii> v[NMAX];

void init(){

    for(ll i = 1; i <= n; i++){
        sz[i] = 0;
        for(ll j = 0; j <= k; j++){
            dp[i][j] = 0;
        }
    }
}

void DFS(ll node, ll p){
    sz[node] = 1;
    for(auto x : v[node]){
        if(x.first == p)
            continue;
        DFS(x.first, node);
        sz[node] += sz[x.first];
    }
    ll s = 0;
    for(auto y : v[node]){
        ll x = y.first;
        if(x == p)
            continue;
        for(int i = s; i >= 0; i--){
            for(ll cant = 0; cant <= min(k - i, sz[x]); cant++){
                ll drum = (cant > 0) * 1LL * y.second;
                dp[node][i + cant] = max(dp[node][i + cant], dp[node][i] + dp[x][cant] + drum);
            }
        }
        s += sz[x];
    }
}

int main()
{
//    ifstream cin(".in");
//    ofstream cout(".out");
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ll i;
    cin >> n >> k;
    for(i = 1; i < n; i++){
        ll x, y, z;
        cin >> x >> y >> z;
        v[x].push_back({y, z});
        v[y].push_back({x, z});
    }
    for(ll i = 1; i <= n; i++){
        init();
        DFS(i, 0);
        cout << dp[i][k] << "\n";
    }
    return 0;
}
