/**
* user:  negoescu-c8b
* fname: Divia Petra
* lname: Negoescu
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 08:25:29.388405
*/
#include "weirdtree.h"
int v[100002],sol,poz,n;
long long sum;
struct strnod{
    int valmax;
    int pozmax;
    long long sum;
} a[400002];

void build(int nod,int st,int dr){
    if(st==dr){
        a[nod].valmax=v[st];
        a[nod].pozmax=st;
        a[nod].sum=v[st];
        return;
    }
    int mid=(st+dr)/2;
    build(2*nod, st, mid);
    build(2*nod+1,mid+1, dr);
    //a[nod].valmax=max(a[2*nod].valmax, a[2*nod+1]);
    if(a[2*nod].valmax>a[2*nod+1].valmax || (a[2*nod].valmax==a[2*nod+1].valmax && a[2*nod].pozmax<a[2*nod+1].pozmax)){
       a[nod].valmax=a[2*nod].valmax;
       a[nod].pozmax=a[2*nod].pozmax;
    }
    else{
        a[nod].valmax=a[2*nod+1].valmax;
        a[nod].pozmax=a[2*nod+1].pozmax;
    }
    a[nod].sum=a[2*nod].sum+a[2*nod+1].sum;
}
void update(int nod,int st,int dr,int poz,int x){
    if(st==dr){
        a[nod].valmax=x;
        a[nod].sum=x;
        return;
    }
    int mid=(st+dr)/2;
    if(poz<=mid)
        update(2*nod,st,mid,poz,x);
    else update(2*nod+1,mid+1,dr,poz,x);

   // a[nod]=max(a[2*nod],a[2*nod+1]);
    if(a[2*nod].valmax>a[2*nod+1].valmax || (a[2*nod].valmax==a[2*nod+1].valmax && a[2*nod].pozmax<a[2*nod+1].pozmax)){
       a[nod].valmax=a[2*nod].valmax;
       a[nod].pozmax=a[2*nod].pozmax;
    }
    else{
        a[nod].valmax=a[2*nod+1].valmax;
        a[nod].pozmax=a[2*nod+1].pozmax;
    }
    a[nod].sum=a[2*nod].sum+a[2*nod+1].sum;
}
void query_pozmax(int nod,int st,int dr, int l,int r){
    if(l<=st && dr<=r){
        if(sol<a[nod].valmax || (sol==a[nod].valmax && poz>a[nod].pozmax)){
            sol=a[nod].valmax;
            poz=a[nod].pozmax;
        }
        return;
    }
    int mid=(st+dr)/2;
    if(l<=mid)
        query_pozmax(2*nod, st,mid,l,r);
    if(r>mid)
        query_pozmax(2*nod+1, mid+1, dr,l,r);
}
void query_sum(int nod,int st,int dr,int l,int r){
    if(l<=st && dr<=r){
        sum+=a[nod].sum;
        return;
    }
    int mid=(st+dr)/2;
    if(l<=mid)
        query_sum(2*nod, st,mid,l,r);
    if(r>mid)
        query_sum(2*nod+1, mid+1, dr,l,r);
}
void initialise(int N, int Q, int h[]){
    n=N;
    for(int i=1;i<=n;i++)
        v[i]=h[i];
    build(1,1,n);
}
void cut(int l, int r, int k) {
	for(int i=1;i<=k;i++){
        sol=0;
        query_pozmax(1,1,n,l,r); //lasa in poz si sol rasp
        if(sol>0)
            update(1,1,n,poz, sol-1);
	}
}
void magic(int i, int x) {
	update(1,1,n,i,x);
}
long long int inspect(int l, int r) {
	sum=0;
	query_sum(1,1,n,l,r);
	return sum;
}

