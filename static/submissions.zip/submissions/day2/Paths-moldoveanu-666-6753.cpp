/**
* user:  moldoveanu-666
* fname: Cosmin-Adrian
* lname: Moldoveanu
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:14:32.236034
*/
#include <bits/stdc++.h>

using namespace std;
const int NMAX = 2000;
using pii = pair <int, int>;
vector <pii> g[NMAX + 5];
using ll = long long;
int n, k, t, l;
int e[12][2 * NMAX + 5], p[NMAX + 5], tin[NMAX + 5], lg2[2 * NMAX + 5], r[2 * NMAX + 5];
ll d[NMAX + 5], lc[NMAX + 5];
void dfs(int u, int prev, int w) {
    p[u] = prev;
    d[u] = d[prev] + w;
    tin[u] = ++t;
    e[0][t] = t;
    r[t] = u;
    for(pii v : g[u])
        if(v.first != prev)
            dfs(v.first, u, v.second);
    e[0][++t] = tin[prev];
}
void rmq() {
    for(int j = 1; j <= l; j++)
        for(int i = 1; i <= 2 * n - (1 << j); i++)
            e[j][i] = min(e[j - 1][i], e[j - 1][i + (1 << j - 1)]);
    //for(int j = 0; j <= l; j++, cout << "\n") for(int i = 1; i <= 2 * n; i++) cout << e[j][i] << " ";
    for(int i = 2; i <= 2 * n; i++)
        lg2[i] = lg2[i >> 1] + 1;
}
int query(int l, int r) {
    int lg = lg2[r - l + 1];
    return min(e[lg][l], e[lg][r - (1 << lg) + 1]);
}
int lca(int u, int v) {
    if(tin[u] > tin[v]) swap(u, v);
    int et = query(tin[u], tin[v]);
    return r[et];
}

int main()
{
    int u, v, w;
    cin >> n >> k;
    for(int i = 1; i < n; i++)
        cin >> u >> v >> w,
        g[u].emplace_back(v, w),
        g[v].emplace_back(u, w);
    l = 32 - __builtin_clz(n);
    vector <int> cleaves, leaves;
    for(int i = 1; i <= n; i++) if(g[i].size() == 1) cleaves.push_back(i);
    for(int root = 1; root <= n; root++) {
        t = 0;
        dfs(root, 0, 0);
        rmq();
        ll res = 0;
        fill(lc + 1, lc + n + 1, 0);
        leaves = cleaves;
        for(int i = 0 ; i < leaves.size() ; i++) if(leaves[i] == root) leaves.erase(leaves.begin() + i);
        //for(int i = 0; i < leaves.size(); i++) cout << leaves[i] << " \n"[i == n];
        sort(leaves.begin(), leaves.end(), [](int u, int v){return d[u] > d[v];});
        res += d[leaves[0]];
        for(int i = 1; i < min(k, (int)leaves.size()); i++) {
            for(int id = i; id < leaves.size(); id++)
                lc[leaves[id]] = max(lc[leaves[id]], d[lca(leaves[id], leaves[i - 1])]);
            stack <int> er;
            for(int i = 1; i < leaves.size(); i++) if(d[leaves[i]] == lc[leaves[i]]) er.push(i);
            while(!er.empty()) {
                int top = er.top();
                er.pop();
                leaves.erase(leaves.begin() + top);
            }
            if(leaves.size() <= i) break;
            sort(leaves.begin() + i, leaves.end(), [&](int u, int v){ return d[u] - lc[u] > d[v] - lc[v]; });
            //for(int i = 1; i < leaves.size(); i++) cout << d[leaves[i]] - lc[leaves[i]] << " ";
            //cout << leaves[i];
            res += d[leaves[i]] - lc[leaves[i]];
        }
        cout << res << "\n";
    }
    return 0;
}
