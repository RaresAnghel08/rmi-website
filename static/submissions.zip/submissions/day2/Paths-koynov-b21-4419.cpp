/**
* user:  koynov-b21
* fname: Daniel Iliev
* lname: Koynov
* task:  Paths
* score: 12.0
* date:  2021-12-17 07:50:54.446383
*/
#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
typedef long long ll;
const int maxn = 100010, maxlog = 20;
const ll inf = 1e17;

void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}

struct edge
{
    int ver;
    ll len;

    edge(int _ver, ll _len)
    {
        ver = _ver;
        len = _len;
    }

    bool operator < (const edge &e) const
    {
        return len > e.len;
    }
};

int n, k, used[maxn];
ll dp[maxn];
vector < edge > g[maxn];
void djikstra(int s)
{
    for (int i = 1; i <= n; i ++)
    {
        used[i] = 0;
        dp[i] = inf;
    }

    priority_queue < edge > pq;
    pq.push({s, 0});
    dp[s] = 0;
    while(!pq.empty())
    {
        edge e = pq.top();
        pq.pop();
        if (!used[e.ver])
            if (dp[e.ver] >= e.len)
        {
            for (int i = 0; i < g[e.ver].size(); i ++)
            {
                edge nb = g[e.ver][i];
                nb.len += e.len;
                if (!used[nb.ver] && nb.len < dp[nb.ver])
                {
                    dp[nb.ver] = nb.len;
                    pq.push(nb);
                }
            }
        }
    }
}

/**ll lvl[maxn];
int occ[3 * maxn], fin[3 * maxn], timer;

void dfs(int ver, int par)
{
    occ[++ timer] = ver;
    fin[ver] = timer;
    for (int i = 0; i < g[ver].size(); i ++)
    {
        int u = g[ver][i].ver;
        if (u == par)
            continue;
        lvl[u] = lvl[v] + g[ver][i].second;
        dfs(u, ver);
        occ[++ timer] = ver;
    }
    occ[++ timer] = ver;
}

ll tb[maxlog][maxn], lg[maxn];

void build_sparse_table()
{
    for (int i = 1; i <= timer; i ++)
        tb[0][i] = lvl[occ[i]];

    for (int i = 1; i <= timer; i ++)
        lg[i] = lg[i / 2] + 1;

    for (int j = 1; j < lg[timer]; j ++)
        for (int i = 1; i <= timer - (1 << j) + 1; i ++)
    {
        dp[j][i] = dp[j - 1][i];
        if (dp[j - 1][i + (1 << (j - 1))] < dp[j][i])
            dp[j][i] = dp[j - 1][i + (1 << (j - 1))];
    }
}

ll query(int v, int u)
{

}*/

ll ans[maxn];
void solve()
{
    cin >> n >> k;
    for (int i = 1; i < n; i ++)
    {
        int v, u;
        ll w;
        cin >> v >> u >> w;
        edge e(u, w);
        g[v].push_back(e);
        e.ver = v;
        g[u].push_back(e);
    }

    djikstra(1);
    int st = 1;
    for (int i = 2; i <= n; i ++)
    {
        if (dp[i] > dp[st])
            st = i;
    }
    djikstra(st);
    int en = 1;
    for (int i = 2; i <= n; i ++)
    {
        if (dp[i] > dp[en])
            en = i;
    }

    for (int i = 1; i <= n; i ++)
        ans[i] = dp[i];

    djikstra(en);

    for (int i = 1; i <= n; i ++)
    {
        ans[i] = max(ans[i], dp[i]);
        cout << ans[i] << endl;
    }
    ///dfs(1, -1);

    ///build_sparse_table();
}

int main()
{
    solve();
    return 0;
}
