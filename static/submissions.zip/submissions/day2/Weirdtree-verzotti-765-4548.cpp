/**
* user:  verzotti-765
* fname: Matteo-Alexandru
* lname: Verzotti
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 08:06:58.232067
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
#define dbg(x) cerr << #x << ' ' << x << '\n'
#define dsp(x) cerr << #x << ' ' << x << ' '

using namespace std;

class SegTree {
private:
    struct Node {
        long long sum, max_elem, pos;
    };
    int _n;
    vector <Node> a;

    void recalculate(int node) {
        a[node].sum = a[node << 1].sum + a[node << 1 | 1].sum;
        a[node].max_elem = a[node << 1].max_elem; a[node].pos = a[node << 1].pos;

        if (a[node << 1 | 1].max_elem > a[node].max_elem) {
            a[node].max_elem = a[node << 1 | 1].max_elem;
            a[node].pos = a[node << 1 | 1].pos;
        }
    }

    Node inspect_max(int node, int l, int r, int ql, int qr) {
        if (ql <= l && r <= qr)
            return a[node];
        int mid = (l + r) >> 1;
        Node ans = Node{0, 0, 0};

        if (mid >= ql)
            ans = inspect_max(node << 1, l, mid, ql, qr);
        
        if (mid < qr) {
            Node ans2 = inspect_max(node << 1 | 1, mid + 1, r, ql, qr);
            if (ans2.max_elem > ans.max_elem)
                ans = ans2;
        }
        return ans;
    }

public:
    void resize(int n) {
        a.resize(4 * n + 1);
        _n = n;
    }

    int inspect_max(int l, int r) {
        return inspect_max(1, 1, _n, l, r).pos;
    }

    void magic(int node, int l, int r, int pos, int value) {
        if (l == r) {
            a[node].sum = a[node].max_elem = value;
            a[node].pos = pos;
            return;
        }

        int mid = (l + r) >> 1;
        if (pos <= mid)
            magic(node << 1, l, mid, pos, value);
        else
            magic(node << 1 | 1, mid + 1, r, pos, value);
        
        recalculate(node);
    }

    long long inspect(int node, int l, int r, int ql, int qr) {
        if (ql <= l && r <= qr)
            return a[node].sum;
        int mid = (l + r) >> 1;
        long long ans = 0;

        if (mid >= ql)
            ans += inspect(node << 1, l, mid, ql, qr);
        if (mid < qr)
            ans += inspect(node << 1 | 1, mid + 1, r, ql, qr);
        return ans;
    }
};

SegTree aint;
int n;
vector <int> v;
void initialise(int N, int Q, int h[]) {
    aint.resize(N);
    n = N;
    v.push_back(0);

    for (int i = 1; i <= N; i++) {
        aint.magic(1, 1, N, i, h[i]);
        v.push_back(h[i]);
    }
}

void cut(int l, int r, int k) {
    // k = 1
    int pos = aint.inspect_max(l, r);
    if (v[pos] == 0)
        return;
    aint.magic(1, 1, n, pos, v[pos] - 1);
    v[pos]--;
}
void magic(int i, int x) {
    aint.magic(1, 1, n, i, x);
    v[i] = x;
}

long long int inspect(int l, int r) {
	return aint.inspect(1, 1, n, l, r);
}
