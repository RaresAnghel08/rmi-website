/**
* user:  koynov-b21
* fname: Daniel Iliev
* lname: Koynov
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:23:13.606796
*/
#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
typedef long long ll;
const ll mod = 1e9 + 7;
void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}

map < vector < int >, ll > dp;

int calc(vector < int > v)
{

    if (v.back() == 0)
        return 1;

    if (dp[v] != 0)
        return dp[v];
    vector < int > to = v;
    dp[v] = -1;
    for (int i = 0; i < v.size(); i ++)
        for (int j = i + 1; j < v.size(); j ++)
    {
        if (v[i] == 0 || v[j] == 0)
        continue;
        to = v;
        to[i] --;
        to[j] --;
        sort(to.begin(), to.end());

        ll fp = calc(to);
        if (fp == -1)
            continue;
        if (dp[v] == -1)
            dp[v] = 0;
        dp[v] = dp[v] + (fp * v[i] * v[j]) % mod;
        if (dp[v] >= mod)
            dp[v] -= mod;
    }
    return dp[v];
}
void solve()
{
    int n, m;
    cin >> n >> m;
    vector < int > v;
    int top = (n * 2) / m, ost = (n * 2) % m;
    int such = m - ost;
    for (int i = 0; i < such; i ++)
        v.push_back(top);
    for (int i = 0; i < ost; i ++)
        v.push_back(top + 1);



    ll ans = calc(v);
    for (int i = 1; i <= n; i ++)
    {
        ans = (ans * 2) % mod;
    }

    cout << ans << endl;
}

int main()
{
    solve();
    return 0;
}
