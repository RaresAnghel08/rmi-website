/**
* user:  lugli-eb4
* fname: Francesco
* lname: Lugli
* task:  NoM
* score: 100.0
* date:  2021-12-17 09:43:44.815951
*/
#include<bits/stdc++.h>
#pragma gcc optimize("Ofast")
#define mod 1000000007
using namespace std;
typedef long long ll;

ll fact[2001];
ll inv[2001];
ll cap[2001];
ll dp[2001][2001];

ll modpow(ll b, ll e)
{
	if (e == 0) return 1;
	ll t = modpow(b, e/2);
	return ((t*t)%mod * (e%2 ? b : 1))%mod;
}

ll choose(ll n, ll k)
{
	ll num = fact[n];
	ll den = (inv[k] * inv[n-k])%mod;
	return (num * den)%mod;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	ll N, M;	
	cin >> N >> M;
	fact[0] = inv[0] = 1;

	for (int n = 1; n <= N; n++)
	{
		fact[n] = (fact[n-1] * n)%mod;
		inv[n] = modpow(fact[n], mod-2);
	}
	for (int i = 0; i < (2*N)%M; i++)
	{
		cap[i] = ((2*N)/M+1);
	}
	for (int i = (2*N)%M; i < M; i++)
	{
		cap[i] = ((2*N)/M);
	}

	dp[M][0] = 1;

	for (int i = M-1; i >= 0; i--)
	{
		//cout << i << ": " << cap[i] << "\n";
		for (ll b = 0; b <= N; b++)
		{
			//cout << i << " " << b << "!!\n";
			for (int u = 0; u <= min(b, cap[i]); u++)
			{
				ll nb = b + cap[i] - 2 * u;
				if (nb > N) continue;
				ll nv = ((dp[i+1][nb] * choose(cap[i], u))%mod * fact[u])%mod;
				nv *= choose(b, u);
				nv %= mod;
				dp[i][b] += nv;
				dp[i][b] %= mod;
			}
		}
	}
	ll ans = (dp[0][0] * fact[N])%mod;
	ans *= modpow(2, N);
	ans %= mod;
	cout << ans << "\n";
}
