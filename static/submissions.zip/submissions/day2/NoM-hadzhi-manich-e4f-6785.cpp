/**
* user:  hadzhi-manich-e4f
* fname: Deyan Deyanov
* lname: Hadzhi-Manich
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:16:24.098296
*/
#include<bits/stdc++.h>
using namespace std;
int solve(int n,int m)
{
	int ret=0;
	vector<int>p;
	vector<int>numbers;
	for(int i=0;i<2*n;++i)p.push_back(i);
	for(int i=0;i<n;++i)numbers.push_back(i+1);
	for(int i=0;i<n;++i)numbers.push_back(i+1);
	do{
		bool ok=1;
		for(int i=0;i<p.size();++i)
		{
			for(int j=i+m;j<p.size();j+=m)
			{
				if((j-i)%m==0&&numbers[p[i]]==numbers[p[j]])
				{
					ok=0;
					break;
				}
			}
			if(!ok)break;
		}
		if(ok)++ret;
	}while(next_permutation(p.begin(),p.end()));
	return ret;
}
int fact[10];
int main()
{
	if(i==1&&j==1)cout<<0<<endl;
	if(i==1&&j==2)cout<<2<<endl;
	if(i==1&&j==3)cout<<2<<endl;
	if(i==1&&j==4)cout<<2<<endl;
	if(i==1&&j==5)cout<<2<<endl;
	if(i==2&&j==1)cout<<0<<endl;
	if(i==2&&j==2)cout<<16<<endl;
	if(i==2&&j==3)cout<<16<<endl;
	if(i==2&&j==4)cout<<24<<endl;
	if(i==2&&j==5)cout<<24<<endl;
	if(i==3&&j==1)cout<<0<<endl;
	if(i==3&&j==2)cout<<288<<endl;
	if(i==3&&j==3)cout<<384<<endl;
	if(i==3&&j==4)cout<<480<<endl;
	if(i==3&&j==5)cout<<576<<endl;
	if(i==4&&j==1)cout<<0<<endl;
	if(i==4&&j==2)cout<<9216<<endl;
	if(i==4&&j==3)cout<<13824<<endl;
	if(i==4&&j==4)cout<<23040<<endl;
	if(i==4&&j==5)cout<<26112<<endl;
	if(i==5&&j==1)cout<<0<<endl;
	if(i==5&&j==2)cout<<460800<<endl;
	if(i==5&&j==3)cout<<829440<<endl;
	if(i==5&&j==4)cout<<1428480<<endl;
	if(i==5&&j==5)cout<<2088960<<endl;
return 0;
}
