/**
* user:  suleymanov-b26
* fname: Karam
* lname: Suleymanov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:22:44.568813
*/
typedef long long ll;
const ll g = 8;
ll tree[2 * g - 1];
ll treem[2 * g - 1];
ll a[g];

void build(ll i = 0, ll l = 0, ll r = g - 1) {
    if (r - l == 0) {
        tree[i] = a[i - g + 1];
        treem[i] = i - g + 1;
        return;
    }
    build(2 * i + 1, l, (l + r) / 2);
    build(2 * i + 2, (l + r) / 2 + 1, r);
    tree[i] = tree[2 * i + 1] + tree[2 * i + 2];
    if (a[treem[2 * i + 1]] >= a[treem[2 * i + 2]]) {
        treem[i] = treem[2 * i + 1];
    } else {
        treem[i] = treem[2 * i + 2];
    }
}

ll find(ll ql, ll qr, ll i = 0, ll l = 0, ll r = g - 1) {
    if (r < ql || qr < l) {
        return 0;
    }
    if (ql <= l && r <= qr) {
        return tree[i];
    }
    return find(ql, qr, 2 * i + 1, l, (l + r) / 2) + find(ql, qr, 2 * i + 2, (l + r) / 2 + 1, r);
}

void _magic(ll x, ll del, ll i, ll l, ll r) {
    if (x < l || r < x) {
        return;
    }
    if (r - l == 0) {
        tree[i] = del;
        a[i - g + 1] = del;
        return;
    }
    _magic(x, del, 2 * i + 1, l, (l + r) / 2);
    _magic(x, del, 2 * i + 2, (l + r) / 2 + 1, r);
    tree[i] = tree[2 * i + 1] + tree[2 * i + 2];
    if (a[treem[2 * i + 1]] >= a[treem[2 * i + 2]]) {
        treem[i] = treem[2 * i + 1];
    } else {
        treem[i] = treem[2 * i + 2];
    }
}

ll findm(ll ql, ll qr, ll i = 0, ll l = 0, ll r = g - 1) {
    if (r < ql || qr < l) {
        return 0;
    }
    if (ql <= l && r <= qr) {
        return treem[i];
    }
    if (a[findm(ql, qr, 2 * i + 1, l, (l + r) / 2)] >= a[findm(ql, qr, 2 * i + 2, (l + r) / 2 + 1, r)]) {
        return findm(ql, qr, 2 * i + 1, l, (l + r) / 2);
    } else {
        return findm(ql, qr, 2 * i + 2, (l + r) / 2 + 1, r);
    }
}

void initialise(ll N, ll Q, ll h[]) {
    for (ll i = 1; i <= N; i++) {
        a[i - 1] = h[i];
    }
    build();
}

void cut(ll l, ll r, ll k) {
    l--, r--;
    for (ll i = 0; i < k; i++) {
        ll x = findm(l, r);
        if (a[x] - 1 >= 0)
            _magic(x, a[x] - 1, 0, 0, g - 1);
    }
}

void magic(ll i, ll x) {
    i--;
    _magic(i, x, 0, 0, g - 1);
}


long long int inspect(ll l, ll r) {
    l--, r--;
    return find(l, r);
}