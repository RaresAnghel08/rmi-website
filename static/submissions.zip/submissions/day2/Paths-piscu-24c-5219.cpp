/**
* user:  piscu-24c
* fname: Stefan Constantin
* lname: Piscu
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:11:31.967102
*/
#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;

#define ll long long

int n, k;
vector<vector<pair<int, int>>> out;
vector<int> nrl;
vector<vector<ll>> dp;

void setSize(int n){
	nrl.resize(n+1);
	out.resize(n+1);
	dp.resize(n+1);
}

void compute(int x, int fat=-1){
	nrl[x]=0;
	if(out[x].size()==1&&(fat!=-1)) nrl[x]=1;
	for(auto it:out[x]){
		if(it.first==fat) continue;
		compute(it.first, x);
		nrl[x]+=nrl[it.first];
	}
	dp[x].clear();
	dp[x].resize(min(k+1, max(2, nrl[x]+1)), 0);
	//cout<<x<<" "<<nrl[x]<<"*\n";
}

void mergedp(vector<ll> &dp1, vector<ll> &dp2, int val){
	vector<int> orig(dp1.size());
	for(int i=0;i<dp1.size();++i) orig[i]=dp1[i];
	for(int i=1;i<dp2.size();++i){
		for(int j=i;j<dp1.size();++j){
			dp1[j]=max(dp1[j], dp2[i]+orig[j-i]+val);
		}
	}

}

void calcdp(int x, int fat=-1){
	for(auto it:out[x]){
		if(it.first==fat) continue;
		calcdp(it.first, x);
		mergedp(dp[x], dp[it.first], it.second);
	}
	/*
	cout<<x<<"\n";
	for(auto it:dp[x]) cout<<it<<" ";
	cout<<"\n";
	*/
}

/*
void topdown(int x, vector<ll> dpprop, int nrlprop){

	mergedp(dp, dpprop);
	nrl+=nrlprop;

	vector<vector<ll>> dpprop2(out[x].size(), vector<ll>(nrl[x]));
	vector<int> nrlprop2(out[x].size());
	int start=1;
	for(int i=0;i<out[x].size();++i){
		for(int j=0;j<out[x].size();++j){
			if(j==i) continue;
			nrlprop2[out[x][i].first]+=nrl[out[x][j].first];
		}
		dpprop2[out[x][i]].resize(min(k+1, max(2, nrlprop2[out[x][i]]+1)), 0);

	}
	for(int i=0;i<out[x].size();++i){
		for(int j=0;j<out[x].size();++j){
			if(j==i) continue;
			mergedp(dprop[out[x][i].first], dp[out[x][j].first], out[x][j].second);
		}
	}
	for(int i=1;i<out[x].size();++i){
		dp[i]=mergedp(dppre[i-1], dp[out[x][i].first]);
		topdown(out[x][i].first, x, dpprop[i], nrlprop[i]);
	}
}
*/

int32_t main(){
	cin>>n>>k;
	setSize(n);
	for(int i=1;i<n;++i){
		int a, b, c;
		cin>>a>>b>>c;
		out[a].push_back({b, c});
		out[b].push_back({a, c});
	}
	for(int i=1;i<=n;++i){
		compute(i);
		calcdp(i);
		if(nrl[i]<k) cout<<dp[i][nrl[i]]<<"\n";
		else cout<<dp[i][k]<<"\n";
	}
}
