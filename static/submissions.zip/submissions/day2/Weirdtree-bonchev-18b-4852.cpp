/**
* user:  bonchev-18b
* fname: Petar Plamenov
* lname: Bonchev
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:39:23.785586
*/
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int n,q;
int a[300001];

bool compareP(pair<int,int> f,pair<int,int> s)
{
	if(f.first!=s.first) return f.first>s.first;
	return f.second<s.second;
}

void initialise(int N, int Q, int h[])
{
	n=N;
	q=Q;
	for(int i=1;i<=n;i++)
		a[i]=h[i];
}

void cut(int l, int r, int k)
{
	vector<pair<int,int> > v;
	
	for(int i=l;i<=r;i++)
	{
		v.push_back(make_pair(a[i],i));
	}
	sort(v.begin(),v.end(),compareP);
	

	
	int q=1;//first q with same value
	
	while(q<v.size()&&k>q*(v[q-1].first-v[q].first))
	{
		k-=q*(v[q-1].first-v[q].first);
		
		for(int i=0;i<q;i++)
			v[i].first=v[q].first;
		
		q++;
	}
	
	for(int i=0;i<q;i++)
	{
		v[i].first-=(k/q);
		v[i].first=max(v[i].first,0);
	}
	
	for(int i=0;i<k%q;i++)
	{
		v[i].first--;
		v[i].first=max(v[i].first,0);
	}
	
	for(int i=0;i<v.size();i++)
		a[v[i].second]=v[i].first;
}

void magic(int i, int x)
{
	a[i]=x;
}

long long int inspect(int l, int r)
{
	long long s=0;
	for(int i=l;i<=r;i++)
		s+=a[i];
	return s;
}

int main() 
{
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
}
