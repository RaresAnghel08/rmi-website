/**
* user:  marciuc-b16
* fname: Andrei
* lname: Marciuc
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:48:46.279350
*/
#include <algorithm>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <queue>
using namespace std;

vector<long long> v;
vector<pair<long long, int>> vv;
vector<pair<int, long long>> nod[ 100010 ];
queue<pair<int, long long>> q;
int n;

void plimbare( int poz ) {
  //  printf( "caca\n" );
    int *ok = new int[ n + 1 ]();
    q.push( { poz, 0 } );
    ok[ poz ] = 1;
    while( !q.empty() ) {
        //printf( "caca\n" );
        int idx = q.front().first;
        long long suma = q.front().second;
        int vecini = 0;
        ok[ idx ] = 1;
        q.pop();

        bool okk = 1;
        //printf( "din %d pleaca:\n", idx );
        for( int i = 0; i < nod[ idx ].size(); i++ )
            if( !ok[ nod[ idx ][ i ].first ] ) {
                vv.push_back( { nod[ idx ][ i ].second, nod[ idx ][ i ].first } );
                ok[ nod[ idx ][ i ].first ] = true;

            }

        if( vv.size() == 0 )
            v.push_back( suma );
        else {
            sort( vv.begin(), vv.end() );
            int right = vv.size() - 1;
            for( int i = 0; i < right; i++ ){
                //printf( "\t %d cu suma = %lld\n", vv[ i ].second, vv[ i ].first );
                q.push( { vv[ i ].second, vv[ i ].first } );
            }
            q.push( { vv[ right ].second, vv[ right ].first + suma } );
        }
        vv.clear();
    }
}

long long sum( int ind, int k ) {
   // printf( "intru\n" );
    plimbare( ind );
    sort( v.begin(), v.end() );
   // for( int i = 0; i < v.size(); i++ )
     //   cout << v[ i ] << ' ';
    int poz = v.size() - 1;
    long long suma = 0;
    while( k-- && poz >= 0 )
        suma += v[ poz-- ];
    v.clear();

    return suma;
}

int main()
{
    int k, a, b;
    long long c;
    scanf( "%d%d", &n, &k );
    //printf( "%d %d\n", n, k );
    for( int i = 1; i < n; i++ ) {
        scanf( "%d%d%lld", &a, &b, &c );
        nod[ a ].push_back( { b, c } );
        nod[ b ].push_back( { a, c } );
    }
    //printf( "caca\n" );
    for( int i = 1; i <= n; i++ )
        cout << sum( i, k ) << '\n';
    return 0;
}
