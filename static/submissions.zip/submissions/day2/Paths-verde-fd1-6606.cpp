/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:03:08.036618
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast","unroll-loops")
#pragma GCC target("avx","avx2","fma")
using namespace std;
vector<int> v[2001];
int tata[2001],cnt,poz[2001],mar[2001],vec[2001];
bool curat[2001];
pair <long long,int> aint[8001];
long long lazy[8001];
void propag(int nod,int a,int b)
{
    if(a==b||!lazy[nod])
        return;
    lazy[2*nod]+=lazy[nod];
    lazy[2*nod+1]+=lazy[nod];
    aint[2*nod].first+=lazy[nod];
    aint[2*nod+1].first+=lazy[nod];
    lazy[nod]=0;
}
void update(int nod,int a,int b,int ua,int ub,int val)
{
    propag(nod,a,b);
    if(ua<=a&&b<=ub)
    {
        if(a==b)
        {
            aint[nod].first+=val;
            aint[nod].second=a;
        }
        else
        {
            aint[nod].first+=val;
            lazy[nod]+=val;
        }
        return;
    }
    int mid=(a+b)/2;
    if(ua<=mid)
        update(2*nod,a,mid,ua,ub,val);
    if(ub>mid)
        update(2*nod+1,mid+1,b,ua,ub,val);
    if(aint[2*nod].first>aint[2*nod+1].first)
        aint[nod]=aint[2*nod];
    else
        aint[nod]=aint[2*nod+1];
}
int cost[2001][2001],n;
void dfs(int nod,int papa)
{
    mar[nod]=1;
    tata[nod]=papa;
    vec[++cnt]=nod;
    poz[nod]=cnt;
    for(auto it:v[nod])
        if(it!=papa)
        {
            dfs(it,nod);
            mar[nod]+=mar[it];
        }
}
void up(int nod)
{
    if(tata[nod]==0)
        return;
    update(1,1,n,poz[nod],poz[nod]+mar[nod]-1,-cost[nod][tata[nod]]);
    curat[nod]=1;
    if(!curat[tata[nod]])
        up(tata[nod]);
}
void curata(int nod,int a,int b)
{
    lazy[nod]=0;
    aint[nod]= {0,0};
    if(a==b)
        return;
    int mid=(a+b)/2;
    curata(2*nod,a,mid);
    curata(2*nod+1,mid+1,b);
}
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int k,i,a,b,c;
    cin>>n>>k;
    for(i=1; i<n; i++)
    {
        cin>>a>>b>>c;
        v[a].push_back(b);
        v[b].push_back(a);
        cost[a][b]=cost[b][a]=c;
    }
    long long sum;
    int j;
    for(i=1; i<=n; i++) ///radacina
    {
        sum=0;
        cnt=0;
        int ck=k;
        curata(1,1,n);
        dfs(i,0);
        for(j=1; j<=n; j++)
            curat[j]=0;
        for(j=1; j<=n; j++)
            if(j!=i)
                update(1,1,n,poz[j],poz[j]+mar[j]-1,cost[j][tata[j]]);
        while(k)///iau cel mai bun si updatez
        {
            pair <long long,int> ind=aint[1];
            if(ind.first==0)
                break;
            sum+=ind.first;
            //cout<<vec[ind.second]<<" ";
            up(vec[ind.second]);
            k--;
        }
        cout<<sum<<'\n';
        k=ck;
    }
    return 0;
}
