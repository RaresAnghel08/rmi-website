/**
* user:  nikolova-7e0
* fname: Vesela Georgieva
* lname: Nikolova
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:50:50.800195
*/
#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

const int maxn = 100001;
int n, k, ver, par[maxn];
long long int ans;
bool used[maxn];
struct edge
{
    int x;
    int st;
};
vector<edge> v[maxn], v1[maxn];

void read()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> k ;
    int i, xx, yy, p;
    for (i=1; i<n; ++i)
    {
        cin >> xx >> yy >> p ;
        v1[xx].push_back({yy, p});
        v1[yy].push_back({xx, p});
        v[xx].push_back({yy, p});
        v[yy].push_back({xx, p});
    }
}

void DFS(int s, long long p)
{
    //cout << s << "  " << p << endl;
    used[s] = true;
    int i, len = v[s].size();
    bool lamp = true;
    for (i=0; i<len; ++i)
    {
        if (!used[v[s][i].x])
        {
            lamp = false;
            par[v[s][i].x] = s;
            DFS(v[s][i].x, p + v[s][i].st);
        }
    }
    if (lamp && ans < p)
    {
        ans = p;
        ver = s;
    }
}

void zero(int s)
{
    int i, len1 = v[s].size(), j, len2;
    for (i=0; i<len1; ++i)
    {
        if (v[s][i].x == par[s])
        {
            v[s][i].st = 0;
            len2 = v[v[s][i].x].size();
            for (j=0; j<len2; ++j) if (v[v[s][i].x][j].x == s) v[v[s][i].x][j].st = 0;
            zero(v[s][i].x);
        }
    }
}

void solve()
{
    int i, j, l, len, w;
    long long sum;
    for (i=1; i<=n; ++i)
    {
        sum = 0;
        for (l=1; l<=n; ++l)
        {
            //v[l].clear();
            v[l] = v1[l];
            //len = v1[l].size();
            //for (w=0; w<len; ++w) v[l].push_back({v1[l][w].x, v1[l][w].st});
        }
        for (j=1; j<=k; ++j)
        {
            ans = 0;
            memset(used, 0, sizeof(used));
            memset(par, 0, sizeof(par));
            DFS(i, 0);
            //cout << "******" << ans << endl;
            sum += ans;
            zero(ver);
            /*for (l=1; l<=n; ++l)
            {
                cout << l << ": ";
                len = v[l].size();
                for (w=0; w<len; ++w) cout << v[l][w].x << " " << v[l][w].st << endl;
            }*/
        }
        cout << sum << '\n' ;
    }
}

void solve_1()
{
    int i, j, l, len, w;
    for (i=1; i<=n; ++i)
    {
        ans = 0;
        memset(used, 0, sizeof(used));
        memset(par, 0, sizeof(par));
        DFS(i, 0);
        //cout << "******" << ans << endl;
        //sum += ans;
        //zero(ver);
        /*for (l=1; l<=n; ++l)
        {
            cout << l << ": ";
            len = v[l].size();
            for (w=0; w<len; ++w) cout << v[l][w].x << " " << v[l][w].st << endl;
        }*/
        cout << ans << '\n' ;
    }
}

int main()
{
    read();
    if (k == 1) solve_1();
    else solve();
    return 0;
}
