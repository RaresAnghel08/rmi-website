/**
* user:  abramson-f2e
* fname: Carmel
* lname: Abramson
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:40:01.014865
*/
#include <bits/stdc++.h>

#include "weirdtree.h"
using namespace std;

typedef long long ll;
typedef vector<int>vi;
typedef vector<ll> vl;

#define out(x){cout << x << "\n"; return 0;}
#define all(x) x.begin(),x.end()
#define pb push_back
#pragma GCC optimize("Ofast")
map<int,set<int>>where;

struct seg{
    int l,r,m;
    ll sum=0,mx=0;
    seg* lp,*rp;

    seg(){}
    seg (int l,int r):l(l),r(r),m((l+r)/2){
        if(l+1<r){
            lp=new seg(l,m);
            rp=new seg(m,r);
        }
    }
    void upd(int i,int v){
        if(l+1==r){
            sum=v;
            mx=v;
            return;
        }
        if(i<m)
            lp->upd(i,v);
        else
            rp->upd(i,v);
        sum=lp->sum+rp->sum;
        mx=max(lp->mx,rp->mx);
    }


    int qur_mx(int a,int b){

        if(b<=l || r<=a)
            return 0;
        else if(a<=l && r<=b)
            return mx;
        return max(lp->qur_mx(a,b),rp->qur_mx(a,b));
    }
    ll qur_sum(int a,int b){
        if(b<=l || r<=a)
            return 0;
        else if(a<=l && r<=b)
            return sum;
        return lp->qur_sum(a,b)+rp->qur_sum(a,b);
    }

};

seg s;

void initialise(int N, int Q, int h[]) {
    s=seg(1,N+1);

    for(int i=1; i<=N; i++)
        s.upd(i,h[i]),where[h[i]].insert(i);
}

void cut(int l, int r, int k) {

    while (k--) {
        int mx = s.qur_mx(l, r + 1), p = *where[mx].lower_bound(l);

        if(!mx)break;
        where[mx].erase(p);
        where[max(0, mx - 1)].insert(p);

        s.upd(p, max(0, mx - 1));

    }
}
void magic(int i, int x) {
    where[s.qur_mx(i,i+1)].erase(i);
    s.upd(i,x);
    where[x].insert(i);
}
long long int inspect(int l, int r) {
    return s.qur_sum(l,r+1);
}