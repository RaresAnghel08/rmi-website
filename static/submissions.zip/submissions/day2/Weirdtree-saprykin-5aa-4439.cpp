/**
* user:  saprykin-5aa
* fname: Maxim
* lname: Saprykin
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 07:53:27.689276
*/
#include "bits/stdc++.h"
#include "weirdtree.h"

using namespace std;
typedef long long ll;
#define vec vector
struct Node {
    ll sm, mx, imx;
};
class SegTree {
    int n;
    vec<Node> t;
    vec<ll> a;
    Node mrg(Node a, Node b) {
        Node nd;
        nd.sm = a.sm + b.sm;
        if (a.mx == b.mx) {
            nd.mx = a.mx;
            if (a.imx < b.imx) {
                nd.imx = a.imx;
            } else {
                nd.imx = b.imx;
            }
        } else if (a.mx > b.mx) {
            nd.mx = a.mx;
            nd.imx = a.imx;
        } else {
            nd.mx = b.mx;
            nd.imx = b.imx;
        }
        return nd;
    }
    
    void build(int v, int l, int r) {
        if (l == r - 1) {
            t[v] = {a[l], a[l], l};
            return;
        }
        int m = (r + l ) /2;
        build(2 * v + 1, l, m);
        build(2 * v + 2, m, r);
        t[v] = mrg(t[2 * v + 1], t[2 * v + 2]);
    }
    void set(int v, int l, int r,int i, int x) {
        if (l == r - 1) {
            a[l] = x;
            t[v] = {x, x, l};
            return;
        }
        int m = (r + l) / 2;
        if (i < m) {
            set(2 * v + 1, l, m, i, x);
        } else {
            set(2 * v + 2, m, r, i, x);
        }
        t[v] = mrg(t[2 * v + 1], t[2 * v + 2]);
    }
    Node get(int v, int l, int r, int L, int R) {
        if (L <= l && r <= R) {
            return t[v];
        }
        if (R <= l || r <= L) {
            return {0, 0, 0};
        }
        int m = (r + l) / 2;
        Node x = get(2 * v + 1, l, m, L, R);
        Node y = get(2 * v + 2, m, r, L, R);
        return mrg(x, y);
        
    }
public:
    void rebuild(vec<ll> &a) {
        this->a = a;
        n = a.size();
        t.resize(4 * n);
        build(0, 0, n);
    }
    void cut(int l, int r, int k) {
        assert(k == 1);
        Node nd = get(0, 0, n, l - 1, r);
        if (nd.mx == 0) return;
        set(0, 0, n, nd.imx, nd.mx - 1);
    }
    void magic(int i, int x) {
        set(0, 0, n, i - 1, x);
    }
    ll get(int l, int r){
        Node nd = get(0, 0, n, l - 1, r);
        return nd.sm;
    }
};
int n;
SegTree sg;
void initialise(int N, int Q, int h[]) {
    n = N;
    vec<ll> a(n);
    for (int i = 0; i < n; ++i) {
        a[i] = h[i + 1];
    }
    sg.rebuild(a);
}
void cut(int l, int r, int k) {
    sg.cut(l, r, k);
}
void magic(int i, int x) {
    sg.magic(i, x);
}
long long int inspect(int l, int r) {
    return sg.get(l, r);
}
