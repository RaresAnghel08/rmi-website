/**
* user:  fylypiuk-6b6
* fname: Andrii
* lname: Fylypiuk
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:04:45.648162
*/
#pragma GCC optimize("Ofast")
#include <bits/stdc++.h>
using namespace std;
typedef int ll;
#define x first
#define y second
typedef pair<ll, ll> pll;
const ll inf = 0x3fff3fff3fff3fff;
const ll N = 1e5+22;

struct edge{
    ll to, len;
    edge(ll to, ll len) : to(to), len(len) {}
};

vector<edge*> d[N];
pair<ll, edge*> par[N];

ll tin[N], rtin[N], tout[N], timer=0, a[N], w[N*4];
pll t[N*4];

void do_order(ll v, ll p){
    rtin[timer]=v;
    tin[v]=timer++;
    for(auto i : d[v]){
        if(i->to==p) continue;
        a[i->to] = a[v]+i->len;
        par[i->to] = {v, i};
        do_order(i->to, v);
    }
    tout[v]=timer;
}
void build(ll v, ll tl, ll tr){
    w[v]=0;
    if(tl+1==tr){
        t[v] = {a[rtin[tl]], tl};
        return;
    }
    ll tm = (tl+tr)>>1;
    build(v+v+1, tl, tm);
    build(v+v+2, tm, tr);
    t[v]=max(t[v+v+1], t[v+v+2]);
}
void seginc(ll v, ll tl, ll tr, ll ql, ll qr, ll qx){
    if(tl>=ql&&tr<=qr){
        w[v]+=qx;
        t[v].x+=qx;
        return;
    }
    if(w[v]){
        t[v+v+1].x += w[v];
        w[v+v+1] += w[v];
        t[v+v+2].x += w[v];
        w[v+v+2] += w[v];
        w[v]=0;
    }
    ll tm = (tl+tr)>>1;
    if(tl<qr && ql<tm) seginc(v+v+1, tl, tm, ql, qr, qx);
    if(tm<qr && ql<tr) seginc(v+v+2, tm, tr, ql, qr, qx);
    t[v]=max(t[v+v+1], t[v+v+2]);
}

int main(){
    cin.tie(0);cout.tie(0);ios_base::sync_with_stdio(0);
    ll n, k;
    cin >> n >> k;
    for(ll i = 1;i<n;i++){
        ll a, b, c;
        cin >> a >> b >> c;
        --a, b--;
        edge *tb = new edge(b, c);
        edge *ta = new edge(a, c);
        d[a].push_back(tb);
        d[b].push_back(ta);
    }
    for(ll root=0;root<n;root++){
        par[root]={-1, nullptr};
        a[root]=0;
        timer=0;
        do_order(root, -1);
        build(0, 0, n);
        ll res=0;
        for(ll it=0;it<k && t[0].x;it++){
            res+=t[0].x;
            ll v = rtin[t[0].y];
            while(par[v].y){
                seginc(0, 0, n, tin[v], tout[v], -par[v].y->len);
                par[v].y=nullptr;
                v = par[v].x;
            }
        }
        cout<<res<<'\n';
    }
}

