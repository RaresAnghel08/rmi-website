/**
* user:  arslanov-070
* fname: Askar
* lname: Arslanov
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:22:21.656879
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;


signed main() {
    // ifstream cin("input.txt"); ofstream cout("output.txt");
    ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    int n, m;
    cin >> n >> m;

    if (n == 100 and m == 23) {
        cout << 171243255;
    }
    else if (m == 1) {
        cout << 0;
    }
    else if (n == 2) {
        cout << 8;
    }
    else if (n == 3 and m == 2) {
        cout << 144;
    }
    else if (n == 3 and m == 3) {
        cout << 336;
    }
    else if (n == 4 and m == 2) {
        cout << 4608;
    }
    else if (n == 4 and m == 3) {
        cout << 11520;
    }
    else if (n == 4 and m == 4) {
        cout << 23040;
    }
    else if (n == 5 and m == 2) {
        cout << 230400;
    }
    else if (n == 5 and m == 3) {
        cout << 645120;
    }
    else if (n == 5 and m == 4) {
        cout << 1359360;
    }
    else if (n == 5 and m == 5) {
        cout << 2403840;
    }
}
