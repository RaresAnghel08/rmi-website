/**
* user:  tatarinova-7c8
* fname: Yuliia
* lname: Tatarinova
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:35:49.878467
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
long long mas[300006];
long long n;
pair<long long, long long> mas1[3000006];
void initialise(int N, int Q, int h[]) {
	for(int i=1; i<=N; i++)
        mas[i-1]=h[i];
        n=N;
}
void cut(int l, int r, int k) {
    l--;
    for(int i=l; i<r; i++)
        {mas1[i].first=mas[i];
        mas1[i].second=i;}

    sort(mas1+l, mas1+r);
    reverse(mas1+l, mas1+r);
    long long h=r, k1=k;
    for(int i=l+1; i<r; i++)
      if(k<(i-l)*(mas1[i-1].first-mas1[i].first))
            {
               // cout<<(i-l)*(mas1[i-1].first-mas1[i].first)<<' ';
                h=i;
                break;
            } else
            {
                k-=(i-l)*(mas1[i-1].first-mas1[i].first);
            }

 //  cout<<h<<'\n';
    for(int i=l; i<h; i++)
    {
        k1-=mas1[i].first-mas1[h-1].first;
        mas1[i].first=mas1[h-1].first;
    }
    long long d=k1/(h-l);
    for(int i=l; i<h; i++)
    {
        k1-=d;
        mas1[i].first-=d;
        if(mas1[i].first<0) mas1[i].first=0;
    }
    sort(mas1+l, mas1+h);
    for(int i=l; i<l+k1; i++)
    {
        mas1[i].first--;
        if(mas1[i].first<0) mas1[i].first=0;
    }
    for(int i=l; i<r; i++)
    {
        mas[mas1[i].second]=mas1[i].first;
    }

   // for(int i=0; i<n; i++)
  //      cout<<mas[i]<<' ';
  //  cout<<'\n';
}
void magic(int i, int x) {
	mas[i-1]=x;
}
long long int inspect(int l, int r) {
	long long s=0;
	for(int i=l-1; i<r; i++)
        s+=mas[i];
	return s;
}
