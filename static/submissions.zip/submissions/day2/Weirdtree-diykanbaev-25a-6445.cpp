/**
* user:  diykanbaev-25a
* fname: Talant
* lname: Diykanbaev
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:53:25.443178
*/
//~ #include "weirdtree.h"
#include "grader2.cpp"
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;

#define pb push_back
#define mp make_pair
#define sz(v) (int)v.size()
#define all(v) v.begin(), v.end()

const int N = 3e5+7;

struct node {
    ll sum;
    ll val;
    int ind;
} tree[N*4];

node combine(node a, node b) {
    node res;
    res.sum = a.sum+b.sum;
    if (a.val >= b.val) {
        res.val = a.val;
        res.ind = a.ind;
    }
    else {
        res.val = b.val;
        res.ind = b.ind;
    }
    return res;
}

void update(int v, int l, int r, int pos, ll val) {
    if (l == r) {
        tree[v].sum += val;
        tree[v].val += val;
        return;
    }
    int mid = (l+r) >> 1;
    if (pos <= mid) update(v*2, l, mid, pos, val);
    else update(v*2+1, mid+1, r, pos, val);
    tree[v] = combine(tree[v*2], tree[v*2+1]);
}

node get(int v, int l, int r, int ql, int qr) {
    if (ql > r || l > qr) {
        node tmp;
        tmp.sum = 0;
        tmp.val = 0;
        tmp.ind = l;
        return tmp;
    }
    if (ql <= l && r <= qr) return tree[v];
    int mid = (l+r) >> 1;
    return combine(get(v*2, l, mid, ql, qr), get(v*2+1, mid+1, r, ql, qr));
}

int n;
const int MAXN = 1e5+7;
int a[MAXN];

void initialise(int N, int Q, int h[]) {
	n = N;
    for (int i = 1; i <= n; i++) {
        a[i] = h[i];
        update(1, 1, n, i, a[i]);
    }
}
void cut(int l, int r, int k) {
    auto ans = get(1, 1, n, l, r);
    a[ans.ind]--;
    update(1, 1, n, ans.ind, -1);
}
void magic(int i, int x) {
    update(1, 1, n, i, x-a[i]);
}
long long int inspect(int l, int r) {
    
	return get(1, 1, n, l, r).sum;
}
