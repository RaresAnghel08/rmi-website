/**
* user:  myskiv-a26
* fname: Vladyslav
* lname: Myskiv
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 11:57:18.100455
*/
#include <bits/stdc++.h>

using namespace std;

vector<int> H;
vector<int> tmax;
vector<long long> tsum;

int n, it, nw, cnt;

long long sum;

void BuildMax(vector<int> &t, vector<int> &h, int v, int tl, int tr){
    if(tl==tr){
        t[v]=h[tl];
        return;
    }
    int tm=(tl+tr)>>1;
    BuildMax(t, h, 2*v+1, tl, tm);
    BuildMax(t, h, 2*v+2, tm+1, tr);
    t[v]=max(t[2*v+1], t[2*v+2]);
    return;
}

void BuildSum(vector<long long> &t, vector<int> &h, int v, int tl, int tr){
    if(tl==tr){
        t[v]=h[tl];
        return;
    }
    int tm=(tl+tr)>>1;
    BuildSum(t, h, 2*v+1, tl, tm);
    BuildSum(t, h, 2*v+2, tm+1, tr);
    t[v]=t[2*v+1]+t[2*v+2];
    return;
}

pair<int, int> get_max(vector<int> &t, int v, int tl, int tr, int L, int R){
    if(tr<L || R<tl) return{-1, -1};
    if(L<=tl && tr<=R){
        if(tl==tr) return {t[v], tl};
        int tm=(tl+tr)>>1;
        if(t[2*v+1]==t[v]) return get_max(t, 2*v+1, tl, tm, L, R);
        else return get_max(t, 2*v+2, tm+1, tr, L, R);
    }
    int tm=(tl+tr)>>1;
    pair<int, int> mx1=get_max(t, 2*v+1, tl, tm, L, R);
    pair<int, int> mx2=get_max(t, 2*v+2, tm+1, tr, L, R);
    if(mx1.first==-1) return mx2;
    if(mx2.first==-1) return mx1;
    if(mx1.first>mx2.first) return mx1;
    if(mx2.first>mx1.first) return mx2;
    return mx1;
}

long long get_sum(vector<long long> &t, int v, int tl, int tr, int L, int R){
    if(tr<L || R<tl) return 0;
    if(L<=tl && tr<=R) return t[v];
    int tm=(tl+tr)>>1;
    long long sum1=get_sum(t, 2*v+1, tl, tm, L, R);
    long long sum2=get_sum(t, 2*v+2, tm+1, tr, L, R);
    return sum1+sum2;
}

void updatemax(vector<int> &t, int v, int tl, int tr, int x, int val){
    if(tr<x || x<tl) return;
    if(tl==tr){
        t[v]=val;
        return;
    }
    int tm=(tl+tr)>>1;
    updatemax(t, 2*v+1, tl, tm, x, val);
    updatemax(t, 2*v+2, tm+1, tr, x, val);
    t[v]=max(t[2*v+1], t[2*v+2]);
    return;
}


void updatesum(vector<long long> &t, int v, int tl, int tr, int x, int val){
    if(tr<x || x<tl) return;
    if(tl==tr){
        t[v]=val;
        return;
    }
    int tm=(tl+tr)>>1;
    updatesum(t, 2*v+1, tl, tm, x, val);
    updatesum(t, 2*v+2, tm+1, tr, x, val);
    t[v]=t[2*v+1]+t[2*v+2];
    return;
}

void initialise(int N, int Q, int h[]) {
    n=N;
    tmax.resize(4*N+3);
    tsum.resize(4*N+3);
    H.resize(N+1);
    for(int i=1; i<=N; i++) H[i]=h[i];
    BuildMax(tmax, H, 0, 1, N);
    BuildSum(tsum, H, 0, 1, N);
    return;
}


void cut(int l, int r, int k) {
    vector<int> vec;
    vector<int> ch;
    for(int i=l; i<=r; i++){
        vec.push_back(get_sum(tsum, 0, 1, n, i, i));
        ch.push_back(vec[i-l]);
    }
    sort(vec.begin(), vec.end());
    reverse(vec.begin(), vec.end());
    cnt=0;
    if(vec[0]==vec[r-l]){
        cnt=r-l+1;
        if(cnt*vec[0]<=k){
            for(int i=l; i<=r; i++){
                updatemax(tmax, 0, 1, n, i, 0);
                updatesum(tsum, 0, 1, n, i, 0);
            }
            return;
        }
        nw=k/cnt;
        cnt=k%cnt;
        for(int i=l; i<=r; i++){
            if(i-l+1<=cnt){
                updatemax(tmax, 0, 1, n, i, max(0, vec[0]-nw-1));
                updatesum(tsum, 0, 1, n, i, max(0, vec[0]-nw-1));
            }
            else{
                updatemax(tmax, 0, 1, n, i, vec[0]-nw);
                updatesum(tsum, 0, 1, n, i, vec[0]-nw);
            }
        }
        return;
    }
    if(k>=get_sum(tsum, 0, 1, n, l, r)){
        for(int i=l; i<=r; i++){
            updatemax(tmax, 0, 1, n, i, 0);
            updatesum(tsum, 0, 1, n, i, 0);
        }
        return;
    }
    sum=0;
    it=0;
    for(int i=0; i<r-l+1; i++){
        cnt=i+1;
        if(vec[i]==vec[r-l]){
            cnt=i;
            it=vec[i];
            break;
        }
        sum+=vec[i];
        if(vec[i]==vec[i+1]) continue;
        if(sum-cnt*vec[i+1]>=k){
            it=vec[i];
            break;
        }
    }
    k-=sum-cnt*it;
    cnt=0;
    for(int i=0; i<r-l+1; i++){
        if(vec[i]>=it) cnt++;
    }
    int nw=k/cnt;
    cnt=k%cnt;
    for(int i=l; i<=r; i++){
        long long val=ch[i-l];
        if(val<it) continue;
        if(cnt>0){
            updatemax(tmax, 0, 1, n, i, it-nw-1);
            updatesum(tsum, 0, 1, n, i, it-nw-1);
            cnt--;
        }
        else{
            updatemax(tmax, 0, 1, n, i, it-nw);
            updatesum(tsum, 0, 1, n, i, it-nw);
        }
    }
    return;
}


void magic(int i, int x) {
    updatemax(tmax, 0, 1, n, i, x);
    updatesum(tsum, 0, 1, n, i, x);
	return;
}


long long int inspect(int l, int r) {
	return get_sum(tsum, 0, 1, n, l, r);
}
