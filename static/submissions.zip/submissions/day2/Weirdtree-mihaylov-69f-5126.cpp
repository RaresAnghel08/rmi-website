/**
* user:  mihaylov-69f
* fname: Miroslav Milenov
* lname: Mihaylov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:03:28.517239
*/
#include <iostream>
#include <algorithm>
#include <limits.h>
using namespace std;

int Heigths[300010];
int N,Q;

struct Node
{
	Node *l,*r;
	int from,to;
	int Max;
	long long Sum;
	int lp;

	Node(int f,int t)
	{
		from=f;
		to=t;
		l=NULL;
		r=NULL;
	}
	void SetV(int V)
	{
		Sum=V;
		Max=V;
	}
}*root;

void PrintLeafs(Node* node)
{
	if(node==NULL)return;
	if(node->from==node->to)cout<<node->Max<<" ";
	PrintLeafs(node->l);
	PrintLeafs(node->r);
}
void Build(Node* node, int from, int to)
{
	
	if(from==to){node->SetV(Heigths[from]);return;}
	if(node->l==NULL)node->l=new Node(from,(from+to)/2);
	if(node->r==NULL)node->r=new Node((from+to)/2+1,to);
	Build(node->l,from,(from+to)/2);
	Build(node->r,(from+to)/2+1,to);
	node->Max=max(node->l->Max,node->r->Max);
	node->Sum=node->l->Sum+node->r->Sum;
}

void initialise ( int n , int q , int h [])
{
	for(int i=0;i<n;i++)
	Heigths[i]=h[i];
	N=n;
	Q=q;
	root=new Node(0,n-1);
	Build(root,0,n-1);
	cout<<"OK"<<endl;
}

int getMaxHeigth(Node* node,int l,int r)
{
	if(node==NULL)return INT_MIN;
	if(l>node->to)return INT_MIN;
	if(r<node->from)return INT_MIN;
	if(l<=node->from&&r>=node->to)return node->Max;
	int m1=getMaxHeigth(node->l,l,r);
	int m2=getMaxHeigth(node->r,l,r);
	return max(m1,m2);
}

bool CutHeighest(Node* node,int l,int r,int MAX)
{
	if(node==NULL)return false;
	if(l>node->to)return false;
	if(r<node->from)return false;
	if(l<=node->from&&r>=node->to)
	{
		if(node->Max==MAX)
		{
			if(node->from==node->to)
			{
				node->Max--;
				return true;
			}
			bool b=CutHeighest(node->l,l,r,MAX);
			if(!b)b=CutHeighest(node->r,l,r,MAX);
			if(b)
			{
				node->Max=max(node->l->Max,node->r->Max);
				node->Sum=node->l->Sum+node->r->Sum;
			}
			return b;
		}
		else return false;
	}
	if(node->Max<MAX)return false;
	bool b=CutHeighest(node->l,l,r,MAX);
	if(!b)b=CutHeighest(node->r,l,r,MAX);
	if(b)
	{
		node->Max=max(node->l->Max,node->r->Max);
		node->Sum=node->l->Sum+node->r->Sum;
	}
	return b;
			
}

void cut ( int l , int r , int k )
{
	for(int i=0;i<k;i++)
	{
		int m=getMaxHeigth(root,l,r);
//		cout<<"------"<<m<<"--------"<<endl;
 		CutHeighest(root,l,r,m);
 		PrintLeafs(root);
		cout<<endl;
	}
}

void magic ( int i , int x )
{
	
}

long long int inspect ( int l , int r )
{
	
}

void Print(Node* node,int depth)
{
	if(node==NULL)return;
	for(int i=0;i<depth;i++)cout<<"             ";
	cout<<node->from<<"-"<<node->to<<endl;
	for(int i=0;i<depth;i++)cout<<"             ";
	cout<<node->Max<<"  "<<node->Sum<<endl;
	Print(node->l,depth+1);
	Print(node->r,depth+1);
	
}


int main()
{
	int a[100]={3,10,8,2,5,7,20,13,21,8,21,4,12,3,10,9};
	initialise(16,5,a);
//	Print(root,0);
	PrintLeafs(root);
	cout<<endl;
	cut(5,12,30);

	Print(root,0);
}