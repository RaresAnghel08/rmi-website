/**
* user:  koynov-b21
* fname: Daniel Iliev
* lname: Koynov
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:49:37.740813
*/
#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
typedef long long ll;
const int maxn = 20;
void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}

int n, m, used[maxn], last[maxn], ans, p[maxn];
///25920
void check()
{
    for (int i = 1; i <= 2 * n; i ++)
        for (int j = i + 1; j <= 2 * n; j ++)
        {
            if (abs(p[i] - p[j]) != n)
                continue;
            if ((j - i) % m == 0)
                return;
        }
    ans ++;
}
void brute(int pos)
{
    if (pos == 2 * n + 1)
    {
        check();
    }
    else
    {
        for (int i = 1; i <= 2 * n; i ++)
        {
            if (!used[i])
            {
                used[i] = 1;
                p[pos] = i;
                brute(pos + 1);
                used[i] = 0;
                p[pos] = i;
            }
        }
    }

}
void solve()
{
    cin >> n >> m;
    brute(1);
    cout << ans << endl;
}

int main()
{
    solve();
    return 0;
}
