/**
* user:  greaca-04d
* fname: Albert Antoniu
* lname: Greaca
* task:  Paths
* score: 19.0
* date:  2021-12-17 09:01:24.712426
*/
#include<bits/stdc++.h>
#define ll long long
using namespace std;
vector<pair<int,int>>g[100005];
ll dp[1005][105];
int k;
void dfs(int nod,int t)
{
    for(auto it:g[nod])
        if (it.first!=t)
            dfs(it.first,nod);
    int i,j;
    for(auto it:g[nod])
        if (it.first!=t)
            for(i=k;i>=1;i--)
                for(j=1;j<=i;j++)
                    dp[nod][i]=max(dp[nod][i],dp[nod][i-j]+dp[it.first][j]+it.second);
}
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    int n,i,x,y,w;
    scanf("%d%d",&n,&k);
    for(i=1;i<n;i++){
        scanf("%d%d%d",&x,&y,&w);
        g[x].push_back(make_pair(y,w));
        g[y].push_back(make_pair(x,w));
    }
    for(i=1;i<=n;i++){
        memset(dp,0,sizeof(dp));
        dfs(i,0);
        printf("%lld\n",dp[i][k]);
    }
return 0;
}
