/**
* user:  stepanov-b9e
* fname: Anton
* lname: Stepanov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:13:04.731668
*/
#pragma GCC optimize("Ofast")


#include "weirdtree.h"


#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <array>
#include <cassert>
#include <set>
#include <map>
#include <deque>
#include <random>


using namespace std;


#define ll long long
#define ld long double
#define flt double
#define pb push_back
#define emb emplace_back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()


const ll inf = 1e18;


struct SGT {
	struct node {
		ll mx1;
		ll c;
		ll mx2;
		ll sm;
		ll d;

		node() : mx1(-inf), c(0), mx2(-inf - 1), sm(0), d(inf) {}
		node(ll x) : mx1(x), c(1), mx2(-inf), sm(x), d(inf) {}


		inline void apply(ll x) {
			if (x >= mx1) {
				return;
			}
			sm -= c * (mx1 - x);
			mx1 = x;
			d = x;
		}
	};


	inline void mrg(const node& n1, const node& n2, node& res) {
		res.sm = n1.sm + n2.sm;
		res.d = inf;
		if (n1.mx1 > n2.mx1) {
			res.mx1 = n1.mx1;
			res.c = n1.c;
			res.mx2 = max(n1.mx2, n2.mx1);
		} else if (n2.mx1 > n1.mx1) {
			res.mx1 = n2.mx1;
			res.c = n2.c;
			res.mx2 = max(n2.mx2, n1.mx1);
		} else {
			res.mx1 = n1.mx1;
			res.c = n1.c + n2.c;
			res.mx2 = max(n1.mx2, n2.mx2);
		}
		return;
	}


	int n;
	vector<node> t;


	inline void upd(int v) {
		mrg(t[v + v], t[v + v + 1], t[v]);
	}

	inline void push(int v) {
		t[v + v].apply(t[v].d);
		t[v + v + 1].apply(t[v].d);
		t[v].d = inf;
	}


	inline void build(vector<ll>& a) {
		n = 1;
		while (n < a.size()) {
			n *= 2;
		}
		t.assign(n + n, node());
		for (int i = 0; i < a.size(); ++i) {
			t[i + n] = node(a[i]);
		}
		for (int i = n - 1; i > 0; --i) {
			upd(i);
		}
		return;
	}


	void set(int v, int tl, int tr, int i, ll x) {
		if (tl == tr) {
			t[v] = node(x);
			return;
		}
		ll tm = (tl + tr) / 2;
		push(v);
		if (i <= tm) {
			set(v + v, tl, tm, i, x);
		} else {
			set(v + v + 1, tm + 1, tr, i, x);
		}
		upd(v);
	}


	inline void set(int i, ll x) {
		set(1, 0, n - 1, i, x);
	}


	void mnmz(int v, int tl, int tr, int l, int r, ll x, ll& k) {
		if (tr < l || r < tl || k <= 0 || t[v].mx1 <= x) {
			return;
		}
		if (l <= tl && tr <= r && t[v].mx2 < x && t[v].c * (t[v].mx1 - x) <= k) {
			k -= t[v].c * (t[v].mx1 - x);
			t[v].apply(x);
			return;
		}
		if (v >= n) {
			return;
		}
		ll tm = (tl + tr) / 2;
		push(v);
		mnmz(v + v, tl, tm, l, r, x, k);
		mnmz(v + v + 1, tm + 1, tr, l, r, x, k);
		upd(v);
	}


	inline void mnmz(int l, int r, ll x, ll& k) {
		mnmz(1, 0, n - 1, l, r, x, k);
	}


	node get(int v, int tl, int tr, int l, int r) {
		if (tr < l || r < tl) {
			return node();
		}
		if (l <= tl && tr <= r) {
			return t[v];
		}
		ll tm = (tl + tr) / 2;
		push(v);
		node res;
		mrg(get(v + v, tl, tm, l, r), get(v + v + 1, tm + 1, tr, l, r), res);
		return res;
	}


	inline node get(int l, int r) {
		return get(1, 0, n - 1, l, r);
	}

	inline void get_down(int l, int r, ll& k) {
		while (k > 0) {
			auto nd = get(l, r);
			ll mx1 = nd.mx1;
			if (mx1 == 0) {
				return;
			}
			ll c = nd.c;
			ll mx2 = nd.mx2;
			if ((mx1 - mx2) * c <= k) {
				mnmz(l, r, max((ll)(0), mx2), k);
				continue;
			}
			mnmz(l, r, max((ll)(0), mx1 - (k / c)), k);
			mx1 -= (k / c);
			mnmz(l, r, max((ll)(0), mx1 - 1), k);
			return;
		}
	}
};


int n, q;
SGT sgt;
vector<ll> a;


void initialise(int N, int Q, int h[]) {
	n = N;
	q = Q;
	a.resize(n);
	for (int i = 0; i < n; ++i) {
		a[i] = h[i + 1];
	}
	sgt.build(a);
}


void cut(int l, int r, int k) {
	l -= 1;
	r -= 1;
	ll mk = k;
	sgt.get_down(l, r, mk);
}


void magic(int i, int x) {
	i -= 1;
	sgt.set(i, x);
}



ll inspect(int l, int r) {
	l -= 1;
	r -= 1;
	
	return sgt.get(l, r).sm;
}
