/**
* user:  badea-bb4
* fname: Lucian Andrei
* lname: Badea
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 09:18:31.904535
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
using namespace std;

const int NMAX = 3e5;
const int INF = 1e9 + 7;

struct hatz {
    long long e, pozmax;
};

long long v[NMAX], lstart, rstart, nn;
long long sss;
long long stg;
long long aib[NMAX + 1], len;

hatz aint[4 * NMAX + 1];

void build(long long n) {
    nn = 1;
    while(nn <= n)
        nn *= 2;
    for(long long i = n; i < nn; i++)
        v[i] = -INF;
    for(long long i = nn - 1; i < 2 * nn - 1; i++)
        aint[i] = {v[i - nn + 1], i - nn + 1};
    for(long long i = nn - 2; i >= 0; i--) {
        if(aint[2 * i + 1].e > aint[2 * i + 2].e)
            aint[i] = aint[2 * i + 1];
        else
            aint[i] = aint[2 * i + 2];
    }
//    cout << "nn = " << nn << endl;
//    for(int i = 0; i < 2 * nn - 1; i++)
//        cout << aint[i].e << ' ';
//    cout << endl;
}

void update(long long val, long long poz) {
    hatz x;
    v[poz] = val;
    poz += nn - 1;
    aint[poz] = {val, poz - nn + 1};
    while(poz) {
        if(poz % 2 == 0) {
            if(aint[poz].e > aint[poz - 1].e)
                x = aint[poz];
            else
                x = aint[poz - 1];
        } else {
            if(aint[poz].e > aint[poz + 1].e)
                x = aint[poz];
            else
                x = aint[poz + 1];
        }
        aint[(poz - 1) / 2] = x;
        poz = (poz - 1) / 2;
    }
}

long long maxx, pozz;

void maximum(long long node, long long st, long long dr) {
    if(st > rstart || dr < lstart)
        return;
    else if(st >= lstart && dr <= rstart) {
        if(aint[node].e > maxx)
            maxx = aint[node].e, pozz = aint[node].pozmax;
    } else {
        int mij = (st + dr) / 2;
        maximum(node * 2 + 1, st, mij);
        maximum(node * 2 + 2, mij + 1, dr);
    }
}

void update_aib(long long poz, long long val) {
    while(poz <= len) {
        aib[poz] += val;
        poz += (poz & (-poz));
    }
}

long long sum(long long poz) {
    long long s = 0;
    while(poz) {
        s += aib[poz];
        poz -= (poz & (-poz));
    }
    return s;
}


void initialise(int N, int Q, int h[]) {
    len = N;
    for(int i = 1; i <= N; i++)
        aib[i] = 0;
    sss = 0;
    for(int i = 1; i <= N; i++) {
        sss += h[i];
        v[i - 1] = h[i];
        update_aib(i, v[i - 1]);
    }
    build(N);
//    for(int i = 1; i <= len; i++)
//        cout << aib[i] << ' ';
//    cout << endl;
}

void cut(int l, int r, int k) {
    if(l == 1 && r == len) {
        sss = max(sss - k, 0LL);
    } else {
        maxx = 1;
        while(k && maxx > 0) {
            maxx = pozz = -1;
            lstart = l - 1;
            rstart = r - 1;
            maximum(0, 0, nn - 1);
            //cout << maxx << ' ' << pozz << endl;
            if(maxx) {
                update(v[pozz] - 1, pozz);
                /*for(int i = 0; i < 2 * nn - 1; i++)
                    cout << aint[i].e << ' ';
                cout << endl;*/
                update_aib(pozz + 1, -1);

            }
            k--;
        }
    }
}

void magic(int i, int x) {
    long long val = v[i - 1];
    long long xx = x;
    update(xx, i - 1);
    update_aib(i, xx - val);
    sss = sss - val + x;
//    cout << "aib" << endl;
//    for(int i = 1; i <= len; i++)
//        cout << aib[i] << ' ';
//    cout << endl;
}

long long int inspect(int l, int r) {
//    cout << "aib" << endl;
//    for(int i = 1; i <= len; i++)
//        cout << aib[i] << ' ';
//    cout << endl;
    if(l == 1 && r == len)
        return sss;
    return sum(r) - sum(l - 1);
}
