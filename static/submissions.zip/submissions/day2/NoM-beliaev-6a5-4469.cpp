/**
* user:  beliaev-6a5
* fname: Vladislav
* lname: Beliaev
* task:  NoM
* score: 0.0
* date:  2021-12-17 07:57:11.188674
*/
#include <iostream>
#include <vector>
#include <map>

using namespace std;

typedef long long ll;

/*vector<ll> v;
ll q = 0 , n;

ll t[4 * 300001], q = 0, tc[4 * 300001];

void build(int v, int tl, int tr, int a[]) {
	if (tl == tr) {
		t[v] = a[tl];
	}
	else {
		int tm = (tl + tr) / 2;
		build(v * 2, tl, tm, a);
		build(v * 2 + 1, tm + 1, tr , a);
		t[v] = t[v * 2 + 1] + t[v * 2];
	}
}

void initialise(int N, int Q, int h[]) {
	v.resize(N);
	q = Q;
	n = N;
	for (int i = 0; i < N; i++) {
		v[i] = h[i + 1];
	}
}

void cut(int l, int r, int k) {
	l--; r--;
	while (k > 0) {
		ll mx = -1, mxi = 0;
		for (int i = l; i <= r; i++) {
			if (mx < v[i]) {
				mx = v[i];
				mxi = i;
			}
		}
		if(mx > 0)
			v[mxi] -= 1;
		k--;
	}
}

void magic(int i, int x) {
	i--;
	v[i] = x;
}

ll inspect(int l, int r) {
	l--; r--;
	ll sum = 0;
	for (int i = l; i <= r; i++) {
		sum += v[i];
	}
	return sum;
}*/

vector<ll> v;
map<ll, ll> mp;
ll n, m;
ll cnt = 0;

void rek(ll k) {
	if (k == n * 2) {
		bool flag = true;
		for (int i = 0; i < n * 2; i++) {
			for (int j = i + 1; j < n * 2; j++) {
				if (v[i] == v[j] && (j - i) % m == 0) {
					flag = false;
				}
			}
		}
		if (flag) {
			cnt++;
		}
		return;
	}
	for (int i = 1; i <= n; i++) {
		if (mp[i] < 2) {
			mp[i] ++;
			v.push_back(i);
			rek(k + 1);
			v.pop_back();
			mp[i]--;
		}
	}
}

int main() {
	cin >> n >> m;
	rek(0);
	cout << cnt << endl;
	return 0;
}