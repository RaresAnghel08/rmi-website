/**
* user:  magirescu-396
* fname: Tudor Stefan
* lname: Magirescu
* task:  Paths
* score: 19.0
* date:  2021-12-17 08:51:27.252517
*/
#include <iostream>
#include <vector>
#define NMAX 100000
#define f first
#define s second
#define ll long long

using namespace std;

vector <pair <int, ll> > nod[NMAX+10];
int tata[NMAX+10], n, k, idxLeaf;
ll sus[NMAX+10], sum[NMAX+10], maxLeaf;

void dfsInit(int x, int p = 0){
    tata[x] = p;
    for(auto u : nod[x])
        if(u.f != p){
            sus[u.f] = u.s;
            dfsInit(u.f, x);
        }
}

void dfs(int x, int p = 0, ll cost = 0){
    sum[x] = cost;
    for(auto u : nod[x])
        if(u.f != p){
            dfs(u.f, x, max(0LL, sus[u.f]) + cost);
        }
    if(nod[x].size() == 1 && p){
        if(sum[x] > maxLeaf){
            maxLeaf = sum[x];
            idxLeaf = x;
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    cin >> n >> k;
    for(int i=1; i<n; i++){
        int nod1, nod2;
        ll cost;
        cin >> nod1 >> nod2 >> cost;
        nod[nod1].push_back({nod2, cost});
        nod[nod2].push_back({nod1, cost});
    }

    for(int root=1; root<=n; root++){
        sus[root] = 0;
        dfsInit(root);
        ll ans = 0;

        for(int i=1; i<=k; i++){
            maxLeaf = 0;
            idxLeaf = 1;

            dfs(root);

            ans += maxLeaf;

            while(tata[idxLeaf] && sus[idxLeaf] != -1){
                sus[idxLeaf] = -1;
                idxLeaf = tata[idxLeaf];
            }
        }

        cout << ans << '\n';
    }
    return 0;
}
