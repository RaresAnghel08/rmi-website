/**
* user:  slavchev-772
* fname: Yuliyan Radoslavov
* lname: Slavchev
* task:  Paths
* score: 48.0
* date:  2021-12-17 11:58:56.201930
*/
#include <iostream>
#include <vector>
using namespace std;
#define endl '\n'
#define MAXN 5005
#define NEWMAX 100005
#define int long long
int br, k;
vector<pair<int, int> > tree[NEWMAX];
vector<int> euler;
int u[MAXN], par[MAXN]; int way;
int posof[MAXN], from[MAXN], to[MAXN];
long long val[MAXN], ingo[MAXN];
void dfs1(int v, int p, long long sum, int edge)
{
    u[v] = way; par[v] = p; euler.push_back(v); from[v] = euler.size() - 1;
    val[v] = sum; ingo[v] = edge;
    for(pair<int, int> pa : tree[v]){
        int att = pa.first, c = pa.second;
        if(att == p) continue;
        dfs1(att, v, sum + c, c);
    }
    to[v] = euler.size() - 1;
}

int u2[NEWMAX], par2[NEWMAX], first[NEWMAX], second[NEWMAX], vfirst[NEWMAX], vsecond[NEWMAX], result[NEWMAX];
bool check(int v, int val, int att)
{
    if(val > first[v]){
        second[v] = first[v]; vsecond[v] = vfirst[v];
        first[v] = val; vfirst[v] = att;
        return true;
    }
    else if(val > second[v]){
        second[v] = val; vsecond[v] = att;
        return true;
    }
    else return false;
}
void dfs2(int v, int p, int sum)
{
    u2[v] = 1; par2[p] = p; first[v] = 0; second[v] = 0;
    for(pair<int, int> pa : tree[v]){
        int att = pa.first, c = pa.second;
        if(att == p) continue;
        dfs2(att, v, sum + c);
        bool b = check(v, first[att] + c, att);
        if(!b) check(v, second[att] + c, att);
    }
}

void dfs3(int v, int p, int edge)
{
    if(p != -1){
        if(vfirst[p] != v){
            check(v, first[p] + edge, p);
        }
        else{
            check(v, second[p] + edge, p);
        }
    }
    for(pair<int, int> pa : tree[v]){
        int att = pa.first, c = pa.second;
        if(att == p) continue;
        dfs3(att, v, c);
    }
}

long long segmval[4 * MAXN], lazy[4 * MAXN];
int segmidx[4 * MAXN];
void build(int idx, int from, int to)
{
    if(from > to) return;
    lazy[idx] = 0;
    if(from == to){
        segmval[idx] = val[euler[from]]; segmidx[idx] = from; return;
    }
    int mid = (from + to) / 2;
    segmval[2 * idx] = 0; lazy[2 * idx] = 0; segmidx[2 * idx] = 0;
    segmval[2 * idx] = 1; lazy[2 * idx] = 1; segmidx[2 * idx] = 1;
    build(2 * idx, from, mid); build(2 * idx + 1, mid + 1, to);
    if(segmval[2 * idx] > segmval[2 * idx + 1]){
        segmval[idx] = segmval[2 * idx]; segmidx[idx] = segmidx[2 * idx];
    }
    else{
        segmval[idx] = segmval[2 * idx + 1]; segmidx[idx] = segmidx[2 * idx + 1];
    }
    //cout << from << ' ' << to << ' ' << segmval[idx] << ' ' << segmidx[idx] << endl;
}

void fix(int idx, int from, int to)
{
    if(lazy[idx] == 0) return;
    segmval[idx] -= lazy[idx];
    if(from == to){
        lazy[idx] = 0; return;
    }
    lazy[2 * idx] += lazy[idx]; lazy[2 * idx + 1] += lazy[idx];
    lazy[idx] = 0;
}

void update(int idx, int from, int to, int l, int r, long long value)
{
    if(from > to) return;
    if(l > to || r < from) return;
    fix(idx, from, to);
    if(from >= l && to <= r){
        lazy[idx] += value;
        fix(idx, from, to); return;
    }
    int mid = (from + to) / 2;
    update(2 * idx, from, mid, l, r, value); update(2 * idx + 1, mid + 1, to, l, r, value);
    fix(2 * idx, from, mid); fix(2 * idx + 1, mid + 1, to);
    if(segmval[2 * idx] > segmval[2 * idx + 1]){
        segmval[idx] = segmval[2 * idx]; segmidx[idx] = segmidx[2 * idx];
    }
    else{
        segmval[idx] = segmval[2 * idx + 1]; segmidx[idx] = segmidx[2 * idx + 1];
    }
}

inline void solve5()
{
    dfs2(1, -1, 0);
    //for(int i = 1; i <= br; ++i){
    //    cout << first[i] << ' ' << vfirst[i] << ' ' << second[i] << ' ' << vsecond[i] << endl;
    //}
    //cout << "===========\n";
    dfs3(1, -1, 0);
    for(int i = 1; i <= br; ++i){
        cout << first[i] << endl;
    }
}

bool digit(char c)
{
    return c >= '0' && c <= '9';
}

int read()
{
    int res = 0;
    char c;
    do{
        c = getchar_unlocked();
    }
    while(!digit(c));
    do{
        res *= 10; res += (c - '0');
        c = getchar_unlocked();
    }
    while(digit(c));
    return res;
}
signed main()
{
    //ios_base::sync_with_stdio(false);
    //cin.tie(0); cout.tie(0);
   // cin >> br >> k;
   br = read(); k = read();
    for(int i = 0; i < br - 1; ++i){
        int from, to, c; //cin >> from >> to >>c;
        from = read(); to = read(); c = read();
        tree[from].push_back({to, c}); tree[to].push_back({from, c});
    }
    if(br > 2000){
    //if(true){ //
        solve5(); return 0;
    }
    for(int i = 1; i <= br; ++i){
        euler.clear(); ++way;
        dfs1(i, -1, 0, -1);
        for(int z = 0; z < euler.size(); ++z){
            posof[euler[z]] = z;
        }
        build(1, 0, br - 1);
        long long res = 0;
        for(int z = 0; z < k; ++z){
            //cout << "here " << segmval[1] << ' ' << segmidx[1] << endl;
            res += segmval[1]; int champ = euler[segmidx[1]];
            //cout << "HERE: " << res << ' ' << champ << endl;
            while(true){
                int rem = ingo[champ];
                if(rem == -1) break;
                //cout << rem << ' ' << from[champ] << ' ' << to[champ] << endl;
                if(rem != 0) update(1, 0, br - 1, from[champ], to[champ], rem);
                ingo[champ] = -1; champ = par[champ];
            }
        }
        cout << res << endl;
        //return 0; //
    }

    return 0;
}
