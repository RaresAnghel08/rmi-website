/**
* user:  palyn-40b
* fname: Stanislau
* lname: Palyn
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:08:41.088208
*/
#include <bits/stdc++.h>

#define fr(i, a, b) for(int i = (a); i <= (b); ++i)
#define rf(i, a, b) for(int i = (a); i >= (b); --i)
#define fe(x, y) for(auto& x : y)

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define mt make_tuple

#define sz(x) (int)(x).size()
#define all(x) (x).begin(), (x).end()
#define pw(x) (1LL << (x))

using namespace std;

#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;
template<typename T>
using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define fbo find_by_order
#define ook order_of_key

template<typename T>
bool umn(T& a, T b) { return (a > b ? (a = b, 1) : 0); }
template<typename T>
bool umx(T& a, T b) { return (a < b ? (a = b, 1) : 0); }

using ll = long long;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
template<typename T>
using ve = vector<T>;

const int N = 1e5 + 5;

int n, k;
ve<pii> g[N];
int cost[N], was[N];

ve<int> st;
int best;
ve<int> best_st;

void dfs(int v, int p, int dep) {
    if(umx(best, dep)) {
        best_st = st;
    }
    fe(to, g[v]) {
        if(to.fi == p) continue;
        st.pb(to.se);
        dfs(to.fi, v, dep + cost[to.se]);
        st.pop_back();
    }
}

int main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
#else
//    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
#endif

    cin >> n >> k;

    fr(i, 0, n - 2) {
        int x, y, c;
        cin >> x >> y >> c;
        x--;
        y--;
        g[x].pb({y, i});
        g[y].pb({x, i});
        cost[i] = c;
    }

    fr(i, 0, n - 2) was[i] = cost[i];

    fr(i, 0, n - 1) {
        fr(j, 0, n - 2) cost[j] = was[j];
        ll ans = 0;
        fr(j, 1, k) {
            best = -1;
            best_st.clear();
            dfs(i, i, 0);

            fe(x, best_st) cost[x] = 0;
            ans += best;
        }
        cout << ans << "\n";
    }

    return 0;
}
