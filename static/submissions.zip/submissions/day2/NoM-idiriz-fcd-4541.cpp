/**
* user:  idiriz-fcd
* fname: Nermin Hyusmen
* lname: Idiriz
* task:  NoM
* score: 9.0
* date:  2021-12-17 08:06:21.782541
*/
/// NoM
#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
const int MOD=1e9+7,MAXN=12;
void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}
int n,m;
int a[MAXN],cnt=0;
void check()
{
    /*for(int i=1; i<=2*n; i++)
        cout<<a[i]<<" ";
    cout<<endl;*/
    for(int i=1; i<=n; i++)
    {
        vector<int>v;
        for(int j=1; j<=2*n; j++)
            if(a[j]==i)v.push_back(j);
        //cout<<v[1]<<" "<<v[0]<<endl;
        if((v[1]-v[0])%m==0)return;
    }
    int add=1;
    for(int i=1; i<=n; i++)
    {
        add*=2;
        add%=MOD;
    }
    cnt+=add;
    cnt%=MOD;
}
int used[MAXN];
void gen(int pos)
{
    if(pos>2*n)
    {
        check();
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(used[i]<2)
        {
            a[pos]=i;
            used[i]++;
            gen(pos+1);
            used[i]--;
        }
    }
}
int main()
{
    speed();
    cin>>n>>m;
    gen(1);
    cout<<cnt<<endl;
    return 0;
}
