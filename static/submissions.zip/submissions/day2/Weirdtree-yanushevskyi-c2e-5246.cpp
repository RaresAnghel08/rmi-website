/**
* user:  yanushevskyi-c2e
* fname: Roman
* lname: Yanushevskyi
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:13:37.049367
*/
#include "weirdtree.h"
#include <cstdio>
#include <algorithm>

const int N = 300000;
int n;
struct item {
	long long sum;
	int mn, mx, upd;
	item() {}
	item(int x) {
		sum = x;
		mn = mx = x;
		upd = -1;
	}
	item operator+(item arg) {
		item res;
		res.sum = sum + arg.sum;
		res.mn = std::min(mn, arg.mn);
		res.mx = std::max(mx, arg.mx);
		res.upd = -1;
		return res;
	}
} t[N << 1];

void push(int v, int tl, int tr) 
{
}

int mxq(int l, int r, int v = 0, int tl = 0, int tr = n) 
{
	if (tl >= r || tr <= l) return 0;
	if (tl >= l && tr <= r) return t[v].mx;
	int m = tl + tr >> 1;
	return std::max(mxq(l, r, v + 1, tl, m), mxq(l, r, v + (tr - tl & ~1), m, tr));
}

bool update(int l, int r, int k, int v = 0, int tl = 0, int tr = n) 
{
	if (tl >= r || tr <= l) return 0;
	if (tl >= l && tr <= r && t[v].mx != k) return 0;
	if (tr - tl == 1) {
		if (t[v].mx == k) {
			t[v] = item(k - 1);
			return 1;
		}
		return 0;
	}
	int m = tl + tr >> 1;
	if (!update(l, r, k, v + 1, tl, m)) update(l, r, k, v + (tr - tl & ~1), m, tr);
	t[v] = t[v + 1] + t[v + (tr - tl & ~1)];
	return 1;
}

void build(int *a, int v = 0, int tl = 0, int tr = n) 
{
	if (tr - tl == 1) t[v] = item(a[tr]);
	else {
		int m = tl + tr >> 1;
		build(a, v + 1, tl, m);
		build(a, v + (tr - tl & ~1), m, tr);
		t[v] = t[v + 1] + t[v + (tr - tl & ~1)];
	}
}

void change(int i, int x, int v = 0, int tl = 0, int tr = n) 
{
	if (tr - tl == 1) t[v] = item(x);
	else {
		push(v, tl, tr);
		int m = tl + tr >> 1;
		if (i < m) change(i, x, v + 1, tl, m);
		else change(i, x, v + (tr - tl & ~1), m, tr);
		t[v] = t[v + 1] + t[v + (tr - tl & ~1)];
	}
}

long long sq(int l, int r, int v = 0, int tl = 0, int tr = n) 
{
	if (tl >= r || tr <= l) return 0;
	if (tl >= l && tr <= r) return t[v].sum;
	push(v, tl, tr);
	int m = tl + tr >> 1;
	return sq(l, r, v + 1, tl, m) + sq(l, r, v + (tr - tl & ~1), m, tr);
}

void initialise(int n_, int q, int *h) 
{
	n = n_;
	build(h);
}

void cut(int l, int r, int k) 
{
	int val = mxq(l, r);
	if (val) update(l, r, val);
}

void magic(int i, int x) 
{
	change(i - 1, x);
}

long long inspect(int l, int r) 
{
	return sq(l - 1, r);
}
