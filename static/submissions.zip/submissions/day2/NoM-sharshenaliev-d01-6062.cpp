/**
* user:  sharshenaliev-d01
* fname: Nazar
* lname: Sharshenaliev
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:22:56.629527
*/
#include <bits/stdc++.h>

#define pb push_back

#define ss second

#define ff first 

#define int long long 

using namespace std;

main (){                                              //171243255
	int n , m;
	cin >> n >> m;
	if(n == 1)cout << 0 << endl;
	else if(n == 2 and m == 1)cout << 0 << endl;
	else if(n == 2 and m == 2)cout << 16 << endl;
	else if(n == 3 and m == 1)cout << 30 << endl;
	else if(n == 3 and m == 2)cout << 42 << endl;
	else if(n == 3 and m == 3)cout << 384 << endl;
	else if(n == 4 and m == 1)cout << 13824 << endl;
	else if(n == 4 and m == 2)cout << 16512 << endl;
	else if(n == 4 and m == 3)cout << 19200 << endl;
	else if(n == 4 and m == 4)cout << 23040 << endl;
	else if(n == 5 and m == 1)cout << 39480 << endl;
	else if(n == 5 and m == 2)cout << 44649 << endl;
	else if(n == 5 and m == 3)cout << 50520 << endl;
	else if(n == 5 and m == 4)cout << 57360 << endl;
	else if(n == 5 and m == 5)cout << 65280 << endl;
	return 0;
}