/**
* user:  buntov-447
* fname: Atanas Todorov
* lname: Buntov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:40:01.125733
*/
#include "weirdtree.h"

int n,he[81000],i;
long long int pr[81000];

void initialise(int N, int Q, int h[]) {
    pr[0]=0;
    n=N;
	for(i=1;i<=N;i++){he[i]=h[i];pr[i]=pr[i-1]+he[i];}
}
void cut(int l, int r, int k) {
	for(int j=0;j<k;j++){
            	int maxx=-1,pos;
	for(i=l;i<=r;i++)
    {
        if(he[i] > maxx){maxx=he[i];pos=i;}
    }
    if(he[pos]>0)he[pos]--;
	}
	for(i=1;i<=n;i++){pr[i]=pr[i-1]+he[i];}
}
void magic(int i, int x) {
	he[i]=x;
}
long long int inspect(int l, int r) {
	return pr[r]-pr[l-1];
}
