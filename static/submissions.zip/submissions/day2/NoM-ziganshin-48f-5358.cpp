/**
* user:  ziganshin-48f
* fname: Emir Ramilevich
* lname: Ziganshin
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:23:50.046279
*/
#include <bits/stdc++.h>

using namespace std;

void solve();

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    solve();
}

#define int long long

const int N = 1001, MOD = 1e9 + 7;

int pw(int a, int n) {
    if (n == 0) return 1;
    if (n % 2 == 0) {
        int b = pw(a, n / 2);
        return b * b % MOD;
    } else {
        return pw(a, n - 1) * a % MOD;
    }
}

int n, m, cnt[N], fc[N], CC[2001][2001], dp1[N][N], e;

int C(int n, int k) {
    return fc[n] * pw(fc[n - k] * fc[k] % MOD, MOD - 2) % MOD;
}

int f(int a, int b) {
    return CC[a + b][a];
}

int sl() {
    dp1[0][0] = 1;
    int i, j, k, u, sum = 0;
    for (i = 0; i < m; i++) {
        for (j = 0; j <= n; j++) {
            if ((sum - j) % 2 == 1) continue;
            for (k = 0; k <= min(cnt[i + 1], j); k++) {
                u = cnt[i + 1] - k;
                dp1[i + 1][j - k + u] += ((dp1[i][j] * f(k, u) % MOD) * CC[j][k] % MOD) * fc[k] % MOD;
                dp1[i + 1][j - k + u] %= MOD;
            }
        }
        sum += cnt[i + 1];
    }
    int bin = 1;
    for (i = 1; i <= n; i++) {
        bin = bin * 2 % MOD;
    }
    return (fc[n] * bin % MOD) * dp1[m][0] % MOD;
}

void solve() {
    fc[0] = 1;
    for (int i = 1; i < N; i++) {
        fc[i] = fc[i - 1] * i % MOD;
    }
    for (int i = 0; i < 2001; i++) {
        for (int j = 0; j <= i; j++) {
            CC[i][j] = C(i, j);
        }
    }
    cin >> n >> m;
    e = n * 2;
    for (int i = 0; i < e; i++) {
        cnt[i % m + 1]++;
    }
    cout << sl() << endl;
}