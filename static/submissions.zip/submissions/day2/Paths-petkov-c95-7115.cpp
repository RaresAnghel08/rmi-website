/**
* user:  petkov-c95
* fname: Georgi Martinov
* lname: Petkov
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:38:14.926487
*/
#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

struct node
{
    int v, tg;
    node () {}
    node (int _v, int _tg)
    {
        v = _v;
        tg = _tg;
    }
};

bool operator < (node a, node b)
{
    return a.tg > b.tg;
}

const int MAXN = 100000+10;
int n, k;
vector <node> G[MAXN];

bool used[MAXN];
bool u[MAXN];
long long d[MAXN];
int par[MAXN];
int add[MAXN];
bool vertex[MAXN];

int calc(int v)
{
    int ret = 0;
    while (par[v] != -1)
    {
        if (!u[v])
        {
            u[v] = 1;
            ret += add[v];
        }
        v = par[v];
    }
    return ret;
}

int a[MAXN];
bool u2[MAXN];
int answer = 0;

void rec(int ind = 0)
{
    if (ind == k)
    {
        int sum = 0;

        memset(u, 0, sizeof(u));

        for (int i = 0; i < k; i++)
        {
//            cerr << a[i] << " ";
            sum += calc(a[i]);
        }
//        cerr << endl;


        answer = max(answer, sum);
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        if (vertex[i]) continue;
        if (u2[i]) continue;
        a[ind] = i;
        u2[i] = 1;
        rec(ind + 1);
        u2[i] = 0;
    }
}

void solve(int start)
{
    queue <node> pq;
    pq.push(node(start, 0));

    memset(par, -1, sizeof(par));
    memset(used, 0, sizeof(used));
    memset(add, 0, sizeof(used));
    memset(u, 0, sizeof(used));
    for (int i = 0; i <= n; i++)
        d[i] = 2e9;
    d[start] = 0;

    while (!pq.empty())
    {
        int v = pq.front().v;
        int tg = pq.front().tg;
        pq.pop();
        if (used[v]) continue;
        used[v] = 1;

        int sz = G[v].size();
        for (int i = 0; i < sz; i++)
        {
            int vi = G[v][i].v;
            int di = G[v][i].tg;

            if (d[v] + di < d[vi])
            {
                d[vi] = d[v] + di;
                par[vi] = v;
                add[vi] = di;
            }
            pq.push(node(vi, d[vi]));
        }
    }
    answer = 0;
    rec();
    cout << answer << endl;
}

int main()
{
    cin >> n >> k;
    for (int i = 1; i < n; i++)
    {
        int a, b, c;
        cin >> a >> b >> c;
        G[a].push_back(node(b, c));
        vertex[a] = true;
        G[b].push_back(node(a, c));
    }

    for (int i = 1; i <= n; i++)
    {
        solve(i);
    }

    return 0;
}
/**
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1

*/
