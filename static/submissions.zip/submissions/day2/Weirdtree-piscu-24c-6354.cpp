/**
* user:  piscu-24c
* fname: Stefan Constantin
* lname: Piscu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:46:42.953068
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

#define ll long long

struct nod{
	int pozmax, maxval;
	ll sum;	
};


int n, q;
vector<int> v;
#define mid ((l+r)/2)
struct segmentTree{
	int n;
	vector<nod> val;
	
	segmentTree(int _n=0): n(_n+1){
		val.resize(4*n+1);
	}

	void setVal(int poz, int value, int l, int r, int cr){
		if(l==r){
			val[cr].sum=value;
			val[cr].maxval=value;
			val[cr].pozmax=l;
			return;
		}
		if(poz<=mid) setVal(poz, value, l, mid, cr*2);
		else setVal(poz, value, mid+1, r, cr*2+1);
		val[cr].sum=val[cr*2].sum+val[cr*2+1].sum;
		if(val[2*cr].maxval>=val[2*cr+1].maxval) val[cr].maxval=val[2*cr].maxval, val[cr].pozmax=val[2*cr].pozmax;
		else val[cr].maxval=val[2*cr+1].maxval, val[cr].pozmax=val[2*cr+1].pozmax;
	}

	pair<int, int> getMax(int ql, int qr, int l, int r, int cr){
		if(ql==ql&&qr==r) return {val[cr].maxval, -val[cr].pozmax};
		if(qr<=mid) return getMax(ql, qr, l, mid, cr*2);
		if(mid<ql) return getMax(ql, qr, mid+1, r, cr*2+1);
		return max(getMax(ql, mid, l, mid, cr*2), getMax(mid+1, qr, mid+1, r, cr*2+1));
	}

	ll getSum(int ql, int qr, int l, int r, int cr){
		if(ql==ql&&qr==r) return val[cr].sum;
		if(qr<=mid) return getSum(ql, qr, l, mid, cr*2);
		if(mid<ql) return getSum(ql, qr, mid+1, r, cr*2+1);
		return getSum(ql, mid, l, mid, cr*2)+getSum(mid+1, qr, mid+1, r, cr*2+1);
	}

	void show(int l, int r, int cr){
		cout<<l<<" "<<r<<" "<<val[cr].sum<<" "<<val[cr].pozmax<<" "<<val[cr].maxval<<"\n";
		if(l==r) return;
		show(l, mid, cr*2);
		show(mid+1, r, cr*2+1);
	}

};
#undef mid

segmentTree aint;

void initialise(int N, int Q, int h[]) {
	n=N, q=Q;
	v.resize(n+1);
	aint=segmentTree(n+1);
	for(int i=1;i<=n;++i){
		v[i]=h[i];
		aint.setVal(i, v[i], 1, n, 1);
	}
	//aint.show(1, n, 1);
}

void cut(int l, int r, int k) {
	//cout<<"CUT "<<l<<" "<<r<<" "<<k<<endl;
	//int step=floor(k/n);
	while(k--){
		auto ret=aint.getMax(l, r, 1, n, 1);
		int poz=-ret.second;
		if(v[poz]==0) continue;
		v[poz]--;
		aint.setVal(poz, v[poz], 1, n, 1);
	}
	/*
	for(int i=1;i<=n;++i) cout<<v[i]<<" ";
	cout<<endl;
	aint.show(1, n, 1);
	*/
}

void magic(int i, int x) {
	//cout<<"MAGIC "<<i<<" "<<x<<endl;
	v[i]=x;
	aint.setVal(i, x, 1, n, 1);
	/*
	for(int i=1;i<=n;++i) cout<<v[i]<<" ";
	cout<<"\n";
	aint.show(1, n, 1);
	*/

}

long long int inspect(int l, int r) {
	//cout<<"SUM "<<l<<" "<<r<<endl;
	return aint.getSum(l, r, 1, n, 1);
}
