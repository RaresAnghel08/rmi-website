/**
* user:  kopchev-f98
* fname: Martin
* lname: Kopchev
* task:  Paths
* score: 8.0
* date:  2021-12-17 10:18:13.207569
*/
#include<bits/stdc++.h>
using namespace std;

const int nmax=2e5+42;

int n,k;

int to[nmax];
int cost[nmax];

int help_to[nmax],help_cost[nmax];

vector< pair<int,int> > adj[nmax];

long long MX[nmax];

bool blocked[nmax];

set< pair<long long,int> > active[nmax];

set< pair<long long,int> > not_blocked;
set< pair<long long,int> >::iterator pointer;
long long OUTP=0;

void print()
{
    for(auto w:not_blocked)cout<<w.first<<" "<<w.second<<"\t";
    cout<<"OUTP= "<<OUTP<<" pointer= "<<(*pointer).first<<" "<<(*pointer).second<<endl;
}

void my_push(long long a,long long b)
{
    pair<long long,long long> cur={a,b},help=*pointer;

    if(cur>help)
    {
        not_blocked.insert(cur);

        OUTP-=(*pointer).first;

        pointer++;

        OUTP+=a;
    }
    else not_blocked.insert(cur);

    /*
    cout<<"my push "<<a<<" "<<b<<endl;
    print();
    */
}

void my_pop(long long a,long long b)
{
    if(not_blocked.count({a,b})==0)return;

    pair<long long,long long> cur={a,b},help=*pointer;

    if(cur<help)not_blocked.insert(cur);
    else
    {
        OUTP-=a;
        pointer--;

        not_blocked.erase(cur);

        OUTP+=(*pointer).first;
    }

    /*
    cout<<"my pop "<<a<<" "<<b<<endl;
    print();
    */
}

long long outp[nmax];

void dfs(int node,int parent)
{
    //cout<<"dfs "<<node<<" "<<parent<<endl;

    MX[node]=0;

    int big=0;

    for(auto w:adj[node])
        if(w.first!=parent)
        {
            dfs(w.first,node);

            MX[w.first]+=w.second;

            active[node].insert({MX[w.first],w.first});

            if(MX[big]<MX[w.first])big=w.first;

            MX[node]=max(MX[node],MX[w.first]);
        }

    blocked[big]=1;
}

void prec()
{
    dfs(1,0);

    for(int i=1;i<=k+1;i++)
        not_blocked.insert({0,-i});
    pointer=not_blocked.begin();
    pointer++;

    for(int i=1;i<=n;i++)
        if(blocked[i]==0)
            my_push(MX[i],i);

    /*
    for(auto w:not_blocked)cout<<w.first<<" "<<w.second<<endl;
    cout<<(*pointer).first<<" "<<(*pointer).second<<endl;
    */

    outp[1]=OUTP;
}

int calc_big(int node)
{
    if(active[node].size()==0)return 0;

    set< pair<long long,int> >::iterator it=active[node].end();
    it--;

    return (*it).second;
}

void recalc(int node,long long cost)
{
    if(blocked[node]==0)
    {
        my_pop(MX[node],node);
    }

    if(active[node].size())
    {
        set< pair<long long,int> >::iterator it=active[node].end();
        it--;

        cost+=(*it).first;

        blocked[(*it).second]=1;
        my_pop((*it).first,(*it).second);
    }

    MX[node]=cost;
    my_push(MX[node],node);
}

void move_root(int old_root,int new_root,int EDGE_COST)
{
    int arr[2]={new_root,old_root};

    for(int i=0;i<2;i++)
    {
        int which_was_big=calc_big(arr[i]);

        if(which_was_big!=0)
        {
            assert(blocked[which_was_big]);

            blocked[which_was_big]=0;

            my_push(MX[which_was_big],which_was_big);
        }
    }

    for(int i=0;i<2;i++)
        my_pop(MX[arr[i]],arr[i]);

    active[old_root].erase({MX[new_root],new_root});

    recalc(old_root,EDGE_COST);

    active[new_root].insert({MX[old_root],old_root});

    recalc(new_root,0);
}

void solve_all(int node,int parent)
{
    /*
    cout<<"dfs "<<node<<" "<<parent<<endl;
    for(int i=1;i<=n;i++)cout<<MX[i]<<" "<<blocked[i]<<endl;
    */

    outp[node]=OUTP;

    for(auto w:adj[node])
        if(w.first!=parent)
        {
            move_root(node,w.first,w.second);

            solve_all(w.first,node);

            move_root(w.first,node,w.second);
        }
}

/*
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/
int main()
{
    scanf("%i%i",&n,&k);
    for(int i=1;i<n;i++)
    {
        int u,v,c;
        scanf("%i%i%i",&u,&v,&c);

        adj[u].push_back({v,c});
        adj[v].push_back({u,c});
    }

    prec();

    solve_all(1,0);

    for(int i=1;i<=n;i++)
        printf("%lld\n",outp[i]);

    return 0;
}
