/**
* user:  bartoli-386
* fname: Davide
* lname: Bartoli
* task:  Paths
* score: 48.0
* date:  2021-12-17 10:24:40.434428
*/
#pragma GCC optimize("O3")
#pragma target("avx2")
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define pb push_back
#define int ll
int N,K;
vector<pair<int,int> >v[100010];
vector<int> ans[100009];
int res[100009];
const int dim=100;
struct kk{
    vector<vector<int> >ans1;
    unordered_map<int,int> position;
    int pos;
    void init(int ff){
        pos=ff;
        int cur=0;
        for(auto [x,y]:v[pos]){
            int yyy=cur/dim;
            position[x]=yyy;
            if(yyy>=ans1.size())ans1.pb(vector<int> (K+2,0));

            for(int i=K;i>=0;i--){
                for(int j=i;j>0;j--){
                    ans1[yyy][i]=max(ans1[yyy][i],ans1[yyy][i-j]+ans[x][j]+y);
                }
            }
            cur++;
        }
    }
    vector<int> calcola(int prec){
        vector<int> res(K+2,0);
        /*for(int pp=0;pp<(int)v[pos].size();pp++){
                    auto [x,y]=v[pos][pp];
                    if(x==prec)continue;
                    for(int i=K;i>=0;i--){
                        for(int j=i;j>0;j--){
                            res[i]=max(res[i],res[i-j]+ans[x][j]+y);
                        }
                    }
                }
                return res;*/

        int k=position[prec];
        if(prec==0)k=ans1.size();

        for(int w=0;w<ans1.size();w++){
            if(w!=k){
                for(int i=K;i>=0;i--){
                    for(int j=i;j>0;j--){
                        res[i]=max(res[i],res[i-j]+ans1[w][j]);
                    }
                }
            }else{
                for(int pp=w*dim;pp<min(w*dim+dim,(int)v[pos].size());pp++){
                    auto [x,y]=v[pos][pp];
                    if(x==prec)continue;
                    for(int i=K;i>=0;i--){
                        for(int j=i;j>0;j--){
                            res[i]=max(res[i],res[i-j]+ans[x][j]+y);
                        }
                    }
                }
            }
        }
        return res;
    }
};
vector<kk> qq(100010);
void riempi(int pos){
    if(v[pos].size()<dim)return;
    qq[pos].init(pos);
}

void ricalcola(int pos,int prec,bool prova=1){
    if(v[pos].size()<dim || prova==0){
        fill(ans[pos].begin(),ans[pos].end(),0);
        for(auto [x,y]:v[pos]){
            if(x==prec)continue;
            for(int i=K;i>=0;i--){
                for(int j=i;j>0;j--){
                    ans[pos][i]=max(ans[pos][i],ans[pos][i-j]+ans[x][j]+y);
                }
            }
        }
    }else{
        ans[pos]=qq[pos].calcola(prec);
    }


    /*ans[pos][1]=0;
    for(auto [x,y]:v[pos]){
        if(x==prec)continue;
        ans[pos][1]=max(ans[pos][1],ans[x][1]+y);
    }*/

}

void calc(int pos,int prec){
    for(auto [x,y]:v[pos]){
        if(x==prec)continue;
        calc(x,pos);
    }
    ricalcola(pos,prec,0);
}


vector<int> x,y;
void calc1(int pos,int prec){
    x=ans[prec];
    //y=ans[pos];
    ricalcola(prec,pos);
    riempi(pos);
    ricalcola(pos,0);

    res[pos]=ans[pos][K];

    for(auto [x,y]:v[pos]){
        if(x==prec)continue;
        calc1(x,pos);
    }
    //ans[pos]=y;
    ricalcola(pos,prec);
    ans[prec]=x;
    //ricalcola(prec,0);
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin>>N>>K;
    for(int i=0;i<=N;i++)ans[i].resize(K+2);
    for(int i=0;i<N-1;i++){
        int a,b,c;
        cin>>a>>b>>c;
        v[a].pb({b,c});
        v[b].pb({a,c});
    }
    calc(1,0);
    calc1(1,0);
    for(int i=1;i<=N;i++){
        cout<<res[i]<<'\n';
    }
    //calc(1,0);
    //for(int i=1;i<=N;i++){
    //    cout<<calc(i,K);
    //}
}

