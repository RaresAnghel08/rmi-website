/**
* user:  kadyrov-b60
* fname: Edil
* lname: Kadyrov
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 07:50:41.254390
*/
#include <bits/stdc++.h>
using namespace std;
vector <int> t;
int n, q;
void initialise (int N , int Q , int h [])
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    n = N, q = Q;
    t.resize(n+1);
    for(int i = 1; i <= n; i++)
        t[i] = h[i];
}
void cut ( int l , int r , int k )
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    for(int i = 0; i < k; i++)
    {
        set <int> s{t.begin() + l, t.begin() + r + 1};
        int it = *(--s.end());
        for(int j = l; j <= r; j++)
            if(t[j] == it && t[j] != 0)
            {
                t[j] -= 1;
                break;
            }
    }
}
void magic (int i , int x )
{
    t[i] = x;
}
long long inspect ( int l , int r )
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    long long hsm = 0;
    for(int i = l; i <= r; i++)
            hsm += t[i];
    return hsm;
}
