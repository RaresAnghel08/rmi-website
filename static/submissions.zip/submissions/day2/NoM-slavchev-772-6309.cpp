/**
* user:  slavchev-772
* fname: Yuliyan Radoslavov
* lname: Slavchev
* task:  NoM
* score: 9.0
* date:  2021-12-17 10:43:59.173673
*/
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
#define endl '\n'
#define int long long
#define MAXN 2005
int br, m;
vector<int> v;
int lastpos[MAXN];
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    cin >> br >> m;
    for(int i = 0; i < 2 * br; ++i){
        v.push_back(i);
    }
    int cnt = 0;
    do{
        for(int i = 0; i <= br; ++i) lastpos[i] = -1;
        bool flag = true;
        for(int i = 0; i < v.size(); ++i){
            int val = v[i] / 2;
            //cout << i << ' ' << val << ' ' << lastpos[val] << endl;
            if(lastpos[val] == -1) lastpos[val] = i;
            else{
                int dif = i - lastpos[val];
                if(dif % m == 0){
                    flag = false; break;
                }
            }
        }
        if(flag) ++cnt;
    }
    while(next_permutation(v.begin(), v.end()));
    cout << cnt << endl;
    return 0;
}
