/**
* user:  alexandru andrei-c8e
* fname: Benescu
* lname: Alexandru Andrei
* task:  Paths
* score: 19.0
* date:  2021-12-17 10:21:07.400327
*/
#include <bits/stdc++.h>
#define L 203
using namespace std;
int v_data_1[L], v_data_2[L], v_data_cost[L], v_tree[L], v_cost[L], v_cost_copy[L];
int main(){
  int n, k, i, j, root, edges, q, best_j;
  long long s_ans, s, mx;
  cin >> n >> k;
  edges = n - 1;
  for (i = 0; i < edges; i++)
    cin >> v_data_1[i] >> v_data_2[i] >> v_data_cost[i];
  for (root = 1; root <= n; root++){
    for (i = 0; i < n + 1; i++)
      v_tree[i] = v_cost[i] = 0;
    v_tree[root] = -1;
    for (i = 0; i < edges; i++){
      j = 0;
      while ((v_tree[v_data_1[j]] == 0 && v_tree[v_data_2[j]] == 0) || (v_tree[v_data_1[j]] != 0 && v_tree[v_data_2[j]] != 0))
        j++;
      if (v_tree[v_data_1[j]] == 0){
        v_tree[v_data_1[j]] = v_data_2[j];
        v_cost[v_data_1[j]] = v_data_cost[j];
      }
      else{
        v_tree[v_data_2[j]] = v_data_1[j];
        v_cost[v_data_2[j]] = v_data_cost[j];
      }
    }
    /**
    cout << "ROOT = " << root << "\n";
    for (i = 0; i < n + 1; i++)
      cout << v_tree[i] << " ";
    cout << "\n";
    for (i = 0; i < n + 1; i++)
      cout << v_cost[i] << " ";
    cout << "\n";
    cout << "\n";
    **/
    s_ans = 0;
    for (i = 0; i < k; i++){
      mx = best_j = -1;
      for (j = 1; j <= n; j++){
        for (q = 0; q <= n; q++)
          v_cost_copy[q] = v_cost[q];
        s = 0;
        q = j;
        while (v_tree[q] != -1){
          s = s + v_cost_copy[q];
          v_cost_copy[q] = 0;
          q = v_tree[q];
        }
        if (mx < s){
          mx = s;
          best_j = j;
        }
      }
      q = best_j;
      while (v_tree[q] != -1){
        v_cost[q] = 0;
        q = v_tree[q];
      }
      s_ans = s_ans + mx;
    }
    cout << s_ans << "\n";
  }
  return 0;
}
