/**
* user:  stoyanov-925
* fname: Stefan Ivaylov
* lname: Stoyanov
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:25:13.561956
*/
#include<iostream>
#include<cstdio>
#include<map>
using namespace std;
const int maxn=16,mod=1e9+7;
struct stone
{
    int val;
    bool colour;
    stone(){val=colour=false;}
    stone(int _val,bool _colour)
    {
        val=_val;
        colour=_colour;
    }
    bool operator<(const stone &e)const
    {
        if(val==e.val)return (colour<e.colour);
        return val<e.val;
    }
};
int n,m,ans_cnt=0;
stone a[maxn];
map<stone,int>pos;
void check()
{
    int dist;
    for(int i=1;i<=n;i++)
    {
        dist=abs(pos[stone(i,true)]-pos[stone(i,false)]);
        if(dist%m==0)
            return;
    }
    ans_cnt=(ans_cnt+1)%mod;
}
void recursion(int len)
{
    if(len==2*n+1)
    {
        check();
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(pos[stone(i,false)]==0)
        {
            pos[stone(i,false)]=len;
            recursion(len+1);
            pos[stone(i,false)]=0;
        }
        if(pos[stone(i,true)]==0)
        {
            pos[stone(i,true)]=len;
            recursion(len+1);
            pos[stone(i,true)]=0;
        }
    }
}
int main()
{
	/*ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);*/
	scanf("%d%d",&n,&m);
	recursion(1);
	printf("%d\n",ans_cnt);
return 0;
}
