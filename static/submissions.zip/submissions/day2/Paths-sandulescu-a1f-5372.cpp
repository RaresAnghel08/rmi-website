/**
* user:  sandulescu-a1f
* fname: Alexandru Nicolae
* lname: Săndulescu
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:25:12.049004
*/
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int N, K;
vector<pair<int, int>> A[100003];
long long cost[100003];

long long parc(int node, int from = -1)
{
    cost[node] = 0;
    for(auto it : A[node])
    {
        if(it.first != from)
            cost[node] += it.second + parc(it.first, node);
    }
    return cost[node];
}

int main()
{
    cin >> N >> K;
    for(int i = 1; i < N; i++)
    {
        int x, y, c;
        cin >> x >> y >> c;
        A[x].push_back({y, c});
        A[y].push_back({x, c});
    }
    /// brutus maximus
    for(int i = 1; i <= N; i++)
    {
        parc(i);
        sort(cost + 1, cost + N + 1);
        long long sum = 0;
        for(int j = N; j >= N - K + 1; j--)
            sum += cost[j];
        cout << sum << "\n";
    }
    return 0;
}
