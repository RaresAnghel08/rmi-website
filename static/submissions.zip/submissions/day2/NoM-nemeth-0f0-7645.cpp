/**
* user:  nemeth-0f0
* fname: Márton
* lname: Németh
* task:  NoM
* score: 9.0
* date:  2021-12-17 11:59:59.876153
*/
#include <bits/stdc++.h>

using namespace std;
typedef long long int ll;

const ll k=1e9+7;

ll po[10002];
ll fact[10002];
ll n,m;

vector<ll> db;

ll quick_pow(ll x,ll b) {
    ll b2=b;
    ll ans=1;
    ll z=x;
    while (b2>0) {
        if (b2%2==1) {
            ans=(ans*z)%k;
        }
        z=(z*z)%k;
        b2=b2/2;
    }
    return(ans);
}


ll inverz(ll x) {
    return(quick_pow(x,k-2));
}

ll binom(ll a,ll b) {

    return((((fact[a]*inverz(fact[b]))%k)*(inverz(fact[a-b])%k))%k);
}

ll rek(ll i,ll x,ll y) {
    //cout << i << " " << x << " " << y << endl;
    if (i==m) {
        if ((x==0)&&(y==0)) {
            return(1);
        } else {
            return(0);
        }
    }
    ll t=0;
    for (int j=0;j<=min(y,db[i]);j++) {
        if (x>=db[i]-j) {
            //cout << j << " " << binom(x,db[i]-j) << " " << binom(y,j) << endl;
            t=(t+(((((rek(i+1,x+2*j-db[i],y-j)*fact[db[i]])%k)*(binom(x,db[i]-j)))%k)*(binom(y,j)))%k)%k;
        }
    }
    //cout << i << " " << x << " " << y << " " << t[i][x][y] << endl;
    return(t);
}

int main()
{
    fact[0]=1;

    for (int i=1;i<=10000;i++) {
        fact[i]=(fact[i-1]*i)%k;
    }
    po[0]=1;
    for (int i=1;i<=10000;i++) {
        po[i]=(po[i-1]*2)%k;
    }

    cin >> n >> m;
    db.resize(m);
    for (int i=0;i<m;i++) {
        db[i]=(2*n-i-1)/m+1;
    }
    cout << (rek(0,0,n)*po[n])%k << endl;
    return 0;
}
