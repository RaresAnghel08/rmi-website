/**
* user:  yankova-448
* fname: Denitsa Marinova
* lname: Yankova
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:28:44.638377
*/
#pragma GCC optimize ("Ofast")
#include<bits/stdc++.h>
#define endl "\n"
using namespace std;

int const MAXN=1010;
int n, k;
long long maxn, used[MAXN], pos, lev[MAXN];
bool m[MAXN][MAXN];

struct Edge
{
    int edge;
    long long val;
};

vector<Edge> v[MAXN];

void BFS(int i)
{
    used[i]=1;
    queue<int> q;
    q.push(i);
    while(!q.empty())
    {
        int w=q.front();
        q.pop();
        int sz=v[w].size();
        for(int j=0;j<sz;j++)
        {
            if(!used[v[w][j].edge])
            {
                if(m[w][v[w][j].edge]==false) used[v[w][j].edge]=used[w]+v[w][j].val;
                else used[v[w][j].edge]=used[w];
                if(used[v[w][j].edge]>maxn)
                {
                    maxn=used[v[w][j].edge];
                    pos=v[w][j].edge;
                }
                q.push(v[w][j].edge);
            }
        }
    }
}

void BFS1(int i)
{
    lev[i]=1;
    queue<int> q;
    q.push(i);
    while(!q.empty())
    {
        int w=q.front();
        q.pop();
        int sz=v[w].size();
        for(int j=0;j<sz;j++)
        {
            if(!lev[v[w][j].edge])
            {
                lev[v[w][j].edge]=lev[w]+1;
                q.push(v[w][j].edge);
            }
        }
    }
}

void read()
{
    int x, y;
    long long s;
    cin>>n>>k;
    for(int i=1;i<n;i++)
    {
        cin>>x>>y>>s;
        v[x].push_back({y,s});
        v[y].push_back({x,s});
    }
    long long ans=0;
    for(int i=1;i<=n;i++)
    {
        memset(m,false,sizeof(m));
        memset(lev,0,sizeof(lev));
        int ways=k;
        ans=0;
        BFS1(i);
        while(ways>0)
        {
            memset(used,0,sizeof(used));
            maxn=0;
            BFS(i);
            if(maxn==1) break;
            int now=pos;
            ans+=(maxn-1);
            while(now!=i)
            {
                int sz=v[now].size();
                for(int j=0;j<sz;j++)
                {
                    if(lev[v[now][j].edge]<lev[now])
                    {
                        m[v[now][j].edge][now]=true;
                        m[now][v[now][j].edge]=true;
                        now=v[now][j].edge;
                        break;
                    }
                }
            }
            ways--;
        }
        cout<<ans<<endl;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
	read();
	return 0;
}
