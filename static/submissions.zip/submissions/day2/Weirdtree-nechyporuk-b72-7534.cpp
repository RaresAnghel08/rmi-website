/**
* user:  nechyporuk-b72
* fname: Vladyslav
* lname: Nechyporuk
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:58:17.772965
*/
#pragma GCC optimize("Ofast")
//#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")



#include <bits/stdc++.h>

//#include "weirdtree.h"
using namespace std;
//#define ll long long

vector<int> mas;

void initialise(int N, int Q, int h[]) {
	mas.resize(N+3);
	for(int i=1;i<=N;i++)mas[i]=h[i];
}
void cut(int l, int r, int k) {
	int ll=-1,rr=1e9+1;
	while(rr-ll>1)
    {
        int mid=(rr+ll)/2;
        long long c=0;
        for(int i=l;i<=r;i++)
        {
            c+=max(0,mas[i]-mid);
            //cout<<i<<' '<<mid<<' '<<mas[i]-mid<<'\n';
        }
        //cout<<"C "<<c<<' '<<ll<<' '<<rr<<'\n';
        if(c<=k)rr=mid;
        else ll=mid;
    }
    int c=0;
    for(int i=l;i<=r;i++)
    {
        c+=max(0,mas[i]-rr);
        mas[i]=min(mas[i],rr);
    }
    //cout<<"RR "<<rr<<'\n';
    k-=c;
    for(int i=l;i<=r;i++)
    {
        if(k==0)break;
        if(mas[i]==rr && mas[i]!=0)
        {
            mas[i]--;
            k--;
        }
    }
}
void magic(int i, int x) {
	mas[i]=x;
}
long long int inspect(int l, int r) {
	long long sum=0;
	for(int i=l;i<=r;i++)
	{
	    //cout<<mas[i]<<' ';
	    sum+=mas[i];
	}
	//cout<<'\n';
	return sum;
}

/*
int main() {
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}

*/
