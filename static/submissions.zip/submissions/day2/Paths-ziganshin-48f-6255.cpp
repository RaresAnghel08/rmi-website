/**
* user:  ziganshin-48f
* fname: Emir Ramilevich
* lname: Ziganshin
* task:  Paths
* score: 12.0
* date:  2021-12-17 10:39:08.869243
*/
#include <bits/stdc++.h>

using namespace std;

void solve();

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    solve();
}

#define int long long

const int N = 1e5 + 100, MOD = 1e9 + 7;

int n, k, pa[N], d[N], mx[N], ans[N];
vector<pair<int, int>> a[N];

void dfs(int v, int p) {
    pa[v] = p;
    mx[v] = v;
    for (auto to : a[v]) {
        if (to.first == p) continue;
        d[to.first] = d[v] + to.second;
        dfs(to.first, v);
        if (d[mx[to.first]] > d[mx[v]]) {
            mx[v] = mx[to.first];
        }
    }
}

void dfs1(int v, int p, int c) {
    ans[v] = max(c, d[mx[v]] - d[v]);
    int pos = -1, e = 0;
    for (auto to : a[v]) {
        if (to.first == p) continue;
        if (e < d[mx[to.first]] + to.second) {
            e = d[mx[to.first]] + to.second;
            pos = to.first;
        }
    }
    int u = 0;
    for (auto to : a[v]) {
        if (to.first == p || to.first == pos) continue;
        u = max(u, d[mx[to.first]] - d[to.first] + to.second);
    }
    for (auto to : a[v]) {
        if (to.first == p) continue;
        if (to.first == pos) {
            dfs1(to.first, v, max(c, u) + to.second);
        } else {
            dfs1(to.first, v, max(c, d[mx[v]] - d[v]) + to.second);
        }
    }
}

vector<pair<int, int>> sl(int v, int p) {
    int pos = mx[v];
    int prev = pos;
    vector<pair<int, int>> res;
    if (v == p) {
        res.push_back({d[pos] - d[v], v});
    } else {
        res.push_back({d[pos] - d[pa[v]], v});
    }
    while (true) {
        for (auto to : a[pos]) {
            if (to.first == pa[pos] || to.first == prev) continue;
            for (pair<int, int> x : sl(to.first, v)) {
                res.push_back(x);
            }
        }
        if (pos == v) break;
        prev = pos;
        pos = pa[pos];
    }
    return res;
}

void solve() {
    cin >> n >> k;
    for (int i = 0; i < n - 1; i++) {
        int f, s, c;
        cin >> f >> s >> c;
        f--, s--;
        a[f].emplace_back(s, c);
        a[s].emplace_back(f, c);
    }
    dfs(0, 0);
    dfs1(0, 0, 0);
    for (int i = 0; i < n; i++) {
        cout << ans[i] << '\n';
    }
}