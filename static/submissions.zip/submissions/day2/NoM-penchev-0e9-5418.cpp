/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:28:30.600479
*/
#include <algorithm>
#include <iostream>
#include <string>
#define endl '\n'
using namespace std;

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n, m;
    cin >> n >> m;

    string s = "";
    for (int i = 0; i < 2 * n; ++ i)
    {
        s += char(i + '0');
    }

    int cnt = 0;
    do
    {
        bool flag = true;
        for (int i = 0; i < 2 * n; ++ i)
        {
            for (int j = i + 1; j < 2 * n; ++ j)
            {
                int a = (s[i] - '0') % n;
                int b = (s[j] - '0') % n;
                if (a == b and (j - i) % m == 0) flag = false;
            }
        }
        if (flag) cnt++;
    } while (next_permutation(s.begin(), s.end()));

    cout << cnt << endl;

    return 0;
}

/*
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/
