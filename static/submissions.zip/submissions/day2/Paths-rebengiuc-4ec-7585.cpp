/**
* user:  rebengiuc-4ec
* fname: Mircea Maxim
* lname: Rebengiuc
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:59:04.308093
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define MAXN 2048//100000
#define MAXM 4096//200000
#define MAXK MAXN
#define NIL  -1

#ifndef EVAL
#define DBEUG(var) fprintf(stderr, "(!) DBEUG: "#var" = %d\n", var)
#else
#define DBEUG(var)
#endif

int list[MAXN];
int parrent[MAXN];// node -> parrent edge
int adj[MAXM];
int inv[MAXM];
//int from[MAXM];
//int to[MAXM]; // to[i] = from[inv[i]]
int costorig[MAXM];
int next[MAXM];
int ne = 0;

long long path[MAXN];
int cost[MAXM];

int topo[MAXN];
int topostart[MAXN];
int topoend[MAXN];
int sp;

int n;

// lazy aint over toppologicaly sorted nodes:
//   (1) range update
//   (2) range maximum
//   (3) binary search

struct AINT {
	int left, right;
	int intr, intl;
	int max;
	int islazy, delta;// for lazy update
} aint[MAXN * 2];
int aintroot, aintn;

static inline int max( int a, int b ){
	return a > b ? a : b;
}

static inline void AINTpropdown( int root ){// lazy propagation
	int left = aint[root].left, right = aint[root].right;

	if( !aint[root].islazy )
		return;

  // update left
  aint[left].islazy = 1;
  aint[left].delta += aint[root].delta;
  aint[left].max   += aint[root].delta;

  // update right
  aint[right].islazy = 1;
  aint[right].delta += aint[root].delta;
  aint[right].max   += aint[root].delta;

  aint[root].islazy = aint[root].delta = 0;
}

void AINTjoin( int root ){
	int left = aint[root].left, right = aint[root].right;

	aint[root].intl = aint[left ].intl;
	aint[root].intr = aint[right].intr;
	aint[root].islazy = aint[root].delta = 0;
	aint[root].max = max(aint[left].max, aint[right].max);
}

void AINTupdate( int root, int l, int r, int delta ){
	if( aint[root].intl > r || aint[root].intr < l )
		return;

  if( l <= aint[root].intl && aint[root].intr <= r ){
  	// lazy update
  	aint[root].islazy = 1;
  	aint[root].delta += delta;
  	aint[root].max += delta;
  	return;
  }

  AINTpropdown( root );

  AINTupdate(aint[root].left,  l, r, delta);
  AINTupdate(aint[root].right, l, r, delta);

  AINTjoin( root );
}

void AINTprint( int root ){
	int left = aint[root].left, right = aint[root].right;

	if( left == -1 ){
		printf("@%d | %d\n", aint[root].intl, aint[root].max);
		return;
	}

  AINTpropdown( root );

  AINTprint( left );
  AINTprint( right );
}

void AINTbuild(){
	int i, j;

	aintn = 1;
	while( n > aintn )
		aintn <<= 1;

	for( i = 0 ; i < n ; i++ ){
		aint[i].intl = aint[i].intr = i;
		aint[i].max = path[topo[i]];
		aint[i].islazy = aint[i].delta = 0;
		aint[i].left = aint[i].right = -1;
	}
	for( ; i < aintn ; i++ ){
		aint[i].intl = aint[i].intr = i;
		aint[i].max = 0;
		aint[i].islazy = aint[i].delta = 0;
		aint[i].left = aint[i].right = -1;
	}

  i--;
  j = 0;
  do{
  	i++;
  	aint[i].left  = j++;
  	aint[i].right = j++;
		AINTjoin(i);
  }while( aint[i].intl != 0 || aint[i].intr != aintn - 1 );

	aintroot = i;
}

int AINTfind( int root, int val ){
	int left = aint[root].left, right = aint[root].right;

	if( aint[root].intl == aint[root].intr )
		return aint[root].intl;

	if( val == aint[left].max )
		return AINTfind(left,  val);
	else
		return AINTfind(right, val);
}

static inline int fgetint(){
	int n = 0, ch;

	while( !isdigit(ch = fgetc(stdin)) );
	do
	  n = n * 10 + ch - '0';
	while( isdigit(ch = fgetc(stdin)) );

	return n;
}

void getParrents( int root, int e ){
	int i;

	parrent[root] = e;

	for( i = list[root] ; i != NIL ; i = next[i] )
		if( i != e )
			getParrents(adj[i], inv[i]);
}

void toposort( int root ){
	int i;

	topostart[root] = sp;
	topo[sp++] = root;

	for( i = list[root] ; i != NIL ; i = next[i] )
		if( i != parrent[root] )
			toposort(adj[i]);

	topoend[root] = sp;
}

void getPaths( int root, long long dist ){
	int i;

	path[root] = dist;

	for( i = list[root] ; i != NIL ; i = next[i] )
		if( i != parrent[root] )
			getPaths(adj[i], dist + cost[i]);
}

long long maxSum( int root, int k ){
	int i, leaf, j;
	long long retval = 0;

	for( i = 0 ; i < ne ; i++ )
  	cost[i] = costorig[i];

  getParrents( root, NIL );
  sp = 0;
  toposort( root );

  path[root] = 0;
	leaf = root;
	for( i = 1 ; i < n ; i++ ){
		j = topo[i];
		path[j] = path[adj[parrent[j]]] + cost[parrent[j]];
		leaf = path[j] > path[leaf] ? j : leaf;
	}

	AINTbuild();

	for( ; k-- ; ){
		#ifndef EVAL
		AINTprint(aintroot);
		#endif
		retval += aint[aintroot].max; // update answer
		i = AINTfind(aintroot, aint[aintroot].max); // find maximum index
		leaf = topo[i];
		DBEUG(i);
		DBEUG(leaf);
		DBEUG(retval);

		while( parrent[leaf] != NIL ){
			DBEUG(leaf);
			DBEUG(-cost[parrent[leaf]]);
  		DBEUG(topostart[leaf]);
			DBEUG(topoend[leaf]);
    	AINTupdate(aintroot, topostart[leaf], topoend[leaf] , -cost[parrent[leaf]]);
	    cost[parrent[leaf]] = cost[inv[parrent[leaf]]] = 0;
	  	leaf = adj[parrent[leaf]];
	  }
	}

	return retval;
}

int main(){
	int k, i, a, b, c;

	n = fgetint();
	k = fgetint();

	for( i = 0 ; i < n ; i++ )
		list[i] = NIL;

  ne = 0;
	for( i = 1 ; i < n ; i++ ){
		a = fgetint() - 1;
		b = fgetint() - 1;
		c = fgetint();

		adj[ne] = b;
		costorig[ne] = c;
		inv[ne] = ne + 1;
		next[ne] = list[a];
		list[a] = ne++;

		adj[ne] = a;
		costorig[ne] = c;
		inv[ne] = ne - 1;
		next[ne] = list[b];
		list[b] = ne++;
	}

	/*for( i = 0 ; i < n ; i++ ){
		printf("%d:", i);
		for( int j = list[i] ; j != NIL ; j = next[j] ){
			printf(" %d", adj[j]);
		}
		printf("\n");
	}*/

	for( i = 0 ; i < n ; i++ )
		printf("%lld\n", maxSum(i, k));

	return 0;
}