/**
* user:  nadareishvili-7bf
* fname: Giorgi
* lname: Nadareishvili
* task:  NoM
* score: 9.0
* date:  2021-12-17 11:15:10.427013
*/
#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int mod = 1e9 + 7;

ll P(ll a, ll b) {
    if(!b) return 1;
    if(b & 1) return a * P(a, b - 1) % mod;
    ll c = P(a, b >> 1);
    return c * c % mod;
}
ll D(ll a, ll b) {
    return a * P(b, mod - 2) % mod;
}
vector<ll> _F(1, 1);
ll F(ll a) {
    while(_F.size() <= a) {
        _F.push_back(_F.back() * _F.size() % mod);
    }
    return _F[a];
}
ll C(ll a, ll b) {
    if(b > a) return 0;
    return D(F(a), F(a - b) * F(b) % mod);
}

const int N = 2003;
ll n, m, dp[N][N], c[N][N], z[N];

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    // for(;;) {
    cin >> n >> m;
    // if(n > 5 || m > 5) return 0;
    // cout << 0 << endl; return 0;
    // for(int i = 0; i <= m; ++i) {
    //     for(int j = 0; j <= n; ++j) {
    //         dp[i][j] = 0;
    //     }
    // }
    for(int i = 0; i <= n; ++i) {
        for(int j = 0; j <= n; ++j) {
            c[i][j] = C(i, j);
        }
    }
    // return 0;
    for(int i = 1; i <= m; ++i) {
        z[i] = n * 2 / m + (2 * n % m >= i);
        // cout << z[i] << endl;
    }
    dp[0][0] = 1;
    int sz = 0;
    for(int i = 0; i < m; ++i) {
        for(int x = 0; x <= n; ++x) {
            for(int k = 0; k <= x; ++k) {
                int y = 2 * n - sz - x >> 1;
                int t = z[i + 1] - k;
                if(t > y) continue;
                int xs = x + t - k;
                if(xs < 0) continue;
                (dp[i + 1][xs] += c[x][k] * c[y][t] % mod * dp[i][x]) %= mod;
            }
        }
        sz += z[i + 1];
    }
    ll pz = 1;
    for(int i = 1; i <= m; ++i) {
        (pz *= F(z[i])) %= mod;
    }
    ll fp = dp[m][0] * pz % mod * P(2, n) % mod;
    // cout << dp[m][0] << endl;
    cout << fp << endl;
    // }
    return 0;
}
