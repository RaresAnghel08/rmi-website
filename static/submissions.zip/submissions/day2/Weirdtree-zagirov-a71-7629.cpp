/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:59:46.297484
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

typedef long long ll;

//weirdtree

//grader

#define pb push_back
#define pii pair<ll, ll>
#define f first
#define s second

using namespace std;

vector<int> vec;

void initialise(int N, int Q, int h[]) {
    for (int i = 1; i <= N; i++) {
        vec.pb(h[i]);
    }
}

bool comp(int a, int b) {
    if (vec[a] == vec[b])
        return a < b;
    return vec[a] > vec[b];
}

void cut(int l, int r, int k) {
    vector<int> now;
    for (int i = l - 1; i < r; i++){
        now.pb(i);
    }
    sort(now.begin(), now.end(), comp);
//    for (auto u : now)
//        cout << u << ' ';
//    cout << endl;
    int it = 0;
    for (int i = 0; i < now.size() - 1; i++) {
        int d = vec[now[i]] - vec[now[i + 1]];
        if (k >= d * (i + 1)) {
            k -= d * (i + 1);
            it++;
        } else {
            break;
        }
    }
    cout << endl;
    for (int i = 0; i < it; i++) {
        vec[now[i]] = vec[now[it]];
    }
    it++;
    for (int i = 0; i < it; i++) {
        vec[now[i]] -= it / k;
    }
    k -= it / k * k;
    for (int i = 0; i < it && k--; i++){
        vec[now[i]]--;
    }
}

void magic(int i, int x) {
    vec[i - 1] = x;
}

long long int inspect(int l, int r) {
    ll sum = 0;
    for (int i = l - 1; i < r; i++) {
        sum += vec[i];
    }
    return sum;
}
