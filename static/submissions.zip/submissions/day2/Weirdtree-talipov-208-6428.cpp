/**
* user:  talipov-208
* fname: Islam Iliasovich
* lname: Talipov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:52:08.804236
*/
#include "weirdtree.h"


using namespace std;


const int MAXN = 80001;

int t_mx[MAXN * 4];
int t_sum[MAXN * 4];
int a[MAXN * 4];

int mx_merge(int lhs, int rhs) {
    if (lhs == -1) return rhs;
    if (rhs == -1) return lhs;
    if (a[lhs] >= a[rhs]) return lhs;
    else return rhs;
}

void build(int v = 1, int tl = 0, int tr = MAXN) {
    if (tr - tl == 1) {
        t_mx[v] = tl;
        t_sum[v] = a[tl];
        return;
    }
    int m = (tl + tr) / 2;
    build(v * 2, tl, m);
    build(v * 2 + 1, m, tr);
    t_sum[v] = t_sum[v * 2] + t_sum[v * 2 + 1];
    t_mx[v] = mx_merge(t_mx[v * 2], t_mx[v * 2 + 1]);
}


int get_sum(int l, int r, int v = 1, int tl = 0, int tr = MAXN) {
    if (tr <= l || r <= tl) return 0;
    if (l <= tl && tr <= r) return t_sum[v];
    int m = (tl + tr) / 2;
    return get_sum(l, r, v * 2, tl, m) + get_sum(l, r, v * 2 + 1, m, tr);
}


int get_mx(int l, int r, int v = 1, int tl = 0, int tr = MAXN) {
    if (tr <= l || r <= tl) return -1;
    if (l <= tl && tr <= r) return t_mx[v];
    int m = (tl + tr) / 2;
    return mx_merge(get_mx(l, r, v * 2, tl, m), get_mx(l, r, v * 2 + 1, m, tr));
}

void update(int i, int d, int v = 1, int tl = 0, int tr = MAXN) {
    if (tr - tl == 1) {
        a[i] = d;
        t_mx[v] = i;
        t_sum[v] = a[i];
        return;
    }
    int m = (tl + tr) / 2;
    if (i < m) {
        update(i, d, v * 2, tl, m);
    } else {
        update(i, d, v * 2 + 1, m, tr);
    }
    t_sum[v] = t_sum[v * 2] + t_sum[v * 2 + 1];
    t_mx[v] = mx_merge(t_mx[v * 2], t_mx[v * 2 + 1]);
}


void initialise(int N, int Q, int h[]) {
    for (int i = 0; i < N; ++i) {
        a[i] = h[i + 1];
    }
    build();
}


void cut(int l, int r, int k) {
    --l;
    while (k-- > 0) {
        int mx = get_mx(l, r);
        if (a[mx] != 0)
            update(mx, a[mx] - 1);
    }
}

void magic(int i, int x) {
    --i;
    update(i, x);
}

long long int inspect(int l, int r) {
    --l;
    return get_sum(l, r);
}
