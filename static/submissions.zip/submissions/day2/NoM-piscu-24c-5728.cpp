/**
* user:  piscu-24c
* fname: Stefan Constantin
* lname: Piscu
* task:  NoM
* score: 9.0
* date:  2021-12-17 09:55:32.572651
*/
#include <bits/stdc++.h>
using namespace std;

int n, m;

int check(vector<int> v){
	for(int i=0;i<2*n;++i){
		for(int j=i+m;j<2*n;j+=m){
			if(v[i]%n==v[j]%n) return 0;
		}
	}
	return 1;
}

int main(){
	cin>>n>>m;
	vector<int> v;
	for(int i=0;i<2*n;++i) v.push_back(i);
	int nr=0;
	do{
		if(check(v)) nr++;
	}while(next_permutation(v.begin(), v.end()));
	cout<<nr<<"\n";
	return 0;
}
