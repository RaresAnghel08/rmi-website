/**
* user:  nizamutdinov-1d5
* fname: Azat
* lname: Nizamutdinov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:43:04.912602
*/
#include <algorithm>
#include <bitset>
#include <deque>
#include <iomanip>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <array>
#include <random>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <chrono>
#include <ctime>
#include <random>
#define ll long long
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
template <typename KEY> using ve = std::vector<KEY>;

using namespace std;

const ll INF = INT64_MAX;
int n, siz;
ve<pair<int, int>> tree;
ve<int> a;
bool cmp(pair<int, int> a, pair<int, int> b) {
	if (a.first == b.first) return a.second < b.second;
	else return a.first > b.first;
}
struct m {
	bool operator()(pair<int, int> a, pair<int, int> b) const {
		if (a.first == b.first) return a.second < b.second;
		else return a.first > b.first;
	}
};
struct st {
	void init(int n) {
		siz = 1;
		while (siz < n) siz *= 2;
		tree.assign(2 * siz - 1, {0, INT32_MIN});
	}
	void build(ve<int> &a, int lx, int rx, int x) {
		if (rx - lx == 1) {
			if (lx < n) tree[x].first = a[lx], tree[x].second = a[lx];
			return;
		}
		int m = (lx + rx) / 2;
		build(a, lx, m, 2 * x + 1);
		build(a, m, rx, 2 * x + 2);
		tree[x].first = tree[2 * x + 1].first + tree[2 * x + 2].first;
	}
	void build(ve<int> &a) {
		init(n);
		build(a, 0, siz, 0);
	}
	void set(int lx, int rx, int x, int i, int v) {
		if (rx - lx == 1) {
			tree[x].first = v;
			return;
		}
		int m = (lx + rx) / 2;
		if (i < m) set(lx, m, 2 * x + 1, i, v);
		else set(m, rx, 2 * x + 2, i, v);
		tree[x].first = tree[2 * x + 1].first + tree[2 * x + 2].first;
	}
	void set(int i, int v) {
		set(0, siz, 0, i, v);
	}
	int sum(int l, int r, int x, int lx, int rx) {
		if (lx >= l && rx <= r) return tree[x].first;
		if (rx <= l || lx >= r) return 0;
		int m = (lx + rx) / 2;
		int s1 = sum(l, r, 2 * x + 1, lx, m);
		int s2 = sum(l, r, 2 * x + 2, m, rx);
		return s1 + s2;
	}
	int sum(int l, int r) {
		return sum(l, r, 0, 0, siz);
	}
};

void initialise(int N, int Q, ve<int> h) {
	n = N;
	a.resize(n);
	for (int i = 1; i <= n; ++i) a[i - 1] = h[i];
	st().build(a);
}
void cut(int l, int r, int k) {
	--l;
	ve<pair<int, int>> d(r - l);
	for (int i = 0; i < r - l; ++i) d[i] = { a[l + i], l + i };
	sort(all(d), cmp);
	int cnt = 0, sum = 0, R = -1, ans;
	for (int i = 0; i < r - l; ++i) {
		sum += d[i].first;
		++cnt;
		if (i < r - l - 1) {
			if (sum - d[i + 1].first * cnt >= k) {
				R = i + 1;
				ans = d[i + 1].first;
				break;
			}
		}
		else {
			if (sum >= k) {
				R = i + 1;
				ans = 0;
				break;
			}
		}
	}
	if (R == -1) {
		if (sum < k) for (int i = l; i < r; ++i) st().set(i, 0), a[i] = 0;
		else {
			ve<int> f;
			int op = sum - k;
			for (int i = 0; i < r - l; ++i) f.push_back(d[i].second);
			set<pair<int, int>, m> g(d.begin(), d.begin() + R);
			int count = 0;
			set<int> ty;
			while (count < k) {
				if ((*g.begin()).first == 0) break;
				ty.insert((*g.begin()).second);
				pair<int, int> i = { (*g.begin()).first - 1, (*g.begin()).second };
				g.erase(g.begin());
				g.insert(i);
				++count;
			}
			for (auto i : g) {
				if (ty.find(i.second) != ty.end()) {
					st().set(i.second, i.first);
					a[i.second] = i.first;
				}
			}
		}
	}
	else {
		ve<int> f;
		int op = sum - ans * cnt - k;
		for (int i = 0; i < R - l; ++i) f.push_back(d[i].second);
		set<pair<int, int>, m> g(d.begin(), d.begin() + R);
		int count = 0;
		set<int> ty;
		while (count < k) {
			if ((*g.begin()).first == 0) break;
			ty.insert((*g.begin()).second);
			pair<int, int> i = { (*g.begin()).first - 1, (*g.begin()).second };
			g.erase(g.begin());
			g.insert(i);
			++count;
		}
		for (auto i : g) {
			if (ty.find(i.second) != ty.end()) {
				st().set(i.second, i.first);
				a[i.second] = i.first;
			}
		}
	}

}
void magic(int i, int x) {
	--i;
	a[i] = x;
	st().set(i, x);
}
long long int inspect(int l, int r) {
	--l;
	return st().sum(l, r);
}

