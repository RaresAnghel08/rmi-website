/**
* user:  pavic-e27
* fname: Patrick
* lname: Pavić
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:46:50.430227
*/
#include <cstdio>
#include <vector>
#include <algorithm>

#define X first
#define Y second
#define PB push_back

using namespace std;

typedef long long ll;
typedef pair < int, ll > pil;

const int N = 2e3 + 50;

int n, k;
ll dep[N], up[N];
vector < pil > v[N];

void dfs(int x, int lst){
	for(pil nxt : v[x]){
		if(nxt.X == lst) continue;
		dfs(nxt.X, x);
		up[nxt.X] = max(up[nxt.X], dep[x] + nxt.Y);
		dep[x] = max(dep[x], dep[nxt.X] + nxt.Y);
	}
	ll dos = 0;
	reverse(v[x].begin(), v[x].end());
	for(pil nxt : v[x]){
		if(nxt.X == lst) continue;
		up[nxt.X] = max(up[nxt.X], dos + nxt.Y);
		dos = max(dos, dep[nxt.X] + nxt.Y);
	}
}

void update_up(int x, int lst){
	for(pil nxt : v[x]){
		if(nxt.X == lst) continue;
		up[nxt.X] = max(up[nxt.X], up[x] + nxt.Y);
		update_up(nxt.X, x);
	}
}

int main(){
	scanf("%d%d", &n, &k);
	for(int i = 1;i < n;i++){
		int x, y, z; scanf("%d%d%d", &x, &y, &z);
		v[x].PB({y, z}), v[y].PB({x, z});
	}
	dfs(1, 1);  update_up(1, 1);
	for(int i = 1;i <= n;i++)
		printf("%lld\n", max(up[i], dep[i]));
	return 0;
}
