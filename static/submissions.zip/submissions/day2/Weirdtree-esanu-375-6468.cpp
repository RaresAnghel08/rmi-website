/**
* user:  esanu-375
* fname: Mihai
* lname: Eșanu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:54:38.555374
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
#define MOD 1000000007
#define vint vector<int>
#define pb push_back
#define fr first
#define sc second
using namespace std;

struct node
{
    int mx, posmx, sum;
};
int nglb;
int nds = 0;
vector<node> tree;
int posnd[100005];

node mrg(node one, node two)
{
    node res;
    if(one.mx >= two.mx)
    {
        res.mx = one.mx;
        res.posmx = one.posmx;
    }
    else
    {
        res.mx = two.mx;
        res.posmx = two.posmx;
    }
    res.sum = one.sum+two.sum;
    return res;
}

void build(int now, int l, int r, int h[])
{
    if(r < l)
    {
        return;
    }
    if(l == r)
    {
        tree[now].mx = a[l-1];
        tree[now].sum = a[l-1];
        posnd[l] = now;
        tree[now].posmx = now;
        return;
    }
    int mid = (l+r)/2;
    build(now*2, l, mid, a);
    build(now*2+1, mid+1, r, a);
    tree[now] = mrg(tree[now*2], tree[now*2+1]);
}

pair<int, int> fnd(int now, int l, int r, int tl, int tr)
{
    if( r < l || r < tl || l > tr)
    {
        return {-1, -1};
    }
    if(tl <= l && r <= tr)
    {
        return {tree[now].mx, tree[now].posmx};
    }
    int mid = (l+r)/2;
    pair<int, int> now1 = fnd(now*2, l, mid, tl, tr);
    pair<int, int> now2 = fnd(now*2+1, mid+1, r, tl, tr);
    if(now1.fr >= now2.fr)
    {
        return now1;
    }
    else
    {
        return now2;
    }
}

void update(int pos)
{
    while(pos != 1)
    {
        if(pos%2 == 0)
        {
            tree[pos/2] = mrg(tree[pos], tree[pos+1]);
        }
        else
        {
            tree[pos/2] = mrg(tree[pos], tree[pos-1]);
        }
        pos/=2;
    }
}

void cut(int l, int r, int k)
{
    pair<int, int> modif = fnd(1, 1, nglb, l, r);
    if(modif.sc <= 0)
    {return;}
    //cout << modif.fr << " " << modif.sc << endl;
    tree[modif.sc].mx = max(0, modif.fr-1);
    tree[modif.sc].sum = tree[modif.sc].mx;
    update(modif.sc);
}

void magic(int pos, int x)
{
    tree[posnd[pos]].mx = x;
    tree[posnd[pos]].sum = x;
    update(posnd[pos]);
}

long long query3(int now, int l, int r, int tl, int tr)
{
    if(r < l || r < tl || tr < l)
    {
        return 0;
    }
    if(tl <= l && r <= tr)
    {
        return tree[now].sum;
    }
    int mid = (l+r)/2;
    return query3(now*2, l, mid, tl, tr)+query3(now*2+1, mid+1, r, tl, tr);
}

long long inspect(int l, int r)
{
    return query3(1, 1, nglb, l, r);
}



void initialise(int n, int q, int h[])
{
    node tmp;
    tmp.mx = -1;
    tmp.posmx = -1;
    tmp.sum = 0;
    nglb = n;
    tree.assign(12*n, tmp);
    build(1,1, n, h);
}
