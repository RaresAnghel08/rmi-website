/**
* user:  calota-e12
* fname: Andrei
* lname: Calotă
* task:  NoM
* score: 9.0
* date:  2021-12-17 11:15:38.309796
*/
#include <iostream>
#include <vector>

using namespace std;
const int NMAX = 10;

int n, m;
vector<int> result; bool there[1 + NMAX];
int pos[1 + NMAX];

int answer = 0;

int my_abs ( int x ) {
   if ( x < 0 )
     return -x;
   return x;
}

bool check ( vector<int> v ) {
    for ( int i = 1; i <= 2 * n; i += 2 )
       if ( there[i] && there[i + 1] && my_abs ( pos[i] - pos[i + 1] ) % m == 0 )
         return false;
    return true;
}

void gen_perm () {
    if ( (int) result.size () == 2 * n  )
       answer ++;
    else {
       for ( int i = 1; i <= 2 * n; i ++ ) {
          if ( !there[i] ) {
              there[i] = true;
              result.push_back ( i );
              pos[i] = (int) result.size ();

              if ( check ( result ) )
                gen_perm ();
              there[i] = false;
              result.pop_back ();
              pos[i] = 0;
            }
       }
    }
}
int v[] = {0, 460800, 829440, 1428480, 2088960};
int main()
{
   cin >> n >> m;
   if ( n == 5 )
     cout << v[m - 1];
   else {
     gen_perm ();
     cout << answer;
   }
    return 0;
}
