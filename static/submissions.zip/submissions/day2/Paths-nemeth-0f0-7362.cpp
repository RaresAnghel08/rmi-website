/**
* user:  nemeth-0f0
* fname: Márton
* lname: Németh
* task:  Paths
* score: 31.0
* date:  2021-12-17 11:52:38.062160
*/
#include <bits/stdc++.h>

using namespace std;
typedef long long int ll;

struct node{
    ll e,l;
    ll a,b;
    ll bal,jobb;
};

vector<node> tr;
ll p1=0;

ll epit(ll x,ll y) {
    ll p2=p1; p1++;
    tr[p2].a=x; tr[p2].b=y;
    tr[p2].e=0; tr[p2].l=0;

    if (x==y) {
        tr[p2].bal=-1;
        tr[p2].jobb=-1;
        return(p2);
    }

    tr[p2].bal=epit(x,(x+y)/2);
    tr[p2].jobb=epit((x+y)/2+1,y);

    return(p2);
}

ll frissit(ll p,ll x,ll y,ll u) {
    //cout << p << " " << x << " " << y << " " << u << " x" << endl;
    if (p==-1) {
        return(-1e9);
    }
    if ((tr[p].a>=x)&&(tr[p].b<=y)) {
        tr[p].l+=u;
        return(tr[p].e+tr[p].l);
    }
    if ((tr[p].b<x)||(tr[p].a>y)) {
        return(tr[p].e+tr[p].l);
    }
    if (tr[p].bal>-1) {
        tr[tr[p].bal].l+=tr[p].l;
    }
    if (tr[p].jobb>-1) {
        tr[tr[p].jobb].l+=tr[p].l;
    }
    tr[p].l=0;
    tr[p].e=max(frissit(tr[p].bal,x,y,u),frissit(tr[p].jobb,x,y,u));
    return(tr[p].e);
}

int lekerd(int p) {
    if (tr[p].a==tr[p].b) {
        return(tr[p].a);
    }
    if (tr[p].bal==-1) {
        return(lekerd(tr[p].jobb));
    }
    if (tr[p].jobb==-1) {
        return(lekerd(tr[p].bal));
    }
    if (tr[tr[p].bal].e+tr[tr[p].bal].l>tr[tr[p].jobb].e+tr[tr[p].jobb].l) {
        return(lekerd(tr[p].bal));
    } else {
        return(lekerd(tr[p].jobb));
    }
}

struct el{
    ll s,e;
};

vector<el> t[100001];
el z;
int n,k;

vector<ll> volt;
ll find_furthest(ll p) {
    ll o=0;
    vector<ll> q;
    volt.clear(); volt.resize(n+1,-1);
    q.clear();
    q.push_back(p);
    volt[p]=0;
    ll furt=p;
    while (o<q.size()) {
        for (el i:t[q[o]]) {
            if (volt[i.s]==-1) {
                volt[i.s]=volt[q[o]]+i.e;
                q.push_back(i.s);
                if (volt[i.s]>volt[furt]) {
                    furt=i.s;
                }
            }
        }
        o++;
    }
    return(furt);
}



ll g[100001][2];
ll f[100001][2];
ll r=0;
ll h[200001];
ll v[100001];
ll par[100001];
ll dpar[100001];

void bejar(ll p,ll pa,ll d) {
    //cout << p << " " << pa << " " << d << endl;
    par[p]=pa;
    dpar[p]=d;
    v[p]=1;
    f[p][0]=r; h[r]=p; r++;
    for (el i:t[p]) {
        if (v[i.s]==0) {
            bejar(i.s,p,i.e);
        }
    }
    f[p][1]=r; h[r]=p; r++;
}

int main()
{
    cin >> n >> k;
    int a,b;
    for (int i=0;i<n-1;i++) {
        cin >> a >> b >> z.e;
        z.s=a;
        t[b].push_back(z);
        z.s=b;
        t[a].push_back(z);
    }
    ll szel=find_furthest(1);
    ll szel2;
    if (k==1) {
        szel2=find_furthest(szel);
        for (int i=1;i<=n;i++) {
            g[i][0]=volt[i];
        }
        find_furthest(szel2);
        for (int i=1;i<=n;i++) {
            g[i][1]=volt[i];
        }
        for (int i=1;i<=n;i++) {
            cout << max(g[i][0],g[i][1]) << endl;
        }
        return(0);
    }

    ll hely;
    ll ans;
    node z2;
    ll fa;

    for (int w=1;w<=n;w++) {

    z2.e=0; z2.a=0; z2.b=0; z2.bal=0; z2.jobb=0; z2.l=0;
    tr.clear(); p1=0;
    tr.resize(5*n,z2);
    fa=epit(0,2*n-1);
    for (int i=1;i<=n;i++) {
        v[i]=0;
    }
    find_furthest(w);
    r=0;
    bejar(w,-1,0);
/*
    for (int i=1;i<=n;i++) {
        cout << volt[i] << " ";
    }
    cout << endl;
*/
    for (int i=1;i<=n;i++) {
        frissit(fa,f[i][0],f[i][0],volt[i]);
        frissit(fa,f[i][1],f[i][1],volt[i]);
    }
/*
    for (int i=0;i<=5*n;i++) {
        cout << tr[i].a << " " << tr[i].b << " " << tr[i].e << " " << tr[i].l << endl;
    }
    cout << endl;
*/
    ans=0;

    for (int i=1;i<=k;i++) {
        ans+=tr[fa].e+tr[fa].l;
        if (tr[fa].e+tr[fa].l==0) {
            break;
        }
        hely=lekerd(fa);
        hely=h[hely];
        while (hely!=w) {
            frissit(fa,f[hely][0],f[hely][1],-1*dpar[hely]);
            for (el j:t[hely]) {
                if (j.s!=par[hely]) {
                    par[j.s]=w;
                }
            }
            hely=par[hely];
        }
    }

    cout << ans << endl;

    }

    return 0;
}

/*
3 2
1 2 3
2 3 4
*/

/*
11 2
1 2 1
2 6 5
2 7 1
7 9 1
1 3 2
3 5 1
3 4 0
4 8 0
5 11 2
5 10 3
*/
