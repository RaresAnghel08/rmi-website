/**
* user:  kruhlikau-b9e
* fname: Ihar
* lname: Kruhlikau
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 07:29:52.791795
*/
#include <bits/stdc++.h>

#define fi first
#define se second
#define mp make_pair

#define pb push_back
#define pob pop_back

#define ld long double
#define ll long long

#define re return
#define cont continue

#define endl '\n'

using namespace std;

ll a[350001], n, i, q, mx, nom, l1, r1, mid, val, val1, ans;

    ll get(ll l, ll r, ll val)
    {
        ll i, ans = 0;

        for (i = l; i <= r; i++) ans += max(a[i] - val, 0LL);

        re ans;
    }

    void cut(int l, int r, int k)
    {
        l1 = 0;

        r1 = 1000000000;

        while (l1 <= r1) {
            mid = (l1 + r1) / 2;

            if (get(l, r, mid) <= k) {
                val = mid;

                r1 = mid - 1;
            }
            else l1 = mid + 1;
        }

        for (i = l; i <= r; i++)
            if (a[i] > val) {
                k -= a[i] - val;

                a[i] = val;
            }

        for (i = l; i <= r; i++)
            if (a[i] == val && a[i] > 0) {
                if (k - 1 >= 0) {
                    a[i]--;

                    k--;
                }
            }
    }

    long long int inspect(int l, int r)
    {
        ans = 0;

        for (i = l; i <= r; i++) ans += a[i];

        re ans;
    }

    void magic(int i, int x)
    {
        a[i] = x;
    }

    void initialise(int N, int Q, int h[])
    {
        n = N;

        q = Q;

        for (i = 1; i <= n; i++) a[i] = h[i];
    }

//int main()
//{
//    ios::sync_with_stdio(0);
//    cin.tie(0);
//
//
//
//    re 0;
//}
