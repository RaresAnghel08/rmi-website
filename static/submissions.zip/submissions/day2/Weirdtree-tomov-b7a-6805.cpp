/**
* user:  tomov-b7a
* fname: Konstantin Konstantinov
* lname: Tomov
* task:  Weirdtree
* score: 8.0
* date:  2021-12-17 11:17:49.530762
*/
#include<iostream>
#include<vector>
#include<algorithm>
#include "weirdtree.h"
using namespace std;

typedef long long ll;

ll vals[1010];
ll n,q;

void initialise(int N,int Q,int h[]){
  n=N;
  q=Q;
  for(ll i=1;i<=n;++i)vals[i]=h[i];
  }

void magic(int i,int x){
  //nope
  }

void cut(int l,int r,int k){
  vector<ll> v;
  for(ll i=l;i<=r;++i)v.push_back(vals[i]);
  sort(v.begin(),v.end());

  //cout<<endl;
  //for(ll i=0;i<v.size();++i)cout<<v[i]<<" ";cout<<endl;

  ll br,howm;
  ll kolko,gra;
  ll dok;
  for(ll i=v.size()-1;i>=0;--i){
    while(i>0 && v[i-1]==v[i])--i;
    br=v.size()-i;
    if(i==0)howm=v[0];
    else howm=v[i]-v[i-1];

    //cout<<i<<" "<<howm<<" "<<br<<" "<<k<<endl;

    if(k>br*howm){
      k-=br*howm;
      }
    else {
      ll x=k/br;
      if(k%br==0){
        kolko=br;
        gra=v[i]-x+1;
        dok=v[i]-x;
        }
      else {
        kolko=k%br;
        gra=v[i]-x;
        dok=v[i]-x-1;
        }
      k=0;
      break;
      }
    }

  if(k){
    kolko=r-l+1;
    gra=0;
    dok=0;
    }
  //cout<<kolko<<" "<<gra<<" "<<dok<<endl;

  for(ll i=l;i<=r;++i){
    if(vals[i]>=gra){
      vals[i]=dok;
      --kolko;
      if(kolko==0){kolko=1e9;++dok;}
      }
    }

  //for(ll i=1;i<=n;++i)cout<<vals[i]<<" ";cout<<endl;
  }

long long int inspect(int l,int r){
  ll s=0;
  for(ll i=l;i<=r;++i)s+=vals[i];
  return s;
  }

/*
int main(){

int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }

return 0;
}
/*
6 1
1 2 3 10 10 5
1 1 6 1
*/
