/**
* user:  priboi-950
* fname: Mihai Luca
* lname: Priboi
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:21:41.141432
*/
#include <bits/stdc++.h>

using namespace std;

#define ll long long

#define MAXN 1000

struct muchie {
  int next;
  int start_val, val;
};

vector<muchie> muchii[MAXN + 1];

void dfs( int node, int root ) {
  int i;
  for( i = 0; i < muchii[node].size() - 1; i++ ) {
    if( muchii[node][i].next == root )
      swap( muchii[node][i], muchii[node].back() );

    dfs( muchii[node][i].next, node );
  }
}

ll road_sum( int node ) {
  ll s = 0;
  while( muchii[node].back().next != -1 ) {
    s += muchii[node].back().val;
    node = muchii[node].back().next;
  }

  return s;
}

void empty_road( int node ) {
  while( muchii[node].back().next != -1 ) {
    muchii[node].back().val = 0;
    node = muchii[node].back().next;
  }
}

void redo_roads( int n ) {
  int i, j;
  for( i = 1; i <= n; i++ ) {
    muchii[i].back().val = muchii[i].back().start_val;
  }
}

int main() {
  int n, k, root, i, a, b, c, q, max_node;
  ll x, maxim, rez;

  scanf( "%d%d", &n, &k );
  for( i = 0; i < n - 1; i++ ) {
    scanf( "%d%d%d", &a, &b, &c );
    muchii[a].push_back({b, c, c});
    muchii[b].push_back({a, c, c});
  }

  for( root = 1; root <= n; root++ ) {
    muchii[root].push_back({-1, 0, 0});

    dfs( root, -1 );

    rez = 0;
    q = 0;
    maxim = 1;
    while( q < k && maxim > 0 ) {
      maxim = 0;
      for( i = 1; i <= n; i++ ) {
        if( muchii[i].size() == 1 ) {
          //printf( "%d\n debug o\n", i);
          x = road_sum(i);
          //printf( " debug k\n\n");
          if( x > maxim ) {
            maxim = x;
            max_node = i;
          }
        }
      }

      rez += maxim;
      empty_road(max_node);
      q++;
    }
    muchii[root].pop_back();
    redo_roads(n);

    printf( "%d\n", rez );
  }
  return 0;
}
