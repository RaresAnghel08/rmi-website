/**
* user:  denysiuk-795
* fname: Vladyslav
* lname: Denysiuk
* task:  NoM
* score: 9.0
* date:  2021-12-17 10:11:03.398829
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double ld;

#define endl '\n'
#define all(var) var.begin(),var.end()
#define mp make_pair

const int N = 4e3+7;
const ll MOD = 1e9+7;

ll fact[N],rev[N];
ll C(int n,int k){
    if (n<0 || k<0 || n<k)
        return 0;
    return fact[n]*rev[n-k]%MOD*rev[k]%MOD;
}

ll binpow(ll x,ll power){
    ll mult = x%MOD;
    x = 1;

    while(power){
        if (power&1)
            x = x*mult%MOD;
        mult = mult*mult%MOD;
        power = power>>1;
    }
    return x;
}
int pos[N];
bool check(vector<pair<int,int> > &V,int m){
    int sz = V.size();
    for(int i = 0;i<sz;++i){
        pos[i] = -1;
    }
    for(int i = 0;i<sz;++i){
        if (pos[V[i].first]!=-1 && (i-pos[V[i].first])%m==0)
            return 0;
        else if (pos[V[i].first]==-1)
            pos[V[i].first] = i;
    }
    return 1;
}
int checkmask(int n,int m){
    vector<pair<int,int> > V;
    for(int i = 1;i<=n;++i){
        V.push_back({i,0});
        V.push_back({i,1});
    }
    int res = 0;
    do{
        res+=check(V,m);
    }while(next_permutation(V.begin(),V.end()));
    return res;
}
void solve(){
    int n,m;
    cin>>n>>m;
    /*ll res = fact[2*n];

    for(int i = 1;i<=n;++i){
        ll add = C(n,i)*C(2*n-m,i)%MOD*fact[(n-i)*2]%MOD*binpow(2,i)%MOD;
      //  cout<<C(n,i)<<' '<<C(2*n-m,i)<<' '<<fact[(n-i)*2]<<' '<<binpow(2,i)<<endl;
        if (i&1)
            res-=add;
        else res+=add;
    }
    cout<<res<<endl;*/
    cout<<checkmask(n,m)<<endl;
}

signed main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    fact[0] = 1;

    for(int i = 1;i<N;++i)
        fact[i] = fact[i-1]*i%MOD;

    rev[N-1] = binpow(fact[N-1],MOD-2);
    for(int i = N-2;i>=0;--i)
        rev[i] = rev[i+1]*(i+1)%MOD;

    int t = 1;
    //cin>>t;
    while(t--)
        solve();
}