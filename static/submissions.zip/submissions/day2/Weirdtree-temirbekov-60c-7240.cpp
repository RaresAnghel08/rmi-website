/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:46:43.445408
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

vector <long long> t;
long long n;
long long ppow = 1ll;
vector <long long> H;
vector <pair <int, int>> b;

void countDecomposition() {
	int len = (int)sqrt(n);
	b.resize(len + 1, {-1e9, 0});
	for(int i = 0; i < n; i ++) {
		if(b[i/len].first < H[i]) {
			b[i/len].first = H[i];
			b[i/len].second = i;
		}
	}
}

int answerQuery(int l, int r) {
	int len = (int)sqrt(n);
	int mx = -1e9;
	int idx = 0;
	while(l <= r) {
		if(l % len == 0 and l + len - 1 <= r) {
			if(mx < b[l/len].first) {
				mx = b[l/len].first;
				idx = b[l/len].second;
			}
			l += len;
		}else {
			if(mx < H[l]) {
				mx = b[l].first;
				idx = l;
			}
			l += 1;
		}
	}
	return idx;
}


void print() {
	for(long long i = 0; i < (long long)1e6; i += 1) {
		if(i >= 2 * ppow - 1) break;
		cout << (i + 1) << " -> " << t[i] << "\n";
	}
	//cout << ppow << endl;
}

void build(long long v, long long vl, long long vr, const vector <long long> & a) {
	if(vl == vr){
		if(vl < n)
			t[v] = a[vl];
	}else {
		long long vm = (vl + vr) / 2;
		build(2*v+1, vl, vm, a);
		build(2*v+2, vm+1, vr, a);
		t[v] = t[2*v+1] + t[2*v+2] + 0ll;
	}
}

long long get(long long v, long long vl, long long vr, const long long l, const long long r) {
	if(vr < l or vl > r) return 0ll;
	else if(l <= vl and vr <= r) return t[v] * 1ll;
	else {
		long long vm = (vl + vr) / 2;
		//return 0;
		return get(2*v+1, vl, vm, l, r) + get(2*v+2, vm+1, vr, l, r) + 0ll;
	}
}

void add(long long v, long long vl, long long vr, const long long pos, const long long x) {
	if(vl == vr) {
		t[v] -= x;
		return;
	}
	long long vm = (vl + vr) / 2;
	if(pos <= vm) add(2*v+1, vl, vm, pos, x);
	else add(2*v+2, vm + 1, vr, pos, x);
	t[v] = t[2*v+1] + t[2*v+2] + 0ll;
}

void upd(long long v, long long vl, long long vr, const long long pos, const long long x) {
	if(vl == vr) {
		t[v] = x + 0ll;
		return;
	}
	long long vm = (vl + vr) / 2;
	if(pos <= vm) upd(2*v+1, vl, vm, pos, x);
	else upd(2*v+2, vm + 1, vr, pos, x);
	t[v] = t[2*v+1] + 0ll + t[2*v+2];
}

void initialise(int N, int Q, int h[]) {
	// Your code here.
	for(long long i = 1; i <= N; i ++) {
		H.push_back(h[i]);
	}
	n = N;
	while(ppow < n) ppow <<= 1ll;
	t.resize(2*ppow-1);
	build(0, 0, ppow - 1, H);
	countDecomposition();
}
void cut(int l, int r, int k) {
	// Your code here.
	l--;
	r--;
	while(k--){
		/*long long pos = getmax(0, 0, ppow-1, l, r).second;
		long long mx = getmax(0, 0, ppow-1, l, r).first;
		if(mx == 0ll) break;
		H[pos] --;
		addmx(0ll, 0ll, ppow-1+ 0ll, pos+ 0ll, 1+ 0ll);
			add(0ll, 0ll, ppow-1+ 0ll, pos+ 0ll, 1+ 0ll);*/
		add(0, 0, n - 1, answerQuery(l, r), -1);
		
	}
	
}
void magic(int i, int x) {
	upd(0+ 0ll, 0+ 0ll, ppow - 1+ 0ll, i-1+ 0ll, x);
	H[i-1] = x;
	// Your code here.
}
long long inspect(int l, int r) {
	// Your code here.
	l --;
	r --;
	//cout << l << ' ' << r << "\n";
	return get(0+ 0ll, 0+ 0ll, ppow- 1+ 0ll, l+ 0ll, r+ 0ll) + 0ll;
}
