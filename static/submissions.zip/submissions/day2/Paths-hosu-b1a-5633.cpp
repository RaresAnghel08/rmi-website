/**
* user:  hosu-b1a
* fname: Iulia
* lname: Hosu
* task:  Paths
* score: 19.0
* date:  2021-12-17 09:47:35.674915
*/
#include <iostream>
#include <vector>

using namespace std;

const int N = 1e5 + 5;

int n, k;
long long dp[N][105];

vector <pair <int, long long> > v[N];

void dfs(int nod, int last, int muchie)   {
    for (int i = 0; i <= k; ++i)
        dp[nod][i] = 0;
    for (auto it : v[nod])  {
        if (it.first != last)   {
            dfs(it.first, nod, it.second);
        }
    }
    for (auto it : v[nod])  {
        if (it.first == last)
            continue;
        for (int i = k; i; --i)    {
            for (int j = 0; j < i; ++j)    {
                if (dp[nod][i] < dp[nod][j] + dp[it.first][i - j] + it.second)
                    dp[nod][i] = dp[nod][j] + dp[it.first][i - j] + it.second;
            }
        }
    }
}

void solve(int root)    {
    dfs(root, 0, 0);
    cout << dp[root][k] << '\n';
}

int main()  {
    cin >> n >> k;
    int x, y, c;
    for (int i = 1; i < n; ++i) {
        cin >> x >> y >> c;
        v[x].push_back({y, c});
        v[y].push_back({x, c});
    }
    for (int i = 1; i <= n; ++i)
        solve(i);
    return 0;
}
