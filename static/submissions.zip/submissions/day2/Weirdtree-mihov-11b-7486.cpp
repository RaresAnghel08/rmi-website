/**
* user:  mihov-11b
* fname: Rumen
* lname: Mihov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:57:11.399263
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e6+5;
long long w[maxn],n;
struct Segment
{
    long long segm[maxn],id[maxn],sum[maxn];
    void update(long long v, long long from, long long to, long long d, long long x)
    {
        if(from==to)
        {
            id[v] = from;
            segm[v] = x;
            sum[v] = x;
            return ;
        }
        long long mid = (from+to)/2;
        if(d<=mid)update(2*v,from,mid,d,x);
        else
            update(2*v+1,mid+1,to,d,x);
        if(segm[2*v]>=segm[2*v+1])
        {
            segm[v] = segm[2*v];
            id[v] = id[2*v];
        }
        else
        {
            segm[v] = segm[2*v+1];
            id[v] = id[2*v+1];
        }
        sum[v] = sum[2*v]+sum[2*v+1];
    }
    pair <long long,long long> query(long long v, long long from, long long to, long long l, long long r)
    {
        if(l<=from&&to<=r)return {segm[v],id[v]};
        long long mid = (from+to)/2;
        pair <long long,long long> p1={-1,-1},p2={-1,-1};
        if(l<=mid)p1 = query(2*v,from,mid,l,r);
        if(r>mid)p2 = query(2*v+1,mid+1,to,l,r);
        if(p1.first>=p2.first)return p1;
        return p2;
    }
    long long query2(long long v, long long from, long long to, long long l, long long r)
    {

         if(l<=from&&to<=r)return sum[v];
        long long mid = (from+to)/2;
        long long ans = 0;
        if(l<=mid)ans += query2(2*v,from,mid,l,r);
        if(r>mid)ans += query2(2*v+1,mid+1,to,l,r);

        return ans;
    }
};
Segment S;
void initialise(int N, int Q, int h[]) {
	long long i;
	n=N;
	for(i=1;i<=n;i++)
    {
        w[i] = h[i];
       // S.update(1,1,n,i,w[i]);
    }

}
vector <long long> a;
void cut(int l, int r, int k) {
	//auto p  = S.query(1,1,n,l,r);
	//cout<<p.first<<" "<<p.second<<endl;
	//if(p.second==0)return ;
	//S.update(1,1,n,p.second,p.first-1);
	long long maxs = k,num=0,prev=-1;
	long long i;
	a.clear();
	for(i=l;i<=r;i++)
    {
       a.push_back(w[i]);
    }
    a.push_back(0);
    sort(a.begin(),a.end());
    prev = a[a.size()-1];
    num=1;
    for(i=a.size()-2;i>=0;i--)
    {
        if(prev==a[i]){num++;continue;}
        //cout<<prev<<" && "<<a[i]<<" "<<num<<endl;
        if((prev-a[i])*num <=maxs)
        {
            maxs-=((prev-a[i])*num);
            prev=  a[i];
            num++;

            continue;
        }
        else
        break;
    }


   //cout<<prev<<" && "<<maxs<<endl;
    for(i=l;i<=r;i++)
    {
        if(w[i]>=prev)w[i] = prev;
    }

    long long br = 0;
    for(i = l;i<=r;i++)
    {
        if(w[i]==prev&&w[i]>0)br++;
    }
    if(br==0)return ;
    long long t = maxs/br;
    maxs = maxs%br;
    for(i = l;i<=r;i++)
    {
        if(w[i]==prev&&w[i]>0){w[i]-=t;
        if(maxs){w[i]--;maxs--;}
        }
    }
    for(i = l;i<=r;i++)
        if(w[i]<0)w[i]=0;
}
void magic(int i, int x) {
	// Your code here.
	w[i] =x;
}
long long inspect(int l, int r) {
	// Your code here.
	long long ans=  0;
	long long i;
	for(i=l;i<=r;i++)ans+=w[i];
	return ans;

}
