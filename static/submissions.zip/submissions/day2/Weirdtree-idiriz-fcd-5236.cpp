/**
* user:  idiriz-fcd
* fname: Nermin Hyusmen
* lname: Idiriz
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:12:59.319738
*/
#include<bits/stdc++.h>
#include "weirdtree.h"
const int MAXN=300010;
int n,q,height[MAXN];
long long sum=0;
void initialise(int N, int Q, int h[])
{
    n=N;
    q=Q;
    for(int i=1; i<=n; i++)
    {
        height[i]=h[i];
        sum+=height[i];
    }
}
void cut(int l, int r, int k)
{
    if(n>80000&&l==1&&r==n)
    {
        sum=sum-k;
        if(sum<0)sum=0;
        return;
    }
    while(k--)
    {
        int idx=l;
        for(int i=l+1; i<=r; i++)
        {
            if(height[i]>height[idx])idx=i;
        }
        height[idx]=height[idx]-1;
        if(height[idx]==-1)height[idx]=0;
        else sum--;
    }
}
void magic(int i, int x)
{
    sum+=x-height[i];
    height[i]=x;
}
long long int inspect(int l, int r)
{
    if(l==1&&r==n)return sum;
    long long int ans=0;
    for(int i=l; i<=r; i++)
        ans+=height[i];
    return ans;
}
