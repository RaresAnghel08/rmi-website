/**
* user:  chiriac-c10
* fname: Matei
* lname: Chiriac
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:25:23.342223
*/
#include <iostream>
#define mod 1000000007

using namespace std;

long long n,m;
long long dp[305][305][305];
long long fact[2005];

long long put(long long baza, long long exp)
{
    if(!exp)
        return 1;

    long long ans=put(baza, exp/2);
    ans *= ans;
    ans %= mod;

    if(exp % 2)
    {
        ans *= baza;
        ans %= mod;
    }

    return ans;
}
int main()
{
    cin>>n>>m;

    fact[0]=1;
    for(long long i=1;i<=n;i++)
        fact[i]=(fact[i-1]*i)%mod;

    dp[0][0][0]=1;

    for(int i=0;i<m;i++)
    {
        int libere = (2*n-i-1)/m + 1;

        for(int st=0; st<=n; st++)
            for(int dr=st; dr<=n; dr++)
                for(int noi=0; noi<=libere; noi++)
                {
                    int vechi = libere - noi;

                    if(st + vechi > dr)
                        continue;

                    if(st+vechi > n || dr+noi>n)
                        continue;

                    long long nans = (dp[i][st][dr]*fact[libere])%mod;
                    nans *= put(fact[noi], mod-2);
                    nans %= mod;

                    dp[i+1][st+vechi][dr+noi] += nans;
                    dp[i+1][st+vechi][dr+noi] %= mod;
                }
    }

    long long ans = dp[m][n][n];
    ans *= fact[n];
    ans %= mod;

    ans *=2;
    ans %= mod;

    cout<<ans;
    return 0;
}
