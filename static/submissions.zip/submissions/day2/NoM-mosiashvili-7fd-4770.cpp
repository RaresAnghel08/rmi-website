/**
* user:  mosiashvili-7fd
* fname: Luka
* lname: Mosiashvili
* task:  NoM
* score: 52.0
* date:  2021-12-17 08:32:10.595815
*/
#include<bits/stdc++.h>
using namespace std;
long long a,b,c,d,e,i,j,ii,jj,zx,xc,n,m,K,k,x[4009],X[4009],mod=1000000007LL,dp[2004][2004],fct[4009],Afct[4009],E,ans;
long long xar(long long q, long long w){
	if(w==0) return 1LL;
	long long qw=xar(q,w/2);
	if(w%2==0) return (qw*qw)%mod; else return ((qw*qw)%mod*q)%mod;
}
long long ga(long long q, long long w){
	return (q*xar(w,mod-2))%mod;
}
long long C(long long q, long long w){
	return ((Afct[w]*Afct[q-w])%mod*fct[q])%mod;
}
int main(){
	ios_base::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>n>>m;a=n*2;
	fct[0]=1;
	for(i=1; i<=4003; i++){
		fct[i]=fct[i-1]*i;fct[i]%=mod;
	}
	for(i=0; i<=4003; i++){
		Afct[i]=ga(1LL,fct[i]);
	}
	for(i=1; i<=2*n; i++){
		if(i%m==0){
			x[m]++;
		}else{
			x[i%m]++;
		}
	}
	dp[0][0]=1;E=0;
	for(i=1; i<=m; i++){
		E+=x[i]/2;
		for(j=0; j<=E; j++){
			e=min(j,x[i]/2);
			for(k=0; k<=e; k++){
				X[i]=C(x[i],2*k)*C(2*k,k);X[i]%=mod;
				X[i]*=fct[k];X[i]%=mod;
				X[i]*=fct[k];X[i]%=mod;
				zx=dp[i-1][j-k]*X[i];zx%=mod;
				zx*=C(j,k);zx%=mod;
				dp[i][j]+=zx;dp[i][j]%=mod;
			}
		}
	}
	//cout<<dp[m][1]<<" "<<dp[m][2]<<"\n";
	ans=fct[2*n];
	for(K=1; K<=n; K++){
		zx=dp[m][K]*C(n,K);zx%=mod;
		zx*=fct[2*n-2*K];zx%=mod;
		if(K%2==1){
			ans=(ans-zx+mod)%mod;
		}else{
			ans+=zx;ans%=mod;
		}
	}
	cout<<ans;
	return 0;
}
