/**
* user:  mihov-0af
* fname: Petar Velislavov
* lname: Mihov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:13:09.610977
*/
#include<bits/stdc++.h>
using namespace std;
#define MAXN  80007
int n,seg1[4*MAXN],seg2[4*MAXN],H[MAXN];
long long seg3[4*MAXN];
void Init(int ind, int l, int r)
{
    if (l==r)
    {
        seg1[ind]=H[l];
        seg3[ind]=H[l];
        seg2[ind]=l;
        return ;
    }
    int mid=(l+r)/2;
    Init(ind*2,l,mid);
    Init(ind*2+1,mid+1,r);
    if (seg1[ind*2]>=seg1[ind*2+1])
    {
        seg1[ind]=seg1[ind*2];
        seg2[ind]=seg2[ind*2];
    }
    else
    {
        seg1[ind]=seg1[ind*2+1];
        seg2[ind]=seg2[ind*2+1];
    }
    seg3[ind]=seg3[ind*2]+seg3[ind*2+1];
}
int mx=-1,mxi=0;
long long sm=0;
void Query(int ind, int l, int r, int ql, int qr)
{
    if (l>=ql && r<=qr)
    {
        sm+=seg3[ind];
        if (seg1[ind]>mx)
        {
            mx=seg1[ind];
            mxi=seg2[ind];
        }
        return;
    }
    int mid=(l+r)/2;
    if (ql<=mid) Query(ind*2,l,mid,ql,qr);
    if (qr>=(mid+1)) Query(ind*2+1,mid+1,r,ql,qr);
}
void Update(int ind, int l, int r, int qu, int hh)
{
    if (l==r && l==qu)
    {
        seg1[ind]=hh;
        seg3[ind]=hh;
        return;
    }
    int mid=(l+r)/2;
    if (qu<=mid) Update(ind*2,l,mid,qu,hh);
    if (qu>=(mid+1)) Update(ind*2+1,mid+1,r,qu,hh);
    if (seg1[ind*2]>=seg1[ind*2+1])
    {
        seg1[ind]=seg1[ind*2];
        seg2[ind]=seg2[ind*2];
    }
    else
    {
        seg1[ind]=seg1[ind*2+1];
        seg2[ind]=seg2[ind*2+1];
    }
    seg3[ind]=seg3[ind*2]+seg3[ind*2+1];
}
void initialise(int N, int Q, int h[])
{
    n=N;
    for (int q=1;q<=n;q++) H[q]=h[q];
    Init(1,1,n);
}
void cut(int l, int r, int k)
{
    for (int q=0;q<k;q++)
    {
        mx=-1;mxi=0;sm=0;
        Query(1,1,n,l,r);
        if (mx==0) return;
        H[mxi]--;
        //cout<<mx<<" "<<mxi<<"\n";
        Update(1,1,n,mxi,H[mxi]);
        //for (int q=1;q<=n;q++) cout<<H[q]<<" ";
        //cout<<"\n";
    }
}
void magic(int i, int x)
{
    H[i]=x;
    Update(1,1,n,i,x);
    //for (int q=1;q<=n;q++) cout<<H[q]<<" ";
    //cout<<"\n";
}
long long int inspect(int l, int r)
{
    mx=-1;mxi=0;sm=0;
    Query(1,1,n,l,r);
    return sm;
}
