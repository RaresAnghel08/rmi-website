/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 09:25:07.448594
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include "weirdtree.h"
#include <map>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef pair<ll, ll> pii;
typedef vector<pii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

vi h;

void initialise(int n, int q, int H[]) {
   h.resize(n + 1);
   for (int i = 1; i <= n; i++) h[i] = H[i];
}

void cut(int l, int r, int k) {
    map<ll, vi, greater<ll>> mp;
    mp[0] = {};
    for (int i = l; i <= r; i++) mp[h[i]].push_back(i);
    auto next = mp.begin();
    auto curr = next++;
    while (k) {
        if (!curr->x) return;
        ll x = curr->x, y = 0;
//        if (next != mp.end()) y = next->x;
        int n = curr->y.size();
        ll dec = (x - y) * n;
        if (dec <= k) {
            k -= dec;
            for (int i : curr->y) {
                next->y.push_back(i);
                h[i] = y;
            }
            curr = next++;
            continue;
        }
        sort(all(curr->y));
        int m = k % n;
        int a = (k - m) / n;
        for (int i = 0; i < m; i++) {
            h[curr->y[i]] -= a + 1;
        }
        for (int i = m; i < n; i++) h[curr->y[i]] -= a;
        return;
    }
}

void magic(int i, int x) {
    h[i] = x;
}

long long int inspect(int l, int r) {
    ll ans = 0;
    for (int i = l; i <= r; i++) ans += h[i];
    return ans;
}
