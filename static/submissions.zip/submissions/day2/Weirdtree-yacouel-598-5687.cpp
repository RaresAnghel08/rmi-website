/**
* user:  yacouel-598
* fname: Assaf
* lname: Yacouel
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:51:51.130182
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include "weirdtree.h"
using namespace std;
typedef long long ll;
typedef vector<ll> vi;
typedef pair<ll, ll> pii;
typedef vector<pii> vpi;
vi h1;
#define all(v) v.begin(), v.end()
void initialise(int N, int Q, int h[]) {
	for (int i = 0; i < N; i++) h1.push_back(h[i]);
}
void cut(int l, int r, int k) {
	int m = -1, indm = -1;
	for (int i = r-1; i >= l-1; i--) {
		if (h1[i] >= m) {
			m = h1[i];
			indm = i;
		}
	}
	if(h1[indm] > 0) h1[indm] -= 1;
}
void magic(int i, int x) {
	h1[i - 1] = x;
}
long long int inspect(int l, int r) {
	ll sum = 0;
	for (int i = l - 1; i < r; i++) sum += h1[i];
	return sum;
}