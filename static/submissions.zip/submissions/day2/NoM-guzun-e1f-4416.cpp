/**
* user:  guzun-e1f
* fname: Veaceslav
* lname: Guzun
* task:  NoM
* score: 9.0
* date:  2021-12-17 07:50:36.900793
*/
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define sz(a) (int)a.size()
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()
#define pb push_back

void solve(){
    int n, m;
    cin >> n >> m;
    int N = 2 * n;
    vector<int> a(N);
    iota(all(a), 0);
    int ans = 0;
    do{
        vector<int> pos(N, 0);
        for(int i = 0;i < N; ++i){
            pos[a[i]] = i;
        }
        bool ok = true;
        for(int i = 0;i < n; ++i){
            if(abs(pos[i] - pos[i + n]) % m == 0)ok = false;
        }
        if(ok)++ans;
    }while(next_permutation(all(a)));
    cout << ans << "\n";
}

int main() {
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}
