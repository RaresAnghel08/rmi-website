/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:21:21.493757
*/
#include "weirdtree.h"
#include <iostream>
#include <utility>
#define endl '\n'
using namespace std;

const int MAXN = 300000;

int n;
int h[MAXN + 5];
long long int sum[4 * MAXN + 5];
pair<int, int> tree[4 * MAXN + 5];

void build(int v, int l, int r)
{
    if (l == r)
    {
        tree[v] = {h[l], -l};
        sum[v] = h[l];
        return;
    }

    int mid = (l + r) / 2;
    build(2 * v, l, mid);
    build(2 * v + 1, mid + 1, r);
    tree[v] = max(tree[2 * v], tree[2 * v + 1]);
    sum[v] = sum[2 * v] + sum[2 * v + 1];
}

void update(int v, int l, int r, int p, int val)
{
    if (r < p or p < l) return;
    if (l == r)
    {
        h[l] = val;
        tree[v] = {h[l], -l};
        sum[v] = h[l];
        return;
    }

    int mid = (l + r) / 2;
    update(2 * v, l, mid, p, val);
    update(2 * v + 1, mid + 1, r, p, val);
    tree[v] = max(tree[2 * v], tree[2 * v + 1]);
    sum[v] = sum[2 * v] + sum[2 * v + 1];
}

pair<int, int> query1(int v, int l, int r, int L, int R)
{
    if (r < L or R < l) return {-1, 0};
    if (L <= l and r <= R) return tree[v];

    int mid = (l + r) / 2;
    return max(query1(2 * v, l, mid, L, R), query1(2 * v + 1, mid + 1, r, L, R));
}

long long int query2(int v, int l, int r, int L, int R)
{
    if (r < L or R < l) return 0;
    if (L <= l and r <= R) return sum[v];

    int mid = (l + r) / 2;
    return (query2(2 * v, l, mid, L, R) + query2(2 * v + 1, mid + 1, r, L, R));
}

void initialise(int N, int Q, int H[])
{
    n = N;

    for (int i = 1; i <= n; ++ i)
    {
        h[i] = H[i];
    }

    build(1, 1, n);
}

void cut(int l, int r, int k)
{
    int le = 0, ri = 1000000000, mid;
    while (ri - le > 1)
    {
        mid = (le + ri) / 2;
        long long sum = 0;
        for (int i = l; i <= r; ++ i)
        {
            sum += max(0, h[i] - mid);
        }
        if (sum <= k) le = mid;
        else ri = mid;
    }

    long long sum = 0;
    for (int i = l; i <= r; ++ i)
    {
        if (le < h[i])
        {
            sum += h[i] - le;
            update(1, 1, n, i, le);
        }
    }

    k -= sum;

    for (int i = 1; i <= k; ++ i)
    {
        auto p = query1(1, 1, n, l, r);
        update(1, 1, n, -p.second, max(p.first - 1, 0));
    }
}

void magic(int i, int x)
{
    update(1, 1, n, i, x);
}

long long int inspect(int l, int r)
{
    return query2(1, 1, n, l, r);
}

/*
int main() {
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}*/
