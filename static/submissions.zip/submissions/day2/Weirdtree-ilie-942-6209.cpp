/**
* user:  ilie-942
* fname: Luca Mihai
* lname: Ilie
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:35:51.273243
*/
//#include "weirdtree.h"
#include <iostream>

using namespace std;

#define MAX_N 80000

int sumaH, N;
int v[MAX_N + 1];

struct nodAINT {
    int maxVal, maxPoz, sum;
};

struct AINT {
    nodAINT aint[4 * MAX_N];

    nodAINT join( nodAINT x, nodAINT y ) {
        nodAINT ans;

        if ( x.maxVal >= y.maxVal ) {
            ans.maxVal = x.maxVal;
            ans.maxPoz = x.maxPoz;
        } else {
            ans.maxVal = y.maxVal;
            ans.maxPoz = y.maxPoz;
        }
        ans.sum = x.sum + y.sum;

        return ans;
    }
    void init( int nod, int l, int r ) {
        int mid = (l + r) / 2;

        if ( l == r ) {
            aint[nod].maxVal = aint[nod].sum = v[l];
            aint[nod].maxPoz = l;
        } else {
            init( nod * 2 + 1, l, mid );
            init( nod * 2 + 1, mid + 1, r );
            aint[nod] = join( aint[nod * 2 + 1], aint[nod * 2 + 2] );
        }
    }
    void update( int nod, int l, int r, int p, int x ) {
        int mid = (l + r) / 2;

        if ( l <= p && p <= r ) {
            if ( l == r ) {
                aint[nod].maxVal = x;
                aint[nod].sum = x;
            } else {
                update( nod * 2 + 1, l, mid, p, x );
                update( nod * 2 + 2, mid + 1, r, p, x );
                aint[nod] = join( aint[nod * 2 + 1], aint[nod * 2 + 2] );
            }
        }
    }
    nodAINT query( int nod, int l, int r, int lq, int rq ) {
        int mid = (l + r) / 2;

        if ( lq <= l && r <= rq )
            return aint[nod];
        if ( l > r || lq > r || rq < l )
            return { -1, -1, -1 };
        return join( query( nod * 2 + 1, l, mid, lq, rq ), query( nod * 2 + 2, mid + 1, r, lq, rq ) );
    }
};

AINT padure;

void initialise(int n, int Q, int h[]) {
	int i;

    N = n;
    for ( i = 0; i <= n; i++ )
        v[i] = h[i];

    padure.init( 0, 1, n );

    sumaH = 0;
    for ( i = 1; i <= n; i++ )
        sumaH += h[i];
}
void cut(int l, int r, int k) {
	int p;

    sumaH = max( 0, sumaH - k );
    if ( k == 1 ) {
        p = padure.query( 0, 1, N, l, r ).maxPoz;
        if ( v[p] > 0 )
            v[p]--;
        padure.update( 0, 1, N, p, v[p] );
    }
}
void magic(int i, int x) {
	sumaH += x - v[i];
    v[i] = x;
    padure.update( 0, 1, N, i, v[i] );
}
long long int inspect(int l, int r) {
	if ( l == 1 && r == N )
        return sumaH;
    return padure.query( 0, 1, N, l, r ).sum;
}
