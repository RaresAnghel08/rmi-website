/**
* user:  stepanov-b9e
* fname: Anton
* lname: Stepanov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:17:30.523970
*/
#include "weirdtree.h"


#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <array>
#include <cassert>
#include <set>
#include <map>
#include <deque>
#include <random>


using namespace std;


#define ll long long
#define ld long double
#define flt double
#define pb push_back
#define emb emplace_back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()


const ll inf = 1e18;


struct SGT {
	struct node {
		ll x;
		int i;
		ll sm = 0;

		node() : x(-1), i(-1), sm(0) {}
		node(int i, ll x) : i(i), x(x), sm(x) {}

	};


	void mrg(const node n1, const node n2, node& res) {
		if (n1.x > n2.x || (n1.x == n2.x && n1.i < n2.i)) {
			res = n1;
		} else {
			res = n2;
		}
		res.sm = n1.sm + n2.sm;
	}


	int n;
	vector<node> t;


	void upd(int v) {
		mrg(t[v + v], t[v + v + 1], t[v]);
	}


	void build(vector<ll>& a) {
		n = 1;
		while (n < a.size()) {
			n *= 2;
		}
		t.assign(n + n, node());
		for (int i = 0; i < a.size(); ++i) {
			t[i + n] = node(i, a[i]);
		}
		for (int i = n - 1; i > 0; --i) {
			upd(i);
		}
	}


	void set(int i, ll x) {
		t[i + n] = node(i, x);
		i += n;
		for (i /= 2; i > 0; i /= 2) {
			upd(i);
		}
	}


	node get(int l, int r) {
		l += n;
		r += n;
		node res;
		while (l < r) {
			if (l & 1) {
				mrg(res, t[l], res);
				++l;
			}
			if (r & 1){
				--r;
				mrg(res, t[r], res);
			}
			l /= 2;
			r /= 2;
		}
		return res;
	}
};


int n, q;
SGT sgt;
vector<ll> a;


void initialise(int N, int Q, int h[]) {
	n = N;
	q = Q;
	a.resize(n);
	for (int i = 0; i < n; ++i) {
		a[i] = h[i + 1];
	}
	sgt.build(a);
}


void cut(int l, int r, int k) {
	l -= 1;
	for(int c = 0; c < k; ++c){
		int i = sgt.get(l, r).i;
		if (a[i] > 0) {
			a[i] -= 1;
			sgt.set(i, a[i]);
		}
	}
}


void magic(int i, int x) {
	i -= 1;
	a[i] = x;
	sgt.set(i, x);
}



ll inspect(int l, int r) {
	l -= 1;
	return sgt.get(l, r).sm;
}
