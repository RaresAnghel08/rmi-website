/**
* user:  mingazov-4fb
* fname: Artem
* lname: Mingazov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:29:31.083040
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
using namespace std;
int Size = 1, zero = 0;
vector <long long> tree_max, tree_sum;
long long merge_max(int A, int B) {
    return max(tree_max[A], tree_max[B]);
}
long long merge_sum(int A, int B) {
    return tree_sum[A] + tree_sum[B];
}
void initialise(int N, int Q, int h[]) {
    while (Size < N) {
        Size *= 2;
    }
    tree_max.assign(Size * 2 - 1, zero);
    tree_sum.assign(Size * 2 - 1, zero);
    for (int i = 1; i <= N; i++) {
        tree_max[i + Size - 1 - 1] = h[i];
        tree_sum[i + Size - 1 - 1] = h[i];
    }
    for (int i = Size - 2; i >= 0; i--) {
        tree_max[i] = merge_max(i * 2 + 1, i * 2 + 2);
        tree_sum[i] = merge_sum(i * 2 + 1, i * 2 + 2);
    }
}
long long find_max(int l, int r, int x, int lx, int rx) {
    if (r < lx || rx < l) {
        return zero;
    }
    if (l <= lx && rx <= r) {
        return tree_max[x];
    }
    int mx = (lx + rx) / 2;
    return max(find_max(l, r, x * 2 + 1, lx, mx), find_max(l, r, x * 2 + 2, mx + 1, rx));
}
int find(int MAX, int l, int r, int x, int lx, int rx) {
    if (r < lx || rx < l || tree_max[x] < MAX) {
        return -1;
    }
    if (lx == rx) {
        return lx;
    }
    int mx = (lx + rx) / 2, res = find(MAX, l, r, x * 2 + 1, lx, mx);
    if (res == -1) {
        res = find(MAX, l, r, x * 2 + 2, mx + 1, rx);
    }
    return res;
}
pair <long long, long long> find_elem(int MAX, int second_MAX, int l, int r, int k, int x, int lx, int rx) {
    if (r < lx || rx < l || tree_max[x] < MAX) {
        return make_pair(-1, -1);
    }
    if (lx == rx) {
        if (tree_max[x] == MAX) {
            int temp = 0;
            if (MAX != second_MAX) {
                temp = min(k, MAX - second_MAX);
            }
            else {
                temp = min(k, 1);
            }
            tree_max[x] -= temp;
            tree_sum[x] -= temp;
            return make_pair(lx, temp);
        }
        return make_pair(-1, -1);
    }
    int mx = (lx + rx) / 2;
    pair <int, int> res = find_elem(MAX, second_MAX, l, r, k, x * 2 + 1, lx, mx);
    if (res.first == -1) {
        res = find_elem(MAX, second_MAX, l, r, k, x * 2 + 2, mx + 1, rx);
    }
    tree_max[x] = merge_max(x * 2 + 1, x * 2 + 2);
    tree_sum[x] = merge_sum(x * 2 + 1, x * 2 + 2);
    return res;
}
void Sset(int i, int v, int x, int lx, int rx) {
    if (lx == rx) {
        tree_max[x] = v;
        tree_sum[x] = v;
        return;
    }
    int mx = (lx + rx) / 2;
    if (i <= mx) {
        Sset(i, v, x * 2 + 1, lx, mx);
    }
    else {
        Sset(i, v, x * 2 + 2, mx + 1, rx);
    }
    tree_max[x] = merge_max(x * 2 + 1, x * 2 + 2);
    tree_sum[x] = merge_sum(x * 2 + 1, x * 2 + 2);
}
void magic(int i, int x) {
    Sset(i - 1, x, 0, 0, Size - 1);
}
void cut(int l, int r, int k) {
    while (k) {
        long long MAX = find_max(l - 1, r - 1, 0, 0, Size - 1), index_max = find(MAX, l - 1, r - 1, 0, 0, Size - 1);
        magic(index_max + 1, 0);
        long long Second_MAX = find_max(l - 1, r - 1, 0, 0, Size - 1);
        magic(index_max + 1, MAX);
        if (MAX) {
            pair<long long, long long> ans = find_elem(MAX, Second_MAX, l - 1, r - 1, k, 0, 0, Size - 1);
            k -= ans.second;
        }
        else {
            break;
        }
    }
}
long long sum(int l, int r, int x, int lx, int rx) {
    if (l <= lx && rx <= r) {
        return tree_sum[x];
    }
    if (r < lx || rx < l) {
        return zero;
    }
    int mx = (lx + rx) / 2;
    return sum(l, r, x * 2 + 1, lx, mx) + sum(l, r, x * 2 + 2, mx + 1, rx);
}
long long int inspect(int l, int r) {
    return sum(l - 1, r - 1, 0, 0, Size - 1);
}