/**
* user:  hecht-9cd
* fname: Yahli
* lname: Hecht
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:09:53.637156
*/
#include <iostream>
#include <vector>

using namespace std;
using ll = long long;
using pi = pair<ll, ll>;


ll dfs_solve(int root, const vector<vector<pi>> & adj, vector<int> & down, int par = 0){
    ll res = 0; 
    for (int i = 0; i < adj[root].size(); ++i) if (adj[root][i].first != par){
        ll now = adj[root][i].second + dfs_solve(adj[root][i].first, adj, down, root); 
        if (now >= res) res = now, down[root] = i; 
    }
    return res; 
}

void solve(int root, vector<vector<pi>> adj, int k, int n){
    ll res = 0; 
    vector<int> down(n + 1, -1); 
    while (k--){
        res += dfs_solve(root, adj, down); 
        
        int croot = root; 
        while (down[croot] != -1){
            adj[croot][down[croot]].second = 0;
            croot = adj[croot][down[croot]].first; 
        }
    }
    cout << res << "\n"; 
}


int main(){
    int n, k; cin >> n >> k;
    vector<vector<pi>> adj(n+1, vector<pi>()); 
    for (int i = 1; i < n; ++i){
        ll x, y, c; cin >> x >> y >> c;
        adj[x].push_back(pi(y, c));
        adj[y].push_back(pi(x, c));
    }

    for (int i = 1; i <= n; ++i){
        solve(i, adj, k, n); 
    }
}