/**
* user:  erdim-fbd
* fname: Yasmin Behich
* lname: Erdim
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 08:07:25.324087
*/
#include "weirdtree.h"

int a[300001], n;

void initialise(int N, int Q, int h[]) {
	int i;
	n = N;
	for(i=1;i<=N;i++) a[i] = h[i];
}
void cut(int l, int r, int k) {
	int i, j;
	for(i=1;i<=k;i++) {
		int maxx = 0, pos;
		for(j=l;j<=r;j++) {
			if(maxx < a[j]) maxx = a[j], pos = j;
		}
		if(maxx != 0) a[pos]--;
	}

}
void magic(int i, int x) {
	a[i] = x;
}
long long int inspect(int l, int r) {
	long long sum = 0;
	int i;
	for(i=l;i<=r;i++) sum+= a[i];

	return sum;
}
