/**
* user:  vassilev-392
* fname: Yoan Rumenov
* lname: Vassilev
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:03:22.682800
*/
#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
using namespace std;
long long fl[10],n,a[20],m,br;
void fff(int d){
    if(d==2*n){
        bool fll=true;
        for(int i=0;i<2*n-1;i++){
            for(int j=i+1;j<2*n;j++)if(a[i]==a[j] && (j-i)%m==0)fll=false;
        }
        if(fl){
            //for(int i=0;i<2*n;i++)cout<<a[i]<<" "; cout<<endl;
            br++;
        }
        return;
    }
    for(int i=1;i<=n;i++){
        if(fl[i]!=2){
            fl[i]++; a[d]=i; fff(d+1); fl[i]--;
        }
    }

}
int main(){
    int i,j;
    cin>>n>>m;
    fff(0);
    cout<<br<<endl;
    return 0;
}
/*

*/
