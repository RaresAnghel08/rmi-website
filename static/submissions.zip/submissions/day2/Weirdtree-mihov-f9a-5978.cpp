/**
* user:  mihov-f9a
* fname: Boris Vladimirov
* lname: Mihov
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 10:16:10.291144
*/
#include "weirdtree.h"
#include <iostream>
#include <algorithm>
using namespace std;
const int maxn = 3e5+10;
typedef long long llong;
llong a[maxn], n;

llong cmp(llong x, llong y) {

    if (a[x] > a[y]) return x;
    return y;

}

llong tree[4*maxn];
llong tree_sum[4*maxn];
void init(llong l, llong r, llong node) {

    if (l == r) {

        tree[node] = l;
        tree_sum[node] = a[l];
        return;

    }

    llong mid = (l+r)/2;
    init(l, mid, 2*node);
    init(mid+1, r, 2*node+1);

    tree[node] = cmp(tree[2*node], tree[2*node+1]);
    tree_sum[node] = tree_sum[2*node] + tree_sum[2*node+1];

}

void update(llong l, llong r, llong node, llong query_ix, llong query_val) {

    if (l == r) {

        a[tree[node]] = query_val;
        tree_sum[node] = query_val;
        return;

    }

    llong mid = (l+r)/2;
    if (query_ix <= mid) update(l, mid, 2*node, query_ix, query_val);
    else update(mid+1, r, 2*node+1, query_ix, query_val);

    tree[node] = cmp(tree[2*node], tree[2*node+1]);
    tree_sum[node] = tree_sum[2*node] + tree_sum[2*node+1];

}

llong query_max(llong l, llong r, llong node, llong query_l, llong query_r) {

	if (query_l <= l && r <= query_r) return tree[node];

	llong mid = (l+r)/2;
	llong ans = 0;
	if (query_l <= mid) ans = cmp(ans, query_max(l, mid, 2*node, query_l, query_r));
	if (mid+1 <= query_r) ans = cmp(ans, query_max(mid+1, r, 2*node+1, query_l, query_r));

	return ans;

}

llong query_sum(llong l, llong r, llong node, llong query_l, llong query_r) {

	if (query_l <= l && r <= query_r) return tree_sum[node];

	llong mid = (l+r)/2;
	llong ans = 0;
	if (query_l <= mid) ans += query_sum(l, mid, 2*node, query_l, query_r);
	if (mid+1 <= query_r) ans += query_sum(mid+1, r, 2*node+1, query_l, query_r);

	return ans;

}


void initialise(int N, int Q, int h[]) {
	// Your code here.
	a[0] = -1;
    n = N;
    for (llong i = 1 ; i <= n ; ++i)
		a[i] = h[i];

    init(1, n, 1);

}

void cut(int l, int r, int k) {

    llong maximum = query_max(1, n, 1, l, r);
    if (a[maximum] == 0) return;
    update(1, n, 1, maximum, a[maximum]-1);

}

void magic(int i, int x) {
	
    update(1, n, 1, i, x);

}
long long int inspect(int l, int r) {
	
    return query_sum(1, n, 1, l, r);

}
