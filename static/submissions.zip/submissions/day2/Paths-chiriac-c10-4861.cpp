/**
* user:  chiriac-c10
* fname: Matei
* lname: Chiriac
* task:  Paths
* score: 36.0
* date:  2021-12-17 08:40:44.062821
*/
#include <bits/stdc++.h>

using namespace std;

struct segS
{
    long long lazy;
    pair<long long, long long> dp;
};
struct nodS
{
    bool on;
    long long sum, par, st, dr;
    vector<pair<long long, long long>> v;
};

long long t,n,k;
vector<segS> seg;
nodS nod[100005];

void push(int p)
{
    ///left
    long long old = seg[2*p].lazy;
    seg[2*p].lazy = max(seg[2*p].lazy, seg[p].lazy);

    seg[2*p].dp.first += old - seg[2*p].lazy;


    ///right
    old = seg[2*p+1].lazy;
    seg[2*p+1].lazy = max(seg[2*p+1].lazy, seg[p].lazy);

    seg[2*p+1].dp.first += old - seg[2*p+1].lazy;
}

void putValue(int i, int st, int dr, int p, long long val, int id)
{
    if(st == dr)
    {
        seg[p].dp = {val, id};
        return;
    }

    int mij=(st+dr)/2;

    if(i <= mij)
        putValue(i, st, mij, 2*p, val, id);
    else
        putValue(i, mij+1, dr, 2*p+1, val, id);

    seg[p].dp = max(seg[2*p].dp, seg[2*p+1].dp);
}

void upd(int stt, int drt, int st, int dr, int p, long long val)
{
    if(stt == st && drt == dr)
    {
        long long old = seg[p].lazy;
        seg[p].lazy = max(seg[p].lazy, val);

        seg[p].dp.first += old - seg[p].lazy;
        return;
    }

    push(p);
    int mij=(st+dr)/2;

    if(drt <= mij)
        upd(stt, drt, st, mij, 2*p, val);
    else if(stt > mij)
        upd(stt, drt, mij+1, dr, 2*p+1, val);
    else
    {
        upd(stt, mij, st, mij, 2*p, val);
        upd(mij+1, drt, mij+1, dr, 2*p+1, val);
    }

    seg[p].dp = max(seg[2*p].dp, seg[2*p+1].dp);
}
pair<long long, long long> query()
{
    return seg[1].dp;
}

void dfs(int p, int par)
{
    nod[p].par = par;
    nod[p].st = 1e9;
    nod[p].dr = 0;

    for(auto it : nod[p].v)
    {
        if(it.first == par)
            continue;

        nod[it.first].sum = nod[p].sum + it.second;
        dfs(it.first, p);

        nod[p].st = min(nod[p].st, nod[it.first].st);
        nod[p].dr = max(nod[p].dr, nod[it.first].dr);
    }

    if(nod[p].v.size() == 1 && nod[p].v[0].first == par)
    {
        t++;
        nod[p].st=t;
        nod[p].dr=t;

        putValue(t, 1, n, 1, nod[p].sum, p);
    }
}

void turnOff(int p)
{
    //cout<<"inchid "<<p<<'\n';

    nod[p].on=false;
    upd(nod[p].st, nod[p].dr, 1, n, 1, nod[p].sum);
}

void afis(int st, int dr, int p)
{
    cout<<st<<' '<<dr<<' '<<seg[p].dp.first<<' '<<seg[p].dp.second<<' '<<seg[p].lazy<<'\n';

    if(st !=dr)
    {
        int mij=(st+dr)/2;
        afis(st, mij, 2*p);
        afis(mij+1, dr, 2*p+1);
    }

}

long long solve(int rad, int k)
{
    t=0;
    long long ans=0;
    seg.clear();
    seg.resize(4*n+4);

    for(int i=1;i<=n;i++)
    {
        nod[i].on = true;
        nod[i].sum = 0;
    }

    dfs(rad, 0);

    while(k)
    {
        k--;

        auto it = query();

        //cout<<it.first<<' '<<it.second<<'\n';

        ans += it.first;
        int id = it.second;

        vector<int> vOff;
        while(id && nod[id].on)
        {
            vOff.push_back(id);
            id=nod[id].par;
        }

        reverse(vOff.begin(), vOff.end());
        for(int it : vOff)
            turnOff(it);
    }

    return ans;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    cin>>n>>k;
    for(int i=1;i<n;i++)
    {
        long long x, y, cost;
        cin>>x>>y>>cost;

        nod[x].v.push_back({y, cost});
        nod[y].v.push_back({x, cost});
    }

    for(int i=1;i<=n;i++)
        cout<<solve(i, k)<<'\n';
    return 0;
}
