/**
* user:  taga-9e5
* fname: Ștefan
* lname: Țaga
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:54:16.402112
*/
#include <bits/stdc++.h>

using namespace std;
int frec[15],n,sol[30],m,sum;
void back1(int k )
{
    if (k>2*n)
    {
        int i;
        vector <int> fr[15];
        for (i=1;i<=2*n;i++)
        {
            fr[sol[i]].push_back(i);
        }
        int ok=1;
        for (i=1;i<=n;i++)
        {
            if (abs(fr[i][1]-fr[i][0])%m==0)
            {
                ok=0;
                break;
            }
        }
        sum=sum+ok;
    }
    else
    {
        for (int i=1;i<=n;i++)
        {
            if (frec[i]<2)
            {
                frec[i]++;
                sol[k]=i;
                back1(k+1);
                sol[k]=0;
                frec[i]--;
            }
        }
    }
}
int main()
{
    #ifdef HOME
    ifstream cin("date.in");
    ofstream cout("date.out");
    #endif // HOME
    cin>>n>>m;
    back1(1);
    cout<<sum;
    return 0;
}
