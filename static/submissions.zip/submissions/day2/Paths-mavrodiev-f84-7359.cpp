/**
* user:  mavrodiev-f84
* fname: Tsvetoslav Valentinov
* lname: Mavrodiev
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:52:31.546172
*/
#include<bits/stdc++.h>
#define pb push_back
#define ll long long
using namespace std;
struct edge{int to,w;};
int n,k;
vector<edge> v[100001];
ll sub_ans[100001];
ll ans[100001];
void dfs(int x,int p=0)
{
    ll ret=0;
    for(edge e:v[x])
    {
        if(e.to!=p)
        {
            dfs(e.to,x);
            ret=max(ret,sub_ans[e.to]+e.w);
        }
    }
    sub_ans[x]=ret;
}
void prop(int x,int p=0,ll leg=-1)
{
    ans[x]=sub_ans[x];
    multiset<ll, greater<ll> > ms;
    ms.insert(leg);
    for(edge e:v[x])
        if(e.to!=p) ms.insert(sub_ans[e.to]+e.w);
    for(edge e:v[x])
    {
        if(e.to!=p)
        {
            ll tmp=sub_ans[e.to]+e.w;
            ms.erase(tmp);
            ll path=(*ms.begin())+e.w;
            sub_ans[e.to]=max(sub_ans[x],path);
            //cout<<x<<" -> "<<e.to<<" "<<(*ms.begin())<<" "<<leg<<endl;
            prop(e.to,x,path);
            ms.insert(tmp);
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin>>n>>k;
    for(int i=1;i<n;i++)
    {
        int a,b,c;
        cin>>a>>b>>c;
        v[a].pb({b,c});
        v[b].pb({a,c});
    }
    dfs(1);
    prop(1);
    for(int i=1;i<=n;i++) cout<<ans[i]<<endl;
    return 0;
}
/**

11 1
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1

3 1
1 2 4
2 3 5

*/
