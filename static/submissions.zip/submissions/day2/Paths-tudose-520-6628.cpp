/**
* user:  tudose-520
* fname: Rareş Felix
* lname: Tudose
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:04:46.880179
*/
#include <bits/stdc++.h>
#define MN 3071

#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")



using namespace std;
int n, k;
typedef long long ll;
typedef pair<int, int> ii;
vector<ii> L[MN];


//namespace solutia1
vector<ll> DP[MN];

void unite(int a, int b) {
    int p1 = 0, p2 = 0;
    vector<ll> R;
    while(p1 < DP[a].size() - 1 && p2 < DP[b].size() - 1) {
        R.push_back(DP[a][p1] + DP[b][p2]);
        if(DP[b][p2 + 1] - DP[b][p2] > DP[a][p1 + 1] - DP[a][p1]) ++p2;
        else ++p1;
    }
    if(p1 != DP[a].size() - 1) for(; p1 < DP[a].size() && p1 + p2 <= k; ++p1) R.push_back(DP[a][p1] + DP[b][p2]);
    if(p2 != DP[b].size() - 1) for(; p2 < DP[b].size() && p1 + p2 <= k; ++p2) R.push_back(DP[a][p1] + DP[b][p2]);
    DP[a] = move(R);
    DP[b].clear();
}

void dfs(int u, int p) {
    set<ii> Copii;
    for(auto [it, w] : L[u]){
        if(it != p) {
            dfs(it, u);
            for(int i = 1; i < DP[it].size(); ++i) DP[it][i] += w;
            Copii.insert({DP[it].size(), it});
        }
    }
    DP[u].assign(2, 0);
    Copii.insert({DP[u].size(), u});
    while(Copii.size() > 1) {
        int c1, c2;
        c1 = Copii.begin() -> second;
        Copii.erase(Copii.begin());
        c2 = Copii.begin() -> second;
        Copii.erase(Copii.begin());
        if(c2 == u) swap(c2, c1);
        unite(c1, c2);
        Copii.insert({DP[c1].size(), c1});
    }
}

ll rez(int rad) {
    dfs(rad, -1);
    return DP[rad][k];
}
void solve1() {
    for(int i = 1; i <= n; ++i) cout << rez(i) << "\n";
}

void solve2() {

}

signed main() {
    cin.tie(0);
    ios_base::sync_with_stdio(0);
    cin >> n >> k;
    if(n > 2000) return 0;
    for(int i = 1, u, v, w; i < n; ++i) {
        cin >> u >> v >> w;
        L[u].push_back({v, w});
        L[v].push_back({u, w});
    }
    if(n <= 2000) solve1();
    else if(k == 1) solve2();
    else return 0;
    return 0;
}
///max 35 min - 68 p
