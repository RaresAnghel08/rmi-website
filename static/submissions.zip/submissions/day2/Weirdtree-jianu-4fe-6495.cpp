/**
* user:  jianu-4fe
* fname: Ioana
* lname: Jianu
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:56:21.227380
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
using namespace std;

const int NMAX = 3e5+5;
int v[NMAX], n;

long long sum = 0;

void initialise(int N, int q, int h[]) {
    n = N;
    for (int i = 1; i <= N; i++)
        v[i] = h[i];
}

void cut(int l, int r, int k) {
    for (int cont = 1; cont <= k; cont++) {
        int mx = -1;
        int poz = 0;
        for (int i = l; i <= r; i++)
            if (v[i] > mx) {
                mx = v[i];
                poz = i;
            }
        if (mx != 0) {
            v[poz]--;
        }
    }
}

void magic (int i, int x) {
    v[i] = x;
}


long long int inspect(int l, int r) {
    long long sum = 0;
    for (int i = l; i <= r; i++)
        sum += v[i];
    return sum;
}
/*
int main() {

    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int q, h[NMAX];
    cin >> n >> q;
    for (int i = 1; i <= n; i++)
        cin >> h[i];


    initialise(n, q, h);
    for (int i = 1; i <= q; i++) {
        int type;
        cin >> type;
        if (type == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        }
        else if (type == 2) {
            int j, x;
            cin >> j >> x;
            magic(j, x);
        }
        else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << "\n";
        }
    }

    return 0;
}
*/
