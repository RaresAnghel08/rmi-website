/**
* user:  iordache-732
* fname: Rares Mihai
* lname: Iordache
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:21:53.539945
*/
#include "weirdtree.h"
#include <algorithm>

using namespace std;

#define MAXN 300000
#define RADMAX 550

int q[RADMAX], rad;

long long aib[MAXN], l;

int v[MAXN];

int lsb(int x) {
    return x & -x;
}

void update(int pos, int val) {
    while ( pos <= l ) {
        aib[pos] += val;
        pos += lsb(pos);
    }
}

long long calcSumFromStart(int pos) {
    long long sum;

    sum = 0;
    while ( pos > 1 ) {
        sum += aib[pos];
        pos -= lsb(pos);
    }

    return sum;
}

long long calcSum(int l, int r) {
    return calcSumFromStart(r) - calcSumFromStart(l - 1);
}

int calcRad(int x) {
    int i;

    i = 1;
    while ( i * i <= x ) {
        i++;
    }

    return i - 1;
}

int findMax(int left, int right) {
    int minq, maxq, pos, posq, maxnr, max_in_q, i, ok;

    minq = left / rad + 1;
    if ( left % rad == 0 ) {
        minq--;
    }
    maxq = right / rad - 1;

    pos = posq = maxnr = max_in_q = -1;
    for ( i = left; i <= minq * rad && i <= right; i++ ) {
        if ( v[i] > maxnr ) {
            maxnr = v[i];
            pos = i;
        }
    }

    while ( minq <= maxq ) {
        if ( max_in_q < q[minq] ) {
            max_in_q = q[minq];
            posq = minq;
        }

        minq++;
    }

    ok = 0;
    for ( i = (maxq + 1) * rad; i <= right; i++ ) {
        if ( v[i] > maxnr ) {
            ok = 1;
            maxnr = v[i];
            pos = i;
        }
    }

    if ( maxnr < max_in_q || (max_in_q == maxnr && ok == 1) ) {
        return posq;
    }
    return pos + RADMAX;
}

void findMaxInq(int locq) {
    int i;

    q[locq] = 0;
    for ( i = locq * rad; i < (locq + 1) * rad; i++ ) {
        q[locq] = max(q[locq], v[i]);
    }
}

void initialise(int n, int qu, int h[]) {
    int i;

    rad = calcRad(n);
    l = n;

    for ( i = 1; i <= n; i++ ) {
        aib[i] += h[i];
        if ( i + lsb(i) <= n ) {
            aib[i + lsb(i)] += aib[i];
        }
        v[i - 1] = h[i];

        q[(i - 1) / rad] = max(q[(i - 1) / rad], h[i]);
    }
}

void cut(int l, int r, int k) {
    int pos_in_q, maxh, i;

    l--;
    r--;
    maxh = 1;
    while ( k > 0 && maxh != 0 ) {
        pos_in_q = findMax(l, r);

        if ( pos_in_q >= RADMAX ) {
            maxh = v[pos_in_q - RADMAX];
        } else {
            maxh = q[pos_in_q];
        }

        if ( maxh != 0 ) {
            if ( pos_in_q < RADMAX ) {
                i = pos_in_q * rad;
                while ( v[i] != maxh ) {
                    i++;
                }
            } else {
                i = pos_in_q - RADMAX;
            }

            v[i]--;
            findMaxInq(i / rad);
            update(i + 1, -1);
        }
        k--;
    }
}

void magic(int i, int x) {
    update(i, x - v[i - 1]);
    i--;
    v[i] = x;
    findMaxInq(i / rad);
}

long long int inspect(int l, int r){
    return calcSum(l, r);
}
