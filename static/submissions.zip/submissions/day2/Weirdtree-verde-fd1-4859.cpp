/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:40:27.410630
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast","unroll-loops")
#pragma GCC target("avx","avx2","fma")
#include "weirdtree.h"
using namespace std;
int v[300001],n,q;
long long aint[1200001];
pair <int,int> aint2[1200001];
void update(int nod,int a,int b,int poz,int val)
{
    if(a==b)
    {
        aint[nod]+=val;
        return;
    }
    int mid=(a+b)/2;
    if(poz<=mid)
        update(2*nod,a,mid,poz,val);
    else
        update(2*nod+1,mid+1,b,poz,val);
    aint[nod]=aint[2*nod]+aint[2*nod+1];

}
void updatemax(int nod,int a,int b,int poz,int val)
{
    if(a==b)
    {
        aint2[nod]= {val,a};
        return;
    }
    int mid=(a+b)/2;
    if(poz<=mid)
        updatemax(2*nod,a,mid,poz,val);
    else
        updatemax(2*nod+1,mid+1,b,poz,val);
    if(aint2[2*nod].first>=aint2[2*nod+1].first)
        aint2[nod]=aint2[2*nod];
    else
        aint2[nod]=aint2[2*nod+1];
}
int query(int nod,int a,int b,int ua,int ub)
{
    if(ua<=a&&b<=ub)
        return aint[nod];
    if(ua>b||a>ub)
        return 0;
    int mid=(a+b)/2;
    return query(2*nod,a,mid,ua,ub)+query(2*nod+1,mid+1,b,ua,ub);
}
int max1,ind;
void findmax(int nod,int a,int b,int ua,int ub)
{
    if(ua<=a&&b<=ub)
    {
        if(aint2[nod].first>max1)
        {
            max1=aint2[nod].first;
            ind=aint2[nod].second;
        }
        else if(aint2[nod].first==max1&&aint2[nod].second<ind)
            ind=aint2[nod].second;
        return;
    }
    if(ua>b||a>ub)
        return;
    int mid=(a+b)/2;
    if(ua<=mid)
        findmax(2*nod,a,mid,ua,ub);
    if(ub>mid)
        findmax(2*nod+1,mid+1,b,ua,ub);
}
void initialise ( int N, int Q, int h [])
{
    n=N;
    q=Q;
    for(int i=1; i<=n; i++)
    {
        v[i]=h[i];
        update(1,1,n,i,h[i]);
        updatemax(1,1,n,i,h[i]);
    }
}
void cut ( int l, int r, int k )
{
    for(int i=1; i<=k; i++)
    {
        max1=ind=-1;
        findmax(1,1,n,l,r);
        if(v[ind])
        {
            update(1,1,n,ind,-1);
            updatemax(1,1,n,ind,v[ind]-1);
            v[ind]--;
        }
        else
            break;
    }
}
void magic ( int i, int x )
{
    update(1,1,n,i,x-v[i]);
    updatemax(1,1,n,i,x);
    v[i]=x;
}
long long int inspect ( int l, int r )
{
    return query(1,1,n,l,r);
}
