/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  NoM
* score: 0.0
* date:  2021-12-17 07:30:32.147876
*/
#include <bits/stdc++.h>

using namespace std;

signed main(void) {
	int n, m;
	cin >> n >> m;
	vector <int> a;
	for(int i = 1; i <= n; i ++){
		a.push_back(i);
	}
	for(int i = 1; i <= n; i ++) {
		a.push_back(n + i);
	}
	int cnt = 0;
	do{
		vector <int> idx(n + 1);
		for(int i = 0; i < a.size(); i ++) {
			if(idx[a[i] % n] == 0) {
				idx[a[i]%n] = i + 1;
			}else if((abs(idx[a[i] % n]) - (i + 1) + 1) % m == 0){ 
				goto end;
			}
			
		}
		cnt ++;
		cnt %=( (int)1e9 + 7);
		end:;
		/*for(auto i : a) cout << i << " ";
		cout << endl;*/
	}while(next_permutation(a.begin(), a.end()));
	cout << cnt % ((int)1e9 + 7);
	return false;
}