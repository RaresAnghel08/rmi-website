/**
* user:  karimov-0d4
* fname: Renat Airatovich
* lname: Karimov
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:19:24.672957
*/
#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb emplace_back
#define ld long double

mt19937 rnd(51);

signed main()
{
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif // LOCAL
    int n, m;
    cin >> n >> m;
    vector<int> a(2 * n);
    for (int i = 0; i < 2 * n; i++){
        a[i] = i % n;
    }
    sort(a.begin(), a.end());
    int ans = 0;
    do{
        bool x = 1;
        for (int i = 0; i + m < 2 * n; i++){
            if (a[i] == a[i + m]){
                x = 0;
            }
        }
        ans += x;
    }while(next_permutation(a.begin(), a.end()));
    for (int i = 0; i < n; i++){
        ans *= 2;
    }
    cout << ans << endl;
    return 0;
}
