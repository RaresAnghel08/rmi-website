/**
* user:  markovich-b21
* fname: Vesselin Nikolaev
* lname: Markovich
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:21:24.734746
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
using namespace std;

int n;
long long a[300002];
long long sutr[1200002];
long long tree[1200002];

void buildtree(int v, int le, int ri)
{
    if(le==ri)
    {
        tree[v]=le;
        sutr[v]=a[le];
    }
    else
    {
        int mid=(le+ri)/2;
        buildtree(2*v, le, mid);
        buildtree(2*v+1, mid+1, ri);
        if(a[tree[2*v]]>=a[tree[2*v+1]]) tree[v]=tree[2*v];
        else tree[v]=tree[2*v+1];
        sutr[v]=sutr[2*v]+sutr[2*v+1];
    }
}

void update_max(int v, int le, int ri, int id)
{
    if(le>id || ri<id) return;
    if(le==ri) return;
    int mid=(le+ri)/2;
    update_max(2*v, le, mid, id);
    update_max(2*v+1, mid+1, ri, id);
    if(a[tree[2*v]]>=a[tree[2*v+1]]) tree[v]=tree[2*v];
    else tree[v]=tree[2*v+1];
}

void update_sum(int v, int le, int ri, int id, long long st)
{
    if(le>id || ri<id) return;
    if(le==ri) {sutr[v]+=st; return;}
    int mid=(le+ri)/2;
    update_sum(2*v, le, mid, id, st);
    update_sum(2*v+1, mid+1, ri, id, st);
    sutr[v]=sutr[2*v]+sutr[2*v+1];
}


long long query_sum(int v, int le, int ri, int be, int en)
{
    if(le>en || ri<be) return 0;
    if(be<=le && ri<=en) return sutr[v];
    int mid=(le+ri)/2;
    return query_sum(2*v, le, mid, be, en)+query_sum(2*v+1, mid+1, ri, be, en);
}

long long query_max(int v, int le, int ri, int be, int en)
{
    if(le>en || ri<be) return n+1;
    if(be<=le && ri<=en) return tree[v];
    int mid=(le+ri)/2;
    int v1=query_max(2*v, le, mid, be, en);
    int v2=query_max(2*v+1, mid+1, ri, be, en);
    if(a[v1]>=a[v2]) return v1;
    return v2;
}

void initialise(int N, int Q, int h[])
{
    n=N;
    for(int i=1; i<=n; i++) a[i]=h[i];
    buildtree(1, 1, n);
}

void cut(int l, int r, int k)
{
    if(k==1)
    {
        int v=query_max(1, 1, n, l, r);
        update_sum(1, 1, n, v, -1);
        a[v]--;
        update_max(1, 1, n, v);
    }
    else if(k>query_sum(1, 1, n, l, r))
    {
        for(int i=l; i<=r; i++)
        {
            update_sum(1, 1, n, i, -a[i]);
            a[i]=0;
            update_max(1, 1, n, i);
        }
    }
}

void magic(int i, int x)
{
    update_sum(1, 1, n, i, x-a[i]);
    a[i]=x;
    update_max(1, 1, n, i);
}

long long int inspect(int l, int r)
{
    return query_sum(1, 1, n, l, r);
}
