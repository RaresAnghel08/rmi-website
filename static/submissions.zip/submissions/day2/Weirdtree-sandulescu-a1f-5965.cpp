/**
* user:  sandulescu-a1f
* fname: Alexandru Nicolae
* lname: Săndulescu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:15:04.250071
*/
#include "weirdtree.h"


struct {
    int first;
    long long second;
} AB[300000 * 4 + 8];
int N;

inline int max(int a, int b) {
    if(a > b) return a;
    return b;
}

void mymagic(int i, int x, int st, int dr, int nod = 1) {
    if(st == dr)
    {
        AB[nod].first = AB[nod].second = x;
        return;
    }
    int mij = (st + dr) / 2;
    if(i <= mij)
        mymagic(i, x, st, mij, nod * 2);
    else
        mymagic(i, x, mij + 1, dr, nod * 2 + 1);

    AB[nod].first = max(AB[nod * 2].first, AB[nod * 2 + 1].first);
    AB[nod].second = AB[nod * 2].second + AB[nod * 2 + 1].second;

}


long long myquerysum(int a, int b, int st, int dr, int nod = 1) {
    if(a <= st && dr <= b)
        return AB[nod].second;
    int mij = (st + dr) / 2;
    long long res1 = 0, res2 = 0;
    if(a <= mij) res1 = myquerysum(a, b, st, mij, nod * 2);
    if(mij < b)  res2 = myquerysum(a, b, mij + 1, dr, nod * 2 + 1);
    return res1 + res2;
}

void mycut(int a, int b, int st, int dr, int nod = 1) {
    if(st == dr && a <= st && st <= b) {
        if(AB[nod].first)
        {
            AB[nod].first--;
            AB[nod].second--;
        }
        return;
    }

    int mij = (st + dr) / 2;
    long long res1 = -1, res2 = -1;
    if(a <= mij) res1 = AB[nod * 2].first;
    if(mij < b)  res2 = AB[nod * 2 + 1].first;
    if(res1 >= res2)
        mycut(a, b, st, mij, nod * 2);
    else
        mycut(a, b, mij + 1, dr, nod * 2 + 1);


    AB[nod].first = max(AB[nod * 2].first, AB[nod * 2 + 1].first);
    AB[nod].second = AB[nod * 2].second + AB[nod * 2 + 1].second;
}


void initialise(int pN, int Q, int h[]) {
    N = pN;

    for(int i = 1; i <= N; i++)
    {
        mymagic(i, h[i], 1, N);
    }
}
void cut(int l, int r, int k) {
	for(int i = 1; i <= k; i++)
        mycut(l, r, 1, N);

}
void magic(int i, int x) {
	mymagic(i, x, 1, N);
}
long long int inspect(int l, int r) {
	return myquerysum(l, r, 1, N);
}
