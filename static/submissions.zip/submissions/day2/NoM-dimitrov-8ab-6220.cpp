/**
* user:  dimitrov-8ab
* fname: Atanas
* lname: Dimitrov
* task:  NoM
* score: 34.0
* date:  2021-12-17 10:36:25.853132
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
#pragma GCC target("sse4")
using namespace std;
typedef long long ll;
#define endl "\n"
template<class T, class T2> bool chkmin(T &a, const T2 &b) {return (a > b) ? a = b, 1 : 0;}
template<class T, class T2> bool chkmax(T &a, const T2 &b) {return (a < b) ? a = b, 1 : 0;}
#ifndef LOCAL
#define cerr if(false)cerr
#endif // LOCAL

const ll mod = 1e9 + 7;

ll solve(ll n, ll m) {
    vector<int> perm;
    for(int i = 0; i < 2 * n; i ++) {
        perm.push_back(i);
    }
    ll cnt = 0;
    ll interesting = 0;
    do {
        int howm = 0;
        for(int i = 0; i < 2 * n; i ++) {
            for(int j = i + m; j < 2 * n; j += m) {
                if(abs(perm[i] - perm[j]) == n) {
                    howm ++;
                }
            }
        }
        if(howm == 0) {
            cnt ++;
        }
    } while(next_permutation(perm.begin(), perm.end()));
    return cnt;
}

const int MAX_N = 2e3 + 10;
ll pw[MAX_N];
ll perm[MAX_N];
ll dp[MAX_N][MAX_N / 2];
ll arr[MAX_N];
ll invp[MAX_N];

ll fpow(ll x, ll p) {
    if(p == 0) {
        return 1;
    }
    ll ans = fpow(x, p / 2);
    ans = (ans * ans) % mod;
    if(p & 1) {
        return (ans * x) % mod;
    } else {
        return ans;
    }
}

ll comb(ll n, ll m) {
    return perm[n] * invp[m] % mod * invp[n - m] % mod;
}

ll var(ll n, ll m) {
    return perm[n] * invp[n - m] % mod % mod;
}

int n, m;

signed main() {
#ifndef LOCAL
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#endif
    perm[0] = invp[0] = pw[0] = 1;
    for(ll i = 1; i < MAX_N; i ++) {
        perm[i] = (perm[i - 1] * i) % mod;
        invp[i] = fpow(perm[i], mod - 2);
        pw[i] = (pw[i - 1] * 2ll) % mod;
    }

    cin >> n >> m;
    ll sz = (2 * n + m - 1) / m;
    for(int i = 1; i <= m; i ++) {
        if(i * sz + (m -  i) * (sz - 1) <= 2 * n) {
            arr[i - 1] = sz;
        } else {
            arr[i - 1] = sz - 1;
        }
    }

    dp[0][0] = 1;
    for(int i = 0; i < m; i ++) {
        for(int start = 0; start <= 2 * n; start ++) {
            for(int open = 0; open <= arr[i]; open ++) {
                if(start >= arr[i] - open) {
                    dp[i + 1][start - arr[i] + 2 * open] += dp[i][start] * comb(arr[i], open) % mod * var(start, arr[i] - open) % mod;
                    dp[i + 1][start - arr[i] + 2 * open] %= mod;
                }
            }
        }
    }

    cout << (dp[m][0] * pw[n] % mod * perm[n]) % mod << endl;

    return 0;
}

