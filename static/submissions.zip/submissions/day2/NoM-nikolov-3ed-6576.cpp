/**
* user:  nikolov-3ed
* fname: Zdravko Svetlozarov
* lname: Nikolov
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:01:28.031040
*/
#include <bits/stdc++.h>

using namespace std;
int n,m;
int garden[4001];
void read()
{
    cin>>n>>m;
}
void solve()
{
    read();
    for(int i=1;i<=m;i++)
    {
        garden[i]=n;
    }
    for(int i=m+1;i<=2*n;i++)
    {
        garden[i]=garden[i-m]-1;
    }
    unsigned long long poss=1;
    for(int i=1;i<=2*n;i++)
    {
        poss=poss*(unsigned long long)(garden[i]);
    }
    cout<<poss<<endl;
}
int main()
{
	solve();
    return 0;
}
