/**
* user:  ardelean-f07
* fname: Alexandru Petru
* lname: Ardelean
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:03:24.688916
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

using namespace std;

const int N = 3e5 + 7;

namespace SGT {
    struct Node {
        long long sum;
        pair < int, int > maxim;
//        int lazy;
    } t[4 * N];

    int n, l, r, x, poz;

    void propaga(int nod, int st, int dr) {
        if (st == dr) {
//            t[nod].lazy = 0;
            return;
        }
        return;
    }

    void add(int nod = 1, int st = 1, int dr = n) {
        if (st == poz && dr == poz) {
            t[nod] = {x, {x, -poz}};
            return;
        }
        propaga(nod, st, dr);
        int mij((st + dr) >> 1);
        if (poz <= mij)
            add(nod << 1, st, mij);
        else
            add((nod << 1) + 1, mij + 1, dr);
        t[nod] = {t[nod << 1].sum + t[(nod << 1) + 1].sum, max(t[nod << 1].maxim, t[(nod << 1) + 1].maxim)};
    }

    pair < int, int > find_max(int nod = 1, int st = 1, int dr = n) {
        if (l <= st && dr <= r)
            return t[nod].maxim;
        propaga(nod, st, dr);
        int mij((st + dr) >> 1);
        pair < int, int > ans;
        if (l <= mij)
            ans = max(ans, find_max(nod << 1, st, mij));
        if (r > mij)
            ans = max(ans, find_max((nod << 1) + 1, mij + 1, dr));
        return ans;
    }

    long long find_sum(int nod = 1, int st = 1, int dr = n) {
        if (l <= st && dr <= r)
            return t[nod].sum;
        propaga(nod, st, dr);
        int mij((st + dr) >> 1);
        long long ans(0);
        if (l <= mij)
            ans += find_sum(nod << 1, st, mij);
        if (r > mij)
            ans += find_sum((nod << 1) + 1, mij + 1, dr);
        return ans;
    }
}

void initialise(int n, int q, int h[]) {
    SGT::n = n;
    for (int i = 1; i <= n; ++i) {
        SGT::poz = i;
        SGT::x = h[i];
        SGT::add();
    }
}

void cut(int l, int r, int k) {
    SGT::l = l;
    SGT::r = r;
    tie(SGT::x, SGT::poz) = SGT::find_max();
    SGT::x--;
    SGT::poz = -SGT::poz;
    SGT::add();
}

void magic(int i, int x) {
    tie(SGT::x, SGT::poz) = make_tuple(x, i);
    SGT::add();
}

long long int inspect(int l, int r) {
    SGT::l = l;
    SGT::r = r;
	return SGT::find_sum();
}
