/**
* user:  mavrodiev-f84
* fname: Tsvetoslav Valentinov
* lname: Mavrodiev
* task:  Paths
* score: 56.0
* date:  2021-12-17 08:55:57.687035
*/
#include<bits/stdc++.h>
#define pb push_back
#define ll long long
using namespace std;
struct edge{int to,w;};
int n,k;
vector<edge> v[2048];
vector<ll> sub_ans[2048];
ll ans[2048];
vector<ll> merge(vector<ll> a,vector<ll> b)
{
    vector<ll> c; int p=0,q=0;
    while(p<a.size()&&q<b.size())
    {
        if(a[p]<b[q]) c.pb(b[q++]);
        else c.pb(a[p++]);
    }
    while(p<a.size()) c.pb(a[p++]);
    while(q<b.size()) c.pb(b[q++]);
    return c;
}
vector<ll> unmerge(vector<ll> a,vector<ll> b)
{
    vector<ll> c; int p=0,q=0;
    while(p<a.size())
    {
        if(q<b.size()&&a[p]==b[q]) q++;
        else c.pb(a[p]);
        p++;
    }
    if(!c.size()) return {0};
    return c;
}
vector<ll> dfs(int x,int p=0)
{
    vector<ll> ret;
    for(edge e:v[x])
    {
        if(e.to!=p)
        {
            vector<ll> tmp=dfs(e.to,x);
            tmp[0]+=e.w;
            ret=merge(ret,tmp);
        }
    }
    if(!ret.size()) return sub_ans[x]={0};
    return sub_ans[x]=ret;
}
ll get_ans(int x)
{
    ll a=0;
    for(int i=0;i<k&&i<sub_ans[x].size();i++) a+=sub_ans[x][i];
    return a;
}
void prnt(int x)
{
    cout<<x<<": ";
    for(ll i:sub_ans[x]) cout<<i<<" "; cout<<endl;
}
void prop(int x,int p=0)
{
    ans[x]=get_ans(x);
    //prnt(x);
    for(edge e:v[x])
    {
        if(e.to!=p)
        {
            vector<ll> a=sub_ans[x];
            sub_ans[e.to][0]+=e.w;
            a=unmerge(a,sub_ans[e.to]);
            a[0]+=e.w;
            sub_ans[e.to][0]-=e.w;
            sub_ans[e.to]=merge(a,sub_ans[e.to]);
            prop(e.to,x);
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin>>n>>k;
    for(int i=1;i<n;i++)
    {
        int a,b,c;
        cin>>a>>b>>c;
        v[a].pb({b,c});
        v[b].pb({a,c});
    }
    dfs(1);
    prop(1);
    for(int i=1;i<=n;i++) cout<<ans[i]<<endl;
    return 0;
}
/**

11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1

3 1
1 2 4
2 3 5

*/
