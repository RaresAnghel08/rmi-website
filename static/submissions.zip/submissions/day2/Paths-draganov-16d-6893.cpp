/**
* user:  draganov-16d
* fname: Krastan Asenov
* lname: Draganov
* task:  Paths
* score: 48.0
* date:  2021-12-17 11:23:15.222433
*/
#include <iostream>
#include <vector>

#define endl '\n'

using namespace std;

const int MAXN = 1e5 + 3;
const int MAXK = 2e2 + 3;

struct Edge {
    int to;
    int64_t cost;

    Edge() : to(-1), cost(0) {}
    Edge(int _to, int64_t _cost) : to(_to), cost(_cost) {}
};

vector<Edge> graph[MAXN];
int64_t dp_down[MAXN][MAXK];
int64_t dp_all[MAXN][MAXK];
int subtree_size[MAXN];

void dfs_subtree(int currv, int parent, int k) {
    subtree_size[currv] = 1;
    dp_down[currv][0] = dp_down[currv][1] = 0;

    vector<Edge> children;
    for (Edge& nextv : graph[currv]) {
        if (nextv.to == parent) {
            continue;
        }

        dfs_subtree(nextv.to, currv, k);
        subtree_size[currv] += subtree_size[nextv.to];

        children.push_back(nextv);
    }

    bool is_leaf = children.empty();
    if (is_leaf) {
        return;
    }

    for (auto &[child, cost] : children) {
        for (int total_picked = min(k, subtree_size[currv]); total_picked >= 1; --total_picked) {
            for (int picked_below = 1; picked_below <= min(total_picked, subtree_size[child]); ++picked_below) {
                dp_down[currv][total_picked] = max(dp_down[currv][total_picked],
                                              dp_down[child][picked_below] + cost + dp_down[currv][total_picked - picked_below]);
            }
        }
    }
}

void dfs_all(int currv, int parent, int64_t edge_up_cost, vector<int64_t>& dp_up, int k) {
    for (int picked = 0; picked <= k; ++picked) {
        dp_all[currv][picked] = dp_down[currv][picked];
    }

    for (int total_picked = k; total_picked >= 1; --total_picked) {
        for (int picked_up = 1; picked_up <= total_picked; ++picked_up) {
            dp_all[currv][total_picked] = max(dp_all[currv][total_picked],
                                          dp_up[picked_up] + edge_up_cost + dp_down[currv][total_picked - picked_up]);
        }
    }

    vector<Edge> children;
    for (Edge& nextv : graph[currv]) {
        if (nextv.to == parent) {
            continue;
        }

        children.push_back(nextv);
    }

    bool is_leaf = children.empty();
    if (is_leaf) {
        return;
    }

    int children_size = (int) children.size();

    vector<vector<int64_t>> dp_left(children_size, vector<int64_t>(k + 1, 0));
    for (int i = 1; i <= k; ++i) {
        dp_left[0][i] = dp_up[i] + edge_up_cost;
    }
    for (int i = 0; i < children_size - 1; ++i) {
        int child = children[i].to;
        int64_t cost = children[i].cost;

        for (int total_picked = k; total_picked >= 1; --total_picked) {
            dp_left[i + 1][total_picked] = dp_left[i][total_picked];
            for (int prev_picked = 1; prev_picked <= total_picked; ++prev_picked) {
                dp_left[i + 1][total_picked] = max(dp_left[i + 1][total_picked],
                                                   dp_down[child][prev_picked] + cost + dp_left[i][total_picked - prev_picked]);
            }
        }
    }

    vector<vector<int64_t>> dp_right(children_size, vector<int64_t>(k + 1, 0));
    for (int i = children_size - 1; i > 0; --i) {
        int child = children[i].to;
        int64_t cost = children[i].cost;

        for (int total_picked = k; total_picked >= 1; --total_picked) {
            dp_right[i - 1][total_picked] = dp_right[i][total_picked];
            for (int prev_picked = 1; prev_picked <= total_picked; ++prev_picked) {
                dp_right[i - 1][total_picked] = max(dp_right[i - 1][total_picked],
                                                   dp_down[child][prev_picked] + cost + dp_right[i][total_picked - prev_picked]);
            }
        }
    }

    /*if (currv == 0) {
        for (int i = children_size - 1; i >= 0; --i) {
            int child = children[i].to;
            int64_t cost = children[i].cost;

            cout << child << " " << cost << endl;
            //for (int )
        }
    }*/

    for (int i = 0; i < children_size; ++i) {
        vector<int64_t> new_dp(k + 1, 0);
        for (int picked = 0; picked <= k; ++picked) {
            for (int picked_left = 0; picked_left <= picked; ++picked_left) {
                new_dp[picked] = max(new_dp[picked], dp_left[i][picked_left] + dp_right[i][picked - picked_left]);
            }
        }

        /*if (currv == 0) {
            cout << children[i].to << ": ";
            for (int i = 0; i <= k; ++i) {
                cout << new_dp[i] << " ";
            }
            cout << endl;
        }*/

        dfs_all(children[i].to, currv, children[i].cost, new_dp, k);
    }
}

void brute_force(int n, int k) {
    for (int currv = 0; currv < n; ++currv) {
        for (int i = 0; i < n; ++i) {
            subtree_size[i] = 0;
            for (int j = 0; j <= k; ++j) {
                dp_down[i][j] = 0;
            }
        }

        dfs_subtree(currv, -1, k);

        cout << dp_down[currv][k] << endl;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    for (int i = 1; i < n; ++i) {
        int from, to;
        int64_t cost;
        cin >> from >> to >> cost;

        --from;
        --to;

        graph[from].emplace_back(to, cost);
        graph[to].emplace_back(from, cost);
    }

    dfs_subtree(0, -1, k);

    vector<int64_t> dummy(k + 1, 0);
    dfs_all(0, -1, 0, dummy, k);

    for (int currv = 0; currv < n; ++currv) {
        cout << dp_all[currv][k] << endl;
    }

    /*for (int currv = 0; currv < n; ++currv) {
        cout << "For vertex " << currv + 1 << ":\n";
        for (int picked = 0; picked <= min(subtree_size[currv], k); ++picked) {
            cout << "#" << picked << " -> " << dp_down[currv][picked] << endl;
        }
    }*/
return 0;
}
