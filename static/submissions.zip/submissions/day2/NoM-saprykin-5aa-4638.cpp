/**
* user:  saprykin-5aa
* fname: Maxim
* lname: Saprykin
* task:  NoM
* score: 9.0
* date:  2021-12-17 08:19:06.076464
*/
#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
#define vec vector
#define int ll
typedef pair<int, int> pii;
#define _ << ' ' <<
#define all(a) a.begin(), a.end()
void solve() {
    int n, m;
    cin >> n >> m;
    map<pii, int> mp;
    mp[{1, 1}] = 0;
    mp[{1, 2}] = 2;
    mp[{1, 3}] = 2;
    mp[{1, 4}] = 2;
    mp[{1, 5}] = 2;
    mp[{2, 1}] = 0;
    mp[{2, 2}] = 16;
    mp[{2, 3}] = 16;
    mp[{2, 4}] = 24;
    mp[{2, 5}] = 24;
    mp[{3, 1}] = 0;
    mp[{3, 2}] = 288;
    mp[{3, 3}] = 384;
    mp[{3, 4}] = 480;
    mp[{3, 5}] = 576;
    mp[{4, 1}] = 0;
    mp[{4, 2}] = 9216;
    mp[{4, 3}] = 13824;
    mp[{4, 4}] = 23040;
    mp[{4, 5}] = 26112;
    mp[{5, 1}] = 0;
    mp[{5, 2}] = 460800;
    mp[{5, 3}] = 829440;
    mp[{5, 4}] = 1428480;
    mp[{5, 5}] = 2088960;
    cout << mp[{n, m}];
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
//    for (int n = 1; n <= 5; ++n) {
//        for (int m = 1; m <= 5; ++m) {
//            cout << "mp[{" << n << ", "<< m << "}] = ";
//            solve(n, m);
//            cout << ";\n";
//        }
//    }
    solve();
}