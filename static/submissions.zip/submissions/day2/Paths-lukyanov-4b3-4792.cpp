/**
* user:  lukyanov-4b3
* fname: Igor
* lname: Lukyanov
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:34:12.725151
*/
#include<bits/stdc++.h>
using namespace std;

const int NMAX=1000;
vector<pair<int,int>>g[NMAX+5];

vector<long long>dfs(int v,int k,int p=-1){
    vector<long long>res;
    res.push_back(0);
    for(auto edge:g[v]){
        int u=edge.first;
        int c=edge.second;
        if(u==p)continue;
        vector<long long>son=dfs(u,k,v);
        res.push_back(son[0]+c);
        for(int i=1;i<son.size()&&i<k;i++)res.push_back(son[i]);
    }
    sort(res.begin(),res.end(),greater<int>());
    while(res.size()>k)res.pop_back();
    return res;
}

signed main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int n,k;
    cin>>n>>k;
    for(int i=1;i<n;i++){
        int a,b,c;
        cin>>a>>b>>c;
        g[a].push_back(make_pair(b,c));
        g[b].push_back(make_pair(a,c));
    }
    for(int i=1;i<=n;i++){
        vector<long long>ans=dfs(i,n,-1);
        cout<<accumulate(ans.begin(),ans.begin()+k,0ll)<<"\n";
    }
}