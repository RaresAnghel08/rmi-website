/**
* user:  tirziu-3f9
* fname: Petre
* lname: Tirziu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 07:51:44.421370
*/
#include <iostream>
#include "weirdtree.h"
using namespace std;
long long aib[300005], aint[300005], v[300005];
int len;
void update(int x, int val)
{
    int i;
    for(i = x; i <= len; i += (i & -i))
        aib[i] += val;
}
long long query(int x)
{
    long long i, sum = 0;
    for(i = x; i >= 1; i -= (i & -i))
        sum += aib[i];
    return sum;
}
void initialise(int n, int q, int h[])
{
    int i;
    len = n;
    for(i = 1; i <= n; i++){
        update(i, h[i]);
        v[i] = h[i];
    }
}
long long int inspect(int l, int r)
{
    return query(r) - query(l - 1);
}
void magic(int i, int x)
{
    if(x >= v[i])
        update(i, x - v[i]);
    else
        update(i, v[i] - x);
    v[i] = x;
}
void cut(int l, int r, int k)
{
    for(int j = 1; j <= k; j++){
        long long maxx = 0, poz, i;
        for(i = l; i <= r; i++)
            if(v[i] > maxx){
                maxx = v[i];
                poz = i;
            }
        if(maxx > 0){
            update(poz, -1);
            v[poz] -= 1;
        }
        else
            break;
    }
}
