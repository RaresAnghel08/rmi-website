/**
* user:  nicola-f4a
* fname: Alexandra Mihaela
* lname: Nicola
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:36:24.193227
*/
#include <bits/stdc++.h>
#define DIM 100010
using namespace std;

vector <pair<int,int> > L[DIM];
long long sp[DIM],dp_down[DIM],dp_up[DIM];
int fth[DIM];
int n,x,y,cost,i,k;

void dfs (int nod, int tata){

    fth[nod] = tata;
    for (auto it : L[nod]){
        int vecin = it.first, cost = it.second;
        if (vecin != tata){
            sp[vecin] = sp[nod] + cost;
            dfs (vecin,nod);
        }
    }

    dp_down[nod] = sp[nod];
    for (auto it : L[nod]){
        int vecin = it.first;
        if (vecin != tata)
            dp_down[nod] = max (dp_down[nod],dp_down[vecin]);
    }

}

void dfs_up (int nod, int tata, int cost){

    if (nod != 1){

        dp_up[nod] = dp_up[tata] + cost;
        for (auto it : L[tata]){
            int vecin = it.first;
            if (vecin == fth[tata] || vecin == nod)
                continue;

            dp_up[nod] = max (dp_up[nod], cost + dp_down[vecin] - sp[tata]);
        }

    }

    for (auto it : L[nod]){
        int vecin = it.first;
        if (vecin != tata)
            dfs_up (vecin,nod,it.second);
    }

}

int main (){

    //ifstream cin ("date.in");
    //ofstream cout ("date.out");

    cin>>n>>k;
    for (i=1;i<n;i++){
        cin>>x>>y>>cost;
        L[x].push_back(make_pair(y,cost));
        L[y].push_back(make_pair(x,cost));
    }

    dfs (1,0);
    dfs_up (1,0,0);

    for (i=1;i<=n;i++)
        cout<<max(dp_up[i],dp_down[i] - sp[i])<<"\n";
        //cout<<dp_up[i] + dp_down[i] - sp[i]<<"\n";


    return 0;
}
