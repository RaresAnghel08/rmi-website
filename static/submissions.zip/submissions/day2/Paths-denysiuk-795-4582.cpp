/**
* user:  denysiuk-795
* fname: Vladyslav
* lname: Denysiuk
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:10:51.200791
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double ld;

#define endl '\n'
#define all(var) var.begin(),var.end()
#define mp make_pair

const int N = 1e5+7;

vector<pair<int,int> > G[N];
ll dp[N];

void dfs(int v,int par){
    dp[v] = 0;

    for(auto [to,w]:G[v]){
        if (to==par)
            continue;
        dfs(to,v);
        dp[v] = max(dp[v],dp[to]+w);
    }
}

ll ans[N];

void recalc(int v,int par){

    set<pair<ll,int> > S = {{0,v}};

    for(auto [to,w]:G[v]){
        S.insert({dp[to]+w,to});
    }

    ans[v] = S.rbegin()->first;

    for(auto [to,w]:G[v]){
        if (to==par)
            continue;
        if (S.rbegin()->second==to)
            dp[v] = prev(S.rbegin())->first;
        else dp[v] = S.rbegin()->first;
        recalc(to,v);
    }
}

void solve(){
    int n,k;
    cin>>n>>k;
    for(int i = 1;i<n;++i){
        int a,b,w;
        cin>>a>>b>>w;
        G[a].push_back({b,w});
        G[b].push_back({a,w});
    }
    dfs(1,1);
    recalc(1,1);
    for(int i = 1;i<=n;++i)
        cout<<ans[i]<<'\n';
    //cout<<endl;
}

signed main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin>>t;
    while(t--)
        solve();
}