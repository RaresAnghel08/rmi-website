/**
* user:  metehau-bba
* fname: Luca
* lname: Metehau
* task:  Paths
* score: 36.0
* date:  2021-12-17 11:23:58.164668
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
#define ll long long
#define ld long double
#define x first
#define y second
#define pii pair <int, int>

using namespace std;

int n, k, x, y, z;

vector <pii> g[100005];
ll dp[2005][2005];
int sz[100005], t[100005];

void dfs(int nod, int tata = 0) {
  for(int i = 0; i <= k; i++)
    dp[nod][i] = 0;

  sz[nod] = (g[nod].size() == 1 && tata);

  for(auto &i : g[nod]) {
    int fiu = i.x, cost = i.y;
    if(fiu == tata)
      continue;

    dfs(fiu, nod);

    sz[nod] += sz[fiu];

    for(int i = k; i >= 0; i--) {
      /*if(i && !dp[nod][i])
        continue;*/

      for(int j = min(sz[fiu], k - i); j >= 1; j--)
        dp[nod][i + j] = max(dp[nod][i + j], dp[nod][i] + dp[fiu][j] + cost);
    }
  }

  /*cout << "nod : " << nod << "\n";
  for(int i = 1; i <= k; i++)
    cout << dp[nod][i] << " ";
  cout << "\n";*/
}

struct S {
  int ind;
  ll sum;
};

bool marked[100005];
ll sum[100005];

ll cod(int a, int b) {
  return 1LL * (n + 1) * a + b;
}

int timer;

int fst[100005], lst[100005];
S aint[800005];
ll lazy[800005];

S max(S a, S b) {
  return (a.sum > b.sum ? a : b);
}

void propag(int nod, int st, int dr) {
  if(st != dr) {
    aint[2 * nod].sum += lazy[nod];
    aint[2 * nod + 1].sum += lazy[nod];
    lazy[2 * nod] += lazy[nod];
    lazy[2 * nod + 1] += lazy[nod];
  }
  lazy[nod] = 0;
}

void init(int nod, int st, int dr, int ind, ll val, int poz) {
  lazy[nod] = 0;

  if(st == dr) {
    aint[nod].ind = poz;
    aint[nod].sum = val;
    return;
  }

  int mid = (st + dr) >> 1;

  if(ind <= mid)
    init(2 * nod, st, mid, ind, val, poz);
  else
    init(2 * nod + 1, mid + 1, dr, ind, val, poz);

  aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}

void update(int nod, int st, int dr, int l, int r, ll val) {
  propag(nod, st, dr);

  if(l <= st && dr <= r) {
    aint[nod].sum += val;
    lazy[nod] += val;
    return;
  }

  int mid = (st + dr) >> 1;

  if(l <= mid)
    update(2 * nod, st, mid, l, r, val);
  if(mid < r)
    update(2 * nod + 1, mid + 1, dr, l, r, val);

  aint[nod] = max(aint[2 * nod], aint[2 * nod + 1]);
}

S query(int nod, int st, int dr, int l, int r) {
  propag(nod, st, dr);

  if(l <= st && dr <= r)
    return aint[nod];

  int mid = (st + dr) >> 1;
  S ans = {0, -(ll)1e18};

  if(l <= mid)
    ans = max(ans, query(2 * nod, st, mid, l, r));
  if(mid < r)
    ans = max(ans, query(2 * nod + 1, mid + 1, dr, l, r));

  return ans;
}

void build(int nod, int tata = 0) {
  t[nod] = tata;
  fst[nod] = ++timer;
  marked[nod] = 0;

  for(auto &i : g[nod]) {
    int fiu = i.x, cost = i.y;
    if(fiu == tata)
      continue;

    sum[fiu] = sum[nod] + cost;
    build(fiu, nod);
  }

  lst[nod] = timer;
  init(1, 1, n, fst[nod], sum[nod], nod);
}

int main() {
  cin >> n >> k;

  srand(time(0));
  //n = 2000, k = rand() % min(n, 1000) + 1;
  //cout << n << " " << k << "\n";

  for(int i = 1; i < n; i++) {
    cin >> x >> y >> z;
    //x = rand() % i + 1, y = i + 1, z = rand() % 10;
    //cout << x << " " << y << " " << z << "\n";
    g[x].push_back({y, z});
    g[y].push_back({x, z});
  }

  for(int i = 1; i <= n; i++) {
    sum[i] = 0;
    timer = 0;

    for(int j = 1; j <= 4 * n; j++)
      aint[j] = {0, 0}, lazy[j] = 0;

    build(i);

    ll ans = 0;

    for(int j = 1; j <= k; j++) {
      propag(1, 1, n);
      S p = aint[1];

      if(!p.sum)
        break;

      ans += p.sum;

      int nod = p.ind;
      while(nod != i && !marked[nod]) {
        update(1, 1, n, fst[nod], lst[nod], -sum[nod] + sum[t[nod]]);

        marked[nod] = 1;
        nod = t[nod];
      }
    }
    cout << ans << "\n";
    /*dfs(i);

    cout << dp[i][k] << "\n";
    assert(!dp[i][k] || ans == dp[i][k]);*/
  }
  return 0;
}
