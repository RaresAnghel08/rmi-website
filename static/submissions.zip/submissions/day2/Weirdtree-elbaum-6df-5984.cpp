/**
* user:  elbaum-6df
* fname: Eitan
* lname: Elbaum
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:16:30.917706
*/
#include "weirdtree.h"
#include <iostream>
#include<vector>
using namespace std;
//#define maxn (1<<10)
#define maxn (1<<19)
typedef long long ll;
ll n,q;
struct th{ll mx,mi,x,l,r;} st[2*maxn];
void up(ll ind, ll up){
    ll i = 2*(ind+maxn);
    while(i/=2){
        st[i].x += up;
        st[i].mx = max(st[2*i].mx,st[2*i +1].mx);
        st[i].mi = st[2*i +1].mi;
        if(st[2*i].mx >= st[2*i +1].mx) st[i].mi = st[2*i].mi;
    }
}
ll qu(ll ind, ll l, ll r){
    if(st[ind].l >=l && st[ind].r <=r) return st[ind].x;
    if(st[ind].l>r || st[ind].r<l) return 0;
    return qu(2*ind,l,r) + qu(2*ind +1,l,r);
}
ll q1(ll ind, ll l, ll r){
    if(st[ind].l >=l && st[ind].r <=r) return st[ind].mi;
    if(st[ind].l>r || st[ind].r<l) return -1;
    ll p1 = q1(2*ind,l,r),p2=q1(2*ind +1,l,r);
    if(p2 == -1 || (p1!=-1 && st[p1+maxn].x>st[p2+maxn].x)) return p1;
    return p2;
}
void initialise(int N, int Q, int h[]) {
	n=N; q=Q;
	for(ll i=maxn;i< 2*maxn;++i){
	    st[i].x= 0;
        if(i < maxn+n){ st[i].x=h[i+1-maxn];}
        st[i].l=st[i].r = i-maxn;
        st[i].mx=st[i].x;
        st[i].mi=0;
        st[i].mi=i-maxn;
    }
    for(ll i=maxn -1;i>0;--i){
        st[i].x=st[2*i].x+st[2*i +1].x;
        st[i].mx = max(st[2*i].mx,st[2*i +1].mx);
        st[i].mi = st[2*i +1].mi;
        if(st[2*i].mx >= st[2*i +1].mx) st[i].mi = st[2*i].mi;
        st[i].l=st[2*i].l;
        st[i].r=st[2*i +1].r;
    }
}
void cut(int l, int r, int k) {
	ll p = q1(1,l-1,r-1);
	if(p!=-1 && st[p].x) up(p,-1);
}
void magic(int i, int x) {
	up(i-1,x-st[i-1+maxn].x);
}
long long int inspect(int l, int r) {
	return qu(1,l-1,r-1);
}