/**
* user:  stoyanov-5d6
* fname: Boris Stoyanov
* lname: Stoyanov
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:57:33.160862
*/
#include<bits/stdc++.h>
using namespace std;
struct node
{
    long long v,w;
    node() {}
    node(long long _v, long long _w)
    {
        v=_v;
        w=_w;
    }
};
long long dist[2005];
vector<node> t[2005],r[2005];
long long ans[2005];
long long n,k;
long long used[2005],u[2005],par[2005];
void calcdist(long long s, vector<node> tree[2005], long long add, long long l)
{
    ///cout<<s<<' '<<add<<endl;
    u[s]=1;
    dist[s]=add;
    if(tree[s].size()==1 && s!=l)
    {
        return;
    }
    for(long long i=0; i<tree[s].size(); i++)
    {
        if(!u[tree[s][i].v])
        {
            par[tree[s][i].v]=s;
            calcdist(tree[s][i].v,tree,add+tree[s][i].w,tree[s][i].v);
        }
    }
}
long long dumo(long long s, vector<node> tree[2005], long long e)
{
    for(long long j=1; j<=n; j++)
    {
        for(long long i=0; i<t[j].size(); i++)
        {
            tree[j][i].w=r[j][i].w;
            ///cout<<r[j][i].w<<' ';
        }
        //cout<<endl;
    }
    ///cout<<s<<endl;
    long long sol=0;
    for(long long i=1; i<=n; i++)
    {
        u[i]=0;

    }
    par[s]=-1;

    for(long long i=0; i<k; i++)
    {
        memset(dist,0,sizeof(dist));
        memset(u,0,sizeof(u));
        calcdist(s,tree,0,s);
        ///calcdist(s,tree,0,s);
        long long mx=-2,ind=1;
        for(long long j=1; j<=n; j++)
        {
            if(dist[j]>mx)
            {
                mx=dist[j];

                ind=j;
            }///cout<<dist[j]<<' ';
        }
///cout<<endl;
        ///cout<<ind<<' ';
        sol+=mx;
        if(i==n)
        {
            break;
        }
        vector<int>p;
        p.push_back(ind);
        while(par[ind]!=-1)
        {
            p.push_back(par[ind]);
            ///cout<<"!"<<par[ind];
            ind=par[ind];
        }
        for(long long y=0; y<p.size()-1; y++)
        {
            for(long long j=0; j<tree[p[y+1]].size(); j++)
            {
                if(tree[p[y+1]][j].v==p[y])
                {
                    tree[p[y+1]][j].w=0;
                    break;
                }///cout<<p[y+1]<<' '<<tree[p[y+1]][j].v<<endl;break;}
            }
        }
        long long o=0;
    }
    ///cout<<endl;
    return sol;
}
void dfs(long long s,vector<node> tree[2005])
{
    if(used[s])return;
    used[s]=1;
    ans[s]=dumo(s,tree,tree[s][0].v);
    ///cout<<s<<endl;
    for(long long i = 0; i<t[s].size(); i++)
    {
        ///cout<<tree[s][i].v<<endl;
        if(!used[t[s][i].v])
        {
            dfs(t[s][i].v, tree);
        }

    }
}
int main()
{
    cin>>n>>k;
    for(long long i=0; i<n-1; i++)
    {
        long long x,y,w;
        cin>>x>>y>>w;
        t[x].push_back({y,w});
        t[y].push_back({x,w});
        r[x].push_back({y,w});
        r[y].push_back({x,w});
    }

    dfs(1,t);
    for(long long i=1; i<=n; i++)
    {
        cout<<ans[i]<<endl;
    }
}
