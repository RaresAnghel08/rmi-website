/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:50:41.880679
*/
#include <bits/stdc++.h>

#pragma GCC optimize("Ofast")
//#pragma GCC optimize("avx, avx2")

#define pii pair<int, long long>
#define pb push_back
#define f first
#define s second

using namespace std;

typedef long long ll;
typedef long double ld;

int n, m, used[5], pos[5];

int f(int it) {
    if (it == 2 * n) {
        return 1;
    }
    int sum = 0;
    for (int i = 0; i < n; i++) {
        if (used[i] == 0) {
            used[i] = 1;
            pos[i] = it;
            sum += f(it + 1);
            used[i] = 0;
            pos[i] = 0;
        } else {
            if ((it - pos[i] + 1) % m) {
                used[i] = 2;
                sum += f(it + 1);
                used[i] = 1;
            }
        }
    }
    return sum;
}

void solve() {
    cin >> n >> m;
    cout << f(0) << endl;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    solve();
}