/**
* user:  erdim-fbd
* fname: Yasmin Behich
* lname: Erdim
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:25:58.534234
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
int a[300001], n;
long long sum = 0;
struct Tel{
	int l, r;
	long long st;
};
Tel tree[800001];
int fl[800001];

void Build(int v) {
	if(tree[v].l == tree[v].r) {
		tree[v].st = a[tree[v].l];
		return;
	}
	tree[v*2].l = tree[v].l;
	tree[v*2].r = (tree[v].l+tree[v].r)/2;
	Build(2*v);
	tree[v*2+1].l = tree[2*v].r+1;
	tree[v*2+1].r = tree[v].r;
	Build(2*v+1);
	tree[v].st = tree[2*v].st + tree[2*v+1].st;
}

void Find(int v, int l, int r, int k) {
	if(tree[v].l > r || tree[v].r < l) return;

	if(fl[v] != 0) {
		tree[v].st-= fl[v];
		if(tree[v].st < 0) tree[v].st = 0;
	}

	if(tree[v].l >= l && tree[v].r <= r) {
		tree[v].st-=k;
		if(tree[v].st < 0) tree[v].st = 0;
		fl[2*v]+= k;
		fl[2*v+1]+= k;
	}
	else {
		Find(2*v, l, r, k);
		Find(2*v+1,l, r, k);
		tree[v].st = tree[2*v].st+tree[2*v+1].st;
	}
	//cout<<v<<" "<<tree[v].st<<endl;
}

void Sum(int v, int l, int r) {
	if(tree[v].l > r || tree[v].r < l) return;
	if(fl[v] != 0) {
		tree[v].st-= fl[v];
	}

	if(tree[v].l <= r && tree[v].r >= l) {
		sum+=tree[v].st;
	}
	else {
		Sum(2*v, l, r);
		Sum(2*v+1,l, r);
	}


}



void initialise(int N, int Q, int h[]) {
	int i;
	n = N;
	for(i=1;i<=N;i++) a[i] = h[i];
	tree[1].l = 1;
	tree[1].r = n;
	Build(1);
}
void cut(int l, int r, int k) {
    Find(1, l, r, k);
  /*  for(int i=1;i<=13;i++) {
    	cout<<tree[i].l<<" "<<tree[i].r<<"  "<<tree[i].st<<endl;
    }*/

}
void magic(int i, int x) {
	a[i] = x;
}
long long int inspect(int l, int r) {
	sum = 0;
	Sum(1, l , r);

	return sum;
}
