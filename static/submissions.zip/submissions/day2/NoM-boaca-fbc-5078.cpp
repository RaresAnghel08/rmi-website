/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  NoM
* score: 34.0
* date:  2021-12-17 08:59:27.435607
*/
#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;
typedef long long ll;
const ll mod=1e9+7;
ll n,m,dp[2005][2005],ans,fact[10005],invfact[10005],nr[10005];
ll pw(ll a, ll b)
{
    ll rez=1;
    while(b)
    {
        if(b&1)
            rez=(rez*a)%mod;
        b/=2;
        a=(a*a)%mod;
    }
    return rez;
}
ll inv(ll a)
{
    return pw(a,mod-2);
}
ll comb(ll a, ll b)
{
    if(a<b)
        return 0;
    ll rez=(fact[a]*invfact[b])%mod;
    rez=(rez*invfact[a-b])%mod;
    return rez;
}
ll aranj(ll a, ll b)
{
    ll rez=comb(a,b);
    rez=(rez*fact[b])%mod;
    return rez;
}
int main()
{
    fact[0]=invfact[0]=1;
    for(ll i=1;i<=10000;i++)
    {
        fact[i]=(fact[i-1]*i)%mod;
        invfact[i]=inv(fact[i])%mod;
    }
    cin>>n>>m;
    for(int i=1;i<=2*n;i++)
        nr[i%m+1]++;
    dp[0][0]=1;
    for(int i=1;i<=m;i++)
    {
        for(int tot=0;tot<=n;tot++)
            for(int cur=0;cur<=tot;cur++)
            {
                ll val=dp[i-1][tot-cur];
                ll x=aranj(nr[i],cur*2);
                val=(val*x)%mod;
                val=(val*comb(n-tot+cur,cur))%mod;
                dp[i][tot]=(dp[i][tot]+val)%mod;
            }
        //cout<<dp[i][0]<<' ';
    }
    for(int i=0;i<=n;i++)
    {
        ll val=(dp[m][i])%mod;
        val=(val*fact[2*n-2*i])%mod;
        if(i%2==1)
        {
            ans-=val;
            if(ans<0)
                ans+=mod;
        }
        else
            ans=(ans+val)%mod;
    }
    cout<<ans;
    return 0;
}
