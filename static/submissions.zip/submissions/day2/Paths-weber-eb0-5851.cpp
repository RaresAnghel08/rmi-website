/**
* user:  weber-eb0
* fname: Daniel
* lname: Weber
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:05:41.646035
*/
// #define _GLIBCXX_DEBUG
#include <bits/stdc++.h>
using namespace std;
#define ll int
#define vll vector<ll>
#define vvll vector<vector<long long>>

struct triple {
    long long a, b, c;
};

vector<vector<triple>> graph;
vvll dp;
int k;

void recurs(ll v, ll i) {
    dp[v][i] = 0;
    for (ll j = 0; j < graph[v].size(); j++) {
        if (j == i) continue;
        triple neigh = graph[v][j];
        if (dp[neigh.a][neigh.c]==-1)
            recurs(neigh.a, neigh.c);
        dp[v][i] = max(dp[v][i], neigh.b + dp[neigh.a][neigh.c]);
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    ll n;
    cin >> n >> k;
    graph.resize(n); // O(n)
    dp.resize(n); // O(n)
    for (ll i = 1; i < n; i++) {
        long long x, y, c;
        cin >> x >> y >> c;
        x--, y--;
        ll x_ind = graph[x].size();
        ll y_ind = graph[y].size();
        graph[x].push_back({y, c, y_ind});
        graph[y].push_back({x, c, x_ind});
    } // O(n)
    for (ll v = 0; v < n; v++) {
        dp[v].resize(graph[v].size()+1, -1); // O(n)
    }
    for (ll v = 0; v < n; v++) {
        for (ll i = 0; i <= graph[v].size(); i++) {
            if (dp[v][i] == -1)
                recurs(v, i); // O(n)
        }
        cout << dp[v][graph[v].size()] << '\n';
    }
}