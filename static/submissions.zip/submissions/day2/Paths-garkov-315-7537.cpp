/**
* user:  garkov-315
* fname: Velislav Petrov
* lname: Garkov
* task:  Paths
* score: 48.0
* date:  2021-12-17 11:58:21.627964
*/
#include <iostream>
#include <vector>
using namespace std;
#define endl '\n'
const int MAXN=1e5+10;
struct Node {
    long long maxs;
    int ind;
};
vector <pair <int,long long> > v[MAXN];
Node tree[4*MAXN];
long long lazy[4*MAXN];
long long sum[MAXN];
int lef[MAXN], ri[MAXN], par[MAXN];
int lis[MAXN], br;
long long res[MAXN];
pair <int, long long> path[MAXN];
int ss;
bool used[MAXN];
void build(int x) {
    used[x]=true;
    lef[x]=MAXN;
    ri[x]=-1;
    for (auto i:v[x]) {
        if (used[i.first]) continue;
        par[i.first]=x;
        sum[i.first]=sum[x]+i.second;
        build(i.first);
        lef[x]=min(lef[x],lef[i.first]);
        ri[x]=max(ri[x],ri[i.first]);
    }
    if (v[x].size()==1 && par[x]!=-1) {
        lis[br]=x;
        lef[x]=ri[x]=br;
        br++;
    }
}
void build_tree(int node, int l, int r) {
    lazy[node]=0;
    if (l==r) {
        ///cout << sum[lis[l]] << ' ' << lis[l] << endl;
        tree[node].maxs=sum[lis[l]];
        tree[node].ind=lis[l];
        return;
    }
    int mid=(l+r)/2;
    build_tree(node*2,l,mid);
    build_tree(node*2+1,mid+1,r);
    if (tree[node*2].maxs>=tree[node*2+1].maxs) tree[node]=tree[node*2];
    else tree[node]=tree[node*2+1];
}
void push_lazy(int node, int l, int r) {
    if (lazy[node]==0) return;
    if (l!=r) {
        if (tree[node*2].maxs-lazy[node]>=0) {
            tree[node*2].maxs-=lazy[node];
            lazy[node*2]+=lazy[node];
        }
        if (tree[node*2+1].maxs-lazy[node]>=0) {
            tree[node*2+1].maxs-=lazy[node];
            lazy[node*2+1]+=lazy[node];
        }
    }
    lazy[node]=0;
}
void update_interv(int node, int l, int r, int ql, int qr, long long ch) {
    if (l>qr || r<ql) return;
    push_lazy(node,l,r);
    if (l>=ql && r<=qr) {
        if (tree[node].maxs-ch>=0) {
            tree[node].maxs-=ch;
            lazy[node]+=ch;
        }
        return;
    }
    int mid=(l+r)/2;
    update_interv(node*2,l,mid,ql,qr,ch);
    update_interv(node*2+1,mid+1,r,ql,qr,ch);
    ///cout << node << ' ' << l << ' ' << r << ' ' << tree[node*2].maxs << ' ' << tree[node*2+1].maxs << endl;
    if (tree[node*2].maxs>=tree[node*2+1].maxs) tree[node]=tree[node*2];
    else tree[node]=tree[node*2+1];
}
void update_path(int x, long long cur, int p) {
    if (par[x]==-1) return;
    ///cout << lef[x] << ' ' << ri[x] << ' ' << lef[p] << ' ' << ri[p] << ' ' << cur << endl;
    if (p!=-1) {
        if (lef[x]<lef[p]) update_interv(1,0,br-1,lef[x],lef[p]-1,cur);
        if (ri[x]>ri[p]) update_interv(1,0,br-1,ri[p]+1,ri[x],cur);
    } else update_interv(1,0,br-1,lef[x],ri[x],cur);
    ///cout << tree[1].maxs << ' ' << tree[1].ind << endl;
    cur-=(sum[x]-sum[par[x]]);
    update_path(par[x],cur,x);
    par[x]=-1;
}
void find_path(int x) {
    ss=0;
    while (par[x]!=-1) {
        path[ss].first=x;
        path[ss].second=(sum[x]-sum[par[x]]);
        ss++;
        x=par[x];
    }
}
void dfs(int x) {
    used[x]=true;
    for (auto i:v[x]) {
        if (used[i.first]) continue;
        update_interv(1,0,br-1,lef[i.first],ri[i.first],i.second);
        if (lef[i.first]>0) update_interv(1,0,br-1,0,lef[i.first]-1,-i.second);
        if (ri[i.first]<br-1) update_interv(1,0,br-1,ri[i.first]+1,br-1,-i.second);
        dfs(i.first);
        update_interv(1,0,br-1,lef[i.first],ri[i.first],-i.second);
        if (lef[i.first]>0) update_interv(1,0,br-1,0,lef[i.first]-1,i.second);
        if (ri[i.first]<br-1) update_interv(1,0,br-1,ri[i.first]+1,br-1,i.second);
    }
    res[x]=tree[1].maxs;
}
int main () {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int n, k, a, b, c;
    cin >> n >> k;
    for (int i=0;i<n-1;i++) {
        cin >> a >> b >> c;
        v[a].push_back({b,c});
        v[b].push_back({a,c});
    }
    if (k>1) {
        long long ans, cur;
        int maxind;
        for (int i=1;i<=n;i++) {
            ans=0;
            for (int j=1;j<=n;j++) used[j]=false;
            par[i]=-1;
            sum[i]=0;
            br=0;
            build(i);
            build_tree(1,0,br-1);
            for (int j=0;j<min(br,k);j++) {
                cur=tree[1].maxs;
                maxind=tree[1].ind;
                if (j+1<min(br,k)) {
                    find_path(maxind);
                    for (int j=ss-1;j>=0;j--) {
                        update_interv(1,0,br-1,lef[path[j].first],ri[path[j].first],path[j].second);
                        par[path[j].first]=-1;
                    }
                }
                ans+=cur;
            }
            cout << ans << endl;
        }
    } else {
        sum[1]=0;
        par[1]=-1;
        br=0;
        build(1);
        build_tree(1,0,br-1);
        for (int i=1;i<=n;i++) used[i]=false;
        dfs(1);
        for (int i=1;i<=n;i++) cout << res[i] << endl;
    }
    return 0;
}
/**
11 1
11 1 2
11 2 1
2 3 5
2 4 6
11 5 10
5 7 5
5 8 7
7 10 2
11 6 1
6 9 6
**/
