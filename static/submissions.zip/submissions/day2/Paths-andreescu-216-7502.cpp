/**
* user:  andreescu-216
* fname: Mihnea
* lname: Andreescu
* task:  Paths
* score: 36.0
* date:  2021-12-17 11:57:29.860337
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;


const int N = 2000 + 7;
const ll INF = (ll) 1e18;
int n, k, sub[N];
ll dp[N][N], ndp[N];
vector<pair<int, int>> g[N];


void compute(int a, int p, ll topar) {
  sub[a] = 1;
  for (auto &it : g[a]) {
    int b = it.first;
    if (b == p) {
      continue;
    }
    sub[a] += sub[b];
  }
  int cur = 1;
  dp[a][cur] = 0;
  for (auto &it : g[a]) {
    int b = it.first;
    if (b == p) {
      continue;
    }
    int newcur = min(k, cur + sub[b]);
    int x = 0, y = 0;
    while (x + y < newcur) {
      if (x + 1 <= cur && y + 1 <= min(sub[b], k)) {
        if (dp[a][x + 1] + dp[b][y] > dp[a][x] + dp[b][y + 1]) {
          x++;
        } else {
          y++;
        }
      } else {
        if (x + 1 <= cur) {
          x++;
        } else {
          y++;
        }
      }
      ndp[x + y] = dp[a][x] + dp[b][y];
    }
    for (int j = 0; j <= newcur; j++) {
      dp[a][j] = ndp[j];
    }
    cur = newcur;
  }
  for (int j = 1; j <= cur; j++) {
    dp[a][j] += topar;
  }
}

void rer(int a, int b, int edge) {
  compute(a, b, edge);
  compute(b, -1, 0);
}

void dfs(int a, int p = -1, int topar = 0) {
  for (auto &it : g[a]) {
    int b = it.first;
    if (b == p) {
      continue;
    }
    dfs(b, a, it.second);
  }
  compute(a, p, topar);
}

ll memo[N];

void solve(int a, int p = -1) {
  memo[a] = dp[a][k];
  for (auto &it : g[a]) {
    int b = it.first;
    if (b != p) {
      rer(a, b, it.second);
      solve(b, a);
      rer(b, a, it.second);
    }
  }
}

mt19937 rng((long long) (new char));


signed main()  {
  ios::sync_with_stdio(0); cin.tie(0);

  //freopen ("input", "r", stdin);

  cin >> n >> k;
  for (int i = 1; i < n; i++) {
    int x, y, z;
    cin >> x >> y >> z;
    g[x].push_back({y, z});
    g[y].push_back({x, z});
  }
  int x = rng() % n + 1;
  dfs(x);
  solve(x);
  for (int i = 1; i <= n; i++) {
    cout << memo[i] << "\n";
  }

}
