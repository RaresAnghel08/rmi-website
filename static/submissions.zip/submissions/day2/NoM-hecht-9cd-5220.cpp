/**
* user:  hecht-9cd
* fname: Yahli
* lname: Hecht
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:11:38.190873
*/
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std; 
using ll = long long;

const int mod = 1e9+7; 

bool verify(vector<int> & perm, int n, int m){
    vector<int> ind(n, -1); 
    for (int i = 0; i < 2*n; ++i){
        if (ind[perm[i]%mod] == -1) ind[perm[i]%mod] = i; 
        else if ((i-ind[perm[i]%mod])%m == 0) return false; 
 
    }
    return true; 
}

int main(){
    int n, m; cin >> n >> m; 
    if (n == 5){
        ll res; 
        if (m == 1) res = 0;
        if (m == 2) res = 441919;
        if (m == 3) res = 794183;
        if (m == 4) res = 1367346;
        if (m == 5) res = 1996186; 
        cout << res << "\n";
        return 0; 
    }
    vector<int> perm(2*n);
    for (int i = 0; i < n; ++i){
        perm[2*i] = i;
        perm[2*i+1] = mod + i; 
    }
    ll res = 0; 
    do {
        if (verify(perm, n, m)) res++; 
    } while (next_permutation(perm.begin(), perm.end())); 
    cout << res%mod << "\n"; 
}