/**
* user:  levashkevich-aa5
* fname: Stanislau
* lname: Levashkevich
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:51:32.475765
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

using namespace std;
//#define fast ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
//#define endl '\n'
#define ff first
#define ss second
#define ll long long
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()

struct node {
    long long sum = 0;
    int mx = 0,pos = 2e9;
    int mx2 = 0;
};

const int MX = 3e5 + 7;

long long cur[MX];

int SZ = 0,n;

void initialise(int N, int Q, int h[]) { // Your code here.
    for(int i = 1; i <= N; ++i) {
        cur[i] = h[i];
    }
    SZ = N;
    n = N;
}
void cut(int l, int r, int k) { // Your code here.
    vector<pair<int,int>> tek;
    tek.reserve(r - l + 1);
    for(int i = l; i <= r; ++i) {
        tek.push_back({cur[i],i});
    }
    sort(rall(tek));
    set<int> id;
    for(int i = 0; i < tek.size(); ++i) {
        id.insert(tek[i].ss);
        while(i + 1 < tek.size() && tek[i].ff == tek[i + 1].ff)
            ++i,id.insert(tek[i].ss);
        int mn = tek[i].ff;
        if(i + 1 < tek.size())
            mn -= tek[i + 1].ff;
        if(mn * (i + 1) <= k) {
            k -= mn * (i + 1);
            for(int j : id) {
                cur[j] -= mn;
            }
            continue;
        }
        int vse = k / (i + 1),ost = k % (i + 1),was = 0;
        for(int j : id) {
            cur[j] -= vse;
            if(was < ost) cur[j]--;
            ++was;
        }
        break;
    }
}
void magic(int i, int x) { // Your code here.

}
long long inspect(int l, int r) { // Your code here.
    long long ans = 0;
    for(int i = l; i <= r; ++i) {
        ans += cur[i];
    }
    return ans;
}
/*
6 10
1 2 3 1 2 3
1 1 6 3
3 1 6
1 1 3 3
3 1 6
1 1 3 1000
3 1 6
2 1 1000
3 1 6
1 1 3 999
3 1 5
*/
