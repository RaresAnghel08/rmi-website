/**
* user:  taravskii-2e3
* fname: Denys
* lname: Taravskii
* task:  NoM
* score: 0.0
* date:  2021-12-17 07:21:31.088307
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll DIM = 2e3 + 7;

ll nt,n,m;

ll a[DIM],b[DIM],last[DIM];

void read(){
    cin>>n>>m;
}

bool check(){

    for(int i=1;i<=n;i++)last[i]=0;

    for(int i=1;i<=2*n;i++){
     b[i]=a[i];
     if(a[i]>n)b[i]-=n;
    }

    ll fl=0;

    for(int i=1;i<=2*n;i++){
     if(last[b[i]]==0){
      last[b[i]]=i;
      continue;
     }

     if((i-last[b[i]])%m==0){
      fl=1;
      break;
     }
    }

    /*cout<<fl<<endl;

    for(int i=1;i<=2*n;i++){
     cout<<a[i]<<' ';
    }

    cout<<endl;*/

    if(fl==1)return false;
    return true;
}

void solve(){

    read();

    ll c=0,res=0;

    for(int i=1;i<=2*n;i++)a[i]=i;

    if(check())res++;

    while(next_permutation(a+1,a+1+2*n)){
     if(check())res++;
    }

    cout<<res<<endl;

    return;
}

int main()
{

    ios_base::sync_with_stdio();
    cin.tie();
    cout.tie();

    //cin>>nt;

    nt=1;

    for(int t=1;t<=nt;t++){
     solve();
    }

    return 0;
}
