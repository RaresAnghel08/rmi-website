/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 11:51:34.554981
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)


using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int mxn = 100005;

#include "weirdtree.h"

int n;
ll H[mxn];


void initialise(int N, int Q, int h[]) {
	n = N;
	fr(i, 0 , N) H[i] = h[i];
	
	// Your code here.
}
void cut(int l, int r, int k) {
	
	int pos = l;
	ll mx = H[l];
	fr(i, l, r+1){
		if(H[i] > mx){
			mx = H[i];
			pos = i;
		}
	}
	H[pos] = max(H[pos]-1, 0LL);
	
	
	
	// Your code here.
}
void magic(int i, int x) {
	H[i] = x;
	// Your code here.
}
long long int inspect(int l, int r) {
	
	ll sum = 0;
	fr(i, l, r+1){
		sum += H[i];
	}
	// Your code here.
	return sum;
}

