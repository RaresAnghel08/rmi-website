/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:22:38.312390
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
const int N=300100;
int n,q;
int h[N];

ll sum[N*4];
int w[N*4];
map<int,int>cnt[N*4];
struct ret{
    int mx,mx2,cnt;
    ret(){
        mx=mx2=cnt=0;
    }
};
ret Merge(ret A,ret B){
    ret C;
    if (A.mx==B.mx){
        C.mx=A.mx;
        C.cnt=A.cnt+B.cnt;
        C.mx2=max(A.mx2,B.mx2);
        return C;
    }
    if (A.mx<B.mx) swap(A,B);
    C.mx=A.mx;
    C.cnt=A.cnt;
    C.mx2=max(B.mx,A.mx2);
    return C;
}
void build(int v,int l,int r){
    sum[v]=0ll;
    w[v]=1000000001;
    for (int i=l;i<=r;i++) {
        cnt[v][h[i]]++;
        sum[v]+=h[i];
    }
    if (l==r) return;
    int m=(l+r)/2;
    build(v+v,l,m);
    build(v+v+1,m+1,r);

}
void go(int v,int x){
    w[v]=min(w[v],x);
    while (!cnt[v].empty() && (*cnt[v].rbegin()).first>x){
        int mx=(*cnt[v].rbegin()).first;
        int cn=cnt[v][mx];
        sum[v]-=1ll*(mx-x+0ll)*cn;
        cnt[v].erase(mx);
        cnt[v][x]+=cn;
    }
}
void push(int v){
    go(v+v,w[v]);
    go(v+v+1,w[v]);
    w[v]=1000000001;
}
void upd_pos(int v,int l,int r,int pos,int x,int last){
    sum[v]+=x-last;
    cnt[v][last]--;
    if ((--cnt[v][last])==0) cnt[v].erase(last);
    cnt[v][x]++;
    if (l==r){
        return;
    }
    push(v);
    int m=(l+r)/2;
    if (pos<=m) upd_pos(v+v,l,m,pos,x,last);
    else upd_pos(v+v+1,m+1,r,pos,x,last);
}
int super_upd(int v,int l,int r,int L,int R,int x,int cn){
//    cout<<"AAA "<<v<<" "<<l<<" "<<r<<" "<<x<<endl;

    if (l>R || r<L || cn<=0) return 0;

    if (l<r){
        push(v);
    }
    if (l>=L && r<=R){
        int mx=(*cnt[v].rbegin()).first;
        int was=cnt[v][mx];
        int can=min(was,cn);
        cnt[v][mx]-=can;
        if (!cnt[v][mx]) cnt[v].erase(mx);
        cnt[v][x]+=can;
        sum[v]-=1ll*can*(mx-x+0ll);
        if (can==was){
            w[v]=x;
            return can;
        }
        int m=(l+r)/2;
        int cur=super_upd(v+v,l,m,L,R,x,cn);
        cur+=super_upd(v+v+1,m+1,r,L,R,x,cn-cur);
        return cur;
    }
    int m=(l+r)/2;
    int cur=super_upd(v+v,l,m,L,R,x,cn);
    cur+=super_upd(v+v+1,m+1,r,L,R,x,cn-cur);
    sum[v]=sum[v+v]+sum[v+v+1];
    return cur;
}
ll get_sum(int v,int l,int r,int L,int R){
    if (l>R || r<L) return 0ll;
    if (l>=L && r<=R) return sum[v];
    push(v);
    int m=(l+r)/2;
    return get_sum(v+v,l,m,L,R)+get_sum(v+v+1,m+1,r,L,R);
}
ret get_mx(int v,int l,int r,int L,int R){
    if (l>R || r<L || cnt[v].empty()) return ret();
    if (l>=L && r<=R){
        auto it=cnt[v].end();
        it--;
        ret cur;
        cur.mx=(*it).first;
        cur.cnt=(*it).second;
        cur.mx2=0;
        if (it!=cnt[v].begin()){
            it--;
            cur.mx2=(*it).first;
        }
        return cur;
    }
    push(v);
    int m=(l+r)/2;
    return Merge(get_mx(v+v,l,m,L,R),get_mx(v+v+1,m+1,r,L,R));

}


void initialise(int nn, int qq, int hh[]) {
	// Your code here.
	n=nn;
	q=qq;
	for (int i=1;i<=n;i++) h[i]=hh[i];
	build(1,1,n);
}
void cut(int l, int r, int k) {
	// Your code here.
	int CNT=0;
	while (true){
        ret cur=get_mx(1,1,n,l,r);
        if (cur.mx<=0) break;
        if (1ll*(cur.mx-cur.mx2+0ll)*cur.cnt<k*1ll){
            k-=(cur.mx-cur.mx2)*cur.cnt;
            super_upd(1,1,n,l,r,cur.mx2,1000000001);
//            cout<<"AAA "<<cur.mx2<<" "<<get_mx(1,1,n,l,r).mx<<endl;
            CNT++;
        } else {
//            return;
            int x=(1ll*cur.mx*cur.cnt-k+cur.cnt-1)/cur.cnt;
            k-=(cur.mx-x)*cur.cnt;
            super_upd(1,1,n,l,r,x,1000000001);


            super_upd(1,1,n,l,r,x-1,k);

            break;
        }
	}
//	cout<<"CNT = "<<CNT<<endl;
}
void magic(int i, int x) {
    int last=get_mx(1,1,n,i,i).mx;
    upd_pos(1,1,n,i,x,last);
	// Your code here.
}
long long int inspect(int l, int r) {
	// Your code here.
	int sum=0;
	for (int i=1;i<=n*4;i++){
        sum+=(int)cnt[i].size();
	}
//	cout<<"cnt= "<<sum<<endl;
	return get_sum(1,1,n,l,r);
}
/**
6 2
1 2 3 1 2 3
1 1 6 3
3 1 6

**/
