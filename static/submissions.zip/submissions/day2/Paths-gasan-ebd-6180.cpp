/**
* user:  gasan-ebd
* fname: Luca Carol
* lname: Gasan
* task:  Paths
* score: 36.0
* date:  2021-12-17 10:33:19.071422
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct muchie
{
    int first;
    int second;
};
vector<muchie> vec[2005];
bool ok[2005];
int papa[2005];
int cost[2005];
int dim[2005];
int n,k,x,y,c;
void precalc(int nod)
{
    ok[nod]=true;
    dim[nod]=1;
    for(auto x:vec[nod])
    if(!ok[x.first])
    {
        papa[x.first]=nod;
        cost[x.first]=x.second;
        precalc(x.first);
        dim[nod]+=dim[x.first];
    }
}
ll down[2005][2005];
ll upp[2005][2005];
ll ans[2005][2005];
void df_jos(int nod)
{
    int tata=papa[nod];
    for(auto x:vec[nod])
    if(x.first!=tata)
    {
        df_jos(x.first);
        for(int tot=min(k,dim[nod]);tot>=1;--tot)
        for(int util=min(tot,dim[x.first]);util>=1;--util)
            down[nod][tot]=max(down[nod][tot],
                            down[nod][tot-util]+down[x.first][util]+x.second),
            ans[nod][tot]=down[nod][tot];
    }
}
void df(int nod)
{
    int tata=papa[nod];
    for(auto x:vec[nod])
    if(x.first!=tata)
    {
        for(int util=k;util>=1;--util)
            upp[nod][util]=upp[tata][util]+cost[nod];
        for(auto y:vec[nod]) if(y.first!=tata and y.first!=x.first)
        for(int tot=k;tot>=1;--tot)
        for(int util=min(tot,dim[y.first]);util>=1;--util)
            upp[nod][tot]=max(upp[nod][tot],
                            upp[nod][tot-util]+down[y.first][util]+y.second);
        df(x.first);
    }
    if(tata!=0)
    for(int tot=k;tot>=1;--tot)
    for(int util=min(n-dim[nod],tot);util>=1;--util)
        ans[nod][tot]=max(ans[nod][tot],
                        ans[nod][tot-util]+upp[tata][util]+cost[nod]);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>k;
    for(int i=1;i<n;++i)
        cin>>x>>y>>c,
        vec[x].push_back({y,c}),
        vec[y].push_back({x,c});
    precalc(1);
    df_jos(1);
    df(1);
    for(int i=1;i<=n;++i)
        cout<<ans[i][k]<<'\n';
    return 0;
}

/*
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/
