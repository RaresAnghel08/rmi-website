/**
* user:  myskiv-a26
* fname: Vladyslav
* lname: Myskiv
* task:  Paths
* score: 12.0
* date:  2021-12-17 08:58:30.407017
*/
#include <bits/stdc++.h>

using namespace std;

#define DIM 100007

int n, k, timer, tin[DIM], tout[DIM], u, v;

long long c, t[4*DIM], mod[4*DIM], ans[DIM];

vector<pair<int, long long> > vec[DIM];

void dfs(int v, int p){
    tin[v]=++timer;
    for(auto e : vec[v]){
        int to=e.first;
        if(to!=p) dfs(to, v);
    }
    tout[v]=timer;
    return;
}

void push(int v){
    t[2*v+1]+=mod[v];
    t[2*v+2]+=mod[v];
    mod[2*v+1]+=mod[v];
    mod[2*v+2]+=mod[v];
    mod[v]=0;
    return;
}

void update(int v, int tl, int tr, int L, int R, long long val){
    if(R<tl || tr<L) return;
    if(L<=tl && tr<=R){
        t[v]+=val;
        mod[v]+=val;
        return;
    }
    push(v);
    int tm=(tl+tr)>>1;
    update(2*v+1, tl, tm, L, R, val);
    update(2*v+2, tm+1, tr, L, R, val);
    t[v]=max(t[2*v+1], t[2*v+2]);
    return;
}

long long get_max(int v, int tl, int tr, int L, int R){
    if(tr<L || R<tl) return 0;
    if(L<=tl && tr<=R) return t[v];
    push(v);
    int tm=(tl+tr)>>1;
    long long mx1=get_max(2*v+1, tl, tm, L, R);
    long long mx2=get_max(2*v+2, tm+1, tr, L, R);
    return max(mx1, mx2);
}

void get_cost(int v, int p, int val){
    update(0, 1, n, tin[v], tout[v], val);
    for(auto e : vec[v]){
        int to=e.first;
        if(to==p) continue;
        get_cost(to, v, e.second);
    }
    return;
}

void get_ans(int v, int p, int edg){
    if(p==-1){
        ans[v]=get_max(0, 1, n, 1, n);
    }
    else{
        update(0, 1, n, 1, n, edg);
        update(0, 1, n, tin[v], tout[v], -2*edg);
        ans[v]=get_max(0, 1, n, 1, n);
    }
    for(auto e : vec[v]){
        int to=e.first;
        if(to==p) continue;
        get_ans(to, v, e.second);
    }
    if(p!=-1){
        update(0, 1, n, 1, n, -edg);
        update(0, 1, n, tin[v], tout[v], 2*edg);
    }
    return;
}

int main()
{
    scanf("%d%d", &n, &k);
    for(int i=1; i<n; i++){
        scanf("%d%d%lld", &u, &v, &c);
        vec[u].push_back({v, c});
        vec[v].push_back({u, c});
    }
    timer=0;
    dfs(1, -1);
    get_cost(1, -1, 0);
    get_ans(1, -1, 0);
    for(int i=1; i<=n; i++) printf("%lld\n", ans[i]);
    return 0;
}
