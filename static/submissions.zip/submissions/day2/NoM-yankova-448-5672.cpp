/**
* user:  yankova-448
* fname: Denitsa Marinova
* lname: Yankova
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:50:52.684744
*/
#include<bits/stdc++.h>
using namespace std;

int const MAXN=100;
int n, m, p[MAXN], cnt[MAXN], dist[MAXN], br;

void print()
{
    for(int i=1;i<=2*n;i++)
    {
        cout<<p[i]<<" ";
    }
    cout<<endl;
}

void perm(int pos)
{
    if(pos>2*n)
    {
        memset(dist,0,sizeof(dist));
        memset(cnt,0,sizeof(cnt));
        for(int i=1;i<=2*n;i++)
        {
            cnt[p[i]]++;
            if(dist[p[i]]==0) dist[p[i]] = i;
            else dist[p[i]] = dist[p[i]]-i;
            if(cnt[p[i]]>2) return;
        }
        for(int i=1;i<=n;i++)
        {
            if(dist[i]%m==0) return;
        }
        br++;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        p[pos]=i;
        perm(pos+1);
    }
}

int main()
{
	cin>>n>>m;
	perm(1);
	cout<<br<<endl;
	return 0;
}
