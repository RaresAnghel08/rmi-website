/**
* user:  greaca-04d
* fname: Albert Antoniu
* lname: Greaca
* task:  Paths
* score: 12.0
* date:  2021-12-17 08:44:56.447887
*/
#include<bits/stdc++.h>
#define ll long long
using namespace std;
vector<pair<int,int>>g[100005];
ll max1[100005],a[100005],b[100005],sus[100005];
int ta[100005],c[100005];
void dfs(int nod,int t)
{
    for(auto it:g[nod])
        if (it.first!=t){
            ta[it.first]=nod;
            c[it.first]=it.second;
            dfs(it.first,nod);
            max1[nod]=max(max1[nod],max1[it.first]+it.second);
            if (max1[it.first]+it.second>=a[nod])
                b[nod]=a[nod],a[nod]=max1[it.first]+it.second;
            else
                if (max1[it.first]+it.second>=b[nod])
                    b[nod]=max1[it.first]+it.second;
        }
}
void dfs2(int nod,int t)
{
    if (t){
        if (max1[nod]+c[nod]==a[t])
            sus[nod]=max(sus[nod],b[t]+c[nod]);
        else
            sus[nod]=max(sus[nod],a[t]+c[nod]);
        if (ta[t])
            sus[nod]=max(sus[nod],sus[t]+c[nod]);
    }
    for(auto it:g[nod])
        if (it.first!=t)
            dfs2(it.first,nod);
}
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    int n,k,i,x,y,w;
    scanf("%d%d",&n,&k);
    for(i=1;i<n;i++){
        scanf("%d%d%d",&x,&y,&w);
        g[x].push_back(make_pair(y,w));
        g[y].push_back(make_pair(x,w));
    }
    dfs(1,0);
    dfs2(1,0);
    for(i=1;i<=n;i++)
        printf("%lld\n",max(max1[i],sus[i]));
return 0;
}
