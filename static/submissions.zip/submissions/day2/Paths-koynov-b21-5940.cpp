/**
* user:  koynov-b21
* fname: Daniel Iliev
* lname: Koynov
* task:  Paths
* score: 36.0
* date:  2021-12-17 10:12:44.318669
*/
#include <bits/stdc++.h>
#define endl '\n'

using namespace std;
typedef long long ll;
const int maxn = 2010, maxk = 1100;
const ll inf = 1e17;

void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}

int n, k;
ll dp[maxn][maxk], org[maxn][maxk], ks[maxk][2];
vector < pair < int, ll > > g[maxn];
void dfs(int ver, int par)
{
    for (int i = 0; i < g[ver].size(); i ++)
    {
        int u = g[ver][i].first;
        if (u == par)
            continue;
        dfs(u, ver);
    }

    for (int i = 0; i <= k; i ++)
        ks[i][0] = ks[i][1] = -inf;
    ks[0][0] = ks[0][1] = 0;
    ks[1][0] = ks[1][1] = 0;
    for (int i = 0; i < g[ver].size(); i ++)
    {
        int u = g[ver][i].first;
        if (u == par)
            continue;
        for (int fk = 1; fk <= k; fk ++)
        {
            ll sum = g[ver][i].second + dp[u][fk];
            for (int j = k; j >= fk; j --)
                ks[j][1] = max(ks[j][1], ks[j - fk][0] + sum);
        }

        for (int j = 0; j <= k; j ++)
            ks[j][0] = ks[j][1];
    }


    for (int i = 0; i <= k; i ++)
        dp[ver][i] = ks[i][0], org[ver][i] = ks[i][0];
}

void calc(int ver, int par)
{

    for (int i = 0; i <= k; i ++)
        ks[i][0] = ks[i][1] = -inf;
    ks[0][0] = ks[0][1] = 0;
    ks[1][0] = ks[1][1] = 0;

    for (int i = 0; i < g[ver].size(); i ++)
    {
        int u = g[ver][i].first;
        if (u == par)
            continue;

        for (int fk = 1; fk <= k; fk ++)
        {
            ll sum = g[ver][i].second + dp[u][fk];
            for (int j = k; j >= fk; j --)
                ks[j][1] = max(ks[j][1], ks[j - fk][0] + sum);
        }

        for (int j = 0; j <= k; j ++)
            ks[j][0] = ks[j][1];
    }


    for (int i = 0; i <= k; i ++)
        dp[ver][i] = ks[i][0];
}

ll ans[maxn], curr[maxk][2];
vector < ll > toright[maxn][maxk], toleft[maxn][maxk];
void calc_dfs(int ver, int par)
{
    /// calculating answer for current node
    calc(ver, -1);
    for (int i = 0; i <= k; i ++)
        ans[ver] = max(ans[ver], dp[ver][k]);



    /// if it is empty just go back
    int sz = g[ver].size();
    if (sz == 0)
    {
        for (int j = 0; j <= k; j ++)
            dp[ver][j] = org[ver][j];
        return;
    }

    for (int fk = 0; fk <= k; fk ++)
        toright[ver][fk].resize(sz + 1);
    for (int fk = 0; fk <= k; fk ++)
        toleft[ver][fk].resize(sz + 1);
    ///if (ver == 2)
     ///   cout << "--------------------" << endl;
    /// calculating children from left to right
    for (int i = 0; i <= k; i ++)
    {
        toright[ver][i][0] = dp[g[ver][0].first][i];
        if (i > 0)
            toright[ver][i][0] += g[ver][0].second;
    }
    for (int j = 1; j < sz; j ++)
    {
        int u = g[ver][j].first;
        for (int fk = 0; fk <= k; fk ++)
            toright[ver][fk][j] = toright[ver][fk][j - 1];
        for (int fk = 1; fk <= k; fk ++)
        {
            ll sum = dp[u][fk] + g[ver][j].second;
            for (int tp = k; tp >= fk; tp --)
            {
                ///cout << tp << " " << fk << " " << sum << endl;
                toright[ver][tp][j] = max(toright[ver][tp][j], toright[ver][tp - fk][j - 1] + sum);
                ///cout << toright[ver][j][tp] << " " << toright[ver][j - 1][tp - fk] << endl;
            }
        }
    }

    /// calculating children from right to left
    for (int i = 0; i <= k; i ++)
    {
        toleft[ver][i][sz - 1] = dp[g[ver][sz - 1].first][i];
        if (i > 0)
            toleft[ver][i][sz - 1] += g[ver][sz - 1].second;
    }

    for (int j = sz - 2; j >= 0; j --)
    {
        int u = g[ver][j].first;
        for (int fk = 0; fk <= k; fk ++)
            toleft[ver][fk][j] = toleft[ver][fk][j + 1];
        for (int fk = 1; fk <= k; fk ++)
        {
            ll sum = dp[u][fk] + g[ver][j].second;
            for (int tp = k; tp >= fk; tp --)
            {
                toleft[ver][tp][j] = max(toleft[ver][tp][j], toleft[ver][tp - fk][j + 1] + sum);
            }
        }
    }

    /**if (ver == 2)
    {
        cout << "-------------------" << endl;
        cout << g[ver][0].first << endl;
        for (int i = 0; i <= k; i ++)
            cout << toright[ver][0][i] << " ";
        cout << endl;

        for (int i = 0; i <= k; i ++)
            cout << dp[3][i] << " ";
        cout << endl;
                cout << g[ver][1].first << endl;
        for (int i = 0; i <= k; i ++)
            cout << toright[ver][1][i] << " ";
        cout << endl;
        exit(0);
    }*/



    for (int j = 0; j < sz; j ++)
    {
        int u = g[ver][j].first;
        if (u == par)
            continue;
        /// now we want to go down
        for (int fk = 0; fk <= k; fk ++)
            curr[fk][0] = curr[fk][1] = -inf;
        curr[0][0] = curr[1][0] = curr[0][1] = curr[1][1] = 0;
        if (j == 0 && j == sz - 1)
        {
                  for (int fk = 0; fk <= k; fk ++)
            dp[ver][fk] = curr[fk][0];
            calc_dfs(u, ver);
            continue;
        }

        if (j != 0)
        {
            for (int fk = 0; fk <= k; fk ++)
            {
                for (int tp = k; tp >= fk; tp --)
                {
                    curr[tp][1] = max(curr[tp][1], curr[tp - fk][0] + toright[ver][fk][j - 1]);
                }
            }

            for (int fk = 0; fk <= k; fk ++)
                curr[fk][0] = curr[fk][1];
        }


        if (j != sz - 1)
        {
                       for (int fk = 0; fk <= k; fk ++)
            {
                for (int tp = k; tp >= fk; tp --)
                {
                    curr[tp][1] = max(curr[tp][1], curr[tp - fk][0] + toleft[ver][fk][j + 1]);
                }
            }

            for (int fk = 0; fk <= k; fk ++)
                curr[fk][0] = curr[fk][1];
            }


        for (int fk = 0; fk <= k; fk ++)
            dp[ver][fk] = curr[fk][0];


        calc_dfs(u, ver);


    }

    for (int j = 0; j <= k; j ++)
        dp[ver][j] = org[ver][j];


}

void solve()
{
    cin >> n >> k;
    k = min(k, n);
    for (int i = 1; i < n; i ++)
    {
        int v, u;
        ll w;
        cin >> v >> u >> w;

        g[v].push_back({u, w});
        g[u].push_back({v, w});
    }

    dfs(1, -1);
    calc_dfs(1, -1);
    for (int root = 1; root <= n; root ++)
    {
        cout << ans[root] << endl;
    }
}

int main()
{
    speed();
    solve();
    return 0;
}
