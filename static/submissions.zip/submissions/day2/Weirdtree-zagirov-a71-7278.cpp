/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:48:52.042645
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

typedef long long ll;

//weirdtree

//grader

#define pb push_back
#define pii pair<ll, ll>
#define f first
#define s second

using namespace std;

const int MAXN = 8e4 + 10;
ll sum[4 * MAXN];
pii mx[4 * MAXN];
vector<int> vec;

pii maxim(pii a, pii b) {
    if (a.f == b.f)
        return min(a, b);
    return max(a, b);
}

void build(int v, int l, int r) {
    if (l == r - 1) {
        sum[v] = vec[l];
        mx[v] = {vec[l], l};
    } else {
        int mid = (r + l) / 2;
        build(2 * v + 1, l, mid);
        build(2 * v + 2, mid, r);
        sum[v] = sum[2 * v + 1] + sum[2 * v + 2];
        mx[v] = maxim(mx[2 * v + 1], mx[2 * v + 2]);
    }
}

ll get_s(int v, int l, int r, int tl, int tr) {
    if (tl <= l && tr >= r)
        return sum[v];
    if (tl >= r || tr <= l)
        return 0;
    int mid = (r + l) / 2;
    return get_s(2 * v + 1, l, mid, tl, tr) + get_s(2 * v + 2, mid, r, tl, tr);
}

pii get_mx(int v, int l, int r, int tl, int tr) {
    if (tl <= l && tr >= r)
        return mx[v];
    if (tl >= r || tr <= l)
        return {0, 0};
    int mid = (r + l) / 2;
    return maxim(get_mx(2 * v + 1, l, mid, tl, tr), get_mx(2 * v + 2, mid, r, tl, tr));
}

void update(int v, int l, int r, ll pos, ll val) {
    if (l == r - 1) {
        sum[v] = val;
        mx[v].f = val;
    } else {
        int mid = (r + l) / 2;
        if (pos < mid)
            update(2 * v + 1, l, mid, pos, val);
        else
            update(2 * v + 2, mid, r, pos, val);
        sum[v] = sum[2 * v + 1] + sum[2 * v + 2];
        mx[v] = maxim(mx[2 * v + 1], mx[2 * v + 2]);
    }
}

void initialise(int N, int Q, int h[]) {
    for (int i = 1; i <= N; i++) {
        vec.pb(h[i]);
    }
    build(0, 0, N);
}

void cut(int l, int r, int k) {
    int n = vec.size();
//    cout << l << ' ' << r << endl;
    while (k--) {
        auto u = get_mx(0, 0, n, l - 1, r);
//        cout << u.f << ' ' << u.s << endl;
        if (u.f)
            update(0, 0, n, u.s, u.f - 1);
    }
}

void magic(int i, int x) {
    int n = vec.size();
    update(0, 0, n, i - 1, x);
}

long long int inspect(int l, int r) {
    int n = vec.size();
    return get_s(0, 0, n, l - 1, r);
}
