/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  Paths
* score: 56.0
* date:  2021-12-17 08:34:37.570456
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

mt19937 rnd(time(0));

const int maxn = 1e5 + 50;
int ans[maxn];
vector<pii> r[maxn];
int k;


struct node {
	node *l = 0, *r = 0;
	int x;
	int y;
	int sum = 0;
	int s = 0;
	int max = 0;
	node(int x) : x(x), y(rnd()) {
		sum = x;
		max = x;
		s = 1;
	}
};

void upd(node *v) {
	if (!v)
		return;
	v->s = (v->l ? v->l->s : 0) + (v->r ? v->r->s : 0) + 1;
	v->sum = (v->l ? v->l->sum : 0) + (v->r ? v->r->sum : 0) + v->x;
	v->max = max({v->l ? v->l->max : 0, v->r ? v->r->max : 0, v->x});
}

node *merge(node *a, node *b) {
	if (!a)
		return b;
	if (!b)
		return a;
	if (a->y > b->y) {
		a->r = merge(a->r, b);
		upd(a);
		return a;
	} else {
		b->l = merge(a, b->l);
		upd(b);
		return b;
	}
}

pair<node*, node*> split(node *v, int x) {
	if (!v)
		return {0, 0};
	int id = (v->l ? v->l->s : 0);
	if (x > id) {
		auto p = split(v->r, x - id - 1);
		v->r = p.f;
		upd(v);
		return {v, p.s};
	} else {
		auto p = split(v->l, x);
		v->l = p.s;
		upd(v);
		return {p.f, v};
	}
}


pair<node*, node*> split2(node *v, int x) {
	if (!v)
		return {0, 0};
	if (x < v->x) {
		auto p = split2(v->r, x);
		v->r = p.f;
		upd(v);
		return {v, p.s};
	} else {
		auto p = split2(v->l, x);
		v->l = p.s;
		upd(v);
		return {p.f, v};
	}
}
int tim = -1;
int tin[maxn], tout[maxn];

node *tn = 0, *sn = 0;

node* del(node *v, int x) {
	if (!v)
		return 0;
	if (v->x == x) {
		return merge(v->l, v->r);
	} else {
		if (v->x > x) {
			v->r = del(v->r, x);
			upd(v);
			return v;
		} else {
			v->l = del(v->l, x);
			upd(v);
			return v;
		}
	}
}

node* ins(node *v, node *x) {
	if (!v)
		return x;
	if (v->y > x->y) {
		if (v->x > x->x) {
			v->r = ins(v->r, x);
			upd(v);
			return v;
		} else {
			v->l = ins(v->l, x);
			upd(v);
			return v;
		}
	} else {
		auto p = split2(v, x->x - 1);
		x->l = p.f;
		x->r = p.s;
		upd(x);
		return x;
	}
}

void kek(node *v, int p = -1) {
	if (!v)
		return;
	kek(v->l, 1);
	cout << v->x << ' ';
	kek(v->r, 1);
	if (p == -1)
		cout << endl;
}

void upd(int x, int y) {
	// cout << x << ' ' << y << endl;
	sn = del(sn, x);
	// auto p = split2(sn, -1);
	// kek(sn);
	auto p = split2(sn, y - 1);
	sn = merge(p.f, merge(new node(y), p.s));
	// kek(sn);
}


pii t[4 * maxn];

void build(int v, int tl, int tr) {
	t[v] = {0, tr};
	if (tl != tr) {
		int tm = (tl + tr) / 2;
		build(2 * v, tl, tm);
		build(2 * v + 1, tm + 1, tr);
	}
}
pii get(int v, int tl, int tr, int l, int r) {
	if (tl > r || tr < l || l > r)
		return {-1, -1};
	if (tl >= l && tr <= r) {
		return t[v];
	} else {
		int tm = (tl + tr) / 2;
		return max(get(2 * v, tl, tm, l, r), get(2 * v + 1, tm + 1, tr, l, r));
	}
}

void update(int v, int tl, int tr, int i, int x) {
	if (tl == tr) {
		t[v] = {x, tl};
		return;
	}
	int tm = (tl + tr) / 2;
	if (i <= tm) {
		update(2 * v, tl, tm, i, x);
	} else {
		update(2 * v + 1, tm + 1, tr, i, x);
	}
	t[v] = max(t[2 * v], t[2 * v + 1]);
}

int n;

void dfs(int v, int p = -1) {
	tin[v] = -1;
	for (auto &u : r[v]) {
		if (p != u.f) {
			dfs(u.f, v);
			if (tin[v] == -1) {
				tin[v] = tin[u.f];
			}
			tout[v] = tout[u.f];
			pii max = get(1, 0, n - 1, tin[u.f], tout[u.f]);
			upd(max.f, max.f + u.s);
			update(1, 0, n - 1, max.s, max.f + u.s);
		}
	}
	if (tin[v] == -1) {
		tin[v] = tout[v] = ++tim;
	}
}

int all = 0;
void dfs2(int v, int p = -1) {
	// kek(sn);
	auto d = split(sn, k);
	ans[v] = d.f->sum;
	sn = merge(d.f, d.s);
	for (auto &u : r[v]) {
		if (u.f != p) {
			pii max = get(1, 0, n - 1, tin[u.f], tout[u.f]);
			upd(max.f, max.f - u.s);
			update(1, 0, n - 1, max.s, max.f - u.s);
			pii max2 = {-1, -1};
			max2 = std::max(max2, get(1, 0, n - 1, tin[all], tin[u.f] - 1));
			max2 = std::max(max2, get(1, 0, n - 1, tout[u.f] + 1, tout[all]));
			// cout << get(1, 0, n - 1, tout[u.f] + 1, tout[all]).s << endl;
			update(1, 0, n - 1, max2.s, max2.f + u.s);
			// cout << tin[all] << ' ' << tin[u.f] - 1 << ' ' << tout[u.f] + 1 << ' ' << tout[all] << endl;
			// cout << max.s << ' ' << max2.s << endl;
			upd(max2.f, max2.f + u.s);
			dfs2(u.f, v);
			update(1, 0, n - 1, max.s, max.f);
			update(1, 0, n - 1, max2.s, max2.f);
			upd(max.f - u.s, max.f);
			upd(max2.f + u.s, max2.f);
			
		}
	}
}

void solve() {
	cin >> n >> k;

	for (int i = 0; i < n - 1; ++i) {
		int a, b, c;
		cin >> a >> b >> c;
		a--;
		b--;
		r[a].pb({b, c});
		r[b].pb({a, c});
	}
	if (n == 1) {
		cout << 0 << endl;
		exit(0);
	} else if (n == 2) {
		cout << r[0][0].s << '\n' << r[0][0].s << '\n';
		exit(0);
	}
	for (int i = 0; i < n; ++i) {
		sn = merge(sn, new node(0));
	}
	build(1, 0, n - 1);
	for (int j = 0; j < n; ++j) {
		if (r[j].size() > 1) {
			all = j;
			dfs(j);
			dfs2(j);
			break;
		}
	}
	for (int i = 0; i < n; ++i)
		cout << ans[i] << '\n';
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	while (t--)
		solve();
}