/**
* user:  gheorghies-4e2
* fname: Alexandru
* lname: Gheorghies
* task:  Paths
* score: 12.0
* date:  2021-12-17 10:52:57.059925
*/
#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll NMAX=1e5+5;
vector<pair<ll,ll>> edg[NMAX];
ll st[NMAX*8],id[NMAX*8],lazy[NMAX*8],n,k;
void add(ll ql, ll qr, ll val, ll node, ll l, ll r){
    if(id[node]==0) id[node]=l;

    st[node]+=lazy[node];
    lazy[node*2+1]+=lazy[node],lazy[node*2+2]+=lazy[node];
    lazy[node]=0;

    if(l>qr || r<ql) return;
    if(l>=ql && r<=qr)
        lazy[node]+=val;

    st[node]+=lazy[node];
    lazy[node*2+1]+=lazy[node],lazy[node*2+2]+=lazy[node];
    lazy[node]=0;

    if(l!=r){
        if(l<ql || r>qr){
            add(ql,qr,val,node*2+1,l,(r+l)/2),add(ql,qr,val,node*2+2,(r+l)/2+1,r);
            if(st[node*2+1]+lazy[node*2+1]>=st[node*2+2]+lazy[node*2+2]) id[node]=id[node*2+1],st[node]=st[node*2+1]+lazy[node*2+1];
            else id[node]=id[node*2+2],st[node]=st[node*2+2]+lazy[node*2+2];
        }
    }
}
pair<ll,ll> getMaxId(ll ql, ll qr, ll node, ll l, ll r){
    if(id[node]==0) id[node]=l;
    st[node]+=lazy[node];
    lazy[node*2+1]+=lazy[node],lazy[node*2+2]+=lazy[node];
    lazy[node]=0;
    if(l>qr || r<ql) return {-1e15,0};


    if(l>=ql && r<=qr) return {st[node],id[node]};

    pair<ll,ll> q1=getMaxId(ql,qr,node*2+1,l,(r+l)/2),q2=getMaxId(ql,qr,node*2+2,(r+l)/2+1,r);
    return q1.first>=q2.first?q1:q2;
}
ll rn[NMAX],ln[NMAX],p[NMAX],parentEdge[NMAX],unmap[NMAX];
ll ans[NMAX];
ll node_id=1;
void euler_tour(ll node){
    for(auto it : edg[node]){
        if(p[it.first]==-1){
            p[it.first]=node;
            euler_tour(it.first);
            ln[node]=(ln[node]==-1 || ln[it.first]<ln[node]?ln[it.first]:ln[node]);
        }
    }
    rn[node]=node_id++;
    unmap[rn[node]]=node;
    if(ln[node]==-1) ln[node]=rn[node];
}
void dfs(ll root){
    ll dist=getMaxId(rn[root],rn[root],0,1,n).first;
    add(1,n,dist,0,1,n);
    add(ln[root],rn[root],-2*dist,0,1,n);

    vector<pair<ll,ll>> eliminated_edges;

    for(ll i=0;i<k;i++){
        pair<ll,ll> farthest=getMaxId(1,n,0,1,n);
        ans[root]+=farthest.first;
        if(i!=k-1){
            ll u=unmap[farthest.second];
            if(rn[u]<ln[root] || rn[u]>rn[root]){
                while(u!=1 && parentEdge[u]){
                    add(ln[u],rn[u],-parentEdge[u],0,1,n);
                    eliminated_edges.push_back({u,parentEdge[u]});
                    parentEdge[u]=0;
                    u=p[u];
                }
                ll v=root;
                while(v!=1 && parentEdge[v]){
                    add(ln[v],rn[v],parentEdge[v],0,1,n);
                    add(1,n,-parentEdge[v],0,1,n);
                    eliminated_edges.push_back({v,-parentEdge[v]});
                    parentEdge[v]=0;
                    v=p[v];
                }
            }
            else{
                while(u!=root && parentEdge[u]){
                    add(ln[u],rn[u],-parentEdge[u],0,1,n);
                    eliminated_edges.push_back({u,parentEdge[u]});
                    parentEdge[u]=0;
                    u=p[u];
                }
            }
        }
    }
    for(auto it : eliminated_edges){
        parentEdge[it.first]=abs(it.second);
        add(ln[it.first],rn[it.first],it.second,0,1,n);
        if(it.second<0)
            add(1,n,-it.second,0,1,n);
    }
    for(auto it : edg[root])
        if(it.first!=p[root])
            dfs(it.first);
    add(1,n,-dist,0,1,n);
    add(ln[root],rn[root],2*dist,0,1,n);
}
signed main(){
    ios_base::sync_with_stdio(false); cin.tie(0);
    cin>>n>>k;
    for(ll i=1;i<n;i++){
        rn[i]=ln[i]=p[i]=-1;
        ll u,v,c;
        cin>>u>>v>>c;
        edg[u].push_back({v,c});
        edg[v].push_back({u,c});
    }
    rn[n]=ln[n]=p[n]=-1;
    p[1]=0;
    euler_tour(1);
    for(ll i=2;i<=n;i++){
        for(auto it : edg[i]){
            if(it.first==p[i]){
                parentEdge[i]=it.second;
                break;
            }
        }
        add(ln[i],rn[i],parentEdge[i],0,1,n);
    }
    dfs(1);

    for(ll i=1;i<=n;i++)
        cout<<ans[i]<<'\n';
}
