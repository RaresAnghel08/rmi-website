/**
* user:  ulukbekov-6c0
* fname: Erzhan
* lname: Ulukbekov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:18:17.057782
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

using namespace std;

vector<int> t;

void initialise(int N, int Q, int h[]) {
	t = vector<int> (N + 1, 0);
	for (int i = 1; i <= N; i++) t[i] = h[i];
}
void cut(int l, int r, int k) {
	auto check = [&](int x) ->int {
		int cnt = 0;
		for (int i = l; i <= r; i++) {
			if (t[i] > x) cnt += t[i] - x;
		}
		return cnt;
	};

	int left = 0, right = 1e9;
	while (left < right) {
		int mid = (left + 1 + right) >> 1;
		if (check(mid) >= k) {
			left = mid;
		} else {
			right = mid - 1;
		}
	}
	//if (check(left) > k) left++;
	if (check(left) == k) {
		for (int i = l; i <= r; i++) {
			t[i] = left;
		}
	} else {
		vector<pair<int, int>> srt;
		for (int i = l; i <= r; i++) {
			srt.push_back({t[i], i});
		}
		sort(srt.begin(), srt.end(), [&](pair<int,int> a, pair<int,int> b) {
			if (a.first != b.first) return a.first > b.first;
			return a.second < b.second;
		});
		int K = k;
		for (auto [x, y] : srt) {
			int cur = min(K, x - left);
			K -= cur;
			x -= cur;
			t[y] -= cur;
		}
	}
}
void magic(int i, int x) {
	//assert(false);
	t[i] = x;
}
long long int inspect(int l, int r) {
	long long sum = 0;
	for (int i = l; i <= r; i++) {
		sum += t[i];
	}
	return sum;
}
