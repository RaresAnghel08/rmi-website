/**
* user:  tanay-683
* fname: Alon
* lname: Tanay
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:46:15.958077
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

using namespace std;

bool cmp(pli a, pli b) {
    return (a.first > b.first || (a.first == b.first && a.second < b.second));
}
pli mx(pli a, pli b) {
    return (cmp(a,b) ? a : b);
}

struct Seg {
    vector<pli> seg_max;
    vector<ll> seg_sum;
    int n;
    void pull_max(int i) {
        seg_max[i] = mx(seg_max[i*2],seg_max[i*2+1]);
    }
    void pull_sum(int i) {
        seg_sum[i] = seg_sum[i*2] + seg_sum[i*2+1];
    }
    void build(int N, int *xs) {
        n = N;
        seg_max.resize(n*2);
        seg_sum.resize(n*2);
        for(int i = 0; i < n; i ++) {
            seg_max[i+n] = {xs[i+1],i};
            seg_sum[i+n] = xs[i+1];
        }
        for(int i = n - 1; i >= 1; i --) {
            pull_sum(i);
            pull_max(i);
        }
    }
    void update(int i, ll x) {
        int idx = i + n;
        seg_max[idx].first = x;
        seg_sum[idx] = x;
        for(idx >>= 1; idx > 0; idx >>= 1) {
            pull_sum(idx);
            pull_max(idx);
        }
    }
    void update_rel(int i, ll dif) {
        update(i,seg_sum[i+n]+dif);
    }
    ll query_sum(int l, int r) {
        ll res = 0;
        for(l += n, r += n; l < r; l >>= 1, r >>= 1) {
            if(l&1) {
                res += seg_sum[l++];
            }
            if(r&1) {
                res += seg_sum[--r];
            }
        }
        return res;
    }
    pli query_max(int l, int r) {
        pli res = seg_max[l+n];
        for(l += n, r += n; l < r; l >>= 1, r >>= 1) {
            if(l&1) {
                res = mx(res, seg_max[l++]);
            }
            if(r&1) {
                res = mx(res, seg_max[--r]);
            }
        }
        return res;
    }
    void cut_once(int l, int r) {
        pli big = query_max(l,r);
        if(big.first == 0) { return; }
        update_rel(big.second,-1);
    }
};

Seg seg;

void initialise(int N, int Q, int h[]) {
    seg.build(N,h);
}
void cut(int l, int r, int k) {
    seg.cut_once(l-1,r);
}
void magic(int i, int x) {
    seg.update(i-1,x);
}
long long int inspect(int l, int r) {
    return seg.query_sum(l-1,r);
}