/**
* user:  dimitrova-b08
* fname: Niya Radoslavova
* lname: Dimitrova
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 08:37:33.959600
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
using namespace std;
const int maxn = 400004;
struct node
{
    int maxe;
    long long sume;
    int idxe;
    node() {};
    node( int maxe1, long long sume1, int idxe1 )
    {
        maxe = maxe1;
        sume = sume1;
        idxe = idxe1;
    }
};
node tree[maxn * 4];
int t_h[maxn * 2];
int n;
void make_tree(int i, int l, int r)
{
    if( l == r )
    {
        tree[i].maxe = tree[i].sume = t_h[l];
        tree[i].idxe = l;
        return;
    }
    int m = (l+r)/2;
    make_tree(i*2,l,m);
    make_tree(i*2+1,m+1,r);
    if( tree[i*2].maxe >= tree[i*2+1].maxe )
    {
        tree[i].maxe = tree[i*2].maxe;
        tree[i].idxe = tree[i*2].idxe;
    }
    else
    {
        tree[i].maxe = tree[i*2 + 1].maxe;
        tree[i].idxe = tree[i*2 + 1].idxe;
    }
    tree[i].sume = tree[i*2].sume + tree[i*2+1].sume;
    return;
}
pair< int,int > get_max_element(int i, int l, int r, int ql, int qr)
{
    if( l == ql && r == qr )
    {
        pair< int,int > tp( tree[i].maxe, tree[i].idxe );
        return tp;
    }
    int m = (l + r)/2;
    if( qr <= m ) return get_max_element(i*2,l,m,ql,qr);
    else if( ql > m ) return get_max_element(i*2+1,m+1,r,ql,qr);
    else
    {
        pair< int,int > tp1 = get_max_element(i*2,l,m,ql,m);
        pair< int,int > tp2 = get_max_element(i*2+1,m+1,r,m+1,qr);
        if( tp1.first > tp2.first ) return tp1;
        else return tp2;
    }
}
long long get_sum_element(int i, int l, int r, int ql, int qr)
{
    if( l == ql && r == qr )
    {
        return tree[i].sume;
    }
    int m = (l + r)/2;
    if( qr <= m ) return get_sum_element(i*2,l,m,ql,qr);
    else if( ql > m ) return get_sum_element(i*2+1,m+1,r,ql,qr);
    else
    {
        long long x = get_sum_element(i*2,l,m,ql,m);
        long long y = get_sum_element(i*2+1,m+1,r,m+1,qr);
        return ( x + y );
    }
}
void update_cut(int i, int l, int r, int pos, int x)
{
    if( l == r )
    {
        if( tree[i].sume - x >= 0 ) tree[i].sume -= x;
        if( tree[i].maxe - x >= 0 ) tree[i].maxe -= x;
        return;
    }
    int m = (l + r)/2;
    if( pos <= m ) update_cut(i*2,l,m,pos,x);
    else update_cut(i*2+1,m+1,r,pos,x);
    if( tree[i*2].maxe >= tree[i*2+1].maxe )
    {
        tree[i].maxe = tree[i*2].maxe;
        tree[i].idxe = tree[i*2].idxe;
    }
    else
    {
        tree[i].maxe = tree[i*2 + 1].maxe;
        tree[i].idxe = tree[i*2 + 1].idxe;
    }
    tree[i].sume = tree[i*2].sume + tree[i*2+1].sume;
    return;
}
void update_magic(int i, int l, int r, int pos, int x)
{
    if( l == r && l == pos )
    {
        tree[i].sume = x;
        tree[i].maxe = x;
        return;
    }
    int m = (l + r)/2;
    if( pos <= m ) update_magic(i*2,l,m,pos,x);
    else update_magic(i*2+1,m+1,r,pos,x);
    if( tree[i*2].maxe >= tree[i*2+1].maxe )
    {
        tree[i].maxe = tree[i*2].maxe;
        tree[i].idxe = tree[i*2].idxe;
    }
    else
    {
        tree[i].maxe = tree[i*2 + 1].maxe;
        tree[i].idxe = tree[i*2 + 1].idxe;
    }
    tree[i].sume = tree[i*2].sume + tree[i*2+1].sume;
    return;
}
void initialise(int N, int Q, int h[])
{
    n = N;
    for(int i=1; i<=n; i++)
    {
        t_h[i] = h[i];
    }
    make_tree(1,1,n);
}
void cut(int l, int r, int k)
{
    for(int i=1; i<=k; i++)
    {
        pair< int,int > tp = get_max_element(1,1,n,l,r);
        int t_idx = tp.second;
        update_cut(1,1,n,t_idx,1);
    }
}
void magic(int i, int x)
{
    update_magic(1,1,n,i,x);
}
long long int inspect(int l, int r)
{
    long long t_sum = get_sum_element(1,1,n,l,r);
    return t_sum;
}
