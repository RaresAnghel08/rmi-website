/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  Paths
* score: 48.0
* date:  2021-12-17 09:09:25.595992
*/
#include <algorithm>
#include <iostream>
#include <utility>
#include <vector>
#define endl '\n'
using namespace std;

const int MAXN = 100000;

int k;
vector<long long> dp[MAXN + 5];
vector< pair<int, int> > G[MAXN + 5];
vector< vector<long long> > pref[MAXN + 5], suff[MAXN + 5];

void DFS_pref(int u, int p)
{
    dp[u].resize(k + 1, 0);
    pref[u].resize(G[u].size() + 1, dp[u]);
    int cnt = 0;
    for (int i = 0; i < G[u].size(); ++ i)
    {
        int v = G[u][i].first, w = G[u][i].second;
        if (v != p)
        {
            DFS_pref(v, u);
            for (int s = k; s >= 1; -- s)
            {
                for (int i = 1; i <= s; ++ i)
                {
                    dp[u][s] = max(dp[u][s], dp[v][i] + w + dp[u][s - i]);
                }
            }
        }
        cnt++;
        pref[u][cnt] = dp[u];
    }
}

void DFS_suff(int u, int p)
{
    dp[u].clear();
    dp[u].resize(k + 1, 0);
    suff[u].resize(G[u].size() + 1, dp[u]);
    int cnt = G[u].size();
    for (int i = G[u].size() - 1; i >= 0; -- i)
    {
        int v = G[u][i].first, w = G[u][i].second;
        if (v != p)
        {
            DFS_suff(v, u);
            for (int s = k; s >= 1; -- s)
            {
                for (int i = 1; i <= s; ++ i)
                {
                    dp[u][s] = max(dp[u][s], dp[v][i] + w + dp[u][s - i]);
                }
            }
        }
        suff[u][cnt] = dp[u];
        cnt--;
    }
}

void DFS_final(int u, int p, int w0, vector<long long> v0)
{
    if (p != -1)
    {
        int idx = lower_bound(G[p].begin(), G[p].end(), make_pair(u, 0)) - G[p].begin();
        vector<long long> v1 = pref[p][idx];
        vector<long long> v2;
        if (idx + 2 > G[p].size()) v2 = suff[p][0];
        else v2 = suff[p][idx + 2];
        for (int s = k; s >= 1; -- s)
        {
            for (int i = 1; i <= s; ++ i)
            {
                v0[s] = max(v0[s], v1[i] + v0[s - i]);
            }
        }
        for (int s = k; s >= 1; -- s)
        {
            for (int i = 1; i <= s; ++ i)
            {
                v0[s] = max(v0[s], v2[i] + v0[s - i]);
            }
        }
        for (int s = 1; s <= k; ++ s)
        {
            v0[s] += w0;
        }
        for (int s = k; s >= 1; -- s)
        {
            for (int i = 1; i <= s; ++ i)
            {
                dp[u][s] = max(dp[u][s], v0[i] + dp[u][s - i]);
            }
        }
    }
    for (auto [v, w] : G[u])
    {
        if (v != p)
        {
            DFS_final(v, u, w, v0);
        }
    }
}

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n;
    cin >> n >> k;

    for (int i = 1; i < n; ++ i)
    {
        int u, v, w;
        cin >> u >> v >> w;
        G[u].push_back(make_pair(v, w));
        G[v].push_back(make_pair(u, w));
    }

    for (int i = 1; i <= n; ++ i)
    {
        sort(G[i].begin(), G[i].end());
    }

    DFS_pref(1, -1);
    DFS_suff(1, -1);
    vector<long long> v0;
    v0.resize(k + 1, 0);
    DFS_final(1, -1, 0, v0);

    for (int i = 1; i <= n; ++ i)
    {
        cout << dp[i][k] << endl;
    }

    return 0;
}

/*
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/
