/**
* user:  dimitrov-8ab
* fname: Atanas
* lname: Dimitrov
* task:  Paths
* score: 12.0
* date:  2021-12-17 08:38:04.456422
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl "\n"
template<class T, class T2> bool chkmin(T &a, const T2 &b) {return (a > b) ? a = b, 1 : 0;}
template<class T, class T2> bool chkmax(T &a, const T2 &b) {return (a < b) ? a = b, 1 : 0;}
#ifndef LOCAL
#define cerr if(false)cerr
#endif // LOCAL

const ll MAX_N = 1e6 + 10;
vector<pair<ll, ll> > g[MAX_N];
ll n;
ll k;

ll lng[MAX_N];
ll ans[MAX_N];

void calcdp(ll x, ll p) {
    for(auto it : g[x]) {
        if(it.first == p) {continue;}
        calcdp(it.first, x);
        chkmax(lng[x], lng[it.first] + it.second);
    }
}

void reroot(ll x, ll p, ll pardp) {
    vector<ll> adj, pref, suf;
    for(auto it : g[x]) {
        if(it.first == p) {
            adj.push_back(pardp);
        } else {
            adj.push_back(lng[it.first] + it.second);
        }
    }
    for(ll i = 0; i < adj.size(); i ++) {
        pref.push_back(adj[i]);
        if(i != 0) {
            chkmax(pref[i], pref[i - 1]);
        }
    }
    suf.resize(adj.size());
    for(ll i = adj.size() - 1; i >= 0; i --) {
        suf[i] = adj[i];
        if(i != adj.size() - 1) {
            chkmax(suf[i], suf[i + 1]);
        }
    }
    ans[x] = pref.back();
    for(ll i = 0; i < adj.size(); i ++) {
        auto it = g[x][i];
        if(it.first == p) {continue;}
        ll mx = 0;
        if(i != 0) {
            chkmax(mx, pref[i - 1]);
        }
        if(i != adj.size() - 1) {
            chkmax(mx, suf[i + 1]);
        }
        reroot(it.first, x, mx + it.second);
    }
}

signed main() {
#ifndef LOCAL
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#endif

    cin >> n >> k;
    for(ll i = 0; i < n - 1; i ++) {
        ll a, b, c;
        cin >> a >> b >> c;
        g[a].push_back({b, c});
        g[b].push_back({a, c});
    }

    calcdp(1, 0);
    reroot(1, 0, 0);

    for(ll i = 1; i <= n; i ++) {
        cout << ans[i] << endl;
    }
    cout << endl;

    return 0;
}

