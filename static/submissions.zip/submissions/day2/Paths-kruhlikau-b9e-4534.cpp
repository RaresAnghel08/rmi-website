/**
* user:  kruhlikau-b9e
* fname: Ihar
* lname: Kruhlikau
* task:  Paths
* score: 12.0
* date:  2021-12-17 08:05:15.515132
*/
#include <bits/stdc++.h>

#define fi first
#define se second
#define mp make_pair

#define pb push_back
#define pob pop_back

#define ld long double
#define ll long long

#define in insert
#define er erase

#define re return
#define cont continue

#define endl '\n'

using namespace std;

multiset <ll> Set[120001];

vector < pair <ll, ll> > v[120001];

ll one[120001], two[120001], w[120001], dp[120001], dp1[120001], prv[120001], n, i, j, k;

    void dfs(ll nom, ll last)
    {
        ll i;

        prv[nom] = last;

        for (i = 0; i < v[nom].size(); i++)
            if (v[nom][i].fi != last) {
                dfs(v[nom][i].fi, nom);

                dp[nom] = max(dp[nom], dp[v[nom][i].fi] + v[nom][i].se);
            }
    }

    void dfs1(ll nom, ll last, ll w)
    {
        ll i;

        if (last != -1) {
            dp1[nom] = dp1[last] + w;

            Set[last].er(Set[last].find(dp[nom] + w));

            if (!Set[last].empty())
            dp1[nom] = max(dp1[nom], *Set[last].rbegin() + w);

//            if (nom == 3)
//            cout << *Set[last].rbegin() << endl;

            Set[last].in(dp[nom] + w);
        }

        for (i = 0; i < v[nom].size(); i++)
            if (v[nom][i].fi != last) dfs1(v[nom][i].fi, nom, v[nom][i].se);
    }

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin >> n >> k;

    if (k == 1) {
        for (i = 1; i <= n - 1; i++) {
            cin >> one[i] >> two[i] >> w[i];

            v[one[i]].pb(mp(two[i], w[i]));

            v[two[i]].pb(mp(one[i], w[i]));
        }

        dfs(1, -1);

        for (i = 1; i <= n; i++)
            for (j = 0; j < v[i].size(); j++)
                if (v[i][j].fi != prv[i]) Set[i].in(dp[v[i][j].fi] + v[i][j].se);

        dfs1(1, -1, -1);

        for (i = 1; i <= n; i++) cout << max(dp[i], dp1[i]) << endl;

        re 0;
    }



    re 0;
}
/*
5 1
1 2 3
1 4 2
2 3 1
2 5 4
*/
