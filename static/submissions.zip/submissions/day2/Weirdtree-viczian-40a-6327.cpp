/**
* user:  viczian-40a
* fname: András
* lname: Viczián
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:44:37.018970
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
using namespace std;
using ll = long long;

const int N = 80008;

#define ar array

struct node{
	ll sum=-1, mx=-1, mxpos=-1;
};

node neutral_elem;
node tree[4*N];

int a[N], n;

void merge(int x, int lx, int rx){
	if(tree[rx].mx > tree[lx].mx){
		tree[x].mx = tree[rx].mx;
		tree[x].mxpos = tree[rx].mxpos;
	}else{
		tree[x].mx = tree[lx].mx;
		tree[x].mxpos = tree[lx].mxpos;
	}
	tree[x].sum = tree[lx].sum + tree[rx].sum;
	return;
}

void build(int lx, int rx, int x){
	if(lx == rx){
		tree[x].sum = tree[x].mx = a[lx];
		tree[x].mxpos = lx;
		return;
	}

	int m = (lx + rx) / 2;
	build(lx, m, 2*x+1);
	build(m+1, rx, 2*x+2);
	merge(x, 2*x+1, 2*x+2);
}


node findmx(int l, int r, int lx, int rx, int x){
	if(lx > r || rx < l) return neutral_elem;
	if(lx >= l && rx <= r) return tree[x];

	int m = (lx + rx) / 2;
	node lv = findmx(l, r, lx, m, 2*x+1);
	node rv = findmx(l, r, m+1, rx, 2*x+2);
	return (rv.mx > lv.mx ? rv : lv);
}

ll q(int l, int r, int lx, int rx, int x){
	if(lx > r || rx < l) return 0LL;
	if(lx >= l && rx <= r) return tree[x].sum;

	int m = (lx + rx) / 2;
	return q(l, r, lx, m, 2*x+1) + q(l, r, m+1, rx, 2*x+2);
}

void mod(int pos, ll v, int lx, int rx, int x){
	if(lx == rx){
		assert(lx == pos);
		tree[x].sum = v;
		tree[x].mx = v;
		tree[x].mxpos = lx;
		return;
	}

	int m = (lx + rx) / 2;
	if(pos <= m) mod(pos, v, lx, m, 2*x+1);
	else mod(pos, v, m+1, rx, 2*x+2);

	merge(x, 2*x+1, 2*x+2);
}

void initialise(int N, int Q, int h[]) {
	n = N;
	for(int i = 1; i <= N; ++i) a[i] = h[i];
	build(1, n, 0);
	return;
}

void cut(int l, int r, int k) {
	assert(k==1);
	node x = findmx(l, r, 1, n, 0);
	if(x.mx > 0) mod(x.mxpos, x.mx-1, 1, n, 0);
	return;
}

void magic(int i, int x) {
	mod(i, x, 1, n, 0);
	return;
}

ll inspect(int l, int r) {
	return q(l, r, 1, n, 0);
}
