/**
* user:  patrushava-e4f
* fname: Hanna
* lname: Patrushava
* task:  Paths
* score: 12.0
* date:  2021-12-17 09:03:02.207296
*/
#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("unroll-loops")

#include <bits/stdc++.h>

#define pii pair<int, int>
#define f first
#define s second
#define pb push_back
#define ll long long

using namespace std;

const int N = 1e5 * 5;
vector < pii > g[N];
set < pair < ll, int > > s[N];

ll dfs(int v, int pr = -1) {
    ll d = 0;
    for (auto to: g[v]) {
        int u = to.f;
        if (u == pr)
            continue;
        int cost = to.s;
        ll dd = dfs(to.f, v);
        dd += cost;
        d = max(d, dd);
        s[v].insert({dd, to.f});
        if ((int)s[v].size() > 2) {
            s[v].erase(*s[v].begin());
        }
    }

    return d;
}

ll ans[N];
void calc(int v, ll dist = 0, int pr = -1)
{
    ans[v] = 0;
    if ((int)s[v].size() > 0)
    ans[v] = (*s[v].rbegin()).f;
    ans[v] = max(ans[v], dist);

    for (auto to: g[v])
    {
        if (to.f == pr) continue;
        int u = to.f;
        ll cost = to.s;
        ll dd = dist;

        pair < ll, int > p1 = *s[v].rbegin();
        pair < ll, int > p2 = *s[v].begin();
        if (p1.s == u) p1 = p2;
        if (p1.s != u)
        {
            dd = max(dd, p1.f);
        }

        dd += cost;
        calc(u, dd, v);
    }

    return;

}
int32_t main() {
#ifdef LOCAL
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
#endif // LOCAL


    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, k;
    cin >> n;
    cin >> k;

    for (int i = 0; i < n - 1; i++) {
        int x, y;
        cin >> x >> y;
        x--;
        y--;
        int c;
        cin >> c;
        g[x].pb({y, c});
        g[y].pb({x, c});
    }

    dfs(0);

    calc(0);

    for (int i = 0; i < n; i++) cout << ans[i] << "\n";
    return 0;
}


