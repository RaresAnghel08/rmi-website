/**
* user:  rodionov-7be
* fname: Valerii
* lname: Rodionov
* task:  Weirdtree
* score: 100.0
* date:  2021-12-17 10:06:55.713813
*/
#include "weirdtree.h"

#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int N = 300300;
const int INF = 1e9 + 100;

int n, q;
int h[N];

struct S {
	int mx, mx2, c;
	ll s;

	S() {}
	S(int mx, int mx2, int c, ll s) : mx(mx), mx2(mx2), c(c), s(s) {}
};

S merge(const S &l, const S &r) {
	S res;
	res.mx = max(l.mx, r.mx);
	res.mx2 = -1;
	for (int x : {l.mx, r.mx, l.mx2, r.mx2}) {
		if (x < res.mx && x > res.mx2) {
			res.mx2 = x;
		}
	}
	res.c = 0;
	if (l.mx == res.mx) {
		res.c += l.c;
	}
	if (r.mx == res.mx) {
		res.c += r.c;
	}
	res.s = l.s + r.s;
	return res;
}

S t[4 * N];
int d[4 * N];

void upd(int v) {
	t[v] = merge(t[2 * v], t[2 * v + 1]);
	d[v] = INF;
}

void apply(int v, int x) {
	d[v] = min(d[v], x);
	if (x < t[v].mx) {
		t[v].s -= 1ll * (t[v].mx - x) * t[v].c;
		t[v].mx = x;
	}
}

void push(int v) {
	apply(2 * v, d[v]);
	apply(2 * v + 1, d[v]);
	d[v] = INF;
}

void updmin(int v, int tl, int tr, int l, int r, int x) {
	if (tl >= r || tr <= l || t[v].mx <= x) {
		return;
	}
	if (tl >= l && tr <= r && t[v].mx > x && t[v].mx2 < x) {
		apply(v, x);
		return;
	} 
	push(v);
	int tm = (tl + tr) / 2;
	updmin(2 * v, tl, tm, l, r, x);
	updmin(2 * v + 1, tm, tr, l, r, x);
	upd(v);
}

void updpos(int v, int tl, int tr, int pos, int x) {
	if (tr - tl == 1) {
		t[v].mx = x;
		t[v].mx2 = -1;
		t[v].c = 1;
		t[v].s = x;
		d[v] = INF;
		return;
	}
	push(v);
	int tm = (tl + tr) / 2;
	if (pos < tm) {
		updpos(2 * v, tl, tm, pos, x);
	} else {
		updpos(2 * v + 1, tm, tr, pos, x);
	}
	upd(v);
}

void build(int v, int tl, int tr) {
	if (tr - tl == 1) {
		t[v].mx = h[tl];
		t[v].mx2 = -1;
		t[v].c = 1;
		t[v].s = h[tl];
		d[v] = INF;
	} else {
		int tm = (tl + tr) / 2;
		build(2 * v, tl, tm);
		build(2 * v + 1, tm, tr);
		upd(v);
	}
}

S get(int v, int tl, int tr, int l, int r) {
	if (tl >= r || tr <= l) {
		return {-1, -2, 0, 0};
	}
	if (tl >= l && tr <= r) {
		return t[v];
	}
	push(v);
	int tm = (tl + tr) / 2;
	return merge(get(2 * v, tl, tm, l, r), get(2 * v + 1, tm, tr, l, r));
}

void updk(int v, int tl, int tr, int l, int r, int &k, int mx) {
	if (tl >= r || tr <= l || k == 0 || t[v].mx < mx) {
		return;
	}
	if (tl >= l && tr <= r && t[v].c <= k) {
		k -= t[v].c;
		updmin(v, tl, tr, tl, tr, mx - 1);
		return;
	}
	push(v);
	int tm = (tl + tr) / 2;
	updk(2 * v, tl, tm, l, r, k, mx);
	updk(2 * v + 1, tm, tr, l, r, k, mx);
	upd(v);
}

void initialise(int NN, int QQ, int hh[]) {
	n = NN;
	q = QQ;
	for (int i = 0; i < n; ++i) {
		h[i] = hh[i + 1];
	}
	build(1, 0, n);
}

void cut(int l, int r, int k) {
	--l;
	while (k > 0) {
		S s = get(1, 0, n, l, r);

		if (s.mx == 0) {
			break;
		}

		if (k <= s.c) {
			updk(1, 0, n, l, r, k, s.mx);
			break;
		}

		int mx2 = max(s.mx2, 0);
		int z = min(k / s.c, s.mx - mx2);
		k -= z * s.c;
		updmin(1, 0, n, l, r, s.mx - z);
	}
	/*for (int i = 0; i < n; ++i) {
		cout << get(1, 0, n, i, i + 1).mx << " ";
	}
	cout << endl;*/
}

void magic(int i, int x) {
	--i;
	updpos(1, 0, n, i, x);
	h[i] = x;
}

ll inspect(int l, int r) {
	--l;
	S s = get(1, 0, n, l, r);
	return get(1, 0, n, l, r).s;
}
