/**
* user:  nikolov-3ed
* fname: Zdravko Svetlozarov
* lname: Nikolov
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 07:27:08.358865
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
using namespace std;
int n;
int tree[300001];
void initialise(int N, int Q, int h[])
{
    n=N;
    for(int i=1; i<=n; i++)
    {
        tree[i]=h[i];
    }
}
void cut(int l,int r,int k)
{
    for(int j=0; j<k; j++)
    {
        int maxi=0;
        int maxx=0;
        for(int i=l; i<=r; i++)
        {
            if(tree[i]>maxx)
            {
                maxx=tree[i];
                maxi=i;
            }
        }
        if(maxx>0)
        {
            tree[maxi]--;
        }
    }

}
void magic(int i, int x)
{
    tree[i]=x;
}
long long inspect(int l, int r)
{
    long long sum=0;
    for(int i=l;i<=r;i++)
    {
        sum+=(long long)(tree[i]);
    }
    return sum;
}
