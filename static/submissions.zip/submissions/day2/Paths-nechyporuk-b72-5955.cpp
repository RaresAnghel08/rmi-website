/**
* user:  nechyporuk-b72
* fname: Vladyslav
* lname: Nechyporuk
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:13:59.891089
*/
#pragma GCC optimize("Ofast")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")


#include <bits/stdc++.h>
//#define int long long
#define ll long long
#define fr(i,x,y) for(int i=x;i<y;i++)
using namespace std;
const ll N=1e6+3,INF=1e9;

vector<pair<int,int> > gr[N];
int dp[N];
int to[N];
int ans[N];
//set<pair<ll,int> > och;
void dfs(int v,int pr=-1)
{
    dp[v]=0;
    for(auto j:gr[v])
    {
        if(j.first==pr)continue;
        dfs(j.first,v);
        if(dp[v]<dp[j.first]+j.second)
        {
            dp[v]=dp[j.first]+j.second;
            to[v]=j.first;
        }
        //cout<<v<<' '<<dp[v][dp[v].size()-1].first<<' '<<dp[v][dp[v].size()-1].second<<'\n';
    }

    //cout<<v<<' '<<dp[v]<<'\n';
    //och.insert({-dp[v],v});
}
void dfs2(int v,int pr=-1)
{
    int res=0;
    int was=dp[v];
    int wasto=to[v];
    for(auto j:gr[v])
    {
        if(dp[v]<dp[j.first]+j.second)
        {
            dp[v]=dp[j.first]+j.second;
            to[v]=j.first;
        }
        int was=dp[v];
        if(j.first==to[v])
        {
            dp[v]=0;
            to[v]=-1;
            for(auto z:gr[v])
            {
                if(z.first==j.first)continue;
                if(dp[v]<dp[z.first]+z.second)
                {
                    dp[v]=dp[z.first]+z.second;
                    //to[v]=z.first;
                }
            }
        }
        if(j.first!=pr)dfs2(j.first,v);
        dp[v]=was;

    }
    ans[v]=dp[v];
    dp[v]=was;
    to[v]=wasto;
}
int n,k;
signed main()
{
    ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    cin>>n>>k;
    fr(i,0,n-1)
    {
        int a,b,c;
        cin>>a>>b>>c;
        gr[a].push_back({b,c});
        gr[b].push_back({a,c});
    }
    dfs(1);
    dfs2(1);
    fr(i,1,n+1)cout<<ans[i]<<'\n';

}
/*
6 20
479001600


3628800 10
3225600 9
2880000 8
*/
