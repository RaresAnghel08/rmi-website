/**
* user:  yacouel-598
* fname: Assaf
* lname: Yacouel
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:43:24.091620
*/
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
typedef long long ll;
typedef vector<ll> vi;
typedef pair<ll, ll> pll;
typedef vector<pll> vpl;
typedef vector<vpl> vvp;
typedef vector<vi> vvi;
//vvi ans;
//vvp adj;
//vi visited, vm, vindm;
//ll n, k, c1, x1, y;
vi bin(ll n, int len) {
    ll m = n;
    vi ans = {};
    while (m > 0) {
        ans.push_back(m % 2);
        m /= 2;
    }
    while (ans.size() < len) ans.push_back(0);
    return ans;
}
/*void dfs1(int node) {
    visited[node] = 1;
    ll m;
    int v;
    for (int i = 0; i < adj[node].size(); i++) {
        v = adj[node][i].first;
        if (!visited[v]) {
            dfs1(v);
            m = 0;
            for (int j = 0; j < ans[v].size(); j++) {
                m = max(m, ans[v][j]);
            }
            ans[node][i] = m + adj[node][i].second;
        }
    }
    ll mnode = 0, indm = 0;
    for (int i = 0; i < adj[node].size(); i++) {
        if (ans[node][i] > mnode) {
            mnode = ans[node][i];
            indm = adj[node][i].first;
        }
    }
    vm[node] = mnode, vindm[node] = indm;
}*/
/*void dfs2(int node) {
    visited[node] = 1;
    int v;
    for (int i = 0; i < adj[node].size(); i++) {
        v = adj[node][i].first;
        if (visited[v]) {
            if (vindm[v] != node) {
                ans[node][i] = vm[v] + adj[node][i].second;
            }
            else {
                for (int j = 0; j < adj[v].size(); j++) {
                    if (adj[v][j].first != node) if (ans[v][j] + adj[node][i].second > ans[node][i]) ans[node][i] = ans[v][j]+ adj[node][i].second;
                }
            }
            if (vm[node] < ans[node][i]) {
                vm[node] = ans[node][i];
                vindm[node] = v;
            }
        }
    }
    for (int i = 0; i < adj[node].size(); i++) {
        v = adj[node][i].first;
        if (!visited[v]) {
            dfs2(v);
        }
    }
}*/
int main()
{
    cin.tie(0);
    ios::sync_with_stdio(false);
    /*cin >> n >> k;
    for (int i = 0; i < n; i++) {
        ans.push_back({});
        visited.push_back(0);
        adj.push_back({});
        vm.push_back(0);
        vindm.push_back(-1);
    }
    for (int i = 0; i < n - 1; i++) {
        cin >> x1 >> y >> c1;
        x1--;
        y--;
        adj[x1].push_back({ y,c1 });
        adj[y].push_back({ x1,c1 });
        ans[x1].push_back(0);
        ans[y].push_back(0);
    }
    dfs1(0);
    for (int i = 0; i < n; i++) {
        visited[i] = 0;
    }
    ll m0 = 0, indm = -1;
    for (int i = 0; i < adj[0].size(); i++) {
        if (ans[0][i] > m0) {
            m0 = ans[0][i];
            indm = adj[0][i].first;
        }
    }
    vm[0] = m0, vindm[0] = indm;
    dfs2(0);
    for (int i = 0; i < n; i++) cout << vm[i] << " ";*/
    int n, m;
    bool b = true;
    ll ans = 0;
    cin >> n >> m;
    vi per = {};
    for (int i = 1; i <= 2 * n; i++) per.push_back(i);
    while (next_permutation(per.begin(), per.end())) {
        b = true;
        for (int j = 0; j < 2 * n; j++) {
            for (int k = j + m; k < 2 * n; k += m) {
                if ((per[j] - per[k]) % n == 0) {
                    b = false;
                }
            }
        }
        ans += b;
    }
    if (n % m) ans++;
    cout << ans;
}