/**
* user:  mihov-f9a
* fname: Boris Vladimirov
* lname: Mihov
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 09:46:51.203671
*/
#include "weirdtree.h"
#include <iostream>
#include <algorithm>
using namespace std;
const int maxn = 3e5+10;
typedef long long llong;
llong a[maxn], b[maxn], n;

bool cmp(llong x, llong y) {

	return (a[x] > a[y] || (a[x] == a[y] && x < y));

}

void initialise(int N, int Q, int h[]) {
	// Your code here.
	n = N;
	for (llong i = 1 ; i <= n ; ++i)
		a[i] = h[i];

}
void cut(int l, int r, int k) {

	// cout << "cut: " << l << ' ' << r << ' ' << k << '\n';

	// Your code here.
	for (llong i = l ; i <= r ; ++i)
		b[i] = i;
	sort(b+l, b+r+1, cmp);
	b[r+1] = 0;

	for (llong i = l ; i <= r ; ++i) {

		// cout << "cut: " << a[b[i]] << ' ' << a[b[i+1]] << ' ' << k << ' ' << (i-l+1)*(a[b[i]] - a[b[i+1]]) << '\n';
		if (k >= (i-l+1)*(a[b[i]] - a[b[i+1]])) {

			k -= (i-l+1)*(a[b[i]] - a[b[i+1]]);

			if (i == r) {

				for (llong j = l ; j <= r ; ++j)
					a[j] = 0;

			}
			continue;

		}

		// cout << "done cutting: " << i << ' ' << a[b[i]] << ' ' << a[b[i+1]] << ' ' << k << '\n';

		for (llong j = i ; j >= l ; --j) a[b[j]] = a[b[i]] - (k/(i-l+1));
		k %= (i-l+1);
		sort(b+l, b+i+1, cmp);
		for (llong j = l ; j <= l+k-1 ; ++j)
			--a[b[j]];

		break;

	}

	// cout << "after:\n";
	// for (llong i = 1 ; i <= n ; ++i)
	// 	cout << a[i] << ' ';
	// cout << '\n';

}
void magic(int i, int x) {
	a[i] = x;
	// Your code here.
}
long long int inspect(int l, int r) {
	llong sum = 0;
	for (llong i = l ; i <= r ; ++i)
		sum += a[i];
	// Your code here.
	return sum;
}
