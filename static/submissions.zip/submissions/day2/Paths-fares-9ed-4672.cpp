/**
* user:  fares-9ed
* fname: Yusuf
* lname: Fares
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:22:54.643861
*/
#include <bits/stdc++.h>
#define NMAX 2000
#define int64 long long

using namespace std;

struct strmuchie {
  int price;
  int son;
};

struct strsort {
  int val, index;
};

bool f[NMAX + 1];
strsort vlevel[NMAX + 1];
int vlca[NMAX + 1][NMAX + 1], vtata[NMAX + 1];
int64 vprice[NMAX + 1];
vector <strmuchie> vsons[NMAX + 1];

void dfs(int node, int price, int level) {
  int n, i;

  f[node] = 1;
  vprice[node] = price;
  vlevel[node].val = level;
  vlevel[node].index = node;
  n = vsons[node].size();
  for (i = 0; i < n; i++) {
    if (f[vsons[node][i].son] == 0) {
      vtata[vsons[node][i].son] = node;
      dfs(vsons[node][i].son, price + vsons[node][i].price, level + 1);
    }
  }
}

bool cmp(strsort A, strsort B) {
  return A.val < B.val;
}

int main() {
  int n, k, x, y, z, node, i, j, root, node1, node2, ck, nodechange;
  int64 max1, sol;
  cin >> n >> k;

  for (i = 0; i < n - 1; i++) {
    cin >> x >> y >> z;
    vsons[x].push_back({z, y});
    vsons[y].push_back({z, x});
  }

  for (root = 1; root <= n; root++) {
    dfs(root, 0, 1);
    sort(vlevel + 1, vlevel + n + 1, cmp);
    for (i = 1; i <= n; i++) {
      vlca[vlevel[i].index][vlevel[i].index] = vlevel[i].index;
      for (j = i + 1; j <= n; j++) {
        if (vlevel[i].val == vlevel[j].val) {
          node1 = vlevel[i].index;
          node2 = vlevel[j].index;
          vlca[node1][node2] = vlca[node2][node1] = vlca[vtata[node1]][vtata[node2]];
        }
        else {
          node1 = vlevel[i].index;
          node2 = vlevel[j].index;
          vlca[node1][node2] = vlca[node2][node1] = vlca[node1][vtata[node2]];
        }
      }
    }

    ck = k;
    sol = 0;
    while (ck--) {
      max1 = 0;
      for (i = 1; i <= n; i++) {
        if (vprice[i] > max1)
          max1 = vprice[i], node = i;
      }
      sol += max1;

      for (i = n; i >= 1; i--) {
        nodechange = vlevel[i].index;
        vprice[nodechange] -= vprice[vlca[nodechange][node]];
      }
    }

    cout << sol << "\n";

    for (i = 1; i <= n; i++)
      vprice[i] = 0, f[i] = 0;
  }
  return 0;
}
