/**
* user:  mihov-11b
* fname: Rumen
* lname: Mihov
* task:  Paths
* score: 12.0
* date:  2021-12-17 11:23:28.648705
*/
# include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e6+5;
vector <pair <long long,long long> > g[maxn];
long long ins[maxn],outs[maxn],ids;
long long len[maxn],per[maxn],w[maxn];
long long T[maxn],vis[maxn];
void dfs(long long v, long long par,long long sz)
{
    ids++;
    vis[v] = 1;
    ins[v]=ids;
    T[ids] = v;
    len[v] = sz;
    per[v] = par;
    for(auto u:g[v])
    {
        if(u.first!=par){w[u.first] = u.second;dfs(u.first,v,u.second+sz);}

    }
    outs[v] = ids;
}
struct Segment
{
    long long segm[maxn],id[maxn],lazy[maxn];
    void build(long long v, long long l, long long r)
    {
        lazy[v] = 0;
        if(l==r)
        {
            segm[v]  =len[T[l]];
            id[v] = T[l];
            //cout<<v<<" "<<l<<" ** "<<segm[v]<<" "<<id[v]<<endl;
            return ;
        }
        long long mid = (l+r)/2;
        build(2*v,l,mid);
        build(2*v+1,mid+1,r);
        if(segm[2*v]>=segm[2*v+1])
        {
            segm[v]=segm[2*v];
            id[v] = id[2*v];
        }
        else
        {
            segm[v]=segm[2*v+1];
            id[v] = id[2*v+1];
        }
    }
    void update_lazy(long long v, long long from, long long to)
    {
        if(lazy[v]==0)return ;
        if(from==to)
        {
            segm[v]-=lazy[v];
            lazy[v]= 0;
            return ;
        }
        lazy[2*v]+=lazy[v];
        lazy[2*v+1]+=lazy[v];
        segm[v]-=lazy[v];
        lazy[v] =0;
        return ;
    }
    void update(long long v, long long from, long long to, long long l, long long r, long long delta)
    {
          //  cout<<v<<"::: "<<lazy[v]<<endl;
        update_lazy(v,from,to);//cout<<v<<" "<<from<<" "<<to<<" "<<l<<" "<<r<<" "<<delta<<" ::: "<<segm[v]<<" - "<<id[v]<<endl;
        if(l<=from&&to<=r)
        {
            lazy[v]+=delta;
            update_lazy(v,from,to);
            //cout<<v<<" -> "<<segm[v]<<" "<<id[v]<<endl;
            return ;
        }
        long long mid=  (from+to)/2;
        if(l<=mid)update(2*v,from,mid,l,r,delta);
        if(r>mid)update(2*v+1,mid+1,to,l,r,delta);
        update_lazy(2*v,from,mid);
        update_lazy(2*v+1,mid+1,to);
        if(segm[2*v]>=segm[2*v+1])
        {
            segm[v]=segm[2*v];
            id[v] = id[2*v];
        }
        else
        {
            segm[v]=segm[2*v+1];
            id[v] = id[2*v+1];
        }
       // cout<<v<<" ::" <<segm[v]<<" "<<id[v]<<endl;
    }
    void print(long long v, long long l, long long r)
    {
        update_lazy(v,l,r);
       // cout<<v<<" "<<l<<" "<<r<<" ::: "<<segm[v]<<" "<<id[v]<<endl;
        if(l==r)return ;
        long long mid= (l+r)/2;
        print(2*v,l,mid);
        print(2*v+1,mid+1,r);
    }

};
Segment S;
long long maxans[maxn];
long long ANS[maxn];
void dfs2(long long v, long long par)
{
    for(auto u: g[v])
    {
        if(u.first==par)continue;
        dfs2(u.first,v);
        maxans[v] = max(maxans[u.first]+u.second,maxans[v]);
    }
}
void dfs3(long long v, long long par)
{
    ANS[v] = maxans[v];
    long long ff=0,ss=0,id1,id2;
    for(auto u: g[v])
    {
      //  if(u.first==par)continue;
        if(maxans[u.first]+u.second>=ff)
        {
            id2 = id1;
            id1=  u.first;
            ss=ff;
            ff = maxans[u.first]+u.second;
        }
        else
        {
            if(maxans[u.first]+u.second>=ss)
            {
                id2=u.first;
                ss=maxans[u.first]+u.second;
            }
        }

    }
      for(auto u: g[v])
    {
        if(u.first==par)continue;
        long long old = maxans[v];
        long long tt = maxans[u.first];
        if(id1==u.first)
        {
            maxans[v] = ss;
        }
      //  cout<<v<<" "<<u.first<<" "<<maxans[v]<<endl;
        maxans[u.first] = max(maxans[v]+u.second,maxans[u.first]);
        dfs3(u.first,v);
        maxans[v]  = old;
        maxans[u.first] = tt;
    }
    return ;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n,k,i,j,u,v,c;
    cin>>n>>k;
    for(i=1;i<n;i++)
    {
        cin>>u>>v>>c;
        g[u].push_back({v,c});
        g[v].push_back({u,c});
    }
    dfs2(1,-1);
    dfs3(1,-1);
    for(i=1;i<=n;i++)
        cout<<ANS[i]<<endl;
    /*for(i =1;i<=n;i++)
    {
       // cout<<"*******************"<<i<<endl;
        ids = 0;
        dfs(i,-1,0);
        S.build(1,1,n);

         long long sum = 0;
        for(j = 1;j<=k;j++)
        {
            long long k = S.id[1];
            long long t = S.segm[1];
            sum+=t;
           // cout<<k<<" && "<<t<<endl;
            while(k!=i&&vis[k])
            {//cout<<k<<endl;
                S.update(1,1,n,ins[k],outs[k],w[k]);
                vis[k] = 0;
              //  S.prlong long(1,1,n);
                k = per[k];
            }
          //  cout<<"Ok"<<endl;
        }
       // cout<<"&&&&&&&&"<<endl;
        cout<<sum<<endl;
    }*/
    return 0;
}
