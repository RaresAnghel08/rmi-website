/**
* user:  georgiev-51d
* fname: Aleksandar Petrov
* lname: Georgiev
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:14:49.421195
*/
#include<bits/stdc++.h>
#define mod 1000000007
using namespace std;
int a[500];
int main()
{
    int n,m,br=0;
    cin>>n>>m;
    for(int i=0;i<2*n;i++)
    {
        a[i]=i%n+1;
    }
    do
    {
        bool t=0;
        /*for(int i=0;i<2*n;i++)
        {
            cout<<a[i]<<" ";
        }*/
        for(int i=0;i<2*n-m;i++)
        {

            int p=m;
            for(int p=m;p+i<2*n;p+=m)
            {
                //cout<<p<<endl;
                if(a[i]==a[p+i])
                {
                    t=1;
                    break;
                }
            }
            if(t==1)break;
        }
        if(t==0)br=(br+1)%mod;
    }
    while(next_permutation(a,a+2*n));
    cout<<br<<endl;
}
