/**
* user:  bozhkov-3b7
* fname: Denis Petrov
* lname: Bozhkov
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:04:50.223798
*/
#include<iostream>
#include<cstring>
using namespace std;
#define MOD 1000000007
#define MAXN 4000
int main()
{
	int N,M;
	cin>>N>>M;
	int N2=2*N;
	long long diff=0LL;
	long long tmp;
	long long res=1LL;
	int t;
	long long P[MAXN];
	memset(P,0LL,sizeof(P));
	for(int i=0;i<N2;i++)
	{
		P[i]+=N2-i;
		for(int j=i+M;j<N;j+=M)
			P[j]--;
	}
	for(int i=0;i<N2;i++)
		res=(P[i]*res)%MOD;
	cout<<res<<endl;
	return 0;
}
//171243255