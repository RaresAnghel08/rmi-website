/**
* user:  hadzhi-manich-e4f
* fname: Deyan Deyanov
* lname: Hadzhi-Manich
* task:  Paths
* score: 56.0
* date:  2021-12-17 10:27:03.081459
*/
#include<bits/stdc++.h>
using namespace std;
#pragma GCC optimize ("Ofast")
#pragma GCC target ("avx,avx2,fma")
#define ll long long
const int MAXN=1e5+6;
vector<pair<int,ll> >g[MAXN];
int st[MAXN];
int n,k;
ll time_in[MAXN],time_out[MAXN],timenow;
void dfs_init(int u,int p)
{
	st[u]=1;
	for(auto xd:g[u])
	{
		if(xd.first==p)continue;
		dfs_init(xd.first,u);
		st[u]+=st[xd.first];
	}
}
void dfs(int u,int p,priority_queue<pair<ll,int> > &pq)
{
	int bch,maxst=-1;
	for(auto xd:g[u])
	{
		if(xd.first==p)continue;
		if(st[xd.first]>maxst)
		{
			maxst=st[xd.first];
			bch=xd.first;
		}
	}
	if(maxst==-1)
	{
		pq.push({0,u});
		return;
	}
	for(auto xd:g[u])
	{
		if(xd.first==p)continue;
		if(xd.first==bch)
		{
			dfs(xd.first,u,pq);
			pair<ll,int> lol=pq.top();
			pq.pop();
			pq.push({lol.first+xd.second,lol.second});
		}
		/*else
		{
			priority_queue<ll>tmp;
			dfs(xd.first,u,tmp);
			ll lol=tmp.top();
			tmp.pop();
			tmp.push(lol+xd.second);
			while(!tmp.empty())
			{
				ll dx=tmp.top();tmp.pop();
				pq.push(dx);
			}
		}*/
	}
	for(auto xd:g[u])
	{
		if(xd.first==p)continue;
		if(xd.first==bch)continue;
		else
		{
			priority_queue<pair<ll,int> >tmp;
			dfs(xd.first,u,tmp);
			pair<ll,ll> lol=tmp.top();
			tmp.pop();
			tmp.push({lol.first+xd.second,lol.second});
			while(!tmp.empty())
			{
				pair<ll,ll> dx=tmp.top();tmp.pop();
				pq.push(dx);
			}
		}
	}
	pq.push({0,u});
}
struct segmen_tree_easy
{
	pair<ll,ll> tree[3*MAXN];
	void update(int l,int r,int idx,int pos,ll val)
	{
		if(l>pos)return;
		if(r<pos)return;
		if(l==r)
		{
			tree[idx].first+=val;
			tree[idx].second=l;
			return;
		}
		int mid=(l+r)/2;
		update(l,mid,idx*2,pos,val);
		update(mid+1,r,idx*2+1,pos,val);
		tree[idx]=max(tree[idx*2],tree[idx*2+1]);
	}
	pair<ll,ll> query(int l,int r,int idx,int ql,int qr)
	{
		if(l>=ql&&r<=qr)return tree[idx];
		int mid=(l+r)/2;
		if(qr<=mid)return query(l,mid,idx*2,ql,qr);
		if(ql>mid)return query(mid+1,r,idx*2+1,ql,qr);
		return max(query(l,mid,idx*2,ql,qr),query(mid+1,r,idx*2+1,ql,qr));
	}
}t;
//i se molq na vsi4ki bogove
void dfs_faster_than_the_flame(int u,int p)
{
	//cout<<u<<" "<<p<<endl;
	for(auto xd:g[u])
	{
		if(xd.first==p)continue;
		dfs_faster_than_the_flame(xd.first,u);
		//cout<<"query ?"<<endl;
		pair<ll,ll> best = t.query(1,n,1,time_in[xd.first],time_out[xd.first]);
		//cout<<"query !\n";
		t.update(1,n,1,best.second,xd.second);
	}
	//cout<<"eho?\n";
	t.update(1,n,1,time_in[u],0);
}
struct tnode
{
	pair<ll,int> max_node,min_node;
	bool marked;
	pair<ll,int> min_marked_node;
};
tnode merge(tnode t1,tnode t2)
{
	t1.max_node=max(t1.max_node,t2.max_node);
	t1.min_node=min(t1.min_node,t2.min_node);
	t1.min_marked_node=min(t1.min_marked_node,t2.min_marked_node);
	t1.marked=0;
	return t1;
}
struct segment_tree
{
	tnode tree[3*MAXN];
	void update(int l,int r,int idx,int pos,ll val)
	{
		if(l>pos)return;
		if(r<pos)return;
		if(l==r)
		{
			tree[idx].max_node.first+=val;
			tree[idx].max_node.second=pos;
			tree[idx].min_node.second=pos;
			tree[idx].min_node.first+=val;
			if(tree[idx].marked)tree[idx].min_marked_node=tree[idx].min_node;
			else tree[idx].min_marked_node = {(ll)1e9,(ll)1e9};
			return;
		}
		int mid=(l+r)/2;
		if(pos<=mid)update(l,mid,idx*2,pos,val);
		if(pos>mid)update(mid+1,r,idx*2+1,pos,val);
		tree[idx]=merge(tree[idx*2],tree[idx*2+1]);
	}
	void mark(int l,int r,int idx,ll pos)
	{
		if(l>pos)return;
		if(r<pos)return;
		if(l==r)
		{
			tree[idx].marked=1;
			if(tree[idx].marked)tree[idx].min_marked_node=tree[idx].min_node;
			else tree[idx].min_marked_node = {(ll)1e9,(ll)1e9};
			return;
		}
		int mid=(l+r)/2;
		if(pos<=mid)mark(l,mid,idx*2,pos);
		if(pos>mid)mark(mid+1,r,idx*2+1,pos);
		tree[idx]=merge(tree[idx*2],tree[idx*2+1]);
	}
	void unmark(int l,int r,int idx,ll pos)
	{
		if(l>pos)return;
		if(r<pos)return;
		if(l==r)
		{
			tree[idx].marked=0;
			if(tree[idx].marked)tree[idx].min_marked_node=tree[idx].min_node;
			else tree[idx].min_marked_node = {(ll)1e9,(ll)1e9};
			return;
		}
		int mid=(l+r)/2;
		if(pos<=mid)unmark(l,mid,idx*2,pos);
		if(pos>mid)unmark(mid+1,r,idx*2+1,pos);
		tree[idx]=merge(tree[idx*2],tree[idx*2+1]);
	}
	bool is_marked(int l,int r,int idx,ll pos)
	{
		if(l==r)return tree[idx].marked;
		int mid=(l+r)/2;
		if(pos<=mid)return is_marked(l,mid,idx*2,pos);
		else return is_marked(mid+1,r,idx*2+1,pos);
	}
	tnode query(int l,int r,int idx,int ql,int qr)
	{
		if(l>=ql&&r<=qr)return tree[idx];
		int mid=(l+r)/2;
		if(ql>mid)return query(mid+1,r,idx*2+1,ql,qr);
		if(qr<=mid)return query(l,mid,idx*2,ql,qr);
		return merge(query(l,mid,idx*2,ql,qr),query(mid+1,r,idx*2+1,ql,qr));
	}
}drvo;
struct treap
{
	struct node
	{
		node *l,*r;
		pair<ll,int> content;
		int pr;
		ll sum;
		int width;
		node(){
			l=nullptr;r=nullptr;
			content={0,0};
			pr=rand()*rand()*rand()-rand()*rand()+rand();
		}
		node(pair<ll,ll> p)
		{
			l=nullptr;r=nullptr;
			content=p;width=1;
			sum=p.first;
			pr=rand()*rand()*rand()-rand()*rand()+rand();
		}
	};
	typedef node* pnode;
	pnode root=nullptr;
	ll sum(pnode t)
	{
		if(t)return t->sum;
		else return 0;
	}
	int width(pnode t)
	{
		if(t)return t->width;
		else return 0;
	}
	void recalc(pnode t1)
	{
		if(!t1)return;
		t1->sum=t1->content.first+sum(t1->l)+sum(t1->r);
		t1->width=1+width(t1->l)+width(t1->r);
	}
	pnode merge(pnode t1,pnode t2)
	{
		if(!t1)return t2;
		if(!t2)return t1;
		if(t1->pr>t2->pr)
		{
			t1->r=merge(t1->r,t2);
			recalc(t1);
			recalc(t2);
			return t1;
		}
		else
		{
			t2->l=merge(t1,t2->l);
			recalc(t1);
			recalc(t2);
			return t2;
		}
	}
	pair<pnode,pnode> split(pnode t,pair<ll,int> k)
	{
		if(!t)return {nullptr,nullptr};
		if(t->content<=k)
		{
			pair<pnode,pnode> lol=split(t->r,k);
			t->r=lol.first;
			recalc(t);
			recalc(lol.second);
			return {t,lol.second};
		}
		else
		{
			pair<pnode,pnode> lol=split(t->l,k);
			t->l=lol.second;
			recalc(t);
			recalc(lol.first);
			return {lol.first,t};
		}
	}
	pair<pnode,pnode> split_by_cnt(pnode t,int k)
	{
		if(!t)return {nullptr,nullptr};
		if(k==0)return {nullptr,t};
		if(k>=width(t))return {t,nullptr};
		if(width(t->l)>=k)
		{
			pair<pnode,pnode> lol=split_by_cnt(t->l,k);
			t->l=lol.second;
			recalc(t);
			recalc(lol.first);
			return {lol.first,t};
		}
		else
		{
			pair<pnode,pnode> lol=split_by_cnt(t->r,k-width(t->l)-1);
			t->r=lol.first;
			recalc(t);
			recalc(lol.second);
			return {t,lol.second};
		}
	}
	ll query(int cnt)
	{
		int all=width(root);
		//cout<<all<<endl;
		pair<pnode,pnode> lol=split_by_cnt(root,all-cnt);
		//cout<<all-cnt<<endl;
		ll ret=sum(lol.second);
		//cout<<"printing treap\n";
		//print(lol.first);
		//cout<<"-------\n";
		//print(lol.second);
		root=merge(lol.first,lol.second);
		return ret;
	}
	void add(pair<ll,int> val)
	{
		pair<pnode,pnode> lol=split(root,val);
		pair<pnode,pnode> lol1=split(lol.second,val);
		lol1.first = new node(val);
		root=merge(lol.first,merge(lol1.first,lol1.second));
	}
	void remove(pair<ll,int> val)
	{
		pair<pnode,pnode> lol1=split(root,{val.first,val.second-1});
		pair<pnode,pnode> lol2=split(lol1.second,val);
		lol2.first = nullptr;
		root=merge(lol1.first,lol2.second);
	}
	void print(pnode t)
	{
		if(!t)return;
		cout<<t->width<<" "<<t->sum<<" "<<t->content.first<<","<<t->content.second<<endl;
		print(t->l);
		print(t->r);
	}
}tr;
void dfs_euler(int u,int p)
{
	++timenow;
	time_in[u]=timenow;
	for(auto xd:g[u])
	{
		if(xd.first==p)continue;
		dfs_euler(xd.first,u);
	}
	time_out[u]=timenow;
}
ll ans1=0,delta;
ll output[MAXN];
void dfs_answer_all(int u,int p)
{
	//cout<<u<<" "<<p<<endl;
	//cout<<"--------------\n";
	//tr.print(tr.root);
	output[u]=tr.query(k);
	//output[u]=ans1+delta-drvo.query(1,n,1,1,n).min_marked_node.first;
	for(auto xd:g[u])
	{
		if(xd.first==p)continue;
		ll len=xd.second;
		int l=time_in[xd.first],r=time_out[xd.first];
		vector<pair<ll,int> >to_rollback;
		vector<pair<ll,int> >to_remove;
		vector<pair<ll,int> >to_add;
		tnode lol=merge(drvo.query(1,n,1,1,l-1),drvo.query(1,n,1,r+1,n));
		tr.remove(lol.max_node);
		//cout<<"remove 1\n";
		//tr.print(tr.root);
		to_add.push_back(lol.max_node);
		tr.add({lol.max_node.first+len,lol.max_node.second});
		//cout<<"add 1\n";
		//tr.print(tr.root);
		to_remove.push_back({lol.max_node.first+len,lol.max_node.second});
		drvo.update(1,n,1,lol.max_node.second,+len);
		/*if(drvo.is_marked(1,n,1,lol.max_node.second))
		{
			delta+=len;
			delta_rollback-=len;
		}*/
		to_rollback.push_back({lol.max_node.second,-len});
		lol=drvo.query(1,n,1,l,r);
		drvo.update(1,n,1,lol.max_node.second,-len);
		tr.remove(lol.max_node);
		//cout<<"remove 2\n";
		//tr.print(tr.root);
		to_add.push_back(lol.max_node);
		tr.add({lol.max_node.first-len,lol.max_node.second});
		//cout<<"add 2\n";
		//tr.print(tr.root);
		to_remove.push_back({lol.max_node.first-len,lol.max_node.second});
		/*if(drvo.is_marked(1,n,1,lol.max_node.second))
		{
			delta-=len;
			delta_rollback+=len;
		}*/
		to_rollback.push_back({lol.max_node.second,+len});
		dfs_answer_all(xd.first,u);
		for(auto gg:to_rollback)
		{
			drvo.update(1,n,1,gg.first,gg.second);
		}
		for(auto gg:to_remove)
		{
			tr.remove(gg);
		}
		for(auto gg:to_add)
		{
			tr.add(gg);
		}
		//delta+=delta_rollback;
	}
}
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	cin>>n>>k;
	for(int i=1;i<n;++i)
	{
		int x,y,z;
		cin>>x>>y>>z;
		g[x].push_back({y,z});
		g[y].push_back({x,z});
	}
	priority_queue<pair<ll,int> >frog;
	dfs_init(1,0);
	//dfs(1,0,frog);
	dfs_euler(1,0);
	dfs_faster_than_the_flame(1,0);
	for(int i=1;i<=n;i++)
	{
		frog.push(t.query(1,n,1,i,i));
	}
	int cnt=0;
	while(!frog.empty())
	{
		pair<ll,int> pp=frog.top();frog.pop();
		drvo.update(1,n,1,pp.second,pp.first);
		tr.add({pp.first,pp.second});
		cnt++;
		if(cnt<=k+1)
		{
			drvo.mark(1,n,1,pp.second);
			ans1+=pp.first;
		}	
		else drvo.unmark(1,n,1,pp.second);
		//cout<<pp.first<<" "<<time_in[pp.second]<<endl;
		//cout<<"-------------------\n";
		//tr.print(tr.root);
	}
	//tr.print(tr.root);
	dfs_answer_all(1,0);
	for(int i=1;i<=n;++i)
	{
		cout<<output[i]<<'\n';
	}
return 0;
}
