/**
* user:  dumitrescu-d88
* fname: Eduard Valentin
* lname: Dumitrescu
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:37:50.319266
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

//std::ifstream fin("wt.in");

// #define fin std::cin
#define fout std::cout

#define maxn 100005

long long sum[4*maxn];
int max[4*maxn], pmax[4*maxn];

int x[maxn];

void build(int node, int left, int right) {
    if(left == right) {
        sum[node] = x[left];
        max[node] = x[left];
        pmax[node] = left;
        return;
    }
    int mid = (left + right) / 2;
    build(2*node+1, left, mid);
    build(2*node+2, mid+1, right);
    sum[node] = sum[2*node+1] + sum[2*node+2];
    if(max[2*node+1] >= max[2*node+2]) {
        max[node] = max[2*node+1];
        pmax[node] = pmax[2*node+1];
    }
    else {
        max[node] = max[2*node+2];
        pmax[node] = pmax[2*node+2];
    }
}

std::pair <int, int> qmax(int node, int left, int right, int l, int r) {
    if(l <= left and right <= r) {
        return {max[node], pmax[node]};
    }
    if(left > r or right < l)
        return {-1, 0};

    int mid = (left + right) / 2;

    auto p1 = qmax(2*node+1, left, mid, l, r);
    auto p2 = qmax(2*node+2, mid+1, right, l, r);
    if(p1.first >= p2.first)
        return p1;
    else return p2;
}

void reduce(int node, int left, int right, int pos) {
    if(left == right) {
        max[node] --;
        sum[node] --;
        return;
    }
    
    if(max[node] == 0)
        return;  

    int mid = (left + right) / 2;
    
    if(mid >= pos)
        reduce(2*node+1, left, mid, pos);
    else reduce(2*node+2, mid+1, right, pos);

    sum[node] = sum[2*node+1] + sum[2*node+2];
    if(max[2*node+1] >= max[2*node+2]) {
        max[node] = max[2*node+1];
        pmax[node] = pmax[2*node+1];
    }
    else {
        max[node] = max[2*node+2];
        pmax[node] = pmax[2*node+2];
    }
}

void update(int node, int left, int right, int pos, int val) {
    if(left == right) {
        max[node] = val;
        sum[node] = val;
        return;
    }
    int mid = (left + right) / 2;
    if(mid >= pos)
        update(2*node+1, left, mid, pos, val);
    else
        update(2*node+2, mid+1, right, pos, val);

    sum[node] = sum[2*node+1] + sum[2*node+2];
    if(max[2*node+1] >= max[2*node+2]) {
        max[node] = max[2*node+1];
        pmax[node] = pmax[2*node+1];
    }
    else {
        max[node] = max[2*node+2];
        pmax[node] = pmax[2*node+2];
    }
}

long long query(int node, int left, int right, int l, int r) {
    if(l <= left and right <= r)
        return sum[node];
    if(right < l or left > r)
        return 0;
    int mid = (left + right) / 2;
    return query(2*node+1, left, mid, l, r) + query(2*node+2, mid+1, right, l, r);
}
int n;

void initialise(int N, int Q, int h[]) {
    n = N;
	for(int i = 0; i < N; i ++)
        x[i] = h[i+1];
    build(0, 0, N-1);
}

void cut(int l, int r, int k) {
	while(k--) {
        auto p = qmax(0, 0, n-1, l-1, r-1);
        if(p.first == 0)
            break;
        reduce(0, 0, n-1, p.second);
    }
}
void magic(int i, int x) {
	update(0, 0, n-1, i-1, x);
}
long long int inspect(int l, int r) {
	return query(0, 0, n-1, l-1, r-1);
}
/*
int main() {
    int N, Q;
    fin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) fin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        fin >> t;

        if (t == 1) {
            int l, r, k;
            fin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            fin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            fin >> l >> r;
            fout << inspect(l, r) << '\n';
        }
    }
    return 0;
}
*/