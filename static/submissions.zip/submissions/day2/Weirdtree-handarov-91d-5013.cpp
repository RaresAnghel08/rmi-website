/**
* user:  handarov-91d
* fname: Radostin Nikolaev
* lname: Handarov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:53:27.893196
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

#pragma GCC optimize "-O3"

#define endl '\n'
#define trace(x) cerr << #x << " = " << x << endl

using namespace std;

int N;
vector<long long> tree, lazy;
vector<long long> heights;

void build(int node, int low, int high) {
    if (low == high) {
        tree[node] = heights[low];
        return;
    }

    int mid = (low + high) >> 1;
    build(node << 1, low, mid);
    build(node << 1 | 1, mid + 1, high);

    tree[node] = tree[node << 1] + tree[node << 1 | 1];
}

void initialise(int N, int Q, int h[]) {
	heights.resize(N + 1);
	for (int i = 1; i <= N; i++) {
        heights[i] = h[i];
	}

	::N = N;
    tree.resize((N + 1) << 2);
    lazy.resize((N + 1) << 2, 0);
    build(1, 1, N);
}

void push(int node, int low, int high) {
    if (lazy[node]) {
        tree[node] -= (high - low + 1) * lazy[node];

        if (low != high) {
            lazy[node << 1] += lazy[node];
            lazy[node << 1 | 1] += lazy[node];
        }

        lazy[node] = 0;
    }
}

void update(int node, int low, int high, int ql, int qr, int k) {
    push(node, low, high);

    if (high < ql || low > qr) {
        return;
    }

    if (low >= ql && high <= qr) {
        lazy[node] += k;
        push(node, low, high);
        return;
    }

    int mid = (low + high) >> 1;
    update(node << 1, low, mid, ql, qr, k);
    update(node << 1 | 1, mid + 1, high, ql, qr, k);

    tree[node] = tree[node << 1] + tree[node << 1 | 1];
}

long long getSum(int node, int low, int high, int ql, int qr) {
    push(node, low, high);

    if (high < ql || low > qr) {
        return 0;
    }

    if (low >= ql && high <= qr) {
        return tree[node];
    }

    int mid = (low + high) >> 1;
    return (getSum(node << 1, low, mid, ql, qr) + getSum(node << 1 | 1, mid + 1, high, ql, qr));
}

void cut(int l, int r, int k) {
    long long total = getSum(1, 1, N, l, r);
    k = min((long long)k, total);

    int len = r - l + 1;
    update(1, 1, N, l, r, k / len);
    int rem = k % len;
    update(1, 1, N, l, l + rem - 1, 1);
}

void magic(int i, int x) {
    assert(false);
}

long long int inspect(int l, int r) {
    return getSum(1, 1, N, l, r);
}

/*
6 9
1 2 3 1 2 3
1 1 6 1
3 1 6
1 1 3 1
3 1 6
1 1 3 1000
3 1 6
3 1 6
1 1 3 1
3 1 5
*/
