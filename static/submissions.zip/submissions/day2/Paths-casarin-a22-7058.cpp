/**
* user:  casarin-a22
* fname: Filippo
* lname: Casarin
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:34:20.704509
*/
#include <iostream>
#include <climits>
#include <functional>
#include <vector>

int main() {
	size_t n, k;
	std::cin >> n >> k;

	std::vector<uint32_t> a, b, c;
	a.reserve(2 * n - 2);
	b.reserve(2 * n - 2);
	c.reserve(2 * n - 2);
	std::vector<std::vector<uint32_t>> g(n);
	for (size_t i{}; i < n - 1; ++i) {
		uint32_t x, y, z;
		std::cin >> x >> y >> z;
		--x, --y;

		g[x].push_back(a.size());
		a.push_back(x);
		b.push_back(y);
		c.push_back(z);

		g[y].push_back(a.size());
		a.push_back(y);
		b.push_back(x);
		c.push_back(z);
	}

	// std::vector<uint64_t> dp(a.size(), ULLONG_MAX);
	// std::function<void(size_t)> calc = [&](size_t e) {
	// 	auto &v = dp[e];
	// 	if (v != ULLONG_MAX) return;
	// 	v = 0;
	// 	for (auto f : g[b[e]])
	// 		if (b[f] != a[e]) {
	// 			calc(f);
	// 			v = std::max(v, dp[f]);
	// 		}
	// 	v += c[e];
	// };

	// for (size_t i{}; i < n; ++i) {
	// 	uint64_t v = 0;
	// 	for (auto f : g[i]) {
	// 		calc(f);
	// 		v = std::max(v, dp[f]);
	// 	}
	// 	std::cout << v << '\n';
	// }
}
