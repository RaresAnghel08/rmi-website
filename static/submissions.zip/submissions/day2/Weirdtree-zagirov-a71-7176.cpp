/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:42:21.477129
*/
#include <bits/stdc++.h>

#pragma GCC optimize("Ofast")
//#pragma GCC optimize("avx, avx2")

#define pii pair<int, int>
#define pb push_back
#define f first
#define s second

using namespace std;

typedef long long ll;
typedef long double ld;

//#define int ll

const int N = 1e5 + 10;
vector<pii > g[N];
int it = 0, lg[N], rg[N];
vector<pair<pii, int>> q;

pair<ll, int> t[4 * N];

void update(int v, int l, int r, int pos, ll val) {
    if (l == r - 1) {
        t[v] = {val, l};
    } else {
        int mid = (r + l) / 2;
        if (pos < mid)
            update(2 * v + 1, l, mid, pos, val);
        else
            update(2 * v + 2, mid, r, pos, val);
        t[v] = max(t[2 * v + 1], t[2 * v + 2]);
    }
}

pair<ll, int> get(int v, int l, int r, int tl, int tr) {
    if (tl <= l && tr >= r)
        return t[v];
    if (tl >= r || tr <= l)
        return {-N, -N};
    int mid = (r + l) / 2;
    return max(get(2 * v + 1, l, mid, tl, tr), get(2 * v + 2, mid, r, tl, tr));
}

void build(int v, int p = -1) {
    lg[v] = N;
    if (g[v].size() == 1) {
        lg[v] = rg[v] = it;
        it++;
    }
    for (auto u: g[v]) {
        if (u.f == p)
            continue;
        build(u.f, v);
        lg[v] = min(lg[v], lg[u.f]);
        rg[v] = max(rg[v], rg[u.f]);
        q.pb({{lg[u.f], rg[u.f]}, u.s});
    }
}

ll ans[N], k;

inline ll get_ans() {
    return get(0, 0, N, 0, N).f;
}

void dfs(int v, int p = -1) {
    ans[v] = get_ans();
    for (auto u: g[v]) {
        if (u.f == p)
            continue;
        pair<ll, int> mx = get(0, 0, N, lg[u.f], rg[u.f] + 1);
        update(0, 0, N, mx.s, mx.f - u.s);
        pair<ll, int> mx1 = {-1, -1}, mx2;
        if (lg[u.f])
            mx1 = get(0, 0, N, 0, lg[u.f]);
        mx2 = get(0, 0, N, rg[u.f] + 1, N);
        mx1 = max(mx1, mx2);
        update(0, 0, N, mx1.s, mx1.f + u.s);
        dfs(u.f, v);
        update(0, 0, N, mx1.s, mx1.f);
        update(0, 0, N, mx.s, mx.f);
    }
}

bool comp(pair<pii, int> a, pair<pii, int> b) {
    return (a.f.s - a.f.f) < (b.f.s - b.f.f);
}

void build_t(int v, int l, int r){
    if (l == r - 1){
        t[v] = {0, l};
    }else{
        int mid = (r + l) / 2;
        build_t(2 * v + 1, l, mid);
        build_t(2 * v + 2, mid, r);
        t[v] = max(t[2 * v + 1], t[2 * v + 2]);
    }
}

void solve() {
    int n, a, b, c = 0;
    cin >> n >> k;
    for (int i = 0; i < n - 1; i++) {
        cin >> a >> b >> c;
        a--;
        b--;
        g[a].pb({b, c});
        g[b].pb({a, c});
    }
    if (n <= 2) {
        for (int i = 0; i < n; i++) {
            cout << c << '\n';
        }
        return;
    }
    int root = 0;
    for (int i = 0; i < n; i++) {
        if ((int) g[i].size() >= 2)
            root = i;
    }
    build(root);
    sort(q.begin(), q.end(), comp);
    build_t(0, 0, N);
    for (auto u: q) {
        auto now = get(0, 0, N, u.f.f, u.f.s + 1);
        update(0, 0, N, now.s, now.f + u.s);
    }
    dfs(root);
    for (int i = 0; i < n; i++)
        cout << ans[i] << endl;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    solve();
}