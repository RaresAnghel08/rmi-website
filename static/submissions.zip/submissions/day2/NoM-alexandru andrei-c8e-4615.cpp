/**
* user:  alexandru andrei-c8e
* fname: Benescu
* lname: Alexandru Andrei
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:15:30.537718
*/
#include <bits/stdc++.h>
#define L 12
using namespace std;
int m[L][L] = { {0}, {0}, {0, 0, 16}, {0, 0, 288, 384}, {0, 0, 9216, 13824, 23040}, {0, 0, 460800, 829440, 1428481, 2088961} };
int main(){
  int n, k;
  cin >> n >> k;
  cout << m[n][k] << "\n";
  return 0;
}
