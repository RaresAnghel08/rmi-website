/**
* user:  kolisnyk-9d2
* fname: Illia
* lname: Kolisnyk
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:01:21.544986
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
#include "weirdtree.h"
//#define int long long

using namespace std;

const int N = 3e5 + 55;

//struct item {
//    int mx;
//    int cnt;
//    int mi;
//    long long sum;
//    int push;
//};

//typedef item* pitem;

int mx[4 * N];
int cnt[4 * N];
int mi[4 * N];
long long sum[4 * N];
int prom[4 * N];
//pitem t[4 * N];
int a[N];
int cnn;
int n;

inline void Merge(int x, int y, int nw) {
    sum[nw] = sum[x] + sum[y];
    mi[nw] = min(mi[x], mi[y]);
    mx[nw] = max(mx[x], mx[y]);
    if (mx[x] == mx[y]) {
        cnt[nw] = cnt[x] + cnt[y];
    }
    else if (mx[x] > mx[y]) {
        cnt[nw] = cnt[x];
    }
    else {
        cnt[nw] = cnt[y];
    }
}

inline void push(int v, int tl, int tr) {
    if (prom[v] != -1) {
//        cout << "|| " << tl << ' ' << tr << ' ' << t[v] -> push << '\n';
        mx[v] = mi[v] = prom[v];
        cnt[v] = tr - tl + 1;
        sum[v] = 1ll * (tr - tl + 1) * prom[v];
        if (tl != tr) {
            prom[v * 2] = prom[v];
            prom[v * 2 + 1] = prom[v];
//            int m = (tl + tr) / 2;
//            push(v * 2, tl, m);
//            push(v * 2 + 1, m + 1, tr);
        }
        prom[v] = -1;
    }
}

void build(int v, int tl, int tr) {
    prom[v] = -1;
    if (tl == tr) {
        sum[v] = mx[v] = mi[v] = a[tl];
        cnt[v] = 1;
        return;
    }
    int m = (tl + tr) / 2;
    build(v * 2, tl, m);
    build(v * 2 + 1, m + 1, tr);
    Merge(v * 2, v * 2 + 1, v);
}

long long getgr(int v, int tl, int tr, int l, int r, int x) {
//    cout << v << ' ' << tl << ' ' << tr << ' ' << l << ' ' << r << ' ' << x << '\n';
    if (tl > r || tr < l || tr < tl) return 0;
    push(v, tl, tr);
    if (tl >= l && tr <= r) {
//            cout << t[v] -> mx << '\n';
        if (mx[v] <= x) return 0;
        if (mi[v] > x) {

//                cout << tl << ' ' << tr << ' ' << t[v] -> sum << '\n';
                return sum[v] - 1ll * (tr - tl + 1) * x;
        }
    }
    int m = (tl + tr) / 2;
    return getgr(v * 2, tl, m, l, r, x) + getgr(v * 2 + 1, m + 1, tr, l, r, x);
}

void setmx(int v, int tl, int tr, int l, int r, int x) {
    if (tl > r || tr < l || tr < tl) return;
    push(v, tl, tr);
    if (tl >= l && tr <= r) {
        if (mx[v] < x) return;
        if (mi[v] >= x) {
            prom[v] = x;
            return;
        }
    }
    int m = (tl + tr) / 2;
    setmx(v * 2, tl, m, l, r, x);
    setmx(v * 2 + 1, m + 1, tr, l, r, x);
    push(v * 2, tl, m);
    push(v * 2 + 1, m + 1, tr);
    Merge(v * 2, v * 2 + 1, v);
}

void cutk(int v, int tl, int tr, int l, int r, int x) {
//            cout << v << ' ' << tl << ' ' << tr << '\n';
    if (tl > r || tr < l || tr < tl || !cnn) return;
    push(v, tl, tr);
    if (tl >= l && tr <= r) {
        if (x == mi[v] && mi[v] == mx[v] && cnt[v] <= cnn) {
            cnn -= cnt[v];
            prom[v] = mx[v] - 1;
            return;
        }
    }
    if (tl == tr) return;
    int m = (tl + tr) / 2;
    push(v * 2, tl, m);
    push(v * 2 + 1, m + 1, tr);
    if (mx[v * 2] >= x) cutk(v * 2, tl, m, l, r, x);
    if (cnn && mx[v * 2 + 1] >= x) cutk(v * 2 + 1, m + 1, tr, l, r, x);
    push(v * 2, tl, m);
    push(v * 2 + 1, m + 1, tr);
    Merge(v * 2, v * 2 + 1, v);
}

void update(int v, int tl, int tr, int pos, int cur) {
    push(v, tl, tr);
    if (tl == tr) {
        sum[v] = mx[v] = mi[v] = cur;
        cnt[v] = 1;
        return;
    }
    int m = (tl + tr) / 2;
    if (pos <= m) update(v * 2, tl, m, pos, cur);
    else update(v * 2 + 1, m + 1, tr, pos, cur);
    push(v * 2, tl, m);
    push(v * 2 + 1, m + 1, tr);
    Merge(v * 2, v * 2 + 1, v);
}

long long get(int v, int tl, int tr, int l, int r) {
    if (l > r) return 0;
    push(v, tl, tr);
    if (tl == l && tr == r) {
        return sum[v];
    }
    int m = (tl + tr) / 2;
    return get(v * 2, tl, m, l, min(r, m)) + get(v * 2 + 1, m + 1, tr, max(m + 1, l), r);
}

int getmx(int v, int tl, int tr, int l, int r) {
    if (l > r) return 0;
    push(v, tl, tr);
    if (tl == l && tr == r) {
        return mx[v];
    }
    int m = (tl + tr) / 2;
    return max(getmx(v * 2, tl, m, l, min(r, m)), getmx(v * 2 + 1, m + 1, tr, max(m + 1, l), r));
}

void initialise(int32_t nn, int32_t q, int32_t h[]) {
    n = nn;
	for (int i = 1; i <= n; i ++) {
        a[i] = h[i];
	}
    build(1, 1, n);
}
void cut(int32_t l, int32_t r, int32_t kk) {
    if (kk == 0) return;
    long long k = (long long) kk;
	int l1 = 0, r1 = getmx(1, 1, n, l, r);
	int mxxx = r1;
	if (get(1, 1, n, l, r) <= k) r1 = 0;
	if (k == 1) l1 = max(r1 - 4, 0);
	if (r1 - 10000 > 0 && getgr(1, 1, n, l, r, r1 - 10000) > (long long)k) l1 = r1 - 10000;
	else if (r1 - 10000 > 0) r1 = r1 - 10000;
	while (r1 - l1 > 1) {
        int m = (l1 + r1) / 2;
        if (getgr(1, 1, n, l, r, m) > (long long)k) l1 = m + 1;
        else r1 = m;
	}
	if (getgr(1, 1, n, l, r, l1) <= (long long)k) r1 = l1;
	k -= getgr(1, 1, n, l, r, r1);
	setmx(1, 1, n, l, r, r1);
	cnn = (long long)k;
//	cout << "| " << l << ' ' << r << ' ' << r1 << ' ' << k << '\n';
	if (r1 && mxxx != r1) cutk(1, 1, n, l, r, r1);
}
void magic(int32_t i, int32_t x) {
	update(1, 1, n, i, x);
}
long long int inspect(int32_t l, int32_t r) {
	return get(1, 1, n, l, r);
}

/*
6 10
1 2 3 1 2 3
1 1 6 3
3 1 6
1 1 3 3
3 1 6
1 1 3 1000
3 1 6
2 1 1000
3 1 6
1 1 3 999
3 1 5

6 10
1 2 5 6 7 3
3 1 6
1 1 6 7
3 1 6
1 4 6 3
3 1 6

10 1
1000000000
1000000000
1000000000
1000000000
1000000000
1000000000
1000000000
1000000000
1000000000
1000000000
3 1 5
*/
