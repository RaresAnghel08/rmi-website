/**
* user:  mosiashvili-7fd
* fname: Luka
* lname: Mosiashvili
* task:  Paths
* score: 19.0
* date:  2021-12-17 10:32:10.082737
*/
#include<bits/stdc++.h>
using namespace std;
long long a,b,c,d,e,i,j,ii,jj,zx,xc,K,dep[100009],rt,dp[1005][1005],DP[1005];
vector <pair <long long, long long> > v[100009];
void dfsst(int q, int w){
	if(q!=rt&&v[q].size()==1) dep[q]++;
	for(vector <pair <long long, long long> >::iterator it=v[q].begin(); it!=v[q].end(); it++){
		if((*it).first==w) continue;
		dfsst((*it).first,q);
		dep[q]+=dep[(*it).first];
	}
}
void dfs(int q, int w){
	int E=0;
	for(j=0; j<=dep[q]+1; j++) DP[j]=0;
	for(vector <pair <long long, long long> >::iterator it=v[q].begin(); it!=v[q].end(); it++){
		if((*it).first==w) continue;
		dfs((*it).first,q);
		for(j=0; j<=E; j++){
			for(jj=0; jj<=dep[(*it).first]; jj++){
				zx=dp[(*it).first][jj]+dp[q][j];
				if(jj!=0) zx+=(*it).second;
				if(DP[j+jj]<zx) DP[j+jj]=zx;
			}
		}
		E+=dep[(*it).first];
		for(j=0; j<=E; j++){
			dp[q][j]=DP[j];
		}
	}
}
int main(){
	ios_base::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>a>>K;
	for(i=1; i<a; i++){
		cin>>c>>d>>e;
		v[c].push_back(make_pair(d,e));
		v[d].push_back(make_pair(c,e));
	}
	for(rt=1; rt<=a; rt++){
		for(i=0; i<=a+1; i++){
			dep[i]=0;
			for(j=0; j<=a+1; j++){
				dp[i][j]=0;
			}
		}
		dfsst(rt,0);
		dfs(rt,0);
		zx=0;
		for(j=0; j<=K; j++){
			if(zx<dp[rt][j]) zx=dp[rt][j];
		}
		cout<<zx<<"\n";
	}
	return 0;
}
