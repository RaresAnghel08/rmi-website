/**
* user:  denysiuk-795
* fname: Vladyslav
* lname: Denysiuk
* task:  Paths
* score: 56.0
* date:  2021-12-17 11:16:06.750062
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double ld;

#define endl '\n'
#define all(var) var.begin(),var.end()
#define mp make_pair

const int N = 1e5+7;
const ll INF = 1e18;
const int MX_depth = 60;

vector<pair<int,int> > G[N];

pair<ll,int> dp[N];

void dfs(int v,int par,ld k){
    pair<pair<ll,int>,int> mx = mp(mp(0,1),0);
    for(auto [to,w]:G[v]){
        if (to==par)
            continue;
        dfs(to,v,k);
        if (mx.first.first-k*mx.first.second<dp[to].first+w-k*dp[to].second)
            mx = mp(mp(dp[to].first+w,dp[to].second),to);
    }
    dp[v] = mx.first;
    for(auto [to,w]:G[v]){
        if (to==par || to==mx.second)
            continue;
        if (dp[to].first+w-k*dp[to].second>0)
            dp[v].first+=dp[to].first+w,dp[v].second+=dp[to].second;
    }
}
ld L[N],R[N];
ll ans[N];
pair<ll,int> root_calc[N];

void recalc(int v,int par,ld k){
    pair<pair<ll,int>,int> mx = mp(mp(0,1),0);
    for(auto [to,w]:G[v]){
        if (mx.first.first-k*mx.first.second<dp[to].first+w-k*dp[to].second)
            mx = mp(mp(dp[to].first+w,dp[to].second),to);
    }
    dp[v] = mx.first;
    for(auto [to,w]:G[v]){
        if (to==mx.second)
            continue;
        if (dp[to].first+w-k*dp[to].second>0)
            dp[v].first+=dp[to].first+w,dp[v].second+=dp[to].second;
    }
    root_calc[v] = dp[v];
    for(auto [to,w]:G[v]){
        if (to==par)
            continue;
        pair<ll,int> v_val = dp[v],to_val = dp[to];
        if (to==mx.second){
            int blk = to;
            pair<pair<ll,int>,int> mx = mp(mp(0,1),0);
            for(auto [to,w]:G[v]){
                if (to==blk)
                    continue;
                if (mx.first.first-k*mx.first.second<dp[to].first+w-k*dp[to].second)
                    mx = mp(mp(dp[to].first+w,dp[to].second),to);
            }
            dp[v] = mx.first;
            for(auto [to,w]:G[v]){
                if (to==mx.second || to==blk)
                    continue;
                if (dp[to].first+w-k*dp[to].second>0)
                    dp[v].first+=dp[to].first+w,dp[v].second+=dp[to].second;
            }
        }
        else{
            if (dp[to].first+w-k*dp[to].second>0)
                dp[v].first-=dp[to].first+w,dp[v].second-=dp[to].second;
        }
        recalc(to,v,k);
        dp[v] = v_val;
        dp[to] = to_val;
    }
}
int ops = 0;
int nn;
void calc_all(set<int> &S,int k,int depth){
    if (S.empty())
        return;
    ++ops;
    if (ops/MX_depth>sqrt(nn))
        assert(0);
    if (depth==MX_depth) {
        int v = *S.begin();
        dfs(1,1,R[v]);
        recalc(1,1,R[v]);
        for(int to:S){
            ans[to] = round(root_calc[to].first-root_calc[to].second*R[v]+R[v]*k);
        }
        return;
    }
    int v = *S.begin();
    ld mid = (L[v]+R[v])/2;
    dfs(1,1,mid);
    recalc(1,1,mid);
    int less = 0,sz = S.size();
    for(int to:S){
        if (root_calc[to].second<=k)
            ++less;
    }
    set<int> ns;
    for(int to:S){
        if (root_calc[to].second>k)
            L[to] = mid;
        else R[to] = mid;
        if (less*2<sz && root_calc[to].second<=k)
            ns.insert(to);
        if (less*2>=sz && root_calc[to].second>k)
            ns.insert(to);
    }
    for(int to:ns)
        S.erase(to);
    calc_all(S,k,depth+1);
    calc_all(ns,k,depth+1);
}

void solve(){
    int n,k;
    cin>>n>>k;
    nn = n;
    for(int i = 1;i<n;++i){
        int a,b,w;
        cin>>a>>b>>w;
        G[a].push_back({b,w});
        G[b].push_back({a,w});
    }

    set<int> to_calc;
    for(int i = 1;i<=n;++i)
        to_calc.insert(to_calc.end(),i), L[i] = 0, R[i] = 1e12;

    calc_all(to_calc,k,0);

    for(int i = 1;i<=n;++i)
        cout<<ans[i]<<'\n';
    cout<<endl;
}

signed main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin>>t;
    while(t--)
        solve();
}