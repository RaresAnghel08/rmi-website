/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:21:17.465542
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)

using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int mxn = 2005;
int n, k;
vector<pii> g[mxn];

int par[mxn];
int paw[mxn];
int dep[mxn];

ll sum[mxn];
ll ans[mxn];
ll ANS;

ll submax[mxn];

void dfs(int u, int p){
	par[u] = p;
	submax[u] = sum[u];
	
	for(auto e : g[u]){
		if(e.st == p) continue;
		sum[e.st] = sum[u] + e.nd;
		paw[e.st] = e.nd;
		dep[e.st] = dep[u] + 1;
		dfs(e.st, u);
		submax[u] = max(submax[u], submax[e.st]);
	}
}
bool isleaf[mxn];
vector<int> G;
vector<int> L;

ll collect(int r){
	G.clear();
	memset(isleaf, false, sizeof(isleaf));
	isleaf[r] = true;
	sum[r] = 0;
	dfs(r,r);
	pq<pair<ll, int> > Q;
	for(auto e : g[r]){
		Q.push({submax[e.st], e.st});
	}
	ll ans = 0;
	int rem = k-1;
	vector<int> v;
	while(!Q.empty()){
		int u = Q.top().nd;
		Q.pop();
		
		if(isleaf[par[u]]){
			isleaf[par[u]] = false;
			isleaf[u] = true;
		}
		else{
			if(rem == 0) continue;
			--rem;
			isleaf[u] = true;
			
		}
		v.pb(u);
		ans += paw[u];
		for(auto e : g[u]){
			if(e.st == par[u]) continue;
			Q.push({submax[e.st] - sum[u], e.st});
		}
	}
	for(auto u : v){
		if(isleaf[u]){
			G.pb(u);
		}
	}
	return ans;
}
int lca(){
	int mind = n+1;
	for(auto u : G) mind = min(mind, dep[u]);
	fr(i, 0, (int)G.size()){
		while(dep[G[i]] > mind){
			G[i] = par[G[i]];
		}
	}
	bool ok = false;
	while(!ok){
		int x = -1;
		ok = true;
		for(auto u : G){
			if(x == -1) x = u;
			else if(u != x){
				 ok = false;
				 fr(i, 0, (int)G.size()){
					G[i] = par[G[i]];
				 }
				 break;
			}
		}
	}
	return G[0];
}

bool colored[mxn];

void dfs2(int u, int p){
	for(auto e : g[u]){
		if(e.st == p) continue;
		dfs2(e.st, u);
		if(colored[e.st]){
			ANS += e.nd;
			colored[u] = true;
		}
	}
}


void dfs3(int u, int p, ll w){
	if(colored[u]) w = 0;
	else{
		ans[u] = ANS + w;
	}
	for(auto e : g[u]){
		if(e.st == p) continue;
		dfs3(e.st, u, w + e.nd);
	}
}

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	
	cin >> n >> k;
	fr(i, 0, n-1){
		int u, v, c;
		cin >> u >> v >> c;
		--u, --v;
		g[u].pb({v, c});
		g[v].pb({u, c});
	}
	if(k == 1){
		fr(i, 0, n){
			cout<<collect(i)<<endl;
		}
		return 0;
	}
	
	if(n == 1){
		cout<<0<<endl;
		return 0;
	}
	if(n == 2){
		cout<<g[0][0].nd<<endl;
		cout<<g[0][0].nd<<endl;
		return 0;
	}
	
	
	int rrr = 0;
	fr(i, 0, n){
		if(g[i].size() > 1){
			rrr = i;
			break;
		}
	}
	
	collect(rrr);
	L = G;
	
	for(auto u : G) colored[u] = true;
	int lc = lca();
	
	
	collect(lc);
	L = G;
	
	memset(colored, false, sizeof(colored));
	for(auto u : G) colored[u] = true;
	int LC = lca();




	
	dfs2(LC, LC);
	dfs3(LC, LC, 0);
	//ll ans2 = collect(L[0]);
	fr(i, 0, n){
		if(colored[i]){
			ans[i] = ANS;
		}
	}
	
	for(auto u : L){
		ans[u] = collect(u);
	}
	
	fr(i, 0, n){
		cout<<ans[i]<<endl;
	}
}
