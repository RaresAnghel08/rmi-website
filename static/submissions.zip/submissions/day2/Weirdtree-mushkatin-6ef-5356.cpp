/**
* user:  mushkatin-6ef
* fname: Shirli
* lname: Mushkatin
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:23:46.436289
*/
﻿// weirdTree.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef pair<int, ll> pii;
typedef vector<pii> vp;
typedef vector<vp> vvp;

int cnt = 0;

void initialise(int N, int Q, int h[]) {
	for (int i = 1; i <= N; i++)
		cnt += h[i];
}

void cut(int l, int r, int k) {
	cnt = min(0, cnt - k);
}

void magic(int i, int x) {
	cnt += x;
}

long long int inspect(int l, int r) {
	return cnt;
}


