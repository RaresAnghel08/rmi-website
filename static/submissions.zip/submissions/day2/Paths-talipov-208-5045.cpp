/**
* user:  talipov-208
* fname: Islam Iliasovich
* lname: Talipov
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:56:08.051101
*/
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <algorithm>
#include <numeric>

#define AIDAR ASADULLIN
#define ll long long
#define all(v) v.begin(), v.end()

using namespace std;

const ll MOD = 1e9 + 7;
const int MAXN = 2000 + 1;
const int MAXK = 2000;


vector<pair<int, int>> graph[MAXN];
ll dp[MAXN][MAXK];
int sz[MAXN];

int k;

void dfs(int v, int p) {
    int children = 0;
    for (auto e: graph[v]) {
        int u = e.first, c = e.second;
        if (u != p) {
            children++;
            dfs(u, v);
            sz[v] += sz[u];
        }
    }
    if (children == 0) sz[v]++;
    for (auto e: graph[v]) {
        int u = e.first, c = e.second;
        if (u == p) continue;
        for (int k1 = min(k, sz[v]); k1 >= 1; --k1) {
            for (int k2 = 0; k2 <= min({k, sz[u], k1}); ++k2) {
                dp[v][k1] = max(dp[v][k1], dp[v][k1 - k2] + (k2 != 0 ? c : 0) + dp[u][k2]);
            }
        }
    }
}

int main() {
    cin.tie(0);
    ios::sync_with_stdio(false);
    int n;
    cin >> n >> k;
    for (int i = 0; i < n - 1; ++i) {
        int x, y, c;
        cin >> x >> y >> c;
        --x, --y;
        graph[x].emplace_back(y, c);
        graph[y].emplace_back(x, c);
    }
    for (int i = 0; i < n; ++i) {
        for (int v = 0; v < n; ++v) {
            sz[v] = 0;
            for (int h = 0; h <= min(k, (int)graph[v].size()); ++h) {
                dp[v][h] = 0;
            }
        }
        dfs(i, -1);
        cout << dp[i][k] << "\n";
    }
}