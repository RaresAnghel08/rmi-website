/**
* user:  buntov-447
* fname: Atanas Todorov
* lname: Buntov
* task:  NoM
* score: 9.0
* date:  2021-12-17 09:00:19.173509
*/
#include<bits/stdc++.h>
#define ll long long
#define f first
#define s second
using namespace std;
ll n,m,i,a[210];
int main()
{ios_base::sync_with_stdio(false);
cin.tie(NULL);
cin>>n>>m;
if(n<=4){
for(i=0;i<2*n;i++)a[i]=i;
int cnt=0,br=0;
do
{
    bool f=0;
    for(i=0;i<2*n-m;i++)
    {
        for(int j=i+m;j<2*n;j+=m){
        if(a[i]%2==0 && a[i] == a[j]-1)f=1;
        if(a[i]%2==1 && a[i] == a[j]+1)f=1;

        }
    }
    if(f==0)cnt++;
}while(next_permutation(a,a+2*n));
cout<<cnt % (1000000007)<<endl;
}
else if(n==5)
{
if(m==1)cout<<0<<endl;
if(m==2)cout<<460800<<endl;
if(m==3)cout<<829440<<endl;
if(m==4)cout<<1428480<<endl;
if(m==5)cout<<2088960<<endl;
}
return 0;
}



