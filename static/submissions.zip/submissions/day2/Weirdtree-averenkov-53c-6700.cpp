/**
* user:  averenkov-53c
* fname: Vladimir
* lname: Averenkov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:10:34.423659
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
#define X first
#define Y second
#define sz(a) (int)a.size()
#define pb push_back

using namespace std;

int n;

int rmq1[400010];
int rmq2[400010];

int a[300010];

void build1(int t, int l, int r) {
	if (r - l == 1) {
		rmq1[t] = a[l];
		return;
	}
	int mid = (r + l) / 2;
	build1(t * 2 + 1, l, mid);
	build1(t * 2 + 2, mid, r);
	rmq1[t] = rmq1[t * 2 + 1] + rmq1[t * 2 + 2];
}

void update1(int t, int l, int r, int x, int y) {
	if (r - l == 1) {
		rmq1[t] = y;
		return;
	}
	int mid = (r + l) / 2;
	if (x < mid) {
		update1(t * 2 + 1, l, mid, x, y);
	} else {
		update1(t * 2 + 2, mid, r, x, y);
	}
	rmq1[t] = rmq1[t * 2 + 1] + rmq1[t * 2 + 2];
}

int get1(int t, int l, int r, int x, int y) {
	if (r <= x || y <= l)
		return 0;
	if (x <= l && r <= y)
		return rmq1[t];
	int mid = (r + l) / 2;
	return get1(t * 2 + 1, l, mid, x, y) + get1(t * 2 + 2, mid, r, x, y);
}

void build2(int t, int l, int r) {
	if (r - l == 1) {
		rmq2[t] = l;
		return;
	}
	int mid = (r + l) / 2;
	build2(t * 2 + 1, l, mid);
	build2(t * 2 + 2, mid, r);
	if (a[rmq2[t * 2 + 1]] >= a[rmq2[t * 2 + 2]])
		rmq2[t] = rmq2[t * 2 + 1];
	else
		rmq2[t] = rmq2[t * 2 + 2];
}

void update2(int t, int l, int r, int x) {
	if (r - l == 1) {
		return;
	}
	int mid = (r + l) / 2;
	if (x < mid) {
		update2(t * 2 + 1, l, mid, x);
	} else {
		update2(t * 2 + 2, mid, r, x);
	}
	if (a[rmq2[t * 2 + 1]] >= a[rmq2[t * 2 + 2]])
		rmq2[t] = rmq2[t * 2 + 1];
	else
		rmq2[t] = rmq2[t * 2 + 2];
}

int get2(int t, int l, int r, int x, int y) {
	if (r <= x || y <= l)
		return -1;
	if (x <= l && r <= y)
		return rmq2[t];
	int mid = (r + l) / 2;
	int pp1 = get2(t * 2 + 1, l, mid, x, y);
	int pp2 = get2(t * 2 + 2, mid, r, x, y);
	if (pp1 == -1)
		return pp2;
	if (pp2 == -1)
		return pp1;
	if (a[pp1] >= a[pp2])
		return pp1;
	return pp2;
}

void initialise(int N, int Q, int h[]) {
	n = N;
	for (int i = 1; i <= N; ++i)
		a[i - 1] = h[i];
	build1(0, 0, n);
	build2(0, 0, n);
}
void cut(int l, int r, int k) {
	for (int i = 0; i < k; ++i) {
		int ind = get2(0, 0, n, l - 1, r);
		if (a[ind] == 0)
			return;
		update1(0, 0, n, ind, a[ind] - 1);
		a[ind]--;
		update2(0, 0, n, ind);
	}
}
void magic(int i, int x) {
	i--;
	update1(0, 0, n, i, x);
	a[i] = x;
	update2(0, 0, n, i);
}
long long int inspect(int l, int r) {
	// Your code here.
	return get1(0, 0, n, l - 1, r);
}
