/**
* user:  pavleski-d5d
* fname: Blagojche
* lname: Pavleski
* task:  Paths
* score: 36.0
* date:  2021-12-17 07:47:34.968910
*/
#include <bits/stdc++.h>
#define fr(i, n, m) for(int i = (n); i < (m); i ++)
#define pb push_back
#define st first
#define nd second
#define pq priority_queue
#define all(x) begin(x), end(x)

using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int mxn = 1e5+5;
int n, k;
vector<pii> g[mxn];

int par[mxn];
int paw[mxn];

ll sum[mxn];
ll submax[mxn];
bool is[mxn];

void dfs(int u, int p){
	par[u] = p;
	submax[u] = sum[u];
	for(auto e : g[u]){
		if(e.st == p) continue;
		sum[e.st] = sum[u] + e.nd;
		paw[e.st] = e.nd;
		dfs(e.st, u);
		submax[u] = max(submax[u], submax[e.st]);
	}
	is[u] = (bool)g[u].size() == 1;
}
bool isleaf[mxn];
bool isused[mxn];
ll A[mxn];

ll solve(int r){
	fr(i, 0, n) isleaf[i] = isused[i] = false;
	isused[r] = true;
	isleaf[r] = true;
	sum[r] = 0;
	dfs(r,r);
	pq<pair<ll, int> > Q;
	for(auto e : g[r]){
		Q.push({submax[e.st], e.st});
	}
	ll ans = 0;
	int rem = k-1;
	vector<int> v;
	while(!Q.empty()){
		int u = Q.top().nd;
		Q.pop();
		
		if(isleaf[par[u]]){
			isleaf[par[u]] = false;
			v.pb(par[u]);
			
			isleaf[u] = true;
		}
		else{
			if(rem == 0) continue;
			--rem;
			isleaf[u] = true;
		}
		
		
		ans += paw[u];
		
		for(auto e : g[u]){
			if(e.st == par[u]) continue;
			Q.push({submax[e.st] - sum[u], e.st});
		}
	}
	if(!is[r]){
		for(auto u : v) A[u] = ans;
	}
	return ans;
}

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	
	cin >> n >> k;
	fr(i, 0, n-1){
		int u, v, c;
		cin >> u >> v >> c;
		--u, --v;
		g[u].pb({v, c});
		g[v].pb({u, c});
	}
	memset(A, -1, sizeof(A));
	fr(i, 0, n){
		if(A[i] != -1) continue;
		A[i] = solve(i);
		cout<<A[i]<<endl;
	}
	cout<<endl;
	
}
