/**
* user:  pakkanen-669
* fname: Mariia
* lname: Pakkanen
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 08:48:33.425407
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn = 1 << 17;
vector <ll> a(maxn, 0), mx(2*maxn, 0), sum(2*maxn, 0);

void build(int v = 1, int l = 1, int r = maxn + 1)
{
    if(l + 1 ==r){
        mx[v] = l;
        sum[v] = a[l];
        return;
    }
    int m = (l + r) / 2;
    build(2*v, l, m);
    build(2*v+1, m, r);
    sum[v] = sum[2*v] + sum[2*v+1];
    if(a[mx[2*v]] >= a[mx[2*v+1]])
        mx[v] = mx[2*v];
    else
        mx[v] = mx[2*v+1];
}

ll getsum(int l, int r, int v = 1, int tl = 1, int tr = maxn + 1)
{
    if(l <= tl && tr <= r)
        return sum[v];
    if(r <=  tl || tr <= l)
        return 0;
    int tm = (tl + tr) / 2;
    return getsum(l, r, 2*v, tl, tm) + getsum(l, r, 2*v+1, tm, tr);
}

ll getmax(int l, int r, int v = 1, int tl = 1, int tr = maxn + 1)
{
    if(l <= tl && tr <= r)
        return mx[v];
    if(r <=  tl || tr <= l)
        return maxn-1;
    int tm = (tl + tr) / 2;
    ll ml = getmax(l, r, 2*v, tl, tm);
    ll mr = getmax(l, r, 2*v+1, tm, tr);
    if(a[ml] < a[mr])
        return mr;
    else
        return ml;
}

void update(int pos, int x, int v = 1, int l = 1, int r = maxn + 1)
{
    if(r <= pos || pos < l)
        return;
    if(l + 1 == r){
        a[l] = x;
        sum[v] = a[l];
        mx[v] = l;
        return;
    }
    int m = (l + r) / 2;
    update(pos, x, 2*v, l, m);
    update(pos, x, 2*v+1, m, r);
    sum[v] = sum[2*v] + sum[2*v+1];
    if(a[mx[2*v]] >= a[mx[2*v+1]])
        mx[v] = mx[2*v];
    else
        mx[v] = mx[2*v+1];
}

void initialise(int N, int Q, int h[]) {
    for(int i = 1; i <= N; ++i){
        a[i] = h[i];
    }
    build();

}
void cut(int l, int r, int k) {
    if(k == 1){
        int ind = getmax(l, r + 1);
        if(a[ind] != 0) update(ind, a[ind] - 1);
        return;
    }
    int si = r - l + 1;
    vector <pair <int, int> > b(si);
    for(int i = l; i <= r; ++i){
        b[i - l] = {a[i], -i};
    }
    sort(b.begin(), b.end());
    reverse(b.begin(), b.end());
    b.push_back({0, 0});
    si++;
    int pref = b[0].first;
    for(int i = 1; i < si; ++i){
        if(pref - b[i].first * i < k && i != si - 1){
            pref+= b[i].first;
            continue;
        }
        //cout << k << ' ' << i << '\n';
        for(int j = 0; j < i; ++j){
            b[j].first = max(0, b[j].first - k/i);
            if(j < k % i)
                b[j].first = max(0, b[j].first - 1);
        }

        for(int j = 0; j < b.size(); ++j){
            update(-b[j].second, b[j].first );
            //cout << -b[j].second << ' ' << b[j].first << '\n';
        }
        return;
    }
}
void magic(int i, int x) {
    update(i, x);
}
long long int inspect(int l, int r) {
    return getsum(l, r + 1);
}