/**
* user:  magirescu-396
* fname: Tudor Stefan
* lname: Magirescu
* task:  Paths
* score: 36.0
* date:  2021-12-17 10:09:36.503991
*/
#include <iostream>
#include <vector>
#define NMAX 4000
#define ll long long
#define f first
#define s second

using namespace std;

int n, k, tata[NMAX+10], leaves[NMAX+10], currLeaf, m, stnod, drnod, stq, drq, cost;
ll sus[NMAX+10], sum[NMAX+10];
pair <int, int> leafInt[NMAX+10];
vector <pair <int, ll> > nod[NMAX+10];

struct Lazy{
    ll maxi;
    int idx;
    ll lazy;
}aint[4*NMAX+10];

void dfs(int x, int p = 0, ll cost = 0){
    tata[x] = p;
    sum[x] = cost;

    for(auto u : nod[x])
        if(u.f != p){
            dfs(u.f, x, cost + u.s);
            sus[u.f] = u.s;

            if(leafInt[x].f == -1)
                leafInt[x] = leafInt[u.f];
            else{
                leafInt[x].f = min(leafInt[x].f, leafInt[u.f].f);
                leafInt[x].s = max(leafInt[x].s, leafInt[u.f].s);
            }
        }
    if(nod[x].size() == 1 && p){
        currLeaf++;
        leaves[currLeaf] = x;
        leafInt[x] = {currLeaf, currLeaf};
    }
}

void buildAint(int root){
    int bit = 0;
    while((1 << bit) < leafInt[root].s - leafInt[root].f + 1)
        bit++;
    m = (1 << bit);
    for(int i=leafInt[root].s-leafInt[root].f+2; i<=m; i++)
        leaves[i] = 0;


    for(int i=m; i<2*m; i++){
        aint[i].idx = leaves[i-m+1];
        aint[i].lazy = 0;
        aint[i].maxi = sum[leaves[i-m+1]];
    }

    for(int i=m-1; i; i--){
        if(aint[2*i].maxi >= aint[2*i+1].maxi){
            aint[i].maxi = aint[2*i].maxi;
            aint[i].idx = aint[2*i].idx;
        }
        else{
            aint[i].maxi = aint[2*i+1].maxi;
            aint[i].idx = aint[2*i+1].idx;
        }
        aint[i].lazy = 0;
    }
}

void update(int nod){
    if(stq <= stnod && drnod <= drq){
        aint[nod].maxi += cost;
        aint[nod].lazy += cost;
        return;
    }

    aint[2*nod].lazy += aint[nod].lazy;
    aint[2*nod+1].lazy += aint[nod].lazy;
    aint[2*nod].maxi += aint[nod].lazy;
    aint[2*nod+1].maxi += aint[nod].lazy;
    aint[nod].lazy = 0;

    int mij = (stnod + drnod) / 2;
    if(stq <= mij){
        int drnod1 = drnod;
        drnod = mij;

        update(2*nod);

        drnod = drnod1;
    }
    if(drq > mij){
        int stnod1 = stnod;
        stnod = mij + 1;

        update(2*nod + 1);

        stnod = stnod1;
    }

    if(aint[2*nod].maxi >= aint[2*nod+1].maxi)
        aint[nod].maxi = aint[2*nod].maxi, aint[nod].idx = aint[2*nod].idx;
    else
        aint[nod].maxi = aint[2*nod+1].maxi, aint[nod].idx = aint[2*nod+1].idx;
}

int main()
{

    cin >> n >> k;
    for(int i=1; i<n; i++){
        int nod1, nod2;
        ll cost;
        cin >> nod1 >> nod2 >> cost;
        nod[nod1].push_back({nod2, cost});
        nod[nod2].push_back({nod1, cost});
    }

    for(int root=1; root<=n; root++){
        sus[root] = 0;
        currLeaf = 0;

        ll ans = 0;
        for(int i=1; i<=n; i++)
            leafInt[i] = {-1, -1};
        dfs(root);

        buildAint(root);

        for(int i=1; i<=k; i++){
            int idx = aint[1].idx;
            if(aint[1].maxi == 0)
                break;
            while(tata[idx] && sus[idx] != -1){
                stnod = 1;
                drnod = m;
                stq = leafInt[idx].f;
                drq = leafInt[idx].s;
                cost = -sus[idx];
                update(1);

                ans += sus[idx];
                sus[idx] = -1;
                idx = tata[idx];
            }
        }

        cout << ans << '\n';
    }

    return 0;
}
