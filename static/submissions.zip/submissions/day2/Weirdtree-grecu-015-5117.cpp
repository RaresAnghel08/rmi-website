/**
* user:  grecu-015
* fname: Tudor Stefan
* lname: Grecu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:02:51.895910
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

using namespace std;

const int MAXN = 80005;

int tree[4 * MAXN];
int sum[4 * MAXN];
int pos[4 * MAXN];
int sz;

void update( int node, int l, int r, int x, int p ) {
  if ( l == r ) {
    tree[node] = sum[node] = x;
    pos[node] = p;
    return;
  }
  int mid = (l + r) / 2;
  if ( p <= mid ) update( 2 * node, l, mid, x, p );
  else update( 2 * node + 1, mid + 1, r, x, p );

  if ( tree[2 * node] >= tree[2 * node + 1] ) {
    tree[node] = tree[2 * node];
    pos[node] = pos[2 * node];
  } else {
    tree[node] = tree[2 * node + 1];
    pos[node] = pos[2 * node + 1];
  }
  sum[node] = sum[2 * node] + sum[2 * node + 1];
}

long long querySum( int node, int l, int r, int x, int y ) {
  long long res = 0;
  if ( x <= l && r <= y ) {
    return sum[node];
  }
  int mid = (l + r) / 2;
  if ( x <= mid ) res += querySum( 2 * node, l, mid, x, y );
  if ( y > mid ) res += querySum( 2 * node + 1, mid + 1, r, x, y );
  return res;
}

pair<int, int> queryMax( int node, int l, int r, int x, int y ) {
  pair<int, int> best;
  if ( x <= l && r <= y ) {
    return {tree[node], -pos[node]};
  }
  int mid = (l + r) / 2;
  if ( x <= mid ) best = max(best, queryMax( 2 * node, l, mid, x, y ));
  if ( y > mid ) best = max(best, queryMax( 2 * node + 1, mid + 1, r, x, y ));
  return best;
}

void initialise( int N, int Q, int h[] ) {
  sz = N;
  for ( int i = 1; i <= N; ++i ) {
    update( 1, 1, N, h[i], i );
  }
}
void cut( int l, int r, int k ) { /// k == 1
  pair<int, int> res = queryMax( 1, 1, sz, l, r );
  res.second *= -1;
  update( 1, 1, sz, res.first - 1, res.second );
}
void magic( int p, int x ) {
  update( 1, 1, sz, x, p );
}
long long inspect( int l, int r ) {
  return querySum( 1, 1, sz, l, r );
}

