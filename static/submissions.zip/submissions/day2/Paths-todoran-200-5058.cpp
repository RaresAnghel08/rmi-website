/**
* user:  todoran-200
* fname: Alexandru Raul
* lname: Todoran
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:58:13.774979
*/
/**
 ____ ____ ____ ____ ____
||a |||t |||o |||d |||o ||
||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|

**/

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int N_MAX = 100000;

int N, K;

struct Edge {
    int to;
    int len;
};

vector <Edge> adj[N_MAX + 2];

int parent[N_MAX + 2];
int plen[N_MAX + 2];

vector <int> leafs;

void dfs (int u) {
    bool isLeaf = true;
    for (Edge e : adj[u]) {
        if (e.to != parent[u]) {
            parent[e.to] = u;
            plen[e.to] = e.len;
            isLeaf = false;
            dfs(e.to);
        }
    }
    if (isLeaf == true) {
        leafs.push_back(u);
    }
}

int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    cin >> N >> K;

    for (int i = 1; i <= N - 1; i++) {
        int u, v, len;
        cin >> u >> v >> len;
        adj[u].push_back(Edge{v, len});
        adj[v].push_back(Edge{u, len});
    }

    for (int root = 1; root <= N; root++) {
        parent[root] = 0;
        plen[root] = 0;
        dfs(root);

        int answer = 0;
        for (int it = 1; it <= K; it++) {
            int best = -1;
            int maxLen = INT_MIN;
            for (int u : leafs) {
                int len = 0;
                int v = u;
                while (v != root) {
                    len += plen[v];
                    v = parent[v];
                }
                if (len > maxLen) {
                    best = u;
                    maxLen = len;
                }
            }
            if (best == -1) {
                break;
            }
            answer += maxLen;
            int v = best;
            while (v != root) {
                plen[v] = 0;
                v = parent[v];
            }
        }

        cout << answer << "\n";
    }

    return 0;
}
