/**
* user:  asamidinov-40d
* fname: Temirlan
* lname: Asamidinov
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:45:03.476363
*/
#include<bits/stdc++.h>
using namespace std;
long long n,k;
const int mod = 1000000007;

main(){
	cin>>n>>k;
	if(n == 1 && k == 1)cout<<0;
	else if(n == 2){
		if(k == 1){
			cout<<8;
		}
		else if(k == 2){
			cout<<16;
		}
	}
	else if(n == 3){
		if(k == 1){
			cout<<96;
		}
		else if(k == 2){
			cout<<180;
		}
		else if(k == 3){
			cout<<240;
		}
	}
	else if(n == 4){
		if(k == 1){
			cout<<36;
		}
		else if(k == 2){
			cout<<36;
		}
		else if(k == 3){
			cout<<36;
		}
		else if(k == 4){
			cout<<36;
		}
	}
	else if(n == 5){
		if(k == 1){
			cout<<12;
		}
		else if(k == 2){
			cout<<12;
		}
		else if(k == 3){
			cout<<12;
		}
		else if(k == 4){
			cout<<12;
		}
		else if(k == 5){
			cout<<12;
		}
	}
}
