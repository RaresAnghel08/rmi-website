/**
* user:  kuchynski-16c
* fname: Ilya
* lname: Kuchynski
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:10:10.717668
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 3e5 + 20;

struct node{
      pair<int, int> mx;
//      int cnt_max;
//      int sec_max;
      ll sum;
      node(){
            mx = make_pair(-1, -1);
            sum = 0;
//            cnt_max = sec_max = -1;
      }
};

node t[4 * N];


node merge(node a, node b){
      node c;
      if(a.mx.first >= b.mx.first)
            c.mx = a.mx;
      else
            c.mx = b.mx;
      c.sum = a.sum + b.sum;
      return c;
//      if(a.mx != c.mx)
//            c.sec_max = max(b.sec_max, a.mx;
//      else if(b.mx != c.mx)
}

int h[N], n, q;

void build(int v, int tl, int tr){
      if(tl == tr){
            t[v].mx = make_pair(h[tl], tl);
//            t[v].cnt_max = 1;
//            t[v].sec_max = 0;
            t[v].sum = h[tl];
            return;
      }
      int tm = (tl + tr) / 2;
      build(v * 2, tl, tm);
      build(v * 2 + 1, tm + 1, tr);
      t[v] = merge(t[v * 2], t[v * 2 + 1]);
//      cout << " build " << tl << " " << tr << " : " << t[v * 2].mx.first << " " << t[v * 2].mx.second << endl;
}

void upd(int v, int tl, int tr, int pos, int x){
      if(tl == tr){
            h[tl] = x;
            t[v].mx = make_pair(h[tl], tl);
//            t[v].cnt_max = 1;
//            t[v].sec_max = 0;
            t[v].sum = h[tl];
            return;
      }
      int tm = (tl + tr) / 2;
      if(pos <= tm)
            upd(v * 2, tl, tm, pos, x);
      else
            upd(v * 2 + 1, tm + 1, tr, pos, x);
      t[v] = merge(t[v * 2], t[v * 2 + 1]);
}

node get(int v, int tl, int tr, int l, int r){
      if(l > r)
            return node();
      if(tl == l && tr == r)
            return t[v];
      int tm = (tl + tr) / 2;
      auto x = get(v * 2, tl, tm, l, min(r, tm));
      auto y = get(v * 2 + 1, tm + 1, tr, max(l, tm + 1), r);
      return merge(x, y);
}


void initialise(int _N, int _Q, int hx[]) {
      n = _N;
      q = _Q;
      for(int i = 1; i <= _N; i ++)
            h[i] = hx[i];//, cur_max = max(cur_max, h[i]);
	// Your code here.
	build(1, 1, n);
}
void cut(int l, int r, int k) {

      while(k > 0){
            auto v = get(1, 1, n, l, r);
//            cout << v.mx.first << " : " << v.mx.second << endl;
//            break;
            if(v.mx.first <= 0)
                  break;
            upd(1, 1, n, v.mx.second, v.mx.first - 1);
            -- k;
      }

	// Your code here.
}
void magic(int i, int x) {
      upd(1, 1, n, i, x);
	// Your code here.
}
long long int inspect(int l, int r) {

	auto v = get(1, 1, n, l, r);
	return v.sum;

	// Your code here.
//	return -1;
}
