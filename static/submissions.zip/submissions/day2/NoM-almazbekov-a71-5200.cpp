/**
* user:  almazbekov-a71
* fname: Beksultan
* lname: Almazbekov
* task:  NoM
* score: 9.0
* date:  2021-12-17 09:09:44.106683
*/
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define fr first
#define sc second
#define OK puts("OK");
#define endi puts("");
#define ret return
#define all(s) s.begin(),s.end()
#define allr(s) s.rbegin(),s.rend()
#define pii pair<int,int> 
const int N = 1e5+12;
vector <pii> g[N];
vector <int> v[N];
int up[21][N],upsum[21][N],l,tin[N],tout[N],cntt;

/*
void dfs(int x,int p,int c){
	up[0][x] = p;upsum[0][x] = c;tin[x] = cntt++;
	for(int i=1;i<=20;++i){
		up[i][x] = up[i-1][up[i-1][x]];
		upsum[i][x] = upsum[i-1][x]+upsum[i-1][up[i-1][x]];
	}
	for (auto to:g[x]){
		if (to.fr == p)continue;
		dfs(to.fr,x,to.sc);
	}tout[x] = cntt++;
}
bool predok(int a,int b){ret (tin[a] <= tin[b] && tout[b] <= tout[a]);}
int find_lca(int a,int b){
	if (predok(a,b))ret a;
	if (predok(b,a))ret b;
	for (int i=20;i>=0;--i)
		if (!predok(up[i][a],b)){
			a = up[i][a];
		}
	ret up[0][a];
}
int lcasum(int a,int b){
	int sum = 0;
	for (int i=20;i>=0;--i)
		if (!predok(up[i][b],a)){
			sum += upsum[i][b];
			b = up[i][b];
		}
	ret upsum[0][b]+sum;
}

int sumsum(int a,int b){
	int lca = find_lca(a,b);
	int x = lcasum(lca,a);
	int y = lcasum(lca,b);
	ret x+y;
}



bool used[N];
int as[N];
void dffs(int x,int p,int c){
	as[x] = c;
	
	for (auto to: g[x]){
		if (to.fr == p)continue;
		
		if (used[x] == 0 || used[to.fr] == 0)
			dffs(to.fr,x,c+to.sc);
		else dffs(to.fr,x,c);
		
	}
}
vector <int> vv;

void dfss(int x,int p,int c){
	vv.pb(x);
	if (x == c){
		for(auto f: vv)used[f] = 1;
	}
	
	for (auto to: g[x]){
		if (to.fr == p)continue;
		
		dfss(to.fr,x,c);
		
	}
	vv.pop_back();
	
}


int sum[N],ans[N];
void dfs1(int x,int p){
	
	for (auto to: g[x]){
		if (to.fr == p)continue;
		dfs1(to.fr,x);
		sum[x] = max(sum[x],sum[to.fr]+to.sc);
	}
}


void dfs(int x,int p,int c){
	vector <pii> v;
	for (auto to: g[x]){
		if (to.fr == p)continue;
		v.pb({sum[to.fr]+to.sc,to.fr});
	}
	sort(allr(v));
	ans[x] = sum[x];
	if (v.size() > 0)
		ans[x] = max(v[0].fr,ans[x]);
	ans[x] = max(ans[x],c);
	for (auto to: g[x]){
		
		if (to.fr == p)continue;
		int mx = c;
		if (to.fr == v[0].sc && v.size()>1)
			mx = max(mx,v[1].fr);
		else 
			mx = max(mx,v[0].fr);
		
		dfs(to.fr,x,mx+to.sc);
	}
	
	
	
}
*/
bool is[6][6];

main(){
	int n,i,m,ans=0,j;
	cin>>n>>m;
	vector <pii> v;
	for (i=1;i<=n;++i){
		v.pb({i,0});
		v.pb({i,1});
	}
	sort(all(v));
	if (n > 5)ret 0;
	do {
		bool f=1;
		for (i=0;i<v.size();++i){
			if (is[i%m][v[i].fr] == 1){
				f =0 ;
				break;
			}
			is[i%m][v[i].fr] = 1;
		}
		if (f == 1)
			ans++;
		for (i=0;i<6;++i)for(j=0;j<6;++j)is[i][j] = 0;
		
	}while(next_permutation(all(v)));
	
	cout <<ans;
}









