/**
* user:  nadareishvili-7bf
* fname: Giorgi
* lname: Nadareishvili
* task:  Paths
* score: 56.0
* date:  2021-12-17 10:05:30.854336
*/
#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int N = 2003;
int n, k, up[N], wh[N];
vector<pair<int, int>> vi[N], v[N], vv[N];
vector<pair<ll, int>> u;
ll fp[N];

void init(int x, int y = 0) {
    up[x] = y;
    for(auto p : vi[x]) {
        if(p.first != y) {
            wh[p.first] = v[x].size();
            v[x].push_back(p);
            vv[x].push_back(p);
            init(p.first, x);
        }
    }
}

pair<ll, int> mxv(int x) {
    pair<ll, int> y = {0, x};
    for(auto p : v[x]) {
        pair<ll, int> z = mxv(p.first);
        z.first += p.second;
        y = max(y, z);
    }
    return y;
}


bool ub[N];
void init2(int x) {
    for(;;) {
        pair<ll, int> z = mxv(x);
        if(!z.first) break;
        int y = z.second;
        while(y != x) {
            v[up[y]][wh[y]].second = 0;
            y = up[y];
        }
        u.push_back(z);
        ub[z.second] = 1;
    }
    for(int i = 1; i <= n; ++i) {
        if(ub[i] == 0) {
            ub[i] = 1;
            u.push_back(pair<ll, int>(0, i));
        }
    }
}

ll extract() {
    // for(int i = 0; i < n; ++i) {
    //     cout << "[] " << u[i].first << " " << u[i].second << "\n";
    // } cout << endl;
    ll x = 0;
    multiset<ll> s;
    for(auto p : u) {
        s.insert(p.first);
        x += p.first;
        if(s.size() == k + 1) {
            x -= (*s.begin());
            s.erase(s.begin());
        }
    }
    return x;
}

bitset<N> bo;
void exg(int x) {
    bo[x] = 1;
    for(auto p : v[x]) {
        exg(p.first);
    }
}

void dfs(int x) {
    // cout << x << " vv\n";
    fp[x] = extract();
    for(auto p : vv[x]) {
        bo = 0;
        exg(p.first);
        pair<ll, int> mx[2] = {{0, 0}, {0, 0}};
        for(int i = 0; i < n; ++i) {
            int w = u[i].second;
            mx[bo[w]] = max(mx[bo[w]], pair<ll, int>(u[i].first, i));
        }
        // cout << x << endl;
        u[mx[0].second].first += p.second;
        u[mx[1].second].first -= p.second;
        // cout << p.first << " vvvv\n";
        // cout << "+" << u[mx[0].second].second << " -" << u[mx[1].second].second << endl << endl;
        dfs(p.first);
        u[mx[0].second].first -= p.second;
        u[mx[1].second].first += p.second;
    }
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n >> k; if(n == 1) return cout << 0 << endl, 0;
    if(n > 2000) return 0;
    for(int i = 1; i < n; ++i) {
        int x, y, z;
        cin >> x >> y >> z;
        vi[x].push_back({y, z});
        vi[y].push_back({x, z});
    }
    init(1);
    init2(1);
    dfs(1);
    for(int i = 1; i <= n; ++i) {
        cout << fp[i] << "\n";
    }
    return 0;
}
