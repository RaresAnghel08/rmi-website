/**
* user:  savu-e4c
* fname: Ştefan Cătălin
* lname: Savu
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:56:11.540139
*/
#include <iostream>
#include <vector>
#include <map>
using namespace std;
int n,k,i,x,y,j,ma,kk,t[100005],eul[400005],cnt,first[100005],last[100005],app[100005];
long long ii,val;
pair<long long ,int > ar[800005],ma2;
vector <pair<int ,int > >v[100005];
vector <int> v2[100005];
map <pair<int,int>,int> mat;
long long lazy[800005],sum;
static inline void upd(int st,int dr,int nod)
{
    lazy[nod]=0LL;
    ar[nod].second=eul[st];
    ar[nod].first=0LL;
    if (st==dr) return ;
    int mij=(st+dr)/2;
    upd(st,mij,nod*2);
    upd(mij+1,dr,nod*2+1);
}
static inline void propag(int nod)
{
    lazy[nod*2]+=lazy[nod];
    lazy[nod*2+1]+=lazy[nod];
    ar[nod].first+=lazy[nod];
    lazy[nod]=0;
}
static inline pair<long long,int> my(pair<long long,int> a,pair<long long,int> b)
{
    if (a.first>b.first) return a;
    return b;
}
static inline void update(int st,int dr,int nod,int qa,int qb,long long val)
{
    propag(nod);
    if (qa<=st&&dr<=qb)
    {
        lazy[nod]+=val;
        propag(nod);
        return;
    }
    int mij=(st+dr)/2;
    propag(nod*2);
    propag(nod*2+1);
    if (qa<=mij) update(st,mij,nod*2,qa,qb,val);
    if (qb>mij) update(mij+1,dr,nod*2+1,qa,qb,val);
    ar[nod]=my(ar[nod*2],ar[nod*2+1]);
}
static inline void dfs(int nod,int tata)
{
    t[nod]=tata;
    eul[++cnt]=nod;
    eul[cnt+2*n-1]=nod;
    first[nod]=cnt;
    for (int i=0;i<v[nod].size();++i)
        if (v[nod][i].first!=tata)
            {dfs(v[nod][i].first,nod); eul[++cnt]=nod;     eul[cnt+2*n-1]=nod;
}
    last[nod]=cnt;
}
pair<long long,long long> query(long long st,long long dr,long long nod,long long qa,long long qb)
{
    propag(nod);
    if (qa<=st&&dr<=qb)
    {
        return ar[nod];
    }
    long long mij=(st+dr)/2;
    pair<long long,long long> ras1,ras2;
    if (qa<=mij) ras1=query(st,mij,nod*2,qa,qb);
    if (qb>mij) ras2=query(mij+1,dr,nod*2+1,qa,qb);
    return my(ras1,ras2);
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>k;
    for (i=1;i<n;++i)
    {
        cin>>x>>y>>val;
        v[x].push_back({y,val});
        v[y].push_back({x,val});
        mat[{x,y}]=mat[{y,x}]=val;
    }
    dfs(1,0);
    for (i=1;i<=4*n-2;++i)
        if (i!=first[eul[i]]) v2[eul[i]].push_back(i);
    for (j=1;j<=n;++j)
        if (t[j]) update(1,4*n,1,first[j],last[j],mat[{j,t[j]}]);
    for (ii=1;ii<=2*n-1;++ii)
    {
        if (app[eul[ii]]==0){
        propag(1);
        cout<<ar[1].first<<'\n';
        app[eul[ii]]=1;}
        update(1,4*n,1,first[eul[ii]],last[eul[ii]],mat[{eul[ii],eul[ii+1]}]);
        update(1,4*n,1,first[eul[ii+1]],last[eul[ii+1]],(-2)*mat[{eul[ii],eul[ii+1]}]);
        last[eul[ii+1]]=ii+2*n-1;
        first[eul[ii]]=v2[eul[ii]][0];
        v2[eul[ii]].pop_back();
    }
    return 0;
}
///1 2 3 4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1
///  2 3 4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2
///    3 4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2 3
///      4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2 3 4
///        3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2 3 4 3
