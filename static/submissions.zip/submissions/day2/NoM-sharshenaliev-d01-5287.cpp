/**
* user:  sharshenaliev-d01
* fname: Nazar
* lname: Sharshenaliev
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:17:02.598370
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;
main(){
	int n , m;
	cin >> n >> m;
	vector <int> v;
	for (int i = 1; i <= n; i++){
		v.push_back(i);
		v.push_back(i);
	}
	sort(v.begin() , v.end());
	int cnt = 0 , ans = 0;
	do{
	int ok  = 0;
	for (int i = 0; i < n * 2 - m; i++){
		if(v[i] == v[i + m]){ok = 1; break;
		}
	}
	if(!ok)ans++;
	}while(next_permutation(v.begin() , v.end()));
	cout << ans << endl;
	return 0;
}