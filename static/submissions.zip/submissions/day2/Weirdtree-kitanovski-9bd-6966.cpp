/**
* user:  kitanovski-9bd
* fname: Teo 
* lname: Kitanovski
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:27:43.156896
*/
#include <bits/stdc++.h>
#ifndef LOCAL_DEBUG
    #include "weirdtree.h"
#endif // LOCAL_DEBUG

typedef long long ll;

#define MS(x,y) memset((x), (y), sizeof((x)))
#define pb push_back
#define MN 1000000007

using namespace std;

ll n,q,niza[1001];

void initialise (int n2, int q2, int niza2[]) {
    n = n2;
    q = q2;
    for (int i = 0; i<n; i++) niza[i] = niza2[i];
}

void cut(int l, int r, int k) {
    l--; r--;

    for (int i = 0; i<k; i++) {
        int maxi = -1, maxiI = -1;

        for (int j = l; j<=r; j++) {
            if (niza[j] > maxi) {
                maxi = niza[j];
                maxiI = j;
            }
        }

        if (maxi != 0) niza[maxiI]--;
    }
}

ll inspect(int l, int r) {
    l--; r--;

    ll sum = 0;

    for (int i = l; i<=r; i++) sum += niza[i];

    return sum;
}

void magic (int i, int x) {
    i--;

    niza[i] = x;
}

#ifdef LOCAL_DEBUG
int main() {
    #ifdef LOCAL_DEBUG
        fstream cin("in.txt");
    #endif // LOCAL_DEBUG

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int n3,q3;
    cin>>n3>>q3;

    int niza3[n3];
    for (int i = 0; i<n3; i++) cin>>niza3[i];

    initialise(n3,q3,niza3);

    for (int i = 0; i<q3; i++) {
        int t;
        cin>>t;

        if (t == 1) {
            int a,b,c;
            cin>>a>>b>>c;
            cut(a,b,c);
        } else if (t == 2) {
            int a,b;
            cin>>a>>b;
            magic(a,b);
        } else if (t == 3) {
            int a,b;
            cin>>a>>b;
            for (int j = 1; j<=n3; j++) cout<<inspect(j,j)<<" ";
            cout<<endl;
            cout<<inspect(a,b)<<endl;
        }
    }
}
#endif
