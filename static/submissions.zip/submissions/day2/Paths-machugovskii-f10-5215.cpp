/**
* user:  machugovskii-f10
* fname: Ivan
* lname: Machugovskii
* task:  Paths
* score: 36.0
* date:  2021-12-17 09:11:06.571054
*/
#include <bits/stdc++.h>

using namespace std;

#define int long long


vector<vector<pair<int, int>>> adj;
vector<vector<int>> dp;
vector<int> dp_longest_path;


void dfs(int u, int p) {
	dp[u].push_back(0);

	for(auto pp: adj[u]) {
		int v = pp.first;
		int c = pp.second;
		if(v != p) {
			dfs(v, u);
			dp[u].push_back(c + dp_longest_path[v]);
		}
	}

	auto it = max_element(dp[u].begin(), dp[u].end());
	dp_longest_path[u] = *it;
	dp[u].erase(it);

	for(auto pp: adj[u]) {
		int v = pp.first;
		if(v != p) {
			if(dp[v].size() > dp[u].size()) {
				swap(dp[u], dp[v]);
			}
			for(int x: dp[v]) {
				dp[u].push_back(x);
			}
		}
	}
}


signed main() {
	int n, k;
	cin >> n >> k;

	adj.resize(n);
	for(int i = 0; i < n - 1; i++) {
		int u, v, c;
		cin >> u >> v >> c;
		u--; v--;
		adj[u].emplace_back(v, c);
		adj[v].emplace_back(u, c);
	}

	for(int u = 0; u < n; u++) {
		dp.clear();
		dp_longest_path.clear();
		dp.resize(n);
		dp_longest_path.resize(n);
		dfs(u, -1);

		int c = dp_longest_path[u];
		sort(dp[u].rbegin(), dp[u].rend());
		for(int i = 0; i < k - 1 && i < dp[u].size(); i++) {
			c += dp[u][i];
		}
		cout << c << "\n";
	}

	return 0;
}
