/**
* user:  dimitrova-a26
* fname: Emiliana Ivanova
* lname: Dimitrova
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:58:05.793511
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
using namespace std;
const long long MAXN=300005;
vector<pair<long long, long long>> tree[4*MAXN], ans;
long long sum[4*MAXN], H[MAXN], n;
void merge_sort(vector<pair<long long, long long>> &indi, vector<pair<long long, long long>> &ind1, vector<pair<long long, long long>> &ind2){
    long long p1=0, p2=0;
    vector<pair<long long, long long>> ind;
    while(!(p1==ind1.size() and p2==ind2.size())){
        if(p1==ind1.size()){
            ind.push_back(ind2[p2]);
            p2++;
        }else if(p2==ind2.size()){
            ind.push_back(ind1[p1]);
            p1++;
        }else{
            if(ind1[p1]>=ind2[p2]){
                ind.push_back(ind1[p1]);
                p1++;
            }else{
                ind.push_back(ind2[p2]);
                p2++;
            }
        }
    }
    indi=ind;
    return;
}
void build(long long ind, long long l, long long r){
    if(l==r){
        sum[ind]=H[l];
        tree[ind].push_back({H[l], l});
        return;
    }
    long long mid=(l+r)/2;
    build(2*ind, l, mid);
    build(2*ind, mid+1, r);
    merge_sort(tree[ind], tree[2*ind], tree[2*ind+1]);
    sum[ind]=sum[2*ind]+sum[2*ind+1];
    return;
}
void update(long long ind, long long l, long long r, long long ql, long long qr, long long x){
    if(l>qr or r<ql)return;
    if(ql<=l and qr>=r){
        tree[ind][0].first+=x;
        sum[ind]+=x;
        return;
    }
    long long mid=(l+r)/2;
    update(2*ind, l, mid, ql, qr, x);
    update(2*ind+1, mid+1, r, ql, qr, x);
    merge_sort(tree[ind], tree[2*ind], tree[2*ind+1]);
    sum[ind]=sum[2*ind]+sum[2*ind+1];
    return;
}
vector<pair<long long, long long>> query1(long long ind, long long l, long long r, long long ql, long long qr){
    if(l>qr or r<ql)return {};
    if(ql<=l and qr>=r){
        return tree[ind];
    }
    long long mid=(l+r)/2;
    vector<pair<long long, long long>> v1=query1(2*ind, l, mid, ql, qr), v2=query1(2*ind+1, mid+1, r, ql, qr);
    merge_sort(ans, ans, v1);
    merge_sort(ans, ans, v2);
    return ans;
}
long long query2(long long ind, long long l, long long r, long long ql, long long qr){
    if(l>qr or r<ql)return 0;
    if(ql<=l and qr>=r){
        return sum[ind];
    }
    long long mid=(l+r)/2;
    return (query2(2*ind, l, mid, ql, qr)+query2(2*ind+1, mid+1, r, ql, qr));
}
void initialise(int N, int Q, int h[]){
    for(long long i=0; i<N; i++)H[i]=h[i+1];
    n=N;
    build(1, 0, N-1);
    return;
}
void cut(int l, int r, int k){
    ans.clear();
    query1(1, 0, n-1, l-1, r-1);
    long long now=ans[0].first;
    long long br=1;
    while(br<ans.size()){
        if((k/br)>=(now-ans[br].first)){
            now=ans[br].first;
            k-=(now-ans[br].first)*br;
            br++;
        }else{
            now-=(k/br);
            break;
        }
    }
    for(long long i=0; i<ans.size(); i++){
        if(ans[i].first<now)break;
        if(ans[i].first>now){
            update(1, 0, n-1, ans[i].second, ans[i].second, (now-ans[i].first));
        }
    }
    return;
}
void magic( int i , int x ){
    return;
}
long long int inspect(int l, int r){
    return query2(1, 0, n-1, l-1, r-1);
}
