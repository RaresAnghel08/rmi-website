/**
* user:  alexandru andrei-c8e
* fname: Benescu
* lname: Alexandru Andrei
* task:  NoM
* score: 0.0
* date:  2021-12-17 07:26:14.487269
*/
#include <bits/stdc++.h>
#define L 12
using namespace std;
int v[L];
int main(){
  int n, m, i, j, r, good;
  cin >> n >> m;
  for (i = 0; i < n; i++)
    v[i] = i - n;
  for (i = n; i < n + n; i++)
    v[i] = i - n + 1;
  n = n + n;
  r = 0;
  do {
    good = 1;
    for (i = 0; i < n; i++)
      for (j = i + 1; j < n; j++)
        if (v[i] + v[j] == 0 && abs(i - j) % m == 0)
          good = 0;
    r = r + good;
  } while (next_permutation(v, v + n));
  cout << r << "\n";
  return 0;
}
