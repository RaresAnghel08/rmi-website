/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:08:25.106065
*/
#include <bits/stdc++.h>

using namespace std;
#define int long long
#define inf 1e9
int32_t main(void) {
	int n, kk;
	cin >> n >> kk;
	int a[n][n];
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < n; j ++) a[i][j] = inf;
	}
	for(int i = 0; i < n - 1; i ++) {
		int u, v, w;
		cin >> u >> v >> w;
		u --;
		v --;
		a[v][u] = w;
		a[u][v] = w;
	}
	for(int k = 0; k < n; k ++) {
		for(int i = 0; i < n; i ++) {
			for(int j = 0; j < n; j ++) {
				a[i][j] = min(a[i][j], a[i][k] + a[k][j]);
			}
		}
	}
	for(int i = 0; i < n; i ++) {
		cout << *max_element(a[i], a[i]+n) << endl;
	}
	return false;
}