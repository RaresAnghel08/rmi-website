/**
* user:  tazhibaev-879
* fname: Iskhak
* lname: Tazhibaev
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:40:42.271628
*/
#include "weirdtree.h"



vector<pair<int, int> > tree(4 * 100000+50);
vector<int> treesum(4 * 100000 + 50, 0);
vector<int> a;
int siz = 1;
const int INF = 1e9 + 700;
pair<int, int> combine(pair<int, int> &a, pair<int, int> &b){
	if(a.first > b.first) return a;
	if(b.first > a.first) return b;
	if(b.second > a.second) return a;
	else return b;
}


void build(int v, int vl, int vr){
	if(vl == vr){
		tree[v] = {a[vl], vl};
		return; 
	}
	int m = (vl + vr) / 2;
	build(2*v , vl, m);
	build(2 * v +1, m + 1, vr);
	tree[v] =combine(tree[v * 2], tree[v * 2 + 1]);
}
void build_sum(int v, int vl, int vr){
	if(vl == vr){
		treesum[v] = a[vl];
		return; 
	}
	int m = (vl + vr) / 2;
	build_sum(2*v , vl, m);
	build_sum(2 * v +1, m + 1, vr);
	treesum[v] = treesum[v * 2]+ treesum[v * 2 +1];
}

pair<int, int>  get_max(int l, int r, int v, int vl, int vr){
	if(l > vr or vl > r){ 
		return make_pair(-(1e9 + 7), 0);
	}
	if(l <= vl and r >= vr){
		return tree[v];
	}
	int m = (vl + vr) / 2;
	pair<int, int> mx1 = get_max(l, r, 2 * v, vl, m);
	pair<int, int> mx2 = get_max(l, r, 2 * v + 1, m + 1, vr);
	return combine(mx1, mx2);
}
long long int get_sum(int l, int r, int v, int vl, int vr){
	if(l > vr or vl > r) return 0;
	if(l <= vl and r >= vr){ 
		return treesum[v];
	}
	int m = (vl + vr) / 2;
	int sum1 = get_sum(l, r, v * 2, vl, m);
	int sum2 = get_sum(l, r, v * 2 + 1, m + 1, vr);
	return sum1 +sum2;
}




void initialise(int N, int Q, int h[]) {
	
	while(N > siz) siz*= 2;
	treesum.assign(2 *siz +100, 0);
	tree.assign(2 * siz+100, {-INF, 0});
	a.push_back(0);
	for(int i = 1;i <= N; i++){
		a.push_back(h[i]);
	}
	build(1, 1, siz);
	build_sum(1, 1, siz);
}
void cut(int l, int r, int k) {
		for(int j = 1;j <= k; j++){
			pair<int, int> mx = get_max(l, r, 1, 1, siz);
			if(mx.first > 0){
				a[mx.second]-=1;
				build(1, 1, siz);
				build_sum(1, 1, siz);
			}
		}
}
void magic(int i, int x) {
			a[i] = x;
			build(1,1, siz);
			build_sum(1, 1, siz);
}
long long int inspect(int l, int r) {
	return get_sum(l, r,1, 1, siz);
}