/**
* user:  stancu-88b
* fname: Sergiu Nicolae
* lname: Stancu
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:57:27.299840
*/
#include <bits/stdc++.h>
#define nl '\n'
#define pb push_back
#define mp make_pair
#define nod first
#define cost second
#define ll long long
using namespace std;
const int NMAX = 100002;
vector<pair<int, int>>G[NMAX], F[NMAX];
int K, rad;
void DFSfii ( int x, int tata )
{
    for ( auto i : G[x] )
        if ( i.nod != tata )
        {
            F[x].pb ( i );
            DFSfii ( i.nod, x );
        }
}
ll dp[NMAX][3], dp2[NMAX][3];
void DFS ( int x )
{
    for ( int i = 0; i < F[x].size(); i++ )
    {
        DFS ( F[x][i].nod );

        for ( int kk = 1; kk <= K; kk++ )
        {
            for ( int kkk = 1; kkk <= kk; kkk++ )
                dp2[x][kk] = max ( dp2[x][kk], dp[F[x][i].nod][kkk] + dp[x][kk - kkk] + F[x][i].cost );
        }

        for ( int kk = 1; kk <= K; kk++ )
        {
            dp[x][kk] = max ( dp[x][kk], dp2[x][kk] );
            dp2[x][kk] = 0;
        }
    }
}
ll ans[NMAX];
void mutradacina ( int x, int y ) /// din x in y
{
    for ( int i = 0; i <= K; i++ )
        dp[x][i] = 0;

    ll pret = 0;

    for ( unsigned contor = 0; contor < G[x].size(); contor++ )
        if ( G[x][contor].nod != y )
        {
            for ( int kk = 1; kk <= K; kk++ )
                for ( int kkk = 1; kkk <= kk; kkk++ )
                    dp2[x][kk] = max ( dp2[x][kk], dp[G[x][contor].nod][kkk] + dp[x][kk - kkk] + G[x][contor].cost );

            for ( int kk = 1; kk <= K; kk++ )
            {
                dp[x][kk] = max ( dp[x][kk], dp2[x][kk] );
                dp2[x][kk] = 0;
            }
        }
        else
            pret = G[x][contor].cost;

    for ( int kk = 1; kk <= K; kk++ )
        for ( int kkk = 1; kkk <= kk; kkk++ )
            dp2[y][kk] = max ( dp2[y][kk], dp[x][kkk] + dp[y][kk - kkk] + pret );

    for ( int kk = 1; kk <= K; kk++ )
    {
        dp[y][kk] = max ( dp[y][kk], dp2[y][kk] );
        dp2[y][kk] = 0;
    }
}
void DFS2 ( int x, int tata )
{
    ans[x] = dp[x][K];

    for ( auto i : G[x] )
        if ( ans[i.nod] == 0 )
        {
            mutradacina ( x, i.nod );
            DFS2 ( i.nod, x );
        }

    if ( tata != 0 )
        mutradacina ( x, tata );
}
int main()
{
    cin.tie ( 0 )->sync_with_stdio ( 0 );
    cin.tie ( NULL );
    cout.tie ( NULL );
    int N;
    cin >> N >> K;

    for ( int i = 1; i < N; i++ )
    {
        int x, y, c;
        cin >> x >> y >> c;
        G[x].pb ( mp ( y, c ) );
        G[y].pb ( mp ( x, c ) );
    }

    rad = 1;
    DFSfii ( rad, 0 );
    DFS ( rad );
    ans[rad] = dp[1][K];
//cout<<dp[1][K]<<nl<<nl;;
    DFS2 ( rad, 0 );

//    for ( int i = 1; i <= N; i++ )
//    {
//        rad = i;
//
//        for ( int j = 1; j <= N; j++ )
//        {
//            F[j].clear();
//
//            for ( int kk = 0; kk <= K; kk++ )
//                dp[j][kk] = dp2[j][kk] = 0;
//        }
//
//        DFSfii ( rad, 0 );
//        DFS ( rad );
//        cout << dp[rad][K] << nl;
//    }
    for ( int i = 1; i <= N; i++ )
        cout << ans[i] << nl;

    return 0;
}
