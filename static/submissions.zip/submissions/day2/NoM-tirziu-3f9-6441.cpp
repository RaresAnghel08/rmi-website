/**
* user:  tirziu-3f9
* fname: Petre
* lname: Tirziu
* task:  NoM
* score: 9.0
* date:  2021-12-17 10:53:11.520096
*/
#include <iostream>

using namespace std;
const int mod = 1e9 + 7;
long long cnt = 0, n, m;
int f[15], ans[115];
void backt(int poz)
{
    int i, j;
    if(poz == 2 * n + 1){
        bool ok = true;
        for(i = 1; i <= 2 * n; i++){
            for(j = i + m; j <= 2 * n; j += m)
                if(ans[j] == ans[i]){
                    ok = false;
                    break;
                }
            if(ok == false)
                break;
        }
        if(ok == true){
            cnt++;
        }
        if(cnt >= mod)
            cnt %= mod;
        return ;
    }
    for(i = 1; i <= n; i++)
        if(f[i] <= 1){
            ans[poz] = i;
            f[i]++;
            backt(poz + 1);
            f[i]--;
            ans[poz] = 0;
        }
    return ;
}
int main()
{
    int i;
    cin >> n >> m;
    backt(1);
    int fact = 1;
    cout << (1 << n) * cnt;
    return 0;
}
