/**
* user:  zagirov-a71
* fname: Ruzil Ravilevich
* lname: Zagirov
* task:  Paths
* score: 19.0
* date:  2021-12-17 08:32:18.590325
*/
#include <bits/stdc++.h>

#pragma GCC optimize("Ofast")
#pragma GCC optimize("avx, avx2")

#define pii pair<int, long long>
#define pb push_back
#define f first
#define s second

using namespace std;

typedef long long ll;
typedef long double ld;

//#define int ll

const int N = 1e3 + 10;
vector<pii > g[N];
vector<pair<pii, ll>> vec;
int k;
ll sum[N];

ll dfs(int v, int p = -1) {
    sum[v] = 0;
    for (auto u: g[v]) {
        if (u.f == p)
            continue;
        sum[v] = max(sum[v], dfs(u.f, v) + u.s);
    }
    return sum[v];
}

void rebuild(int v, int p = -1) {
    for (int i = 0; i < g[v].size(); i++) {
        if (g[v][i].f == p)
            continue;
        if (sum[v] == sum[g[v][i].f] + g[v][i].s) {
            vec.pb({{v, i}, g[v][i].s});
            rebuild(g[v][i].f, v);
            g[v][i].s = 0;
            break;
        }
    }
}

void solve() {
    int n, a, b, c;
    cin >> n >> k;
    for (int i = 0; i < n - 1; i++) {
        cin >> a >> b >> c;
        a--;
        b--;
        g[a].pb({b, c});
        g[b].pb({a, c});
    }
    int old = k;
    for (int i = 0; i < n; i++) {
        ll sum1 = 0;
        k = old;
        while (k--) {
            sum1 += dfs(i);
            rebuild(i);
        }
        for (int j = vec.size() - 1; j >= 0; j--){
            pair<pii, int> u = vec[j];
            g[u.f.f][u.f.s].s = u.s;
        }
        vec.clear();
        cout << sum1 << '\n';
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    solve();
}