/**
* user:  arsenoiu-d07
* fname: Iulian George
* lname: Arsenoiu
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:58:42.655153
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

using namespace std;

struct node
{
    long long poz,sum,Max;
    node()
    {
        poz = sum = Max = 0;
    }
};

node ai[2000005];

node nil;

int n;

int aux[1000005];

void update(int poz, int val, int nod, int a,int b)
{
    if(a==b)
    {
        ai[nod].poz = poz;
        ai[nod].sum = val;
        ai[nod].Max = val;
        return;
    }
    int mij = (a+b)>>1;
    if(poz<=mij)
    {
        update(poz,val,nod*2,a,mij);
    }
    else
    {
        update(poz,val,nod*2+1,mij+1,b);
    }
    ai[nod].sum = ai[nod*2].sum + ai[nod*2+1].sum;
    if(ai[nod*2].Max>=ai[nod*2+1].Max)
    {
        ai[nod].Max = ai[nod*2].Max;
        ai[nod].poz = ai[nod*2].poz;
    }
    else
    {
        ai[nod].Max = ai[nod*2+1].Max;
        ai[nod].poz = ai[nod*2+1].poz;
    }
}

node query(int qa, int qb, int nod, int a, int b)
{
    if(qa==0)
    {
        node rez;
        return rez;
    }
    if(qa<=a && qb>=b)
    {
        return ai[nod];
    }
    int mij = (a+b)>>1;
    node rez1, rez2;
    if(qa<=mij)
    {
        rez1 = query(qa,qb,nod*2,a,mij);
    }
    if(qb>mij)
    {
        rez2 = query(qa,qb,nod*2+1,mij+1,b);
    }
    if(rez1.sum==0)
    {
        return rez2;
    }
    if(rez2.sum==0)
    {
        return rez1;
    }
    node rez;
    rez.sum = rez1.sum+rez2.sum;
    if(rez1.Max>=rez2.Max)
    {
        rez.Max = rez1.Max;
        rez.poz = rez1.poz;
    }
    else
    {
        rez.Max = rez2.Max;
        rez.poz = rez2.poz;
    }
    return rez;
}

void initialise(int N, int q, int h[])
{
    n = N;
    for(int i=1; i<=n; i++)
    {
        update(i,h[i],1,1,n);
    }
}

bool cmp(int i, int j)
{
    return (aux[i]>aux[j] || (aux[i]==aux[j] && i<j));
}

void cut(int l, int r, int k)
{
    if(r-l+1<min(1LL*k,query(l,r,1,1,n).sum))
    {
        vector<int> v;
        for(int i=l;i<=r;i++)
        {
            v.push_back(i);
            aux[i] = query(i,i,1,1,n).sum;
        }
        sort(v.begin(),v.end(),cmp);
        v.push_back(0);
        vector<int> cur;
        for(int i=0;i<v.size()-1;i++)
        {
            int vali = aux[v[i]];
            int valj = aux[v[i+1]];
            cur.push_back(v[i]);
            if(vali==valj)
            {
                continue;
            }
            else
            {
                if(k < 1LL * (cur.size()) * (vali-valj))
                {
                    int cat = k/cur.size();
                    int rest = k%cur.size();
                    int val = vali-cat;
                    for(int j=0;j<cur.size();j++)
                    {
                        update(cur[j],val,1,1,n);
                    }
                    for(int j=0;j<rest;j++)
                    {
                        update(cur[j],val-1,1,1,n);
                    }
                    return;
                }
                k -= (1LL * (cur.size()) * (vali-valj));
            }
        }
        for(int i=l;i<=r;i++)
        {
            update(i,0,1,1,n);
        }
    }
    else
    {
        for(int i=1; i<=k; i++)
        {
            node val = query(l,r,1,1,n);
            if(val.Max==0)
            {
                return;
            }
            update(val.poz,val.Max-1,1,1,n);
        }
    }
}

void magic(int poz, int val)
{
    update(poz,val,1,1,n);
}

long long inspect(int l, int r)
{
    return query(l,r,1,1,n).sum;
}

/*int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int N,Q,H[100005];
    cin>>N>>Q;
    for(int i=1; i<=N; i++)
    {
        cin>>H[i];
    }
    initialise(N,Q,H);
    for(int i=1; i<=Q; i++)
    {
        int t;
        cin>>t;
        if(t==1)
        {
            int l,r,k;
            cin>>l>>r>>k;
            cut(l,r,k);
        }
        else if(t==2)
        {
            int poz,val;
            cin>>poz>>val;
            magic(poz,val);
        }
        else
        {
            int l,r;
            cin>>l>>r;
            cout<<inspect(l,r)<<'\n';
        }
    }
    return 0;
}
*/
