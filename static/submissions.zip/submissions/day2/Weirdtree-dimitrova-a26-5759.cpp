/**
* user:  dimitrova-a26
* fname: Emiliana Ivanova
* lname: Dimitrova
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:57:55.892014
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
using namespace std;
const long long MAXN=300005;
struct node{
    long long maxx, summ, mind;
};
node tree[4*MAXN];
long long H[MAXN], n;
void build(long long ind, long long l, long long r){
    if(l==r){
        tree[ind]={H[l], H[l], l};
        return;
    }
    long long mid=(l+r)/2;
    build(2*ind, l, mid);
    build(2*ind+1, mid+1, r);
    if(tree[2*ind].maxx>=tree[2*ind+1].maxx){
        tree[ind].maxx=tree[2*ind].maxx;
        tree[ind].mind=tree[2*ind].mind;
    }else{
        tree[ind].maxx=tree[2*ind+1].maxx;
        tree[ind].mind=tree[2*ind+1].mind;
    }
    tree[ind].summ=tree[2*ind].summ+tree[2*ind+1].summ;
    return;
}
void update(long long ind, long long l, long long r, long long ql, long long qr, long long x){
    if(l>qr or r<ql)return;
    if(ql<=l and r<=qr){
        tree[ind]={tree[ind].maxx+x, tree[ind].summ+x, l};
        return;
    }
    long long mid=(l+r)/2;
    update(2*ind, l, mid, ql, qr, x);
    update(2*ind+1, mid+1, r, ql, qr, x);
    if(tree[2*ind].maxx>=tree[2*ind+1].maxx){
        tree[ind].maxx=tree[2*ind].maxx;
        tree[ind].mind=tree[2*ind].mind;
    }else{
        tree[ind].maxx=tree[2*ind+1].maxx;
        tree[ind].mind=tree[2*ind+1].mind;
    }
    tree[ind].summ=tree[2*ind].summ+tree[2*ind+1].summ;
    return;
}
void update2(long long ind, long long l, long long r, long long ql, long long qr, long long x){
    if(l>qr or r<ql)return;
    if(ql<=l and r<=qr){
        tree[ind]={x, x, l};
        return;
    }
    long long mid=(l+r)/2;
    update2(2*ind, l, mid, ql, qr, x);
    update2(2*ind+1, mid+1, r, ql, qr, x);
    if(tree[2*ind].maxx>=tree[2*ind+1].maxx){
        tree[ind].maxx=tree[2*ind].maxx;
        tree[ind].mind=tree[2*ind].mind;
    }else{
        tree[ind].maxx=tree[2*ind+1].maxx;
        tree[ind].mind=tree[2*ind+1].mind;
    }
    tree[ind].summ=tree[2*ind].summ+tree[2*ind+1].summ;
    return;
}
pair<long long, long long> m(long long ind, long long l, long long r, long long ql, long long qr){
    if(l>qr or r<ql)return {-1, -1};
    if(ql<=l and r<=qr){
        return {tree[ind].maxx, tree[ind].mind};
    }
    long long mid=(l+r)/2;
    pair<long long, long long> x=m(2*ind, l, mid, ql, qr), y=m(2*ind+1, mid+1, r, ql, qr);
    if(x.first>=y.first)return x;
    return y;
}
long long sum(long long ind, long long l, long long r, long long ql, long long qr){
    if(l>qr or r<ql)return 0;
    if(ql<=l and r<=qr){
        return tree[ind].summ;
    }
    long long mid=(l+r)/2;
    return (sum(2*ind, l, mid, ql, qr)+sum(2*ind+1, mid+1, r, ql, qr));
}
void initialise(int N, int Q, int h[]){
    for(long long i=0; i<N; i++)H[i]=h[i+1];
    n=N;
    build(1, 0, N-1);
    return;
}
void cut(int l, int r, int k){
    pair<long long, long long> ans;
    for(long long i=0; i<k; i++){
        ans=m(1, 0, n-1, l-1, r-1);
        if(ans.first<1)break;
        update(1, 0, n-1, ans.second, ans.second, -1);
    }
    return;
}
void magic( int i , int x ){
    update2(1, 0, n-1, i-1, i-1, x);
    return;
}
long long int inspect(int l, int r){
    return sum(1, 0, n-1, l-1, r-1);
}
