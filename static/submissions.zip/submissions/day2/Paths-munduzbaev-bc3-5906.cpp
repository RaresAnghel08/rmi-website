/**
* user:  munduzbaev-bc3
* fname: Aidar
* lname: Munduzbaev
* task:  Paths
* score: 56.0
* date:  2021-12-17 10:10:20.707540
*/
#include "bits/stdc++.h"
using namespace std;

#define ar array

const int N = 2005;
int sub[N], n, k, ss[N];
long long res[N], dp[N][N], up[N][N];
vector<ar<int, 2>> edges[N];

void dfs(int u, int p = -1){
	sub[u] = 1;
	for(auto e : edges[u]){
		int x = e[0], d = e[1];
		if(x == p) continue;
		dfs(x, u);
		for(int j=sub[u];~j;j--){
			for(int l=sub[x];l>0;l--){
				if(j + l > k) continue;
				dp[u][j + l] = max(dp[u][j + l], dp[u][j] + dp[x][l] + d);
			}
		} sub[u] += sub[x];
		sub[u] = min(sub[u], k);
	}
}

void redfs(int u, int p = -1){
	for(int j=0;j<=k;j++){
		res[u] = max(res[u], dp[u][j] + up[u][k - j]);
	}
	
	for(auto e : edges[u]){
		int x = e[0], d = e[1];
		if(x == p) continue;
		for(int j=0;j<=ss[u];j++) up[x][j] = up[u][j];
		ss[x] = ss[u];
		
		for(int j=ss[u];~j;j--){
			for(int l=sub[x];l>0;l--){
				if(j + l > k) continue;
				up[u][j + l] = max(up[u][j + l], up[u][j] + dp[x][l] + d);
			}
		} ss[u] += sub[x];
		ss[u] = min(ss[u], k);
	}
	
	for(int j=0;j<=ss[u];j++) up[u][j] = 0;
	ss[u] = 1;

	for(int j=(int)edges[u].size()-1;~j;j--){
		int x = edges[u][j][0], d = edges[u][j][1];
		if(x == p) continue;
		for(int j=ss[x];~j;j--){
			for(int l=ss[u];~l;l--){
				if(j + l > k) continue;
				up[x][j + l] = max(up[x][j + l], up[x][j] + up[u][l]);
			}
		} ss[x] += ss[u];
		ss[x] = min(ss[x], k);
		for(int j=ss[x];j>0;j--) up[x][j] += d;
		redfs(x, u);
		
		for(int j=ss[u];~j;j--){
			for(int l=sub[x];l>0;l--){
				if(j + l > k) continue;
				up[u][j + l] = max(up[u][j + l], up[u][j] + dp[x][l] + d);
			}
		} ss[u] += sub[x];
		ss[u] = min(ss[u], k);
	}
}

/*

5 1
1 2 1
2 3 2
3 4 2
4 5 2

*/

signed main(){
	ios::sync_with_stdio(0); cin.tie(0);
	
	cin>>n>>k;
	for(int i=1;i<n;i++){
		int a, b, c; cin>>a>>b>>c;
		edges[a].push_back({b, c});
		edges[b].push_back({a, c});
	}
	
	dfs(1);
	redfs(1);
	for(int i=1;i<=n;i++) cout<<res[i]<<"\n";
}
