/**
* user:  mate-5ef
* fname: Lőrinc
* lname: Máté
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:04:05.861341
*/
#include <bits/stdc++.h>

using namespace std;
using ll = long long;

ll n, k;
vector<vector<pair<ll, ll> > > graph, graph2;
vector<set<pair<ll, ll> > > depths;
vector<bool> visited;

/*

11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1

*/

void dfs (ll pos, ll parent){

    // cout << pos << endl;

    for (pair<ll, ll> x : graph[pos]){
        if (x.second == parent) continue;

        dfs(x.second, pos);
        pair<ll, ll> newDepth = *depths[x.second].rbegin();
        newDepth.first += x.first;
        newDepth.second = x.second;
        // cout << pos << ": " << newDepth.first << " " << newDepth.second << endl;
        depths[pos].insert(newDepth);
    }
    if (depths[pos].size() == 0) depths[pos].insert(make_pair(0, -1));

    // cout << pos << ": " << depths[pos].rbegin() -> second << endl;
}

void dfs2 (ll pos, ll parent, ll startPos){

    // cout << pos << " " << parent << endl;

    pair<ll, ll> nect = *depths[pos].rbegin();
    visited[pos] = true;

    for (pair<ll, ll> x : graph[pos]){
        if (x.second == parent) continue;
        if (x.second == nect.second) continue;
        if (visited[x.second]) continue;

        graph[startPos].push_back(make_pair(0, x.second));
        pair<ll, ll> randomCucc = *depths[x.second].rbegin();
        randomCucc.first += x.first;
        randomCucc.second = x.second;

        // cout << "RandomCucc: " << randomCucc.first << " " << randomCucc.second << endl;

        depths[startPos].insert(randomCucc);
    }

    // cout << nect.first << " " << nect.second << endl;

    if (nect.second != -1) dfs2(nect.second, pos, startPos);
}

ll megold (ll pos){
    graph = graph2;
    visited.assign(n, false);
    depths.assign(n, {});

    // cout << pos << endl;

    dfs(pos, -1);

    // cout << pos << ": " << depths[pos].rbegin() -> second << endl;



    ll mo = 0;

    for (ll i = 0; i < k; i++){
        if (depths[i].rbegin() -> first == 0) break;

        pair<ll, ll> nect = *depths[pos].rbegin();
        visited[nect.second] = true;

        // cout << "kovi: " << nect.first << " " << nect.second << endl;

        depths[pos].erase(nect);

        mo += nect.first;
        dfs2(nect.second, pos, pos);

    }

    return mo;
}

int main()
{
    cin >> n >> k;

    graph.resize(n);

    for (ll i = 0; i < n - 1; i++){
        ll a, b, c;
        cin >> a >> b >> c;

        a--, b--;

        graph[a].push_back(make_pair(c, b));
        graph[b].push_back(make_pair(c, a));
    }

    graph2 = graph;

    for (ll i = 0; i < n; i++) cout << megold (i) << endl;

    return 0;
}

/*

11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1

*/


