/**
* user:  dimitrova-b08
* fname: Niya Radoslavova
* lname: Dimitrova
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:19:25.658579
*/
#include<bits/stdc++.h>
using namespace std;
void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}
int n,m;
int used[1024];
int position[1024];
int ans = 0;
int mod = 1000000007;
void get_perm( int pos )
{
    if( pos > 2 * n )
    {
        ans += 1;
        if( ans > mod ) ans -= mod;
        return;
    }
    for(int i=1; i<=n*2; i++)
    {
        if( used[i] == 0 )
        {
            int rev_p = -1;
            if( i <= n ) rev_p = n + i;
            else rev_p = i - n;
            if( position[rev_p] == -1 )
            {
                used[i] = 1;
                position[pos] = i;
                get_perm(pos+1);
                used[i] = 0;
                position[pos] = -1;
            }
            else
            {
                int raz = abs( position[rev_p] - pos );
                if( raz % m != 0 )
                {
                    used[i] = 1;
                    position[pos] = i;
                    get_perm(pos+1);
                    used[i] = 0;
                    position[pos] = -1;
                }
            }
        }
    }
}
int main()
{
    speed();
    cin >> n >> m;
    get_perm(1);
    cout << ans << endl;
    return 0;
}
