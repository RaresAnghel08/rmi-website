/**
* user:  saitov-09b
* fname: Damir
* lname: Saitov
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:49:45.469041
*/
#include <bits/stdc++.h>
using namespace std;
int n, k;
vector <int> used;
vector <int> dist;
vector < vector < pair <int, int> > > a;
void dfs(int v)
{
    int mem = used[v];
    used[v] = 2;
    for(auto i : a[v])
    {

        if(used[i.second] == 2)
            continue;
        if(used[i.second] == 1)
            dist[i.second] = dist[v];
        else
            dist[i.second] = dist[v] + i.first;
        dfs(i.second);
    }
    used[v] = mem;
}
int mx = -1;
bool flag = false;
void dfs_s(int v)
{
    //for(int i : used)
    //    cout << i << " ";
    //cout << endl;
    if(dist[v] == mx)
    {
        used[v] = 1;
        flag = true;
        //cout  << ">" << v << "<\n";
        return;
    }
    int mem = used[v];
    used[v] = 2;

    for(auto i : a[v])
    {
        if(used[i.second] == 2)
            continue;
        dfs_s(i.second);
        if(flag && used[i.second] == 1)
        {
            used[v] = 1;
            return;
        }
    }
    used[v] = mem;
}
int main()
{
    cin >> n >> k;
    used.resize(n, 0);
    dist.resize(n, -1);
    a.resize(n);
    for(int i = 0; i < n - 1; ++i)
    {
        int ef, es, ew;
        cin >> ef >> es >> ew;
        a[ef - 1].push_back({ew, es - 1});
        a[es - 1].push_back({ew, ef - 1});
    }
    for(int i = 0; i < n; ++i)
    {
        dist[i] = 0;
        int ans = 0;
        for(int j = 0; j < k; ++j)
        {
            dfs(i);
            mx = -1;
            for(int f = 0; f < n; ++f)
            {
                mx = max(mx, dist[f]);
            }
            ans += mx;
            //cout << endl;
            //cout << mx << endl;
            //cout << endl;
            dfs_s(i);
            flag = false;
            //for(int x: used)
                //cout << x << " ";
            //cout << endl;

        }
        cout << ans << '\n';
        for(int j = 0; j < n; ++j)
            used[j] = 0;
    }

}