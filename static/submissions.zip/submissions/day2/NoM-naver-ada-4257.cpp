/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  NoM
* score: 52.0
* date:  2021-12-17 07:26:21.125783
*/
#include <bits/stdc++.h>
typedef long long ll;
#define endl '\n'
using namespace std;
const int N=2010;
const ll mod=1000000007;
int cnt[N*2];
ll dp[N][N];
ll f[N*2];
ll rf[N*2];
ll binpow(ll a,ll b){
    if (!b) return 1ll;
    if (b%2) return binpow(a,b-1)*a%mod;
    else return binpow(a*a%mod,b/2ll);
}
ll C(ll n,ll k){
    if (k>n || k<0) return 0;
    return f[n]*rf[k]%mod*rf[n-k]%mod;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n,m;cin>>n>>m;
    f[0]=rf[0]=1ll;
    for (int i=1;i<=n*2;i++){
        f[i]=(f[i-1]*i)%mod;
        rf[i]=binpow(f[i],mod-2);
    }
    for (int i=1;i<=m;i++){
        cnt[i]=(n*2-i)/m+1;
    }
    ll mult=1ll;
    for (ll i=1;i<=n;i++){
        mult*=2ll*i;
        mult%=mod;
    }
    dp[0][0]=1ll;
    for (int i=1;i<=m;i++){
        for (int j=0;j<=n;j++){
            for (int t=0;t<=min(j,cnt[i]);t++){
                if (j+cnt[i]-t*2>n) continue;
                ll mult=C(j,t)*C(cnt[i],t)%mod*f[t]%mod;
                dp[i][j+cnt[i]-t*2]=(dp[i][j+cnt[i]-t*2]+dp[i-1][j]*mult)%mod;
            }
        }
    }
    cout<<dp[m][0]*mult%mod<<endl;
    return 0;
}
