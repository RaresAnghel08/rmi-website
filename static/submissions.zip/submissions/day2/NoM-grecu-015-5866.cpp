/**
* user:  grecu-015
* fname: Tudor Stefan
* lname: Grecu
* task:  NoM
* score: 9.0
* date:  2021-12-17 10:07:08.337893
*/
#include <iostream>

using namespace std;

int n, m;
int v[2 * 10];
int use1[10], use2[10];

long long res;

void subtask1( int pos ) {
  if ( pos == 2 * n + 1 ) {
    ++res;
    return;
  }
  for ( int i = 1; i <= n; ++i ) {
    if ( use1[i] || (use2[i] && (pos - use2[i]) % m == 0) ) continue;
    v[pos] = i;
    use1[i] = pos;
    subtask1( pos + 1 );
    v[pos] = 0;
    use1[i] = 0;
  }
  for ( int i = 1; i <= n; ++i ) {
    if ( use2[i] || (use1[i] && (pos - use1[i]) % m == 0) ) continue;
    v[pos] = i;
    use2[i] = pos;
    subtask1( pos + 1 );
    v[pos] = 0;
    use2[i] = 0;
  }
}

int main() {
  cin >> n >> m;
  subtask1( 1 );
  cout << res;
  return 0;
}
