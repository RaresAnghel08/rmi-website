/**
* user:  voicu-de1
* fname: Mihai Valeriu
* lname: Voicu
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:38:41.694828
*/
#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>

using namespace std;
using ll=long long;
const int nmax=100005;
int n,k;
#pragma GCC optimize ("O3,Ofast")
#pragma GCC target ("avx2,avx,sse3,sse4")

int rand(int x, int y) {
  return rand()%(y-x+1)+x;
}

vector< pair<int,ll> > tree[nmax];
vector< pair<int,ll> > temp[nmax];

vector<ll> merge(vector<ll> l, vector<ll> r, int cl, ll cr) {
  //int kapa=k;
  //if(r.back()<=50000000)
    //kapa=max(45LL,max((ll)k-50LL,(ll)k*4LL/7LL));
  //else if(r.back()<=5000000000LL)
    //kapa=max(75LL,max((ll)k-20LL,(ll)k*2LL/3LL));
  //else if(r.back()>=5000000000000LL)
    //kapa=rand(k-10,k);
  //else
    //kapa=k;
  //kapa=min(kapa,k);
  vector<ll> rez(min((int)l.size()+(int)r.size()-1,k+1),0);
  for(int i=0; i<l.size(); i++) {
    for(int j=0; j<r.size() && j+i<=k; j++) {
      rez[i+j]=max(rez[i+j],l[i]+(cl*(i>0))+r[j]+(cr*(j>0)));
    }
  }
  return rez;
}

int dp[nmax];
int pin[nmax],pout[nmax],preord[nmax];
int inp;

static bool isanc(int node, int resp) {
  return pin[node]<=pin[resp] && pout[resp]<=pout[node];
}

static void reset(int node, int f, int target) {
  for(auto &x:tree[node]) {
    if(x.first!=f) {
      if(isanc(x.first,target))
        x.second=0,reset(x.first,node,target);
    }
  }
}
static void recalc(int node, int f) {
  for(auto x:tree[node]) {
    if(x.first!=f) {
      dp[x.first]=dp[node]+x.second;
      recalc(x.first,node);
    }
  }
  return;
}
static void init(int node, int f) {
  pin[node]=inp;
  preord[inp++]=node;
  for(auto x:tree[node]) {
    if(x.first!=f)
      init(x.first,node);
  }
  pout[node]=inp-1;
}

static void reroot(int root) {
  memset(dp,0,sizeof(dp));
  inp=0;
  init(root,root);
  int maxx,accum=0;
  for(int tc=0; tc<k; tc++) {
    recalc(root,root);
    maxx=0;
    for(int i=0; i<n; i++) {
      if(dp[i]>dp[maxx])
        maxx=i;
    }
    accum+=dp[maxx];
    reset(root,root,maxx);
  }
  cout << accum  <<'\n';
}

int main() {
  srand(time(0));
  cin >> n >> k;
  k=min(k,n);
  for(int i=1,x,y,w; i<n; i++) {
    cin >> x >> y >> w;
    --x;
    --y;
    tree[x].push_back({y,w});
    tree[y].push_back({x,w});
  }
  for(int i=0; i<n; i++)
    temp[i]=tree[i];
  for(int i=0; i<n; i++) {
    reroot(i);
    for(int j=0; j<n; j++)
      tree[j]=temp[j];
  }
}
