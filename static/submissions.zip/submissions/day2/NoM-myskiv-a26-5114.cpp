/**
* user:  myskiv-a26
* fname: Vladyslav
* lname: Myskiv
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:02:36.709328
*/
#include <bits/stdc++.h>

using namespace std;

long long n, m, a[7], cnt, flag;

int main()
{
    cin>>n>>m;
    for(int i=1; i<=2*n; i+=2){
        a[i]=a[i+1]=i;
    }
    if(m!=1) cnt++;
    while(next_permutation(a+1, a+n+1)){
        flag=1;
        for(int i=1; i<=n-m; i++){
            if(a[i]==a[i+m]) flag=0;
        }
        cnt+=flag;
    }
    cout<<cnt*2;
    return 0;
}
