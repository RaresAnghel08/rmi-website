/**
* user:  dimitrova-b08
* fname: Niya Radoslavova
* lname: Dimitrova
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:53:03.048851
*/
#include<bits/stdc++.h>
using namespace std;
void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}
int n,m;
int perm[1024];
int used[1024];
int position[1024];
int ans = 0;
void get_perm( int pos )
{
    if( pos > 2 * n )
    {
        for(int i=1;i<=n;i++)
        {
            int x = position[i];
            int y = position[n+i];
            int raz = abs( x - y );
            if( raz % m == 0 ) return;
        }
        ans += 1;
        return;
    }
    for(int i=1;i<=n*n;i++)
    {
        if( used[i] == 0 )
        {
            used[i] = 1;
            perm[pos] = i;
            position[i] = pos;
            get_perm(pos+1);
            used[i] = 0;
        }
    }
}
int main()
{
    speed();
    cin >> n >> m;
    get_perm(1);
    cout << ans << endl;
    return 0;
}
