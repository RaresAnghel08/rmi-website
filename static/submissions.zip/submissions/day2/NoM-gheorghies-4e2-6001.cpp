/**
* user:  gheorghies-4e2
* fname: Alexandru
* lname: Gheorghies
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:17:51.780981
*/
#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
int main(){
    ll n,m,ans=0;
    cin>>n>>m;
    ll perm[15];
    for(ll i=1;i<=n;i++)
        perm[i]=i;
    for(ll i=n+1;i<=2*n;i++)
        perm[i]=i+n*m;
    do{
        bool mod[15][15]{};
        bool good=1;
        for(ll i=1;i<=2*n;i++){
            if(mod[perm[i]%m][i%m]){
                good=0;
                break;
            }
            mod[perm[i]%m][i%m]=1;
        }
        ans+=good;
    }while(next_permutation(perm+1,perm+2*n+1));
    cout<<ans;
}
