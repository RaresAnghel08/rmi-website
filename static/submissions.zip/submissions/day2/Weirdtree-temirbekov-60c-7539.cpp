/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:58:23.679981
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

vector <int> t;
int n;
int ppow = 1;
vector <int> H;

void print() {
	for(int i = 0; i < (int)1e6; i += 1) {
		if(i >= 2 * ppow - 1) break;
		cout << (i + 1) << " -> " << t[i] << "\n";
	}
	//cout << ppow << endl;
}

void build(int v, int vl, int vr, const vector <int> & a) {
	if(vl == vr){
		if(vl < n)
			t[v] = a[vl];
	}else {
		int vm = (vl + vr) / 2;
		build(2*v+1, vl, vm, a);
		build(2*v+2, vm+1, vr, a);
		t[v] = t[2*v+1] + t[2*v+2];
	}
}

long long get(int v, int vl, int vr, const int l, const int r) {
	if(vr < l or vl > r) return 0ll;
	else if(l <= vl and vr <= r) return t[v] * 1ll;
	else {
		int vm = (vl + vr) / 2;
		//return 0;
		return get(2*v+1, vl, vm, l, r) + get(2*v+2, vm+1, vr, l, r) + 0ll;
	}
}

void add(int v, int vl, int vr, const int pos,  int x) {
	if(vl == vr) {
		t[v] -= x;
		return;
	}
	int vm = (vl + vr) / 2;
	if(pos <= vm) add(2*v+1, vl, vm, pos, x);
	else add(2*v+2, vm + 1, vr, pos, x);
	t[v] = t[2*v+1] + t[2*v+2];
}

void upd(int v, int vl, int vr, const int pos, int x) {
	if(vl == vr) {
		t[v] = x;
		return;
	}
	int vm = (vl + vr) / 2;
	if(pos <= vm) upd(2*v+1, vl, vm, pos, x);
	else upd(2*v+2, vm + 1, vr, pos, x);
	t[v] = t[2*v+1] + t[2*v+2];
}

void initialise(int N, int Q, int h[]) {
	// Your code here.
	for(int i = 1; i <= N; i ++) {
		H.push_back(h[i]);
	}
	n = N;
	while(ppow < n) ppow <<= 1;
	t.resize(2*ppow-1);
	build(0, 0, ppow - 1, H);
}
void cut(int l, int r, int k) {
	// Your code here.
	vector <pair <int, int>> clonh;
	for(int i = 0; i < H.size(); i ++) {
		clonh.push_back({H[i], i});
	}
	sort(clonh.begin(), clonh.end());
	while(true){
		int mx = -1e9, pos = -1;
		if(k == 0) break;
		int add = 0;
		for(int i = 0; i < n; i ++) {
			if(clonh[i].first > mx) {
				mx = clonh[i].first;
				pos = i;
			}
		}
		if(pos == 0) {
			int mn = min(k, clonh[pos].first);
			add(0, 0, ppow - 1, pos, mn);
			k -= min(k, clonh[pos].first);
			H[clonh[pos].second] -= min(k, clonh[pos].first);
			
		}else{
			add(0, 0, ppow - 1, pos, min(k, clonh[pos].first - clonh[pos-1].first));
			k -= min(k, clonh[pos].first - clonh[pos-1].first);	
			H[clonh[pos].second] -= min(k, clonh[pos].first - clonh[pos-1].first);
		}
	}
	
}
void magic(int i, int x) {
	upd(0, 0, ppow - 1, i-1, x);
	H[i-1] = x;
	// Your code here.
}
long long inspect(int l, int r) {
	// Your code here.
	l --;
	r --;
	//cout << l << ' ' << r << "\n";
	return get(0, 0, ppow- 1, l, r) + 0ll;
}
