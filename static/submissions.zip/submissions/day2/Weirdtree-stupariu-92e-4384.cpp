/**
* user:  stupariu-92e
* fname: Teodor-Mihai
* lname: Stupariu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 07:47:41.478401
*/
#include "weirdtree.h"
int n,m,v[300005]
void initialise(int N, int Q, int h[])
{
    n=N;
    m=Q;
    for(int i=1; i<=N; i++)
        v[i]=h[i];
}
void cut(int l, int r, int k)
{
    int maxx=0,re;
    for(int i=l; i<=r; i++)
    {
        if(maxx<v[i])
        {
            re=i;
            maxx=v[i];
        }
    }
    if(maxx!=0)
        v[re]--;
}
void magic(int i, int x)
{
    v[i]=x;
}
long long int inspect(int l, int r)
{
    int sum=0;
    for(int i=l;i<=r;i++)
    {
        sum+=v[i];
    }
    return sum;
}
