/**
* user:  andreescu-216
* fname: Mihnea
* lname: Andreescu
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:59:36.024825
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

using namespace std;

typedef long long ll;

const int N = 300000 + 7;
const int B = 60;
int n, q, a[N], mn[N], first[N], last[N], bucket[N];
vector<int> so[N];
vector<ll> pre[N];

void unwrap(int bucketid) {
  so[bucketid].clear();
  for (int j = first[bucketid]; j <= last[bucketid]; j++) {
    a[j] = min(a[j], mn[bucketid]);
    so[bucketid].push_back(a[j]);
  }
  mn[bucketid] = (int) 1e9 + 7;
  sort(so[bucketid].begin(), so[bucketid].end());
  pre[bucketid].clear();
  ll cur = 0;
  for (auto &x : so[bucketid]) {
    cur += x;
    pre[bucketid].push_back(cur);
  }
}

void initialise(int nn, int qq, int hh[]) {
	// Your code here.
	n = nn;
	q = qq;
	for (int i = 1; i <= n; i++) {
    a[i] = hh[i];
    bucket[i] = (i - 1) / B + 1;
    last[bucket[i]] = i;
	}
	for (int i = n; i >= 1; i--) {
    first[bucket[i]] = i;
    mn[i] = (int) 1e9 + 77;
	}
	for (int j = bucket[1]; j <= bucket[n]; j++) {
    unwrap(j);
	}
}


ll sumsmaller(int l, int r, int value) {
  ll sol = 0;
  if (bucket[l] == bucket[r]) {
    unwrap(bucket[l]);
    for (int i = l; i <= r; i++) {
      sol += min(value, a[i]);
    }
    return sol;
  } else {
    unwrap(bucket[l]);
    unwrap(bucket[r]);

    for (int i = l; i <= last[bucket[l]]; i++) {
      sol += min(value, a[i]);
    }
    for (int i = first[bucket[r]]; i <= r; i++) {
      sol += min(value, a[i]);
    }
    for (int b = bucket[l] + 1; b < bucket[r]; b++) {
      int lim = min(mn[b], value);
      int low = 0, high = (int) so[b].size() - 1, last = -1;
      while (low <= high) {
        int mid = (low + high) / 2;
        if (so[b][mid] <= lim) {
          last = mid;
          low = mid + 1;
        } else {
          high = mid - 1;
        }
      }
      if (last != -1) {
        sol += pre[b][last];
      }
      sol += (ll) ((int) so[b].size() - last - 1) * lim;
    }
  }
  return sol;
}

void minimize(int l, int r, int value) {
  if (bucket[l] == bucket[r]) {
    for (int j = l; j <= r; j++) {
      a[j] = min(a[j], value);
    }
    unwrap(bucket[l]);
  } else {
    for (int j = l; j <= last[bucket[l]]; j++) {
      a[j] = min(a[j], value);
    }
    for (int j = first[bucket[r]]; j <= r; j++) {
      a[j] = min(a[j], value);
    }
    unwrap(bucket[l]);
    unwrap(bucket[r]);
    for (int bucketid = bucket[l] + 1; bucketid < bucket[r]; bucketid++) {
      mn[bucketid] = min(mn[bucketid], value);
    }
  }
}

void cut(int l, int r, int k) {
  ll sum = sumsmaller(l, r, (int) 1e9);
  int low = 0, high = (int) 1e9 + 7, x = -1;
  while (low <= high) {
    int mid = (low + high) / 2;
    ll s = sumsmaller(l, r, mid);
    ll taiat = sum - s;
    if (taiat > k) {
      x = mid;
      low = mid + 1;
    } else {
      high = mid - 1;
    }
  }
  if (x == -1) {
    minimize(l, r, 0);
    return;
  }
  ll s = sumsmaller(l, r, x);
  ll taiat = sum - s;
  ll taiat2 = sum - sumsmaller(l, r, x + 1);
  minimize(l, r, x + 1);
  int need = k - taiat2;
  if (k - taiat2 > 0) {
    int low = l, high = r, last = -1;
    while (low <= high) {
      int mid = (low + high) / 2;
      if (sumsmaller(l, mid, x + 1) - sumsmaller(l, mid, x) <= k - taiat2) {
        last = mid;
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }
    assert(last != -1);
    minimize(l, last, x);
  }
  return;

}

void magic(int i, int x) {
	// Your code here.
	unwrap(bucket[i]);
	a[i] = x;
	unwrap(bucket[i]);
}

long long int inspect(int l, int r) {
	// Your code here.
	return sumsmaller(l, r, (int) 1e9);
}
