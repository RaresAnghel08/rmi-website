/**
* user:  bekkoyonov-7fa
* fname: Tengiz
* lname: Bekkoyonov
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 10:22:11.006543
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
#ifndef EVAL
#include "grader.cpp"
#endif
using namespace std;
using i64 = long long;
// struct node {
    // i64 sum;
    // bool zero;
    // node() : sum(0), zero(0) {}
// };
// const int MAXNODE = 12e6;
// struct segtree {
    // node t[MAXNODE];
    
// };

const int N = 1005;
int a[N], n;

void initialise(int N, int Q, int h[]) {
	n = N;
    for (int i = 0; i < n; i++) {
        a[i] = h[i + 1];
    }
}
void cut(int l, int r, int k) {
    l--;
    r--;
    for (int j = 0; j < k; j++) {
        pair<int, int> mx{-1, -1};
        for (int i = l; i <= r; i++) {
            mx = max(mx, pair<int, int>{a[i], -i});
        }
        if (mx.first != -1 && a[-mx.second] != 0) {
            a[-mx.second]--;
        }
    }
}
void magic(int i, int x) {
	i--;
    a[i] = x;
}
long long int inspect(int l, int r) {
	l--;
    r--;
    i64 sum = 0;
    for (int i = l; i <= r; i++) {
        sum += a[i];
    }
	return sum;
}
