/**
* user:  zabauski-46a
* fname: Daniil
* lname: Zabauski
* task:  NoM
* score: 100.0
* date:  2021-12-17 09:08:21.768490
*/
#include<bits/stdc++.h>
#define fi first
#define se second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define pb push_back
#define sz(x) (int)(x).size()
using namespace std;
typedef long long ll;
typedef long double ld;
//#define int long long

typedef pair < int , int > pii;

const int N = (int)2001;
int dp[2][N];
int cnk[2*N][2*N];

const int mod = (int)1e9 + 7;

void md(int &a){
    if(a >= mod)
    a-=mod;
    if(a < 0)
    a+=mod;
}
int fact[N];


int cnt[N];

vector < int > now;
void rek(int i, int n, int m, int &ans){
    if(i == 2 * n){
        vector < vector < int >> pos(n + 1);
        for(int i = 0 ;i < 2 * n; ++i)
            pos[now[i]].pb(i);
        bool bad = 0;
        for(int i = 1; i <= n; ++i){
            if((pos[i][1]-pos[i][0])%m==0)
                bad = 1;
        }
        if(!bad){
            ans++;
        }
        return;
    }
    for(int v = 1; v <= n; ++v){
        if(cnt[v] < 2){
            now.pb(v);
            cnt[v]++;
            rek(i + 1 , n , m, ans);
            now.pop_back();
            cnt[v]--;
        }
    }
}
int brute(int n , int m){
    int answer = 0;
    fill(cnt , cnt + N , 0);
    rek(0 , n , m , answer);
    return answer;
}
int DP(int n , int m){
    fill(dp[0], dp[0] + N , 0);
    fill(dp[1], dp[1] + N , 0);
    vector < int > cnt(m);
    for(int i = 1; i <= 2 * n; ++i){
        cnt[i % m]++;
    }

    dp[0][0] = 1;

    int alr = 0;
    int bt = 0;

    for(int i = 0; i < m; ++i){
        bt ^= 1;
        fill(dp[bt] , dp[bt] + N , 0);

        for(int j = 0; j <= alr / 2; ++j){

            int one = alr - 2 * j;
            int two = j;
            int zero = n - (one + two);

            if(one + two > n)
                continue;
//            assert(zero >= 0);
            for(int t = 0; t <= min(zero,cnt[i]); ++t){
                ///
                if(cnt[i]-t<=one){
                    int now = 1ll * cnk[zero][t] * cnk[one][cnt[i]-t] % mod;
                    dp[bt][j + cnt[i]-t] += ((1ll * dp[bt^1][j] * now % mod) * fact[cnt[i]] % mod) % mod;
                    md(dp[bt][j+cnt[i]-t]);
                }
            }
        }
        alr += cnt[i];
    }
    return dp[bt][n];


}
signed main(){
ios_base::sync_with_stdio(0) , cin.tie(0) , cout.tie(0);
    for(int i = 0 ; i < 2*N; ++i){
        cnk[i][0] = 1;
        for(int j = 1 ; j <= i; ++j){
            cnk[i][j] = cnk[i - 1][j - 1] + cnk[i - 1][j];
            md(cnk[i][j]);
        }
    }


    fact[0] = 1;
    for(int i = 1; i < N; ++i){
        fact[i] = (1ll * fact[i - 1] * i) % mod;
    }



    int n;cin >> n;
    int pw2 = 1;
    for(int i = 0; i < n; ++i)
    pw2 = (1ll * 2 * pw2) % mod;

    int m;
    cin >> m;
    int ans = DP(n , m);

    ans = (1ll * ans * pw2) % mod;
    cout << ans;
//
//    int N , M;
//    cin >> N >> M;



//    cout <<brute(N , M)<< endl;


    return 0;
    for(int n = 1; n <= 5; ++n){
        for(int m = 1; m <= 5; ++m){
            cout << n << ' ' << m << endl;
            int B = brute(n , m);
            int Dp = DP(n , m);
            if(B != Dp){
                cout << "WA\n";
                cout << B << ' ' << Dp<< endl;
                cout << n << ' ' << m << endl;
                return 0;
            }else{
                cout << "OK\n";
            }
        }
    }
    cout << "DONE \n";
    return 0;
}
