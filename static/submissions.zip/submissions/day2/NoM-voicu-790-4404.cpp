/**
* user:  voicu-790
* fname: Tudor
* lname: Voicu
* task:  NoM
* score: 9.0
* date:  2021-12-17 07:49:35.024454
*/
#include <iostream>

using namespace std;
const int N = 6;
const int mod = 1e9 + 7;
int f[N + 1];
int n, m;
int first[N + 1];
int st[2 * N + 1];
int cate;
void bkt ( int lvl ) {
    if ( lvl == 2 * n + 1 ) {
        cate++;
        if ( cate >= mod )
            cate = 0;
        return;
    }
    for ( int i = 1; i <= n; i++ ) {
        if ( f[i] == 2 ) {
            st[lvl] = i;
            f[i]--;
            first[i] = lvl;
            bkt ( lvl + 1 );
            f[i]++;
        } else if ( f[i] == 1 && ( lvl - first[i] ) % m != 0 ) {
            st[lvl] = i;
            f[i]--;
            bkt ( lvl + 1 );
            f[i]++;
        }
    }
}
int a[N][N] = {
{ 0, 0, 0, 0, 0, 0 },
{ 0, 4, 0, 0, 0, 0 },
{ 0, 36, 48, 0, 0, 0 },
{ 0, 576, 864, 1440, 0, 0 },
{ 0, 14400, 25920, 44640, 65280, 0 },
{ 0, 518400, 1244160, 2410560, 3196800, 4348800 }
};
int lgput ( int a, int b ) {
    int p = 1;
    while ( b ) {
        if ( b % 2 )
            p = ( long long ) p * a % mod;
        a = ( long long ) a * a % mod;
        b /= 2;
    }
    return p;
}
int main() {
    /*
    for ( n = 1; n <= N; n++ )
        for ( m = 1; m <= n; m++ ) {
          //  cout << n << ' ' << m << " :  ";
            for ( int i = 1; i <= n; i++ )
                f[i] = 2, first[i] = 0;
            bkt ( 1 );
        //    cout << cate;
            a[n][m] = cate;
            cate = 0;
      //      cout << '\n';
        }
        */
    cin >> n >> m;
    if ( n <= 6 )
        cout << ( long long ) a[n - 1][m - 1] * lgput ( 2, n );
    else {
        if ( m <= 2 ) {
            int rez = m - 1;
            for ( int i = 1; i <= n; i++ )
                rez = ( long long ) rez * i % mod * i % mod;
            cout << rez;
        }
    }
    return 0;
}
