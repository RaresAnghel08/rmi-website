/**
* user:  bem-c1d
* fname: Andrei
* lname: Bem
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:58:15.580249
*/
#include <bits/stdc++.h>

using namespace std;
int dim;
int aint[1000003];;
void update(int a){
    aint[a]=aint[2*a]+aint[2*a+1];
    if(a!=1){
        update(a/2);
    }
    return;
}
int querry(int a, int b, int st, int dr, int poz){
    if(a==st && b==dr){
        return aint[poz];
    }
    if(b<=(st+dr-1)/2){
        return querry(a, b, st, (st+dr-1)/2, poz*2);
    }
    if(a>(st+dr-1)/2){
        return querry(a, b, (st+dr-1)/2+1, dr, poz*2+1);
    }
    return querry(a, (st+dr-1)/2, st, (st+dr-1)/2, poz*2)+querry((st+dr-1)/2+1, b, (st+dr-1)/2+1, dr, poz*2+1);
}
void initialise(int n, int q, int h[]){
    dim=1;
    while(dim<n){
        dim*=2;
    }
    for(int i=dim;i<dim+n;i++){
        aint[i]=h[i-dim+1];
        update(i/2);
    }
}
void cut(int l, int r, int k){
    while(k--){
        int maxim=0, pos=dim+l;
        for(int i=dim+l-1;i<=dim+r-1;i++){
            if(aint[i]>maxim){
                maxim=aint[i];
                pos=i;
            }
        }
        if(maxim==0){
            break;
        }
        aint[pos]--;
        update(pos/2);
    }
}
void magic(int i, int x){
    aint[dim+i-1]=x;
    update((dim+i-1)/2);
}
long long int inspect(int l, int r){
    return querry(l, r, 1, dim, 1);
}
int main() {
    int N, Q;
    cin >> N >> Q;
    int h[N + 1];
    for (int i = 1; i <= N; ++i) cin >> h[i];
    initialise(N, Q, h);
    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;
        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}
