/**
* user:  bartoli-386
* fname: Davide
* lname: Bartoli
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:15:07.905974
*/
#pragma GCC optimize("O3")
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define pb push_back
#define int ll
const int mod=1e9+7;
int N,M;
vector<int> dim;
vector<int> fact;
int pot(int a,int b) {
    if(b==0)
        return 1;
    int x=pot(a,b/2);
    if(b%2)
        return x*x%mod*a%mod;
    return x*x%mod;
}
int binom(int a,int b) {
    return fact[b]*pot(fact[a],mod-2)%mod*pot(fact[b-a],mod-2)%mod;
}
bool vis[110][110][110];
int memo[110][110][110];
int solve(int coppie,int s,int pos) {
    //cout<<coppie<<" "<<s<<" "<<pos<<" "<<endl;
    if(pos==M-1 && coppie>0)
        return 0;
    if(pos==M-1)
        return 1;
    if(vis[coppie][s][pos])return memo[coppie][s][pos];
    vis[coppie][s][pos]=1;
    int ans=0;
    for(int i=0; i<=coppie; i++) {
        if(i>dim[pos])
            break;
        if(dim[pos]-i>s)
            continue;
        //cout<<"i:"<<i<<" "<<dim[pos]<<endl;
        ans+=solve(coppie-i,s+i-(dim[pos]-i),pos+1)*binom(i,dim[pos])%mod*binom(dim[pos]-i,s)%mod;
    }
    //cout<<coppie<<" "<<s<<" "<<pos<<" "<<ans<<endl;
    return memo[coppie][s][pos]=ans%mod;

}
signed main() {
    //ios_base::sync_with_stdio(0);
    //cin.tie(0);
    fact.pb(1);
    for(int i=1; i<3000; i++)
        fact.pb(fact[i-1]*i%mod);
    cin>>N>>M;
    for(int i=0; i<M; i++) {
        dim.pb((2*N-i-1)/M+1);
        //cout<<dim[i]<<" ";
    }
    //cout<<endl;
    cout<<solve(N,0,0)*fact[N]%mod*pot(2,N)%mod<<'\n';
}

