/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  NoM
* score: 9.0
* date:  2021-12-17 11:58:02.674890
*/
#include <algorithm>
#include <iostream>
#include <string>
#define endl '\n'
using namespace std;

const int MAXN = 2000;

int p[MAXN + 5];

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n, m;
    cin >> n >> m;

    string s = "";
    for (int i = 0; i < 2 * n; ++ i)
    {
        s += char(i + '0');
    }

    int cnt = 0;
    do
    {
        bool flag = true;
        for (int i = 0; i < n; ++ i)
        {
            p[i] = -1;
        }
        for (int i = 0; i < 2 * n; ++ i)
        {
            int x = (s[i] - '0') % n;
            if (p[x] != -1)
            {
                if ((i - p[x]) % m == 0)
                {
                    flag = false;
                    break;
                }
            }
            p[x] = i;
        }
        if (flag) cnt++;
    } while (next_permutation(s.begin(), s.end()));

    cout << cnt << endl;

    return 0;
}
