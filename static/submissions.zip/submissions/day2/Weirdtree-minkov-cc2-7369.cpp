/**
* user:  minkov-cc2
* fname: Stefan Atanasov
* lname: Minkov
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 11:52:57.212082
*/
#include "weirdtree.h"
#include<iostream>
using namespace std;

int N,Q;
int space;
struct Tree
{
    long long int val;
    int l,r;
};
Tree t [1048576];
Tree nt;

int findClosest(int n)
{
    int s=1;
    while(s<n)
    {
        s*=2;
    }
    return s;
}
void Add(int x,long long v)
{
    x+=space-1;
    long long int nu=0;
    while(x>0)
    {
        t[x].val = max(nu, t[x].val+v);
        x/=2;
    }
}
void initTree(int x)
{
    if (x>=space) return;
    initTree(x*2);
    initTree(x*2+1);
    t[x].l=t[x*2].l;
    t[x].r=t[x*2+1].r;
    t[x].val=t[x*2].val+t[x*2+1].val;
}
Tree maxTreeComp(Tree x,Tree y)
{
    if(x.val>=y.val) return x;
    return y;
}
Tree maxTree(int x, int lsi, int rsi)
{
    //cout<<x<<" I: "<<t[x].l<<" "<<t[x].r<<" S: "<<lsi<<" "<<rsi;
    if(lsi>t[x].r || t[x].l>rsi) {/*cout<<" NO"<<endl;*/return nt;}//cout<<endl;
    if(t[x].l == t[x].r) return t[x];
    return maxTreeComp(maxTree(x*2, lsi , min(t[x*2].r,rsi)),maxTree(x*2+1, max(t[x*2+1].l,lsi), rsi));


}
long long int sumTree(int x, int lsi, int rsi)
{
    if(lsi>t[x].r || t[x].l>rsi) return 0;
    if(lsi == t[x].l && rsi == t[x].r) return t[x].val;
    return sumTree(x*2, lsi , min(t[x*2].r,rsi))+sumTree(x*2+1, max(t[x*2+1].l,lsi), rsi);
}
void initialise(int N, int Q, int h[]) {
    ios_base::sync_with_stdio(false);
	space=findClosest(N);
	int c;
	for(int i=0;i<N;i++)
    {
        c=i+space;
        t[c].l=i+1;
        t[c].r=i+1;
        t[c].val=h[i+1];
    }
    for(int i=N;i<space;i++)
    {
        c=i+space;
        t[c].l=i+1;
        t[c].r=i+1;
    }
    initTree(1);
    /*for(int i=1;i<2*space;i++)
    {
        cout<<i<<". "<<t[i].l<<" "<<t[i].r<<" "<<t[i].val<<endl;
    }*/
    nt.val=-1;
}
/*void print()
{
    for(int i=1;i<2*space;i++)
    {
        cout<<"("<<i<<","<<t[i].val<<");";
    }
    cout<<endl;
}*/
void cut(int l, int r, int k) {
	Tree c;
	long long v=-1;
	for(int i=0;i<k;i++)
    {
        c=maxTree(1, l, r);
        if(c.val==0) break;
        Add(c.l, v);
    }
   // print();
}
void magic(int i, int x) {
	long long v=x-t[i+space-1].val;
	Add(i,v);
	//print();
}
long long int inspect(int l, int r) {
	return sumTree(1, l, r);
}
