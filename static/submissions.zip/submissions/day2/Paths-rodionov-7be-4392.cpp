/**
* user:  rodionov-7be
* fname: Valerii
* lname: Rodionov
* task:  Paths
* score: 56.0
* date:  2021-12-17 07:48:24.676144
*/
#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int N = 2005;

int n, k;
vector<pair<int, ll>> e[N];
vector<ll> v;

ll dfs(int v, int p = -1) {
	vector<ll> vv;
	for (auto& [u, w] : e[v]) {
		if (u != p) {
			vv.push_back(dfs(u, v) + w);
		}
	}
	if (vv.empty()) {
		vv.push_back(0);
	}
	swap(vv[0], vv[max_element(vv.begin(), vv.end()) - vv.begin()]);
	for (int i = 1; i < (int)vv.size(); ++i) {
		::v.push_back(vv[i]);
	}
	return vv[0];
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin >> n >> k;
	for (int i = 0; i < n - 1; ++i) {
		int x, y;
		ll c;
		cin >> x >> y >> c;
		--x;
		--y;
		e[x].emplace_back(y, c);
		e[y].emplace_back(x, c);
	}
	for (int root = 0; root < n; ++root) {
		v.clear();
		v.push_back(dfs(root));
		sort(v.rbegin(), v.rend());
		ll sum = 0;
		for (int i = 0; i < k; ++i) {
			sum += v[i];
		}
		cout << sum << "\n";
	}
	return 0;
}
