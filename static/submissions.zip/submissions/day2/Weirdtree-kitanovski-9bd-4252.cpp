/**
* user:  kitanovski-9bd
* fname: Teo 
* lname: Kitanovski
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 07:26:00.678038
*/
#include <bits/stdc++.h>
#ifndef LOCAL_DEBUG
    #include "weirdtree.h"
#endif // LOCAL_DEBUG

typedef long long ll;

#define MS(x,y) memset((x), (y), sizeof((x)))
#define pb push_back
#define MN 1000000007

using namespace std;

int n,q,niza[300001];

void initialise(int n2, int q2, int niza2[]) {
    n=n2;q=q2;
    for (int i = 0; i<n; i++) niza[i] = niza2[i];

}

void cut(int l,int r, int k) {
    l--; r--;

    int maxi = -1, maxiI = -1;

    for (int i = l; i<=r; i++) {
        if (niza[i] > maxi) {
            maxi = niza[i];
            maxiI = i;
        }
    }

    niza[maxiI] = max(niza[maxiI]-1,0);
}

void magic(int i, int x) {
    i--;

    niza[i] = x;
}

ll inspect (int l, int r) {
    l--; r--;

    ll res = 0;
    for (int i = 1; i<=r; i++) res += niza[i];

    return res;
}

#ifdef LOCAL_DEBUG
int main() {
    #ifdef LOCAL_DEBUG
        fstream cin("in.txt");
    #endif // LOCAL_DEBUG

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int n,q;
    cin>>n>>q;

    int niza[n];
    for (int i = 0; i<n; i++) cin>>niza[i];

    initialize(n,q,niza);

    for (int i = 0; i<q; i++) {
        int t;
        cin>>t;

        if (t == 1) {
            int a,b,c;
            cin>>a>>b>>c;
            cut(a,b,c);
        } else if (t == 2) {
            int a,b;
            cin>>a>>b;
            magic(a,b);
        } else if (t == 3) {
            int a,b;
            cin>>a>>b;
            cout<<inspect(a,b)<<endl;
        }
    }
}
#endif
