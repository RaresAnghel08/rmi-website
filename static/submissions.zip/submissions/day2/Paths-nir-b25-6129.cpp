/**
* user:  nir-b25
* fname: Itamar
* lname: Nir
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:27:59.978133
*/
using namespace std;

#include <iostream>
#include <vector>
#include <algorithm>
vector<long long> dp_up;
vector<pair<int,int>> padre;
vector<vector<pair<int,int>>> edg;
vector<vector<pair<long long,int>>> dp;

long long max(long long a, long long b) {
    if (a < b) {
        return b;
    }return a;
}
void visit(int i) {
    for (int j = 0; j < edg[i].size(); j++) {
        if (padre[i].first != edg[i][j].first) {
            padre[edg[i][j].first].first = i;
            padre[edg[i][j].first].second = edg[i][j].second;
            visit(edg[i][j].first);
        }
    }
}
long long collect(int i, long long sum) {
    if (i == 1) {
        return sum;
    }
    return collect(padre[i].first, sum + padre[i].second);
    
}
long long calc_down(int i) {
    int it = 0;
    long long max = 0;
    for (int j = 0; j < edg[i].size(); j++) {
        if (edg[i][j].first != padre[i].first) {
            dp[i].push_back({ calc_down(edg[i][j].first) + edg[i][j].second, edg[i][j].first });
            if (max < dp[i][it].first) {
                max = dp[i][it].first;
            }
            it++;
        }
    }
    return max;
}

void calc_up(int i) {
    if (i > 1) {
        if (dp[padre[i].first][0].second == i) {
            if (dp[padre[i].first].size() > 1) {
                dp_up[i] = max(dp[padre[i].first][1].first, dp_up[padre[i].first]);
            }
            else {
                dp_up[i] = dp_up[padre[i].first];
            }
        }
        else {
            dp_up[i] = max(dp[padre[i].first][0].first, dp_up[padre[i].first]);
        }
    }
    dp_up[i] += padre[i].second;
    for (int j = 0; j < edg[i].size(); j++) {
        if (edg[i][j].first != padre[i].first) {
            calc_up(edg[i][j].first);
        }
    }
}

int main() {

    
        int n, k;
        cin >> n >> k;
        for (int i = 0; i < n - 1; i++) {
            int x, y, c;
            cin >> x >> y >> c;
            edg[x].push_back({ y,c });
            edg[y].push_back({ x,c });
        }
        for (int i = 0; i < n; i++) {
        dp.resize(n + 1);
        dp_up.resize(n + 1);
        vector<int> vec(n);
        padre.resize(n + 1);
        padre[1].first = 1;
        edg.resize(n + 1);

        visit(1);
        calc_down(1);

        for (int i = 1; i <= n; i++) {
            sort(dp[i].begin(), dp[i].end());
            reverse(dp[i].begin(), dp[i].end());
        }
        calc_up(1);
        for (int i = 1; i <= n; i++) {
            if (dp[i].size() > 0) {
                cout << max(dp_up[i], dp[i][0].first) << endl;
            }
            else {
                cout << dp_up[i] << endl;
            }
        }
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
