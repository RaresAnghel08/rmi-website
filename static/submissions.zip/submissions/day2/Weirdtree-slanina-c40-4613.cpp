/**
* user:  slanina-c40
* fname: Iulia
* lname: Slanina
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:15:01.108311
*/
#include <bits/stdc++.h>

using namespace std;
#define ll long long
const int NMAX = 300005;
int n;
ll v[NMAX];
struct jon{
    ll lftmax, sum, valmax;
} seg[4 * NMAX];
struct jul{
    ll val, sp; int poz;
} p[NMAX];
int indici[NMAX];
bool cmp(jul a, jul b)
{
    if (a.val != b.val)
        return a.val > b.val;
    return a.poz < b.poz;
}
void combine(int nod, int ls, int rs)
{
    seg[nod] = seg[ls];
    seg[nod].sum += seg[rs].sum;
    if (seg[ls].valmax < seg[rs].valmax)
    {
        seg[nod].lftmax = seg[rs].lftmax;
        seg[nod].valmax = seg[rs].valmax;
    }
}
void build(int nod, int l, int r, int h[])
{
    if (l == r)
    {
        seg[nod].lftmax = l;
        seg[nod].sum = h[l];
        seg[nod].valmax = h[l];
        return;
    }
    int mid = (l + r) / 2, ls = 2 * nod, rs = ls + 1;
    build(ls, l, mid, h);
    build(rs, mid + 1, r, h);
    combine(nod, ls, rs);
}
void update(int nod, int l, int r, int poz, int val)
{
    if (l == r)
    {
        seg[nod].sum = val;
        seg[nod].valmax = val;
        return;
    }
    int mid = (l + r) / 2, ls = 2 * nod, rs = ls + 1;
    if (poz <= mid)
        update(ls, l, mid, poz, val);
    else
        update(rs, mid + 1, r, poz, val);
    combine(nod, ls, rs);
}
jon query_max(int nod, int l, int r, int ql, int qr)
{
    if (ql <= l && r <= qr)
        return seg[nod];
    int mid = (l + r) / 2, ls = 2 * nod, rs = ls + 1;
    jon ans1 = {0, 0, 0}, ans2 = {0, 0, 0};
    if (ql <= mid)
        ans1 = query_max(ls, l, mid, ql, qr);
    if (mid < qr)
        ans2 = query_max(rs, mid + 1, r, ql, qr);
    if (ans2.valmax > ans1.valmax)
        return ans2;
    else
        return ans1;
}
long long int query_sum(int nod, int l, int r, int ql, int qr)
{
    if (ql <= l && r <= qr)
        return seg[nod].sum;
    int mid = (l + r) / 2, ls = 2 * nod, rs = ls + 1;
    long long int sum = 0;
    if (ql <= mid)
        sum += query_sum(ls, l, mid, ql, qr);
    if (mid < qr)
        sum += query_sum(rs, mid + 1, r, ql, qr);
    return sum;
}
void initialise(int N, int Q, int h[])
{
    n = N;
    for (int i= 1; i <= n; i++)
        v[i] = h[i];
    ///build(1, 1, N, h);
}
void cut(int l, int r, int k)
{
    int m = 0;
    for (int i = l; i <= r; i++)
    {
        m++;
        p[m] = {v[i], 0, i};
    }
    sort(p + 1, p + m + 1, cmp);
    for (int i = 1; i <= m; i++)
        p[i].sp = p[i - 1].sp + p[i].val;
    if (k >= p[m].sp)
    {
        for (int i = l; i <= r; i++)
            v[i] = 0;
        return;
    }
    int st = 0, dr = p[1].val, soll = 0;
    while (st <= dr)
    {
        int mid = (st + dr) / 2; ///cea mai mare valoare ramasa e mid
        int stt = 1, drr = m, sol = 0;
        while (stt <= drr)
        {
            int midd = (stt + drr) / 2;
            if (p[midd].val > mid)
            {
                sol = midd;
                stt = midd + 1;
            }
            else
                drr = midd - 1;
        }
        if (sol)
        {
            ll nr = p[sol].sp - sol * mid;
            if (nr < k)
            {
                soll = mid;
                dr = mid - 1;
            }
            else
                st = mid + 1;
        }
    }
    for (int i = 1; p[i].val > soll; i++)
    {
        k -= (p[i].val - soll);
        p[i].val = soll;
        v[p[i].poz] = soll;
    }
    int h = 1;
    while (p[h].val == soll)
    {
        indici[h] = p[h].poz;
        h++;
    }
    h--;
    sort(indici + 1, indici + h + 1);
    for (int h = 1; h <= k; h++)
        v[indici[h]]--;
 ///   jon iulia = query_max(1, 1, n, l, r);
   /// update(1, 1, n, iulia.lftmax, iulia.valmax - 1);

}
void magic(int i, int x)
{
   /// update(1, 1, n, i, x);
}
long long int inspect(int l, int r)
{
    long long int sum = 0;
    for (int i = l; i <= r; i++)
        sum += v[i];
    return sum;
    ///return query_sum(1, 1, n, l, r);
}
///final eu
/*
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}*/
