/**
* user:  hosu-b1a
* fname: Iulia
* lname: Hosu
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:49:53.368700
*/
#include <iostream>
#include <vector>

using namespace std;

const int N = 1e5 + 3;

int n, k;
long long dp[N][102];
long long ans[N];

vector <pair <int, int> > v[N];

inline void update(int nod, int last)   {
    for (int i = 1; i <= k; ++i)
        dp[nod][i] = 0;
    for (auto it : v[nod])  {
        if (it.first == last)
            continue;
        for (int i = k; i; --i)    {
            for (int j = 0; j < i; ++j)    {
                if (dp[nod][i] < dp[nod][j] + dp[it.first][i - j] + (long long)it.second)
                    dp[nod][i] = dp[nod][j] + dp[it.first][i - j] + (long long)it.second;
            }
        }
    }
}

inline void dfs(int nod, int last)   {
    for (auto it : v[nod])  {
        if (it.first != last)   {
            dfs(it.first, nod);
        }
    }
    update(nod, last);
}

inline void change_root(int root, int ex_root) {
    update(ex_root, root);
    update(root, 0);
}

inline void dfs_roots(int nod, int last)   {
    long long aux[k + 2], aux2[k + 2];
    if (last == 0)  {
        dfs(nod, 0);
        ans[nod] = dp[nod][k];
    } else  {
        for (int i = 1; i <= k; ++i)    {
            aux[i] = dp[nod][i];
            aux2[i] = dp[last][i];
        }
        change_root(nod, last);
        ans[nod] = dp[nod][k];
    }
    for (auto it : v[nod])  {
        if (it.first == last)
            continue;
        dfs_roots(it.first, nod);
    }
    if (last != 0)  {
        for (int i = 1; i <= k; ++i)    {
            dp[nod][i] = aux[i];
            dp[last][i] = aux2[i];
        }
    }
}

int main()  {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    int x, y, c;
    for (int i = 1; i < n; ++i) {
        cin >> x >> y >> c;
        v[x].push_back({y, c});
        v[y].push_back({x, c});
    }
    int R = 1;
    for (int i = 2; i <= n; ++i)
        if (v[i].size() > v[R].size())
            R = i;
    dfs_roots(R, 0);
    for (int i = 1; i <= n; ++i)
        cout << ans[i] << '\n';
    return 0;
}
