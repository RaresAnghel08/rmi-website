/**
* user:  andreescu-216
* fname: Mihnea
* lname: Andreescu
* task:  Paths
* score: 19.0
* date:  2021-12-17 08:57:11.225316
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;


const int N = 2000 + 7;
const ll INF = (ll) 1e18;
int n, k, sub[N];
ll dp[N][N], ndp[N], topar[N];
vector<int> g[N];

void compute(int a, int p) {
  sub[a] = 1;
  for (auto &b : g[a]) {
    if (b == p) {
      continue;
    }
    sub[a] += sub[b];
  }
  int cur = 1;
  dp[a][cur] = 0;
  for (auto &b : g[a]) {
    if (b == p) {
      continue;
    }
    int newcur = min(k, cur + sub[b]);
    for (int j = 0; j <= newcur; j++) {
      ndp[j] = -INF;
    }
    for (int x = 0; x <= cur; x++) {
      for (int y = 0; x + y <= newcur && y <= min(sub[b], k); y++) {
        int z = x + y;
        ndp[z] = max(ndp[z], dp[a][x] + dp[b][y] + topar[b] * (y >= 1));
      }
    }
    for (int j = 0; j <= newcur; j++) {
      dp[a][j] = ndp[j];
    }
    cur = newcur;
  }
}

void dfs(int a, int p = -1) {
  for (auto &b : g[a]) {
    if (b == p) {
      continue;
    }
    dfs(b, a);
  }
  compute(a, p);
}

vector<pair<int, int>> g2[N];

void build(int a, int p = -1) {
  for (auto &it : g2[a]) {
    int b = it.first, c = it.second;
    if (b == p) {
      continue;
    }
    g[a].push_back(b);
    topar[b] = c;
    build(b, a);
  }
}

signed main()  {
  ios::sync_with_stdio(0); cin.tie(0);

  cin >> n >> k;
  for (int i = 1; i < n; i++) {
    int x, y, z;
    cin >> x >> y >> z;
    g2[x].push_back({y, z});
    g2[y].push_back({x, z});
  }
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= n; j++) {
      g[j].clear();
    }
    build(i);
    dfs(i);
    cout << dp[i][k] << "\n";
  }

}
