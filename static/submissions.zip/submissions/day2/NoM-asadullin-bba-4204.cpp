/**
* user:  asadullin-bba
* fname: Aidar Ildarovich
* lname: Asadullin
* task:  NoM
* score: 0.0
* date:  2021-12-17 07:13:54.703323
*/
#include <bits/stdc++.h>

using namespace std;
#define int long long
int ans = 0;
int n, m;

void check(vector<int> &a) {
    vector<int> el[n];
    for (int i = 0; i < a.size(); ++i) {
        el[a[i]].push_back(i);
    }
    for (int j = 0; j < n; ++j) {
        if ((el[j][1] - el[j][0]) % m == 0) {
            return;
        }
    }
    ans++;
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
    cout.tie();
#ifdef foo
    freopen("input.txt", "r", stdin);
#endif
    cin >> n >> m;
    vector<int> a(n * 2);
    for (int i = 0; i < n * 2; ++i) {
        a[i] = i / 2;
    }
    check(a);
    while (next_permutation(a.begin(), a.end())) {
        check(a);
    }
    cout << ans * 2;
}