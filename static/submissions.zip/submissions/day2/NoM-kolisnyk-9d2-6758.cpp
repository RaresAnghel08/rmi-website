/**
* user:  kolisnyk-9d2
* fname: Illia
* lname: Kolisnyk
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:14:36.743214
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
#define int long long
#define pb push_back
#define ft first
#define sc second

using namespace std;

const int N = 1e5 + 55;

int is[N];

main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n, m;
    cin >> n >> m;
    vector <int> vec;
    for (int i = 1; i <= 2 * n; i ++) {
        vec.pb(i);
    }
    int ans = 0;
    do {
            vector <int> vec1;
        bool ok = true;
        for (int i = 0; i < vec.size(); i ++) {
            if (vec[i] <= n) {
                if (is[vec[i] + n] && (i + 1 - is[vec[i] + n]) % m == 0) {
                    ok = false;
                    break;
                }
            }
            else {
                if (is[vec[i] - n] && (i + 1 - is[vec[i] - n]) % m == 0) {
                    ok = false;
                    break;
                }
            }
            vec1.pb(vec[i]);
            is[vec[i]] = i + 1;
        }
        for (auto it : vec1) is[it] = 0;
        if (ok) ans ++;
    } while (next_permutation(vec.begin(), vec.end()));
    cout << ans;
}

/*
8 1
1 2 4
1 3 8
2 4 3
2 5 10
3 8 9
5 6 1
5 7 2
*/
