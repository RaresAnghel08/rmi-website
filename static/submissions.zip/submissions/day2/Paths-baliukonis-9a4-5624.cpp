/**
* user:  baliukonis-9a4
* fname: Tsimafei
* lname: Baliukonis
* task:  Paths
* score: 68.0
* date:  2021-12-17 09:46:51.500396
*/

#include<bits/stdc++.h>
#include<ext/pb_ds/tree_policy.hpp>
#include<ext/pb_ds/assoc_container.hpp>

#define ll long long
#define int long long

#define f first
#define s second
#define pb push_back

using namespace std;


const ll MOD = 1e9 + 7;
ll n, k;

vector<ll> merg(vector<ll> &a, vector<ll> &b) {
vector<ll> c(a.size() + b.size(), -1e18);
for(int j = 0; j < a.size(); j++)
for(int e = 0; e < b.size(); e++) {
if(j + e > k) break;
c[j + e] = max(c[j + e], a[j] + b[e]);
}

while(c.back() == -1e18 || c.size() > k + 1) c.pop_back();
return c;
}

vector<pair<ll,ll>> v[200007];

ll ans[200007];
vector<ll> ma[200007];

vector<ll> dfs2(ll v1, ll pr) {
 ma[v1] = {0};
 bool f1 = 0;
 for(auto to: v[v1]) {
    if(to.f == pr) continue;
    f1 = 1;
    vector<ll> e = dfs2(to.f, v1);
    for(int c = 1; c < e.size(); c++) e[c] += to.s;
    ma[v1] = merg(ma[v1], e);
 }
 if(!f1) ma[v1].pb({0});
 return ma[v1];
}

void dfs3(ll v1, ll pr, vector<ll> mav) {
vector<vector<ll>> vl, vr;

vector<ll> x = mav;
vl.pb({x});

for(int j = 0; j < v[v1].size(); j++) {
    if(v[v1][j].f == pr) {
        swap(v[v1][j], v[v1].back()); v[v1].pop_back(); break;
    }
}
 for(auto to: v[v1]) {
    vector<ll> e = ma[to.f];
    for(int c = 1; c < e.size(); c++) e[c] += to.s;
    x = merg(x, e);
    vl.pb(x);
 }
  ans[v1] = x.back();

  x = {0};
  vr.pb(x);
 reverse(v[v1].begin(), v[v1].end());
 for(auto to: v[v1]) {
    vector<ll> e = ma[to.f];
    for(int c = 1; c < e.size(); c++) e[c] += to.s;
    x = merg(x, e);
    vr.pb(x);
 }
  reverse(v[v1].begin(), v[v1].end());

 ll i = 0, j = vr.size() - 2;
 for(auto to: v[v1]) {
    vector<ll> e2 = merg(vl[i], vr[j]);
    for(int j = 1; j < e2.size(); j++) {
        e2[j] += to.s;
    }
    dfs3(to.f, v1, e2);
    i++; j--;
 }
 return;
}
int32_t main() {

    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif // LOCAL

    cin >> n >> k;
    k = min(k, n);
    for(int j = 1; j < n; j++) {
        ll x, y, cost;
        cin >> x >> y >> cost;
        x--; y--;
        v[x].pb({y, cost});
        v[y].pb({x, cost});
    }
        dfs2(0, 0);
        dfs3(0, 0, {0, 0});
        for(int j = 0; j < n; j++) {
          cout << ans[j] << '\n';
        }
        return 0;

}
