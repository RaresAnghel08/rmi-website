/**
* user:  temirbekov-60c
* fname: Maksat
* lname: Temirbekov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:22:05.015414
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

int t[(int)1e6];
int n;
vector <int> H;
void build(int v, int vl, int vr, const vector <int> & a) {
	if(vl == vr) t[v] = a[vl];
	else {
		int vm = (vl + vr) >> 1;
		build(2*v+1, vl, vm, a);
		build(2*v+2, vm+1, vr, a);
		t[v] = t[2*v+1] + t[2*v+2];
	}
}

int get(int v, int vl, int vr, const int l, const int r) {
	if(vr < l or vl > r) return 0;
	else if(l <= vl and vr <= r) return t[v];
	else {
		int vm = (vl + vr) / 2;
		//return 0;
		return get(2*v+1, vl, vm, l, r) + get(2*v+2, vm+1, vr, l, r);
	}
}

void upd(int v, int vl, int vr, const int pos, const int x) {
	if(vl == vr) {
		t[v] += x;
		return;
	}
	int vm = (vl + vr) / 2;
	if(pos <= vm) upd(2*v+1, vl, vm, pos, x);
	else upd(2*v+2, vm + 1, vr, pos, x);
	t[v] = t[2*v+1] + t[2*v+2];
}

void add(int v, int vl, int vr, const int pos, const int x) {
	if(vl == vr) {
		t[v] = x;
		return;
	}
	int vm = (vl + vr) / 2;
	if(pos <= vm) add(2*v+1, vl, vm, pos, x);
	else add(2*v+2, vm + 1, vr, pos, x);
	t[v] = t[2*v+1] + t[2*v+2];
}

void initialise(int N, int Q, int h[]) {
	// Your code here.
	for(int i = 1; i <= N; i ++) {
		H.push_back(h[i]);
	}
	n = N;
	build(0, 0, n - 1, H);
}
void cut(int l, int r, int k) {
	// Your code here.
	while(k--){
		int pos = -1;
		int mn = -1e9;
		for(int i = l - 1; i < r; i ++) {
			if(H[i] > mn) {
				mn = H[i];
				pos = i;
			}
		}
		if(mn == 0) break;
		H[pos] --;
			upd(0, 0, n-1, pos, -1);
	}
	
}
void magic(int i, int x) {
	upd(0, 0, n - 1, i-1, x);
	H[i-1] = x;
	// Your code here.
}
long long int inspect(int l, int r) {
	// Your code here.
	l --;
	r --;
	//cout << l << ' ' << r << "\n";
	return get(0, 0, n- 1, l, r);
}
