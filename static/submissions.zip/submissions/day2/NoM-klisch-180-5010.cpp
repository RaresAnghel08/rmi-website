/**
* user:  klisch-180
* fname: Danil
* lname: Klisch
* task:  NoM
* score: 52.0
* date:  2021-12-17 08:52:54.003805
*/
//bs:sanitizers
#include <bits/stdc++.h>
using namespace std;

template <typename T>
using normal_queue = priority_queue<T, vector<T>, greater<T>>;

#define x first
#define y second
#define all(x) begin(x), end(x)
#define sz(x) ((int) (x).size())
using ll = long long;
using ld = long double;

const int N = 910, MOD = 1e9 + 7;

ll fpow(ll a, ll b) {
	ll res = 1;
	for (int i = 1; i <= b; i *= 2) {
		if (b & i) {
			(res *= a) %= MOD;
		}
		(a *= a) %= MOD;
	}
	return res;
}

ll inv(ll a) {
	return fpow(a, MOD - 2);
}

int cnt[N];
ll fact[N], ifact[N];
ll dp[N][N];

signed main() {
	cin.tie(0)->sync_with_stdio(0);
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < 2 * n; ++i) {
		++cnt[i % m];
	}
	fact[0] = 1;
	for (int i = 1; i < N; ++i) {
		fact[i] = fact[i - 1] * i % MOD;
	}
	ifact[N - 1] = inv(fact[N - 1]);
	for (int i = N - 1; i--; ) {
		ifact[i] = ifact[i + 1] * (i + 1) % MOD;
	}
	int already = 0;
	dp[0][0] = 1;
	for (int i = 0; i < m; ++i) {
		int l = cnt[i];
		for (int j = 0; j <= n; ++j) {
			if (!dp[i][j]) {
				continue;
			}
			ll old = 2 * j - already;
			for (int nw = 0; nw <= n - j; ++nw) {
				if (nw > l || nw + old < l) {
					continue;
				}
				(dp[i + 1][j + nw] +=
					dp[i][j] * fact[l] % MOD * ifact[l - nw] % MOD *
					ifact[nw] % MOD * fact[old] % MOD * ifact[old - l + nw]) %= MOD;
			}
		}
		already += l;
	}
	ll ans = dp[m][n];
	for (int i = 1; i <= n; ++i) {
		(ans *= i * 2) %= MOD;
	}
	cout << ans;
}