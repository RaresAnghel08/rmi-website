/**
* user:  talypov-615
* fname: Emil
* lname: Talypov
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:26:37.971164
*/
#include <bits/stdc++.h>
using namespace std;

#define ll          long long
#define pii         pair<int,int>
#define v           first
#define l           second

int n, k, cur_len;
vector < vector < pii > > g;

vector < bool > used, claimed;
vector < int > cur;
vector < vector < int > > path;

inline void generate(int id, int len)
{
    if (len > cur_len)
        path.back() = cur,
        cur_len = len;

    used[id] = true;

    for (auto p : g[id])
        if (!used[p.v])
        {
            cur.push_back(p.v);

            if (!claimed[p.v]) generate(p.v, len + p.l);
            else generate(p.v, len);

            cur.pop_back();
        }
}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    int a, b, c, ans = 0;

    cin >> n >> k;

    g.resize(n); used.resize(n); claimed.resize(n);

    for (int i = 0; i < n - 1; i++)
    {
        cin >> a >> b >> c; a--, b--;

        g[a].push_back({ b, c });
        g[b].push_back({ a, c });
    }

    while (path.size() < k)
    {
        path.push_back(vector < int >()); cur_len = 0;
        cur = vector < int >({ 0 });

        generate(0, 0);

        fill(used.begin(), used.end(), false);

        for (int i = 0; i < path.back().size(); i++)
            claimed[path.back()[i]] = true;

        ans += cur_len;
    }

    cout << ans;
}
