/**
* user:  patrushava-e4f
* fname: Hanna
* lname: Patrushava
* task:  Paths
* score: 36.0
* date:  2021-12-17 11:21:28.154871
*/
#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("unroll-loops")

#include <bits/stdc++.h>

#define pii pair<int, int>
#define f first
#define s second
#define pb push_back
#define ll long long

using namespace std;

const int N = 6001;
vector < pii > g[N];
int sz[N];


void calc(int v, int pr = -1)
{
    sz[v] = 0;
    for (auto to: g[v])
    {
        if (to.f == pr) continue;
        calc(to.f, v);
        sz[v] += sz[to.f];
    }
    if ((int)g[v].size() == 1 && pr != -1) sz[v]++;
    return;
}

ll dp[N][N];
int n, k;
int mp[N][N];

int nom = 1;

void dfs(int v, int pr)
{
   if (mp[v][pr] > 0) return;
   mp[v][pr] = nom;
   nom++;
   int c = nom - 1;
   for (auto to: g[v])
   {
       int u = to.f;
       ll cost = to.s;

       if (u == pr) continue;
       dfs(u, v);

       for (int i = min(k, sz[v]); i >= 1; i--)
       for (int j = min(i, sz[u]); j >= 1; j--)
       {
           dp[c][i] = max(dp[c][i], dp[mp[u][v]][j] + cost + dp[c][i - j]);
       }
   }


   return;
}
int32_t main() {
#ifdef LOCAL
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
#endif // LOCAL


    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> n;
    cin >> k;

    for (int i = 0; i < n - 1; i++)
    {
        int x, y;
        cin >> x >> y;
        x--;
        y--;
        int c;
        cin >> c;
        g[x].pb({y, c});
        g[y].pb({x, c});
    }

    for (int i = 0; i < n; i++)
    {
        calc(i, i);

        dfs(i, i);

        ll ans = 0;
        for (int j = 1; j <= k; j++) ans = max(ans, dp[mp[i][i]][j]);
        cout << ans << "\n";
    }

    return 0;
}


