/**
* user:  patrushava-e4f
* fname: Hanna
* lname: Patrushava
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:49:23.335903
*/
#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("unroll-loops")
#include <bits/stdc++.h>
#include "weirdtree.h"


#define pii pair<int, int>
#define f first
#define s second
#define pb push_back

using namespace std;

const int N = 1e5 * 5;
long long a[N];
int n;
void initialise(int N, int Q, int h[]) {

    n = N;
    for (int i = 1; i <= n; i++)
    {
        a[i] = h[i];
    }

    return;
}

void cut(int l, int r, int kol) {

   long long sum = 0;
   for (int i = l; i <= r; i++) sum += a[i];

   if (sum <= kol)
   {
       for (int i = l; i <= r; i++) a[i] = 0;
       return;
   }

   long long l1 = 0;
   long long r1 = a[l];
   for (int i = l + 1; i <= r; i++)
   {
       l1 = min(l1, a[i]);
       r1 = max(r1, a[i]);
   }

   long long res = l1;
   while (l1 <= r1)
   {
        long long mid = (l1 + r1) >> 1;
        long long sum = 0;
        for (int i = l; i <= r; i++)
        {
            if (a[i] > mid) sum += a[i] - mid;
        }

        if (sum > kol)
        {
            l1 = mid + 1;
            continue;
        }

        for (int i = l; i <= r; i++)
        {
            if (a[i] >= mid) sum++;
        }


        if (sum >= kol)
        {
            res = mid;
            break;
        }

        r1 = mid - 1;
   }

   sum = 0;
   for (int i = l; i <= r; i++)
   {
       if (a[i] > res) {sum += a[i] - res;a[i] = res;}
   }

   for (int i = l; i <= r && sum < kol; i++)
   {
         if (a[i] == res)
         {
             a[i]--;
             sum++;
         }
   }



   return;
}
void magic(int i, int x) {

    a[i] = x;

     return;
}
long long int inspect(int l, int r) {
    long long sum = 0;
    for (int i = l; i <= r; i++) sum += a[i];
    return sum;
}
