/**
* user:  haivas-4ca
* fname: Vlad
* lname: Haivas
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:50:57.973489
*/
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
//#pragma GCC optimize("Ofast", "unroll-loops")
#include "weirdtree.h"

using namespace std;
typedef long long ll;
typedef pair <ll, ll> pii;

const ll NMAX = 300001;
const ll MOD = 1000000007;
const ll nr_of_bits = 21;
const ll BLOCK = 420;
const ll KMAX = 2001;

ll n;

class All
{
public:
    struct Node
    {
        ll first, second, maxim2, minim;
    };
    Node combine(Node a, Node b)
    {
        Node c;
        if(a.first == b.first){
            c.first = a.first;
            c.second = min(a.second, b.second);
        }else{
            if(a.first > b.first){
                c.first = a.first;
                c.second = a.second;
            }else{
                c.first = b.first;
                c.second = b.second;
                swap(b.first, a.first);
            }
        }
        c.maxim2 = max({b.first, a.maxim2, b.maxim2});
        c.minim = min({a.minim, b.minim});
        return c;
    }
    Node all[NMAX * 4];
    ll sum[NMAX * 4];
    pii maxi(pii a, pii b)
    {
        if(a.first == b.first)
        {
            if(a.second < b.second)
                return a;
            return b;
        }
        return max(a, b);
    }
    void update(ll node, ll st, ll dr, ll a, ll b)
    {
        if(st == dr)
        {
            all[node] = {b, a, 0, 0};
            sum[node] = 1LL * b;
            return;
        }
        ll mid = (st + dr) / 2;
        if(a <= mid)
            update(node * 2, st, mid, a, b);
        else
            update(node * 2 + 1, mid + 1, dr, a, b);
        all[node] = combine(all[node * 2], all[node * 2 + 1]);
        sum[node] = sum[node * 2 + 1] + sum[node * 2];
    }
    Node query(ll node, ll st, ll dr, ll a, ll b)
    {
        if(a <= st && dr <= b)
            return all[node];
        ll mid = (st + dr) / 2;
        Node maxim = {0, 0, 0, 2000000000};
        if(a <= mid)
            maxim = combine(maxim, query(node * 2, st, mid, a, b));
        if(b > mid)
            maxim = combine(maxim, query(node * 2 + 1, mid + 1, dr, a, b));
        return maxim;
    }
    ll suma(ll node, ll st, ll dr, ll a, ll b)
    {
        if(a <= st && dr <= b)
            return sum[node];
        ll mid = (st + dr) / 2;
        ll maxim = 0;
        if(a <= mid)
            maxim += suma(node * 2, st, mid, a, b);
        if(b > mid)
            maxim += suma(node * 2 + 1, mid + 1, dr, a, b);
        return maxim;
    }

    void taie(ll l, ll r, ll k)
    {
        Node x = query(1, 1, n, l, r);
        while(k > 0 && x.first != x.minim)
        {
            ll taiem = min(k, max(x.first - x.maxim2, 1LL));

            k -= taiem;
            update(1, 1, n, x.second, x.first - taiem);
            x = query(1, 1, n, l, r);
        }
        if(k > 0){
            ll nr = r - l + 1;
            for(ll i = l; i <= r; i++){
                update(1, 1, n, i, max(0LL, query(1, 1, n, i, i).first - k / nr));
            }
            k = k % nr;
            for(ll i = l; i <= r && k--; i++){
                update(1, 1, n, i, max(0LL, query(1, 1, n, i, i).first - 1));
            }
        }

    }
} st;

ll s = 0;
ll valv[NMAX];

void initialise(ll N, ll Q, ll h[])
{
    n = N;
    for(ll i = 1; i <= n; i++){
        s += h[i];
        valv[i] = h[i];
    }
}
void cut(ll l, ll r, ll k)
{
    s -= k;
}
void magic(ll i, ll x)
{
    s += (x - valv[i]);
    valv[i] = x;

}
long long ll inspect(ll l, ll r)
{
    // Your code here.
    return s;
}
