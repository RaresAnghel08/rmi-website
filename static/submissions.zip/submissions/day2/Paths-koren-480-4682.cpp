/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Paths
* score: 12.0
* date:  2021-12-17 08:23:48.860960
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef pair<ll, ll> pii;
typedef vector<pii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

const int MAX_N = 1e5 + 1;

ll ans[MAX_N];
pii dp[MAX_N];

ll Dfs1(vector<vii> &tree, int node, int parent) {
    vi dp_sons;
    for (pii p : tree[node]) {
        if (p.x != parent) {
            dp_sons.push_back(Dfs1(tree, p.x, node) + p.y);
        }
    }
    if (dp_sons.empty()) return 0;
    sort(all(dp_sons), greater<ll>());
    dp[node].x = dp_sons[0];
    if (dp_sons.size() > 1) dp[node].y = dp_sons[1];
    return dp_sons[0];
}

void Dfs2(vector<vii> &tree, int node, int parent, ll dist) {
    vi v = {dist, dp[node].x, dp[node].y};
    sort(all(v), greater<ll>());
    ans[node] = v[0];
    for (pii &p : tree[node]) {
         if (p.x != parent) {
             if (dp[p.x].x + p.y == v[0]) {
                 Dfs2(tree, p.x, node, v[1] + p.y);
             } else {
                 Dfs2(tree, p.x, node, v[0] + p.y);
             }
         }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n, k;
    cin >> n >> k;
    vector<vii> tree(n + 1);
    for (int i = 0; i < n - 1; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        tree[a].push_back({b, c});
        tree[b].push_back({a, c});
    }
    Dfs1(tree, 1, 0);
    Dfs2(tree, 1, 0, 0);
//    for (int i = 1; i <= n; i++) {
//        ans[i] = Solve(i, tree, k);
//    }
    for (int i = 1; i <= n; i++) cout << ans[i] << '\n';
}
