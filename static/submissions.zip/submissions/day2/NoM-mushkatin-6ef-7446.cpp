/**
* user:  mushkatin-6ef
* fname: Shirli
* lname: Mushkatin
* task:  NoM
* score: 9.0
* date:  2021-12-17 11:55:45.071258
*/
﻿// NoM.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef pair<int, int> pii;
typedef vector<pii> vp;
typedef vector<vp> vvp;

ll ans = 0;
const int mod = 1e9 + 7;

void calc(int i, int n, int m, vi& arr, vi& used){
    if (i == 2 * n + 1) {
        for (int ind = 1; ind <= n; ind++) {
            int del = abs(arr[ind] - arr[ind + n]);
            if (del % m == 0)
                return;
        }
        ans = (ans + 1) % mod;
    }
    for (int r = 1; r <= 2 * n; r++) {
        if (used[r])
            continue;
        used[r] = 1;
        arr[r] = i;
        calc(i + 1, n, m, arr, used);
        used[r] = 0;
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    vi used(2 * n + 1);
    vi arr(2 * n + 1);
    calc(1, n, m, arr, used);
    cout << ans << endl;
    return 0;
}

