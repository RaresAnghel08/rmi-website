/**
* user:  daminov-9d1
* fname: Kamil
* lname: Daminov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:45:07.183002
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;

const int mod = 1e9 - 7;

signed main() {
    int n, m; cin >> n >> m;

    vector<pair<int, int>> A;
    for (int i = 1; i <= n; i++) {
        A.push_back({i, 0});
        A.push_back({i, 1});
    }

    int cnt = 0;

    do {
        int pos[2][n];
        for (int i = 0; i < 2 * n; i++) {
            pos[A[i].second][A[i].first - 1] = i;
        }

        bool f = true;
        for (int i = 0; i < n; i++) {
            f &= (abs(pos[0][i] - pos[1][i]) % m != 0);
        }
        if (f) {
            cnt++;
            cnt %= mod;
        }
    }
    while (next_permutation(A.begin(), A.end()));
    cout << cnt;
}
