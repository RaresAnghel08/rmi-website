/**
* user:  guzun-e1f
* fname: Veaceslav
* lname: Guzun
* task:  Paths
* score: 12.0
* date:  2021-12-17 08:34:25.992621
*/
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define sz(a) (int)a.size()
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()
#define pb push_back

const int N = 1e5 + 10;
vector<pair<int,int>> adj[N];
int n, k;
vector<ll> bfs(int start){
    vector<ll> dist(n, -1);
    dist[start] = 0;
    queue<int> q;

    q.push(start);

    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto x: adj[u]){
            int v = x.first, w = x.second;
            if(dist[v] == -1){
                dist[v] = dist[u] + w;
                q.push(v);
            }
        }
    }
    return dist;
}

void solve(){
    cin >> n >> k;
    for(int i = 0;i < n - 1; ++i){
        int u, v, w;
        cin >> u >> v >> w;
        --u, --v;
        adj[u].pb({v, w});
        adj[v].pb({u, w});
    }
    vector<ll> d = bfs(0);

    int farthest = 0;
    for(int i = 0;i < n; ++i){
        if(d[i] >= d[farthest])farthest = i;
    }
    d = bfs(farthest);
    int a = farthest;

    int b = 0;
    for(int i = 0;i < n; ++i){
        if(d[i] > d[b])b = i;
    }

    vector<ll> A = bfs(a);
    vector<ll> B = bfs(b);

    for(int i = 0;i < n; ++i){
        cout << max(A[i], B[i]) << "\n";
    }
}

int main() {
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}
