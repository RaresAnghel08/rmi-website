/**
* user:  penchev-0e9
* fname: Jasen
* lname: Penchev
* task:  Paths
* score: 12.0
* date:  2021-12-17 07:29:57.295059
*/
#include <iostream>
#include <utility>
#include <vector>
#define endl '\n'
using namespace std;

const int MAXN = 100000;

pair<long long, int> dp[MAXN + 5][2];
vector< pair<int, int> > G[MAXN + 5];

void DFS(int u, int p)
{
    dp[u][0] = dp[u][1] = make_pair(0, -1);
    for (auto [v, w] : G[u])
    {
        if (v != p)
        {
            DFS(v, u);
            long long s = dp[v][0].first + w;
            if (dp[u][0].first < s)
            {
                dp[u][1] = dp[u][0];
                dp[u][0] = make_pair(s, v);
            }
            else if (dp[u][1].first < s)
            {
                dp[u][1] = make_pair(s, v);
            }
        }
    }
}

void DFS1(int u, int p, int w0)
{
    if (p != -1)
    {
        long long s;
        if (dp[p][0].second != u) s= dp[p][0].first + w0;
        else s = dp[p][1].first + w0;
        if (dp[u][0].first < s)
        {
            dp[u][1] = dp[u][0];
            dp[u][0] = make_pair(s, p);
        }
        else if (dp[u][1].first < s)
        {
            dp[u][1] = make_pair(s, p);
        }
    }
    for (auto [v, w] : G[u])
    {
        if (v != p)
        {
            DFS1(v, u, w);
        }
    }
}

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n, k;
    cin >> n >> k;

    for (int i = 1; i < n; ++ i)
    {
        int u, v, w;
        cin >> u >> v >> w;
        G[u].push_back(make_pair(v, w));
        G[v].push_back(make_pair(u, w));
    }

    DFS(1, -1);
    DFS1(1, -1, 0);

    for (int i = 1; i <= n; ++ i)
    {
        cout << dp[i][0].first << endl;
    }

    return 0;
}

/*
11 1
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/
