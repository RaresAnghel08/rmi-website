/**
* user:  klisch-180
* fname: Danil
* lname: Klisch
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 09:55:00.311583
*/
//bs:sanitizers,flags:"grader.cpp"
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

template <typename T>
using normal_queue = priority_queue<T, vector<T>, greater<T>>;

#define x first
#define y second
#define all(x) begin(x), end(x)
#define sz(x) ((int) (x).size())
using ll = long long;
using ld = long double;

const int TREE = 1 << 20, INF = 0x3f3f3f3f;

struct Node {
	int mx1, where1, cnt1, mx2, cnt2, mod;
} t[TREE];

void tapply(int i, int x) {
	if (t[i].mod < x) {
		return;
	}
	assert(t[i].mx2 < x);
	t[i].mod = x;
	t[i].mx1 = min(t[i].mx1, x);
}

void node_merge(Node &res, const Node &lef, const Node &rig) {
	res.mod = +INF;
	res.mx1 = max(lef.mx1, rig.mx1);
	res.where1 = min({
		(res.mx1 == lef.mx1 ? lef.where1 : +INF),
		(res.mx1 == rig.mx1 ? rig.where1 : +INF)
	});
	// res.mx2 = max({
	// 	(res.mx1 == lef.mx1 ? -INF : lef.mx1),
	// 	(res.mx1 == rig.mx1 ? -INF : rig.mx1),
	// 	lef.mx2, rig.mx2
	// });
	// res.cnt1 =
	// 	(res.mx1 == lef.mx1 ? lef.cnt1 : 0) + 
	// 	(res.mx1 == rig.mx1 ? rig.cnt1 : 0);
	// res.cnt2 =
	// 	(res.mx2 == lef.mx1 ? lef.cnt1 : 0) +
	// 	(res.mx2 == rig.mx1 ? rig.cnt1 : 0) + 
	// 	(res.mx2 == lef.mx2 ? lef.cnt2 : 0) + 
	// 	(res.mx2 == rig.mx2 ? rig.cnt2 : 0);
	// cout << "mx1 " << lef.mx1 << " " << rig.mx1 << " " << res.mx1 << endl;
}

void trecapply(int x, int i, int l, int r) {
	if (t[i].mx2 < x) {
		tapply(i, x);
		return;
	}
	int mid = (l + r) / 2;
	trecapply(x, 2 * i + 1, l, mid);
	trecapply(x, 2 * i + 2, mid, r);
	node_merge(t[i], t[2 * i + 1], t[2 * i + 2]);
}

void tpush(int i, int l, int r) {
	if (t[i].mod == +INF) {
		return;
	}
	int mid = (l + r) / 2;
	trecapply(t[i].mod, 2 * i + 1, l, mid);
	trecapply(t[i].mod, 2 * i + 2, mid, r);
	t[i].mod = 0;
}

int n;

void tbuild(int h[], int i = 0, int l = 0, int r = n) {
	// cout << i << " " << l << " " << r << endl;
	if (r - l == 1) {
		t[i] = {h[l], l, 1, -INF, 0, +INF};
		return;
	}
	t[i].mod = +INF;
	int mid = (l + r) / 2;
	tbuild(h, 2 * i + 1, l, mid);
	tbuild(h, 2 * i + 2, mid, r);
	node_merge(t[i], t[2 * i + 1], t[2 * i + 2]);
	// cout << t[i].mx1 << endl;
}

pair<int, int> tmax(int ql, int qr, int i = 0, int cl = 0, int cr = n) {
	if (ql <= cl && cr <= qr) {
		return {t[i].mx1, t[i].where1};
	}
	if (qr <= cl || cr <= ql) {
		return {-INF, -1};
	}
	int mid = (cl + cr) / 2;
	tpush(i, cl, cr);
	return max(tmax(ql, qr, 2 * i + 1, cl, mid), tmax(ql, qr, 2 * i + 2, mid, cr));
}

void tset(int qi, int x, int ci = 0, int cl = 0, int cr = n) {
	if (qi < cl || cr <= qi) {
		return;
	}
	if (cr - cl == 1) {
		t[ci] = {x, cl, 1, -INF, 0, +INF};
		return;
	}
	int mid = (cl + cr) / 2;
	tpush(ci, cl, cr);
	tset(qi, x, 2 * ci + 1, cl, mid);
	tset(qi, x, 2 * ci + 2, mid, cr);
	node_merge(t[ci], t[2 * ci + 1], t[2 * ci + 2]);
}

void tmineq(int ql, int qr, int x, int ci = 0, int cl = 0, int cr = n) {
	// cout << ql << " " << qr << " " << x << " " << ci << " " << cl << " " << cr << endl;
	if (ql <= cl && cr <= qr) {
		trecapply(x, ci, cl, cr);
		return;
	}
	if (qr <= cl || cr <= ql) {
		return;
	}
	int mid = (cl + cr) / 2;
	tpush(ci, cl, cr);
	tmineq(ql, qr, x, 2 * ci + 1, cl, mid);
	tmineq(ql, qr, x, 2 * ci + 2, mid, cr);
	node_merge(t[ci], t[2 * ci + 1], t[2 * ci + 2]);
}

void initialise(int n_, int q, int h[]) {
	n = n_;
	tbuild(h + 1);
	// for (int i = 0; i < n; ++i) {
	// 	cout << tmax(i, i + 1).x << " ";
	// }
	// cout << "\n";
}

void cut(int l, int r, int k) {
	--l;
	for (int i = 0; i < k; ++i) {
		auto res = tmax(l, r);
		if (res.x == 0) {
			return;
		}
		// cout << "max " << res.x << " " << res.y << endl;
		tmineq(res.y, res.y + 1, res.x - 1);
	}
}

void magic(int i, int x) {
	tset(--i, x);
}

ll inspect(int l, int r) {
	ll ans = 0;
	for (int i = l - 1; i < r; ++i) {
		ans += tmax(i, i + 1).x;
	}
	return ans;
}
