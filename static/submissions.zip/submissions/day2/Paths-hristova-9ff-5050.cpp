/**
* user:  hristova-9ff
* fname: Simona Nikolaeva
* lname: Hristova
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:56:43.504272
*/
#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>
#include <string>
#include <cstring>
#include <algorithm>

using namespace std;
int n,k;
int x,y,c;
struct cell
{
    int s,b;
};
vector<cell> t[200001];
vector<int> v;
bool used[10000000];
void dfs(int i,int br,int st)
{
    ///cout<<st<<" "<<i<<endl;
    used[i]=1;
    int sz=t[i].size();
    ///cout<<sz<<endl;
    if(sz==1&&used[t[i][0].s]==1){v.push_back(br);}
    else
    {
        for(int j=0;j<sz;j++)
        {
            cell nb=t[i][j];
            if(used[nb.s]==0)dfs(nb.s,br+nb.b,st);
        }
    }
}
void read()
{
    cin>>n>>k;
    for(int i=0;i<n-1;i++)
    {
        ///cout<<i<<endl;
        cin>>x>>y>>c;
        cell p1;
        p1.s=y-1;
        p1.b=c;
        ///cout<<p1.s<<" "<<p1.b<<endl;
        cell p2;
        p2.s=x-1;
        p2.b=c;
        ///cout<<p2.s<<" "<<p2.b<<endl;
        t[x-1].push_back(p1);
        t[y-1].push_back(p2);
    }
}
void print()
{

}
void solve()
{
    for(int i=0;i<n;i++)
    {
        dfs(i,0,i);
        for(int j=0;j<=n;j++)used[j]=0;
        int maxv=0;
       /// cout<<v.size()<<endl;
        while(v.size()!=0)
        {
            if(v[v.size()-1]>maxv)maxv=v[0];
            v.pop_back();
        }
        cout<<maxv<<endl;
    }
}
int main()
{
    read();
    solve();
    return 0;
}
