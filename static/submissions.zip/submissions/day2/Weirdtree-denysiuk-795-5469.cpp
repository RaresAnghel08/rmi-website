/**
* user:  denysiuk-795
* fname: Vladyslav
* lname: Denysiuk
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:33:16.566414
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double ld;

#define endl '\n'
#define all(var) var.begin(),var.end()
#define mp make_pair

const int N = 3e5+7;
const int INF = 1e9+7;

int n;
struct node{
    ll sum;
    ll mod;
    pair<int,int> mx,scmx;
    node(ll _sum = 0,pair<int,int> _mx = {-INF,0},pair<int,int> _scmx = {-INF-1,0}){
        sum = _sum;
        mx = _mx;
        scmx = _scmx;
        mod = -1;
    }
} T[N<<1];

void add(pair<int,int> &mx,pair<int,int> &scmx,pair<int,int> val){
    if (val.first==mx.first)
        mx.second+=val.second;
    else if (val.first==scmx.first)
        scmx.second+=val.second;
    else if (val.first>scmx.first){
        scmx = val;
        if (mx.first<scmx.first)
            swap(mx,scmx);
    }
}
node merge(node a,node b){
    pair<int,int> mx = mp(0,0),scmx = mp(0,0);
    add(mx,scmx,a.mx);
    add(mx,scmx,a.scmx);
    add(mx,scmx,b.mx);
    add(mx,scmx,b.scmx);
    return node(a.sum+b.sum,mx,scmx);
}
int H[N];
void buildtree(int t,int tl,int tr){
    if (tl==tr){
        T[t] = node(H[tl],mp(H[tl],1),mp(-INF,0));
        return;
    }
    int tm = (tl+tr)>>1;
    int nl = t+1, nr = t+((tm-tl+1)<<1);
    buildtree(nl,tl,tm);
    buildtree(nr,tm+1,tr);
    T[t] = merge(T[nl],T[nr]);
}
void F(int t,int val){
    if (T[t].mx.first>val){
        T[t].mod = val;
        T[t].sum-=(T[t].mx.first-val)*T[t].mx.second;
        T[t].mx.first = val;
        T[t].mod = val;
    }
}
void push(int t,int nl,int nr){
    if (T[t].mod==-1)
        return;
    int mod = T[t].mod;
    T[t].mod = -1;
    F(nl,mod);
    F(nr,mod);
}

void update(int t,int tl,int tr,int l,int r,int val){
    if (tl>r || l>tr)
        return;
    if (l<=tl && tr<=r && T[t].scmx.first<val){
        F(t,val);
        return;
    }
    int tm = (tl+tr)>>1;
    int nl = t+1, nr = t+((tm-tl+1)<<1);
    push(t,nl,nr);
    update(nl,tl,tm,l,r,val);
    update(nr,tm+1,tr,l,r,val);
    T[t] = merge(T[nl],T[nr]);
}

node get(int t,int tl,int tr,int l,int r){
    if (tl>r || l>tr)
        return node();
    if (l<=tl && tr<=r)
        return T[t];
    int tm = (tl+tr)>>1;
    int nl = t+1, nr = t+((tm-tl+1)<<1);
    push(t,nl,nr);
    return merge(get(nl,tl,tm,l,r),get(nr,tm+1,tr,l,r));

}
int get_bound(int t,int tl,int tr,int l,int r,int val,int &cnt){
    if (tr<l || r<tl)
        return 0;
    if (l<=tl && tr<=r && T[t].mx.first==val && T[t].mx.second<=cnt){
        cnt-=T[t].mx.second;
        return tr;
    }
    if (tl==tr)
        return tl-1;
    int tm = (tl+tr)>>1;
    int nl = t+1, nr = t+((tm-tl+1)<<1);
    push(t,nl,nr);
    int ret = get_bound(nl,tl,tm,l,r,val,cnt);
    if (cnt==0)
        return ret;
    ret = max(ret,get_bound(nr,tm+1,tr,l,r,val,cnt));
    return ret;
}
void set_val(int t,int tl,int tr,int pos,int val){
    if (tl>pos || tr<pos)
        return;
    if (tl==tr){
        T[t] = node(val,mp(val,1),mp(-INF,0));
        return;
    }
    int tm = (tl+tr)>>1;
    int nl = t+1, nr = t+((tm-tl+1)<<1);
    push(t,nl,nr);
    set_val(nl,tl,tm,pos,val);
    set_val(nr,tm+1,tr,pos,val);
    T[t] = merge(T[nl],T[nr]);
}
void initialise(int N, int Q, int h[]) {
	n = N;
	for(int i = 1;i<=n;++i)
        H[i] = h[i];
	buildtree(0,1,n);
	//cout<<T[0].sum<<endl;
}
void cut(int l, int r, int k) {
    int base = k;
    while(1){

        node ret = get(0,1,n,l,r);
        if (ret.mx.first==0)
            break;
        if (k<ret.mx.second){
           // cout<<k<<' '<<ret.mx.first<<endl;
            int pos = get_bound(0,1,n,l,r,ret.mx.first,k);
            //cout<<pos<<endl;
            update(0,1,n,l,pos,ret.mx.first-1);
            k = 0;
            break;
        }
        int can = k/ret.mx.second;
        //cout<<ret.scmx.first<<' '<<ret.scmx.second<<endl;
       // while(1);
        if (ret.mx.first-can<=ret.scmx.first){
            k-=ret.mx.second*(ret.mx.first-ret.scmx.first);
            update(0,1,n,l,r,ret.scmx.first);
        }
        else{
            k-=ret.mx.second*can;
            update(0,1,n,l,r,ret.mx.first-can);
        }
       // cout<<T[0].sum<<endl;
    }
    //cout<<T[0].sum<<endl;
}
void magic(int i, int x) {
    set_val(0,1,n,i,x);
}
long long int inspect(int l, int r) {
	return get(0,1,n,l,r).sum;
}
