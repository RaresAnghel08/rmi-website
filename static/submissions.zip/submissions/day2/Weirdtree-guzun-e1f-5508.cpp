/**
* user:  guzun-e1f
* fname: Veaceslav
* lname: Guzun
* task:  Weirdtree
* score: 21.0
* date:  2021-12-17 09:36:38.949091
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define sz(a) (int)a.size()
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()
#define pb push_back

struct node{
    int idx;
    ll sum;
};

vector<int> a;
const int N = 3e5 + 2;
node t[4 * N];


node merge(node x, node y){
    node c;
    c.sum = x.sum + y.sum;
    if(x.idx == -1){
        c.idx = y.idx;
    }else if(y.idx == -1){
        c.idx = x.idx;
    }else if(a[x.idx] >= a[y.idx]){
        c.idx = x.idx;
    }else c.idx = y.idx;
    return c;
}

void build(int i, int l, int r){
    if(l == r){
        t[i].idx = l;
        t[i].sum = a[l];
        return;
    }

    int mid = (l + r) / 2;

    build(2 * i, l, mid);
    build(2 * i + 1, mid + 1, r);
    t[i] = merge(t[2 * i], t[2 * i + 1]);
}

node neutral = {-1, 0};
int n;
node query(int i, int l, int r, int tl, int tr){
    if(l > tr || r < tl)return neutral;
    if(l >= tl && r <= tr)return t[i];

    int mid = (l + r) / 2;

    return merge(query(2 * i, l, mid, tl, tr), query(2 * i + 1, mid + 1, r, tl, tr));
}
void modif(int i, int l, int r, int pos){
    if(l > pos || r < pos)return;
    if(l >= pos && r <= pos){
        t[i].sum = a[l];
        t[i].idx = l;
        return;
    }

    int mid = (l + r) / 2;
    modif(2 * i, l, mid, pos);
    modif(2 * i + 1, mid + 1, r, pos);

    t[i] = merge(t[2 * i], t[2 * i + 1]);
}
void  initialise(int N, int Q, int h[]){
    n = N;
    a.clear();
    for(int i = 1;i <= n; ++i)a.pb(h[i]);

    build(1, 0, n - 1);
}
bool cmp(pair<int,int> a, pair<int,int> b){
    if(a.first > b.first)return true;
    if(b.first > a.first)return false;
    return (a.second < b.second);
}

void  cut(int l, int r, int k){
    --l, --r;
    node x = query(1, 0, n - 1, l, r);
    if(x.sum == 0)return;
    if(k >= 10000)
    {
        vector<pair<ll,ll>> x;
        for(int i = l;i <= r; ++i){
            x.pb({a[i], i});
        }
        sort(all(x), cmp);
        ll count = 0;
        ll val_all = x[0].first;
        x.pb({INT_MIN, -1});
        for(int i = 0;i + 1 < sz(x); ++i){
            ++count;
            ll need = count * (x[i].first - x[i + 1].first);
            if(need <= k){
                 k -= need;
                 val_all = x[i + 1].first;
            }else{
                ll substract = k / count;
                k %= count;
                for(int j = 0;j <= i; ++j){
                    x[j].first = max(0LL, val_all - substract);
                }
                sort(all(x), cmp);
                for(int j = 0;j < sz(x) && k; ++j){
                    if(!x[j].first)continue;
                    --x[j].first;
                    --k;
                }
                break;
            }
        }
        for(auto f: x){
            if(f.second != -1){
                a[f.second] = f.first;
                modif(1, 0, n - 1, f.second);
            }
        }
        return;
    }
    while(k--){
        node x = query(1, 0, n - 1, l, r);
        if(x.idx == -1)break;
        assert(x.idx != -1);
        if(a[x.idx] == 0)break;
        a[x.idx]--;
        modif(1, 0, n - 1, x.idx);
    }
}

void magic(int i, int x){
    --i;
    a[i] = x;
    modif(1, 0, n - 1, i);
}

long  long  int inspect(int l, int r){
    --l, --r;
    node x = query(1, 0, n - 1, l, r);
    return x.sum;
}

/*
int main() {
    //ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}
*/
