/**
* user:  dekany-ab1
* fname: Csaba
* lname: Dékány
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:23:57.210127
*/
#include "weirdtree.h"


int H[1001];
int n, q;
void initialise(int N, int Q, int h[]) {
	n=N;
	q=Q;
	for(int i=1;i<n+1;i++)
    {
        H[i]=h[i];
    }
}
void cut(int l, int r, int k) {
    int maxi=-1;
    int index=0;
    for(int j=0;j<k;j++)
    {
        maxi=-1;
        index=0;
   for(int i=l;i<=r;i++)
    {
        if(maxi<H[i])
        {
            maxi=H[i];
            index=i;
        }
    }
    if(maxi>0)
    {
        H[index]--;
    }
    else{
        break;
    }

    }

}
void magic(int i, int x) {
	H[i]=x;
}
long long int inspect(int l, int r) {
    int sum=0;
	for(int i=l;i<=r;i++)
    {
        sum=sum+H[i];
    }
	return sum;
}
