/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  Paths
* score: 56.0
* date:  2021-12-17 07:53:51.964372
*/
#include <bits/stdc++.h>
typedef long long ll;
#define endl '\n'
using namespace std;
const int N=200010;
const ll mod=1000000007;
vector<pair<int,ll> >g[N];
ll d[N];
int go[N];
ll val[N];
void dfs(int v,int pr){
    d[v]=0ll;
    go[v]=v;
    for (auto cur:g[v]){
        int to=cur.first;
        ll c=cur.second;
        if (to==pr) continue;
        dfs(to,v);
        val[go[to]]+=c;
        if (d[v]<d[to]+c){
            d[v]=d[to]+c;
            go[v]=go[to];
        }
    }
}
set<pair<ll,int> >st;
ll ans[N];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n,k;cin>>n>>k;
    for (int i=1;i<n;i++){
        int a,b,c;cin>>a>>b>>c;
        g[a].push_back({b,c});
        g[b].push_back({a,c});
    }
    for (int rt=1;rt<=n;rt++){
        for (int i=1;i<=n;i++) val[i]=0ll;

        dfs(rt,0);
        sort(val+1,val+n+1);
        for (int i=n-k+1;i<=n;i++) ans[rt]+=val[i];
//        for (int i=1;i<=n;i++){
//            st.insert({val[i],i});
//        }
//        while (st.size()>k){
//            st.erase(st.begin());
//        }
//        ans[rt]=0ll;
//        for (auto cur:st) ans[rt]+=cur.first;
//        st.clear();
    }



    for (int i=1;i<=n;i++) cout<<ans[i]<<endl;
    return 0;
}
