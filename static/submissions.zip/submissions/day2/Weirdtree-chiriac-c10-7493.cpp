/**
* user:  chiriac-c10
* fname: Matei
* lname: Chiriac
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:57:24.615045
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

using namespace std;

int n;
long long inPlus;
int a[1005];

long long cost(int st, int dr, long long mx)
{
    long long ans=0;
    for(int i=st;i<=dr;i++)
        ans += max(0, a[i]-mx);
    return ans;
}
int cb(int l, int r, long long k)
{
    long long st=0, dr=1e9, mij, last;

    while(st<=dr)
    {
        mij=(st+dr)/2;

        if(cost(l, r, mij) >= k)
        {
            last=mij;
            st=mij+1;

            inPlus = cost(l, r, mij) - k;
        }
        else
            dr=mij;
    }

    return last;
}

void initialise(int N, int Q, int h[])
{
    n=N;
    for(int i=1;i<=n;i++)
        a[i]=h[i];
}

void cut(int l, int r, int k)
{
    int mx=cb(l, r, k);

    for(int i=r;i>=l;i--)
    {
        if(a[i] > mx && inPlus)
        {
            inPlus--;
            a[i]=mx+1;
        }
        else
            a[i]=min(a[i], mx);
    }

}

void magic(int i, int x)
{
    a[i]=x;
}

long long inspect(int l, int r)
{
    long long ans=0;
    for(int i=l;i<=r;i++)
        ans += a[i];

    return ans;
}
