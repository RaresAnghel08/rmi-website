/**
* user:  taga-9e5
* fname: Ștefan
* lname: Țaga
* task:  Paths
* score: 19.0
* date:  2021-12-17 07:52:35.167221
*/
#include <bits/stdc++.h>

using namespace std;
long long din[2005][2005];
int n,k;
vector <pair <int,long long >  > v[2005];
void dfs(int x,int tata)
{
    bool ok=0;
    for (int i=0;i<v[x].size();i++)
    {
        if (v[x][i].first!=tata)
        {
            dfs(v[x][i].first,x);
            ok=1;
        }
    }
    if (ok==0)
    {
        din[x][1]=0;
        return;
    }
    int i,j,t;
    for (i=0;i<v[x].size();i++)
    {
        if (v[x][i].first!=tata)
        {
            int nod=v[x][i].first;
            long long costul=v[x][i].second;
            for (j=k;j>=1;j--)
            {
                for (t=j;t>=1;t--)
                {
                    if (j-t>=0&&din[nod][t]!=-1&&din[x][j-t]!=-1)
                    {
                        din[x][j]=max(din[x][j],din[nod][t]+din[x][j-t]+costul);
                    }
                }
            }
        }
    }
}
int x,y,cost,i,j,t;
int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(0);
    #ifdef HOME
    ifstream cin("date.in");
    ofstream cout("date.out");
    #endif // HOME
    cin>>n>>k;
    for (i=1;i<n;i++)
    {
        cin>>x>>y>>cost;
        v[x].push_back({y,cost});
        v[y].push_back({x,cost});
    }
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++)
        {
            for (t=1;t<=k;t++)
            {
                din[j][t]=-1;
            }
        }
        dfs(i,0);
        long long solfin=0;
        for (t=1;t<=k;t++)
        {
            solfin=max(solfin,din[i][t]);
        }
        cout<<solfin<<'\n';
    }
    return 0;
}
