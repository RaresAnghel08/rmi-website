/**
* user:  lugli-eb4
* fname: Francesco
* lname: Lugli
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:12:42.554822
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair < ll , ll > pll;
typedef priority_queue < ll > pq;

vector < vector < pll > > g;
vector < pll > dis; //distanza di un nodo da una foglia se radice = r
vector < ll > val; //contributo di un nodo nella risposta se radice = r
vector < ll > ans; //subtask K = 1
ll K;

ll calcd(int x, int f = -1)
{
	dis[x] = {0, 0};

	for (pll p : g[x])
	{
		ll y = p.first, w = p.second;
		if (y != f)
		{
			ll dd = calcd(y, x)+w;
			if (dd > dis[x].second) dis[x].second = dd;
			if (dis[x].second > dis[x].first) swap(dis[x].second, dis[x].first);
		}
	}
	return dis[x].first;
}

/*
void calc(int x, ll d=0, int f=-1)
{
	val[x] = d;
	ll be = -1;
	for (pll p : g[x])
	{
		ll y = p.first, w = p.second;
		if (y != f)
		{
			ll nv = d + w + dis[y];
			if (nv > val[x])
			{
				val[x] = nv;
				be = y;
			}
		}
	}

	if (be != -1)
	{
		calc(y, d+w, x);
	}

	for (ll p : g[x])
	{
		ll y = p.first, w = p.second;
		if (y != f && y != be)
		{
			calc(y, w, x);
		}
	}
}*/

void recalc(int x, ll w = 0, int f=-1)
{
	if (f != -1)
	{
		ll dd = dis[f].first;
		if (dd == dis[x].first + w) dd = dis[f].second;
		dd += w;
		if (dd > dis[x].second) dis[x].second = dd;
		if (dis[x].second > dis[x].first) swap(dis[x].second, dis[x].first);
	}
	for (pll p : g[x])
	{
		ll y = p.first, ww = p.second;
		if (y != f)
		{
			recalc(y, ww, x);
		}
	}
}

int main()
{
	int N;
	cin >> N >> K;
	g.resize(N);
	dis.resize(N);
	ans.resize(N, 0);

	ll tot = 0;
	for (int i = 0; i < N-1; i++)
	{
		int a, b;	
		ll w;
		cin >> a >> b >> w;
		a--; b--;
		tot += w;
		g[a].push_back({b, w});
		g[b].push_back({a, w});
	}

	calcd(0);
	recalc(0);

	for (pll v : dis) cout << v.first << " ";
	cout << "\n";
}
