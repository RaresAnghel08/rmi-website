/**
* user:  mihov-0af
* fname: Petar Velislavov
* lname: Mihov
* task:  Paths
* score: 56.0
* date:  2021-12-17 11:38:19.517171
*/
#include<bits/stdc++.h>
using namespace std;
#define k1 kids[x][q].to
#define k2 kids[x][q].cen
#pragma target ("sse4")
#pragma optimise ("O3")
const long long MAXN=100007;
struct edge
{
    short to;
    long long cen;
};
vector<edge> v[MAXN],kids[MAXN];
edge par[MAXN];
short n,k;
void koren(short x,short pp)
{
    for (short q=0;q<v[x].size();q++)
    {
        if (v[x][q].to!=pp)
        {
            kids[x].push_back(v[x][q]);
            par[v[x][q].to].to=x;par[v[x][q].to].cen=v[x][q].cen;
            koren(v[x][q].to,x);
        }
    }
}
long long dp1[MAXN],cum[MAXN];
void dpe(short x)
{
    dp1[x]=-1;cum[x]=-1;
    for (short q=0;q<kids[x].size();q++)
    {
        dpe(k1);
        if ((dp1[k1]+k2)>dp1[x])
        {
            dp1[x]=(dp1[k1]+k2);
            cum[x]=q;
        }
    }
    if (dp1[x]==-1) dp1[x]=0;
}
bool mn[MAXN],b[MAXN];
long long razt[MAXN],who[MAXN];
void dfs(long long x)
{
    b[x]=1;
    if (par[x].to==0) return;
    if (!mn[par[x].to] && !b[par[x].to])
    {
        dfs(par[x].to);
        razt[x]=razt[par[x].to]+par[x].cen;
        who[x]=who[par[x].to];
    }
    else
    {
        razt[x]=razt[par[x].to]+par[x].cen;
        if (mn[par[x].to]) who[x]=par[x].to;
        else who[x]=who[par[x].to];
    }
}
int main()
{
    srand(time(0));
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>n>>k;
    //n=readInt();k=readInt();
    for (short q=0;q<n-1;q++)
    {
        short a12,b12;
        long long c12;
        cin>>a12>>b12>>c12;
        //a12=readInt();b12=readInt();c12=readLong();
        edge aa;
        aa.to=a12;
        aa.cen=c12;
        v[b12].push_back(aa);aa.to=b12;
        v[a12].push_back(aa);
    }
    long long ans=0,nc=rand()%n+1;
     while (true)
     {
         ans=0;
        for (int w=1;w<=n;w++)
        {
            kids[w].clear();
            mn[w]=false;
        }
        par[nc].to=0;
        koren(nc,0);
        dpe(nc);
        for (short e=0;e<k;e++)
        {
            ans+=dp1[nc];
            short x=nc;
            //cout<<dp1[nc]<<"\n";
            while (cum[x]!=-1)
            {
                mn[x]=1;
                //cout<<x<<"\n";
                kids[x][cum[x]].cen=0;
                x=kids[x][cum[x]].to;
            }
            mn[x]=1;
            //cout<<x<<"\n\n";
            while (x!=0)
            {
                dp1[x]=0;
                for (short w=0;w<kids[x].size();w++)
                {
                    if ((dp1[kids[x][w].to]+kids[x][w].cen) > dp1[x])
                    {
                        dp1[x] = dp1[kids[x][w].to]+kids[x][w].cen;
                        cum[x]=w;
                    }
                }
                x=par[x].to;
            }
        }
        int br=0;
        for (int w=0;w<kids[nc].size();w++)
        {
            if (mn[kids[nc][w].to]) br++;
        }
        //cout<<nc<<"\n";
        if (br>1) break;
        nc=rand()%n+1;
    }
    //cout<<nc<<"\n";
    for (int w=1;w<=n;w++)
    {
        kids[w].clear();
    }
    par[nc].to=0;
    koren(nc,0);
    dpe(nc);
    for (int q=1;q<=n;q++)
    {
        if (!mn[q] && !b[q]) dfs(q);
    }
    long long bst=0;
    for (int q=1;q<=n;q++)
    {
        if (!mn[q]) bst=max(bst,razt[q]);
    }
    //cout<<razt[10]<<"\n";
    for (int q=1;q<=n;q++)
    {
        if (mn[q] && kids[q].size()!=0)
        {
            long long wrst=100001000000000;
            for (int w=0;w<kids[q].size();w++)
            {
                if (mn[kids[q][w].to])
                {
                    wrst=min(wrst,dp1[kids[q][w].to]+kids[q][w].cen);
                }
            }
            //cout<<wrst<<" ";
            if (bst>wrst) cout<<ans+bst-wrst<<"\n";
            else cout<<ans<<"\n";
        }
        else
        {
            if (mn[q]) cout<<ans+bst<<"\n"; // correct
            else
            {
                int qq=who[q];
                long long wrst=100001000000000;
                for (int w=0;w<kids[qq].size();w++)
                {
                    if (mn[kids[qq][w].to])
                    {
                        wrst=min(wrst,dp1[kids[qq][w].to]+kids[qq][w].cen);
                    }
                }
                if (bst>wrst) cout<<ans+razt[q]-wrst+bst<<"\n";
                else cout<<ans+razt[q]<<"\n";
            }
        }
    }
}
/*
36
36
37
38
37
36
36
38
38
37
38
*/
