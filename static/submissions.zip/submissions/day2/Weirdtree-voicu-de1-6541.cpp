/**
* user:  voicu-de1
* fname: Mihai Valeriu
* lname: Voicu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:59:22.599161
*/
#include "weirdtree.h"
#include <iostream>
#define max(x,y) (x>y?x:y)
#define min(x,y) (y>x?x:y)
const int nmax=80005;
int n;
#define int long long
using namespace std;
struct node {
  int maxx=-1,poz=0;
  int sum=0;
  void operator --() {
    maxx--;
    sum--;
    return;
  }
  node operator +(const node& x) const {
    node rez;
    rez.maxx=max(maxx,x.maxx);
    rez.sum=x.sum+sum;
    if(x.maxx>maxx)
      rez.poz=x.poz;
    else if(x.maxx<maxx)
      rez.poz=poz;
    else
      rez.poz=min(x.poz,poz);
    return rez;
  }
  bool operator >=(const int& x) const {
    return maxx>=x;
  }
};

int v[nmax];

class AINT {
  public:
    node tree[nmax*4];
    void build(int nde=1, int cl=1, int cr=n) {
      if(cl==cr) {
        tree[nde].maxx=v[cl];
        tree[nde].sum=v[cl];
        tree[nde].poz=cl;
        //cout << nde << ' ' << cl << ' '<< cr << ' '<< tree[nde].sum << ' '<< tree[nde].maxx << '\n';
        return;
      }
      int mid=cl+cr>>1;
      build(v,2*nde,cl,mid);
      build(v,2*nde+1,mid+1,cr);
      tree[nde]=tree[2*nde]+tree[nde*2+1];
        //cout << nde << ' ' << cl << ' '<< cr << ' '<< tree[nde].sum << ' '<< tree[nde].maxx << '\n';
    }
    void change(int poz, int val, int node=1, int cl=1, int cr=n) {
      if(cl==cr) {
        tree[node].maxx=val;
        tree[node].sum=val;
        return;
      }
      int mid=cl+cr>>1;
      if(poz<=mid)
        change(poz,val,node*2,cl,mid);
      else
        change(poz,val,node*2+1,mid+1,cr);
      tree[node]=tree[node*2]+tree[node*2+1];
      return;
    }
    node query(int l, int r, int nde=1, int cl=1, int cr=n) {
      if(l<=cl && cr<=r) {
        return tree[nde];
      }
      node val;
      int mid=cl+cr>>1,ok=0;
      if(l<=mid)
        val=query(l,r,nde*2,cl,mid),ok=1;
      if(mid<r) {
        if (ok) val=val+query(l,r,nde*2+1,mid+1,cr);
        else val=query(l,r,nde*2+1,mid+1,cr);
      }
      return val;
    }
}aint;


#undef int
void initialise(int N, int q, signed h[]) {
  n=N;
  for(int i=1; i<=n; i++)
    v[i]=h[i];
  aint.build(h);
}
void cut(int l, int r, int k) {
  auto val=aint.query(l,r);
  cout << val.poz << ' '<< val.maxx << '\n';
  aint.change(val.poz,val.maxx-1);
}
void magic(int i, int x) {
  aint.change(i,x);
}
long long inspect(int l, int r) {
  return aint.query(l,r).sum;
}
