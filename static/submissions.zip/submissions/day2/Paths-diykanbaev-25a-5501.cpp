/**
* user:  diykanbaev-25a
* fname: Talant
* lname: Diykanbaev
* task:  Paths
* score: 19.0
* date:  2021-12-17 09:35:49.701992
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;

#define pb push_back
#define mp make_pair
#define sz(v) (int)v.size()
#define all(v) v.begin(), v.end()

const int N = 1e5+7;
vector <pair <int, ll>> graph[N];
vector <pair <pii, ll>> edges;
int n, k;

int children[N], del[N];
bool used[N];
pair <int, ll> par[N];
multiset <pair <ll, int>> st;

void dfs(int v, int p = 0, ll c = 0) {
    par[v] = mp(p, c);
    int cnt = 0;
    for (auto to : graph[v]) {
        if (to.first == p) continue;
        dfs(to.first, v, to.second);
        cnt++;
        children[v] += children[to.first];
    }
    if (cnt == 0) {
        children[v] = 1;
        st.insert(mp(0, v));
    }
}

ll ans_for[N];
pll longest[N];

void dfs2(int v, int p = 0) {
    for (auto to : graph[v]) {
        if (to.first == p) continue;
        dfs2(to.first, v);
        if (longest[to.first].first+to.second > longest[v].first) {
            longest[v].second = longest[v].first;
            longest[v].first = longest[to.first].first+to.second;
        }
        else if (longest[to.first].first+to.second > longest[v].second) {
            longest[v].second = longest[to.first].first+to.second;
        }
    }
}

void dfs3(int v, ll l1, ll l2, int p = 0) {
    ans_for[v] = l1;
    for (auto to : graph[v]) {
        if (to.first == p) continue;
        if (longest[to.first].first+to.second == l1) {
            dfs3(to.first, max(l1-to.second, l2+to.second), min(l1-to.second, l2+to.second), v);
        }
        else if (longest[to.first].first+to.second == l2) {
            dfs3(to.first, l1+to.second, l2-to.second, v);
        }
        else {
            dfs3(to.first, l1+to.second, l2+to.second, v);
        }
    }
}

int main() {
    
    cin >> n >> k;

    ll sum = 0;
    
    for (int i = 0; i < n-1; i++) {
        int a, b;
        ll c;
        cin >> a >> b >> c;
        sum += c;
        if (a > b) swap(a, b);
        graph[a].pb(mp(b, c));
        graph[b].pb(mp(a, c));
        edges.pb(mp(mp(a, b), c));
    }
    sort(all(edges));
    
    if (n <= 2000) {
        for (int i = 1; i <= n; i++) {
            st.clear();
            for (int j = 0; j <= n; j++) children[j] = del[j] = 0, used[j] = 0;
            dfs(i);
            if (sz(st) <= k) {
                cout << sum << endl;
                continue;
            }
            else {
                ll ans = 0;
                while (sz(st) > k) {
                    while (1) {
                        ll x = (*st.begin()).first;
                        int v = (*st.begin()).second;
                        while (children[v]+del[v] == 1) {
                        
                            if (v == i) break;
                            int p = par[v].first;
                            x += par[v].second;
                            children[v]--;
                            del[p] += del[v];
                            v = p;
                        }
                        if ((*st.begin()).second == v) break;
                        st.erase(st.begin());
                        st.insert(mp(x, v));
                    }
                    del[(*st.begin()).second]--;
                    st.erase(st.begin());
                }
                set <int> tmp;
                for (auto to : st) {
                    ans += to.first;
                    tmp.insert(to.second);
                }
                for (auto v : tmp) {
                    while (v != i) {
                        int p = par[v].first;
                        auto it = lower_bound(all(edges), mp(mp(min(v, p), max(v, p)), 0ll))-edges.begin();
                        if (!used[it]) {
                            ans += edges[it].second;
                            used[it] = 1;
                        }
                        v = p;
                    }
                }
                cout << ans << endl;
            }
        }
    }
    else if (k == 1) {
        dfs2(1);
        dfs3(1, longest[1].first, longest[1].second);
        for (int i = 1; i <= n; i++) {
            cout << ans_for[i] << endl;
        }
    }
    
    return 0;
}
