/**
* user:  mushkatin-6ef
* fname: Shirli
* lname: Mushkatin
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:40:48.266913
*/
﻿// weirdTree.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef pair<int, ll> pii;
typedef vector<pii> vp;
typedef vector<vp> vvp;

struct seg {
	vp a;
	int sz;

	void init(int n) {
		for (sz = 1; sz < n; sz <<= 1);
		a.resize(sz << 1, { n + 2, 0 });
	}

	void update(int i, ll v) {
		i += sz;
		a[i] = { i - sz, v };
		for (i >>= 1; i; i >>= 1) {
			if (a[2 * i].second >= a[2 * i + 1].second)
				a[i] = a[2 * i];
			else
				a[i] = a[2 * i + 1];
			//a[i] = max(a[2 * i], a[2 * i + 1]);
		}
	}

	pii query(int l, int r) {
		l += sz; r += sz;
		ll ans = 0;
		int ind = sz / 2 + 2;
		while (l <= r) {
			if (r % 2 == 0) {
				if (a[r].second > ans || (a[r].second == ans && a[r].first < ind)) {
					ans = a[r].second; ind = a[r].first;
				}
				r--;
			}
			if (l % 2 == 1) {
				if (a[l].second > ans || (a[l].second == ans && a[l].first < ind)) {
					ans = a[l].second; ind = a[l].first;
				}
				l++;
			}
			r >>= 1; l >>= 1;
		}
		return { ind, ans };
	}
};

struct seg_sum {
	vl a;
	int sz;

	void init(int n) {
		for (sz = 1; sz < n; sz <<= 1);
		a.resize(sz << 1, 0);
	}

	void update(int i, ll v) {
		i += sz;
		a[i] = v;
		for (i >>= 1; i; i >>= 1) {
			a[i] = a[2 * i] + a[2 * i + 1];
		}
	}

	ll query(int l, int r) {
		l += sz; r += sz;
		ll ans = 0;
		while (l <= r) {
			if (r % 2 == 0) {
				ans += a[r--];
			}
			if (l % 2 == 1) {
				ans += a[l++];
			}
			r >>= 1; l >>= 1;
		}
		return ans;
	}
};

seg sg;
seg_sum sum;


void initialise(int N, int Q, int h[]) {
	int n = N;
	sg.init(n + 1);
	sum.init(n + 1);
	for (int i = 1; i <= n; i++) {
		sg.update(i, h[i]);
		sum.update(i, h[i]);
	}
}

void cut(int l, int r, int k) {
	for (int i = 0; i < k; i++) {
		pii ans = sg.query(l, r);
		if (ans.second == 0)
			break;
		sg.update(ans.first, ans.second - 1);
		sum.update(ans.first, ans.second - 1);
	}
}

void magic(int i, int x) {
	sg.update(i, x);
	sum.update(i, x);
}

long long int inspect(int l, int r) {
	return sum.query(l, r);
}

