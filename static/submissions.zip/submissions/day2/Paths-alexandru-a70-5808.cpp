/**
* user:  alexandru-a70
* fname: Andrei
* lname: Alexandru
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:02:09.261368
*/
#include <bits/stdc++.h> //Andrei Alexandru a.k.a Sho
#define ll int
#define double long double
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define aint(a) (a).begin(), (a).end()
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 1000000007
#define PI 3.14159265359
#define INF 1000000005
#define LINF 1000000000000000005ll
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
ll n,k;
long long dp[1005][105];
vector<pair<ll,ll>>g[1005];
void dfs(ll node,ll par){
for(auto it : g[node]){
if(it.f!=par){
dfs(it.f,node);
for(ll s2=k;s2>=1;s2--)
{
for(ll s1=1;s1<=s2;s1++){
dp[node][s2]=max(dp[node][s2],dp[node][s2-s1]+dp[it.f][s1]+it.s);
}
}
}
}
}
int32_t main(){
cin>>n>>k;
for(ll i=1;i<n;i++)
{
ll x,y,z;
cin>>x>>y>>z;
g[x].pb(mp(y,z));
g[y].pb(mp(x,z));
}
dfs(1,0);
cout<<dp[1][k]<<endl;
}
/*
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/



