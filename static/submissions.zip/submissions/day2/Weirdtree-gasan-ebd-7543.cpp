/**
* user:  gasan-ebd
* fname: Luca Carol
* lname: Gasan
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:58:26.600565
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
const int lim=1005;
ll aib[lim];
ll v[lim];
int n;
void add(int poz,int val)
{
    if(val==-1 and v[poz]==0)
        return ;
    v[poz]+=val;
    for(;poz<=n;poz+=poz&-poz)
        aib[poz]+=val;
}
ll sum(int l,int r)
{
    ll s=0;
    for(;r;r-=r&-r)
        s+=aib[r];
    --l;
    for(;l;l-=l&-l)
        s-=aib[l];
    return s;
}
void initialise(int N, int Q, int h[]) {
	// Your code here.
	n=N;
    for(int i=1;i<=n;++i)
        add(i,h[i]);
}
struct copac
{
    int first;
    int second;
    bool operator<(const copac &other) const
    {
        return make_pair(first,-second)<make_pair(other.first,-other.second);
    };
};
void cut(int l, int r, int k) {
	// Your code here.
	if(k==0)
        return ;
    vector<copac> ord;
    ll overall=0;
    for(int i=l;i<=r;++i)
        ord.push_back({v[i],i}),
        overall+=v[i];
    if(overall<=k)
    {
        for(int i=l;i<=r;++i)
            add(i,-v[i]);
        return ;
    }
    sort(ord.begin(),ord.end());
    vector<copac> stud;
    vector<int> special;
    stud.push_back(ord.back());
    special.push_back(ord.back().second);
    ord.pop_back();
    while(!ord.empty())
    {
        ll zile=0;
        int last=0;
        if(!ord.empty())
            last=ord.back().first+1;
        for(copac c:stud)
            zile+=c.first-last;
        zile+=stud.size()-1;
        if(zile>=k)
            break;
        stud.push_back(ord.back());
        special.push_back(ord.back().second);
        ord.pop_back();
    }
    int st=0,dr=stud.back().first,med;
    if(!ord.empty())
        st=ord.back().first;
    while(st<dr)
    {
        med=(st+dr)>>1;
        ll zile=0;
        for(copac c:stud)
            zile+=c.first-med;
        zile+=stud.size()-1;
        if(zile<k)
            st=med+1;
        else dr=med;
    }
    int by_def=st;
    int zile=0;
    for(copac c:stud)
        zile+=c.first-st;
    sort(special.begin(),special.end());
    int rem=k-zile;
    for(int i=0;i<special.size();++i)
    {
        if(i<rem)
            add(special[i],st-1-v[special[i]]);
        else add(special[i],st-v[special[i]]);
    }
}
void magic(int i, int x) {
	// Your code here.
	int poz=i;
    add(poz,x-v[poz]);
}
long long int inspect(int l, int r) {
	// Your code here.
    return sum(l,r);
}
