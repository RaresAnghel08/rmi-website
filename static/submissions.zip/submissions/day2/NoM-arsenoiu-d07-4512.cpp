/**
* user:  arsenoiu-d07
* fname: Iulian George
* lname: Arsenoiu
* task:  NoM
* score: 9.0
* date:  2021-12-17 08:02:49.004268
*/
#include <bits/stdc++.h>

using namespace std;

int n,m;

int rez = 0;

int sol[100005];

int fr[100005];

void Back(int k)
{
    if(k>2*n)
    {
        ++rez;
        return;
    }
    for(int i=1;i<=2*n;i++)
    {
        if(fr[i])
        {
            continue;
        }
        sol[k] = i;
        bool ok = true;
        for(int j=k-m;j>=1;j-=m)
        {
            if(sol[j]==i+n || sol[j]==i-n)
            {
                ok = false;
            }
        }
        if(ok)
        {
            ++fr[i];
            Back(k+1);
            --fr[i];
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>n>>m;
    Back(1);
    cout<<rez<<'\n';
    return 0;
}
