/**
* user:  talipov-208
* fname: Islam Iliasovich
* lname: Talipov
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:39:29.817555
*/
#define _GLIBCXX_DEBUG

#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <algorithm>
#include <numeric>

#define AIDAR ASADULLIN
#define ll long long
#define all(v) v.begin(), v.end()

using namespace std;

const ll MOD = 1e9 + 7;
const int MAXN = 2000 + 1;
const int MAXK = 2000;


vector<pair<int, ll>> graph[MAXN];
ll dp[MAXN][MAXK];
int sz[MAXN];

int k;

void dfs(int v, int p) {
    int children = 0;
    for (auto e: graph[v]) {
        int u = e.first;
        ll c = e.second;
        if (u != p) {
            children++;
            dfs(u, v);
            sz[v] += sz[u];
        }
    }
    if (children == 0) sz[v]++;
    for (auto e: graph[v]) {
        int u = e.first;
        ll c = e.second;
        if (u == p) continue;
        for (int k1 = min(k, sz[v]); k1 >= 1; --k1) {
            for (int k2 = 1; k2 <= min({k, sz[u], k1}); ++k2) {
                dp[v][k1] = max(dp[v][k1], dp[v][k1 - k2] + (k2 != 0 ? c : 0) + dp[u][k2]);
            }
        }
    }
}


int f[MAXN];
ll cost[MAXN];

void sdfs(int v, int p) {
    f[v] = p;
    for (auto e: graph[v]) {
        int u = e.first;
        ll c = e.second;
        if (u != p) {
            cost[u] = c;
            sdfs(u, v);
        }
    }
}

vector<int> stup(int n) {
    vector<int> ans;
    for (int i = 0; i < n; ++i) {
        cost[i] = 0;
        sdfs(i, -1);
        int mx = 0;
        for (int mask = 1; mask < (1 << n); ++mask) {
            set<int> now;
            for (int j = 0; j < n; ++j) {
                if ((mask >> j) & 1) {
                    now.insert(j);
                }
            }
            if (now.size() != k) continue;
            int res = 0;
            set<int> used;
            while (now.size() > 0) {
                set<int> next;
                for (int v: now) {
                    if (!used.count(v))
                        res += cost[v];
                    used.insert(v);
                    if (f[v] != -1)
                        next.insert(f[v]);
                }
                now = next;
            }
            mx = max(mx, res);
        }
        cout << mx << " ";
        ans.push_back(mx);
    }
    return ans;
}

int main() {
    srand(time(0));
    cin.tie(0);
    ios::sync_with_stdio(false);
    int n;
    cin >> n >> k;
//    n = rand() % 10 + 1;
//    k = rand() % n;
//    cout << n << " " << k << "\n";
    for (int i = 1; i < n; ++i) {
        int x, y;
        ll c;
        cin >> x >> y >> c;
        --x, --y;
//        x = i;
//        y = rand() % x;
//        c = rand() % 10;
//        cout << x + 1 << " " << y + 1 << " " << c << "\n";
        graph[x].emplace_back(y, c);
        graph[y].emplace_back(x, c);
    }
    vector<int> my_ans;
    for (int i = 0; i < n; ++i) {
        for (int v = 0; v < n; ++v) {
            sz[v] = 0;
            for (int h = 0; h <= k; ++h) {
                dp[v][h] = 0;
            }
        }
        dfs(i, -1);
//        cout << dp[i][min(k, sz[i])] << " ";
        my_ans.push_back(dp[i][min(k, sz[i])]);
    }
//    cout << "\n";
    stup(n);
}