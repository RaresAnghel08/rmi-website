/**
* user:  lugli-eb4
* fname: Francesco
* lname: Lugli
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:13:58.913549
*/
#include<bits/stdc++.h>
#define mod 1000000007
using namespace std;
typedef long long ll;

ll fact(ll N)
{
	ll ans = 1;
	for (int i = 1; i <= N; i++)
	{
		ans *= i;
		ans %= mod;
	}
	return ans;
}

ll modpow(ll b, ll e)
{
	if (e == 0) return 1;
	ll t = modpow(b, e/2);
	return ((t*t)%mod * (e%2 ? b : 1))%mod;
}

ll choose(ll n, ll k)
{
	ll num = fact(n);
	ll den = (fact(k) * fact(n-k))%mod;
	return (num * modpow(den, mod-2))%mod;
}

int main()
{
	ll N, M;	
	cin >> N >> M;

	vector < ll > cap;
	ll ctrl = 0;
	for (int i = 0; i < (2*N)%M; i++)
	{
		cap.push_back(N/M+1);
		ctrl += ((2*N)/M)+1;
	}
	for (int i = (2*N)%M; i < M; i++)
	{
		cap.push_back(N/M);
		ctrl += (2*N)/M;
	}
	assert(ctrl == 2*N);

	vector < vector < ll > > dp(M+1, vector < ll > (N+1, 0));
	dp[M][0] = 1;

	for (int i = M-1; i >= 0; i--)
	{
		for (ll b = 0; b <= N; b++)
		{
			cout << i << " " << b << "!!\n";
			for (int u = 0; u <= min(b, cap[i]); u++)
			{
				ll nb = b + cap[i] - 2 * u;
				if (nb > N) continue;
				ll nv = (dp[i+1][nb] * choose(cap[i], u))%mod;
				dp[i][b] += nv;
				dp[i][b] %= mod;
			}
		}
	}
	ll ans = dp[0][0];
	cout << ans << "\n";
	ans *= fact(N);
	ans %= mod,
	ans *= modpow(2, N);
	ans %= mod;
	cout << ans << "\n";
}
