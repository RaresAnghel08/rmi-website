/**
* user:  bartoli-386
* fname: Davide
* lname: Bartoli
* task:  Paths
* score: 19.0
* date:  2021-12-17 09:18:47.480735
*/
#pragma GCC optimize("O3")
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define pb push_back
#define int ll
int N,K;
vector<pair<int,int> >v[100010];
int ans[2009][2009];
int res[2009];
void calc(int pos,int prec){
    for(auto [x,y]:v[pos]){
        if(x==prec)continue;

        calc(x,pos);
        for(int i=K;i>=0;i--){
            for(int j=i;j>=0;j--){
                ans[pos][i]=max(ans[pos][i],ans[pos][i-j]+ans[x][j]+(j>0)*y);
            }
        }
    }
}
void ricalcola(int pos,int prec){
    fill(ans[pos],ans[pos]+K+2,0);

    for(auto [x,y]:v[pos]){
        if(x==prec)continue;
        for(int i=K;i>=0;i--){
            for(int j=i;j>=0;j--){
                ans[pos][i]=max(ans[pos][i],ans[pos][i-j]+ans[x][j]+(j>0)*y);
            }
        }
    }
}
void calc1(int pos,int prec){
    res[pos]=ans[pos][K];

    for(auto [x,y]:v[pos]){
        if(x==prec)continue;

        ricalcola(pos,x);
        ricalcola(x,-1);

        calc1(x,pos);
    }
    ricalcola(pos,prec);
}
signed main() {
    //ios_base::sync_with_stdio(0);
    //cin.tie(0);
    cin>>N>>K;
    for(int i=0;i<N-1;i++){
        int a,b,c;
        cin>>a>>b>>c;
        v[a].pb({b,c});
        v[b].pb({a,c});
    }
    calc(1,0);
    calc1(1,0);
    for(int i=1;i<=N;i++){
        cout<<res[i]<<'\n';
    }
    //calc(1,0);
    //for(int i=1;i<=N;i++){
    //    cout<<calc(i,K);
    //}
}

