/**
* user:  metehau-bba
* fname: Luca
* lname: Metehau
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:56:58.212003
*/
#include <iostream>
#pragma GCC optimize("Ofast")

using namespace std;

const int MOD = (int)1e9 + 7;

int n, m;
int ans;

int f[4005], invf[4005];
int v[10];

int lgput(int n, int p) {
  int ans = 1, x = n;

  while(p) {
    if(p & 1)
      ans = 1LL * ans * x % MOD;
    x = 1LL * x * x % MOD;
    p >>= 1;
  }

  return ans;
}

void bkt(int niv) {
  if(niv == 2 * n + 1) {
    bool ok = 1;
    for(int i = 1; i <= 2 * n && ok; i++) {
      for(int j = i + 1; j <= 2 * n && ok; j++) {
        if(v[i] == v[j])
          ok &= ((j - i) % m != 0);
      }
    }
    ans += ok;
    return;
  }

  for(int i = 1; i <= n; i++) {
    if(f[i] < 2) {
      f[i]++;
      v[niv] = i;
      bkt(niv + 1);
      f[i]--;
    }
  }
}

int main() {
  cin >> n >> m;

  bkt(1);

  cout << ans;
  return 0;
}
