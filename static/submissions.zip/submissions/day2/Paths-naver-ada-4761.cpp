/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  Paths
* score: 56.0
* date:  2021-12-17 08:31:15.714336
*/
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
#include <bits/stdc++.h>
typedef long long ll;
#define endl '\n'
using namespace std;
using namespace __gnu_pbds;
template<class T>using ordered_set = tree<T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;
const int N=200010;
const ll mod=1000000007;
int n,k;
vector<pair<int,ll> >g[N];
ll d[N];
int go[N];
ll val[N];
void dfs(int v,int pr){
    d[v]=0ll;
    go[v]=v;
    for (auto cur:g[v]){
        int to=cur.first;
        ll c=cur.second;
        if (to==pr) continue;
        dfs(to,v);
        val[go[to]]+=c;
        if (d[v]<d[to]+c){
            d[v]=d[to]+c;
            go[v]=go[to];
        }
    }
}
ll SUM=0ll;
ordered_set<pair<ll,int> >st;
ll ans[N];
void upd(int v,ll x){
    pair<ll,int>cur={val[v],v};
    if (st.order_of_key(cur)>=n-k){
        SUM-=val[v];

        SUM+=(*st.find_by_order(n-k-1)).first;
    }
    st.erase({val[v],v});
    val[v]+=x;
    st.insert({val[v],v});
    cur={val[v],v};
    if (st.order_of_key(cur)>=n-k){
        SUM+=val[v];
        SUM-=(*st.find_by_order(n-k-1)).first;
    }
}
void dfs1(int v,int pr){
    ans[v]=SUM;
//    for (auto cur:st) cout<<cur.first<<" "<<cur.second<<endl;
    set<pair<ll,int> >e;
    e.insert({0,v});
    for (auto cur:g[v]){
        int to=cur.first;
        ll c=cur.second;
        e.insert({d[to]+c,go[to]});
    }
    for (auto cur:g[v]){
        int to=cur.first;
        ll c=cur.second;
        if (to==pr) continue;
        e.erase({d[to]+c,go[to]});
        ll d_v=(*e.rbegin()).first;
        int go_v=(*e.rbegin()).second;
        ll d_to=d[to];
        int go_to=go[to];
        if (d_to<d_v+c){
            d_to=d_v+c;
            go_to=go_v;
        }

        upd(go[to],-c);

        upd(go_v,c);

        swap(d_v,d[v]);
        swap(d_to,d[to]);
        swap(go_v,go[v]);
        swap(go_to,go[to]);
        dfs1(to,v);
        swap(go_to,go[to]);
        swap(go_v,go[v]);
        swap(d_to,d[to]);
        swap(d_v,d[v]);
        upd(go_v,-c);
        upd(go[to],c);
        e.insert({d[to]+c,go[to]});
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin>>n>>k;
    ll sum=0ll;
    for (int i=1;i<n;i++){
        int a,b,c;cin>>a>>b>>c;
        sum+=c;
        g[a].push_back({b,c});
        g[b].push_back({a,c});
    }
    if (n==k){
        cout<<sum<<endl;
        return 0;

    }
    for (int i=1;i<=n;i++) val[i]=0ll;

    dfs(1,0);
    for (int i=1;i<=n;i++){
        st.insert({val[i],i});
    }
    SUM=0ll;

    for (int i=1;i<=n;i++){
        pair<ll,int>cur={val[i],i};
        if (st.order_of_key(cur)>=n-k){
            SUM+=val[i];
        }
    }
    dfs1(1,0);
    for (int i=1;i<=n;i++) cout<<ans[i]<<endl;
    return 0;
}
