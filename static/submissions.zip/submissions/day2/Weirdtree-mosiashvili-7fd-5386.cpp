/**
* user:  mosiashvili-7fd
* fname: Luka
* lname: Mosiashvili
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 09:26:20.222180
*/
#include<bits/stdc++.h>
#include "weirdtree.h"
using namespace std;
long long a,b,c,d,e,i,j,ii,jj,zx,xc,f[300009],seg[1200009],segmx[1200009],segmx2[1200009],za,l,r,z,zz,ZZ;
void upd(long long rr){
	if(rr==0) return;
	seg[rr]=seg[rr*2]+seg[rr*2+1];
	if(segmx[rr*2]>=segmx[rr*2+1]){
		segmx[rr]=segmx[rr*2];segmx2[rr]=segmx2[rr*2];
	}else{
		segmx[rr]=segmx[rr*2+1];segmx2[rr]=segmx2[rr*2+1];
	}
	upd(rr/2);
}
void read(long long q, long long w, long long rr){
	if(q>r||w<l) return;
	if(q>=l&&w<=r){
		z+=seg[rr];
		if(zz<segmx[rr]){
			zz=segmx[rr];ZZ=segmx2[rr];
		}else{
			if(zz==segmx[rr]&&ZZ>segmx2[rr]){
				zz=segmx[rr];ZZ=segmx2[rr];
			}
		}
		return;
	}
	read(q,(q+w)/2,rr*2);
	read((q+w)/2+1,w,rr*2+1);
}
void initialise(int NN, int QQ, int Hh[]) {
	a=NN;
	for(i=1; i<=a; i++){
		f[i]=Hh[i];
	}
	za=1;
	while(za<a) za*=2;
	for(i=1; i<=a; i++){
		seg[za+i-1]=f[i];segmx[za+i-1]=f[i];segmx2[za+i-1]=i;
	}
	for(i=za-1; i>=1; i--){
		seg[i]=seg[i*2]+seg[i*2+1];
		if(segmx[i*2]>=segmx[i*2+1]){
			segmx[i]=segmx[i*2];segmx2[i]=segmx2[i*2];
		}else{
			segmx[i]=segmx[i*2+1];segmx2[i]=segmx2[i*2+1];
		}
	}
}
void cut(int Ll, int Rr, int Kk) {
	if(Kk==0) return;
	l=Ll;r=Rr;z=0;zz=0;ZZ=a+1;
	read(1,za,1);
	//cout<<"cut: "<<zz<<" "<<ZZ<<"\n";
	if(zz==0) return;
	c=ZZ;d=zz-1;
	seg[za+c-1]=d;segmx[za+c-1]=d;segmx2[za+c-1]=c;
	upd((za+c-1)/2);
}
void magic(int Ii, int Xx) {
	c=Ii;d=Xx;
	/*l=1;r=1;z=0;
	read(1,za,1);
	cout<<"magic "<<c<<" "<<z<<"\n";*/
	seg[za+c-1]=d;segmx[za+c-1]=d;segmx2[za+c-1]=c;
	upd((za+c-1)/2);
}
long long int inspect(int Ll, int Rr) {
	l=Ll;r=Rr;z=0;zz=0;ZZ=a+1;
	read(1,za,1);
	return z;
}
