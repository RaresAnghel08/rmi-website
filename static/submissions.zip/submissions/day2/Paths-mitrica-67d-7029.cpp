/**
* user:  mitrica-67d
* fname: Alessia Georgiana Gabriela
* lname: Mitrică
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:32:44.853708
*/
#include <iostream>
#include<queue>
#include<vector>
#include<algorithm>
#define NMAX 1001
using namespace std;
int n,k;
bool viz[NMAX],ok[NMAX];
long long d[NMAX];
int costuri[NMAX][NMAX];
int fr[1001][1001],rad;
long long costt,nr;
vector<int>v[NMAX];
struct elem
{
    int d,nod;
}dist[1001];
bool cmp(elem x,elem y)
{
    return x.d<y.d;
}
void dfs(int k)
{
    viz[k]=1;
    for(int i=0;i<v[k].size();i++)
    {
        int nod=v[k][i];
        int cost=costuri[nod][k];
        if(!viz[nod])
           {
               d[nod]=d[k]+cost;
               viz[nod]=1;
               ok[k]=1;
               dfs(nod);
           }

    }
}
void dfs2(int k)
{
    viz[k]=1;
    for(int i=0;i<v[k].size();i++)
    {
        int nod=v[k][i];
        if(!viz[i])
        {
            viz[i]=1;
            fr[nod][k]++;
            fr[k][nod]++;
            dfs2(nod);
        }
    }
}
int x,y,cost;

void resetareb(bool *v)
{
    for(int i=1;i<=n;i++)
        v[i]=0;
}
int main()
{
    cin>>n>>k;
    for(int i=1;i<n;i++)
    {
        cin>>x>>y>>cost;
        v[x].push_back(y);
        v[y].push_back(x);
        costuri[x][y]=costuri[y][x]=cost;
    }
    for(rad=1;rad<=n;rad++)
    {
        costt=0;
        nr=0;
        dfs(rad);
        for(int i=1;i<=n;i++)
          {
              if(!ok[i])
           {
               dist[++nr].d=d[i];
                //if(costt<d[i])
                  //  costt=d[i];

               dist[nr].nod=i;
           }
           d[i]=0;
          }
      sort(dist+1,dist+nr+1,cmp);

      for(int i=nr;i>=nr-k+1;i--)
      {
        costt+=dist[i].d;
        resetareb(viz);
        dfs2(dist[i].nod);

      }
      for(int i=nr;i>=nr-k+1;i--)
      {
          int nod=dist[i].nod;
          int minn=10000001;
          for(int j=0;j<v[nod].size();j++)
          {
              int nod1=v[nod][j];
              if(fr[nod][nod1]>=2)
              {
                  fr[nod][nod1]--;
                  fr[nod1][nod]--;
                  costt-=costuri[nod][nod1];
              }
          }
      }

      cout<<costt<<"\n";
      resetareb(ok);
      resetareb(viz);
      for(int i=1;i<=n;i++)
      {
          dist[i].d=dist[i].nod=0;
      }
      for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
           fr[i][j]=0;
    }
    return 0;
}
