/**
* user:  linhart-f5e
* fname: Yoav
* lname: Linhart
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:36:53.850618
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <queue>
#include <map>

#define upmin(a, b) if(a > b) a = b
#define upmax(a, b) if(a < b) a = b
#define pr(x) cout << x << endl
#define wpr(x) cout << #x << ": " << x << endl
#define spr(x) cout << x << " "
#define wspr(x) cout << #x << ": " << x << " "
#define prv(x) for(auto it : x) cout << it << " "; cout << endl
#define wprv(x) cout << #x << ": " << endl; for(auto it : x) cout << it << " "; cout << endl
#define wprvv(x) cout << #x << ": " << endl; for(auto it : x) { for(auto it2 : it) cout << it2 << " "; cout << endl;}

#define rep(i, s, e) for(ll i = s; i < e; i++)
#define repr(i, s, e) for(ll i = e - (ll)1; i >= s; i--)



using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vvvll = vector<vvll>;
using pll = pair<ll, ll>;
using vpll = vector<pll>;
using vvpll = vector<vpll>;
using vb = vector<bool>;
using vvb = vector<vb>;
using vi = vector<int>;

/*

Solution:

dp[i][j] = number of options to fill first i rows with (at least) j bad pairs.

We only need to choose the order of each pair
*/

const ll mod = 1e9 + 7;
const ll maxn = 1e5;
ll n, m;
ll rnum;
vvll dp;
vll f, finv;

ll powmod(ll a, ll b) {
	ll res = 1;
	while (b) {
		if (b & 1) res = (res * a) % mod;
		a = (a * a) % mod;
		b >>= 1;

	}
	return res;
}

ll inv(ll a) {
	return powmod(a, mod - 2);
}


void gen()
{
	f.resize(maxn, 1);
	rep(i, 2, maxn) {
		f[i] = (i * f[i - 1]) % mod;
	}
	finv.resize(maxn, 1);
	rep(i, 1, maxn) {
		finv[i] = (finv[i-1] * inv(i)) % mod;
	}
}


ll C(ll n, ll k) {
	if (n < 0 || k < 0 || k > n) return 0;
	if (n == 0 || k == 0) return 1;
	ll ret = (f[n] * finv[k]) % mod;
	ret = (ret * finv[n - k]) % mod;
	return ret;
}

/*
How many options to badnum pairs of bad in row of length len
*/
ll calc_bad(ll len, ll badnum)
{
	if (badnum * 2 > len) return 0;
	
	ll ret = C(len, badnum * 2); // choose places
	ret = (ret * f[badnum * 2]) % mod; // order everything
	//ret = (ret * inv(powmod(2, badnum))) % mod; // order in pairs doesn't matter

	return ret;
}


void solve()
{
	cin >> n >> m;
	vll rows(m);
	ll left = (2*n) % m;
	if (left == 0) left -= m;
	rep(i, 0, m) {
		rows[i] = (2*n) / m;
		if (left > i) rows[i]++;
		
	}
	//wprv(rows);
	dp.resize(m+1, vll(n+1, 0));
	dp[0][0] = 1;
	rep(i, 1, m+1) {
		rep(j, 0, n+1) {
			rep(k, 0, j + 1) { // how many bad pairs are in the current one
				dp[i][j] += (dp[i - 1][j - k] * calc_bad(rows[i-1], k)) % mod;
				dp[i][j] %= mod;
			}
		}
	}
	ll ans = 0;
	rep(j, 0, n + 1) {
		ll v = dp[m][j];
		v = (v * C(n, j)) % mod; // choose the pairs
		v = (v * f[j]) % mod; // order the pairs
		//v = (v * powmod(2, j)) % mod; // order IN pairs
		v = (v * f[2 * n - 2 * j])%mod; // order the other people
		
		//wpr(j);
		//wpr(v);
		if (j % 2 == 0) {
			ans = (ans + v) % mod;
		}
		else {
			ans = (ans - v + mod) % mod;
		}
	}
	//wprvv(dp);
	pr(ans);
}


int main()
{
	gen();
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	solve();
}


/*

5 2

4 3


*/