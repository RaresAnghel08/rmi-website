/**
* user:  kryvoviaz-45e
* fname: Illia
* lname: Kryvoviaz
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:09:02.977359
*/
#include <bits/stdc++.h>

using namespace std;

int n, m;
vector<int> a;
int was[1010];
int ans = 0;
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= 2*n; i++)a.push_back(i);
    do {
        for (int i = 1; i <= n; i++)was[i] = 0;
        bool ok = true;
        for (int i = 0; i < 2 * n; i++) {
            int num = a[i] - (a[i] > n ? n : 0);

            if (was[num] == 0)was[num] = i;
            else {
                if ((i - was[num]) % m != 0) {
                    ok = false;
                    break;
                }
            }
        }
        if (ok)ans++;
    } while (next_permutation(a.begin(), a.end()));
    cout << ans;
}
