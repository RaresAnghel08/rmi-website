/**
* user:  boaca-fbc
* fname: Andrei
* lname: Boaca
* task:  Paths
* score: 19.0
* date:  2021-12-17 07:25:57.548800
*/
#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef pair<ll,ll> pll;
ll n,k,weight[100005],auxw[100005],par[100005],topar[100005],ans;
vector<pll> muchii[100005];
ll bestnode=0;
ll maxim=-1;
void dfs(ll nod,ll dist)
{
    if(dist>maxim)
    {
        maxim=dist;
        bestnode=nod;
    }
    for(auto i:muchii[nod])
    {
        ll fiu=i.first;
        ll cost=weight[i.second];
        if(fiu!=par[nod])
        {
            par[fiu]=nod;
            topar[fiu]=i.second;
            dfs(fiu,dist+cost);
        }
    }
}
void calc(int root)
{
    ll need=k;
    while(need--)
    {
        bestnode=0;
        maxim=-1;
        par[root]=0;
        topar[root]=0;
        dfs(root,0);
        if(maxim==0)
            return;
        ans+=maxim;
        while(par[bestnode]!=0)
        {
            ll p=par[bestnode];
            ll index=topar[bestnode];
            weight[index]=0;
            bestnode=p;
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin>>n>>k;
    for(int i=1;i<n;i++)
    {
        ll a,b,c;
        cin>>a>>b>>c;
        muchii[a].push_back({b,i});
        muchii[b].push_back({a,i});
        weight[i]=auxw[i]=c;
    }
    for(int root=1;root<=n;root++)
    {
        for(int i=1;i<n;i++)
            weight[i]=auxw[i];
        ans=0;
        calc(root);
        cout<<ans<<'\n';
    }
    return 0;
}
