/**
* user:  mushkatin-6ef
* fname: Shirli
* lname: Mushkatin
* task:  Paths
* score: 19.0
* date:  2021-12-17 09:08:05.277058
*/
﻿// paths.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef pair<int, ll> pii;
typedef vector<pii> vp;
typedef vector<vp> vvp;

void dfs(vvl& dis, vi& visited, vp& maxi, vi& parent, int v, int n) {
    visited[v] = 1;
    maxi[v] = { v, 0 };
    for (int i = 1; i <= n; i++) {
        if (dis[v][i] == -1)
            continue;
        int u = i;
        ll w = dis[v][i];
        if (visited[u]) {
            parent[v] = u;
            continue;
        }
        dfs(dis, visited, maxi, parent, u, n);
        if (maxi[v].second < maxi[u].second + w) {
            maxi[v].second = maxi[u].second + w;
            maxi[v].first = maxi[u].first;
        }
    }
}

void erase(vvl& dis, int v, vi& parent) {
    int p = parent[v];
    if (p == -1)
        return;
    dis[v][p] = dis[p][v] = 0;
    erase(dis, p, parent);
}

int main()
{
    int n, k; cin >> n >> k;
    //vvp adj(n + 1);
    vvl dis(n + 1, vl(n + 1, -1));
    for (int i = 0; i < n - 1; i++) {
        int u, v, w; cin >> u >> v >> w;
        dis[u][v] = w;
        dis[v][u] = w;
    }
    for (int root = 1; root <= n; root++) {
        vp maxi(n + 1);
        vi parent(n + 1, -1);
        vi visited(n + 1);
        vvl cur_dis = dis;
        dfs(cur_dis, visited, maxi, parent, root, n);
        ll ans = 0;
        for (int i = 0; i < k; i++) {
            ans += maxi[root].second;
            if (i == k - 1) continue;
            erase(cur_dis, maxi[root].first, parent);
            for (int j = 1; j <= n; j++) visited[j] = 0;
            dfs(cur_dis, visited, maxi, parent, root, n);
        }
        cout << ans << endl;
    }
}


