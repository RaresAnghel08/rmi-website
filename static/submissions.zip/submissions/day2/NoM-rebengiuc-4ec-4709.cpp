/**
* user:  rebengiuc-4ec
* fname: Mircea Maxim
* lname: Rebengiuc
* task:  NoM
* score: 9.0
* date:  2021-12-17 08:26:04.701663
*/
#include <stdio.h>
#include <ctype.h>

#define MAXN 5// nice
#define NIL  -1

int next[1 + 2 * MAXN];
int perm[2 * MAXN];
int sp;
int n, m;
int num_good;

void permute(){
	int i, isok, aux;

	if( next[0] == NIL ){
		isok = 1;
		for( i = 0 ; i < 2 * n ; i += 2 )
			if( (perm[i] - perm[i + 1]) % m == 0 )
				isok = 0;

		num_good += isok;
	}

	for( i = 0 ; next[i] != NIL ; i = next[i] ){
		// we choose i for this position => we remove it from the list
		aux = next[i];
		next[i] = next[aux];
		perm[sp++] = aux;
		permute();
		sp--;
		next[i] = aux;
	}
}

static inline int fgetint(){
	int n = 0, ch;

	while( !isdigit(ch = fgetc(stdin)) );
	do
	  n = n * 10 + ch - '0';
	while( isdigit(ch = fgetc(stdin)) );

	return n;
}

int main(){
	int i;

	n = fgetint();
	m = fgetint();

	for( i = 0 ; i < 2 * n ; i++ )
		next[i] = i + 1;
	next[2 * n] = NIL;

  num_good = 0;
	permute();

	printf("%d\n", num_good);

	return 0;
}