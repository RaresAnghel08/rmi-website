/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Paths
* score: 0.0
* date:  2021-12-17 07:40:06.832059
*/
#include <bits/stdc++.h>
using namespace std;
vector<int> v[2001];
int dist[2001];
int tata[2001];
int cost[2001][2001];
void dfs(int nod,int papa)
{
    tata[nod]=papa;
    for(auto it:v[nod])
        if(it!=papa)
        {
            dist[it]=dist[nod]+cost[nod][it];
            dfs(it,nod);
        }
}
void dfsmod(int nod,int papa,int val)
{
    dist[nod]-=val;
    for(auto it:v[nod])
        if(it!=papa)
            dfsmod(it,nod,val);
}
void up(int nod,int venit,int val)
{
    dist[nod]=0;
    if(tata[nod]==0)
        return;
    for(auto it:v[nod])
        if(it!=tata[nod]&&it!=venit)
            dfsmod(it,nod,val);
    if(dist[tata[nod]])
        up(tata[nod],nod,val-cost[nod][tata[nod]]);
}
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    int n,k,i,a,b,c,j;
    cin>>n>>k;
    for(i=1; i<n; i++)
    {
        cin>>a>>b>>c;
        v[a].push_back(b);
        v[b].push_back(a);
        cost[a][b]=cost[b][a]=c;
    }
    long long sum;
    int ind;
    for(i=1; i<=n; i++) ///radacina
    {
        sum=0;
        int ck=k;
        dist[i]=0;
        dfs(i,0);
        while(k)///iau cel mai bun si updatez
        {
            ind=0;
            for(j=1; j<=n; j++)
                if(dist[j]>dist[ind])
                    ind=j;
            /*for(j=1; j<=n; j++)
                cout<<dist[j]<<" ";
            cout<<'\n';*/
            sum+=dist[ind];
            for(auto it:v[ind])
                if(it!=tata[ind])
                    dfsmod(it,ind,dist[ind]);
            up(tata[ind],ind,dist[ind]-cost[ind][tata[ind]]);
            dist[ind]=0;
            k--;
        }
        cout<<sum<<'\n';
        ///cout<<'\n';
        k=ck;
    }
    return 0;
}
