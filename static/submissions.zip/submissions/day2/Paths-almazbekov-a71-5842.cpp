/**
* user:  almazbekov-a71
* fname: Beksultan
* lname: Almazbekov
* task:  Paths
* score: 19.0
* date:  2021-12-17 10:05:06.526122
*/
#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define fr first
#define sc second
#define OK puts("OK");
#define endi puts("");
#define ret return
#define all(s) s.begin(),s.end()
#define allr(s) s.rbegin(),s.rend()
#define ll long long
#define pii pair<int,int> 
const int N = 1e5+12;
vector <pii> g[N];
vector <ll> v[N];
bool used[N];
ll as[N];
void dffs(int x,int p,ll c){
	as[x] = c;
	
	for (auto to: g[x]){
		if (to.fr == p)continue;
		
		if (used[x] == 0 || used[to.fr] == 0)
			dffs(to.fr,x,c+to.sc);
		else dffs(to.fr,x,c);
		
	}
}
vector <int> vv;

void dfss(int x,int p,ll c){
	vv.pb(x);
	if (x == c){
		for(auto f: vv)used[f] = 1;
	}
	
	for (auto to: g[x]){
		if (to.fr == p)continue;
		
		dfss(to.fr,x,c);
		
	}
	vv.pop_back();
}

main(){
	int n,i,k;
	scanf("%d%d",&n,&k);
	for (i=1;i<n;++i){
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		g[x].pb({y,z});
		g[y].pb({x,z});
	}
	ll sum,z;
	for (int x=1;x <= n;++x){
		
		z = k;
		sum = 0;
		while (z--){
			ll mx = 0;
			dffs(x,0,0);
			
			for (i=1;i<=n;++i)
				mx =  max(mx,as[i]);
			for (i=1;i<=n;++i)
				if (mx == as[i])
					 break;
			dfss(x,0,i);
			sum += mx;
		}
		printf("%lld\n",sum);
		for (i=1;i<=n;++i)used[i] = 0;
		
	}
	
	
	
	
	
}
