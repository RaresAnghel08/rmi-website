/**
* user:  kitanovski-9bd
* fname: Teo 
* lname: Kitanovski
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:59:03.477317
*/
#include <bits/stdc++.h>
#ifndef LOCAL_DEBUG
    #include "weirdtree.h"
#endif // LOCAL_DEBUG

typedef long long ll;

#define MS(x,y) memset((x), (y), sizeof((x)))
#define pb push_back
#define MN 1000000007

using namespace std;

ll n,q,niza[300001];

void initialise(int n2, int q2, int niza2[]) {
    n=n2;q=q2;
    for (ll i = 0; i<n; i++) niza[i] = niza2[i];
}

bool comp (pair<int,int> a, pair<int,int> b) {
    if (a.first == b.first) return a.second < b.second;

    return a.first > b.first;
}

void cut(int l,int r, int k) {
    l--; r--;

    if (r-l == 0) {
        niza[l] = max((ll)0,niza[l]-k);
        return;
    }

    vector<pair<ll,ll>> v;

    for (ll i = l; i<=r; i++) v.pb({niza[i],i});

    sort(v.begin(), v.end(), comp);

    ll zbir = v[0].first, gol = v.size();
    ll redKraj = gol-1, minRed = v[0].first;

    for (ll i = 1; i<gol; i++) {
        ll pred = i;

        if (zbir - (pred*v[i].first) >= k) { redKraj = i-1; break; }

        minRed = min(minRed,v[i].first);
        zbir += v[i].first;
    }

    for (ll i = 0; i<=redKraj; i++) {
        if (v[i].first-minRed > k) {
            v[i].first -= k;
            k = 0;
            redKraj = i;
            break;
        }

        k -= v[i].first-minRed;
        v[i].first = minRed;
    }

    sort(v.begin(),v.end(),comp);

    gol = redKraj+1;

    for (ll i = 0; i<redKraj; i++) v[i].first -= k/gol;
    for (ll i = 0; i<(k%gol); i++) v[i].first--;

    for (ll i = 0; i<v.size(); i++) niza[v[i].second] = max((ll)0,v[i].first);
}

void magic(int i, int x) {
    i--;

    niza[i] = x;
}

ll inspect (int l, int r) {
    l--; r--;

    ll res = 0;
    for (ll i = l; i<=r; i++) res+= niza[i];

    return res;
}

#ifdef LOCAL_DEBUG
int main() {
    #ifdef LOCAL_DEBUG
        fstream cin("in.txt");
    #endif // LOCAL_DEBUG

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    ll n3,q3;
    cin>>n3>>q3;

    int niza3[n3];
    for (ll i = 0; i<n3; i++) cin>>niza3[i];

    initialise(n3,q3,niza3);

    for (ll i = 0; i<q3; i++) {
        ll t;
        cin>>t;

        if (t == 1) {
            ll a,b,c;
            cin>>a>>b>>c;
            cut(a,b,c);
        } else if (t == 2) {
            ll a,b;
            cin>>a>>b;
            magic(a,b);
        } else if (t == 3) {
            ll a,b;
            cin>>a>>b;
            for (int j = 0; j<n; j++) cout<<inspect(j+1,j+1)<<" ";
            cout<<endl;
            cout<<inspect(a,b)<<endl;
        }
    }
}
#endif
