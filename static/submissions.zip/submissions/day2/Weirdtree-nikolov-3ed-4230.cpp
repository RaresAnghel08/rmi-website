/**
* user:  nikolov-3ed
* fname: Zdravko Svetlozarov
* lname: Nikolov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 07:23:05.801314
*/
#include <bits/stdc++.h>

using namespace std;
int n;
vector<int>tree;
tree.push_back(0);
void initialise(int N, int Q, int h[])
{
    n=N;
    for(int i=1; i<=n; i++)
    {
        tree.push_back(h[i]);
    }
}
void cut(int l,int r,int k)
{
    for(int j=0; j<k; j++)
    {
        int maxi=0;
        int maxx=0;
        for(int i=l; i<=r; i++)
        {
            if(tree[i]>maxx)
            {
                maxx=tree[i];
                maxi=i;
            }
        }
        if(maxx>0)
        {
            tree[maxi]--;
        }
    }

}
void magic(int i, int x)
{
    tree[i]=x;
}
long long inspect(int l, int r)
{
    long long sum=0;
    for(int i=l;i<=r;i++)
    {
        sum+=(long long)(tree[i]);
    }
    return sum;
}
