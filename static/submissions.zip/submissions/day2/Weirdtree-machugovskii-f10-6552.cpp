/**
* user:  machugovskii-f10
* fname: Ivan
* lname: Machugovskii
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:00:06.603037
*/
#include "weirdtree.h"


#include <bits/stdc++.h>

using namespace std;

using ll = long long;


struct NodeInfo {
	int v;
	int vl;
	int vr;

	bool operator<(const NodeInfo& rhs) const {
		return vl < rhs.vl;
	}
};


struct ByWaterlineInfo {
	// int waterline;
	int total_above;
	int count_above;
	set<NodeInfo> nodes;

	// bool operator<(const ByWaterlineInfo& rhs) const {
	// 	return waterline < rhs.waterline;
	// }
};


class SegmentTreeBeats {
	vector<int> max_;
	vector<int> max2;
	vector<int> cntmax;
	vector<ll> sum;
	vector<int> mod;
	int n;

	void build(int v, int l, int r, const int* data) {
		mod[v] = 2000000000;
		if(r - l == 1) {
			max_[v] = data[l];
			max2[v] = -1;
			cntmax[v] = 1;
			sum[v] = data[l];
		} else {
			int m = (l + r) / 2;
			build(v * 2, l, m, data);
			build(v * 2 + 1, m, r, data);
			pull(v);
		}
	}

	void separate(int v, int vl, int vr, int l, int r, vector<NodeInfo>& nodes) {
		if(vl == l && vr == r) {
			nodes.emplace_back(NodeInfo{v, vl, vr});
		} else {
			push(v, vl, vr);
			int vm = (vl + vr) / 2;
			if(r <= vm) {
				separate(v * 2, vl, vm, l, r, nodes);
			} else if(l >= vm) {
				separate(v * 2 + 1, vm, vr, l, r, nodes);
			} else {
				separate(v * 2, vl, vm, l, vm, nodes);
				separate(v * 2 + 1, vm, vr, vm, r, nodes);
			}
		}
	}
	void separate(int l, int r, vector<NodeInfo>& nodes) {
		separate(1, 0, n, l, r, nodes);
	}


	void do_upd_min_eq(int v, int vl, int vr, int value) {
		// cerr << "do_upd_min_eq(" << v << " " << vl << " " << vr << " " << value << ")" << endl;
		if(value < max_[v]) {
			// cerr << max_[v] << " " << max2[v] << " " << value << endl;
			assert(value > max2[v]);
			sum[v] -= (ll)(max_[v] - value) * cntmax[v];
			max_[v] = value;
			mod[v] = value;

			v /= 2;
			while(v >= 1) {
				pull(v);
				v /= 2;
			}
		}
	}

	void reduce_first_n_maximums(int v, int vl, int vr, int value, int& cnt_zeroes) {
		// cerr << "reduce_first_n_maximums(" << v << " " << vl << " " << vr << " " << value << " " << cnt_zeroes << ")" << endl;
		if(cnt_zeroes == 0) {
			do_upd_min_eq(v, vl, vr, value + 1);
			return;
		}
		if(vr - vl == 1) {
			do_upd_min_eq(v, vl, vr, value);
			cnt_zeroes--;
			return;
		}

		push(v, vl, vr);

		int vm = (vl + vr) / 2;

		int cnt_max_left = max_[v * 2] == max_[v] ? cntmax[v * 2] : 0;
		if(cnt_max_left >= cnt_zeroes) {
			reduce_first_n_maximums(v * 2, vl, vm, value, cnt_zeroes);
			do_upd_min_eq(v * 2 + 1, vm, vr, value + 1);
		} else {
			do_upd_min_eq(v * 2, vl, vm, value);
			cnt_zeroes -= cnt_max_left;
			reduce_first_n_maximums(v * 2 + 1, vm, vr, value, cnt_zeroes);
		}
	}


	void pull(int v) {
		max_[v] = max(max_[v * 2], max_[v * 2 + 1]);
		cntmax[v] = (max_[v * 2] == max_[v] ? cntmax[v * 2] : 0) + (max_[v * 2 + 1] == max_[v] ? cntmax[v * 2 + 1] : 0);

		int arr[5] = {max_[v * 2], max_[v * 2 + 1], max2[v * 2], max2[v * 2 + 1], -1};
		sort(begin(arr), end(arr));
		auto it = unique(begin(arr), end(arr));
		max2[v] = *(it - 2);

		sum[v] = sum[v * 2] + sum[v * 2 + 1];
	}

	void push(int v, int vl, int vr) {
		if(mod[v] != 2000000000) {
			int vm = (vl + vr) / 2;
			do_upd_min_eq(v * 2, vl, vm, mod[v]);
			do_upd_min_eq(v * 2 + 1, vm, vr, mod[v]);
			mod[v] = 2000000000;
		}
	}


	ll get(int v, int vl, int vr, int l, int r) {
		assert(l < r);
		if(vl == l && vr == r) {
			return sum[v];
		} else {
			push(v, vl, vr);

			int vm = (vl + vr) / 2;
			if(r <= vm) {
				return get(v * 2, vl, vm, l, r);
			} else if(l >= vm) {
				return get(v * 2 + 1, vm, vr, l, r);
			} else {
				return get(v * 2, vl, vm, l, vm) + get(v * 2 + 1, vm, vr, vm, r);
			}
		}
	}

	void set(int v, int vl, int vr, int i, int x) {
		if(vr - vl == 1) {
			max_[v] = x;
			sum[v] = x;
		} else {
			push(v, vl, vr);

			int vm = (vl + vr) / 2;
			if(i < vm) {
				set(v * 2, vl, vm, i, x);
			} else {
				set(v * 2 + 1, vm, vr, i, x);
			}
			pull(v);
		}
	}


public:
	void init(int n_, const int* data) {
		n = n_;
		max_.resize(4 * n);
		max2.resize(4 * n);
		cntmax.resize(4 * n);
		sum.resize(4 * n);
		mod.resize(4 * n);
		build(1, 0, n, data);
	}


	void cut(int l, int r, int k) {
		vector<NodeInfo> nodes;
		separate(l, r, nodes);

		map<int, ByWaterlineInfo> by_waterline;

		auto add_node = [&](const NodeInfo& node) {
			int waterline = max2[node.v] + 1;
			by_waterline[waterline].nodes.emplace(node);
			by_waterline[waterline].total_above += (max_[node.v] - waterline) * cntmax[node.v];
			by_waterline[waterline].count_above += cntmax[node.v];
		};

		for(auto& node: nodes) {
			add_node(node);
		}

		while(by_waterline.rbegin()->first > 0 && by_waterline.rbegin()->second.total_above < k) {
			// cerr << "Current situation: ";
			for(auto& [waterline, info]: by_waterline) {
				// cerr << "waterline=" << waterline << ", info={" << endl;
				// cerr << "\ttotal = " << info.total_above << endl;
				// cerr << "\tcount = " << info.count_above << endl;
				// cerr << "\tnodes = {\n";
				for(auto& node: info.nodes) {
					// cerr << "\t\t" << node.v << " [" << node.vl << "; " << node.vr << ")" << endl;
				}
				// cerr << "\t}" << endl;
				// cerr << "}" << endl;
			}
			// cerr << endl;

			// Split leftmost node in hope to reduce the waterline
			int waterline = by_waterline.rbegin()->first;

			auto& info = by_waterline.rbegin()->second;

			auto it = info.nodes.begin();
			auto node = *it;
			info.nodes.erase(it);

			info.total_above -= (max_[node.v] - waterline) * cntmax[node.v];
			info.count_above -= cntmax[node.v];

			push(node.v, node.vl, node.vr);
			int vm = (node.vl + node.vr) / 2;
			add_node(NodeInfo{node.v * 2, node.vl, vm});
			add_node(NodeInfo{node.v * 2 + 1, vm, node.vr});

			if(info.nodes.empty()) {
				auto it = by_waterline.end();
				--it;
				by_waterline.erase(it);
			}
		}

		// cerr << "Current situation: ";
		for(auto& [waterline, info]: by_waterline) {
			// cerr << "waterline=" << waterline << ", info={" << endl;
			// cerr << "\ttotal = " << info.total_above << endl;
			// cerr << "\tcount = " << info.count_above << endl;
			// cerr << "\tnodes = {\n";
			for(auto& node: info.nodes) {
				// cerr << "\t\t" << node.v << " [" << node.vl << "; " << node.vr << ")" << endl;
			}
			// cerr << "\t}" << endl;
			// cerr << "}" << endl;
		}
		// cerr << endl;


		auto it = by_waterline.rbegin();
		int waterline = it->first;
		auto& info = it->second;

		k = min(k, info.total_above);


		vector<NodeInfo> nodes_by_max(info.nodes.begin(), info.nodes.end());
		sort(nodes_by_max.begin(), nodes_by_max.end(), [&](const NodeInfo& a, const NodeInfo& b) {
			return max_[a.v] == max_[b.v] ? a.vl < b.vl : max_[a.v] > max_[b.v];
		});

		int prefix_count = 0;
		for(int i = 0; i < nodes_by_max.size(); i++) {
			prefix_count += cntmax[nodes_by_max[i].v];
			int limit_h = max_[nodes_by_max[i].v] - (i == nodes_by_max.size() - 1 ? waterline : max_[nodes_by_max[i + 1].v]);
			int total_limit = limit_h * prefix_count;
			if(k > total_limit) {
				k -= total_limit;
			} else {
				int new_value = max_[nodes_by_max[i].v] - (k + prefix_count - 1) / prefix_count;
				int plus_one_boundary = k % prefix_count == 0 ? prefix_count : k % prefix_count;

				sort(nodes_by_max.begin(), nodes_by_max.begin() + i, [](const NodeInfo& a, const NodeInfo& b) {
					return a.vl < b.vl;
				});

				int pref_cnt = 0;

				for(int j = 0; j <= i; j++) {
					auto& node = nodes_by_max[j];

					if(pref_cnt >= plus_one_boundary) {
						do_upd_min_eq(node.v, node.vl, node.vr, new_value + 1);
					} else if(pref_cnt + cntmax[node.v] <= plus_one_boundary) {
						do_upd_min_eq(node.v, node.vl, node.vr, new_value);
					} else {
						int cnt_zeroes = plus_one_boundary - pref_cnt;
						// cerr << "node " << node.vl << ".." << node.vr << " " << new_value << "+?1 " << cnt_zeroes << endl;
						reduce_first_n_maximums(node.v, node.vl, node.vr, new_value, cnt_zeroes);
						// cerr << "??" << cnt_zeroes << endl;
						assert(cnt_zeroes == 0);
					}

					pref_cnt += cntmax[node.v];
				}

				// cerr << "yay. " << new_value << " / " << plus_one_boundary << endl;
				return;
			}
		}

		assert(false);
	}


	ll get(int l, int r) {
		return get(1, 0, n, l, r);
	}

	void set(int i, int x) {
		set(1, 0, n, i, x);
	}
};



SegmentTreeBeats st;


void initialise(int N, int Q, int h[]) {
	st.init(N, h + 1);
}

void cut(int l, int r, int k) {
	l--;

	st.cut(l, r, k);
	// cerr << "after cut: ";
	// for(int i = 0; i < 30; i++) cerr << st.get(i, i + 1) << " ";
	// cerr << endl;
}

void magic(int i, int x) {
	i--;
	st.set(i, x);
}

long long int inspect(int l, int r) {
	l--;
	return st.get(l, r);
}
