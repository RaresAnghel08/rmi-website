/**
* user:  bekkoyonov-7fa
* fname: Tengiz
* lname: Bekkoyonov
* task:  NoM
* score: 9.0
* date:  2021-12-17 08:40:55.514312
*/
#include <bits/stdc++.h>

using namespace std;
#define int long long


const int N = 2005;
const int P = 1e9 + 7;

int norm(int x) {
    if (x < 0) {
        x += P;
    }
    if (x >= P) {
        x -= P;
    }
    return x;
}

int fac[N + 1];

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    fac[0] = 1;
    for (int i = 1; i <= N; i++) {
        fac[i] = fac[i - 1] * i % P;
    }
    
    int n, m;
    cin >> n >> m;
    
    int cnt = 0;
    vector<int> p(2 * n);
    iota(p.begin(), p.end(), 0);
    
    int pos[2 * n];
    
    do {
        bool ok = true;
        for (int i = 0; i < 2 * n; i++) pos[p[i]] = i;
        for (int i = 0; i < 2 * n; i++) {
            if (p[i] >= n && (pos[p[i] - n] - i) % m == 0) {
                ok = false;
                break;
            }
        }
        cnt += ok;
    } while (next_permutation(p.begin(), p.end()));
    
    // int ans = cnt * fac[n] % P;
    
    cout << cnt << "\n";
    
    return 0;
}
