/**
* user:  tatarinova-7c8
* fname: Yuliia
* lname: Tatarinova
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:10:38.685671
*/
#include <bits/stdc++.h>

using namespace std;
vector<pair<long long, long long>> g[100005], g1[100005], g2[100005];

pair<long long, long long> dfs(long long v, long long p=-1)
{
    pair<long long, long long> ans;
    ans.first=0;
    ans.second=v;
    for(int i=0; i<g[v].size(); i++)
    {
        pair<long long, long long> to=g[v][i];
        if(to.first!=p)
        {

            pair<long long, long long> u = dfs(to.first, v);
            if(u.first+g[v][i].second>ans.first)
            {
                ans.first=u.first+g[v][i].second;
                ans.second = u.second;
            }
        }
    }
    return ans;
}

bool dfs1(long long v, long long h,  long long p=-1)
{
    bool f1=false;
    long long r=-1;
    for(int i=0; i<g[v].size(); i++)
    {
        pair<long long, long long> to=g[v][i];
        if(to.first!=p)
        {

            bool f =dfs1(to.first,h, v);
            if (f==true) {f1=true; g[v][i].second=0; }
        } else r=i;
    }

    if(h==v) f1=true;

    if(f1==true && r!=-1)
     {
         g[v][r].second=0;
     }


    return f1;
}
long long mas[100005];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    long long n,k;
    cin>>n>>k;
    long long x,y,c, a=0;
    for(int i=0; i<n-1; i++)
    {
        cin>>x>>y>>c;
        x--;
        y--;
        g1[x].push_back(make_pair(y,c));
        g1[y].push_back(make_pair(x, c));
        a+=c;

    }

    for(int step=0; step<n; step++)
    {
        for(int i=0; i<n; i++)
        {
            g[i].clear();
            for(int j=0; j<g1[i].size(); j++)
                g[i].push_back(g1[i][j]);
                mas[i]=i;
        }


        long long ans=0;
        for(int i=0; i<k; i++)
        {


            pair<long long, long long> to=dfs(mas[step]);
            ans+=to.first;
            bool f=dfs1(mas[step], to.second);

            for(int j=0; j<n; j++)
            {
                g2[j].clear();
                for(int h=0; h<g[j].size(); h++)
            {
                if(g[j][h].second==0)
                {
                    mas[g[j][h].first]=mas[j];
                }
            }
            }

            for(int j=0; j<n; j++)
                 for(int h=0; h<g[j].size(); h++)
            {
                if(mas[j]!=mas[g[j][h].first])
                {
                    g2[mas[j]].push_back(make_pair(mas[g[j][h].first], g[j][h].second));
                    //g2[mas[g[j][h].first]].push_back(make_pair(mas[j], g[j][h].second));
                }
            }

            for(int h=0; h<n; h++)
        {
            g[h].clear();
            for(int j=0; j<g2[h].size(); j++)
                g[h].push_back(g2[h][j]);

        }
       //  cout<<"to = "<< to.second<<'\n';
       // cout<<"---------\n";

          //  if(ans==a) break;
        }
        cout<<ans<<'\n';
    }
    return 0;
}
