/**
* user:  garkov-315
* fname: Velislav Petrov
* lname: Garkov
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:54:26.347865
*/
#include <iostream>
#include <vector>
using namespace std;
#define endl '\n'
const int MAXN=1e5+10;
struct Node {
    long long maxs;
    int ind;
};
vector <pair <int,long long> > v[MAXN];
Node tree[4*MAXN];
long long lazy[MAXN];
long long sum[MAXN];
int lef[MAXN], ri[MAXN], par[MAXN];
int lis[MAXN], br;
bool used[MAXN];
void build(int x) {
    used[x]=true;
    lef[x]=MAXN;
    ri[x]=-1;
    for (auto i:v[x]) {
        if (used[i.first]) continue;
        par[i.first]=x;
        sum[i.first]=sum[x]+i.second;
        build(i.first);
        lef[x]=min(lef[x],lef[i.first]);
        ri[x]=max(ri[x],ri[i.first]);
    }
    if (v[x].size()==1 && par[x]!=-1) {
        lis[br]=x;
        lef[x]=ri[x]=br;
        br++;
    }
}
void build_tree(int node, int l, int r) {
    lazy[node]=-1;
    if (l==r) {
        ///cout << sum[lis[l]] << ' ' << lis[l] << endl;
        tree[node].maxs=sum[lis[l]];
        tree[node].ind=lis[l];
        return;
    }
    int mid=(l+r)/2;
    build_tree(node*2,l,mid);
    build_tree(node*2+1,mid+1,r);
    if (tree[node*2].maxs>=tree[node*2+1].maxs) tree[node]=tree[node*2];
    else tree[node]=tree[node*2+1];
}
void push_lazy(int node, int l, int r) {
    if (lazy[node]==-1) return;
    if (l!=r) {
        tree[node*2].maxs-=lazy[node];
        tree[node*2+1].maxs-=lazy[node];
        lazy[node*2]+=lazy[node];
        lazy[node*2+1]+=lazy[node];
    }
    lazy[node]=-1;
}
void update_interv(int node, int l, int r, int ql, int qr, long long ch) {
    if (l>qr || r<ql) return;
    push_lazy(node,l,r);
    if (l>=ql && r<=qr) {
        if (tree[node].maxs!=0) {
            tree[node].maxs-=ch;
            if (lazy[node]==-1) lazy[node]=ch;
            else lazy[node]+=ch;
        }
        return;
    }
    int mid=(l+r)/2;
    update_interv(node*2,l,mid,ql,qr,ch);
    update_interv(node*2+1,mid+1,r,ql,qr,ch);
    ///cout << node << ' ' << l << ' ' << r << ' ' << tree[node*2].maxs << ' ' << tree[node*2+1].maxs << endl;
    if (tree[node*2].maxs>=tree[node*2+1].maxs) tree[node]=tree[node*2];
    else tree[node]=tree[node*2+1];
}
void update_path(int x, long long cur, int p) {
    if (par[x]==-1) return;
    ///cout << lef[x] << ' ' << ri[x] << ' ' << lef[p] << ' ' << ri[p] << ' ' << cur << endl;
    if (p!=-1) {
        if (lef[x]<lef[p]) update_interv(1,0,br-1,lef[x],lef[p]-1,cur);
        if (ri[x]>ri[p]) update_interv(1,0,br-1,ri[p]+1,ri[x],cur);
    } else update_interv(1,0,br-1,lef[x],ri[x],cur);
    ///cout << tree[1].maxs << ' ' << tree[1].ind << endl;
    cur-=(sum[x]-sum[par[x]]);
    update_path(par[x],cur,x);
    par[x]=-1;
}
int main () {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int n, k, a, b, c;
    cin >> n >> k;
    for (int i=0;i<n-1;i++) {
        cin >> a >> b >> c;
        v[a].push_back({b,c});
        v[b].push_back({a,c});
    }
    long long ans, cur;
    int maxind;
    for (int i=1;i<=n;i++) {
        ans=0;
        for (int j=1;j<=n;j++) used[j]=false;
        par[i]=-1;
        sum[i]=0;
        br=0;
        build(i);
        build_tree(1,0,br-1);
        for (int j=0;j<min(br,k);j++) {
            cur=tree[1].maxs;
            maxind=tree[1].ind;
            ///cout << "path " << j << ' ' << cur << ' ' << maxind << endl;
            update_path(maxind,cur,-1);
            ans+=cur;
        }
        cout << ans << endl;
    }
    return 0;
}
