/**
* user:  anica-popa-e2a
* fname: Vlad-Ioan
* lname: Anica-Popa
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:28:04.646003
*/
#include <iostream>

using namespace std;

int cnt;
int v[100];
int fr[100];
int n, m, pos[1000], dub;
//bool isLucky();
void bck(int step);


int main()
{
    cin >> n >> m;
    dub = n * 2;
    bck(1);
    cout << cnt;

    return 0;
}

/*bool isLucky()
{
    int firstPos[100];
    for (int i = 1; i <= dub; i++)
        if (!firstPos[v[i])
            firstPos[v[i]] = i;

    for (int i = 1; i <= dub; i++)
    {
        if (firstPos[v[i]] != i)
        {
            if ((i - firstPos[v[i]]) % m == 0)
                return 0;
        }
    }
    return 1;
}*/
void bck(int step)
{
    if (step == dub + 1)
    {
            cnt++;
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        if (fr[i] == 0)
        {
            fr[i]++;
            pos[i] = step;
            bck(step + 1);
            fr[i]--;
        }
        else if (fr[i] == 1)
        {
            if ((step - pos[i]) % m != 0)
            {
                fr[i]++;
                bck(step + 1);
                fr[i]--;
            }
        }
    }

}
