/**
* user:  yankova-448
* fname: Denitsa Marinova
* lname: Yankova
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:01:56.247494
*/
#include<bits/stdc++.h>
#include "weirdtree.h"
using namespace std;

int const MAXN=300010;
long long tree[4*MAXN], n;

struct Edge
{
    int val, idx;
};

Edge a[MAXN];

void make_tree(int idx, int l, int r)
{
    if(l==r)
    {
        tree[idx]=a[l].val;
        return;
    }
    int mid=(l+r)/2;
    make_tree(idx*2, l, mid);
    make_tree(idx*2+1, mid+1, r);
    tree[idx]=tree[idx*2]+tree[idx*2+1];
}

void update(int idx, int l, int r, int x, int pos)
{
    if(l==r)
    {
        tree[idx]=x;
        return;
    }
    int mid=(l+r)/2;
    if(mid<pos) update(idx*2+1, mid+1, r, x, pos);
    else if(pos<=mid) update(idx*2, l, mid, x, pos);
    tree[idx]=tree[idx*2]+tree[idx*2+1];
}

long long query(int idx, int l, int r, int ql, int qr)
{
    if(ql==l&&qr==r)
    {
        return tree[idx];
    }
    int mid=(l+r)/2;
    if(qr<=mid) return query(idx*2, l, mid, ql, qr);
    else if(ql>mid) return query(idx*2+1, mid+1, r, ql, qr);
    else return query(idx*2, l, mid, ql, mid) + query(idx*2+1, mid+1, r, mid+1, qr);
}

void initialise(int N, int Q, int h[])
{
    for(int i=1;i<=N;i++)
    {
        a[i].val=h[i];
        a[i].idx=i;
    }
    n=N;
    make_tree(1,1,N);
}

bool cmp(Edge l, Edge r)
{
    if(l.val==r.val) return l.idx<r.idx;
    else return l.val>r.val;
}

bool cmp1(Edge l, Edge r)
{
    return l.idx<r.idx;
}

void cut(int l, int r, int k)
{
    long long maxn=0;
    int pos=0;
    /*while(k!=0)
    {
        maxn=0;
        for(int i=l;i<=r;i++)
        {
            if(a[i]>maxn)
            {
                maxn=a[i];
                idx=i;
            }
        }
        maxn--;
        if(maxn<0) maxn=0;
        update(1,1,n,maxn,idx);
        a[idx]=maxn;
        k--;
    }*/
    sort(a+1,a+n+1,cmp);
    while(k!=0)
    {
        maxn=0;
        for(int i=1;i<=n;i++)
        {
            if(a[i].val>maxn)
            {
                maxn=a[i].val;
                pos=a[i].idx;
            }
            else if(a[i].val==maxn) pos=min(pos,a[i].idx);
            else break;
        }
        if(maxn==0) break;;
        a[pos].val=maxn;
        k--;
    }
    sort(a+1,a+n+1,cmp1);
    make_tree(1,1,n);
}

void magic(int i, int x)
{
    update(1,1,n,x,i);
    a[i].val=x;
}

long long int inspect(int l, int r)
{
    return query(1,1,n,l,r);
}

/*int main() {
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
        for(int j=1;j<=n;j++)
        {
            cout<<a[j].val<<" ";
        }
        cout<<endl;
    }
    return 0;
}*/
