/**
* user:  fares-9ed
* fname: Yusuf
* lname: Fares
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:02:31.498425
*/
#include <bits/stdc++.h>
#include "weirdtree.h"
#define VALMAX 1000000000
#define int64 long long
#define NMAX 300000

using namespace std;

struct straint {
  int maxim, pozmax;
  int64 sum;
};

straint vaint[NMAX * 4];
int64 sum;
int v[NMAX + 1], nv;

straint join(straint A, straint B) {
  straint sol;

  if (A.maxim > B.maxim)
    sol.maxim = A.maxim, sol.pozmax = A.pozmax;
  else if (B.maxim > A.maxim)
    sol.maxim = B.maxim, sol.pozmax = B.pozmax;
  else {
    sol.maxim = A.maxim;
    if (A.pozmax < B.pozmax)
      sol.pozmax = A.pozmax;
    else
      sol.pozmax = B.pozmax;
  }
  sol.sum = A.sum + B.sum;
  return sol;
}

void update(int node, int left, int right, int poz, int val) {
  if (left == right) {
    vaint[node].maxim = vaint[node].sum = val;
    vaint[node].pozmax = left;
    return;
  }

  int med = (left + right) / 2;
  if (poz >= left && poz <= med)
    update(node * 2, left, med, poz, val);
  else
    update(node * 2 + 1, med + 1, right, poz, val);
  vaint[node] = join(vaint[node * 2], vaint[node * 2 + 1]);
}

straint query(int node, int left, int right, int srcleft, int srcright) {
  if (srcleft == left && srcright == right)
    return vaint[node];

  int med = (left + right) / 2;
  if (srcleft >= left && srcleft <= med && srcright <= right && srcright >= med + 1)
    return join(vaint[node * 2], vaint[node * 2 + 1]);
  else if (srcleft >= left && srcleft <= med)
    return vaint[node * 2];
  else
    return vaint[node * 2 + 1];
}

void initialise(int n, int q, int h[]) {
  int i;

  sum = 0;
  nv = n;
  for (i = 1; i <= n; i++) {
    v[i] = h[i];
    update(1, 1, n, i, v[i]);
  }
}

void cut(int l, int r, int k) {
  if (k == 1) {
    straint x = query(1, 1, nv, l, r);
    update(1, 1, nv, x.pozmax, v[x.pozmax] - 1);
    v[x.pozmax]--;
  }
}

void magic(int i, int x) {
  update(1, 1, nv, i, x);
  v[i] = x;
}

int64 int inspect(int l, int r) {
  straint x = query(1, 1, nv, l, r);
  return x.sum;
}

int main() {
  int n, q, i, x, y, z, op;
  cin >> n >> q;

  for (i = 1; i <= n; i++)
    cin >> v[i];
  initialise(n, q, v);
  while (q--) {
    cin >> op;
    if (op == 1)
      cin >> x >> y >> z;
    else
      cin >> x >> y;

    if (op == 1)
      cut(x, y, z);
    else if (op == 2)
      magic(x, y);
    else
      cout << inspect(x, y) << "\n";
  }
  return 0;
}
