/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  NoM
* score: 21.0
* date:  2021-12-17 10:49:21.743606
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

mt19937 rnd(time(0));


const int mod = 1e9 + 7;

int fastpow(int a, int b) {
	if (b == 0)
		return 1;
	if (b & 1)
		return a * fastpow(a, b - 1) % mod;
	int t = fastpow(a, b / 2);
	return t * t % mod;
}

void solve() {
	int n, m;
	cin >> n >> m;
	n *= 2;
	int f[n + 10];
	f[0] = 1;
	for (int i = 1; i < n + 10; ++i) {
		f[i] = f[i - 1] * i % mod;
	}
	int dp[n + 1][n + 1];
	memset(dp, 0, sizeof(dp));
	dp[0][0] = 1;
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j <= n; ++j) {
			dp[i][j] = dp[i - 1][j];
			if (i >= 2 && j >= 1) {
				dp[i][j] += dp[i - 2][j - 1] * (i - 1) % mod;
				if (dp[i][j] >= mod)
					dp[i][j] -= mod;
			}
		}
	}
	int c[m];
	memset(c, 0, sizeof(c));
	for (int i = 0; i < n; ++i) {
		c[i % m] += 1;
	}
	int dp2[m + 1][n + 1];
	memset(dp2, 0, sizeof(dp2));
	dp2[0][0] = 1;
	for (int i = 1; i <= m; ++i) {
		for (int j = 0; j <= n; ++j) {
			for (int k = 0; k <= j; ++k) {
				dp2[i][j] += dp2[i - 1][j - k] * dp[c[i - 1]][k] % mod;
				dp2[i][j] %= mod;
			}
		}
	}
	// cout << dp[2][1] << endl;
	// cout << dp2[m - 1][1] << ' ' << dp[c[m - 1]][1] << endl;
	// cout << dp2[m][2] << endl;
	auto C = [&] (int n, int k) {
		return f[n] * fastpow(f[n - k], mod - 2) % mod * fastpow(f[k], mod - 2) % mod;
	};
	int ans[n];
	for (int i = n / 2; i >= 0; --i) {
		ans[i] = dp2[m][i] * f[n / 2] % mod * fastpow(f[n / 2 - i], mod - 2) % mod * fastpow(2, i) % mod * f[(n - 2 * i)] % mod;
		// cout << ans[i] << ' ';
		for (int j = i + 1; j <= n / 2; ++j) {
			ans[i] -= ans[j] * C(j, i) % mod;
			ans[i] = (ans[i] % mod + mod) % mod;
		}
	}
	cout << ans[0] << endl;
	// if ((n / 2) % 2 == 0)
	// 	ans = f[n] - ans;
	// ans = (ans % mod + mod) % mod;
	// cout << ans << endl;
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	// cin >> t;
	while (t--)
		solve();
}