/**
* user:  savu-e4c
* fname: Ştefan Cătălin
* lname: Savu
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:23:50.186486
*/
#include <iostream>
#include <cmath>
using namespace std;
int m,n,ap[101],b[101],ras;
int ver()
{
    for (int i=m+1;i<=2*n;++i)
    {
        if (abs(b[i]-b[i-m])==n) return 0;
    }
    return 1;
}
void bak(int k)
{
    if (k==2*n+1) {ras+=ver(); return;}
    for (int i=1;i<=2*n;++i)
    {
        if (ap[i]==0) {b[k]=i; ap[i]=1; bak(k+1); ap[i]=0;}
    }
}
int main()
{
    cin>>n>>m;
    bak(1);
    cout<<ras;
    return 0;
}
