/**
* user:  piscu-24c
* fname: Stefan Constantin
* lname: Piscu
* task:  Paths
* score: 19.0
* date:  2021-12-17 08:47:50.149007
*/
#include <bits/stdc++.h>
using namespace std;

#define int long long

int n, k;
vector<vector<pair<int, int>>> out;
vector<int> nrl;
vector<vector<int>> dp;

void setSize(int n){
	nrl.resize(n+1);
	out.resize(n+1);
	dp.resize(n+1);
}

void compute(int x, int fat=-1){
	nrl[x]=0;
	for(auto it:out[x]){
		if(it.first==fat) continue;
		compute(it.first, x);
		nrl[x]+=nrl[it.first];
		if(out[it.first].size()==1) nrl[x]++;
	}
	dp[x].clear();
	dp[x].resize(min(k+1, max(2ll, nrl[x]+1)), 0);
	//cout<<x<<" "<<nrl[x]<<"*\n";
}

void mergedp(vector<int> &dp1, vector<int> &dp2, int val){
	vector<int> orig(dp1.size());
	for(int i=0;i<dp1.size();++i) orig[i]=dp1[i];
	for(int i=1;i<dp2.size();++i){
		for(int j=i;j<dp1.size();++j){
			dp1[j]=max(dp1[j], dp2[i]+orig[j-i]+val);
		}
	}

}

void calcdp(int x, int fat=-1){
	for(auto it:out[x]){
		if(it.first==fat) continue;
		calcdp(it.first, x);
		mergedp(dp[x], dp[it.first], it.second);
	}
	/*
	cout<<x<<"\n";
	for(auto it:dp[x]) cout<<it<<" ";
	cout<<"\n";
	*/
}

int32_t main(){
	cin>>n>>k;
	setSize(n);
	for(int i=1;i<n;++i){
		int a, b, c;
		cin>>a>>b>>c;
		out[a].push_back({b, c});
		out[b].push_back({a, c});
	}
	for(int i=1;i<=n;++i){
		compute(i);
		calcdp(i);
		if(nrl[i]<k) cout<<dp[i][nrl[i]]<<"\n";
		else cout<<dp[i][k]<<"\n";
	}
}
