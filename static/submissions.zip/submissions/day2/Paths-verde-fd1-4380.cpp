/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Paths
* score: 36.0
* date:  2021-12-17 07:47:19.656208
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast","unroll-loops")
#pragma GCC target("avx","avx2","fma")
using namespace std;
vector<int> v[2001];
long long dist[2001];
int tata[2001];
int cost[2001][2001];
void dfs(int nod,int papa)
{
    tata[nod]=papa;
    for(auto it:v[nod])
        if(it!=papa)
        {
            dist[it]=dist[nod]+cost[nod][it];
            dfs(it,nod);
        }
}
void dfsmod(int nod,int papa,long long val)
{
    dist[nod]-=val;
    for(auto it:v[nod])
        if(it!=papa)
            dfsmod(it,nod,val);
}
void up(int nod,int venit,long long val)
{
    dist[nod]=0;
    if(tata[nod]==0)
        return;
    for(auto it:v[nod])
        if(it!=tata[nod]&&it!=venit)
            dfsmod(it,nod,val);
    if(dist[tata[nod]])
        up(tata[nod],nod,val-cost[nod][tata[nod]]);
}
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int n,k,i,a,b,c,j;
    cin>>n>>k;
    for(i=1; i<n; i++)
    {
        cin>>a>>b>>c;
        v[a].push_back(b);
        v[b].push_back(a);
        cost[a][b]=cost[b][a]=c;
    }
    long long sum;
    int ind;
    for(i=1; i<=n; i++) ///radacina
    {
        sum=0;
        int ck=k;
        dist[i]=0;
        dfs(i,0);
        while(k)///iau cel mai bun si updatez
        {
            ind=0;
            for(j=1; j<=n; j++)
                if(dist[j]>dist[ind])
                    ind=j;
            sum+=dist[ind];
            up(ind,0,dist[ind]);
            dist[ind]=0;
            k--;
        }
        cout<<sum<<'\n';
        k=ck;
    }
    return 0;
}
