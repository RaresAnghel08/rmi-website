/**
* user:  sayfullin-49d
* fname: Iskandar
* lname: Sayfullin
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:32:30.238858
*/
#include <bits/stdc++.h>
// #include "weirdtree.h"

using namespace std;

struct segtree {
    struct node {
        long long sum;
    };

    node merge(node a, node b) {
        return {a.sum + b.sum};
    }

    node zero = {0};
    vector <node> tree;
    int size = 1, q;


    void init(int N, int Q, int h[]) {
        int q = Q;
        while (size < N) size <<= 1;
        tree.assign(2 * size - 1, zero);

        for (int i = 0; i < N; i++) {
            tree[size - 1 + i].sum = h[i + 1];
        }
        for (int i = size - 2; i >= 0; i--) {
            tree[i] = merge(tree[2 * i + 1], tree[2 * i + 2]);
        }
    }

    node LToR(int l, int r, int x, int lx, int rx) {
        if (l >= rx || r <= lx) return zero;
        if (l <= lx && r >= rx) return tree[x];

        int m = (lx + rx) / 2;
        return merge(LToR(l, r, 2 * x + 1, lx, m),
                     LToR(l, r, 2 * x + 2, m, rx));
    }

    long long sum(int l, int r) {
        return LToR(l - 1, r, 0, 0, size).sum;
    }

    void reduce_max(int l, int r) {
        long long i_max = 0, Max = 0;
        for (int i = size - 1 + (l - 1); i < size - 1 + (r - 1); i++) {
            if (Max < tree[i].sum) {
                Max = tree[i].sum;
                i_max = i;
            }
        }
        if (tree[i_max].sum != 0) {
            tree[i_max].sum--;
            while (i_max > 0) {
                i_max = (i_max - 1) / 2;
                tree[i_max].sum--;
            }
        }
    }

    void replace(int i, int x) {
        i = size - 1 + (i - 1);
        tree[i].sum = x;
        while (i > 0) {
            i = (i - 1) / 2;
            tree[i] = merge(tree[2 * i + 1], tree[2 * i + 2]);
        }
    }
};

segtree tr;

void initialise(int N, int Q, int h[]) {
    tr.init(N, Q, h);
}
void cut(int l, int r, int k) {
    int sum_lr = tr.sum(l, r);

    for (int i = 0; i < min(sum_lr, k); i++) {
        tr.reduce_max(l, r);
    }
}
void magic(int i, int x) {
    tr.replace(i, x);
}
long long int inspect(int l, int r) {
    return tr.sum(l, r);
}