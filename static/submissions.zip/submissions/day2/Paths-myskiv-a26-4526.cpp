/**
* user:  myskiv-a26
* fname: Vladyslav
* lname: Myskiv
* task:  Paths
* score: 0.0
* date:  2021-12-17 08:04:16.306009
*/
#include <bits/stdc++.h>

using namespace std;

#define DIM 27

int n, k, cost, mx, timer, tin[DIM], tout[DIM], u, v, c, bitmask;

vector<pair<int, int> > vec[DIM];

int isbit(int i, int bit){
    i=1<<i;
    return bit&i;
}

void dfs(int v, int p){
    tin[v]=++timer;
    for(auto e : vec[v]){
        int to=e.first;
        if(to!=p) dfs(to, v);
    }
    tout[v]=timer;
    return;
}

void get_cost(int v, int p, int bitmask){
    for(auto e : vec[v]){
        int to=e.first;
        if(to==p) continue;
        for(int i=1; i<=n; i++){
            if(!isbit(i-1, bitmask)) continue;
            if(tin[to]<=tin[i] && tout[i]<=tout[to]){
                cost+=e.second;
                get_cost(to, v, bitmask);
                break;
            }
        }
    }
    return;
}

int main()
{
    cin>>n>>k;
    for(int i=1; i<n; i++){
        cin>>u>>v>>c;
        vec[u].push_back({v, c});
        vec[v].push_back({u, c});
    }
    for(int t=1; t<=n; t++){
        bitmask=(1<<n)-1;
        timer=0;
        dfs(t, -1);
        mx=0;
        for(int i=1; i<=bitmask; i++)
        {
            int cnt=0;
            for(int j=0; j<n; j++){
                if(isbit(j, i)) cnt++;
            }
            if(cnt!=k) continue;
            cost=0;
            get_cost(t, -1, i);
            mx=max(mx, cost);
        }
        cout<<mx<<endl;
    }
    return 0;
}
