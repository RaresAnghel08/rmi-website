/**
* user:  zibnickij-103
* fname: Nikita
* lname: Zibnickij
* task:  Paths
* score: 8.0
* date:  2021-12-17 11:57:47.612919
*/
#include <bits/stdc++.h>
#pragma GCC optimize("O3")

using namespace std;

void fastio(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
}

typedef long long ll;
typedef pair<int,int> pt;

const int MAXN = 203;

vector<pt> gr[MAXN];

const int LG = 12;

int jmp[LG][MAXN];

int d[MAXN];
int p[MAXN];

ll w1[MAXN];

void dfs(int v, int p1){
    for (auto z : gr[v]){
        int u = z.first, w = z.second;
        if (u == p1)
            continue;
        d[u] = d[v] + 1;
        p[u] = v;
        w1[u] = w1[v] + w;
        dfs(u, v);
    }
}

void init_jmp(int n){
    for (int i = 0; i < n; i++)
        jmp[0][i] = p[i];
    for (int k = 1; k < LG; k++){
        for (int i = 0; i < n; i++){
            jmp[k][i] = jmp[k - 1][jmp[k - 1][i]];
        }
    }
}

int lca(int u, int v){
    if (d[u] < d[v])
        swap(u, v);
    for (int k = LG - 1; k >= 0; k--){
        if ((d[u] - d[v]) >= (1 << k))
            u = jmp[k][u];
    }
    if (u == v)
        return u;
    for (int k = LG - 1; k >= 0; k--){
        if (jmp[k][u] != jmp[k][v]){
            u = jmp[k][u], v = jmp[k][v];
        }
    }
    return p[u];
}

vector<int> vs;

ll dp[MAXN][MAXN];


void getans(int v, int k0){
    if (!vs.empty()){
        for (int k = 1; k <= min(k0, (int)vs.size() + 1); k++){
            for (int u : vs){
                ll tmp = dp[k - 1][u] + w1[v] - w1[lca(u, v)];
                dp[k][v] = max(dp[k][v], tmp);
            }
        }
    }
    vs.push_back(v);
    for (auto z : gr[v]){
        int u = z.first;
        if (u != p[v]){
            getans(u, k0);
        }
    }

}

void solve(int root, int n, int k){
    for (int i = 0; i <= k; i++){
        for (int j = 0; j < n; j++)
            dp[i][j] = 0;
    }
    p[root] = root;
    d[root] = 0;
    w1[root] = 0;
    dfs(root, -1);
    init_jmp(n);
    vs.clear();
    dp[0][root] = 0;
    getans(root, k);
    ll ans = 0;
    for (int i = 0; i < n; i++)
        ans = max(ans, dp[k][i]);
    cout << ans << '\n';
}

int main(){
    fastio();
    int n, k;
    cin >> n >> k;
    for (int i = 0; i < n - 1; i++){
        int u, v, w;
        cin >> u >> v >> w;
        u--, v--;
        gr[u].emplace_back(v, w);
        gr[v].emplace_back(u, w);
    }
    for (int i = 0; i < n; i++)
        solve(i, n, k);
    return 0;
}