/**
* user:  dumitrescu-d88
* fname: Eduard Valentin
* lname: Dumitrescu
* task:  Paths
* score: 36.0
* date:  2021-12-17 11:38:12.183684
*/
#include <bits/stdc++.h>

#define fin std::cin
#define fout std::cout

#define maxn 100005

// std::ifstream fin("path.in");
// std::ofstream fout("path.out");

std::vector <std::pair <int, long long>> edge[maxn];

std::vector <bool> visited;
std::vector <bool> path;
std::vector <long long> smax;
std::vector <int> parent;
std::vector <int> start;

int V, k;

void dfs(int node) {
    visited[node] = true;
    start[node] = node;
    for(auto next: edge[node]) {
        if(visited[next.first] == false) {
            dfs(next.first);
            if(smax[node] < smax[next.first] + next.second) {
                smax[node] = smax[next.first] + next.second;
                start[node] = start[next.first];
            }
            parent[next.first] = node;
        }
    }
}

struct Nodes {
    int node;
    long long sum = 0;

    Nodes(int v1, long long v2) {
        node = v1;
        sum = v2;
    }

    bool operator<(const Nodes& n) const {
        return sum > n.sum;
    }
};

std::multiset <Nodes> set;

void solve(int root) {

    std::fill(visited.begin(), visited.end(), false);
    std::fill(smax.begin(), smax.end(), 0);
    std::fill(parent.begin(), parent.end(), 0);
    std::fill(start.begin(), start.end(), 0);
    std::fill(path.begin(), path.end(), false);

    set.clear();

    dfs(root);
    set.insert(Nodes(root, smax[root]));
    long long ans = 0;

    for(int kk = 0; kk < k and set.empty() == false ; kk ++) {
        auto x = *set.begin();
        ans += x.sum;
        set.erase(set.begin());

        int node = start[x.node];
        while(path[node] == false and node > 0) {
            path[node] = true;

            for(auto next: edge[node]) {
                if(path[next.first] == false and next.first != parent[node]) {
                    set.insert(Nodes(next.first, smax[next.first] + next.second));
                }
            }
            node = parent[node];
        }
    }
    fout << ans << '\n';


}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);

    fin >> V >> k;

    visited.resize(V+1);
    smax.resize(V+1);
    parent.resize(V+1);
    start.resize(V+1);
    path.resize(V+1);

    for(int i = 1, src, dest, cost; i < V; i ++) {
        fin >> src >> dest >> cost;
        edge[src].push_back({dest, cost});
        edge[dest].push_back({src, cost});
    }

    for(int i = 1; i <= V; i ++)
        solve(i);


    return 0;
}