/**
* user:  john-316
* fname: Josia
* lname: John
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:52:19.063082
*/
#pragma GCC optimize("O3")
#pragma optimize("unroll-loops")
#pragma optimize("sse,sse2,sse3,ssse3,sse4,avx")

#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

vector<int> heights;

void initialise(int N, int Q, int h[]) {
	heights.assign(N, 0);
	for (int i = 0; i<N; i++) {
		heights[i] = h[i];
	}
}
void cut(int l, int r, int k) {
	// assert(k==1);
	int index = -1;
	int max = -1;
	for (int i = l-1; i<r; i++) {
		if (heights[i] > max) {
			max = heights[i];
			index = i;
		}
	}
	if (max == 0) return;
	heights[index]--;
}
void magic(int i, int x) {
	heights[i] = x;
}
long long int inspect(int l, int r) {
	int res = 0;
	for (int i = l-1; i<r; i++) {
		res+=heights[i];
	}

	return res;
}
