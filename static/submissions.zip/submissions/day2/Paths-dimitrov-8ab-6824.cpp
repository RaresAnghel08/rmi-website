/**
* user:  dimitrov-8ab
* fname: Atanas
* lname: Dimitrov
* task:  Paths
* score: 56.0
* date:  2021-12-17 11:19:21.736644
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl "\n"
template<class T, class T2> bool chkmin(T &a, const T2 &b) {return (a > b) ? a = b, 1 : 0;}
template<class T, class T2> bool chkmax(T &a, const T2 &b) {return (a < b) ? a = b, 1 : 0;}
#ifndef LOCAL
#define cerr if(false)cerr
#endif // LOCAL

const ll MAX_N = 1e6 + 10;
vector<pair<ll, ll> > g[MAX_N];
ll n;
ll k;
ll val[MAX_N];

ll mxind[MAX_N];

void dfs(int x, int p) {
    mxind[x] = x;
    for(auto it : g[x]) {
        if(it.first == p) {continue;}
        dfs(it.first, x);
        val[mxind[it.first]] += it.second;
        if(val[mxind[it.first]] > val[mxind[x]]) {
            mxind[x] = mxind[it.first];
        }
    }
}

ll solve(int x) {
    for(int i = 1; i <= n; i ++) {
        val[i] = 0;
    }
    dfs(x, 0);
    sort(val + 1, val + n + 1);
    ll ans = 0;
    for(int i = n; i >= n - k + 1; i --) {
        ans += val[i];
    }
    return ans;
}

signed main() {
#ifndef LOCAL
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#endif

    cin >> n >> k;
    for(ll i = 0; i < n - 1; i ++) {
        ll a, b, c;
        cin >> a >> b >> c;
        g[a].push_back({b, c});
        g[b].push_back({a, c});
    }

    for(int i = 1; i <= n; i ++) {
        cout << solve(i) << endl;
    }

    return 0;
}

