/**
* user:  negoescu-c8b
* fname: Divia Petra
* lname: Negoescu
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:09:45.076080
*/
#include "weirdtree.h"
#include <set>
int v[100002],sol,poz,n;
multiset <pair<int,int> > aux;
long long sum;
struct strnod{
    int valmax;
    int pozmax;
    long long sum;
} a[400002];

void build(int nod,int st,int dr){
    if(st==dr){
        a[nod].valmax=v[st];
        a[nod].pozmax=st;
        a[nod].sum=v[st];
        return;
    }
    int mid=(st+dr)/2;
    build(2*nod, st, mid);
    build(2*nod+1,mid+1, dr);
    //a[nod].valmax=max(a[2*nod].valmax, a[2*nod+1]);
    if(a[2*nod].valmax>a[2*nod+1].valmax || (a[2*nod].valmax==a[2*nod+1].valmax && a[2*nod].pozmax<a[2*nod+1].pozmax)){
       a[nod].valmax=a[2*nod].valmax;
       a[nod].pozmax=a[2*nod].pozmax;
    }
    else{
        a[nod].valmax=a[2*nod+1].valmax;
        a[nod].pozmax=a[2*nod+1].pozmax;
    }
    a[nod].sum=a[2*nod].sum+a[2*nod+1].sum;
}
void update(int nod,int st,int dr,int poz,int x){
    if(st==dr){
        a[nod].valmax=x;
        a[nod].sum=x;
        return;
    }
    int mid=(st+dr)/2;
    if(poz<=mid)
        update(2*nod,st,mid,poz,x);
    else update(2*nod+1,mid+1,dr,poz,x);

   // a[nod]=max(a[2*nod],a[2*nod+1]);
    if(a[2*nod].valmax>a[2*nod+1].valmax || (a[2*nod].valmax==a[2*nod+1].valmax && a[2*nod].pozmax<a[2*nod+1].pozmax)){
       a[nod].valmax=a[2*nod].valmax;
       a[nod].pozmax=a[2*nod].pozmax;
    }
    else{
        a[nod].valmax=a[2*nod+1].valmax;
        a[nod].pozmax=a[2*nod+1].pozmax;
    }
    a[nod].sum=a[2*nod].sum+a[2*nod+1].sum;
}
void query_pozmax(int nod,int st,int dr, int l,int r){
    if(l<=st && dr<=r){
        if(sol<a[nod].valmax || (sol==a[nod].valmax && poz>a[nod].pozmax)){
            sol=a[nod].valmax;
            poz=a[nod].pozmax;
        }
        return;
    }
    int mid=(st+dr)/2;
    if(l<=mid)
        query_pozmax(2*nod, st,mid,l,r);
    if(r>mid)
        query_pozmax(2*nod+1, mid+1, dr,l,r);
}
void query_sum(int nod,int st,int dr,int l,int r){
    if(l<=st && dr<=r){
        sum+=a[nod].sum;
        return;
    }
    int mid=(st+dr)/2;
    if(l<=mid)
        query_sum(2*nod, st,mid,l,r);
    if(r>mid)
        query_sum(2*nod+1, mid+1, dr,l,r);
}
void initialise(int N, int Q, int h[]){
    n=N;
    for(int i=1;i<=n;i++)
        v[i]=h[i];
    build(1,1,n);
}
void cut(int l, int r, int k) {
    aux.clear();

    for(int i=l;i<=r;i++){
        poz=sol=0;
        query_pozmax(1,1,n,l,r);
        aux.insert({-sol,poz});
    }
    while(k){
        if(aux.size()==0)break;
        int elem1,elem2,poz1,poz2;
        elem1=-aux.begin()->first;
        poz1=aux.begin()->second;
        if(elem1==0)break;
        if(aux.size()==1){
            int dif=min(elem1,k);
            update(1,1,n,poz1,elem1-dif);
            k-=dif;
            break;
        }
        aux.erase(aux.begin());
        elem2=-aux.begin()->first;
        poz2=aux.begin()->second;

        int dif=elem1-elem2;
        if(k<dif){
            dif=k;
        }

        update(1,1,n,poz1,elem1-dif);
        k-=dif;
        if(elem1-dif>0)
            aux.insert({elem1-dif,poz1});
    }
}
void magic(int i, int x) {
	update(1,1,n,i,x);
}
long long int inspect(int l, int r) {
	sum=0;
	query_sum(1,1,n,l,r);
	return sum;
}
