/**
* user:  dzheentaev-018
* fname: Bektur
* lname: Dzheentaev
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:17:34.359996
*/
﻿
#include <iostream>
#include <vector>
#include <set>
#include<algorithm>
using namespace std;
typedef long long ll;
ll nmax = 1e9 + 7;
vector<vector<bool> >used;
vector<vector<pair<ll,ll> > >g;
vector<ll>d;

ll maxx = -1;
void dfs(ll v) {
   
    for (ll i = 0; i < g[v].size(); i++) {
        ll to = g[v][i].first;
      //  cout << to << " " << d[to] << endl;
        if (used[v][to] != true) {
         //   cout << v << " " << to << endl;
            d[to] = min(d[to],d[v] + g[v][i].second);
            maxx = max(maxx, d[to]);
            used[to][v] = true;
            dfs(to);
        }
    }
}
int main()
{
    ll n, m;
    cin >> n >> m;
    vector<ll>a(2 * n );
    ll cnt = 1;
    for (ll i = 0; i < 2 * n; i+=2) {
        a[i] = cnt ;
        a[i + 1] = cnt ;
        cnt++;
    }
    cnt = 0;
    while (next_permutation(a.begin(), a.end())) {
        bool flag = true;
        for (ll i = 0; i < 2 * n; i++) {
           // cout << a[i] << " ";
            for (ll j = i+m; j < 2 * n; j += m) {
                if (a[j] == a[i]) {
                    flag = false;
                    break;
                }
            }
        }
    //    cout << endl;
        if (flag == true)
            cnt++;
        cnt = cnt % nmax;
    }
    cout << cnt << endl;
      //    for (ll i = 0; i < n; i++) {
      //        cout << d[i] << " ";
      //    }
//cout << endl;
         // sort(d.begin(), d.end());
        //  ll sum = 0;
        //  for (ll j = n-1; j >= n-k; j--) {
        //      sum += d[j];
       //   }
     
    return 0;
}
