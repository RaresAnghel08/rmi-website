/**
* user:  ruslanov-d88
* fname: Aktan
* lname: Ruslanov
* task:  Paths
* score: 0.0
* date:  2021-12-17 07:39:21.198659
*/
#include <bits/stdc++.h>
#define int long long
#define ft first
#define sc second
using namespace std;
vector<pair<int,int>> v[200005];
multiset<pair<int,int>> m[200005];
int used[200005];
main(){
	int n,k,a,b,c;
	cin >> n >> k;
	for(int i=1;i<n;i++){
		cin >> a >> b >> c;
		v[a].push_back({c,b});
		v[b].push_back({c,a});
		m[a].insert({c,b});
		m[b].insert({c,a});
	}
	for(int i = 1;i<=n;i++){
		auto it =m[i].end();
		it--;
		cout << it->ft << endl;
	}
	
}
