/**
* user:  yankova-448
* fname: Denitsa Marinova
* lname: Yankova
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:58:05.285215
*/
#include<bits/stdc++.h>
#define endl "\n"
using namespace std;

int const MAXN=100;
int n, m, p[MAXN], cnt[MAXN], dist[MAXN], br;

void print()
{
    for(int i=1;i<=2*n;i++)
    {
        cout<<p[i]<<" ";
    }
    cout<<endl;
}

void perm(int pos)
{
    if(pos>2*n)
    {
        memset(dist,0,sizeof(dist));
        memset(cnt,0,sizeof(cnt));
        for(int i=1;i<=2*n;i++)
        {
            cnt[p[i]]++;
            if(dist[p[i]]==0) dist[p[i]] = i;
            else
            {
                dist[p[i]] = i - dist[p[i]];
                if(dist[p[i]]%m==0) return;
            }
            if(cnt[p[i]]>2) return;
        }
        br++;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(cnt[i]<2)
        {
            p[pos]=i;
            cnt[i]++;
            perm(pos+1);
            cnt[i]--;
        }

    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
	cin>>n>>m;
	perm(1);
	cout<<br<<endl;
	return 0;
}
