/**
* user:  bankov-a77
* fname: Mihail
* lname: Bankov
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:04:55.740876
*/
#include<bits/stdc++.h>
using namespace std;
int n,k;
vector<pair<int,int> >a[100001];
vector<bool>used;
void solve1()
{

}
typedef multiset<int> * vi;
vi u[1001];
vector<multiset<int> >v;
int ttt=0;
void dfs(int n)
{
    //cout<<n<<endl;
    used[n]=1;
    int sz=0;
    vi maxi;
    int c=0;
    for(pair<int,int>i:a[n])
    {
        if(!used[i.first])
        {
            c++;
            dfs(i.first);
            auto x=u[i.first]->end();
            x--;
            int y=*x;
            y+=i.second;
            u[i.first]->erase(x);
            u[i.first]->insert(y);

            //cout<<"shidt";
            //for(multiset<int>::iterator q=u[4]->begin(); q!=u[4]->end(); q++)
            //    cout<<*q<<' ';
            //cout<<endl;
            //cout<<33<<endl;
            //cout<<u[i.first]->size()<<"asdf"<<endl;
            if(sz<u[i.first]->size())
            {
                //cout<<44<<endl;
                maxi=u[i.first];
                //cout<<maxi->size()<<endl;
                sz=u[i.first]->size();
            }
            //cout<<u[i.first]->size()<<"asdf"<<endl;
        }
    }
    if(c==0)
    {
        multiset<int>mmm;
        mmm.insert(0);
        v[ttt++]=mmm;
        //if(n==5 && u[4]->size()==0)cout<<"WHAT THE"<<endl;
        u[n]=&v[ttt-1];
    }
    else
    {
        //cout<<"LOOKOUT"<<n<<endl;
        multiset<int>newm;
        for(pair<int,int>i:a[n])
        {
            if(used[i.first])
                continue;
            if(u[i.first]!=maxi)
            {
                for(multiset<int>::iterator q=u[i.first]->begin(); q!=u[i.first]->end(); q++)
                    newm.insert(*q);
            }
        }
        u[n]=maxi;
        for(int i:newm)
        {
            maxi->insert(i);
        }
    }
    //cout<<"node "<<n<<' ';
    //for(multiset<int>::iterator q=u[n]->begin(); q!=u[n]->end(); q++)
    //    cout<<*q<<' ';
    //cout<<endl;
    used[n]=0;
}
void solve()
{
ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>k;
    for(int i=0; i<n-1; i++)
    {
        int x,y,w;
        cin>>x>>y>>w;
        a[x].push_back({y,w});
        a[y].push_back({x,w});
    }
    ///if(k==1){solve1();return;}
    for(int i=1; i<=n; i++)
    {
        used=vector<bool>(n+1,0);
        v=vector<multiset<int> >(n+1);
        ttt=0;
        dfs(i);
        multiset<int>::iterator x=u[i]->end();
        x--;
        int ans=0;
        for(int j=0; j<k; j++,x--)
        {
            ans+=*x;
        }
        cout<<ans<<'\n';
    }
}
int main()
{
    solve();
    return 0;
}
/**
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/
