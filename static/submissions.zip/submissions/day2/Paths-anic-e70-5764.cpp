/**
* user:  anic-e70
* fname: Vito
* lname: Anić
* task:  Paths
* score: 100.0
* date:  2021-12-17 09:58:28.078562
*/
#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>

using namespace std;

const int maxn=1e5+5, Log=17, pot=(1<<Log);
typedef long long ll;


struct tournament{
	pair < ll, ll > t[pot*2];
	tournament(){
		for(ll i=0; i<pot; i++){
			t[i+pot].second=i;
		}
	}
	void update(ll x, ll val){
		t[x].first+=val;
		for(x/=2; x>0; x/=2){
			if(t[x*2].first>=t[x*2+1].first){
				t[x]=t[x*2];
			}
			else{
				t[x]=t[x*2+1];
			}
		}
	}
	pair < ll, ll > query(ll L, ll D, ll x, ll l, ll d){
		if(L>=l && D<=d){
			return t[x];
		}
		pair < ll, ll > lijeva={-1, 0}, desna={-1, 0};
		if((L+D)/2>=l){
			lijeva=query(L, (L+D)/2, x*2, l, d);
		}
		if((L+D)/2+1<=d){
			desna=query((L+D)/2+1, D, x*2+1, l, d);
		}
		if(lijeva.first>=desna.first){
			return lijeva;
		}
		else{
			return desna;
		}
	}
};


tournament T;
vector < pair < ll, ll > > ms[maxn];
pair < ll, ll > range[maxn];
ll pos;

void dfs(ll x, ll prosl){
	range[x].first=pos;
	pos++;
	for(ll i=0; i<(ll)ms[x].size(); i++){
		if(ms[x][i].first!=prosl){
			dfs(ms[x][i].first, x);
		}
	}
	range[x].second=pos-1;
}

void precompute(ll x, ll prosl, ll val){
//	cout << x << ' ' << prosl << endl;
	for(ll i=0; i<(ll)ms[x].size(); i++){
		if(ms[x][i].first!=prosl){
			precompute(ms[x][i].first, x, ms[x][i].second);
		}
	}
	if(x!=prosl){
//		cout << x << ' ' << range[x].first << ' ' << range[x].second << endl;
		ll ind=T.query(0, pot-1, 1, range[x].first, range[x].second).second;
		T.update(ind+pot, val);
	}
}

ll n, k;
ll curr;
set < pair < ll, ll > > svi;
bool jes[maxn];
ll sol[maxn];
pair < ll, ll > gran1, gran2;

void solve(ll x, ll prosl){
//	cout << "sad " << x << ' ' << curr << endl;
	sol[x]=curr;
	ll y;
	ll val;
	pair < ll, ll > r;
	pair < ll, ll > naj1, naj2, naj3, naj4;
	vector < pair < bool, pair < ll, ll > > > operacije;
	ll delta;
	vector < pair < ll, bool > > dane;
	pair < ll, ll > granp1=gran1, granp2=gran2;
	
	for(ll i=0; i<(ll)ms[x].size(); i++){
		if(ms[x][i].first!=prosl){
			y=ms[x][i].first;
			val=ms[x][i].second;
			r=range[y];
			naj1=T.query(0, pot-1, 1, r.first, r.second);
			naj4={0, x};
			naj2={-1, 0};
			naj3={-1, 0};
			if(r.first>0){
				naj2=T.query(0, pot-1, 1, 0, r.first-1);
			}
			naj3=T.query(0, pot-1, 1, r.second+1, pot-1);
			if(naj4.first<naj3.first){
				naj4=naj3;
			}
			if(naj4.first<naj2.first){
				naj4=naj2;
			}
//			cout << "dolje " << naj1.first << ' ' << naj1.second << endl;
//			cout << "ost " << naj4.first << ' ' << naj4.second << endl;
			T.update(naj1.second+pot, -val);
			T.update(naj4.second+pot, val);
			delta=0;
			operacije.push_back({1, naj1});
			svi.erase(naj1);
			naj1.first-=val;
			operacije.push_back({0, naj1});
			svi.insert(naj1);
			if(jes[naj1.second]){
				delta+=-val;
				if(gran1.first>naj1.first || (gran1.first==naj1.first && gran1.second>naj1.second)){
					delta+=gran1.first-naj1.first;

					jes[naj1.second]=0;
					dane.push_back({naj1.second, 1});
					
					jes[gran1.second]=1;
					dane.push_back({gran1.second,  0});
					
					gran2=gran1;
					auto it=svi.find(gran2);
					gran1=*(--it);
				}
				else{
					auto it=svi.find(gran1);
					gran2=*(++it);
//					cout << "tu " << gran2.first << ' ' << gran2.second << endl;
//					cout << gran1.first << ' ' << gran1.second << endl;
				}
			}
			else{
				auto it=svi.find(gran2);
				gran1=*(--it);
			}
//			cout << "d1 " <<  delta << endl;
			operacije.push_back({1, naj4});
			svi.erase(naj4);
			naj4.first+=val;
			operacije.push_back({0, naj4});
			svi.insert(naj4);
			if(jes[naj4.second]){
				delta+=val;
				auto it=svi.find(gran1);
				gran2=*(++it);
			}
			else{
//				cout << "ovdje " << endl;
//				cout << naj4.first << ' ' << naj4.second << endl;
//				cout << gran2.first << ' ' << gran2.second << endl;
				if(naj4.first>gran2.first || (naj4.first==gran2.first && naj4.second>gran2.second)){
					delta+=naj4.first-gran2.first;

 					jes[naj4.second]=1;
					dane.push_back({naj4.second, 0});

					jes[gran2.second]=0;
					dane.push_back({gran2.second, 1});

					gran1=gran2;
					auto it=svi.find(gran1);
					gran2=*(++it);
				}
				else{
					auto it=svi.find(gran2);
					gran1=*(--it);
				}
			}
//			cout << "d2 " << delta << endl;
//			cout << delta << endl;
			curr+=delta;
			solve(y, x);
			gran1=granp1;
			gran2=granp2;
			curr-=delta;
			T.update(naj1.second+pot, val);
			T.update(naj4.second+pot, -val);
			while(!operacije.empty()){
				naj1=operacije.back().second;
				if(operacije.back().first){
					svi.insert(naj1);
				}
				else{
					svi.erase(naj1);
				}
				operacije.pop_back();
			}
			while(!dane.empty()){
				jes[dane.back().first]=dane.back().second;
				dane.pop_back();
			}
		}
	}
	
}

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> n >> k;
	ll a, b, c;
	for(ll i=0; i<n-1; i++){
		cin >> a >> b >> c;
		a--;
		b--;
		ms[a].push_back({b, c});
		ms[b].push_back({a, c});
	}
	dfs(0, 0);
/*	for(ll i=0; i<n; i++){
		cout << range[i].first << ' ' << range[i].second << endl;
	}*/
	precompute(0, 0, -1);
	pair < ll, ll > x;
	for(ll i=0; i<n; i++){
		svi.insert(T.t[i+pot]);
	}
	auto it=svi.end();
	for(ll i=0; i<k; i++){
		it--;
		curr+=it->first;
		jes[it->second]=1;
	}
	gran2=*it;
	if(it==svi.begin()){
		gran1={-1, 0};
	}
	else{
		it--;
		gran1=*it;
	}
//	cout << gran1.first << ' ' << gran1.second << endl;
//	cout << gran2.first << ' ' << gran2.second << endl;
	solve(0, 0);
	for(ll i=0; i<n; i++){
		cout << sol[i] << '\n';
	}
	return 0;
}
