/**
* user:  yanev-c4c
* fname: Aleksandar Angelov
* lname: Yanev
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 11:57:27.434606
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
#define endl '\n'
#define ll long long
using namespace std;
const ll MAX_N = 160002;
ll n,q;
ll a[MAX_N];
vector< pair<ll,ll> > tree[MAX_N*2]; /// first = val second = idx
ll sum[MAX_N*2];
void merge_sort(ll node, vector< pair<ll,ll> > &res, vector< pair<ll,ll> > a, vector< pair<ll,ll> > b)
{
    if(node != -1) res.clear();
    ll asz = a.size(), bsz = b.size();
    ll ptr1 = 0, ptr2 = 0;
    for(ll i=0; i<asz+bsz; i++)
    {
        if(ptr1 >= asz)
        {
            res.push_back(b[ptr2]);
            ptr2++;
        }
        else if(ptr2 >= bsz)
        {
            res.push_back(a[ptr1]);
            ptr1++;
        }
        else
        {
            if(a[ptr1].first == b[ptr2].first)
            {
                if(a[ptr1].second < b[ptr2].second)
                {
                    res.push_back(a[ptr1]);
                    ptr1++;
                }
                else
                {
                    res.push_back(b[ptr2]);
                    ptr2++;
                }
            }
            else
            {
                if(a[ptr1].first < b[ptr2].first)
                {
                    res.push_back(a[ptr1]);
                    ptr1++;
                }
                else
                {
                    res.push_back(b[ptr2]);
                    ptr2++;
                }
            }
        }
    }
    if(node != -1)
    {
        sum[node] = 0;
        for(auto x: res) sum[node]+=x.first;
    }
}
void build(ll node, ll tl, ll tr)
{
    if(tl == tr)
    {
        tree[node].push_back({a[tl],tl});
        sum[node] = a[tl];
        return;
    }
    ll mid = (tl+tr)/2;
    build(node*2, tl, mid);
    build(node*2+1, mid+1, tr);
    merge_sort(node, tree[node], tree[node*2], tree[node*2+1]);
}
vector< pair<ll, pair<ll,ll> > > node_idx;
void find_node_idx(ll node, ll tl, ll tr, ll l, ll r)
{
    if(tl > r || tr < l) return;
    if(tl >= l && tr <= r)
    {
        node_idx.push_back({node,{tl,tr}});
        return;
    }
    ll mid = (tl+tr)/2;
    find_node_idx(node*2, tl, mid, l, r);
    find_node_idx(node*2+1, mid+1, tr, l, r);
}
void update(ll node, ll tl, ll tr, ll new_val, ll old_val, ll idx)
{
    if(tl > idx || tr < idx) return;
    if(tr == tl)
    {
        tree[node].clear();
        tree[node].push_back({new_val,idx});
        sum[node] = new_val;
        return;
    }
    ll mid = (tl+tr)/2;
    update(node*2, tl, mid, new_val, old_val, idx);
    update(node*2+1, mid+1, tr, new_val, old_val, idx);
    merge_sort(node, tree[node], tree[node*2], tree[node*2+1]);
}
ll query(ll node, ll tl, ll tr, ll l, ll r)
{
    if(tl > r || tr < l) return 0;
    if(tl >= l && tr <= r) return sum[node];
    ll mid = (tl+tr)/2;
    return query(node*2, tl, mid, l, r)+query(node*2+1, mid+1, tr, l, r);
}
struct st
{
    ll first;
    ll second;
    st() {}
    st(pair<ll,ll> pp)
    {
        first = pp.second;
        second = pp.first;
    }
};
bool cmp(st e1, st e2)
{
    if(e1.second == e2.second)
    {
        return e1.first > e2.first;
    }
    return e1.second < e2.second;
}
void cut(int l, int r, int k)
{
    node_idx.clear();
    find_node_idx(1,1,n,l,r);
    vector< pair<ll,ll> > arr;
    vector< pair<ll,ll> > lz;
    for(int i=0; i<node_idx.size(); i++)
    {
        merge_sort((-1), arr, lz, tree[node_idx[i].first]);
        lz = arr;
    }
    lz.clear();
    vector< pair<pair<ll,ll>,ll > > to_update;
    if(arr.size() == 1)
    {
        pair<ll,ll> tmp = *arr.rbegin();
        ll new_v = max(tmp.first-k,0LL);
        to_update.push_back({{new_v, tmp.first}, tmp.second});
    }
    else
    {
        ll br = 0;
        ll suff = 0;
        vector< pair<ll,ll> >::reverse_iterator it = arr.rbegin();
        vector<st> leftmost2;
        ll br_it = arr.size();
        ll new_val, ost;
        while( br_it > 0 )
        {
            if(suff-(((*it).first)*br) >= k)
            {
                new_val = (suff-k)/br;
                ost = (suff-k)%br;
                break;
            }
            else
            {
                leftmost2.push_back(make_pair((*it).second,(*it).first));
                suff+=(*it).first;
                br++;
            }
            br_it--;
            it++;
        }
        sort(leftmost2.begin(), leftmost2.end(), cmp);
        if( br_it == 0 )
        {
            if(suff >= k)
            {
                new_val = (suff-k)/br;
                ost = (suff-k)%br;
            }
            else
            {
                new_val = 0;
                ost = 0;
            }
        }
        for(ll i=br-1; i>=br-ost; i--)
        {
            to_update.push_back({{new_val+1,leftmost2[i].first},leftmost2[i].second});
        }
        for(ll i=br-ost-1; i>=0; i--)
        {
            to_update.push_back({{new_val,leftmost2[i].first},leftmost2[i].second});
        }
        for(auto x: to_update)
        {
            a[x.second] = x.first.first;
            update(1,1,n,x.first.first,x.first.second,x.second);
        }
        leftmost2.clear();
    }
    arr.clear();
    to_update.clear();
}
void magic(int i, int x)
{
    update(1,1,n,x,a[i],i);
    a[i] = x;
}
ll inspect(int l, int r)
{
    return query(1,1,n,l,r);
}
void initialise(int N, int Q, int h[])
{
    n = N;
    for(ll i=1; i<=N; i++) a[i] = h[i];
    build(1,1,n);
}
