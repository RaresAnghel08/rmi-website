/**
* user:  babin-880
* fname: Aleksandr
* lname: Babin
* task:  Weirdtree
* score: 100.0
* date:  2021-12-17 08:52:28.088112
*/
#include <bits/stdc++.h>

#include "weirdtree.h"

using namespace std;
using ll = long long;

const int N = 3e5+7;
const int C = 1e9+7;

const int IMN = numeric_limits<int>::min() / 2;
const int IMX = numeric_limits<int>::max() / 2;

int tmax[4*N], tmx2[4*N], tcnt[4*N], tchk[4*N];
int n;
ll tsum[4*N];

void sgt_push(int v) {
	if (tchk[v] != IMX) {
		if (tmax[2*v] > tchk[v]) {
			tsum[2*v] -= tcnt[2*v] * (ll)(tmax[2*v] - tchk[v]);
			tmax[2*v] = tchk[v];
			tchk[2*v] = tchk[v];
		}

		if (tmax[2*v+1] > tchk[v]) {
			tsum[2*v+1] -= tcnt[2*v+1] * (ll)(tmax[2*v+1] - tchk[v]);
			tmax[2*v+1] = tchk[v];
			tchk[2*v+1] = tchk[v];
		}

		tchk[v] = IMX;
	}
}

void update(int v) {
	if (tmax[2*v] < tmax[2*v+1]) {
		tmax[v] = tmax[2*v+1];
		tmx2[v] = max(tmax[2*v], tmx2[2*v+1]);
		tcnt[v] = tcnt[2*v+1];
	} else if (tmax[2*v] > tmax[2*v+1]) {
		tmax[v] = tmax[2*v];
		tmx2[v] = max(tmx2[2*v], tmax[2*v+1]);
		tcnt[v] = tcnt[2*v];
	} else {
		tmax[v] = tmax[2*v];
		tmx2[v] = max(tmx2[2*v], tmx2[2*v+1]);
		tcnt[v] = tcnt[2*v] + tcnt[2*v+1];
	}

	tsum[v] = tsum[2*v] + tsum[2*v+1];
}

void sgt_set_height(int v, int vl, int vr, int i, int x) {
	if (vl + 1 == vr) {
		tmax[v] = tsum[v] = x;
		tchk[v] = IMX;
	} else {
		sgt_push(v);
		int vm = (vl + vr) / 2;
		if (i < vm) sgt_set_height(2*v,   vl, vm, i, x);
		else 		sgt_set_height(2*v+1, vm, vr, i, x);
		update(v);
	}
}

array<int, 3> res;

void sgt_get_information(int v, int vl, int vr, int l, int r) {
	if (l <= vl && vr <= r) {
		if (tmax[v] >= res[0]) {
			if (tmax[v] > res[0]) {
				res[1] = res[0];
				res[0] = tmax[v];
				res[2] = 0;
			}

			res[2] += tcnt[v];
			res[1] = max(res[1], tmx2[v]);
		} else {
			res[1] = max(res[1], tmax[v]);
		}
	} else if (r <= vl || vr <= l) {
		// nope :)
	} else {
		sgt_push(v);
		int vm = (vl + vr) / 2;
		sgt_get_information(2*v,   vl, vm, l, r);
		sgt_get_information(2*v+1, vm, vr, l, r);
	}
}

void sgt_ckmin(int v, int vl, int vr, int l, int r, int x) {
	if (tmax[v] <= x) return;
	if (l <= vl && vr <= r && tmx2[v] < x) {
		tsum[v] -= (ll) (tmax[v] - x) * tcnt[v];
		tchk[v] = tmax[v] = x;
	} else if (r <= vl || vr <= l) {
		// nope :)
	} else {
		int vm = (vl + vr) / 2;
		sgt_push(v);
		sgt_ckmin(2*v,   vl, vm, l, r, x);
		sgt_ckmin(2*v+1, vm, vr, l, r, x);
		update(v);
	}
}

int sgt_right_bound(int v, int vl, int vr, int l, int x, int& k) {
	if (tmax[v] < x || vr <= l) return 0;

	if (l <= vl && tcnt[v] <= k && tmax[v] == x) {
		k -= tcnt[v];
		return vr;
	} else {
		int vm = (vl + vr) / 2;

		sgt_push(v);
		int bound = sgt_right_bound(2*v, vl, vm, l, x, k);
		if (!k) return bound;
		return sgt_right_bound(2*v+1, vm, vr, l, x, k);
	}
}

void sgt_build(int v, int vl, int vr, int h[]) {
	tchk[v] = IMX;
	if (vl + 1 == vr) {
		tmax[v] = h[vr];
		tmx2[v] = IMN;
		tsum[v] = h[vr];
		tcnt[v] = 1;
	} else {
		int vm = (vl + vr) / 2;
		sgt_build(2*v, vl, vm, h);
		sgt_build(2*v+1, vm, vr, h);
		update(v);
	}

	// cout << vl << "; " << vr << " ==> " << tsum[v] << endl;
}

ll sgt_sum(int v, int vl, int vr, int l, int r) {
	if (l <= vl && vr <= r) {
		return tsum[v];
	} else if (r <= vl || vr <= l) {
		return 0;
	} else {
		sgt_push(v);
		int vm = (vl + vr) / 2;
		return sgt_sum(2*v, vl, vm, l, r) + sgt_sum(2*v+1, vm, vr, l, r);
	}
}

void initialise(int N, int Q, int h[]) {
	n = N;
	sgt_build(1, 0, n, h);
}
void cut(int l, int r, int k) {
	--l;
	// cout << "cut " << l << ", " << r << ", k=" << k << endl;
	while (k != 0) {
		res[0] = res[1] = IMN;
		res[2] = 0;
		sgt_get_information(1, 0, n, l, r);


		// cout << "cut [" << l << ", " << r << ") ==> " << res[0] << " :" << res[1] << " : " << res[2] << ", k=" << k << endl;

		if (res[0] == 0) break;

		if (res[0] - k / res[2] <= max(0, res[1])) {
			sgt_ckmin(1, 0, n, l, r, max(0, res[1]));
			k -= res[2] * (res[0] - max(0, res[1]));
		} else {
			int x = res[0] - k / res[2];
			if (x != res[0]) sgt_ckmin(1, 0, n, l, r, x);

			k %= res[2];
			if (k != 0) {
				int t = sgt_right_bound(1, 0, n, l, x, k);
				sgt_ckmin(1, 0, n, l, t, x - 1);
			}
			break;
		}
	}
}

void magic(int i, int x) {
	sgt_set_height(1, 0, n, i-1, x);
}
long long int inspect(int l, int r) {
	return sgt_sum(1, 0, n, l-1, r);
}
