/**
* user:  talipov-208
* fname: Islam Iliasovich
* lname: Talipov
* task:  Paths
* score: 36.0
* date:  2021-12-17 10:13:55.075602
*/
#define _GLIBCXX_DEBUG

#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <algorithm>
#include <numeric>

//#define AIDAR ASADULLIN
#define int long long
#define ll long long
#define all(v) v.begin(), v.end()

using namespace std;

const ll MOD = 1e9 + 7;
const int MAXN = 2000 + 1;
const int MAXK = 2000 + 1;


vector<pair<int, ll>> graph[MAXN];
ll dp[MAXN][MAXK];
int sz[MAXN];

int k;

void dfs(int v, int p) {
    int children = 0;
    for (auto e: graph[v]) {
        int u = e.first;
        ll c = e.second;
        if (u != p) {
            children++;
            dfs(u, v);
            sz[v] += sz[u];
        }
    }
    if (children == 0) sz[v]++;
    for (auto e: graph[v]) {
        int u = e.first;
        ll c = e.second;
        if (u == p) continue;
        for (int k1 = min(k, sz[v]); k1 >= 1; --k1) {
            for (int k2 = 1; k2 <= min({k, sz[u], k1}); ++k2) {
                dp[v][k1] = max(dp[v][k1], dp[v][k1 - k2] + (k2 != 0 ? c : 0ll) + dp[u][k2]);
            }
        }
    }
}

void mv_down(int f, int s) {
    sz[f] = sz[f] - sz[s] + (graph[f].size() == 1);
    sz[s] += sz[f] - (graph[s].size() == 1);
    for (int k1 = 0; k1 <= min(k, sz[f]); ++k1) {
        dp[f][k1] = 0;
    }
    for (int k1 = 0; k1 <= min(k, sz[s]); ++k1) {
        dp[s][k1] = 0;
    }
    for (auto e: graph[f]) {
        int u = e.first;
        ll c = e.second;
        if (u == s) continue;
        for (int k1 = min(k, sz[f]); k1 >= 1; --k1) {
            for (int k2 = 1; k2 <= min({k, sz[u], k1}); ++k2) {
                dp[f][k1] = max(dp[f][k1], dp[f][k1 - k2] + (k2 != 0 ? c : 0ll) + dp[u][k2]);
            }
        }
    }
    for (auto e: graph[s]) {
        int u = e.first;
        ll c = e.second;
        for (int k1 = min(k, sz[s]); k1 >= 1; --k1) {
            for (int k2 = 1; k2 <= min({k, sz[u], k1}); ++k2) {
                dp[s][k1] = max(dp[s][k1], dp[s][k1 - k2] + (k2 != 0 ? c : 0ll) + dp[u][k2]);
            }
        }
    }
}

int ans[MAXN];

void dfs_mv(int v, int p) {
    ans[v] = dp[v][min(k, sz[v])];
    for (auto e: graph[v]) {
        int u = e.first;
        ll c = e.second;
        if (u != p) {
            mv_down(v, u);
            dfs_mv(u, v);
        }
    }
    if (p != -1)
        mv_down(v, p);
}


signed main() {
    srand(time(0));
    cin.tie(0);
    ios::sync_with_stdio(false);
    int n;
    cin >> n >> k;
    for (int i = 1; i < n; ++i) {
        int x, y;
        ll c;
        cin >> x >> y >> c;
        --x, --y;
        graph[x].emplace_back(y, c);
        graph[y].emplace_back(x, c);
    }
    dfs(0, -1);
    dfs_mv(0, -1);
    for (int i = 0; i < n; ++i) cout << ans[i] << "\n";
}