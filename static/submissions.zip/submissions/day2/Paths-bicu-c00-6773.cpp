/**
* user:  bicu-c00
* fname: Eduard Codruț
* lname: Bicu
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:15:14.073375
*/
#include <bits/stdc++.h>
#define f cin
#define g cout
#define DIM 200005
#define LOG 17

using namespace std;

int n, k, up[DIM][LOG + 1], sum[DIM][LOG + 1], depth[DIM], d[DIM];
vector <pair <int, int>> edges[DIM];
vector <int> frunze;

void dfs(int nod, int tata)
{
    for (auto child : edges[nod])
        if (child.first != tata)
        {
            d[child.first] = d[nod] + child.second;
            depth[child.first] = depth[nod] + 1;
            up[child.first][0] = nod;
            sum[child.first][0] = child.second;
            for (int i = 1; i <= LOG; i++)
            {
                up[child.first][i] = up[up[child.first][i - 1]][i - 1];
                sum[child.first][i] = sum[child.first][i - 1] + sum[up[child.first][i - 1]][i - 1];
            }

            dfs(child.first, nod);
        }
}


int lca(int a, int b)
{
    int nod = 0;
    int cost = 0;
    if (depth[a] < depth[b])
        swap(a, b);
    int k = depth[a] - depth[b];
    for (int i = LOG; i >= 0; i--)
        if (k & (1 << i))
        {
            cost += sum[a][i];
            a = up[a][i];
        }

    for (int i = LOG; i >= 0; i--)
        if (up[a][i] != up[b][i])
        {
            cost += sum[a][i] + sum[b][i];
            a = up[a][i];
            b = up[b][i];
        }

    nod = up[a][0];
    cost += sum[a][0] + sum[b][0];
    return nod;
}

int main()
{
    f >> n >> k;

    for (int i = 1; i < n; i++)
    {
        int x, y, c;
        f >> x >> y >> c;
        edges[x].push_back(make_pair(y, c));
        edges[y].push_back(make_pair(x, c));
    }

    depth[1] = 1;
    dfs(1, 0);

    for (int i = 1; i <= n; i++)
        if (edges[i].size() == 1)
            frunze.push_back(i);

    for (int i = 1; i <= n; i++)
    {
        int maxi = 0;
        for (auto nod: frunze)
        {
            int LCA = lca(i, nod);
            if (LCA != 1)
                maxi = max(maxi, d[nod] + d[i] - d[LCA]);
            else
                maxi = max(maxi, d[nod] + d[i]);
        }
        g << maxi << "\n";
    }



    return 0;
}
