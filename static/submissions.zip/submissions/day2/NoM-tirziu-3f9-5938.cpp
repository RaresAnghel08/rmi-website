/**
* user:  tirziu-3f9
* fname: Petre
* lname: Tirziu
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:12:31.048781
*/
#include <iostream>

using namespace std;
int cnt = 0, n, m;
int f[10], ans[115];
void backt(int poz)
{
    int i, j;
    if(poz == 2 * n + 1){
        bool ok = true;
        for(i = 1; i <= 2 * n; i += m){
            for(j = i - m; j >= 1; j -= m)
                if(ans[j] == ans[i]){
                    ok = false;
                    break;
                }
            if(ok == false)
                break;
        }
        if(ok == true)
            cnt++;
    }
    for(i = 1; i <= n; i++)
        if(f[i] <= 1){
            ans[poz] = i;
            f[i]++;
            backt(poz + 1);
            f[i]--;
            ans[poz] = 0;
        }
}
int main()
{
    int i;
    cin >> n >> m;
    backt(1);
    cout << cnt;
    return 0;
}
