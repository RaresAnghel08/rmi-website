/**
* user:  ralnikov-364
* fname: Paul
* lname: Ralnikov
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 09:19:34.810409
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
#define f first
#define s second
#define _ << ' ' <<
#define mp make_pair
#define sz(x) (int)x.size()
#define all(x) x.beign(), x.end()

#ifdef LOCAL
	#define cerr cout
#else
	#define cerr if (0) cout
#endif

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;

const int MAXN = 8e4 + 10;

int a[MAXN];
int p[MAXN];
int n;

void initialise(int N, int Q, int h[]) {
	// Your code here.
	n = N;
	for (int i = 0; i < n; i++) a[i] = h[i + 1];
}

bool cmp(int i, int j) {
	return mp(a[i], -i) > mp(a[j], -j);
}

void cut(int l, int r, int k) {
	l--, r--;
	int len = r - l + 1;
	iota(p, p + len, l);
	sort(p, p + len, cmp);
	int cnt = 1, m = a[p[0]], delt, c = 0;
	for (int i = 1; i < len; i++) {
		delt = m - a[p[i]];
		if (k >= 1ll * delt * cnt) {
			k -= delt * cnt;
			cnt++;
			m -= delt;
		} else {
			delt = k / cnt;
			m -= delt;
			c = k % cnt;
			k = 0;
			break;
		}
	}
	if (k != 0) {
		m -= k / cnt;
		m = max(0, m);
		c = k % cnt;
		//cerr << "cnt" _ cnt _ "m" _ m _ "c" _ c _ "k" _ k<< endl;
		for (int i = l; i <= r; i++) {
			a[i] = m;
			if (i < c) a[i] = max(0, a[i] - 1);
		}
	} else {
		//cerr << "cnt" _ cnt _ "m" _ m _ "c" _ c _ "k" _ k<< endl;
		for (int i = 0; i < cnt; i++) {
			a[p[i]] = m;
		}
		if (c == 0) return;
		for (int i = l; i <= r; i++) {
			if (a[i] == m) {
				a[i] = max(0, a[i] - 1);
				if (--c == 0) break;
			}
		}
	}
	// cerr << "aftex cut" << endl;
	// for (int i = 0; i< n; i++) cout << a[i] << ' ';
	// cout << endl;
}
void magic(int i, int x) {
	i--;
	a[i] = x;
}
long long int inspect(int l, int r) {
	ll ans = 0;
	l--, r--;
	for (int i = l; i <= r; i++) ans += a[i];
	return ans;
}
