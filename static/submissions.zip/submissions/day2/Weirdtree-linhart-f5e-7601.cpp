/**
* user:  linhart-f5e
* fname: Yoav
* lname: Linhart
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:59:16.329334
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <queue>
#include <map>
#include "weirdtree.h"

#define upmin(a, b) if(a > b) a = b
#define upmax(a, b) if(a < b) a = b
#define pr(x) cout << x << endl
#define wpr(x) cout << #x << ": " << x << endl
#define spr(x) cout << x << " "
#define wspr(x) cout << #x << ": " << x << " "
#define prv(x) for(auto it : x) cout << it << " "; cout << endl
#define wprv(x) cout << #x << ": " << endl; for(auto it : x) cout << it << " "; cout << endl
#define wprvv(x) cout << #x << ": " << endl for(auto it : x) { for(auto it : it) cout << it2 << " "; cout << endl}

#define rep(i, s, e) for(ll i = s; i < e; i++)
#define repr(i, s, e) for(ll i = e - (ll)1; i >= s; i--)



using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vvvll = vector<vvll>;
using pll = pair<ll, ll>;
using vpll = vector<pll>;
using vvpll = vector<vpll>;
using vb = vector<bool>;
using vvb = vector<vb>;
using vi = vector<int>;

ll n, q;
vll h;

bool comp(pll p1, pll p2) {
	if (p1.first > p2.first) return true;
	if (p1.first < p2.first) return false;
	return p1.second > p2.second;
}


void initialise(int N, int Q, int H[]) {
	n = N, q = Q;
	h.resize(n);
	rep(i, 0, n) h[i] = H[i + 1];
}
void cut(int l, int r, int k) {
	l--, r--;
	//wprv(h);
	//wspr(l); wspr(r); wpr(k);
	vpll sorted(r - l + 1);
	rep(i, l, r + 1) {
		sorted[i - l] = { h[i], i };
	}
	sort(sorted.rbegin(), sorted.rend(), comp);

	vll sub(r - l + 1, 0); // denotes a suffix array of how much to substract from each one

	rep(i, 0, r - l + 1) {
		ll dif = sorted[i].first;
		if (i < r - l) dif -= sorted[i + 1].first;
		if ((i + 1) * dif >= k) {
			ll add = k / (i + 1);
			ll left = k % (i + 1);
			sub[i] += add;
			if (left > 0) sub[left - (ll)1]++;
			k = 0;
			break;
		}
		//wpr(dif);
		k -= (i + 1) * dif;
		sub[i] += dif;
	}
	//wprv(sub);
	ll subsum = 0;
	//wpr(r - l + 1);
	repr(i, 0, r - l + 1) {
		//pr("hiiii");
		subsum += sub[i];
		//wpr(subsum);
		h[sorted[i].second] -= subsum;
		upmax(h[sorted[i].second], (ll)0);
	}
	//wprv(h);
}
void magic(int i, int x) {
	i--;
	h[i] = x;
}
long long int inspect(int l, int r) {
	l--, r--;
	ll sum = 0;
	rep(i, l, r + 1) {
		sum += h[i];
	}
	return sum;
}


/*

6 10
1 2 3 1 2 3
1 1 6 3
3 1 6
1 1 3 3
3 1 6
1 1 3 1000
3 1 6
2 1 1000
3 1 6
1 1 3 999
3 1 5


*/	