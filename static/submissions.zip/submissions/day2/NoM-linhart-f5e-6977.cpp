/**
* user:  linhart-f5e
* fname: Yoav
* lname: Linhart
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:28:46.124204
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <queue>
#include <map>

#define upmin(a, b) if(a > b) a = b
#define upmax(a, b) if(a < b) a = b
#define pr(x) cout << x << endl
#define wpr(x) cout << #x << ": " << x << endl
#define spr(x) cout << x << " "
#define wspr(x) cout << #x << ": " << x << " "
#define prv(x) for(auto it : x) cout << it << " "; cout << endl
#define wprv(x) cout << #x << ": " << endl; for(auto it : x) cout << it << " "; cout << endl
#define wprvv(x) cout << #x << ": " << endl for(auto it : x) { for(auto it : it) cout << it2 << " "; cout << endl}

#define rep(i, s, e) for(ll i = s; i < e; i++)
#define repr(i, s, e) for(ll i = e - (ll)1; i >= s; i--)



using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vvvll = vector<vvll>;
using pll = pair<ll, ll>;
using vpll = vector<pll>;
using vvpll = vector<vpll>;
using vb = vector<bool>;
using vvb = vector<vb>;
using vi = vector<int>;


void solve()
{
	ll n, m;
	cin >> n >> m;
	vpll arr(2 * n);
	rep(i, 0, n) {
		arr[2 * i] = { i, 0 };
		arr[2 * i + 1] = { i, 1 };
	}
	ll cnt = 0;
	do {
		//wprv(arr);
		/*
		rep(i, 0, 2 * n) {
			cout << "{" << arr[i].first << ", " << arr[i].second << "} " << endl;
		}
		*/
		vpll have(n, { -1, -1 });
		rep(i, 0, 2 * n) {
			if (have[arr[i].first].first == -1) have[arr[i].first].first = i;
			else have[arr[i].first].second = i;
		}
		bool ok = true;
		rep(i, 0, n) {
			if (abs(have[i].first - have[i].second) % m == 0) ok = false;
		}
		if (ok) cnt++;
	} while (next_permutation(arr.begin(), arr.end()));
	pr(cnt);
}


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	solve();
}
