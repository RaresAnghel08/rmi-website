/**
* user:  savu-e4c
* fname: Ştefan Cătălin
* lname: Savu
* task:  Paths
* score: 19.0
* date:  2021-12-17 10:05:51.847066
*/
#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
int n,k,i,x,y,val,j,ma,kk,t[2005],eul[4005],cnt,first[2005],last[2005],mat[1005][1005],ii;
pair<long long ,int > ar[10005],ma2;
vector <pair<int ,int > >v[2005];
long long lazy[10005],sum;
void upd(int st,int dr,int nod)
{
    lazy[nod]=0;
    ar[nod].second=eul[st];
    ar[nod].first=0;
    if (st==dr) return ;
    int mij=(st+dr)/2;
    upd(st,mij,nod*2);
    upd(mij+1,dr,nod*2+1);
}
void propag(int nod)
{
    lazy[nod*2]+=lazy[nod];
    lazy[nod*2+1]+=lazy[nod];
    ar[nod].first+=lazy[nod];
    lazy[nod]=0;
}
pair<long long,int> my(pair<long long,int> a,pair<long long,int> b)
{
    if (a.first>b.first) return a;
    return b;
}
void update(int st,int dr,int nod,int qa,int qb,int val)
{
    propag(nod);
    if (qa<=st&&dr<=qb)
    {
        lazy[nod]+=val;
        propag(nod);
        return;
    }
    int mij=(st+dr)/2;
    propag(nod*2);
    propag(nod*2+1);
    if (qa<=mij) update(st,mij,nod*2,qa,qb,val);
    if (qb>mij) update(mij+1,dr,nod*2+1,qa,qb,val);
    ar[nod]=my(ar[nod*2],ar[nod*2+1]);
}
void dfs(int nod,int tata,int lvl)
{
    t[nod]=tata;
    eul[++cnt]=nod;
    first[nod]=cnt;
    last[nod]=cnt;
    for (int i=0;i<v[nod].size();++i)
        if (v[nod][i].first!=tata)
            dfs(v[nod][i].first,nod,lvl+1);
    last[nod]=cnt;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>k;
    for (i=1;i<n;++i)
    {
        cin>>x>>y>>val;
        v[x].push_back({y,val});
        v[y].push_back({x,val});
        mat[x][y]=mat[y][x]=val;
    }
    for (ii=1;ii<=n;++ii)
    {
        cnt=0;
        dfs(ii,0,1);
        memset(ar,0,sizeof(ar));
        memset(lazy,0,sizeof(lazy));
        upd(1,n,1);
        for (j=1;j<=n;++j)
            if (t[j]) update(1,n,1,first[j],last[j],mat[j][t[j]]);
        sum=0;
        for (j=1;j<=k;++j)
        {
            propag(1);
            sum+=ar[1].first;
            ma=ar[1].second;
            while (ma!=ii)
            {
                if (mat[ma][t[ma]]==0) break;
                update(1,n,1,first[ma],last[ma],(-1)*mat[ma][t[ma]]);
                mat[ma][t[ma]]=mat[t[ma]][ma]=0;
                ma=t[ma];
            }
        }
        cout<<sum<<'\n';
        for (j=1;j<=n;++j)
            for (kk=0;kk<v[j].size();++kk)
                mat[j][v[j][kk].first]=mat[v[j][kk].first][j]=v[j][kk].second;
    }
    return 0;
}
///1 2 3 4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1
///  2 3 4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2
///    3 4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2 3
///      4 3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2 3 4
///        3 5 3 2 6 2 1 7 8 7 9 7 1 10 11 10 1 2 3 4 3
