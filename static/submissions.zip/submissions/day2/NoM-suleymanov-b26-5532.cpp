/**
* user:  suleymanov-b26
* fname: Karam
* lname: Suleymanov
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:39:02.047052
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

int cnt = 0;

void qwe(vector<int> a, int m, int i, int n, int x) {
    a[i - 1] = x;
    if (i == n - 1) {
        cnt += 2;
        return;
    }
    for (int p = 1; p <= n; p++) {
        bool f = false;
        for (int j = i - m; j >= 0; j -= m) {
            if (a[j] == p) {
                f = true;
                break;
            }
        }
        if (!f) {
            qwe(a, m, i + 1, n, p);
        }
    }
}

void solve() {
    int n, m;
    cin >> n >> m;
    vector<int> a(n);
    for (int p = 1; p <= n; p++) {
        qwe(a, m, 1, n, p);
    }
    cout << cnt;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);

    int t = 1;
//    cin >> t;
    while (t--) solve();

    return 0;
}