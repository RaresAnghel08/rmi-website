/**
* user:  ralnikov-364
* fname: Paul
* lname: Ralnikov
* task:  Paths
* score: 36.0
* date:  2021-12-17 08:21:48.236247
*/
#include<bits/stdc++.h>
#define f first
#define s second
#define _ << ' ' <<
#define mp make_pair
#define sz(x) (int)x.size()
#define all(x) x.beign(), x.end()

#ifdef LOCAL
	#define cerr cout
#else
	#define cerr if (0) cout
#endif

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;

const int MAXN = 2e3 + 10, MAXM = MAXN * 4;

vector<pii> g[MAXN];

ll dst[MAXN];
int par[MAXN], wp[MAXN], tin[MAXN], tout[MAXN], rtin[MAXM];
ll tree[MAXM], add[MAXM];
bool used[MAXN];
int nowt = 0;

void predfs(int v, int p, int wpp) {
	int to, w;
	wp[v] = wpp;
	par[v] = p;
	tin[v] = nowt;
	rtin[nowt] = v;
	nowt++;
	for (auto e : g[v]) {
		to = e.f, w = e.s;
		if (to == p) continue;
		dst[to] = dst[v] + w;
		predfs(to, v, w);
	}
	tout[v] = nowt++;
}

void upd(int v, ll val) {
	add[v] += val;
	tree[v] += val;
}

void push(int v) {
	upd(v * 2 + 1, add[v]);
	upd(v * 2 + 2, add[v]);
	add[v] = 0;
}

void build(int v, int l, int r) {
	if (l == r - 1) {
		tree[v] = (rtin[l] == -1 ? 0 : dst[rtin[l]]);
		add[v] = 0;
		return;
	}
	int m = (l + r) / 2;
	build(v * 2 + 1, l, m);
	build(v * 2 + 2, m, r);
	tree[v] = max(tree[v * 2 + 1], tree[v * 2 + 2]);
	add[v] = 0;
}

void update(int v, int l, int r, int ql, int qr, int val) {
	if (ql <= l && r <= qr) {
		upd(v, val);
		//cerr << "!!!!!! update ok" _ v _ l _ r - 1 _ val << endl;
		return;
	}
	if (l >= qr || ql >= r) return;
	int m = (l + r) / 2;
	push(v);
	update(v * 2 + 1, l, m, ql, qr, val);
	update(v * 2 + 2, m, r, ql, qr, val);
	tree[v] = max(tree[v * 2 + 1], tree[v * 2 + 2]);
}

pair<int, ll> getMax(int v, int l, int r) {
	if (l == r - 1) return {l, tree[v]};
	push(v);
	//cerr << "---getMax" _ v _ l _ r - 1 _ tree[v] _ tree[v * 2 + 1] _ tree[v * 2 + 2] << endl;
	int m = (l + r) / 2;
	if (tree[v * 2 + 1] > tree[v * 2 + 2]) return getMax(v * 2 + 1, l, m);
	return getMax(v * 2 + 2, m, r);
}

void solve() {
	int n, k;
	cin >> n >> k;
	int v, to, w;
	for (int i = 0; i < n - 1; i++) {
		cin >> v >> to >> w;
		g[--v].push_back({--to, w});
		g[to].push_back({v, w});
	}
	ll ans = 0;
	pair<int, ll> tmp;
	ll d;
	for (int root = 0; root < n; root++) {
		nowt = 0;
		ans = 0;
		fill(rtin, rtin + n * 2, -1);
		fill(used, used + n, 0);
		dst[root] = 0;
		predfs(root, root, 0);
		build(0, 0, nowt);
		//cerr << "============== root" _ root + 1 << "==============" << endl;
		// for (int i = 0; i < n; i++) {
		// 	cerr << "vert" _ i _ "dst" _ dst[i] _ "tin" _ tin[i] _ "tout" _ tout[i] _ "par" _ par[i] _ "wp" _ wp[i] << endl;
		// }
		//cerr << "rtin" << endl;
		//for (int i = 0; i < nowt; i++) cerr << i _ rtin[i] + 1 _ tin[rtin[i]]<< endl;
		//cerr << endl;
		for (int i = 0; i < k; i++) {
			tmp = getMax(0, 0, nowt);
			v = rtin[tmp.f], d = tmp.s;
			//cerr << "vertex" _ v + 1 _ d _ tin[v] _ tout[v] - 1<< endl;
			ans += d;
			while (!used[v]) {
				//cerr << "updated" _ v + 1 _ wp[v] _ tin[v] _ tout[v] - 1<< endl;
				used[v] = 1;
				update(0, 0, nowt, tin[v], tout[v], -wp[v]);
				v = par[v];
			}
			//cerr << "end upd" << endl;
		}
		cout << ans << '\n';
	}
}

signed main() {
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int tests = 1;
	//cin >> tests;
	while (tests--) {
		solve();
	}
}