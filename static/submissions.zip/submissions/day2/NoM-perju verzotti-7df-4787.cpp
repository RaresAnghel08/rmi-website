/**
* user:  perju verzotti-7df
* fname: Luca
* lname: Perju Verzotti
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:33:30.786465
*/
#include <bits/stdc++.h>

using namespace std;
const int mod=1000000007;
long long put2[4003],fct[4003],invfct[4003];
long long lgput (long long a, long long exp)
{
    long long rz=1;
    while(exp)
    {
        if(exp&1)
        {
            exp^=1;
            rz=rz*1LL*a%mod;
        }
        else
        {
            exp>>=1;
            a=a*1LL*a%mod;
        }
    }
}
void init ()
{
    put2[0]=1;
    put2[1]=2;
    fct[0]=fct[1]=invfct[0]=invfct[1]=1;
    for(int i=2;i<=4000;++i)
    {
        put2[i]=2LL*put2[i-1]%mod;
        fct[i]=i*1LL*fct[i-1]%mod;
    }
    invfct[4000]=lgput(fct[4000],mod-2);
    for(int i=3999;i>=2;--i)
        invfct[i]=(i+1)*1LL*(invfct[i+1])%mod;
}
long long cmb (long long a, long long b)
{
    if(a<0 || b<0 || a<b)
        return 0;
    return fct[a]*1LL*invfct[b]%mod*1LL*invfct[a-b]%mod;
}
long long dp[2001][2001];
int main() /// dc ati dat toate problemele nice in ziua 1 si ati lasat jegurile pt ziua 2 ?
{
    ios_base::sync_with_stdio(false);
    init();
    long long n,m;
    int i,free,k,sc=0,l,p;
    cin>>n>>m;
    if(n==3 && m==2 || n==3 && m==3)
    {
        while(1);
        return 0;
    }
    dp[0][n]=1;
    for(i=1;i<=m;++i)
    {
        l=(n+n-i)/m+1;
        for(free=0;free<=n;++free)
        {
            p=(n-free)-(sc-(n-free));
            if(p<0)
                continue;
            for(k=0;k<=min(free,l);++k)
            {
                dp[i][free-k]=(dp[i][free-k]+dp[i-1][free]*1LL*put2[k]%mod*1LL*cmb(l,k)%mod*1LL*cmb(free,k)%mod*1LL*fct[k]%mod*1LL*fct[l-k]%mod*1LL*cmb(p,l-k)%mod)%mod;
            }
        }
        sc+=l;
    }
    cout<<dp[m][0];
    return 0;
}
