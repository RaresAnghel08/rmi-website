/**
* user:  fares-9ed
* fname: Yusuf
* lname: Fares
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:34:03.784213
*/
#include <bits/stdc++.h>
#define NMAX 2000
#define int64 long long
#define int long long

using namespace std;

struct strmuchie {
  int price;
  int son;
};

struct strsort {
  int val, index;
};

struct hatz {
  int index, level;
};

bool f[NMAX + 1];
int vlevel1[NMAX + 1];
strsort vlevel[NMAX + 1];
int vtata[NMAX + 1];
int64 vprice[NMAX + 1];
vector <strmuchie> vsons[NMAX + 1];
vector <hatz> veuclid;
int vlog2[100000];
int vpoz[NMAX + 1];
hatz vrmq[100000 + 1][100];
vector <int> v[NMAX + 1];

void dfs(int node, int price, int level) {
  int n, i;

  vlevel[node].val = level;
  vlevel[node].index = node;

  veuclid.push_back({node, level});
  vpoz[node] = veuclid.size() - 1;

  v[level].push_back(node);

  f[node] = 1;
  vprice[node] = price;
  vlevel1[node] = level;
  vlevel[node].val = level;
  vlevel[node].index = node;
  n = vsons[node].size();
  for (i = 0; i < n; i++) {
    if (f[vsons[node][i].son] == 0) {
      vtata[vsons[node][i].son] = node;
      dfs(vsons[node][i].son, price + vsons[node][i].price, level + 1);
      veuclid.push_back({node, level});
    }
  }
}

bool cmp(strsort A, strsort B) {
  return A.val < B.val;
}

hatz minim(hatz A, hatz B) {
  return A.level < B.level ? A : B;
}

void prec_rmq() {
  int n = veuclid.size(), i, j;

  vlog2[0] = -1;
  for (i = 1; i <= n; i++)
    vlog2[i] = (vlog2[i / 2] + 1);

  for (i = 0; i < n; i++)
    vrmq[i][0] = {veuclid[i].index, veuclid[i].level};
  for (j = 1; j <= vlog2[n]; j++) {
    for (i = 0; i + (1 << j) - 1 < n; i++) {
      vrmq[i][j] = minim(vrmq[i][j - 1], vrmq[i + (1 << (j - 1))][j - 1]);
    }
  }
}

int lca(int node1, int node2) {
  int left, right, dif;
  left = min(vpoz[node1], vpoz[node2]);
  right = max(vpoz[node1], vpoz[node2]);
  dif = right - left + 1;

  hatz ceva = minim(vrmq[left][vlog2[dif]], vrmq[right - (1 << vlog2[dif]) + 1][vlog2[dif]]);
  return ceva.index;
}

signed main() {
  int n, k, x, y, z, node, i, j, root, node1, node2, ck, nodechange, levelmax, val, level;
  int64 max1, sol;
  cin >> n >> k;

  for (i = 0; i < n - 1; i++) {
    cin >> x >> y >> z;
    vsons[x].push_back({z, y});
    vsons[y].push_back({z, x});
  }

  for (root = 1; root <= n; root++) {
    veuclid.clear();
    dfs(root, 0, 1);

    ck = k;
    sol = 0;
    prec_rmq();
    while (ck--) {
      max1 = 0;
      for (i = 1; i <= n; i++) {
        if (vprice[i] > max1) {
          max1 = vprice[i];
          node = i;
          levelmax = vlevel1[i];
        }
        else if (vprice[i] == max1 && vlevel1[i] < levelmax) {
          node = i;
          levelmax = vlevel1[i];
        }
      }
      sol += max1;

      for (level = n; level >= 1; level--) {
        for (i = 0; i < v[level].size(); i++) {
          nodechange = v[level][i];
          val = lca(nodechange,node);
          vprice[nodechange] -= vprice[val];
        }
      }
    }

    cout << sol << "\n";

    for (i = 1; i <= n; i++) {
      vprice[i] = 0, f[i] = 0;
      v[i].clear();
    }
  }
  return 0;
}
