/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:05:38.748313
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast","unroll-loops")
#pragma GCC target("avx","avx2","fma")
#include "weirdtree.h"
using namespace std;
long long v[1001],n,q;
void initialise ( long long N, long long Q, long long h [])
{
    n=N;
    q=Q;
    for(long long i=1; i<=n; i++)
        v[i]=h[i];
}
long long suma(long long sus,long long st,long long dr)
{
    long long s=0;
    for(long long i=st;i<=dr;i++)
        s+=max(v[i]-sus,0LL);
    if(s<=INT_MAX)
        return s;
    return INT_MAX;
}
pair <long long,long long> cautbin(long long st,long long dr,long long val)
{
    long long r=0,pas=1<<29;
    while(pas)
    {
        if(suma(r+pas,st,dr)>val)
            r+=pas;
        pas/=2;
    }
    return {r+1,val-suma(r+1,st,dr)};
}
void cut ( long long l, long long r, long long k )
{
    pair <long long,long long> ans=cautbin(l,r,k);
    long long ramas=ans.second;
    for(long long i=l;i<=r;i++)
        if(v[i]>=ans.first)
    {
        if(ramas)
        {
            ramas--;
            v[i]=max(ans.first-1,0);
        }
        else
            v[i]=ans.first;
    }
}
void magic(long long i,long long x)
{
    return;
}
long long int inspect ( long long l, long long r )
{
    long long sum=0;
    for(long long i=l;i<=r;i++)
        sum+=v[i];
    return sum;
}
