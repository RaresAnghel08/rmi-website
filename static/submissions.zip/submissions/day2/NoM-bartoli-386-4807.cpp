/**
* user:  bartoli-386
* fname: Davide
* lname: Bartoli
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:35:11.289749
*/
#pragma GCC optimize("O3")
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define pb push_back
#define int ll
const int mod=1e9+7;
int N,M;
vector<int> dim,pref={0};
vector<int> fact;
int pot(int a,int b) {
    if(b==0)
        return 1;
    int x=pot(a,b/2);
    if(b%2)
        return x*x%mod*a%mod;
    return x*x%mod;
}
int bin[2010][2010];
int binom(int a,int b) {
    return fact[b]*pot(fact[a],mod-2)%mod*pot(fact[b-a],mod-2)%mod;
}
bool vis[2010][2010];
int memo[2010][2010];
int solve(int coppie,int pos) {
    int s=N-coppie-(pref[pos]-(N-coppie));
    //cout<<coppie<<" "<<s<<" "<<pos<<" "<<endl;
    if(pos==M-1 && coppie>0)
        return 0;
    if(pos==M-1)
        return fact[dim[pos]];

    if(vis[coppie][pos])
        return memo[coppie][pos];

    vis[coppie][pos]=1;

    int ans=0;
    for(int i=max((int)0,dim[pos]-s); i<=coppie; i++) {
        if(i>dim[pos])
            break;
        //cout<<"i:"<<i<<" "<<dim[pos]<<endl;
        ans+=solve(coppie-i,pos+1)*bin[i][dim[pos]]%mod*bin[dim[pos]-i][s]%mod*fact[dim[pos]-i]%mod;
    }
    //cout<<coppie<<" "<<s<<" "<<pos<<" "<<ans<<endl;
    return memo[coppie][pos]=ans%mod;

}
void bruteforce() {
    vector<int> a;
    for(int i=0; i<2*N; i++) {
        a.pb(i);
    }
    int tot=0;
    while(1) {
        bool ok=1;
        for(int i=0; i<a.size(); i++) {
            for(int j=i+M; j<a.size(); j+=M) {
                if(abs(a[i]-a[j])==N) {
                    ok=0;
                }
            }
        }
        tot+=ok;
        if(!next_permutation(a.begin(),a.end()))
            break;
    }
    cout<<tot<<'\n';

}
signed main() {
    //ios_base::sync_with_stdio(0);
    //cin.tie(0);
    fact.pb(1);
    for(int i=1; i<3000; i++)
        fact.pb(fact[i-1]*i%mod);

    for(int i=0;i<2005;i++){
        for(int j=i;j<2005;j++){
        bin[i][j]=binom(i,j);
        }
    }
    cin>>N>>M;
    for(int i=0; i<M; i++) {
        dim.pb((2*N-i-1)/M+1);
        pref.pb(pref[i]+dim[i]);
        //cout<<dim[i]<<" ";
    }
    //cout<<endl;
    //bruteforce();
    cout<<solve(N,0)*fact[N]%mod*pot(2,N)%mod<<'\n';
}

