/**
* user:  ghiberdic-f48
* fname: David
* lname: Ghiberdic
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:44:38.745683
*/
#include <iostream>
#include <algorithm>
#include <vector>

typedef long long ll;
int const nmax = 100000;
int const pmax = 17;
std::vector <std::pair <int, ll>> adj[nmax + 5];
ll dist[nmax + 5];
int depth[nmax + 5];
int anc[nmax + 5][pmax + 4];
bool isLeaf[nmax + 5];
bool sters[nmax + 5];
std::vector <std::pair <ll, int>> frunze; // dist, nod
std::vector <std::pair <ll, ll>> selected;

void build_lca (int n) {
    for (int put = 1; put <= pmax; put++)
        for (int i = 1; i <= n; i++)
            anc[i][put] = anc[anc[i][put - 1]][put - 1];
}

void rise (int &x, int delta) {
    for (int put = pmax; put >= 0; put--) {
        if ((delta & (1 << put)) != 0)
            x = anc[x][put];
    }
}

int calc_lca (int x, int y) {
    if (depth[x] < depth[y])
        std::swap (x, y);
    rise (x, depth[x] - depth[y]);
    if (x == y)
        return x;
    for (int put = pmax; put >= 0; put--) {
        if (anc[x][put] != anc[y][put]) {
            x = anc[x][put];
            y = anc[y][put];
        }
    }
    return anc[x][0];
}

void dfs (int nod, int p) {
    bool notLeaf = false;
    for (auto x: adj[nod]) {
        if (x.first != p) {
            notLeaf = true;
            dist[x.first] = dist[nod] + x.second;
            depth[x.first] = depth[nod] + 1;
            anc[x.first][0] = nod;
            dfs (x.first, nod);
        }
    }
    if (!notLeaf) {
        frunze.push_back({dist[nod], nod});
        isLeaf[nod] = true;
    }
}

int main() {
    int n, k;
    std::cin >> n >> k;
    for (int i = 1; i < n; i++) {
        int x, y; ll c;
        std::cin >> x >> y >> c;
        adj[x].push_back({y, c});
        adj[y].push_back({x, c});
    }
    depth[1] = 1;
    depth[0] = -1;
    dist[0] = 0;
    dfs (1, 0);
    build_lca (n);
    int frunzeCnt = frunze.size();
    ll kFirstSum = 0, // SUMA PRIMELOR K
    k1th = 0;          // AL K+1-lea numar
    if (k >= frunzeCnt) {
        ll sum = 0;
        for (int i = 1; i <= n; i++)
            for (auto x: adj[i])
                sum += x.second;
        sum >>= 1;
        for (int i = 1; i <= n; i++)
            std::cout << sum << "\n";
        return 0;
    }
    std::sort(frunze.begin(), frunze.end());
    for (int i = 1; i <= k; i++) {
        kFirstSum += frunze[frunzeCnt - 1].first;
        if (!sters[frunze[frunzeCnt - 1].second]) {
            for (int index = 0; index < frunzeCnt - 1; index++)
                frunze[index].first -= dist[calc_lca(frunze[index].second, frunze[frunzeCnt - 1].second)];
            std::sort(frunze.begin(), frunze.end());
        }
        int aux = frunze[frunzeCnt - 1].second;
        selected.push_back({frunze[frunzeCnt - 1].first, aux});
        while (aux != 0) {
            if (sters[aux])
                break;
            sters[aux] = true;
            aux = anc[aux][0];
        }
        frunze.erase(frunze.end());
        frunzeCnt--;
    }
    selected.push_back({frunze[frunzeCnt - 1].first, frunze[frunzeCnt - 1].second});
    std::sort (selected.begin(), selected.end());
    std::vector <ll> aux;
    for (int nod = 1; nod <= n; nod++) {
        aux.clear();
        bool ad = false, re = false; // adauga, remove
        for (int i = k; i >= 0; i--) {
            ll lca = calc_lca(nod, selected[i].second);
            if (lca == 1) {
                if (!ad) {
                    aux.push_back(selected[i].first + dist[nod]);
                    //std::cout << selected[i].first << " " << dist[nod] << "\n";
                    ad = true;
                } else
                    aux.push_back(selected[i].first);
            } else {
                if (!re) {
                    aux.push_back(selected[i].first - dist[lca]);
                    //std::cout << selected[i].first << " " << -dist[lca] << "\n";
                    re = true;
                } else if (selected[i].second == nod)
                    aux.push_back(0);
                else
                    aux.push_back(selected[i].first);
            }
        }
        ll sum = 0;
        std::sort (aux.begin(), aux.end());
        for (int i = 1; i <= k; i++)
            sum += aux[i];
        std::cout << sum << "\n";

        /*
        if (sters[i] && !isLeaf[i])
            std::cout << kFirstSum << "\n";
        else if (sters[i])
            std::cout << kFirstSum + k1th << "\n";
        else
            std::cout << kFirstSum + distToK[i] << "\n";
        */
    }
    return 0;
}
