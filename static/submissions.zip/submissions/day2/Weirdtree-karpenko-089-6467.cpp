/**
* user:  karpenko-089
* fname: Daryna
* lname: Karpenko
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:54:37.674136
*/

#include "weirdtree.h"
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll n,q,d[300007],t[400007],f[300007];

void F(ll x, ll y){
    for(int i=x;i<=n;i+=(i&-i)){
        f[i]+=y;
    }
    return ;
}

ll F1(ll x){
    ll res=0;
    for(int i=x;i>0;i-=(i&-i)){
        res+=f[i];
    }
    return res;
}

void BT(ll x,ll l,ll r){
    if(l==r){
        t[x]=l;
        return ;
    }
    ll m1=(l+r)/2;
    BT(x*2+1,l,m1);
    BT(x*2+2,m1+1,r);
    if(d[t[x*2+1]]>=d[t[x*2+2]]){
        t[x]=t[x*2+1];
    }else t[x]=t[x*2+2];
    return ;
}

ll R(ll x,ll l,ll r,ll tl,ll tr){
    if(tl>r || tr<l){
        return 100000000;
    }
    if(tl<=l && r<=tr)return t[x];
    ll m1=(l+r)/2;
    return min(R(x*2+1,l,m1,tl,tr),R(x*2+2,m1+1,r,tl,tr));
}

void A(ll x,ll l, ll r,ll tl){
    if(tl<l || r<tl)return ;
    if(l==r){
        return ;
    }
    ll m1=(l+r)/2;
    A(x*2+1,l,m1,tl);
    A(x*2+2,m1+1,r,tl);
    if(d[t[x*2+1]]>=d[t[x*2+2]]){
        t[x]=t[x*2+1];
    }else t[x]=t[x*2+2];
}

void initialise(int N, int Q, int h[]) {
	// Your code here.
	n=N;
	q=Q;
	for(int i=1;i<=n;i++){
        d[i]=h[i];
        F(i,d[i]);
	}
	BT(0,1,n);
}
void cut(int l, int r, int k) {
	// Your code here.
	d[l]--;
	F(R(0,1,n,l,r),-1);
	A(0,1,n,R(0,1,n,l,r));
	return ;
}
void magic(int i, int x) {
	// Your code here.
	F(i,x-d[i]);
	d[i]=x;
	A(0,1,n,i);
}
long long int inspect(int l, int r) {
    ll	m=F1(r)-F1(l-1);

	return m;
}

