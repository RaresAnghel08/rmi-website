/**
* user:  mavrodiev-f84
* fname: Tsvetoslav Valentinov
* lname: Mavrodiev
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 10:30:16.288221
*/
#include<bits/stdc++.h>
#define pb push_back
#define ll long long
#define mod 1000000007
using namespace std;

const ll trsz=(1<<20);
ll maxtr[trsz];
ll sumtr[trsz];

ll getleaf(ll x)
{
    return x+(trsz>>1);
}

void upd(ll x,ll d)
{
    ll ind=getleaf(x);
    sumtr[ind]+=d;
    maxtr[ind]+=d; ind>>=1;
    while(ind)
    {
        sumtr[ind]=sumtr[(ind<<1)] + sumtr[(ind<<1)+1];
        maxtr[ind]=max(maxtr[(ind<<1)], maxtr[(ind<<1)+1]);
        ind>>=1;
    }
}

ll getmax(ll l,ll r)
{
    l=getleaf(l);
    r=getleaf(r);
    if(l==r) return l;
    bool isr=0;
    ll maxx=maxtr[l], maxind=l;
    if(maxtr[r]>maxx){maxx=maxtr[r]; maxind=r; isr=1;}
    while((l>>1)!=(r>>1))
    {
        if(!(l&1))
            if(maxtr[l+1]>maxx){maxx=maxtr[l+1]; maxind=l+1; isr=0;}
            else if(isr&&maxtr[l+1]==maxx){maxind=l+1; isr=0;}
        if(r&1)
            if(maxtr[r-1]>maxx){maxx=maxtr[r-1]; maxind=r-1; isr=1;}
        l>>=1;
        r>>=1;
    }
    while(maxind<getleaf(0))
    {
        if(maxtr[(maxind<<1)]==maxx) maxind<<=1;
        else maxind=(maxind<<1)+1;
    }
    return maxind-(trsz>>1);
}

ll getsum(ll l,ll r)
{
    l=getleaf(l);
    r=getleaf(r);
    if(l==r) return sumtr[l];
    ll sum=sumtr[l]+sumtr[r];
    while((l>>1)!=(r>>1))
    {
        if(!(l&1))
            sum+=sumtr[l+1];
        if(r&1)
            sum+=sumtr[r-1];
        l>>=1;
        r>>=1;
    }
    return sum;
}

void initialise(int n, int q, int h[])
{
    for(ll i=0;i<n;i++) upd(i,h[i+1]);
}

void cut(int l, int r, int k)
{
    l--; r--;
    for(int i=0;i<k;i++)
    {
        ll ind=getmax(l,r);
        if(!maxtr[getleaf(ind)]) return;
        upd(ind,-1);
    }
}

void magic(int i, int x)
{
    i--;
    upd(i,1ll*x-sumtr[getleaf(i)]);
}

long long inspect(int l, int r)
{
    l--; r--;
    return getsum(l,r);
}
