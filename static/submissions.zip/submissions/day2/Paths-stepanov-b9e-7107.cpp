/**
* user:  stepanov-b9e
* fname: Anton
* lname: Stepanov
* task:  Paths
* score: 31.0
* date:  2021-12-17 11:37:30.686363
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <array>
#include <cassert>
#include <set>
#include <map>
#include <deque>
#include <random>
#include <queue>


using namespace std;


#define int long long
#define ll long long
#define ld long double
#define flt double
#define pb push_back
#define emb emplace_back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()


struct edge {
    int to;
    ll w;

    edge() {}
    edge(int to, ll w) : to(to), w(w) {}
};


int n, k;
vector<vector<edge>> g;
vector<int> res;
vector<int> s;
vector<ll> d;
vector<vector<ll>> w;


void mrg(vector<ll>& a, vector<ll>& b, vector<ll>& c) {
    c.resize(a.size() + b.size());
    merge(all(a), all(b), c.begin());
}


vector<ll> nc;


void mrg1(vector<ll>& a, vector<ll>& b, vector<ll>& c) {
    mrg(a, b, nc);
    c.swap(nc);
}


vector<ll> nw;


void dfs5(int v, int p) {
    w[v].push_back(0);
    for (auto& e : g[v]) {
        int to = e.to;
        if (to != p) {
            dfs5(to, v);
            w[to].back() += e.w;
            nw.clear();
            mrg(w[to], w[v], nw);
            nw.swap(w[v]);
            w[to].back() -= e.w;
        }
    }
    return;
}


ll ksm(vector<ll>& a) {
    ll res = 0;
    for (int i = 0; i < a.size() && i < k; ++i) {
        res += a[a.size() - i - 1];
    }
    return res;
}


vector<vector<vector<ll>>> pw;
vector<vector<ll>> tow;
vector<vector<ll>> x;


void dfs6(int v, int p, vector<ll> &mw) {
    int f = g[v].size();
    pw[v].resize(f + 1);
    pw[v][f] = mw;
    for (int i = f - 1; i >= 0; --i) {
        x[v].clear();
        auto e = g[v][i];
        int to = e.to;
        if (to != p) {
            x[v] = w[to];
            x[v].back() += e.w;
        }
        mrg(x[v], pw[v][i + 1], pw[v][i]);
    }
    tow[v].clear();
    for (int i = 0; i < f; ++i) {
        auto e = g[v][i];
        int to = e.to;
        if (to != p) {
            x[v].clear();
            mrg(tow[v], pw[v][i + 1], x[v]);
            x[v].back() += e.w;
            dfs6(to, v, x[v]);
            w[to].back() += e.w;
            mrg1(tow[v], w[to], tow[v]);
            w[to].back() -= e.w;
        }

    }
    res[v] = ksm(pw[v][0]);
}


void solve_slow() {
    pw.resize(n);
    res.resize(n);
    w.assign(n, vector<ll>());
    tow.resize(n);
    x.resize(n);
    dfs5(0, -1);
    vector<ll> x;
    dfs6(0, -1, x);
}



void dfs3(int v, int p) {
    d[v] = 0;
    for (auto& e : g[v]) {
        int to = e.to;
        if (to != p) {
            dfs3(to, v);
            d[v] = max(d[v], d[to] + e.w);
        }
    }
}

void dfs4(int v, int p, ll k) {
    res[v] = k;
    ll f = g[v].size();
    vector<ll> ps(f + 1, 0);
    for (int i = f - 1; i >= 0; --i) {
        auto &e = g[v][i];
        int to = e.to;
        if (to != p) {
            res[v] = max(res[v], d[to] + e.w);
            ps[i] = d[to] + e.w;
        }
        ps[i] = max(ps[i], ps[i + 1]);
    }
    ll x = k;
    for (int i = 0; i < f; ++i) {
        auto &e = g[v][i];
        int to = e.to;
        if (to != p) {
            dfs4(to, v, max(x, ps[i + 1]) + e.w);
            x = max(x, d[to] + e.w);
        }

    }
}


void dfs1(int v, int p) {
    s[v] = 1;
    int mxs = -1;
    int mxsi = -1;
    for (int i = 0; i < g[v].size(); ++i) {
        auto &e = g[v][i];
        int to = e.to;
        if (to != p) {
            dfs1(to, v);
            if (s[to] > mxs) {
                mxs = s[to];
                mxsi = i;
            }
            s[v] += s[to];
        }
    }
    if (mxs != -1) {
        swap(g[v][0], g[v][mxsi]);
    }
}


inline void add_to_bck(priority_queue<ll>& s, ll x) {
    ll f = s.top();
    s.pop();
    s.push(f + x);
}


void dfs2(int v, int p, priority_queue<ll> &s) {
    s.push(0);
    for (int i = 0; i < g[v].size(); ++i) {
        auto& e = g[v][i];
        int to = e.to;
        if (to != p) {
            if (i == 0) {
                dfs2(to, v, s);
                if (!s.empty()) {
                    add_to_bck(s, e.w);
                }
            } else {
                priority_queue<ll> s1;
                dfs2(to, v, s1);
                if (!s1.empty()) {
                    add_to_bck(s1, e.w);
                }
                while (!s1.empty()) {
                    s.push(s1.top());
                    s1.pop();
                }
            }
        }
    }
}


void hldz(int v0) {
    s.resize(n);
    dfs1(v0, -1);
}


void solve_k1() {
    d.resize(n);
    res.resize(n);
    dfs3(0, -1);
    dfs4(0, -1, 0);
}


int32_t main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    g.assign(n, vector<edge>());
    for (int i = 0; i < n - 1; ++i) {
        int u, v;
        ll w;
        cin >> u >> v >> w;
        --u;
        --v;
        g[u].push_back(edge(v, w));
        g[v].push_back(edge(u, w));
    }
    if (k == 1) {
        solve_k1();
    } else{
        solve_slow();
    }
    for (int i = 0; i < n; ++i) {
        cout << res[i] << "\n";
    }
    return 0;
}

/*
 11 3
 1 2 5
 2 3 3
 2 6 5
 3 4 4
 3 5 2
 1 7 6
 7 8 4
 7 9 5
 1 10 1
 10 11 1

*/