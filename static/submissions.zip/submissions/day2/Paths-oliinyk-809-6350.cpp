/**
* user:  oliinyk-809
* fname: Andrii
* lname: Oliinyk
* task:  Paths
* score: 48.0
* date:  2021-12-17 10:46:26.397643
*/
#include <bits/stdc++.h>

#define INF 1000000005
#define EPS 1e-6
#define pb push_back
#define pause system("pause")
#define exit exit(0)
#define endl '\n'

using namespace std;
using ull = unsigned long long;
using ll = long long;

typedef pair<int, int> pii;
const int N = 100005, LG = 16;

int n, k, e_cnt[N], hd[N], nxt[N << 1], tr[N << 1], ct[N << 1], cv;
ll ans[N];
vector<vector<ll>> dp;

inline void add(int u, int v, int w) {
	tr[++cv] = v;
	ct[cv] = w;
	nxt[cv] = hd[u];
	hd[u] = cv;
	++e_cnt[u];
}

inline void mrg2(vector<ll> &a, vector<ll> &b, int ct) {
	ll x;
	for (int i = k; i > 0; --i) {
		x = max(a[i], b[i]);
		for (int j = 0; j < i; ++j) {
			x = max(x, a[i - j] + b[j] + ct);
		}

		a[i] = x;
	}
}

inline void mrg(vector<ll> &a, vector<ll> &b, int ct) {
	for (int i = k; i > 0; --i) {
		for (int j = 1; j <= i; ++j) {
			a[i] = max(a[i], a[i - j] + b[j] + ct);
		}
	}
}

void dfs(int u, int p = -1) {
	int e = hd[u];
	while (e) {
		int v = tr[e];
		if (v != p) {
			dfs(v, u);
			mrg(dp[u], dp[v], ct[e]);
		}

		e = nxt[e];
	}
}

void dfs2(int u, int p = -1) {
	int sz = e_cnt[u];
	vector<vector<ll>> pf(sz, vector<ll>(k + 1)), sf(sz, vector<ll>(k + 1));
	int e = hd[u], i = 0;
	vector<int> wg(sz);
	while (e) {
		int v = tr[e];
		pf[i] = sf[i] = dp[v];
		wg[i++] = ct[e], e = nxt[e];
	}
	
	for (int i = 1; i <= k; ++i) {
		pf[0][i] += wg[0];
		sf[sz - 1][i] += wg[sz - 1];
	}

	for (int i = 1; i < sz; ++i) {
		mrg2(pf[i], pf[i - 1], wg[i]);
	}

	for (int i = sz - 2; i >= 0; --i) {
		mrg2(sf[i], sf[i + 1], wg[i]);
	}

	ans[u] = pf[sz - 1][k];
	vector<ll> dp_prv = dp[u];
	dp[u] = pf[sz - 1];
	e = hd[u], i = 0;
	while (e) {
		int v = tr[e];
		if (v != p) {
			dp[u] = (i == 0 ? vector<ll>(k + 1) : pf[i - 1]);
			if (i != sz - 1) mrg(dp[u], sf[i + 1], 0);
			dfs2(v, u);
		}

		e = nxt[e];
		++i;
	}

	dp[u] = dp_prv;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);

	cin >> n >> k;
	
	ll sm = 0;
	for (int i = 0, u, v, c; i < n - 1; ++i) {
		cin >> u >> v >> c;
		add(u, v, c);
		add(v, u, c);
		sm += c;
	}
	
	int val = 0;
	for (int i = 1; i <= n; ++i) {
		if (e_cnt[i] == 1) {
			++val;
		}
	}

	if (k >= val) {
		cout << sm << endl;
		return 0;
	}
	
	dp.resize(n + 1, vector<ll>(k + 1));
	dfs(1);
	dfs2(1);

	for (int i = 1; i <= n; ++i) {
		cout << ans[i] << endl;
	}
	//cout << endl;
	//pause;
	return 0;
}
