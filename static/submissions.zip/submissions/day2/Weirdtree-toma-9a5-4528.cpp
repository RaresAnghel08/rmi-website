/**
* user:  toma-9a5
* fname: Eliza Maria
* lname: Toma
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:04:29.305907
*/
#include <bits/stdc++.h>

using namespace std;

int n,q,l,r,poz,val;
const int NMAX = 8e4;
int v[NMAX + 5];
struct aint {
    int s;
    int mx,pozmx;
}arb[(NMAX << 2) + 5];

void build(int node, int st, int dr) {
    if (st > dr)
        return;
    if (st == dr) {
        arb[node].mx = v[st];
        arb[node].s = v[st];
        arb[node].pozmx = st;
        return;
    }
    int md = ((st + dr) >> 1);
    build((node << 1), st, md);
    build((node << 1) + 1, md + 1, dr);
    arb[node].mx = max(arb[(node << 1)].mx, arb[(node << 1) + 1].mx);
    if (arb[(node << 1)].mx >= arb[(node << 1) + 1].mx)
        arb[node].pozmx = arb[(node << 1)].pozmx;
    else
        arb[node].pozmx = arb[(node << 1) + 1].pozmx;
    arb[node].s = arb[(node << 1)].s + arb[(node << 1) + 1].s;
}
void update(int node, int st, int dr) {
    if (st > dr || poz < st || poz > dr)
        return;
    if (st == dr) {
        arb[node].mx = val;
        arb[node].pozmx = poz;
        arb[node].s = val;
        return;
    }
    int md = ((st + dr) >> 1);
    update((node << 1), st, md);
    update((node << 1) + 1, md + 1, dr);
    arb[node].mx = max(arb[(node << 1)].mx, arb[(node << 1) + 1].mx);
    if (arb[(node << 1)].mx >= arb[(node << 1) + 1].mx)
        arb[node].pozmx = arb[(node << 1)].pozmx;
    else
        arb[node].pozmx = arb[(node << 1) + 1].pozmx;
    arb[node].s = arb[(node << 1)].s + arb[(node << 1) + 1].s;
}
long long query(int node, int st, int dr) {
    if (st > r || dr < l || st > dr)
        return 0;
    if (l <= st && dr <= r)
        return arb[node].s;
    int md = ((st + dr) >> 1);
    return query((node << 1), st, md) + query((node << 1) + 1, md + 1, dr);
}
int query_mx(int node, int st, int dr) {
    if (st > r || dr < l || st > dr)
        return -1;
    if (st == dr && st >= l && dr <= r) {
        return st;
    }
    int md = ((st + dr) >> 1),xx,yy;
    xx = query_mx((node << 1), st, md);
    yy = query_mx((node << 1) + 1, md + 1, dr);
    if (v[xx] >= v[yy])
        return xx;
    else
        return yy;
}
void initialise(int N, int Q, int h[]) {
    n = N;
    q = Q;
    v[0] = -1;
    for (int i = 1;i <= n;i++)
        v[i] = h[i];
    build(1, 1, n);
}
void cut(int L, int R, int k) {
    l = L;
    r = R;
    for (int i = 0;i < k;i++) {
        poz = query_mx(0, 1, n);
        if (v[poz] == 0)
            break;
        val = --v[poz];
        update(1, 1, n);
    }
}
void magic(int i, int x) {
    poz = i;
    val = x;
    v[poz] = val;
    update(1, 1, n);
}
long long int inspect(int L, int R) {
    l = L;
    r = R;
    return query(1, 1, n);
}
//int main()
//{
//    ifstream fin("weirdtree.in");
//    ofstream fout("weirdtree.out");
//    int v1[NMAX + 5],cer,a,b,c;
//    fin >> n >> q;
//    for (int i = 1;i <= n;i++)
//        fin >> v1[i];
//    initialise(n, q, v1);
//    for (int i = 0;i < q;i++) {
//        fin >> cer;
//        if (cer == 1) {
//            fin >> a >> b >> c;
//            cut(a, b, c);
//        }
//        else if (cer == 2) {
//            fin >> a >> b;
//            magic(a, b);
//        }
//        else {
//            fin >> a >> b;
//            fout << inspect(a, b) << '\n';
//        }
//    }
//    return 0;
//}
