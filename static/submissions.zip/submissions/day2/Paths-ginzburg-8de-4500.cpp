/**
* user:  ginzburg-8de
* fname: Yael
* lname: Ginzburg
* task:  Paths
* score: 36.0
* date:  2021-12-17 08:01:16.164215
*/
// ProblemPaths.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <tuple>

using namespace std;

typedef long long ll;
typedef pair<ll, ll> pii;
typedef tuple<ll, ll, ll> tiii;

vector<vector<ll>> dp;
void solve(ll v, vector<vector<pii>>& g, ll p, ll k)
{
    priority_queue<tiii> prio;
    for (pii u : g[v])
    {
        if (u.first != p)
        {
            solve(u.first, g, v, k);
            prio.push({ dp[u.first][1] + u.second, u.first, 1 });
        }
    }
    ll sum = 0;
    for (ll i = 0; i < k; i++)
    {
        if (!prio.empty())
        {
            tiii temp = prio.top(); prio.pop();
            sum += get<0>(temp);
            if (get<2>(temp) < k && dp[get<1>(temp)][get<2>(temp) + 1] - dp[get<1>(temp)][get<2>(temp)] > 0)
                prio.push({ dp[get<1>(temp)][get<2>(temp) + 1] - dp[get<1>(temp)][get<2>(temp)], get<1>(temp), get<2>(temp) + 1 });
        }
        dp[v][i + 1] = sum;
    }
}

bool solve1(ll v, vector<vector<pii>>& g, ll p, ll k, int r)
{
    bool recalc = v == r;
    for (pii u : g[v])
    {
        if (u.first != p && !recalc)
        {
            recalc |= solve1(u.first, g, v, k, r);
        }
    }
    if (!recalc) return false;
    priority_queue<tiii> prio;
    for (pii u : g[v])
    {
        if (u.first != p)
        {
            prio.push({ dp[u.first][1] + u.second, u.first, 1 });
        }
    }
    ll sum = 0;
    for (ll i = 0; i < k; i++)
    {
        if (!prio.empty())
        {
            tiii temp = prio.top(); prio.pop();
            sum += get<0>(temp);
            if (get<2>(temp) < k && dp[get<1>(temp)][get<2>(temp) + 1] - dp[get<1>(temp)][get<2>(temp)] > 0)
                prio.push({ dp[get<1>(temp)][get<2>(temp) + 1] - dp[get<1>(temp)][get<2>(temp)], get<1>(temp), get<2>(temp) + 1 });
        }
        dp[v][i + 1] = sum;
    }
    return true;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    ll n, k; cin >> n >> k;
    vector<vector<pii>> g(n);
    for (ll i = 0; i < n-1; i++)
    {
        ll v, u, c; cin >> v >> u >> c;
        v--; u--;
        g[v].push_back({ u, c });
        g[u].push_back({ v, c });
    }
    dp.resize(n, vector<ll>(k + 1, 0));
    solve(0, g, -1, k);
    cout << dp[0][k] << endl;
    for (ll i = 1; i < n; i++)
    {
        solve1(i, g, -1, k, i-1);
        cout << dp[i][k] << endl;
    }
}

