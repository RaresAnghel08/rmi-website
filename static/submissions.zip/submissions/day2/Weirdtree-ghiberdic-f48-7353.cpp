/**
* user:  ghiberdic-f48
* fname: David
* lname: Ghiberdic
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:52:07.128673
*/
#include <iostream>

int const nmax = 300000;
int arrH[nmax], n;
int aint[nmax * 2 + 500];

void update (int nod, int st, int dr, int x, int val) {
    if (st == dr && st == x) {
        aint[nod] += val;
        return;
    }
    int med = (st + dr) / 2;
    if (x <= med)
        update (nod << 1, st, med, x, val);
    else
        update (nod << 1 + 1, med + 1, dr, x, val);
    aint[nod] = aint[nod << 1] + aint[nod << 1 + 1];
}

long long int query (int nod, int st, int dr, int l, int r) {
    if (st <= l && r <= dr)
        return aint[nod];
    int med = (st + dr) / 2;
    long long int sum = 0;
    if (l <= med)
        sum += query (nod << 1, st, med, l, r);
    if (med < r)
        sum += query (nod << 1, med + 1, dr, l, r);
    return sum;
}

long long int check (int val) {
    long long int sum = 0;
    for (int i = 1; i <= n; i++)
        if (arrH[i] >= val)
            sum += val - arrH[i];
    return sum;
}

void initialise ( int N, int Q, int h []) {
    for (int i = 1; i <= N; i++)
        arrH[i] = h[i];
    n = N;
}
void cut( int l, int r, int k) {
    int st = 1, dr = n + 1;
    while (st < dr) {
        int med = (st + dr) >> 1;
        if (check (med) < k)
            st = med + 1;
        else
            dr = med;
    }
    long long int sum = check(st + 1);
    if (check(st + 1) == k)
        st++;
    else
        sum = check (st);
    int surplus = k - sum;
    for (int i = 1; i <= n; i++) {
        if (arrH[i] > st) {
            update (1, 1, n, i, st - arrH[i]);
            arrH[i] = st;
        }
        if (arrH[i] == st && surplus > 0) {
            surplus--;
            update(1, 1, n, i, -1);
            arrH[i]--;
        }
    }
}
void magic ( int i, int x) {
    update(1, 1, n, i, x - arrH[i]);
    arrH[i] = x;
}
long long int inspect ( int l, int r) {
    return query (1, 1, n, l, r);
}

