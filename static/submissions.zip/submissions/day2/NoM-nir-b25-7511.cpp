/**
* user:  nir-b25
* fname: Itamar
* lname: Nir
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:57:49.820295
*/
#include<vector>
using namespace std;
#include <iostream>
int n, m;
long long sum = 0;
bool check(vector<int> vec) {
    if (m == 1) {
        return 0;
    }
    for (int i = 0; i < vec.size(); i++) {
        for (int j = i+1; j < vec.size(); j+=m) {
            if (vec[i] % n == vec[j] % n) {
                return 0;
            }
        }
    }
    return 1;
}
void fun(vector<int> vec) {
    if (vec.size() == 2*n) {
        sum += check(vec);
    }
    else {
        for (int i = 0; i < 2 * n; i++) {
            for (int j = 0; j < vec.size(); j++) {
                if (vec[j] == i) {
                    continue;
                }
            }vec.push_back(i);
            fun(vec);
            vec.pop_back();
        }
    }
}
int main()
{
    
    cin >> n >> m;
    vector<int> vec;
    fun(vec);
    cout << sum;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
