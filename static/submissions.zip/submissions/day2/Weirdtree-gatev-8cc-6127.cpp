/**
* user:  gatev-8cc
* fname: Aleksandar Miroslavov
* lname: Gatev
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:27:48.634909
*/
#include<bits/stdc++.h>
#include "weirdtree.h"
using namespace std;

int n;
long long a[300007];

pair<int,long long> tree[1200007];
long long sum[1200007];

pair<int,long long> combine(pair<int,long long> fr,pair<int,long long> sc){
    if(fr.second>=sc.second)return fr;
    else return sc;
}

void update(int v,int l,int r,int pos,long long val){
    if(l==r){
        tree[v].first=pos;
        tree[v].second+=val;
        sum[v]+=val;a[pos]+=val;
    }else{
        int tt=(l+r)/2;
        if(pos<=tt)update(2*v,l,tt,pos,val);
        else update(2*v+1,tt+1,r,pos,val);
        tree[v]=combine(tree[2*v],tree[2*v+1]);
        sum[v]=sum[2*v]+sum[2*v+1];
    }
}

pair<int,long long> getpos(int v,int l,int r,int ll,int rr){
    if(ll>rr)return {0,-10000000};
    if(l==ll and r==rr){
        return tree[v];
    }else{
        int tt=(l+r)/2;
        return combine( getpos(2*v,l,tt,ll,min(tt,rr)) , getpos(2*v+1,tt+1,r,max(ll,tt+1),rr) );
    }
}

long long getsum(int v,int l,int r,int ll,int rr){
    if(ll>rr)return 0;
    if(l==ll and r==rr){
        return sum[v];
    }else{
        int tt=(l+r)/2;
        return getsum(2*v,l,tt,ll,min(tt,rr))+getsum(2*v+1,tt+1,r,max(tt+1,ll),rr);
    }
}

void initialise(int N, int Q, int h[]){
    n=N;
    for(int i=1;i<=n;i++){
        update(1,1,n,i,h[i]);
    }
}

void cut(int l, int r, int k){
    int id=getpos(1,1,n,l,r).first;
    update(1,1,n,id,-1);
}
void magic(int i, int x){
    update(1,1,n,i,x-a[i]);
}
long long int inspect(int l, int r){
    return getsum(1,1,n,l,r);
}