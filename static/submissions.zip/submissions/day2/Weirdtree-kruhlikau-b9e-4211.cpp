/**
* user:  kruhlikau-b9e
* fname: Ihar
* lname: Kruhlikau
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 07:17:01.602091
*/
#include <bits/stdc++.h>

#define fi first
#define se second
#define mp make_pair

#define pb push_back
#define pob pop_back

#define ld long double
#define ll long long

#define re return
#define cont continue

#define endl '\n'

using namespace std;

ll a[350001], n, i, q, mx, nom, ans;

    void cut(int l, int r, int k)
    {
        if (k > 1)
        re;

        mx = -1;

        for (i = l; i <= r; i++)
            if (a[i] > mx) {
                mx = a[i];

                nom = i;
            }

        if (mx > 0)
        a[nom]--;
    }

    long long int inspect(int l, int r)
    {
        ans = 0;

        for (i = l; i <= r; i++) ans += a[i];

        re ans;
    }

    void magic(int i, int x)
    {
        a[i] = x;
    }

    void initialise(int N, int Q, int h[])
    {
        n = N;

        q = Q;

        for (i = 1; i <= n; i++) a[i] = h[i];
    }

//int main()
//{
//    ios::sync_with_stdio(0);
//    cin.tie(0);
//
//
//
//    re 0;
//}
