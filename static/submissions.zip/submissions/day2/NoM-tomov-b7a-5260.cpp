/**
* user:  tomov-b7a
* fname: Konstantin Konstantinov
* lname: Tomov
* task:  NoM
* score: 9.0
* date:  2021-12-17 09:14:34.594478
*/
#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

vector<ll> v;
ll n,m,n2;

bool isok(){
  for(ll i=m;i<n2;i+=m){
    for(ll j=0;j<n2-i;++j){
      if(v[j]==v[j+i])return 0;
      }
    }
  return 1;
  }

int main(){

cin>>n>>m;
n2=n*2;
for(ll i=1;i<=n;++i)v.push_back(i),v.push_back(i);

ll s=0;
if(isok())s+=(1<<n);
//for(ll i : v)cout<<i<<" ";cout<<endl;
while(next_permutation(v.begin(),v.end())){
  //for(ll i : v)cout<<i<<" ";cout<<endl;
  if(isok())s+=(1<<n);
  }

cout<<s<<endl;

return 0;
}
