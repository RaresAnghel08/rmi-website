/**
* user:  calota-e12
* fname: Andrei
* lname: Calotă
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 11:43:48.204786
*/

#include "weirdtree.h"
#include <iostream>

using namespace std;
const int NMAX = 1e5;
const long long INF = 1e18;
using ll = long long;
int n, q;

struct seg_tree {
      ll sum[1 + 4 * NMAX];
      pair<ll, int> maxx[1 + 4 * NMAX];
      void update ( int node, int left, int right, int pos, int x ) {
          if ( left == right ) {
            sum[node] += x;
            maxx[node] = { sum[node], left };
          }
          else {
            int mid = left + ( right - left ) / 2;
            if ( pos <= mid )
              update ( node * 2, left, mid, pos, x );
            else
              update ( node * 2 + 1, mid + 1, right, pos, x );
            sum[node] = sum[node * 2] + sum[node * 2 + 1];
            if ( maxx[node * 2].first >= maxx[node * 2 + 1].first )
              maxx[node] = maxx[node * 2];
            else
              maxx[node] = maxx[node * 2 + 1];
          }
      }

      ll query_sum ( int node, int left, int right, int x, int y ) {
         if ( x <= left && right <= y )
           return sum[node];
         int mid = left + ( right - left ) / 2;
         ll result = 0;
         if ( x <= mid )
           result += query_sum ( node * 2, left, mid, x, y );
         if ( mid + 1 <= y )
           result += query_sum ( node * 2 + 1, mid + 1, right, x, y );
         return result;
      }

      pair<ll, int> query_max ( int node, int left, int right, int x, int y ) {
         if ( x <= left && right <= y )
           return maxx[node];
         int mid = left + ( right - left ) / 2;

         pair<ll, int> result = { -INF, 0 };
         if ( x <= mid )
           result = max ( result, query_max ( node * 2, left, mid, x, y ) );
         if ( mid + 1 <= y )
           result = max ( result, query_max ( node * 2 + 1, mid + 1, right, x, y ) );
         return result;
      }


} aint;

void initialise(int N, int Q, int h[]) {
    n = N; q = Q;
    for ( int i = 1; i <= N; i ++ )
       aint.update ( 1, 1, N, i, h[i] );
}

void cut(int l, int r, int k) {
    pair<ll, int> result;
    result = aint.query_max ( 1, 1, n, l, r );

    for ( int i = 1; i <= k && result.first > 0; i ++ ) {
      /// cout << result.first << " " << result.second << "\n";

       int pos = result.second;
       aint.update ( 1, 1, n, pos, -1 );
       result = aint.query_max ( 1, 1, n, l, r );
    }
}

void magic(int i, int x) {
    pair<ll, int> init_value = aint.query_max ( 1, 1, n, i, i );
    aint.update ( 1, 1, n, i, x - init_value.first );
}

long long int inspect(int l, int r) {
    ll result = aint.query_sum ( 1, 1, n, l, r );
	return result;
}


