/**
* user:  kruhlikau-b9e
* fname: Ihar
* lname: Kruhlikau
* task:  NoM
* score: 52.0
* date:  2021-12-17 09:04:04.103430
*/
#include <bits/stdc++.h>

#define fi first
#define se second
#define mp make_pair

#define pb push_back
#define pob pop_back

#define ld long double
#define ll long long

#define in insert
#define er erase

#define re return
#define cont continue

#define endl '\n'

using namespace std;

ll M = 1000000007, ck[1201][1201], a[1201], p[1201], pw[1201], f[1201], dp[1201][1201], n, m, i, j, z, k, k1, sum, val, val1, ans;

bool x;

    ll mod(ll a)
    {
        re a % M;
    }

    void rec(ll nom)
    {
        ll i;

        if (nom == n * 2 + 1) {
            x = true;

            for (i = 1; i <= n * 2; i++)
                for (j = i + m; j <= n * 2; j += m)
                    if (a[i] == a[j]) x = false;

            if (x)
            ans++;

            re;
        }

        for (i = 1; i <= n; i++)
            if (p[i] + 1 <= 2) {
                a[nom] = i;

                p[i]++;

                rec(nom + 1);

                p[i]--;
            }
    }

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin >> n >> m;

//    if (n <= 5 && m <= 5) {
//        rec(1);
//
//        for (i = 1; i <= n; i++) ans = mod(ans * 2);
//
//        cout << ans << endl;
//
//        re 0;
//    }

    for (i = 0; i <= 1000; i++) ck[i][0] = 1;

    for (i = 1; i <= 1000; i++)
        for (j = 1; j <= 1000; j++) ck[i][j] = mod(ck[i - 1][j] + ck[i - 1][j - 1]);

    f[0] = 1;

    for (i = 1; i <= 1000; i++) f[i] = mod(f[i - 1] * i);

    pw[0] = 1;

    for (i = 1; i <= 1000; i++) pw[i] = mod(pw[i - 1] * 2);

    for (i = 0; i < n * 2; i++) a[i % m + 1]++;

    dp[0][n] = 1;

    for (i = 0; i <= m - 1; i++) {
        sum += a[i];

        for (j = 0; j <= n; j++)
            if (dp[i][j] > 0) {
                k = j;

                k1 = (n * 2 - sum) - j * 2;

                for (z = 0; z <= k; z++) {
                    if (z > a[i + 1] || a[i + 1] - z > k1)
                    cont;

                    dp[i + 1][k - z] = mod(dp[i + 1][k - z] + mod(dp[i][j] * ck[k][z]) * mod(ck[k1][a[i + 1] - z] * f[a[i + 1]]));
                }
            }
    }

    cout << mod(dp[m][0] * pw[n]) << endl;

    re 0;
}
