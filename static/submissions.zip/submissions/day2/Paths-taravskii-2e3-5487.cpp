/**
* user:  taravskii-2e3
* fname: Denys
* lname: Taravskii
* task:  Paths
* score: 19.0
* date:  2021-12-17 09:34:26.184579
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> pllll;

#define fi first
#define se second

const ll DIM = 1e3 + 7;
const ll DIMM = 1e2 + 7;
const ll INF = 1e16 + 7;

ll nt,n,m,k;

ll v1,v2;

ll w[DIM],ck[DIM],res[DIM];

vector<pllll> a[DIM];

ll dp[DIM][DIMM];

void read(){

    cin>>n>>k;

    for(int i=1;i<n;i++){

     cin>>v1>>v2>>w[i];

     a[v1].push_back({v2,i});
     a[v2].push_back({v1,i});
    }
}


void dfs(ll v,ll par){

    ck[v]=0;

    for(auto to:a[v]){
     if(to.fi==par)continue;
     dfs(to.fi,v);
    }

    ll mto,md,val;

    dp[v][0]=0;

    for(int k1=1;k1<=k;k1++){

     mto=(-1);
     md=0;

     for(auto to:a[v]){
      if(to.fi==par)continue;

      val=dp[to.fi][ck[to.fi]+1]-dp[to.fi][ck[to.fi]];
      if(ck[to.fi]==0)val+=w[to.se];

      if(val>md){
       md=val;
       mto=to.fi;
      }
     }

     dp[v][k1]=dp[v][k1-1]+md;
     if(mto!=(-1))ck[mto]++;
    }
}


void solve(){

    read();

    for(int i=1;i<=n;i++){
     dfs(i,(-1));
     res[i]=dp[i][k];
    }

    for(int i=1;i<=n;i++)cout<<res[i]<<endl;

    return;
}

int main()
{

    ios_base::sync_with_stdio();
    cin.tie();
    cout.tie();

    //cin>>nt;

    nt=1;

    for(int t=1;t<=nt;t++){
     solve();
    }

    return 0;
}
