/**
* user:  rigvava-6c6
* fname: Iakob
* lname: Rigvava
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:25:42.965366
*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define F first
#define S second
#define mp make_pair
using namespace std;
ll n,a,b,c,k,dd[100005],ds[100005],df[100005],s,f;
vector<pair<ll,ll> > v[100005];
void go(int u,int d,int p)
{
	dd[u]=d;
	if (v[u].size()<2 && p!=0)
		return;
	for (int i=0; i<v[u].size(); i++)
		if (v[u][i].F!=p)
			go(v[u][i].F,d+v[u][i].S,u);
	return;
}
void findd()
{
	int mx;
	go(1,0,0);
	mx=0;
	for (int i=1; i<=n; i++)
		if (dd[i]>mx)
		{
			mx=dd[i];
			s=i;
		}
	go(s,0,0);
	mx=0;
	for (int i=1; i<=n; i++)
	{
		ds[i]=dd[i];
		if (ds[i]>mx)
		{
			mx=dd[i];
			f=i;
		}
	}
	return;
}
void distf()
{
	go(f,0,0);
	for (int i=1; i<=n; i++)
		df[i]=dd[i];
	return;
}
int main()
{
	ios_base::sync_with_stdio(false);cin.tie(0);
	cin>>n>>k;
	for (int i=0; i<n-1; i++)
	{
		cin>>a>>b>>c;
		v[a].pb(mp(b,c));
		v[b].pb(mp(a,c));
	}
	findd();
	distf();
	for (int i=1; i<=n; i++)
		cout<<max(ds[i],df[i])<<endl;
	return 0;
}
/*
user : rigvava-6c6
pass : 9301cfe0f0de
*/
