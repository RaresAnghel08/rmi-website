/**
* user:  magirescu-396
* fname: Tudor Stefan
* lname: Magirescu
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 10:47:44.622266
*/
#include "weirdtree.h"
#include <iostream>
#define NMAX 80000
#define ll long long
#define f first
#define s second

using namespace std;

int m;
pair <int, int> aint[4*NMAX+10];
ll aint2[4*NMAX+10];

void initialise(int N, int Q, int h[]) {
    int bit = 0;
    while((1 << bit) < N)
        bit++;
    m = (1 << bit);

    for(int i=m; i<2*m; i++)
        aint[i] = {h[i-m+1], i-m+1}, aint2[i] = (ll)h[i-m+1];
    for(int i=m-1; i; i--){
        if(aint[2*i].f>=aint[2*i+1].f)
            aint[i] = aint[2*i];
        else
            aint[i] = aint[2*i+1];
        aint2[i] = aint2[2*i] + aint2[2*i+1];
    }
}

pair <int, int> query1(int nod, int stnod, int drnod, int stq, int drq){
    if(stq <= stnod && drnod <= drq){
        //cout << aint[nod].f << ' ' << aint[nod].s << '\n';
        return aint[nod];
    }

    int mij = (stnod + drnod) / 2;
    pair <int, int> ans = {-1, -1};

    if(stq <= mij){
        pair <int, int> aux = query1(2*nod, stnod, mij, stq, drq);
        if(aux.f > ans.f)
            ans = aux;
    }
    if(drq > mij){
        pair <int, int> aux = query1(2*nod+1, mij+1, drnod, stq, drq);
        if(aux.f > ans.f)
            ans = aux;
    }

    return ans;
}

ll query2(int nod, int stnod, int drnod, int stq, int drq){
    if(stq <= stnod && drnod <= drq)
        return aint2[nod];
    ll sum = 0;
    int mij = (stnod + drnod) / 2;
    if(stq <= mij)
        sum += query2(2 * nod, stnod, mij, stq, drq);
    if(drq > mij)
        sum += query2(2 * nod + 1, mij + 1, drnod, stq, drq);
    return sum;
}

void update(int poz, ll val){
    if(val < 0)
        return;

    poz = poz + m - 1;
    aint[poz] = {val, poz - m + 1};
    aint2[poz] = val;
    poz /= 2;

    while(poz){
        if(aint[2*poz].f >= aint[2*poz+1].f)
            aint[poz] = aint[2*poz];
        else
            aint[poz] = aint[2*poz+1];
        aint2[poz] = aint2[2*poz] + aint2[2*poz+1];
        poz /= 2;
    }
}

void cut(int l, int r, int k) {
    pair <int, int> idx = query1(1, 1, m, l, r);
    update(idx.s, aint2[idx.s+m-1] - 1);
}
void magic(int i, int x) {
	update(i, x);
}
long long int inspect(int l, int r) {
	return query2(1, 1, m, l, r);
}

