/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:09:56.775294
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

mt19937 rnd(time(0));



const int mod = 1e9 + 7;

int fastpow(int a, int b) {
	if (b == 0)
		return 1;
	if (b & 1)
		return a * fastpow(a, b - 1) % mod;
	int t = fastpow(a, b / 2);
	return t * t % mod;
}

void solve() {
	int n, m;
	cin >> n >> m;
	pii a[2 * n];
	for (int i = 0; i < 2 * n; ++i) {
		a[i] = {i % n, i / n};
	}
	sort(a, a + 2 * n);
	int ans = 0;
	do {
		bool ok = 1;
		for (int j = 0; j < 2 * n; ++j) {
			for (int k = 0; k < 2 * n; ++k) {
				if (a[j].f == a[k].f && (j - k + 3 * m) % m == 0)
					ok = 0;
			}
		}
		if (ok) {
			ans++;
			ans %= mod;
		}
	} while (next_permutation(a, a + 2 * n));
	cout << ans << endl;
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	// cin >> t;
	while (t--)
		solve();
}