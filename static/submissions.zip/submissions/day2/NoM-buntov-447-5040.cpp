/**
* user:  buntov-447
* fname: Atanas Todorov
* lname: Buntov
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:55:44.922520
*/
#include<bits/stdc++.h>
#define ll long long
#define f first
#define s second
using namespace std;
ll n,m,i,a[210];
int main()
{ios_base::sync_with_stdio(false);
cin.tie(NULL);
cin>>n>>m;
for(i=0;i<2*n;i++)a[i]=i;
int cnt=0,br=0;
do
{
    bool f=0;
    for(i=0;i<2*n-m;i++)
    {
        for(int j=i+m;j<2*n;j+=m){
        if(a[i]%2==0 && a[i] == a[j]-1)f=1;
        if(a[i]%2==1 && a[i] == a[j]+1)f=1;

        }
    }
    if(f==0)cnt++;
}while(next_permutation(a,a+2*n));
/*
do
{
    bool f=0;
    for(i=0;i<2*n;i++)
    {
        for(int j=m;j<=2*n;j+=m){
                if(i + j < 2*n){
        if(a[i]%2==0 && a[i] == a[i+j]-1)f=1;
        if(a[i]%2==1 && a[i] == a[i+j]+1)f=1;
        }
        }
    }
    if(f==0)cnt++;
}while(next_permutation(a,a+2*n));
cout<<cnt % (1000000007)<<endl;
*/
cout<<cnt % (1000000007)<<endl;
return 0;
}



