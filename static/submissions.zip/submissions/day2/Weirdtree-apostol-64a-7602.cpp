/**
* user:  apostol-64a
* fname: Ilie-Daniel
* lname: Apostol
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 11:59:16.924647
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

using namespace std;
#define dbg(x) cerr << #x << " " << x << "\n"
using ll = long long;
int n;
const int MAX_N = 10000;
int H[1 + MAX_N];
void initialise(int N, int Q, int h[]) {
	// Your code here.
	n = N;
	for (int i = 1; i <= n; i++)
        H[i] = h[i];
}
void cut(int l, int r, int k) {
	// Your code here.
	vector <pair <int, int>> v;
	for (int i = l; i <= r; i++)
        v.push_back({H[i], i});
    sort(v.begin(), v.end());
    reverse(v.begin(), v.end());
    int cnt = 1;
    ll sum = 0;
    int id = 0;
    while (((id + 1) < (int) v.size()) && sum + 1ll * cnt * (v[id].first - v[id + 1].first) <= k) {
        sum += 1ll * cnt * (v[id].first - v[id + 1].first);
        id++;
        cnt++;
    }
  //  dbg(sum);
    k -= sum;
    //dbg(v[id].first);
    int x = v[id].first;
    for (int i = 0; i <= id; i++)
        v[i].first = x;
    int take_more = k / cnt;
    int lucky = k % cnt;
    for (int i = 0; i <= id; i++) {
        v[i].first -= take_more;
        if (id - i < lucky)
            v[i].first--;
    }
    for (int i = 0; i < v.size(); i++) {
        H[v[i].second] = v[i].first;
        if (H[i] < 0)
            H[i] = 0;
    }
}
void magic(int i, int x) {
	// Your code here.
	H[i] = x;
}
ll inspect(int l, int r) {
	// Your code here.
	ll sum = 0;
	for (int i = l; i <= r; i++)
        sum += H[i];
    return sum;
}

