/**
* user:  popp-36b
* fname: Iancu Alexandru
* lname: Popp
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:07:43.112249
*/
#include "weirdtree.h"
#include <iostream>

using namespace std;

const long long N = 3e5 + 5;

long long along long_max[4 * N], along long_sum[4 * N];
long long n, q;

void init_max(long long p, long long a, long long b, long long h[]) {
  if (a == b) {
    along long_max[p] = h[a];
    return;
  }
  long long st = (p << 1);
  long long dr = (p << 1) + 1;
  long long m = (a + b) / 2;
  init_max(st, a, m, h);
  init_max(dr, m + 1, b, h);
  along long_max[p] = max(along long_max[st], along long_max[dr]);
}

void init_sum(long long p, long long a, long long b, long long h[]) {
  if (a == b) {
    along long_sum[p] = h[a];
    return;
  }
  long long st = (p << 1);
  long long dr = (p << 1) + 1;
  long long m = (a + b) / 2;
  init_sum(st, a, m, h);
  init_sum(dr, m + 1, b, h);
  along long_sum[p] = along long_sum[st] + along long_sum[dr];
}

void update_max(long long p, long long a, long long b, long long poz, long long val) {
  if (a == b) {
    along long_max[p] = val;
    return;
  }
  long long st = (p << 1);
  long long dr = (p << 1) + 1;
  long long m = (a + b) / 2;
  if (poz <= m)
    update_max(st, a, m, poz, val);
  else
    update_max(dr, m + 1, b, poz, val);
  along long_max[p] = max(along long_max[st], along long_max[dr]);
}

void update_sum(long long p, long long a, long long b, long long poz, long long val) {
  if (a == b) {
    along long_sum[p] = val;
    return;
  }
  long long st = (p << 1);
  long long dr = (p << 1) + 1;
  long long m = (a + b) / 2;
  if (poz <= m)
    update_sum(st, a, m, poz, val);
  else
    update_sum(dr, m + 1, b, poz, val);
  along long_sum[p] = along long_sum[st] + along long_sum[dr];
}

void cut_max(long long p, long long a, long long b, long long l, long long r) {
  if (a == b) {
    --along long_max[p];
    return;
  }
  long long st = (p << 1);
  long long dr = (p << 1) + 1;
  long long m = (a + b) / 2;
  if (l <= m && r > m) {
    if (along long_max[st] >= along long_max[dr])
      cut_max(st, a, m, l, r);
    else
      cut_max(dr, m + 1, b, l, r);
  } else if (l <= m) {
    cut_max(st, a, m, l, r);
  } else {
    cut_max(dr, m + 1, b, l, r);
  }
  along long_max[p] = max(along long_max[st], along long_max[dr]);
}

void cut_sum(long long p, long long a, long long b, long long l, long long r) {
  if (a == b) {
    --along long_sum[p];
    return;
  }
  long long st = (p << 1);
  long long dr = (p << 1) + 1;
  long long m = (a + b) / 2;
  if (l <= m && r > m) {
    if (along long_max[st] >= along long_max[dr])
      cut_sum(st, a, m, l, r);
    else
      cut_sum(dr, m + 1, b, l, r);
  } else if (l <= m) {
    cut_sum(st, a, m, l, r);
  } else {
    cut_sum(dr, m + 1, b, l, r);
  }
  along long_sum[p] = along long_sum[st] + along long_sum[dr];
}

long long query(long long p, long long a, long long b, long long l, long long r) {
  if (a >= l && b <= r)
    return along long_sum[p];
  long long st = (p << 1);
  long long dr = (p << 1) + 1;
  long long m = (a + b) / 2;
  long long ans = 0;
  if (l <= m)
    ans += query(st, a, m, l, r);
  if (r > m)
    ans += query(dr, m + 1, b, l, r);
  return ans;
}

void initialise(long long _n, long long _q, long long h[]) {
	n = _n;
	q = _q;
  init_max(1, 1, n, h);
  init_sum(1, 1, n, h);
}

void cut(long long l, long long r, long long k) {
  cut_sum(1, 1, n, l, r);
	cut_max(1, 1, n, l, r);
}

void magic(long long i, long long x) {
	update_max(1, 1, n, i, x);
	update_sum(1, 1, n, i, x);
}
long long long long inspect(long long l, long long r) {
	return query(1, 1, n, l, r);
	return -1;
}
