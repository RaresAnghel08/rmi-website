/**
* user:  mavrodiev-f84
* fname: Tsvetoslav Valentinov
* lname: Mavrodiev
* task:  NoM
* score: 9.0
* date:  2021-12-17 09:20:16.336040
*/
#include<bits/stdc++.h>
#define pb push_back
#define ll long long
#define mod 1000000007
using namespace std;
int n,m;
int pos[16];
bool check(vector<int> v)
{
    for(int i=0;i<2*n;i++) pos[v[i]]=i;
    for(int i=0;i<n;i++)
    {
        int ind1=pos[i];
        int ind2=pos[i+n];
        if(abs(ind2-ind1)%m==0) return 0;
    }
    return 1;
}
int main()
{
    ios_base::sync_with_stdio(0);
    vector<int> v;
    cin>>n>>m;
    for(int i=0;i<n;i++) v.pb(i);
    for(int i=0;i<n;i++) v.pb(i+n);
    int ans=check(v);
    while(next_permutation(v.begin(),v.end())) ans+=check(v);
    cout<<ans%mod<<endl;
    return 0;
}
