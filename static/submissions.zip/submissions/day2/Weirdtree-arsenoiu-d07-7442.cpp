/**
* user:  arsenoiu-d07
* fname: Iulian George
* lname: Arsenoiu
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:55:38.342581
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

using namespace std;

struct node
{
    long long poz,sum,Max;
    node()
    {
        poz = sum = Max = 0;
    }
};

node ai[2000005];

node nil;

long long n;

long long aux[1000005];

void update(long long poz, long long val, long long nod, long long a,long long b)
{
    if(a==b)
    {
        ai[nod].poz = poz;
        ai[nod].sum = val;
        ai[nod].Max = val;
        return;
    }
    long long mij = (a+b)>>1;
    if(poz<=mij)
    {
        update(poz,val,nod*2,a,mij);
    }
    else
    {
        update(poz,val,nod*2+1,mij+1,b);
    }
    ai[nod].sum = ai[nod*2].sum + ai[nod*2+1].sum;
    if(ai[nod*2].Max>=ai[nod*2+1].Max)
    {
        ai[nod].Max = ai[nod*2].Max;
        ai[nod].poz = ai[nod*2].poz;
    }
    else
    {
        ai[nod].Max = ai[nod*2+1].Max;
        ai[nod].poz = ai[nod*2+1].poz;
    }
}

node query(long long qa, long long qb, long long nod, long long a, long long b)
{
    if(qa==0)
    {
        node rez;
        return rez;
    }
    if(qa<=a && qb>=b)
    {
        return ai[nod];
    }
    long long mij = (a+b)>>1;
    node rez1, rez2;
    if(qa<=mij)
    {
        rez1 = query(qa,qb,nod*2,a,mij);
    }
    if(qb>mij)
    {
        rez2 = query(qa,qb,nod*2+1,mij+1,b);
    }
    if(rez1.sum==0)
    {
        return rez2;
    }
    if(rez2.sum==0)
    {
        return rez1;
    }
    node rez;
    rez.sum = rez1.sum+rez2.sum;
    if(rez1.Max>=rez2.Max)
    {
        rez.Max = rez1.Max;
        rez.poz = rez1.poz;
    }
    else
    {
        rez.Max = rez2.Max;
        rez.poz = rez2.poz;
    }
    return rez;
}

void initialise(int N, int q, int h[])
{
    n = N;
    for(long long i=1; i<=n; i++)
    {
        update(i,h[i],1,1,n);
    }
}

bool cmp(long long i, long long j)
{
    return (aux[i]>aux[j] || (aux[i]==aux[j] && i<j));
}

void cut(int l, int r, int k)
{
    if(r-l+1<=k)
    {
        vector<long long> v;
        for(long long i=l; i<=r; i++)
        {
            v.push_back(i);
            aux[i] = query(i,i,1,1,n).sum;
        }
        sort(v.begin(),v.end(),cmp);
        v.push_back(0);
        vector<long long> cur;
        for(long long i=0; i<v.size()-1; i++)
        {
            long long vali = aux[v[i]];
            long long valj = aux[v[i+1]];
            cur.push_back(v[i]);
            if(vali==0)
            {
                break;
            }
            if(vali==valj)
            {
                continue;
            }
            else
            {
                long long sz = cur.size();
                if(k <= 1LL * sz * (vali-valj))
                {
                    long long cat = k/sz;
                    long long rest = k%sz;
                    long long val = vali-cat;
                    for(long long j=0; j<sz; j++)
                    {
                        update(cur[j],val,1,1,n);
                    }
                    for(long long j=0; j<rest; j++)
                    {
                        update(cur[j],val-1,1,1,n);
                    }
                    return;
                }
                k -= (1LL * sz * (vali-valj));
            }
        }
        for(long long i=l; i<=r; i++)
        {
            update(i,0,1,1,n);
        }
        return;
    }
    for(long long i=1; i<=k; i++)
    {
        node val = query(l,r,1,1,n);
        if(val.Max==0)
        {
            break;
        }
        update(val.poz,val.Max-1,1,1,n);
    }
}

void magic(int poz, int val)
{
    update(poz,val,1,1,n);
}

long long inspect(int l, int r)
{
    return query(l,r,1,1,n).sum;
}

/*long long main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    long long N,Q,H[100005];
    cin>>N>>Q;
    for(long long i=1; i<=N; i++)
    {
        cin>>H[i];
    }
    initialise(N,Q,H);
    for(long long i=1; i<=Q; i++)
    {
        long long t;
        cin>>t;
        if(t==1)
        {
            long long l,r,k;
            cin>>l>>r>>k;
            cut(l,r,k);
        }
        else if(t==2)
        {
            long long poz,val;
            cin>>poz>>val;
            magic(poz,val);
        }
        else
        {
            long long l,r;
            cin>>l>>r;
            cout<<inspect(l,r)<<'\n';
        }
    }
    return 0;
}
*/
