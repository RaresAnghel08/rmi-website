/**
* user:  voicu-de1
* fname: Mihai Valeriu
* lname: Voicu
* task:  Paths
* score: 19.0
* date:  2021-12-17 10:12:14.829037
*/
#include <iostream>
#include <vector>

using namespace std;
using ll=long long;
const int nmax=2005;
int n,k;
#pragma GCC optimize ("O3,Ofast")
#pragma GCC target ("avx2,avx,sse3,sse4")


vector< pair<int,ll> > tree[nmax];

vector<ll> merge(vector<ll> l, vector<ll> r, int cl, ll cr) {
  vector<ll> rez(min((int)l.size()+(int)r.size()-1,k+1),0);
  for(int i=0; i<l.size(); i++) {
    for(int j=0; j<r.size() && j+i<=k; j++) {
      rez[i+j]=max(rez[i+j],l[i]+(cl*(i>0))+r[j]+(cr*(j>0)));
    }
  }
  return rez;
}
static vector<ll> mkdp(int node, int f) {
  vector<ll> dp(2,0),temp;
  //cerr << node << ' '<< f << '\n';
  for(auto x:tree[node]) {
    if(x.first!=f) {
      temp=mkdp(x.first,node);
      dp=merge(dp,temp,0,x.second);
    }
  }
  return dp;
}

static void reroot(int root) {
  cout << mkdp(root,root)[k] <<'\n';
}

int main() {
  cin >> n >> k;
  k=min(k,n);
  for(int i=1,x,y,w; i<n; i++) {
    cin >> x >> y >> w;
    --x;
    --y;
    tree[x].push_back({y,w});
    tree[y].push_back({x,w});
  }
  for(int i=0; i<n; i++)
    reroot(i);
}
