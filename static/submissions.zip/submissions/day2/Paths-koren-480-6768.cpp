/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Paths
* score: 19.0
* date:  2021-12-17 11:15:06.023562
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <bitset>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef pair<ll, ll> pii;
typedef vector<pii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

const int MAX_N = 2001;


struct Seg{
    vii seg;
    vi lazy;
    int n;
    Seg(int m) {
        for (n = 1; n < m; n <<= 1);
        seg.resize(2 * n);
        lazy.resize(2 * n);
    }
    void push(int i) {
        seg[2 * i].x += lazy[i];
        seg[2 * i + 1].x += lazy[i];
        lazy[2 * i] += lazy[i];
        lazy[2 * i + 1] += lazy[i];
        lazy[i] = 0;
    }
    void pull(int i) {
        seg[i] = max(seg[2 * i], seg[2 * i + 1]);
    }
    void update(pii p, int l, int r, int i, int L, int R) {
        if (l <= L && R <= r) {
            lazy[i] += p.x;
            seg[i].x += p.x;
            if (p.y != -1) seg[i].y = p.y;
            return;
        }
        if (R <= l || r <= L) return;
        push(i);
        update(p, l, r, i * 2, L, (L + R) / 2);
        update(p, l, r, i * 2 + 1, (L + R) / 2, R);
        pull(i);
    }
    void Erase() {
        for (auto &p : seg) p = {0, 0};
        for (ll &x : lazy) x = 0;
    }
};

ll ans[MAX_N];

int n, k;

int pre_order[MAX_N], l[MAX_N], r[MAX_N];
pii parent[MAX_N];
bitset<MAX_N> visited;
Seg seg(1);

void Dfs(vector<vii> &tree, int node, int par, int &t, ll w, Seg &seg, ll dist) {
    parent[node] = {par, w};
    seg.update({dist, t}, t, t + 1, 1, 0, n);
    l[node] = t;
    pre_order[t++] = node;
    for (pii p : tree[node]) {
        if (p.x != par) {
            Dfs(tree, p.x, node, t, p.y, seg, dist + p.y);
        }
    }
    r[node] = t;
}

void Solve(vector<vii> &tree, int node) {
    int t = 0;
    Dfs(tree, node, 0, t, 0, seg, 0);
    int K = k;
    visited[0] = true;
    while (K--) {
        pii p = seg.seg[1];
        ans[node] += p.x;
        int u = pre_order[p.y];
        while (!visited[u]) {
            seg.update({-parent[u].y, -1}, l[u], r[u], 1, 0, n);
            visited[u] = true;
            u = parent[u].x;
        }
    }
    visited.reset();
    seg.Erase();
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    vector<vii> tree(n + 1);
    for (int i = 0; i < n - 1; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        tree[a].push_back({b, c});
        tree[b].push_back({a, c});
    }
    seg = Seg(n + 1);
    for (int i = 1; i <= n; i++) {
        Solve(tree, i);
    }
    for (int i = 1; i <= n; i++) cout << ans[i] << '\n';
}
