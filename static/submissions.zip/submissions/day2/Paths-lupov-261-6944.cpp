/**
* user:  lupov-261
* fname: Ivan Stiliyanov
* lname: Lupov
* task:  Paths
* score: 8.0
* date:  2021-12-17 11:26:33.965952
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>

#define ll long long
#define pb push_back
#define fr first
#define sc second
#define bit(x) x&(-x)
#define all(x) x.begin(), x.end()
#define de(x) cout << #x << " = " << x << endl;

using namespace std;
using namespace __gnu_pbds;

template<class T> using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<class T> using matrix = vector<vector<T>>;

const int MAXN = 20;

ll n, k, ans;
matrix<ll> G;
pair<ll, ll> dp[MAXN];
map<pair<int, int>, ll> mp, mp2;

void dfs_find(ll u, ll p){
	dp[u] = {0, u};
	for(auto v : G[u]){
		if(v == p) continue;
		dfs_find(v, u);
		dp[u] = max(dp[u], {dp[v].fr + mp[{min(u, v), max(u, v)}], dp[v].sc});
	}
}

bool dfs_null(ll u, ll p, ll c){
	if(u == c) return true;
	bool flag = false;
	for(auto v : G[u]){
		if(v == p) continue;
		bool mem = dfs_null(v, u, c);
		flag |= mem;
		if(mem){
			ans += mp[{min(u, v), max(u, v)}];
			mp[{min(u, v), max(u, v)}] = 0;
		}
	}
	return flag;
}

int main(){
	cin >> n >> k;
	G.resize(n + 1);
	for(int i = 0; i < n - 1; i ++){
		ll u, v, c; cin >> u >> v >> c;
		mp[{min(u, v), max(u, v)}] = mp2[{min(u, v), max(u, v)}] = c;
		G[u].pb(v);
		G[v].pb(u);
	}
	for(int u = 1; u <= n; u ++){
		mp = mp2;
		for(int i = 1; i <= k; i ++){
			for(int j = 0; j < MAXN; j ++) dp[j] = {0, 0};
			dfs_find(u, u);
			dfs_null(u, u, dp[u].sc);
		}
		cout << ans << endl;
		ans = 0;
	}
}
/*
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1

28
28
28
32
30
32
28
32
32
29
30
*/
