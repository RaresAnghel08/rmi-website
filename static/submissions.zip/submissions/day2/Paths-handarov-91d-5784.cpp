/**
* user:  handarov-91d
* fname: Radostin Nikolaev
* lname: Handarov
* task:  Paths
* score: 8.0
* date:  2021-12-17 09:59:56.249717
*/
#include <bits/stdc++.h>

#pragma GCC optimize "-O3"

#define endl '\n'
#define trace(x) cerr << #x << " = " << x << endl

using namespace std;

void setIO() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
}

int n, k;
vector<vector<pair<int, int>>> adj;
vector<vector<int>> graph;

void read() {
    cin >> n >> k;

    adj.resize(n + 1);
    graph.resize(n + 1, vector<int>(n + 1));
    for (int i = 1; i < n; i++) {
        int from, to, cnt;
        cin >> from >> to >> cnt;

        adj[from].emplace_back(to, cnt);
        adj[to].emplace_back(from, cnt);
        graph[from][to] = graph[to][from] = cnt;
    }
}

vector<int> dist, parent;
vector<vector<int>> cost;

void dfs(int node, int par = -1) {
    for (auto &i : adj[node]) {
        if (i.first == par) {
            continue;
        }

        dist[i.first] = dist[node] + cost[node][i.first];
        parent[i.first] = node;
        dfs(i.first, node);
    }
}

void mark(int node) {
    while (parent[node] != -1) {
        cost[parent[node]][node] = cost[node][parent[node]] = 0;
        node = parent[node];
    }
}

long long findMaxTotal(int root) {
    long long best = 0;
    dist.resize(n + 1);
    parent.resize(n + 1);
    for (int mask = 0; mask < (1 << n); mask++) {
        if (__builtin_popcount(mask) != k) {
            continue;
        }

        long long total = 0;
        cost = graph;
        for (int i = 1; i <= n; i++) {
            if ((mask >> (i - 1)) & 1) {
                dist[root] = 0;
                parent[root] = -1;
                dfs(root);

                total += dist[i];
                mark(i);
            }
        }

        best = max(best, total);
    }

    return best;
}

void solve() {
    for (int i = 1; i <= n; i++) {
        cout << findMaxTotal(i) << endl;
    }
}

int main() {
    setIO();

    read();

    solve();
}
