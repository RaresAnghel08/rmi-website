/**
* user:  baliukonis-9a4
* fname: Tsimafei
* lname: Baliukonis
* task:  Paths
* score: 19.0
* date:  2021-12-17 08:55:01.873992
*/
#pragma GCC optimize("O3")

#include<bits/stdc++.h>
#include<ext/pb_ds/tree_policy.hpp>
#include<ext/pb_ds/assoc_container.hpp>

#define ll long long
#define f first
#define s second
#define pb push_back

using namespace std;


const ll MOD = 1e9 + 7;
ll n, k;

vector<ll> merg(vector<ll> &a, vector<ll> &b) {
    vector<ll> c(a.size() + b.size(), -1e18);
    for(int j = 0; j < a.size(); j++)
        for(int e = 0; e < b.size(); e++) {
            if(j + e > k) break;
            c[j + e] = max(c[j + e], a[j] + b[e]);
        }

    while(c.back() == -1e18 || c.size() > k + 1) c.pop_back();
    return c;
}

vector<pair<ll,ll>> v[2007];
vector<ll> now2[2007][2007];
vector<ll> nowl[2007][2007];
vector<ll> nowr[2007][2007];
bool used[2007];

vector<ll> dfs(ll v1, ll pr) {
    if(now2[v1][pr].size()) return now2[v1][pr];
    if(used[v1] && v1 != pr) return merg(nowr[v1][pr], nowl[v1][pr]);
    vector<ll> now = {0};
    bool f = 1, f2 = 1;

    for(auto to: v[v1]) {
        if(to.f == pr) {
            continue;
        }
        f = 0;
        vector<ll> e = dfs(to.f, v1);
        for(int  j = 1; j < e.size(); j++) e[j] += to.s;
        now = merg(now, e);
    }

        if(!used[v1]) {
        f2 = 1;
        for(auto to: v[v1]) {
          if(now2[to.f][v1].size() == 0) f2 = 0;
        }
        if(f2) {
            used[v1] = 1;
            vector<ll> nowx = {0};
            for(auto to: v[v1]) {
                nowl[v1][to.f] = nowx;
                vector<ll> e = now2[to.f][v1];
                for(int j = 1; j < e.size(); j++) e[j] += to.s;
                nowx = merg(nowx, e);
            }
            nowx = {0};
            reverse(v[v1].begin(), v[v1].end());
            for(auto to: v[v1]) {
                nowr[v1][to.f] = nowx;
                vector<ll> e = now2[to.f][v1];
                for(int j = 1; j < e.size(); j++) e[j] += to.s;
                nowx = merg(nowx, e);
            }
            reverse(v[v1].begin(), v[v1].end());
            nowr[v1][v1] = nowx;
            nowl[v1][v1] = {0};
        }
    }

    if(f) now.pb(0);
    now2[v1][pr] = now;
    return now;
}




int32_t main() {

    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif // LOCAL

    cin >> n >> k;
    k = min(k, n);
    for(int j = 1; j < n; j++) {
        ll x, y, cost;
        cin >> x >> y >> cost;
        x--;
        y--;
        v[x].pb({y, cost});
        v[y].pb({x, cost});
    }



    for(int j = 0; j < n; j++) {
        cout << dfs(j, j).back() << '\n';
    }
}
