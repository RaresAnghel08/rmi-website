/**
* user:  idiriz-fcd
* fname: Nermin Hyusmen
* lname: Idiriz
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:39:11.677417
*/
#include<bits/stdc++.h>
#include "weirdtree.h"
const int MAXN=80010;
int n,q,height[MAXN];
void initialise(int N, int Q, int h[])
{
    n=N;
    q=Q;
    for(int i=1; i<=n; i++)
        height[i]=h[i];
}
void cut(int l, int r, int k)
{
    if(l==r)
    {
        if(height[l]>=k)
        {
            height[l]-=k;
        }
        else
        {
            height[l]=0;
        }
        return;
    }
    int suma=0;
    for(int i=l; i<=r; i++)
        suma+=height[i];
    while(k>0&&suma>0)
    {
        int max1=-1,max2=-1;
        for(int i=l; i<=r; i++)
        {
            if(max1==-1||height[i]>height[max1])
            {
                max2=max1;
                max1=i;
            }
            else if(max2==-1||height[i]>height[max2])
            {
                max2=i;
            }
        }
        if(height[max1]==height[max2])
        {
            height[max1]--;
            suma--;
            k--;
        }
        else
        {
            int diff=height[max1]-height[max2];
            if(diff>k)
            {
                height[max1]-=k;
                suma-=k;
                k=0;
            }
            else
            {
                height[max1]-=diff;
                suma-=diff;
                k-=diff;
            }
        }
    }
}
void magic(int i, int x)
{
    height[i]=x;
}
long long int inspect(int l, int r)
{
    long long int ans=0;
    for(int i=l; i<=r; i++)
        ans+=height[i];
    return ans;
}
