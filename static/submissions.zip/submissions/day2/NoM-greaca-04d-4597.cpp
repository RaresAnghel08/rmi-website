/**
* user:  greaca-04d
* fname: Albert Antoniu
* lname: Greaca
* task:  NoM
* score: 9.0
* date:  2021-12-17 08:12:25.277550
*/
#include<bits/stdc++.h>
#define ll long long
using namespace std;
int v[15],poz[15],f[15];
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    int n,i,m,cnt=0;
    scanf("%d%d",&n,&m);
    for(i=1;i<=2*n;i++)
        v[i]=i;
    do{
        if (v[1]!=1)
            break;
        for(i=1;i<=2*n;i++)
            poz[i]=0;
        int ok=1;
        for(i=1;i<=2*n;i++){
            if (v[i]>n && poz[v[i]-n])
                if ((i-poz[v[i]-n])%m==0)
                    ok=0;
            if (v[i]<=n && poz[v[i]+n])
                if ((i-poz[v[i]+n])%m==0)
                    ok=0;
            poz[v[i]]=i;
        }
        if (ok){
            //for(i=1;i<=2*n;i++)
             //   if (v[i]==n+1)
                //    f[i]++;
            cnt++;
        }
    }while(next_permutation(v+1,v+2*n+1));
    printf("%d\n",cnt*2*n);
    //for(i=1;i<=2*n;i++)
      //  printf("%d ",f[i]);
return 0;
}
