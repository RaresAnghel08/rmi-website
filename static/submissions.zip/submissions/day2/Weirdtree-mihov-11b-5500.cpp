/**
* user:  mihov-11b
* fname: Rumen
* lname: Mihov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:35:45.133542
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
const int maxn  = 3e5+5;
const int G = 1005;
int w[maxn];
int arr[G][G];
int suff[G][G];
int maxel[G];int pos[G];
int groups;
 int n;
 void create_group(int k)
 {
     int l = k*G;
     int r = (k+1)*G-1;
     int i,p=l;
     for(i = 1;i<=G;i++)
     {
         arr[k][i] = w[p];
         p++;
     }
     sort(arr[k]+1,arr[k]+G+1);
     maxel[k] = arr[k][G];

     suff[k][G+1] = 0;
     for(i = G;i>=1;i--)
     {
         suff[k][i]= suff[k][i+1]+arr[k][i];
         if(arr[k][i]==maxel[k])pos[k] = i;
     }
 }
 void update_array(int k)
 {
     int i;
     int l=k*G;
     for(i = 1;i<=G;i++)
     {
         if(maxel[k]<w[l])w[l] = maxel[k];
         l++;
     }
 }
 long long find_sum(int k)
 {
     long long ans = suff[k][1] - suff[k][pos[k]] + (G-pos[k]+1)*maxel[k];
     return ans;
 }
void initialise(int N, int Q, int h[]) {
	int i,j;
	n = N;
	for(i=1;i<=N;i++)
    {
        w[i] = h[i];
    }
    for(i=0;i*G<=n;i++)
    {
        create_group(i);
    }
    groups = i-1;
}
long long sum_large_group(int k, int t)
{
    if(t>maxel[k])return 0;
    if(t+1==maxel[k])return (G-pos[k]+1);
    int uk1 = 1;
    int uk2 = G,mid;
    while(uk1<uk2)
    {
        mid = (uk1+uk2)/2;
        if(arr[k][mid]<=t)uk1 = mid+1;
        else
            uk2 = mid;

    }
    if(uk1>G)return 0;
    long long ans = suff[k][uk1] - suff[k][pos[k]] + (G-pos[k]+1)*maxel[k] - (G-uk1+1)*t;
    return ans;
}
long long sum_large(int l, int r, int t)
{
    int f = l/G;
    update_array(f);
    long long sum=0;
    int i;
    for(i = l;i/G<=f&&i<=r;i++)
    {
       // cout<<w[i]<<"&&"<<endl;
        if(w[i]>t)sum+=(w[i]-t);
    }
    int s = r/G;
    if(s==f)return sum;
    for(i = f+1;i<s;i++)
        sum+=sum_large_group(i,t);
    for(i = s*G;i<=r;i++)
        if(w[i]>t)sum+=(w[i]-t);
    return sum;
}
int find_pos(int k, int t)
{
    int uk1 = 1;
    int uk2 = G;
    int mid;
    while(uk1<uk2)
    {
        mid= (uk1+uk2)/2;
        if(arr[k][mid]<t)uk1=mid+1;
        else
            uk2 = mid;
    }
    return uk1;
}
void update_max(int l, int r, int t)
{

    int i;
    int f=  l/G;
    update_array(f);
    for(i = l;i<=r&&i/G<=f;i++)
    {
        if(w[i]>t)w[i] = t;
    }
    create_group(f);
    int s = r/G;
    if(f==s)return ;
    for(i = f+1;i<s;i++)
    {
        maxel[i] = t;
        pos[i] = find_pos(i,t);
    }
    update_array(s);
    for(i=i*G;i<=r;i++)
    {
        if(w[i]>t)w[i] = t;
    }
    create_group(s);
}
void cut(int l, int r, int k) {
	int uk1 = 0,uk2 = 1e9,mid;
	while(uk1<uk2)
    {

        mid = (uk1+uk2)/2;
        if(sum_large(l,r,mid)<k)uk2 = mid;
        else
            uk1 = mid+1;
    }  /*  cout<<"HEre"<<endl;
       for(int i = 1;i<=n;i++)
        cout<<w[i]<<" ";
    cout<<endl;*/
    int t = sum_large(l,r,uk2); update_max(l,r,uk2);

  /* cout<<uk2<<" "<<t<<endl;
    for(int i = 1;i<=n;i++)
        cout<<w[i]<<" ";
    cout<<endl;*/
    if(uk2==0)return ;
    int p = sum_large(l,l/G+G-1,uk2-1);
    int i,j;
    int f = l/G;

    if(p+t<k)
    {

        update_array(f);
        for(i = l;i<r&&i/G<=f;i++)
        {
            if(w[i]>uk2-1)w[i]=  uk2-1;
        }
        create_group(f);
    }
    else
    {

        update_array(f);
        for(i = l;t<k&&i<=r&&i/G<=f;i++)
        {
            int prev = w[i];
            if(w[i]>uk2-1)w[i]= max( uk2-1,w[i]-(k-t));
            t+=(prev-w[i]);
        }
        create_group(f);
        return ;
    }
    t+=p;
    int s=r/G;
    if(s==f)return ;
    for(i = f+1;i<s;i++)
    {
        p = sum_large_group(i,uk2-1);
        if(p+t<k)
        {
             maxel[i] = uk2-1;
        pos[i] = find_pos(i,uk2-1);
        }
        else
        {
            update_array(i);
            for(j = i*G;t<k&&j/G<=i;j++)
            {
                int prev = w[j];
                if(w[j]>uk2-1)w[j]= max( uk2-1,w[j]-(k-t));
                t+=(prev-w[j]);
            }
            create_group(i);
            return ;
        }
    }


        update_array(s);
        for(i = s*G;t<k&&i<=r;i++)
        {
            int prev = w[i];
            if(w[i]>uk2-1)w[i]= max( uk2-1,w[i]-(k-t));
            t+=(prev-w[i]);
        }
        create_group(s);
        return ;
}
void magic(int i, int x) {
	update_array(i/G);
	w[i] = x;
	create_group(i/G);
}
long long int inspect(int l, int r) {
	int f=  l/G;
	update_array(f);
	create_group(f);
	long long sum = 0;
	int i;
/*	for(i=1;i<=n;i++)
        cout<<w[i]<<" ";
    cout<<endl;*/
	for(i = l;i/G<=f&&i<=r;i++)
    {
        sum+=w[i];
    }
    int s = r/G;
    if(s==f)return sum;
    for(i = f+1;i<s;i++)
        sum+=find_sum(i);
    update_array(s);
    create_group(s);
    for(i = s*G; i<=r;i++)
        sum+=w[i];
    return sum;

}
