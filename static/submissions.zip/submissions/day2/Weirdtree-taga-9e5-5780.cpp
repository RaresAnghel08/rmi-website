/**
* user:  taga-9e5
* fname: Ștefan
* lname: Țaga
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:59:22.308189
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

using namespace std;
int n,v[1005];
void initialise(int N, int Q, int h[]) {
    n=N;
	for (int i=1;i<=N;i++)
    {
        v[i]=h[i];
    }
}
void cut(int l, int r, int k) {
     vector <int> ceau;
     int i,st,dr,mij;
     for (i=l;i<=r;i++)
     {
         ceau.push_back(v[i]);
     }
     sort (ceau.begin(),ceau.end());
     st=0;
     dr=ceau[ceau.size()-1];
     int sol=0;
     while (st<=dr)
     {
         int sum=0;
         mij=(st+dr)/2;
         for (int t=0;t<(int)ceau.size();t++)
         {
             if (ceau[t]>mij)
             {
                 sum=sum+ceau[t]-mij;
             }
         }
         if (sum<=k)
         {
             sol=mij;
             dr=mij-1;
         }
         else
         {
             st=mij+1;
         }
     }
     for (i=l;i<=r;i++)
     {
         if (v[i]>sol)
         {
             k=k-(v[i]-sol);
             v[i]=sol;
         }
     }
     for (i=l;i<=r;i++)
     {
         if (sol!=0&&v[i]==sol&&k)
         {
             v[i]--;
             k--;
         }
     }
     return;
}
void magic(int i, int x) {
     v[i]=x;
     return;
}
long long int inspect(int l, int r) {
	long long sum=0,i;
	for (i=l;i<=r;i++)
    {
        sum=sum+v[i];
    }
    return sum;
}
#ifdef HOME
int main() {
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}

#endif // HOME
