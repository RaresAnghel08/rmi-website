/**
* user:  karimov-0d4
* fname: Renat Airatovich
* lname: Karimov
* task:  Paths
* score: 56.0
* date:  2021-12-17 09:22:59.977749
*/
#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb emplace_back
#define ld long double

const int N = 1e5 + 10, M = 2e5 + 10;
vector<pair<int,int>> g[N];
int val[N], go[N], tin[N], tout[N];
vector<int> ans(N);
vector<pair<int,int>> all;
vector<int> u;
int root, cnt = 0, n, k;
pair<int,int> t[4 * N];
int tr[4 * M], sum[4 * M];
vector<pair<int,int>> bst[N], pr[N];
bool need = 0;

void update(int v, int l, int r, int pos, int val){
    if (l == r){
        t[v].first += val;
        t[v].second = l;
        return;
    }
    int m = (l + r) / 2;
    if (pos <= m) update(2 * v, l, m, pos, val);
    else update(2 * v + 1, m + 1, r, pos, val);
    t[v] = max(t[v * 2], t[v * 2 + 1]);
}

void update2(int v, int l, int r, int pos, int val){
    if (l == r){
        sum[v] += val;
        if (val < 0) tr[v]--;
        else tr[v]++;
        return;
    }
    int m = (l + r) / 2;
    if (pos <= m) update2(2 * v, l, m, pos, val);
    else update2(2 * v + 1, m + 1, r, pos, val);
    tr[v] = tr[v * 2] + tr[v * 2 + 1];
    sum[v] = sum[v * 2] + sum[v * 2 + 1];
}

pair<int,int> get(int v, int tl, int tr, int l, int r){
    if (l > r) return {-1, -1};
    if (tl == l && tr == r){
        return t[v];
    }
    int tm = (tl + tr) / 2;
    return max(get(2 * v, tl, tm, l, min(r, tm)), get(2 * v + 1, tm + 1, tr, max(l, tm + 1), r));
}

void dfs(int v, int p){
    tin[v] = cnt++;
    pair<int,int> bst{-1, -1};
    for (auto to : g[v]){
        if (to.first != p){
            dfs(to.first, v);
            bst = max(bst, make_pair(val[to.first] + to.second, to.first));
        }
    }
    if (bst.first == -1){
        val[v] = 0;
        go[v] = -1;
    }
    else{
        val[v] = bst.first, go[v] = bst.second;
    }
    tout[v] = cnt - 1;
}

void zhfs(int v, int p, int sum){
    if (go[v] == -1) all.pb(v, sum);
    else all.pb(v, 0);
    for (auto to : g[v]){
        if (to.first != p){
            if (to.first == go[v]){
                zhfs(to.first, v, sum + to.second);
            }
            else{
                zhfs(to.first, v, to.second);
            }
        }
    }
}

int go_v(int v, int l, int r, int k){
    if (l == r) return k * u[l];
    int m = (l + r) / 2;
    if (tr[v * 2 + 1] >= k){
        return go_v(2 * v + 1, m + 1, r, k);
    }
    else{
        return sum[2 * v + 1] + go_v(2 * v, l, m, k - tr[v * 2 + 1]);
    }
}

int get(){
    return go_v(1, 0, M - 1, k);
}

void change(int v, int val){
    if (need){
        int j = lower_bound(u.begin(), u.end(), get(1, 0, n - 1, v, v).first) - u.begin();
        update2(1, 0, M - 1, j, -u[j]);
        update(1, 0, n - 1, v, val);
        j = lower_bound(u.begin(), u.end(), get(1, 0, n - 1, v, v).first) - u.begin();
        update2(1, 0, M - 1, j, u[j]);
    }
    if (!need) {
        update(1, 0, n - 1, v, val);
        u.pb(get(1, 0, n - 1, v, v).first);
    }
}

void walk(int v, int p){
    if (need){
        ans[v] = get();
    }
    int i = 0;
    for (auto to : g[v]){
        if (to.first != p){
            if (!need){
                bst[v].pb(-1, -1);
                pr[v].pb(-1, -1);
                bst[v][i] = max(bst[v][i], get(1, 0, n - 1, 0, tin[to.first] - 1));
                bst[v][i] = max(bst[v][i], get(1, 0, n - 1, tout[to.first] + 1, n - 1));
                pr[v][i] = get(1, 0, n - 1, tin[to.first], tout[to.first]);
            }
            if (bst[v][i].first != -1){
                change(bst[v][i].second, to.second);
            }
            change(pr[v][i].second, -to.second);
            walk(to.first, v);
            if (bst[v][i].first != -1){
                change(bst[v][i].second, -to.second);
            }
            change(pr[v][i].second, to.second);
            i++;
        }
    }
}

vector<int> solve(int N, int K, vector<int> a, vector<int> b, vector<int> c){
    n = N, k = K;
    cnt = 0;
    for (int i = 0; i < n; i++){
        g[i].clear();
    }
    for (int i = 0; i < n - 1; i++){
        g[a[i]].pb(b[i], c[i]);
        g[b[i]].pb(a[i], c[i]);
    }
    root = 0;
    while(g[root].size() == 1) root++;
    dfs(root, -1);
    zhfs(root, -1, 0);
    for (auto to : all){
        update(1, 0, n - 1, tin[to.first], to.second);
        u.pb(to.second);
    }
    walk(root, -1);
    sort(u.begin(), u.end());
    u.erase(unique(u.begin(), u.end()), u.end());
    for (auto to : all){
        int j = lower_bound(u.begin(), u.end(), to.second) - u.begin();
        update2(1, 0, M - 1, j, u[j]);
    }
    need = 1;
    walk(root, -1);
    vector<int> arr(ans.begin(), ans.begin() + N);
    return arr;
}

mt19937 rnd(51);

signed main()
{
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif // LOCAL
    int n, k;
    cin >> n >> k;
    vector<int> a(n - 1), b(n - 1), c(n - 1);
    for (int i = 0; i < n - 1; i++){
        cin >> a[i] >> b[i] >> c[i];
        a[i]--, b[i]--;
    }
    vector<int> ans = solve(n, k, a, b, c);
    for (auto to : ans){
        cout << to << '\n';
    }
    return 0;
}
