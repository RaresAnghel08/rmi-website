/**
* user:  haivas-4ca
* fname: Vlad
* lname: Haivas
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:37:46.914292
*/
#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "

using namespace std;
typedef long long ll;
typedef pair <int, int> pii;

const ll NMAX = 10;
const ll MOD = 1000000007;
const ll nr_of_bits = 21;
const ll BLOCK = 420;
const ll KMAX = 2001;

int mat[NMAX][NMAX];

int main()
{
//    ifstream cin(".in");
//    ofstream cout(".out");
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    mat[1][1] = 0;
    mat[1][2] = 2;
    mat[1][3] = 2;
    mat[1][4] = 2;
    mat[1][5] = 2;
    mat[2][1] = 0;
    mat[2][2] = 15;
    mat[2][3] = 15;
    mat[2][4] = 22;
    mat[2][5] = 22;
    mat[3][1] = 0;
    mat[3][2] = 271;
    mat[3][3] = 359;
    mat[3][4] = 450;
    mat[3][5] = 538;
    mat[4][1] = 0;
    mat[4][2] = 8767;
    mat[4][3] = 13127;
    mat[4][4] = 21810;
    mat[4][5] = 24730;
    mat[5][1] = 0;
    mat[5][2] = 441919;
    mat[5][3] = 794183;
    mat[5][4] = 1367346;
    mat[5][5] = 1996186;
    int n, m;
    cin >> n >> m;
    cout << mat[n][m];
    return 0;
}
