/**
* user:  verde-fd1
* fname: Flaviu-Cristian
* lname: Verde
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 09:04:38.382145
*/
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast","unroll-loops")
#pragma GCC target("avx","avx2","fma")
#include "weirdtree.h"
using namespace std;
int v[1001],n,q;
void initialise ( int N, int Q, int h [])
{
    n=N;
    q=Q;
    for(int i=1; i<=n; i++)
        v[i]=h[i];
}
int suma(int sus,int st,int dr)
{
    long long s=0;
    for(int i=st;i<=dr;i++)
        s+=max(v[i]-sus,0);
    if(s<=INT_MAX)
        return s;
    return INT_MAX;
}
pair <int,int> cautbin(int st,int dr,int val)
{
    int r=0,pas=1<<29;
    while(pas)
    {
        if(suma(r+pas,st,dr)>val)
            r+=pas;
        pas/=2;
    }
    return {r+1,val-suma(r+1,st,dr)};
}
void cut ( int l, int r, int k )
{
    pair <int,int> ans=cautbin(l,r,k);
    int ramas=ans.second;
    for(int i=l;i<=r;i++)
        if(v[i]>=ans.first)
    {
        if(ramas)
        {
            ramas--;
            v[i]=max(ans.first-1,0);
        }
        else
            v[i]=ans.first;
    }
}
void magic(int i,int x)
{
    return;
}
long long int inspect ( int l, int r )
{
    long long sum=0;
    for(int i=l;i<=r;i++)
        sum+=v[i];
    return sum;
}
