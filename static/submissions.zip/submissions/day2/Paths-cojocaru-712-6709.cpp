/**
* user:  cojocaru-712
* fname: Ovidiu
* lname: Cojocaru
* task:  Paths
* score: 0.0
* date:  2021-12-17 11:11:44.967444
*/
#include <bits/stdc++.h>
using namespace std;

#define ll long long

ll pr[1001],a[1001],safe[1001];
vector<int> v;

void change(int x,int p)
{
    if(x == 0)return;
    int d;
    if(pr[x] != 0)change(pr[x],x);
    a[x] = a[p];
    pr[x] = p;
    pr[p] = 0;
    return;
}

long long calcul(int i)
{
    if(pr[i] == 0)return 0;
    else return a[i] + calcul(pr[i]);
}

void del(int i)
{
    if(pr[i] != 0)del(pr[i]);
    a[i] = 0;
    return;
}

long long solve(int k)
{
    ll ans[k+1];
    for(int i = 1;i <= k;i++)
    {
        int n = v.size();
        ll x = 0,y = 0;
        for(int j = 0;j < n;j++)
        {
            if(pr[v[j]] == 0 || a[v[j]] == 0)continue;
            ll p = calcul(v[j]);
            if(x < p)
            {
                x = p;
                y = j;
            }
        }
        ans[i] = x;
        del(v[y]);
    }
    sort(ans+1,ans+k+1);
    ans[0] = ans[1];
    for(int i = 2;i <= k;i++)ans[0] += ans[i];
    return ans[0];
}

int main()
{
    ll n,k;
    cin>>n>>k;
    int m[1001];
    for(int i = 1;i <= n;i++){pr[i] = 0;a[i] = 0;m[i] = 0;}
    for(int i = 1;i < n;i++)
    {
        ll x,y,z;
        cin>>x>>y>>z;
        if(x == 1)
        {
            if(pr[y] != 0)change(pr[y],y);
            else pr[y] = x;
            a[y] = z;
        }
        else if(y == 1)
        {
            if(pr[x] != 0)change(pr[x],x);
            else pr[x] = y;
            a[x] = z;
        }
        else if(pr[x] != 0 && pr[y] != 0)
        {
            change(pr[x],x);
            pr[x] = y;
            a[x] = z;
        }
        else
        {
            if(pr[x] == 0)
            {
                pr[x] = y;
                a[x] = z;
            }
            else
            {
                pr[y] = x;
                a[y] = z;
            }
        }
    }
    for(int i = 1;i <= n;i++)m[pr[i]] = 1;
    for(int i = 1;i <= n;i++)if(m[i] == 0)v.push_back(i);
    a[0] = 0;
    for(int i = 1;i <= n;i++)
    {
        change(pr[i],i);
        for(int j = 1;j <= n;j++)safe[j] = a[j];
        cout<<solve(k)<<endl;
        for(int j = 1;j <= n;j++)a[j] = safe[j];
    }
    return 0;
}
