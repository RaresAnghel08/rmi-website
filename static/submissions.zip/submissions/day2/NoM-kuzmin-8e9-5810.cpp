/**
* user:  kuzmin-8e9
* fname: Daniil Aleksandrovich
* lname: Kuzmin
* task:  NoM
* score: 0.0
* date:  2021-12-17 10:02:15.185748
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define int ll
#define f first
#define s second
#define pii pair<int, int>
#define vi vector<int>
#define pb push_back

mt19937 rnd(time(0));



const int mod = 1e9 + 7;

int fastpow(int a, int b) {
	if (b == 0)
		return 1;
	if (b & 1)
		return a * fastpow(a, b - 1) % mod;
	int t = fastpow(a, b / 2);
	return t * t % mod;
}

void solve() {
	int n, m;
	cin >> n >> m;
	int a[2 * n];
	iota(a, a + n, 0);
	iota(a + n, a + 2 * n, 0);
	sort(a, a + 2 * n);
	int ans = 0;
	do {
		bool ok = 1;
		for (int j = 0; j + m < 2 * n; ++j) {
			ok &= a[j] != a[j + m];
		}
		if (ok) {
			ans += fastpow(2, n);
			ans %= mod;
		}
	} while (next_permutation(a, a + 2 * n));
	cout << ans << endl;
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	// cin >> t;
	while (t--)
		solve();
}