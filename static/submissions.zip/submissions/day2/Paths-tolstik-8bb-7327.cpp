/**
* user:  tolstik-8bb
* fname: Bogdan
* lname: Tolstik
* task:  Paths
* score: 48.0
* date:  2021-12-17 11:50:58.832052
*/
#include <bits/stdc++.h>

#define f first
#define s second
#define vec vector
#define pb push_back
#define m_p make_pair
#define sz(x) (int)(x).size()
#define all(x) (x).begin(),(x).end()
#define rall(x) (x).rbegin(),(x).rend()
#define fast_rmi ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);

//#pragma GCC optimize("unroll-loops")
//#pragma GCC target("avx,avx2,tune=native")

using namespace std;
typedef pair<int,int> pii;
typedef long long ll;
typedef pair<ll,int> pli;
template<class T> bool umax(T &a,const T &b){return (a<b?a=b,1:0);}

const int N=1e5+1;
const ll inf=1e18;
//struct segtree{
    ll t[4*N];
    ll p[4*N];
    ll a[N];
    void build(int v,int tl,int tr){
        p[v]=0;
        if(tl==tr){
            t[v]=a[tl];
            return;
        }
        else{
            int tm=(tl+tr)>>1;
            build(2*v,tl,tm);build(2*v+1,tm+1,tr);
            t[v]=max(t[2*v],t[2*v+1]);
        }
    }
    void push(int v,int tl,int tr){
        if(!p[v])
            return;
        for(auto &u : {2*v,2*v+1}){
            t[u]+=p[v];
            p[u]+=p[v];
        }
        p[v]=0;
    }
    void upd(int id,int x,int v,int tl,int tr){
        if(tl==tr){
            t[v]=x;
            return;
        }
        int tm=(tl+tr)>>1;push(v,tl,tr);
        if(tm>=id)
            upd(id,x,2*v,tl,tm);
        else
            upd(id,x,2*v+1,tm+1,tr);
        t[v]=max(t[2*v],t[2*v+1]);
    }
    void add(int l,int r,int x,int v,int tl,int tr){
        if(tl>=l&&tr<=r){
            t[v]+=x;
            p[v]+=x;
            return;
        }
        if(tl>r||tr<l)
            return;
        int tm=(tl+tr)>>1;push(v,tl,tr);
        add(l,r,x,2*v,tl,tm);add(l,r,x,2*v+1,tm+1,tr);
        t[v]=max(t[2*v],t[2*v+1]);
    }
    pli geti(int v,int tl,int tr){
        if(tl==tr){
            return {t[v],tl};
        }
        int tm=(tl+tr)>>1;push(v,tl,tr);
        if(t[2*v]>t[2*v+1])
            return geti(2*v,tl,tm);
        else
            return geti(2*v+1,tm+1,tr);
    }
//    pli get(int l,int r,int v,int tl,int tr){
//        if(tl>=l&&tr<=r)
//            return t[v];
//        if(tl>r||tr<l)
//            return m_p(0,-1);
//        int tm=(tl+tr)>>1;push(v,tl,tr);
//        return max(get(l,r,2*v,tl,tm),get(l,r,2*v+1,tm+1,tr));
//    }
//}sega;

vec<pii> g[N];
int in[N],out[N],tt;

int cst[N],n;
bool del[N];
int pr[N];
int obr[N];
ll ans[N];
ll dp[N];
bool lst[N];
void dfs3(int v,int p){
    lst[v]=(sz(g[v])==1);
    for(auto &z : g[v]){
        if(z.f==p)
            continue;
        dfs3(z.f,v);
    }
}
void dfs(int v,ll eb,int p){
    in[v]=tt;
    tt+=(lst[v]);
    if(lst[v])
        obr[in[v]]=v;
    a[in[v]]=eb;
    del[v]=0;
    for(auto &z : g[v]){
        if(z.f==p) continue;
        pr[z.f]=v;cst[z.f]=z.s;
        dfs(z.f,eb+z.s,v);
        umax(dp[v],dp[z.f]+z.s);
    }
    out[v]=tt-1;
}

void dfs2(int v,ll mx,int p){
    vec<ll>pref,suf;
    vec<pii> go;
    for(auto &z : g[v]){
        if(z.f!=p)
            go.pb(z);
    }
    int m=sz(go);
    ll me=mx;
    pref.assign(m,0);
    for(int i=0;i<m;i++){
        pref[i]=me;
        umax(me,dp[go[i].f]+go[i].s);
    }
    suf=pref;
    me=mx;
    for(int i=m-1;i>=0;i--){
        suf[i]=me;
        umax(me,dp[go[i].f]+go[i].s);
    }
    ans[v]=me;
    for(int i=0;i<m;i++){
        ll gt=max(pref[i],suf[i])+go[i].s;
        dfs2(go[i].f,gt,v);
    }
}
signed main(){
    fast_rmi;
    int k;
    cin>>n>>k;
    if(n==1){
        cout<<0;
        return 0;
    }
    for(int i=1;i<n;i++){
        int v,u,c;
        cin>>v>>u>>c;--v;--u;
        g[v].pb({u,c});g[u].pb({v,c});
    }
    dfs3(0,0);
    auto getroot=[&](int root){
        pr[root]=-1;
        cst[root]=0;
        tt=0;
        dfs(root,0,root);
        build(1,0,n-1);
        del[root]=1;
        /// build ans for root
        for(int i=0;i<k;i++){
            pli w=geti(1,0,n-1);
            int j=obr[w.s];
//            cout<<"PATH"<<' '<<w.f<<' '<<j+1<<endl;
            ans[root]+=w.f;
            while(!del[j] && j!=root){
                add(in[j],out[j],-cst[j],1,0,n-1);
                cst[j]=0;
                del[j]=1;
                j=pr[j];
            }
        }
//        cout<<endl;
    };
    if(k==1){
        getroot(0);
        dfs2(0,0,-1);
    }
    else{
        for(int i=0;i<n;i++)
            getroot(i);
    }
    for(int i=0;i<n;i++){
        cout<<ans[i]<<'\n';
    }
    return 0;
}
/*
11 3
1 2 5
2 3 3
2 6 5
3 4 4
3 5 2
1 7 6
7 8 4
7 9 5
1 10 1
10 11 1
*/
