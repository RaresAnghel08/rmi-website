/**
* user:  mihalev-d38
* fname: Mihail
* lname: Mihalev
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:18:53.082055
*/
#include<iostream>
using namespace std;
const int MAX_N=3e5+5;
int a[MAX_N];
int n;
long long int Sum[4*MAX_N];
long long int otg;
int Max[4*MAX_N];
void InitSum(int l,int r,int node)
{
    if(l==r)
    {
        Sum[node]=a[l];
        return;
    }
    int mid=(l+r)/2;
    InitSum(l,mid,2*node);
    InitSum(mid+1,r,2*node+1);
    Sum[node]=Sum[2*node]+Sum[2*node+1];
}
void UpdateSum(int l,int r,int node,int idx,int val)
{
    if(l==r)
    {
        Sum[node]=val;
        return;
    }
    int mid=(l+r)/2;
    if(idx<=mid)UpdateSum(l,mid,2*node,idx,val);
    else UpdateSum(mid+1,r,2*node+1,idx,val);
    Sum[node]=Sum[2*node]+Sum[2*node+1];
}
long long int QuerySum(int l,int r,int node,int ql,int qr)
{
    if(ql<=l && r<=qr)
    {
        return Sum[node];
    }
    int mid=(l+r)/2;
    long long int ans=0;
    if(ql<=mid)ans+=QuerySum(l,mid,2*node,ql,qr);
    if(mid+1<=qr)ans+=QuerySum(mid+1,r,2*node+1,ql,qr);
    return ans;
}
void InitMax(int l,int r,int node)
{
    if(l==r)
    {
        Max[node]=l;
        return;
    }
    int mid=(l+r)/2;
    InitMax(l,mid,2*node);
    InitMax(mid+1,r,2*node+1);
    if(a[Max[2*node]]>=a[Max[2*node+1]])Max[node]=Max[2*node];
    else Max[node]=Max[2*node+1];
}
void UpdateMax(int l,int r,int node,int idx)
{
    if(l==r)
    {
        Max[node]=idx;
        return;
    }
    int mid=(l+r)/2;
    if(idx<=mid)UpdateMax(l,mid,2*node,idx);
    else UpdateMax(mid+1,r,2*node+1,idx);
    if(a[Max[2*node]]>=a[Max[2*node+1]])Max[node]=Max[2*node];
    else Max[node]=Max[2*node+1];
}
int QueryMax(int l,int r,int node,int ql,int qr)
{
    if(ql<=l && r<=qr)
    {
        return Max[node];
    }
    int mid=(l+r)/2;
    int pos=0;
    if(ql<=mid)pos=QueryMax(l,mid,2*node,ql,qr);
    if(mid+1<=qr)
    {
        int pos2=QueryMax(mid+1,r,2*node+1,ql,qr);
        if(a[pos2]>a[pos])pos=pos2;
    }
    return pos;
}
void initialise(int N, int Q, int h[])
{
    n=N;
    for(int i=1;i<=n;i++)
    {
        otg+=(h[i]*1LL);
        a[i]=h[i];
    }
    InitMax(1,n,1);
    InitSum(1,n,1);
}
void cut(int l, int r, int k)
{
    //otg-=min(k*1LL,otg);
    //return;
    for(int i=1;i<=k;i++)
    {
        int posMax=QueryMax(1,n,1,l,r);
        //cout<<posMax<<endl;
        if(a[posMax]==0 or posMax==0)break;
        a[posMax]--;
        UpdateMax(1,n,1,posMax);
        UpdateSum(1,n,1,posMax,a[posMax]);
    }
}
void magic(int i, int x)
{
    //otg-=a[i]*1LL;
    //otg+=x*1LL;
    //a[i]=x;
    //return;
    a[i]=x;
    UpdateMax(1,n,1,i);
    UpdateSum(1,n,1,i,x);
}
long long int inspect(int l, int r)
{
    //return otg;
    long long int ans=QuerySum(1,n,1,l,r);
    return ans;
}
