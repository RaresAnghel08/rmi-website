/**
* user:  negoescu-c8b
* fname: Divia Petra
* lname: Negoescu
* task:  NoM
* score: 9.0
* date:  2021-12-17 11:04:40.032190
*/
#include <iostream>
#define R 1000000007
using namespace std;
//ifstream cin("a.in");
//ofstream cout("a.out");
int n,m, a[100],b[100];
long long sol;
void bckt(int pas){ //permutari de n
    if(n+1==pas){
        //verif();
        /*for(int i=1;i<=n;i++)
            cout<<a[i]<<" ";
        cout<<"\n";*/
        sol++;
        if(sol>=R)
            sol-=R;
        return;
    }

    for(int j=1;j<=n;j++){
        if(b[j]==0){
            b[j]=pas;
            a[pas]=j;
            int x=0;
            if(j>n/2){
                x=j-n/2;
            }
            else x=j+n/2;
           // cout<<"j="<<j<<" x="<<x<<"\n";
            if(b[j] && b[x] && (max(b[j]-b[x],b[x]-b[j])%m==0)){
                b[j]=0;
                continue;
            }
            bckt(pas+1);
            b[j]=0;

        }
    }


}
int main(){
    cin>>n>>m;
    n*=2;
    bckt(1);
    cout<<sol;
    return 0;
}
