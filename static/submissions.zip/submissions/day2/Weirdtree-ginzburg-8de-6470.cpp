/**
* user:  ginzburg-8de
* fname: Yael
* lname: Ginzburg
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 10:54:39.967959
*/
#include "weirdtree.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <limits>
using namespace std;

typedef long long ll;
struct Seg
{
	vector<int> tall;
	int n;
	int sum = 0;

	Seg(int* height, int n): n(n)
	{
		tall.resize(n);
		for (int i = 0; i < n; i++)
		{
			tall[i] = height[i + 1];
			sum += tall[i];
		}
	}



	ll query(int a, int b)
	{
		if (a == 0 && b == n) return sum;
		ll _sum = 0;
		for (int i = a; i < b; i++) _sum += tall[i];
		return _sum;
	}

	pair<ll, int> queryChange(int a, int b, ll h)
	{
		ll sum = 0;
		int num = 0;
		for (int i = a; i < b; i++)
		{
			if (tall[i] > h)
			{
				sum += tall[i] - h;
				num++;
			}
		}
		return { sum, num };
	}

	void change(int a, int b, int left, int h, int k)
	{
		int count = left;
		for (int i = b - 1; i >= a; i--)
		{
			if (tall[i] > h)
			{
				if (count > 0)
				{
					tall[i] = h + 1;
					count--;
				}
				else tall[i] = h;
			}
		}
		sum -= k;
		return;
	}
};

Seg* root;

void initialise(int N, int Q, int h[]) {
	// Your code here.
	root = new Seg(h, N);
}
void cut(int l, int r, int k) {
	// Your code here.
	l--;
	int bl = 0, br = 1e9, mid;
	bool changed = false;
	while (!changed && bl != br)
	{
		mid = (bl + br) / 2;
		pair<ll, int> c = root->queryChange(l, r, mid);
		if (c.first - k >= 0 && c.first - k < c.second)
		{
			changed = true;
			root->change(l, r, c.first - k, mid, k);
		}
		else if (c.first - k < 0) br = mid;
		else bl = mid;
	}
	if (bl == br && !changed)
	{
		pair<ll, int> c = root->queryChange(l, r, mid);
		root->change(l, r, c.first - k, mid, k);
	}
}
void magic(int i, int x) {
	// Your code here.
	
}
long long int inspect(int l, int r) {
	// Your code here.
	return root->query(l - 1, r);
}
