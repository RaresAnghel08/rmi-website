/**
* user:  levashkevich-aa5
* fname: Stanislau
* lname: Levashkevich
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 07:34:34.412166
*/
#include "weirdtree.h"
#include <bits/stdc++.h>

using namespace std;
#define fast ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define endl '\n'
#define ff first
#define ss second

struct node{
    int sum = 0,mx = -2e9,pos = 2e9;
};

const int MX = 3e5 + 7;

node t[4 * MX];
int cur[MX];

node mrg(node a,node b) {
    node ans;
    ans.sum = a.sum + b.sum;
    if(a.mx > b.mx) {
        ans.mx = a.mx;
        ans.pos = a.pos;
    } else if(b.mx > a.mx) {
        ans.mx = b.mx;
        ans.pos = b.pos;
    } else {
        ans.mx = a.mx;
        ans.pos = min(a.pos,b.pos);
    }
    return ans;
}

void build(int v,int tl,int tr) {
    if(tl == tr) {
        t[v].sum = cur[tl];
        t[v].mx = cur[tl];
        t[v].pos = tl;
        return;
    }
    int md = (tl + tr) / 2;
    build(v * 2,tl,md);
    build(v * 2 + 1,md + 1,tr);
    t[v] = mrg(t[v * 2],t[v * 2 + 1]);
}

pair<int,int> get_max(int v,int tl,int tr,int l,int r) {
    if(l > r) {
        return {-2e9,2e9};
    }
    if(tl == l && tr == r) {
        return {t[v].mx,t[v].pos};
    }
    int md = (tl + tr) / 2;
    auto ans1 = get_max(v * 2,tl,md,l,min(md,r));
    auto ans2 = get_max(v * 2 + 1,md + 1,tr,max(md + 1,l),r);
    if(ans1.ff > ans2.ff || (ans1.ff == ans2.ff && ans1.ss < ans2.ss)) return ans1;
    return ans2;
}

void upd(int v,int tl,int tr,int pos,int val) {
    if(tl == tr) {
        t[v].sum = val;
        t[v].mx = val;
        t[v].pos = pos;
        return;
    }
    int md = (tl + tr) / 2;
    if(pos <= md) upd(v * 2,tl,md,pos,val);
    else upd(v * 2 + 1,md + 1,tr,pos,val);
    t[v] = mrg(t[v * 2],t[v * 2 + 1]);
}

int get_sum(int v,int tl,int tr,int l,int r) {
    if(l > r) return 0;
    if(tl == l && tr == r) return t[v].sum;
    int md = (tl + tr) / 2;
    return get_sum(v * 2,tl,md,l,min(md,r)) + get_sum(v * 2 + 1,md + 1,tr,max(md + 1,l),r);
}

int SZ = 0;

void initialise(int N, int Q, int h[]) { // Your code here.
    fast;
    for(int i = 1;i <= N; ++i) {
        cur[i] = h[i];
    }
    SZ = N;
    build(1,0,SZ);
}
void cut(int l, int r, int k) { // Your code here.
    while(k--) {
        auto best = get_max(1,0,SZ,l,r);
        if(best.ff == 0) break;
        cur[best.ss]--;
        upd(1,0,SZ,best.ss,cur[best.ss]);
    }
}
void magic(int i, int x) { // Your code here.
    upd(1,0,SZ,i,x);
    cur[i] = x;
}
long long int inspect(int l, int r) { // Your code here.
    return get_sum(1,0,SZ,l,r);
}
/*
6 10
1 2 3 1 2 3
1 1 6 3
3 1 6
1 1 3 3
3 1 6
1 1 3 1000
3 1 6
2 1 1000
3 1 6
1 1 3 999
3 1 5
*/
