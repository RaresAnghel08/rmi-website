/**
* user:  sharshenaliev-d01
* fname: Nazar
* lname: Sharshenaliev
* task:  NoM
* score: 0.0
* date:  2021-12-17 08:47:49.655342
*/
#include <bits/stdc++.h>
#define pb push_back
#define ss second
#define ff first 
#define int long long 
using namespace std;
	int n , m;
int num(int j){
	int ans = 0;
	for (int i = 1; i <= j / 2; i ++){
		if(m % i == 0)ans++;
	}
	return ans;
}
int fac(int n){
	int ans = 1;
	for (int i = 2; i <= n; i++){
		int j = num(i);
		ans*=(i-j);
		ans %= 1000000007;
	}
	return ans;
}
main (){                                              //171243255
	cin >> n >> m;
	n*=2;
	cout << fac(n) - 1 << endl;
	return 0;
}