/**
* user:  voicu-de1
* fname: Mihai Valeriu
* lname: Voicu
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:44:24.253475
*/
#include <iostream>
#include <algorithm>

using namespace std;

int n;
//void testcase(int m) {
  //int cnt=0;
  //int v[n*2+5];
  //for(int i=0; i<n*2; i++) {
    //v[i]=i/2;
  //}
  //int poz[n+5];
  //do {
    //for(int i=0; i<n; i++) {
      //poz[i]=-1;
    //}
    //bool ok=1;
    //for(int i=0; i<2*n; i++) {
      //if(poz[v[i]]==-1)
        //poz[i]=i;
      //else if((i-poz[v[i]])%m==0)
        //ok=0;
    //}
    //cnt+=ok;
  //} while(next_permutation(v,v+2*n));
  //cout << cnt << '\n';
//}
#define int long long
void testcase(int m) {
  int cnt=0;
  int v[n*2+5];
  for(int i=0; i<n*2; i++) {
    v[i]=i;
  }
  int poz[n+5];
  do {
    for(int i=0; i<n; i++) {
      poz[i]=-1;
    }
    bool ok=1;
    for(int i=0; i<2*n; i++) {
      if(poz[v[i]/2]==-1)
        poz[v[i]/2]=i;
      else if((i-poz[v[i]/2])%m==0)
        ok=0;
    }
    cnt+=ok;
  } while(next_permutation(v,v+2*n));
  //cout << cnt << '\n';
  cout << ((long long)cnt*(1LL<<n))%1000000007 << '\n';
}

signed main() {
  int m;
  cin >> n >> m;
    testcase(m);
}
