/**
* user:  kharisov-ffd
* fname: Bulat Rafailevich
* lname: Kharisov
* task:  Paths
* score: 0.0
* date:  2021-12-17 10:23:53.180159
*/
#include <bits/stdc++.h>
using namespace std;

#define int long long
#define size(a) (int)a.size()
#define pii pair<int, int>
#define fi first
#define se second
#define pb emplace_back
#define chkmax(a, b) a = max(a, b)

const int N = (1 << 17), mod = 1e9+7;

int n, k;
vector<pii> gr[N];
bool ban[N];
int d[N], tin[N], tout[N], par[N], pc[N], invtin[N], T = 0;
int depth_suka[N];

int mx[2*N], mxid[2*N], lazy[2*N];

void predfs(int v, int depth, int pr = -1) {
    depth_suka[v] = depth;
    invtin[T] = v;
    tin[v] = T++;
    mx[tin[v]+N] = depth;
    mxid[tin[v]+N] = tin[v];
    for (auto to : gr[v]) {
        if (to.fi != pr) {
            par[to.fi] = v, pc[to.fi] = to.se;
            predfs(to.fi, depth+to.se, v);
        }
    }
    tout[v] = T;
}

void downdate(int v) {
    mx[v] = max(mx[v*2], mx[v*2+1]);
    mxid[v] = mx[v*2]==mx[v] ? mxid[v*2] : mxid[v*2+1];
}

void push(int v) {
    mx[2*v] += lazy[v];
    mx[2*v+1] += lazy[v];
    lazy[2*v] += lazy[v];
    lazy[2*v+1] += lazy[v];
    lazy[v] = 0;
}

void segset(int l, int r, int x, int v = 1, int tl = 0, int tr = N) {
    if (tl >= r || tr <= l) return;
    if (tl >= l && tr <= r) {
        lazy[v] += x, mx[v] += x;
        return;
    }
    push(v);
    int mid = (tl + tr) / 2;
    segset(l, r, x, v*2, tl, mid);
    segset(l, r, x, v*2+1, mid, tr);
    downdate(v);
    /*for (l += N, r += N; l < r; l >>= 1, r >>= 1) {
        if (l && r < N) {
            mx[l] = max(mx[l*2], mx[l*2+1])+lazy[l];
            mx[r] = max(mx[r*2], mx[r*2+1])+lazy[r];
        }

        if (l & 1) {
            lazy[l] += x, mx[l] += x;
            ++l;
        }
        if (r & 1) {
            --r;
            lazy[r] += x, mx[r] += x;
        }
    }*/
}

pii get_max(int l = 0, int r = N, int v = 1, int tl = 0, int tr = N) {
    if (tl >= r || tr <= l) return {-1, -1};
    if (tl >= l && tr <= r) return {mx[v], mxid[v]};
    push(v);
    int mid = (tl + tr) / 2;
    auto r1 = get_max(l, r, v*2, tl, mid);
    auto r2 = get_max(l, r, v*2+1, mid, tr);
    return max(r1, r2);
}


auto comp = [](int v1, int v2) {
    if (d[v1] == d[v2]) return v1 < v2;
    return d[v1] > d[v2];
};
set<int, decltype(comp)> so(comp);

auto get_ans = []() {
    int it = 0, res = 0;
    for (auto i : so) {
        ++it;
        res += d[i];
        if (it == k) break;
    }
    return res;
};

int res[N];

void main_dfs(int v, int pr = -1) {
    res[v] = get_ans();
    segset(tin[v], tout[v], -2 * pc[v]);

    for (auto to : gr[v]) {
        if (to.fi == pr) continue;
        auto t1 = get_max(tin[to.fi], tout[to.fi]);
        auto t2 = get_max(0, tin[to.fi]);
        auto t3 = get_max(tout[to.fi], N);
        int down = invtin[t1.se];
        int up = t2 > t3 ? invtin[t2.se] : invtin[t3.se];

        so.erase(down);
        so.erase(up);
        d[down] -= to.se;
        d[up] += to.se;
        so.emplace(down);
        so.emplace(up);

        main_dfs(to.fi, v);

        so.erase(down);
        so.erase(up);
        d[down] += to.se;
        d[up] -= to.se;
        so.emplace(down);
        so.emplace(up);
    }

    segset(tin[v], tout[v], 2 * pc[v]);
}


void run() {
    scanf("%lld%lld", &n, &k);
    for (int i = 0; i < n - 1; ++i) {
        int v1, v2, c; scanf("%lld%lld%lld", &v1, &v2, &c); --v1, --v2;
        gr[v1].pb(v2, c); gr[v2].pb(v1, c);
    }

    predfs(0, 0);
    for (int i = N - 1; i; --i)
        downdate(i);

    ban[0] = true;
    for (int it = 0; it < n; ++it) {
        auto r = get_max();
        int v = invtin[r.se];
        if (ban[v]) continue;
        d[v] = r.fi;
        while (!ban[v]) {
            ban[v] = true;
            segset(tin[v], tout[v], -pc[v]);
            v = par[v];
        }
    }
        
    fill(lazy, lazy+2*N, 0);
    for (int v = 0; v < n; ++v)
        mx[tin[v]+N] = depth_suka[v];
    for (int i = N - 1; i; --i)
        downdate(i);

    for (int i = 0; i < n; ++i)
        so.insert(i);
    main_dfs(0);

    for (int i = 0; i < n; ++i) {
        cout << res[i] << '\n';
    }
}
    
mt19937 Rand(time(0));
int rnd(int a) { return Rand() % a; }

signed main() {
    cin.tie(0), cout.tie(0), ios_base::sync_with_stdio(0);

    /*int n = 1e5;
    cout << n << " " << 1 << endl;

    for (int i = 1; i < n; ++i) {
        int p = rnd(i), c = rnd(1e9);
        cout << i+1 << " " << p+1 << " " << c << endl;
    }*/

    auto time = clock();

    int t = 1;
    //cin >> t;
    while (t--) {
        run();
    }

    //cout << ((double) clock() - time) / CLOCKS_PER_SEC << endl;
}