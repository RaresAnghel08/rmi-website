/**
* user:  mingazov-4fb
* fname: Artem
* lname: Mingazov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 08:06:45.505879
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
int Size = 1, zero = 0;
vector <long long> tree_max, tree_sum;
long long merge_max(int A, int B) {
    return max(tree_max[A], tree_max[B]);
}
long long merge_sum(int A, int B) {
    return tree_sum[A] + tree_sum[B];
}
void initialise(int N, int Q, const int h[]) {
    while (Size < N) {
        Size *= 2;
    }
    tree_max.assign(Size * 2 - 1, zero);
    tree_sum.assign(Size * 2 - 1, zero);
    for (int i = 1; i <= N; i++) {
        tree_max[i + Size - 1 - 1] = h[i];
        tree_sum[i + Size - 1 - 1] = h[i];
    }
    for (int i = Size - 2; i >= 0; i--) {
        tree_max[i] = merge_max(i * 2 + 1, i * 2 + 2);
        tree_sum[i] = merge_sum(i * 2 + 1, i * 2 + 2);
    }
}
long long find_max(int l, int r, int k, int x, int lx, int rx) {
    if (r < lx || rx < l) {
        return zero;
    }
    if (l <= lx && rx <= r) {
        return tree_max[x];
    }
    int mx = (lx + rx) / 2;
    return max(find_max(l, r, k, x * 2 + 1, lx, mx), find_max(l, r, k, x * 2 + 1, mx + 1, rx));
}
pair <long long, long long> find_elem(int MAX, int l, int r, int k, int x, int lx, int rx) {
    if (r < lx || rx < l) {
        return make_pair(-1, -1);
    }
    if (lx == rx) {
        if (tree_max[x] == MAX) {
            long long temp = min(tree_max[x], (long long)k);
            tree_max[x] -= temp;
            k -= temp;
            return make_pair(lx, k);
        }
        return make_pair(-1, -1);
    }
    int mx = (lx + rx) / 2;
    pair <int, int> res = find_elem(MAX, l, r, k, x * 2 + 1, lx, mx);
    if (res == make_pair(-1, -1)) {
        res = find_elem(MAX, l, r, k, x * 2 + 2, mx + 1, rx);
    }
    tree_max[x] = merge_max(x * 2 + 1, x * 2 + 2);
    return res;
}
void cut(int l, int r, int k) {
    while (k) {
        pair <long long, long long> ans = find_elem(find_max(l - 1, r - 1, k, 0, 0, Size - 1), l - 1, r - 1, k, 0, 0, Size - 1);
        k -= ans.second;
    }
}
void Sset(int i, int v, int x, int lx, int rx) {
    if (lx == rx) {
        tree_max[x] = v;
        tree_sum[x] = v;
        return;
    }
    int mx = (lx + rx) / 2;
    if (i <= mx) {
        Sset(i, v, x * 2 + 1, lx, mx);
    }
    else {
        Sset(i, v, x * 2 + 2, mx + 1, rx);
    }
    tree_max[x] = merge_max(x * 2 + 1, x * 2 + 2);
    tree_sum[x] = merge_sum(x * 2 + 1, x * 2 + 2);
}
void magic(int i, int x) {
    Sset(i - 1, x, 0, 0, Size - 1);
}
int sum(int l, int r, int x, int lx, int rx) {
    if (l <= lx && rx <= r) {
        return tree_sum[x];
    }
    if (r < lx || rx < l) {
        return zero;
    }
    int mx = (lx + rx) / 2;
    return sum(l, r, x * 2 + 1, lx, mx) + sum(l, r, x * 2 + 2, mx + 1, rx);
}
long long int inspect(int l, int r) {
    return sum(l - 1, r - 1, 0, 0, Size - 1);
}