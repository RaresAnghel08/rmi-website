/**
* user:  koren-480
* fname: Elazar
* lname: Koren
* task:  Paths
* score: 36.0
* date:  2021-12-17 08:56:12.459822
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#define x first
#define y second
#define all(v) v.begin(), v.end()
#define chkmin(a, b) a = min(a, b)
#define chkmax(a, b) a = max(a, b)
using namespace std;
typedef long long ll;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef pair<ll, ll> pii;
typedef vector<pii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

const int MAX_N = 2001;

ll ans[MAX_N];
vi dp[MAX_N];

int n, k;

void Dfs1(vector<vii> &tree, int node, int parent) {
    vi next(k + 1), prev(k + 1);
    for (pii p : tree[node]) {
        if (p.x == parent) continue;
        Dfs1(tree, p.x, node);
        if (!dp[p.x][1]) dp[p.x][1] = p.y;
        else {
            for (int i = 1; i <= k; i++) {
                if (!dp[p.x][i]) break;
                dp[p.x][i] += p.y;
            }
        }
        for (int i = 0; i <= k; i++) {
            if (i && prev[i] <= prev[i - 1]) break;
            chkmax(next[i], prev[i]);
            for (int j = 1; j <= k - i; j++) {
                if (!dp[p.x][j]) break;
                chkmax(next[j + i], dp[p.x][j] + prev[i]);
            }
        }
        swap(next, prev);
    }
    dp[node] = prev;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    vector<vii> tree(n + 1);
    for (int i = 0; i < n - 1; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        tree[a].push_back({b, c});
        tree[b].push_back({a, c});
    }
    for (int i = 1; i <= n; i++) {
        Dfs1(tree, i, 0);
        ans[i] = *max_element(dp[i].begin(), dp[i].end());
    }
    for (int i = 1; i <= n; i++) cout << ans[i] << '\n';
}
