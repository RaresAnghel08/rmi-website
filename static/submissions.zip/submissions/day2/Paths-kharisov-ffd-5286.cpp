/**
* user:  kharisov-ffd
* fname: Bulat Rafailevich
* lname: Kharisov
* task:  Paths
* score: 56.0
* date:  2021-12-17 09:16:53.124114
*/
#include <bits/stdc++.h>
using namespace std;

#define int long long
#define size(a) (int)a.size()
#define pii pair<int, int>
#define fi first
#define se second
#define pb emplace_back
#define chkmax(a, b) a = max(a, b)

const int N = (1 << 18), mod = 1e9+7;

int n, k;
vector<pii> gr[N];
bool ban[N];
int d[N], tin[N], tout[N], par[N], pc[N], invtin[N], T = 0;

int mx[2*N], lazy[2*N];

void predfs(int v, int depth, int pr = -1) {
    invtin[T] = v;
    tin[v] = T++;
    mx[tin[v]+N] = depth;
    for (auto to : gr[v]) {
        if (to.fi != pr) {
            par[to.fi] = v, pc[to.fi] = to.se;
            predfs(to.fi, depth+to.se, v);
        }
    }
    tout[v] = T;
}

void push(int v) {
    mx[2*v] += lazy[v];
    mx[2*v+1] += lazy[v];
    lazy[2*v] += lazy[v];
    lazy[2*v+1] += lazy[v];
    lazy[v] = 0;
}

void segset(int l, int r, int x, int v = 1, int tl = 0, int tr = N) {
    if (tl >= r || tr <= l) return;
    if (tl >= l && tr <= r) {
        lazy[v] += x, mx[v] += x;
        return;
    }
    push(v);
    int mid = (tl + tr) / 2;
    segset(l, r, x, v*2, tl, mid);
    segset(l, r, x, v*2+1, mid, tr);
    mx[v] = max(mx[v*2], mx[v*2+1]);
}

int get_max(int v = 1, int tl = 0, int tr = N) {
    while (tr - tl > 1) {
        push(v);
        int mid = (tl + tr) / 2;
        if (mx[v*2] == mx[v]) tr = mid, v = v*2;
        else tl = mid, v = v*2+1;
    }
    return tl;
}

pii find_dia(int v, int pr) {
    pii res = {0, v};
    for (auto to : gr[v]) {
        if (to.fi == pr) continue;
        pii t = find_dia(to.fi, v); t.fi += to.se;
        chkmax(res, t);
    }
    return res;
}


auto comp = [](int v1, int v2) {
    if (d[v1] == d[v2]) return v1 < v2;
    return d[v1] > d[v2];
};
set<int, decltype(comp)> so(comp);

auto get_ans = []() {
    int it = 0, res = 0;
    for (auto i : so) {
        ++it;
        res += d[i];
        if (it == k) break;
    }
    return res;
};

int res[N];

void main_dfs(int v, int pr = -1) {
    res[v] = get_ans();

    for (auto to : gr[v]) {
        if (to.fi == pr) continue;
        int down = find_dia(to.fi, v).se;
        int up = find_dia(v, to.fi).se;
        
        so.erase(down);
        so.erase(up);
        d[down] -= to.se;
        d[up] += to.se;
        so.emplace(down);
        so.emplace(up);

        main_dfs(to.fi, v);

        so.erase(down);
        so.erase(up);
        d[down] += to.se;
        d[up] -= to.se;
        so.emplace(down);
        so.emplace(up);
    }
}


void run() {
    cin >> n >> k;
    for (int i = 0; i < n - 1; ++i) {
        int v1, v2, c; cin >> v1 >> v2 >> c; --v1, --v2;
        gr[v1].pb(v2, c); gr[v2].pb(v1, c);
    }

    predfs(0, 0);
    for (int i = N - 1; i; --i)
        mx[i] = max(mx[i*2], mx[i*2+1]);

    ban[0] = true;
    for (int it = 0; it < n; ++it) {
        int v = invtin[get_max()];
        if (ban[v]) continue;
        d[v] = mx[tin[v]+N];
        while (!ban[v]) {
            ban[v] = true;
            segset(tin[v], tout[v], -pc[v]);
            v = par[v];
        }
    }

    for (int i = 0; i < n; ++i)
        so.insert(i);
    main_dfs(0);

    for (int i = 0; i < n; ++i) {
        cout << res[i] << endl;
    }
}

signed main() {
    cin.tie(0), cout.tie(0), ios_base::sync_with_stdio(0);

    int t = 1;
    //cin >> t;
    while (t--) {
        run();
    }
}