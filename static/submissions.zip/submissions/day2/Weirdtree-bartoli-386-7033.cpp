/**
* user:  bartoli-386
* fname: Davide
* lname: Bartoli
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:33:08.771305
*/
#pragma GCC optimize("O3")
#include <bits/stdc++.h>
#include "weirdtree.h"
using namespace std;
#define ll long long
#define fi first
#define se second
#define pb push_back
struct node{
    int ma,pos;
    int sum;
};
struct segment{
    const int dim=1<<17;
    vector<node> s=vector<node> (2*dim);
    void upd(int pos,int l,int r,int p,int val){
        if(p<l || r<p)return;
        if(l==r){
            s[pos].ma=val;
            s[pos].sum=val;
            s[pos].pos=l;
            return;
        }
        int m=(l+r)/2;
        upd(2*pos,l,m,p,val);
        upd(2*pos+1,m+1,r,p,val);

        if(s[2*pos].ma>=s[2*pos+1].ma)s[pos]=s[2*pos];
        else s[pos]=s[2*pos+1];
        s[pos].sum=s[2*pos].sum+s[2*pos+1].sum;
    }
    void upd(int p,int val){
        upd(1,0,dim-1,p,val);
    }
    node query_ma(int pos,int l,int r,int a,int b){
        if(b<l || r<a)return {-1,-1,-1};

        if(a<=l && r<=b){
            return s[pos];
        }

        int m=(l+r)/2;
        node x=query_ma(2*pos,l,m,a,b);
        node y=query_ma(2*pos+1,m+1,r,a,b);

        if(x.ma>=y.ma)return x;
        return y;
    }
    node query_ma(int a,int b){
        return query_ma(1,0,dim-1,a,b);
    }

    int query_sum(int pos,int l,int r,int a,int b){
        if(b<l || r<a)return 0;
        if(a<=l && r<=b){
            return s[pos].sum;
        }

        int m=(l+r)/2;
        int x=query_sum(2*pos,l,m,a,b);
        int y=query_sum(2*pos+1,m+1,r,a,b);
        return x+y;
    }
    int query_sum(int a,int b){
        return query_sum(1,0,dim-1,a,b);
    }

}seg;
vector<ll> vv;
int N;
void initialise(int n, int Q, int h[]) {
    N=n;
    for(int i=1;i<=N;i++){
        vv.pb(h[i]);
        seg.upd(i-1,h[i]);
        }
    //cout<<"hola: "<<vv.size()<<endl;
}
void cut(int l, int r, int k) {
    l--;r--;

    node x=seg.query_ma(l,r);
    if(x.ma<=0)return;
    seg.upd(x.pos,x.ma-1);
    /*vector<ll> y;
    for(int i=l;i<=r;i++){
        y.pb(vv[i]);
    }
    sort(y.begin(),y.end());

    ll a=0,b=1e9;
    while(a<b){
        ll m=(a+b)/2;

        ll rim=0;
        for(ll i:y)rim+=max((ll)0,i-m);
        if(rim<=k)b=m;
        else a=m+1;
    }

    for(ll i=l;i<=r;i++){
        if(vv[i]>a){
            k-=vv[i]-a;
            vv[i]=a;
        }
    }
    for(ll i=l;i<=r;i++){
        if(k==0)break;
        if(vv[i]==a && a>0){
            k--;
            vv[i]--;
        }
    }*/
    /*cout<<"arrray: "<<a<<endl;
    for(int x:vv)cout<<x<<" ";
    cout<<endl<<endl;;*/

}
void magic(int i, int x) {
    i--;
    seg.upd(i,x);
    //vv[i]=x;
	// Your code here.
}
long long inspect(int l, int r) {
	// Your code here.
	l--;r--;
	ll tot=seg.query_sum(l,r);
	//for(ll i=l;i<=r;i++)tot+=vv[i];
	return tot;
}
