/**
* user:  idiriz-fcd
* fname: Nermin Hyusmen
* lname: Idiriz
* task:  NoM
* score: 0.0
* date:  2021-12-17 07:30:57.603472
*/
/// NoM
#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
const int MOD=1e9+7,MAXN=12;
int n,m;
int a[MAXN],cnt=0;
void check()
{
    for(int i=1;i<=n;i++)
    {
        vector<int>v;
        for(int j=1;j<=2*n;j++)
            if(a[j]==i)v.push_back(j);
        if(abs(v[0]-v[1])%m==0)return;
    }
   /*for(int i=1;i<=2*n;i++)
        cout<<a[i]<<" ";
    cout<<endl;*/
    cnt+=2*n;
    cnt%=MOD;
}
int used[5];
void gen(int pos)
{
    if(pos>2*n)
    {
        check();
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(used[i]<2)
        {
            a[pos]=i;
            used[i]++;
            gen(pos+1);
            used[i]--;
        }
    }
}
int main()
{
    cin>>n>>m;
    gen(1);
    cout<<cnt<<endl;
    return 0;
}
