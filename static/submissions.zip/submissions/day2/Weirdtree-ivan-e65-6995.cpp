/**
* user:  ivan-e65
* fname: Tudor
* lname: Ivan
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:30:16.529924
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
using namespace std;
struct SegTree{
  int maxi, pmaxi;
  long long sum;
};
SegTree join(SegTree a, SegTree b){
  SegTree rsp = {0, 0, 0};
  rsp.sum = a.sum + b.sum;
  rsp.maxi = a.maxi, rsp.pmaxi = a.pmaxi;
  if(b.maxi > rsp.maxi){
    rsp.maxi = b.maxi;
    rsp.pmaxi = b.pmaxi;
  }
  return rsp;
}
const int N = 300005;
SegTree aint[4*N];

int n;
int h[N];
void build(int nod, int l, int r){
  if(l == r){
    aint[nod] = {h[l], l, h[l]};
    return;
  }
  int mid = (l +r)/2;
  build(2*nod, l, mid);
  build(2*nod + 1, mid + 1, r);
  aint[nod] = join(aint[2*nod], aint[2*nod + 1]);
}
void update(int nod, int l ,int r, int poz, int h){
  if(poz < l || poz > r)
    return;
  if(l == r){
    aint[nod].maxi = aint[nod].sum = h;
    return;
  }
  int mid = (l + r)/2;
  update(2*nod, l, mid, poz, h);
  update(2*nod + 1, mid + 1, r, poz, h);
  aint[nod] = join(aint[2*nod], aint[2*nod + 1]);
}
SegTree query(int nod, int l, int r, int ql, int qr){
  if(r < ql || l > qr){
    return {0, 0, 0};
  }
  if(ql <= l && r <= qr){
    return aint[nod];
  }
  int mid = (l +r)/2;
  SegTree lft = query(2*nod, l, mid, ql, qr);
  SegTree rgt = query(2*nod + 1, mid + 1, r, ql, qr);
  return join(lft, rgt);
}
void initialise(int N, int Q, int H[]) {
  for(int i = 1; i<=N; i++){
    h[i] = H[i];
  }
  n = N;
  build(1, 1, n);
}
void cut(int l, int r, int k) {
  while(k){
    SegTree rsp = query(1, 1, n, l, r);
    update(1, 1, n, rsp.pmaxi, max(rsp.maxi - 1, 0));
    k--;
  }
}
void magic(int i, int x) {
	// Your code here.
	update(1, 1, n, i, x);
}
long long int inspect(int l, int r) {
	// Your code here.
	SegTree rsp = query(1, 1, n, l, r);
	return rsp.sum;
}
