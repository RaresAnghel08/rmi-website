/**
* user:  elbaum-6df
* fname: Eitan
* lname: Elbaum
* task:  Paths
* score: 8.0
* date:  2021-12-17 11:20:18.797126
*/
#include<set>
#include <iostream>
#include<vector>
#define x first
#define y second
using namespace std;
typedef long long ll;
vector<vector<pair<ll,ll>>> g(100000);
vector<vector<pair<ll,ll>>> g1(100000);
vector<ll> ar(100000,-1);
ll t[2000][2000];
ll n,k,a,b,c;
int dd[100000],ss[100000];
void leaf(int ind,bool f,vector<bool>&vis, ll s, set<pair<ll,ll>> &st){
    vis[ind]=1;
    if(g1[ind].size()==1 && !f){
        st.insert({s,ind});
        ar[ind]=s;
        return;
    }
    for(int j=0;j<g1[ind].size();j++){
        if(!vis[g1[ind][j].x]) leaf(g1[ind][j].x,0,vis,s+g1[ind][j].y,st);
    }
}
void df(int i, int d){
    dd[i]=d;
    for(int j=0;j<g1[i].size();j++){
        if(g1[i][j].x != d) df(g1[i][j].x,i);
    }
}
void f(int i, ll r, set<pair<ll,ll>> &st){
    if(ar[i] != -1){
        st.erase(st.find({ar[i],i}));
        ar[i] -= r;
        st.insert({ar[i],i});
        return;
    }
    for(int j=0;j<g1[i].size();j++){
        if(g1[i][j].x != dd[i]) f(g1[i][j].x,r,st);
    }
}
ll d(int ind){
    ll s=0;
    df(ind,-1);
    set<pair<ll,ll>> st;
    vector<bool> vis(n,0),vis1(n,0),vis2(n,0);
    leaf(ind,1,vis,0,st);
    for(int i=0;i<k && st.size();i++){
        auto it = st.end(); it--;
        s += it->x;
        ll cur = it->y,r=0;
        ss[cur]=-1;
        while(!vis1[cur] && dd[cur] != -1){
            ss[dd[cur]] = cur;
            cur=dd[cur];
        }
        cur=ss[cur];
        r = t[cur][dd[cur]];
        while(cur != -1){
            vis1[cur]=1;
            if(ar[cur] != -1) f(cur,r,st);
            for(int j=0;j<g1[cur].size();j++){
                if(g1[cur][j].x != ss[cur] && g1[cur][j].x != dd[cur]){
                    f(g1[cur][j].x,r,st);
                }
            }
            if(ss[cur] != -1) r += t[cur][ss[cur]];
            cur=ss[cur];
        }
        st.erase(it);
        //s += leaf(ind,1,vis,g1);
    }
    return s;
}
int main(){
    cin>>n>>k;
    for(ll i=1;i<n;i++){
        cin>>a>>b>>c;a--;b--;
        g[a].push_back({b,c});
        g[b].push_back({a,c});
        if(a<2000 && b<2000) t[a][b]=t[b][a]=c;
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<g[i].size();j++){
            g1[i].push_back(g[i][j]);
        }
    }
    for(int i=0;i<n;i++){
        cout<<d(i)<<endl;
    }
}