/**
* user:  gatev-8cc
* fname: Aleksandar Miroslavov
* lname: Gatev
* task:  Paths
* score: 8.0
* date:  2021-12-17 11:39:27.501073
*/
#include<bits/stdc++.h>
using namespace std;

int n,k,a,b,curr,maxv,cnt,cft;
long long c,ans,cans[2007];
int parent[100007];
long long upe[100007];
int li[100007],tim;

vector< pair<int,long long> > v[100007];
vector<bool> w[100007];
long long dist[2007];

long long down[100007],up[100007],sdown[100007];
pair<long long,int> pp[2007];

void dyndown(int x,int p){
    parent[x]=p;
    down[x]=sdown[x]=0;

    for(int i=0;i<v[x].size();i++){
        if(v[x][i].first!=p){
            upe[v[x][i].first]=v[x][i].second;
            dyndown(v[x][i].first,x);
            if(down[v[x][i].first]+v[x][i].second>down[x]){
                sdown[x]=down[x];
                down[x]=down[v[x][i].first]+v[x][i].second;
            }else if(down[v[x][i].first]+v[x][i].second>sdown[x]){
                sdown[x]=down[v[x][i].first]+v[x][i].second;
            }
        }
    }

    pp[x]={down[x]+upe[x],x};
}

void dynup(int x,int p,long long dd){
    if(p==0){
        up[x]=0;
    }else{
        if(down[x]+dd==down[p]){
            up[x]=max(up[p]+dd,sdown[p]+dd);
        }else{
            up[x]=max(up[p]+dd,down[p]+dd);
        }
    }

    for(int i=0;i<v[x].size();i++){
        if(v[x][i].first!=p){
            dynup(v[x][i].first,x,v[x][i].second);
        }
    }
}

void rec(int x,int p){
    li[x]=tim;
    for(int i=v[x].size()-1;i>=0;i--){
        if(v[x][i].first!=p and down[v[x][i].first]+v[x][i].second==down[x]){
            rec(v[x][i].first,x);
            return;
        }
    }
}

int main(){

    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin>>n>>k;
    for(int i=1;i<=n-1;i++){
        cin>>a>>b>>c;
        v[a].push_back(make_pair(b,c));
        v[b].push_back(make_pair(a,c));
    }
    if(k==1){
        dyndown(1,0);
        dynup(1,0,0);
        for(int i=1;i<=n;i++){
            cout<<max(down[i],up[i])<<"\n";
        }
        return 0;
    }

    for(int root=1;root<=n;root++){
        tim++;
        for(int i=1;i<=n;i++){
            for(int f=0;f<w[i].size();f++){
                w[i][f]=true;
            }
        }

        dyndown(root,0);ans=0;
        sort(pp+1,pp+n+1);
        cnt=0;

        for(int i=n;i>=1 and cnt<k;i--){
            if(pp[i].second==root or li[pp[i].second]==tim)continue;

            cnt++;
            ans+=pp[i].first;
            rec(pp[i].second,parent[pp[i].second]);
        }
        cout<<ans<<"\n";
    }
   

    return 0;
}