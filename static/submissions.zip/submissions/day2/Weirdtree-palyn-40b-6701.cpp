/**
* user:  palyn-40b
* fname: Stanislau
* lname: Palyn
* task:  Weirdtree
* score: 21.0
* date:  2021-12-17 11:10:51.266665
*/
#include <bits/stdc++.h>
#include "weirdtree.h"

#define fr(i, a, b) for(int i = (a); i <= (b); ++i)
#define rf(i, a, b) for(int i = (a); i >= (b); --i)
#define fe(x, y) for(auto& x : y)

#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define mt make_tuple

#define sz(x) (int)(x).size()
#define all(x) (x).begin(), (x).end()
#define pw(x) (1LL << (x))

using namespace std;

#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;
template<typename T>
using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define fbo find_by_order
#define ook order_of_key

template<typename T>
bool umn(T& a, T b) { return (a > b ? (a = b, 1) : 0); }
template<typename T>
bool umx(T& a, T b) { return (a < b ? (a = b, 1) : 0); }

using ll = long long;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
template<typename T>
using ve = vector<T>;

const int N = 3e5 + 5;

int n, q;
int a[N];

void initialise(int N, int Q, int h[]) {
    n = N;
    q = Q;
    fr(i, 1, n) {
        a[i] = h[i];
    }
}

ve<pii> solve(ve<pii>& a, int k) {
    sort(all(a));
    int oper = 0;
    while(k > 0) {
        int pos = 0;
        rf(i, sz(a) - 1, 0) {
            if(a[i].fi != a.back().fi) {
                pos = i + 1;
                break;
            }
        }
        int t = min(k / (sz(a) - pos), a[pos].fi - (pos > 0 ? a[pos - 1].fi : 0));
        fr(i, pos, sz(a) - 1) {
            a[i].fi -= t;
        }
        k -= t * (sz(a) - pos);
        if(t == 0) {
            fr(i, pos, sz(a) - 1) {
                if(k > 0) {
                    a[i].fi = max(0, a[i].fi - 1);
                    k--;
                }
            }
        }
        if(a.back().fi == 0) {
            break;
        }
        oper++;
        sort(all(a), [](pii a, pii b) {
            if(a.fi != b.fi) return a.fi < b.fi;
            else return a.se < b.se;
        });
    }
    return a;
}

void cut(int l, int r, int k) {
    if(n <= 1000 && q <= 1000) {
        ve<pii> v;
        fr(i, l, r) v.pb({a[i], i});
        ve<pii> ans = solve(v, k);
        fr(i, 0, sz(ans) - 1) {
            a[ans[i].se] = ans[i].fi;
        }
    } else {
        fr(t, 1, k) {
            int mx = -1e9;
            int mxi = -1;
            fr(i, l, r) {
                if(umx(mx, a[i])) {
                    mxi = i;
                }
            }
            if(a[mxi] > 0) a[mxi]--;
        }
    }
}


void magic(int i, int x) {
    a[i] = x;
}

ll inspect(int l, int r) {
//    fr(i, 1, n) cout << a[i] << " ";
//    cout << "\n";

	ll sum = 0;
	fr(i, l, r) sum += a[i];
	return sum;
}
