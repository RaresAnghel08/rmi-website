/**
* user:  stupariu-92e
* fname: Teodor-Mihai
* lname: Stupariu
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 08:19:05.240117
*/
#include "weirdtree.h"
int n,m,v[300005];
void initialise(int N, int Q, int h[])
{
    n=N;
    m=Q;
    for(int i=1; i<=N; i++)
        v[i]=h[i];
}
void cut(int l, int r, int k)
{
    while(k>0)
    {
        int maxx=0,cnt=1,re;
        for(int i=l; i<=r; i++)
        {
            if(maxx<v[i])
            {
                re=i;
                maxx=v[i];
                cnt=1;
            }
            else if(maxx==v[i])
                cnt++;
        }
        if(maxx!=0)
        {
            if(k>=cnt)
            {
                for(int i=l; i<=r; i++)
                {
                    if(maxx==v[i])
                        v[i]--;
                }
                k-=cnt;
            }
            else
            {
                for(int i=l; i<=r; i++)
                {
                    if(maxx==v[i])
                    {
                        v[i]--;
                        k--;
                    }
                    if(k==0)
                        break;
                }
            }
        }
        else break;
    }
}
void magic(int i, int x)
{
    v[i]=x;
}
long long int inspect(int l, int r)
{
    long long sum=0;
    for(int i=l; i<=r; i++)
    {
        sum+=v[i];
    }
    return sum;
}
