/**
* user:  priboi-950
* fname: Mihai Luca
* lname: Priboi
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 11:52:28.556352
*/
#include "weirdtree.h"

#define ll long long

#define MAXN 300000

struct interval {
  ll sum;
  int maxim, maxim2;
} aint[MAXN * 2];

int v[MAXN + 1];
int n;

inline int maxim( int a, int b ) {
  return v[a] >= v[b] ? a : b;
}

inline int maxim( int a, int b, int c ) {
  return maxim( a, maxim( b, c ) );
}

interval compun( const interval &a, const interval &b ) {
  interval r;

  if( v[a.maxim] >= v[b.maxim] ) {
    r.maxim = a.maxim;
    r.maxim2 = maxim( b.maxim, a.maxim2, b.maxim2 );
  }
  else {
    r.maxim = b.maxim;
    r.maxim2 = maxim( a.maxim, a.maxim2, b.maxim2 );
  }

  r.sum = a.sum + b.sum;

  return r;
}

void build( int st, int dr, int node ) {
  if( st == dr ) {
    aint[node].maxim = st;
    aint[node].maxim2 = 0;
    aint[node].sum = v[st];
  }
  else {
    int middle, lchild, rchild;
    middle = (st + dr) / 2;
    lchild = node + 1;
    rchild = node + 2 * ( middle - st + 1 );

    build( st, middle, lchild );
    build( middle + 1, dr, rchild );
    aint[node] = compun( aint[lchild], aint[rchild] );
  }
}

interval getInterval( int st, int dr, int qst, int qdr, int node ) {
  if( qst <= st && qdr >= dr )
    return aint[node];

  int middle, lchild, rchild;
  middle = (st + dr) / 2;
  lchild = node + 1;
  rchild = node + 2 * ( middle - st + 1 );

  interval a, b;
  a = b = {0, 0, 0};

  if( qst <= middle )
    a = getInterval( st, middle, qst, qdr, lchild );
  if( qdr >= middle + 1 )
    b = getInterval( middle + 1, dr, qst, qdr, rchild );

  return compun(a, b);
}

void update( int st, int dr, int node, int pos ) {
  if( st == dr ) {
    aint[node].sum = v[st];
    return;
  }

  int middle, lchild, rchild;
  middle = (st + dr) / 2;
  lchild = node + 1;
  rchild = node + 2 * ( middle - st + 1 );

  if( pos <= middle )
    update( st, middle, lchild, pos );
  else
    update( middle + 1, dr, rchild, pos );

  aint[node] = compun( aint[lchild], aint[rchild] );
}

//

void initialise(int N, int Q, int h[]) {
  int i;
  n = N;
  for( i = 1; i <= n; i++ )
    v[i] = h[i];

  build( 1, n, 0 );
}

void cut(int l, int r, int k) {
  interval x;
  int dif;

	while( k > 0 ) {
    x = getInterval( 1, n, l, r, 0 );

    if( v[x.maxim] == 0 )
      return;

    dif = v[x.maxim] - v[x.maxim2];

    if( x.maxim < x.maxim2 )
      dif++;

    dif = v[x.maxim] < dif ? v[x.maxim] : dif;
    dif = k < dif? k : dif;

    v[x.maxim] -= dif;
    k -= dif;
    update( 1, n, 0, x.maxim );
	}
}

void magic(int i, int x) {
	v[i] = x;
	update(1, n, 0, i);
}

long long int inspect(int l, int r) {
	return getInterval( 1, n, l, r,  0 ).sum;
}
