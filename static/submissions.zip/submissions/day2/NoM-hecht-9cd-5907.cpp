/**
* user:  hecht-9cd
* fname: Yahli
* lname: Hecht
* task:  NoM
* score: 21.0
* date:  2021-12-17 10:10:21.062452
*/
#include <iostream>
#include <vector>

using namespace std; 
using ll = long long;

const ll mod = 1e9 + 7; 

ll dp[102][102][102]; 
bool init[102][102][102];

ll fmod(ll val){
    ll res = 1;
    for (ll i = 1; i <= val; ++i) res = res*i%mod; 
    return res; 
}

ll pmod(ll a, ll b){
    if (b == 0) return 1; 
    ll res = pmod(a, b/2); 
    res = res*res%mod; 
    if (b%2) res = res*a%mod; 
    return res; 
}

ll inv(ll val){
    return pmod(val, mod-2); 
}

ll choose(int n, int m){
    ll res = fmod(n)*inv(fmod(m))%mod;
    res = res*inv(fmod(n-m))%mod; 
    return res; 
}

ll req_solve(int n, int m, int gr = 1, int re = 0, int par = 0){
    if (gr == m + 1) return (re == n); 
    if (init[gr][re][par]) return dp[gr][re][par]; 
    int all = (2*n)/m + (gr <= 2*n%m); 
    for (int x = 0; x <= min(par, all); ++x){
        ll c = fmod(all)*choose(par, x)%mod*choose(n-par-re, all-x)%mod;
        dp[gr][re][par] += c*req_solve(n, m, gr+1, re+x, par+all-2*x); 
        dp[gr][re][par] %= mod;
    }
    init[gr][re][par] = true;
    return dp[gr][re][par];  
} 

int main(){
    int n, m; cin >> n >> m; 
    req_solve(n, m); 
    cout << (dp[1][0][0]*pmod(2, n)%mod) << "\n";
}