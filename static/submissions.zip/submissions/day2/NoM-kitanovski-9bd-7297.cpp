/**
* user:  kitanovski-9bd
* fname: Teo 
* lname: Kitanovski
* task:  NoM
* score: 0.0
* date:  2021-12-17 11:49:47.177055
*/
#include <bits/stdc++.h>

typedef long long ll;

#define MS(x,y) memset((x), (y), sizeof((x)))
#define pb push_back
#define MN 1000000007

using namespace std;

int n,m;
ll dp[101][101][101];

ll rec(int pos, int zadnji, int kolku, bitset<101> koi, bitset<203> fateni) {
    if (pos == 2*n+1) return dp[pos][zadnji][kolku] = 1;
    if (dp[pos][zadnji][kolku] != -1) return dp[pos][zadnji][kolku];
    if (fateni[pos]) return dp[pos][zadnji][kolku] = rec(pos+1,zadnji,kolku,koi,fateni);

    int ret = 0;

    for (int i = 0; i<n; i++) {
        if (koi[i]) continue;

        koi[i] = 1;
        fateni[pos] = 1;

        for (int j = pos+1; j<=2*n; j++) {
            if (!fateni[j] && (j-pos)%m != 0) {
                fateni[j] = 1;
                ret += (rec(pos+1,j,kolku+1,koi,fateni)*2)%MN;
                ret %= MN;
                fateni[j] = 0;
            }
        }

        fateni[pos] = 0;
        koi[i] = 0;
    }

    return dp[pos][zadnji][kolku] = ret % MN;
}

int main() {
    #ifdef LOCAL_DEBUG
        fstream cin("in.txt");
    #endif // LOCAL_DEBUG

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    MS(dp,-1);

    cin>>n>>m;

    bitset<101> empti1;
    bitset<203> empti2;
    empti1.reset();
    empti2.reset();

    cout<<rec(1,0,0,empti1,empti2)<<endl;
}
