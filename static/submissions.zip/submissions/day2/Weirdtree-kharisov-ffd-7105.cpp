/**
* user:  kharisov-ffd
* fname: Bulat Rafailevich
* lname: Kharisov
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:37:25.773737
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define size(a) (int)a.size()
#define pii pair<int, int>
#define fi first
#define se second
#define pb emplace_back
#define chkmax(a, b) a = max(a, b)
#define chkmin(a, b) a = min(a, b)

const int N = (1 << 19), mod = 1e9+7;


struct node {
    ll mx1, cnt, mx2, sum;
    node() : mx1(), cnt(), mx2(-1), sum() {}
    node(ll mx1, ll cnt, ll mx2, ll sum) : mx1(mx1), cnt(cnt), mx2(mx2), sum(sum) {}
} t[2*N];

ll n, q;

node merge(node l, node r) {
    node res;
    res.mx1 = max(l.mx1, r.mx1);
    res.cnt = (l.mx1==res.mx1 ? l.cnt : 0) + (r.mx1 == res.mx1 ? r.cnt : 0);

    res.mx2 = max(l.mx2, r.mx2);
    if (l.mx1 != res.mx1) chkmax(res.mx2, l.mx1);
    if (r.mx1 != res.mx1) chkmax(res.mx2, r.mx1);

    res.sum = l.sum + r.sum;
    return res;
}

void upd(ll v, ll x) {
	if (x > t[v].mx1) return;
	t[v].sum -= (t[v].mx1 - x) * t[v].cnt;
	t[v].mx1 = x;
}
void push(ll v) {
	upd(v*2, t[v].mx1);
	upd(v*2+1, t[v].mx1);
}

node segget(ll l, ll r, ll v, ll tl, ll tr) {
    if (tl >= r || tr <= l) return {-1, 0, -1, 0};
    if (tl >= l && tr <= r) return t[v];
    push(v);
    ll mid = (tl + tr) / 2;
    auto t1 = segget(l, r, v*2, tl, mid);
    auto t2 = segget(l, r, v*2+1, mid, tr);
    return merge(t1, t2);
}

void mineq(ll l, ll r, ll x, ll k, ll v, ll tl, ll tr) {
    if (tl >= r || tr <= l || t[v].mx1 <= x) return;
    if (tl >= l && tr <= r && t[v].mx2 < x && t[v].cnt <= k && tr - tl == 1) {
    	upd(v, x);
        return;
    }
    if (tr - tl == 1) return;
    push(v);
    ll mid = (tl + tr) / 2;
    ll rem = k - (t[v*2].mx1 > x ? t[v*2].cnt : 0);
    mineq(l, r, x, k, v*2, tl, mid);
    if (rem > 0) mineq(l, r, x, rem, v*2+1, mid, tr);
    t[v] = merge(t[v*2], t[v*2+1]);
}

void change(ll id, ll x, ll v, ll tl, ll tr) {
    if (tl > id || tr <= id) return;
    if (tl == id && id == tr - 1) {
        t[v].sum = t[v].mx1 = x;
        return;
    }
    push(v);
    ll mid = (tl + tr) / 2;
    change(id, x, v*2, tl, mid);
    change(id, x, v*2+1, mid, tr);
    t[v] = merge(t[v*2], t[v*2+1]);
}

void initialise(int _N, int Q, int h[]) {
	n = _N, q = Q;
	for (int i = 0; i < n; ++i)
		t[N+i] = {h[i+1], 1, -1, h[i+1]};
	for (int i = N-1; i; --i)
		t[i] = merge(t[i*2], t[i*2+1]);
}

void cut(int l, int r, int k) {
	--l;
	auto st = segget(l, r, 1, 0, N);
	while (k >= st.cnt && st.mx1 > 0) {
		ll ch = min(min(st.mx1-st.mx2, k/st.cnt), st.mx1);
		k -= st.cnt*ch;
		mineq(l, r, st.mx1-ch, st.cnt, 1, 0, N);
		st = segget(l, r, 1, 0, N);
	}
	if (st.mx1 > 0) {
		mineq(l, r, st.mx1-1, k, 1, 0, N);
	}
}
void magic(int i, int x) {
	change(i-1, x, 1, 0, N);
}
long long int inspect(int l, int r) {
	return segget(l-1, r, 1, 0, N).sum;
}
