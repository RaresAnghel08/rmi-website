/**
* user:  smutchak-ea1
* fname: Andrii
* lname: Smutchak
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:24:46.524464
*/
#pragma GCC optimize("O3,unroll-loops")
#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
vector<pair<int,ll>> G[1007];
ll dp[1007][1007];
ll dpT[1007];
ll dpT2[1007];
int P[1007];
int ans[1007];
int n,k;
vector<int> euler;
void build_dp(int v,int p){
    for(int i = 0;i <= k;i++) dpT[i] = -1e9,dpT2[i] = -1e9;
    dpT[0] = 0;
    dpT[1] = 0;
    dpT2[0] = 0;
    dpT2[1] = 0;
    for(int i = 0;i < G[v].size();i++){
        if(G[v][i].first == p) continue;
        for(int j = 1;j <= k;j++){
            for(int l = 0;l <= k-j;l++){
                dpT2[l+j] = max(dpT2[l+j],dpT[l]+dp[G[v][i].first][j]+G[v][i].second);
            }
        }
        for(int j = 0;j <=k; j++) dpT[j] = dpT2[j];
     }
     for(int i = 0;i <= k;i++) dp[v][i] = dpT[i];
}
void dfs(int v,int p){
    if(P[v] == p) return;
    P[v] = p;
    for(int i = 0;i < G[v].size();i++){
        if(G[v][i].first != p) dfs(G[v][i].first,v);
    }
    build_dp(v,p);
}
void dfs2(int v,int p){
    euler.push_back(v);
    for(int i = 0;i < G[v].size();i++){
        if(G[v][i].first != p) dfs2(G[v][i].first,v);
    }
}
int main()
{
    cin >> n >> k;
    for(int i = 0;i < n-1;i++){
        ll u,v,c;
        cin >> u >> v >> c;
        G[u].push_back({v,c});
        G[v].push_back({u,c});
    }
    /*dfs(1,0);
    for(int i = 1;i <=n;i++){
        for(int j = 1;j<=k;j++) cout << dp[i][j] << " ";
        cout << "\n";
    }*/
    dfs2(1,-1);
    for(int i = 1;i <=n;i++){
        dfs(euler[i-1],-1);
        ans[euler[i-1]] = dp[euler[i-1]][k];
    }
    for(int i = 1;i <= n;i++) cout << ans[i] << "\n";
    return 0;
}
