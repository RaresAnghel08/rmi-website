/**
* user:  mate-5ef
* fname: Lőrinc
* lname: Máté
* task:  Weirdtree
* score: 0.0
* date:  2021-12-17 11:02:41.431611
*/
#include <bits/stdc++.h>

using namespace std;

int n;
vector<pair<long long, long long> > segmentTree, lazyTree;
vector<long long> tomb;

void builtSegmentTree (int pos, int l, int r){
    // cout << pos << " " << l << " " << r << endl;
    if (l == r) {
        segmentTree[pos].first = segmentTree[pos].second = tomb[l];
        // cout << "tombElem: " << tomb[l] << endl;
        return;
    }


    int mid = (l + r) / 2;
    builtSegmentTree(pos * 2 + 1, l, mid);
    builtSegmentTree(pos * 2 + 2, mid + 1, r);

    segmentTree[pos].first = max(segmentTree[pos * 2 + 1].first, segmentTree[pos * 2 + 2].first);
    segmentTree[pos].second = segmentTree[pos * 2 + 1].second + segmentTree[pos * 2 + 2].second;
}

void update (int pos, int l, int r, int curl, int curr){
    // cout << pos << " " << curl << " " << curr << endl;
    if (curl == curr){
        segmentTree[pos].first--;
        segmentTree[pos].second--;
        tomb[curl]--;
        return;
    }

    int mid = (curl + curr) / 2;

    if (r <= mid) update(pos * 2 + 1, l, r, curl, mid);
    else if (l > mid) update(pos * 2 + 2, l, r, mid + 1, curr);
    else if (segmentTree[pos * 2 + 1].first >= segmentTree[pos * 2 + 2].first) update(pos * 2 + 1, l, r, curl, mid);
    else update(pos * 2 + 2, l, r, mid + 1, curr);

    segmentTree[pos].first = max(segmentTree[pos * 2 + 1].first, segmentTree[pos * 2 + 2].first);
    segmentTree[pos].second = segmentTree[pos * 2 + 1].second + segmentTree[pos * 2 + 2].second;
}

void update2 (int pos, int tarPos, int curl, int curr, int value){
    if (curl == curr){
        segmentTree[pos].first = segmentTree[pos].second = value;
        tomb[curl] = value;
        return;
    }

    int mid = (curl + curr) / 2;

    if (tarPos <= mid) update2(pos * 2 + 1, tarPos, curl, mid, value);
    if (tarPos > mid) update2(pos * 2 + 2, tarPos, mid + 1, curr, value);

    segmentTree[pos].first = max(segmentTree[pos * 2 + 1].first, segmentTree[pos * 2 + 2].first);
    segmentTree[pos].second = segmentTree[pos * 2 + 1].second + segmentTree[pos * 2 + 2].second;
}

long long int querry (int pos, int l, int r, int curl, int curr){
    // cout << pos << " " << curl << " " << curr << endl;
    if (l >= curl && r <= curr) return segmentTree[pos].second;

    long long mid = (curl + curr) / 2, res = 0;
    if (l <= mid) res += querry(pos * 2 + 1, l, r, curl, mid);
    if (r > mid) res += querry(pos * 2 + 2, l, r, mid + 1, curr);

    return res;
}

void initialise(int N, int Q, int h[]){
    n = N;
    segmentTree.resize(n * 4);
    tomb.resize(n);
    for (int i = 0; i < n; i++) tomb[i] = h[i + 1];

    builtSegmentTree(0, 0, N - 1);

    // for (pair<long long, long long> x : segmentTree) cout << x.second << " ";
    // cout << endl;
}
void cut(int l, int r, int k){
    update(0, l - 1, r - 1, 0, n - 1);
    // for (int x : tomb) cout << x << " ";
    // cout << endl;
    // for (pair<long long, long long> x : segmentTree) cout << x.second << " ";
    // cout << endl;
}
void magic(int i, int x){
    update2(0, i - 1, 0, n - 1, x);
}
long long int inspect(int l, int r){
    return querry(0, l - 1, r - 1, 0, n - 1);
}

/*

6 10
1 2 3 1 2 3
1 1 6 3
3 1 6
1 1 3 3
3 1 6
1 1 3 1000
3 1 6
2 1 1000
3 1 6
1 1 3 999
3 1 5

*/


