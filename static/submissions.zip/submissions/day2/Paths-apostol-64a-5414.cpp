/**
* user:  apostol-64a
* fname: Ilie-Daniel
* lname: Apostol
* task:  Paths
* score: 0.0
* date:  2021-12-17 09:28:02.471407
*/
#include <bits/stdc++.h>

using namespace std;
const int MAX_N = 2000;
vector <pair <int, int>> gr[1 + MAX_N]; /// first-> vec, second-> # of treats

using ll = long long;

pair <ll, int> seg[1 + 8 * MAX_N];
ll lazy[1 + 8 * MAX_N];


inline void push(int node, int length) {
    if (lazy[node] != 0) {
        if (length > 0) {
            lazy[node * 2] += lazy[node];
            lazy[node * 2 + 1] += lazy[node];
        }
        seg[node].first += lazy[node];
        lazy[node] = 0;
    }
}
inline void update_pos(int node, int lb, int rb, int pos, ll val) {
    if (lb == rb) {
        /// change leaf
        seg[node] = {val, pos};
        lazy[node] = 0;
        return;
    }
    int mid = (lb + rb) / 2, lnode = node * 2, rnode = node * 2 + 1;
    if (pos <= mid)
        update_pos(lnode, lb, mid, pos, val);
    else
        update_pos(rnode, mid + 1, rb, pos, val);
    seg[node] = max(seg[lnode], seg[rnode]);
}

inline void update_range(int node, int lb, int rb, int ql, int qr, ll value) {
    if (ql <= lb && rb <= qr) {
        lazy[node] += value;
        push(node, rb - lb);
        return;
    }
    int mid = (lb + rb) / 2, lnode = node * 2, rnode = node * 2 + 1;
    push(lnode, mid - lb);
    if (ql <= mid) {
        update_range(lnode, lb, mid, ql, qr, value);
    }
    push(rnode, rb - (mid + 1));
    if (qr > mid)
        update_range(rnode, mid + 1, rb, ql, qr, value);
    seg[node] = max(seg[lnode], seg[rnode]);
}
pair <ll, int> query_range(int node, int lb, int rb, int ql, int qr) {
    push(node, rb - lb);
    if (ql <= lb && rb <= qr)
        return seg[node];
    int mid = (lb + rb) / 2, lnode = node * 2, rnode = node * 2 + 1;
    pair <ll, int> ans = {-1, 0};
    if (ql <= mid)
        ans = max(ans, query_range(lnode, lb, mid, ql, qr));
    if (qr > mid)
        ans = max(ans, query_range(rnode, mid + 1, rb, ql, qr));
    return ans;
}

int n, k;
int mom;
int L[1 + MAX_N], R[1 + MAX_N];
int p[1 + MAX_N];
int up_edge[1 + MAX_N];
int id[1 + MAX_N];
int nr_leaf;
void dfs_leaf(int node, int par) {
    if (gr[node].size() == 1 && par > 0)
        nr_leaf++;
    for (auto it : gr[node]) {
        int son = it.first;
        if (son != par) {
            dfs_leaf(son, node);
        }
    }
}
void dfs_prec(int node, int par, ll w) {
    L[node] = mom + 1;
    p[node] = par;
    if (gr[node].size() == 1 && par > 0) {
        mom++;
        id[mom] = node;
        update_pos(1, 1, nr_leaf, mom, w);
    }
    for (auto it : gr[node]) {
        int son = it.first;
        int c = it.second;
        if (son != par) {
            up_edge[son] = c;
            dfs_prec(son, node, w + c);
        }
    }
    R[node] = mom;
}

bool used[1 + MAX_N];

void calc(int root) {
    if (n == 1) {
        cout << "0\n";
        return;
    }
    for (int i = 1; i <= n; i++)
        used[i] = false, p[i] = 0, up_edge[i] = 0;
    nr_leaf = 0;
    dfs_leaf(root, 0);
    mom = 0;
    dfs_prec(root, 0, 0);
    ll ans = 0;
    for (int step = 1; step <= min(k, nr_leaf); step++) {
        pair<ll, int> best = query_range(1, 1, nr_leaf, 1, mom);

        ans += best.first;
        int now = id[best.second];
        while (used[now] == false && now != root) {
            update_range(1, 1, nr_leaf, L[now], R[now], -up_edge[now]);
            used[now] = true;
            now = p[now];
        }
    }
    cout << ans << "\n";
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    cin >> n >> k;
    for (int i = 1; i < n; i++) {
        int x, y, c;
        cin >> x >> y >> c;
        gr[x].push_back({y, c});
        gr[y].push_back({x, c});
    }
    for (int root = 1; root <= n; root++)
        calc(root);
    //calc(1);
    return 0;
}
