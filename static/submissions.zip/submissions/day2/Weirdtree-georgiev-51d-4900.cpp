/**
* user:  georgiev-51d
* fname: Aleksandar Petrov
* lname: Georgiev
* task:  Weirdtree
* score: 5.0
* date:  2021-12-17 08:44:10.333800
*/
#include<bits/stdc++.h>
#define endl '\n'
#include "weirdtree.h"
using namespace std;
long long n,q;
long long a[300050];
long long tree[600010];
struct f
{
    long long a,i;
    f(){}
    f(long long b, long long c)
    {
        a=b;
        i=c;
    }
};
bool operator<(f p, f q)
{
    return p.a<q.a;
}

void build(long long vr, long long l, long long r)
{
    if(l==r)tree[vr]=a[l];
    else
    {
        long long mid=(l+r)/2;
        build(2*vr,l,mid);
        build(2*vr+1,mid+1,r);
        tree[vr]=tree[2*vr]+tree[2*vr+1];
    }
}
void update(long long vr, long long l, long long r, long long i,long long d)
{
    if(i<l||i>r)return;
    else if(l==r)tree[vr]=d;
    else
    {
        long long mid=(l+r)/2;
        update(2*vr,l,mid,i,d);
        update(2*vr+1,mid+1,r,i,d);
        tree[vr]=tree[2*vr]+tree[2*vr+1];
    }
}
long long query(long long vr, long long b, long long e, long long l, long long r)
{
    if(e<l||b>r)return 0;
    else if(l<=b&&r>=e)return tree[vr];
    long long mid=(b+e)/2;
    return query(2*vr, b, mid, l, r)+query(2*vr+1, mid+1, e, l, r);
}
void initialise(int N, int Q, int h[])
{
    n=N;
    q=Q;
    for(long long i=1;i<=n;i++)
    {
        a[i]=h[i];
    }
    build(1,1,n);

}
void cut(int l, int r, int k)
{
    priority_queue<f> pq;
    for(long long i=l;i<=r;i++)
    {
        //cout<<a[i]<<" ";
        pq.push({a[i],i});
    }
    //cout<<pq.top().a<<" "<<pq.top().i<<endl;
    while(k&&pq.top().a!=0)
    {
        f p=pq.top();
        pq.pop();
        long long x=max((long long)1,p.a-pq.top().a);
        x=min(x,(long long)k);
        k-=x;
        a[p.i]-=x;
        //cout<<p.i<<" "<<a[p.i]<<endl;
        update(1,1,n,p.i,a[p.i]);
        pq.push({a[p.i],p.i});
    }
    /*for(long long i=1;i<=2*n+1;i++)
    {
        cout<<tree[i]<<" ";
    }*/
}
void magic(int i, int x)
{
    a[i]=x;
    update(1,0,n-1,i-1,x);
}
long long int inspect(int l, int r)
{
    return query(1,0,n-1,l-1,r-1);
}

