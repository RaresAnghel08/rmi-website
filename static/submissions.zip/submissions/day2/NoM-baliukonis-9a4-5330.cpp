/**
* user:  baliukonis-9a4
* fname: Tsimafei
* lname: Baliukonis
* task:  NoM
* score: 9.0
* date:  2021-12-17 09:21:03.446861
*/
#include<bits/stdc++.h>
#include<ext/pb_ds/tree_policy.hpp>
#include<ext/pb_ds/assoc_container.hpp>

#define ll long long
#define f first
#define s second
#define pb push_back

using namespace std;


const ll MOD = 1e9 + 7;

int32_t main() {

    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif // LOCAL

  ll n, m;
  cin >> n >> m;
  if(n > 5) return -1;
  vector<ll> e;
  for(int j = 0; j < n; j++) {
        e.pb(j); e.pb(j);
  }
  ll ans = 0;
  while(true) {
    vector<ll> v[n];
    for(int j = 0; j < 2 * n; j++) {
        v[e[j]].pb(j);
    }
    bool f1 = 1;
    for(int i = 0; i < n; i++) {
        if((v[i][1] - v[i][0]) % m == 0) {f1 = 0; break;}
    }
    ans += f1;
    if(!next_permutation(e.begin(), e.end())) break;
  }
  for(int e = 0; e < n; e++) {
    ans *= 2; ans %= MOD;
  }
  cout << ans;

}
