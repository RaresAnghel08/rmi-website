/**
* user:  karimov-0d4
* fname: Renat Airatovich
* lname: Karimov
* task:  Paths
* score: 56.0
* date:  2021-12-17 08:45:58.814930
*/
#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb push_back
#define ld long double

struct edge{
    int to, c, i;
};

const int N = 1e5 + 10;
vector<edge> g[N];
vector<pair<int,int>> par(N);
vector<int> used(N);
pair<int,int> bst;
vector<int> val(N);
vector<int> go(N);
vector<int> ans(N);
vector<int> tin(N), tout(N);
vector<pair<int,int>> all;
int root, cnt = 0, n, k;
pair<int,int> t[4 * N];
multiset<int> st;

void update(int v, int l, int r, int pos, int val){
    if (l == r){
        t[v].first += val;
        t[v].second = l;
        return;
    }
    int m = (l + r) / 2;
    if (pos <= m) update(2 * v, l, m, pos, val);
    else update(2 * v + 1, m + 1, r, pos, val);
    t[v] = max(t[v * 2], t[v * 2 + 1]);
}

pair<int,int> get(int v, int tl, int tr, int l, int r){
    if (l > r) return {-1, -1};
    if (tl == l && tr == r){
        return t[v];
    }
    int tm = (tl + tr) / 2;
    return max(get(2 * v, tl, tm, l, min(r, tm)), get(2 * v + 1, tm + 1, tr, max(l, tm + 1), r));
}

void dfs(int v, int p){
    tin[v] = cnt++;
    pair<int,int> bst{-1, -1};
    for (auto to : g[v]){
        if (to.to != p){
            dfs(to.to, v);
            bst = max(bst, make_pair(val[to.to] + to.c, to.to));
        }
    }
    if (bst.first == -1){
        val[v] = 0;
        go[v] = -1;
    }
    else{
        val[v] = bst.first, go[v] = bst.second;
    }
    tout[v] = cnt - 1;
}

void zhfs(int v, int p, int sum){
    if (go[v] == -1) all.pb({v, sum});
    else all.pb({v, 0});
    for (auto to : g[v]){
        if (to.to != p){
            if (to.to == go[v]){
                zhfs(to.to, v, sum + to.c);
            }
            else{
                zhfs(to.to, v, to.c);
            }
        }
    }
}

int get(){
    int ans = 0;
    vector<int> arr;
    for (auto to : st) arr.pb(to);
    sort(arr.rbegin(), arr.rend());
    for (int i = 0; i < k; i++) ans += arr[i];
    return ans;
}

void change(int v, int val){
    st.erase(st.find(get(1, 0, n - 1, v, v).first));
    update(1, 0, n - 1, v, val);
    st.insert(get(1, 0, n - 1, v, v).first);
}

void walk(int v, int p){
    ans[v] = get();
    for (auto to : g[v]){
        if (to.to != p){
            pair<int,int> bst = {-1, -1}, pr;
            bst = max(bst, get(1, 0, n - 1, 0, tin[to.to] - 1));
            bst = max(bst, get(1, 0, n - 1, tout[to.to] + 1, n - 1));
            if (bst.first != -1){
                change(bst.second, to.c);
            }
            pr = get(1, 0, n - 1, tin[to.to], tout[to.to]);
            change(pr.second, -to.c);
            walk(to.to, v);
            if (bst.first != -1){
                change(bst.second, -to.c);
            }
            change(pr.second, to.c);
        }
    }
}

vector<int> solve(int N, int K, vector<int> a, vector<int> b, vector<int> c){
    n = N, k = K;
    cnt = 0;
    st.clear();
    for (int i = 0; i < n; i++){
        g[i].clear();
    }
    for (int i = 0; i < n - 1; i++){
        g[a[i]].pb({b[i], c[i], i});
        g[b[i]].pb({a[i], c[i], i});
    }
    root = 0;
    while(g[root].size() == 1) root++;
    dfs(root, -1);
    zhfs(root, -1, 0);
    for (auto to : all){
        update(1, 0, n - 1, tin[to.first], to.second);
        st.insert(to.second);
    }
    walk(root, -1);
    vector<int> arr(ans.begin(), ans.begin() + N);
    return arr;
}

mt19937 rnd(51);

signed main()
{
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif // LOCAL
    int n, k;
    cin >> n >> k;
    vector<int> a(n - 1), b(n - 1), c(n - 1);
    for (int i = 0; i < n - 1; i++){
        cin >> a[i] >> b[i] >> c[i];
        a[i]--, b[i]--;
    }
    vector<int> ans = solve(n, k, a, b, c);
    for (auto to : ans){
        cout << to << '\n';
    }
    return 0;
}
