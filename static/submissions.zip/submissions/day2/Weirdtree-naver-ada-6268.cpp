/**
* user:  naver-ada
* fname: Oleh
* lname: Naver
* task:  Weirdtree
* score: 13.0
* date:  2021-12-17 10:40:05.124450
*/
#include "weirdtree.h"
#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
const int N=300100;
int n,q;
int h[N];
pair<int,int> t[N*4];
ll sum[N*4];
void build(int v,int l,int r){
    if (l==r) {
        t[v]={h[l],-l};
        sum[v]=h[l];
        return;
    }
    int m=(l+r)/2;
    build(v+v,l,m);
    build(v+v+1,m+1,r);
    t[v]=max(t[v+v],t[v+v+1]);
    sum[v]=sum[v+v]+sum[v+v+1];
}
void upd(int v,int l,int r,int pos,int x){
    if (l==r){
        h[l]=x;
        t[v]={h[l],-l};
        sum[v]=h[l];
        return;
    }
    int m=(l+r)/2;
    if (pos<=m) upd(v+v,l,m,pos,x);
    else upd(v+v+1,m+1,r,pos,x);
    t[v]=max(t[v+v],t[v+v+1]);
    sum[v]=sum[v+v]+sum[v+v+1];

}
pair<int,int>get(int v,int l,int r,int L,int R){
    if (l>R || r<L) return {0,0};
    if (l>=L && r<=R) return t[v];
    int m=(l+r)/2;
    return max(get(v+v,l,m,L,R),get(v+v+1,m+1,r,L,R));
}
ll get_sum(int v,int l,int r,int L,int R){
    if (l>R || r<L) return 0;
    if (l>=L && r<=R) return sum[v];
    int m=(l+r)/2;
    return get_sum(v+v,l,m,L,R)+get_sum(v+v+1,m+1,r,L,R);
}

void initialise(int nn, int qq, int hh[]) {
	// Your code here.
	n=nn;
	q=qq;
	for (int i=1;i<=n;i++) h[i]=hh[i];
	build(1,1,n);
}
void cut(int l, int r, int k) {
	// Your code here.
	for (int it=1;it<=k;it++){
        auto cur=get(1,1,n,l,r);
        if (!cur.first) break;
        upd(1,1,n,-cur.second,cur.first-1);
	}
}
void magic(int i, int x) {
    upd(1,1,n,i,x);
	// Your code here.
}
long long int inspect(int l, int r) {
	// Your code here.
	return get_sum(1,1,n,l,r);
}
/**
6 2
1 2 3 1 2 3
1 1 6 3
3 1 6

**/
