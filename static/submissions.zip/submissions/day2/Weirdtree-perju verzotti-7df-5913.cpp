/**
* user:  perju verzotti-7df
* fname: Luca
* lname: Perju Verzotti
* task:  Weirdtree
* score: 23.0
* date:  2021-12-17 10:10:59.598034
*/
#include "weirdtree.h"
#include <bits/stdc++.h>
using namespace std;
struct ura
{
    int m1,cntm1,m2,cntm2;
    long long s;
}aint[1200003];
int lazy[1200003];
int n;
int vi[300003];
ura join (ura a, ura b)
{
    ura rz;
    rz.s=a.s+b.s;
    if(a.m1==b.m1)
    {
        rz.m1=a.m1;
        rz.cntm1=a.cntm1+b.cntm1;
        rz.m2=max(a.m2,b.m2);
        if(a.m2==b.m2)
            rz.cntm2=a.cntm2+b.cntm2;
        else if(a.m2>b.m2)
            rz.cntm2=a.cntm2;
        else
            rz.cntm2=b.cntm2;
        return rz;
    }
    if(a.m1<b.m1)
        swap(a,b);
    rz.m1=a.m1;
    rz.cntm1=a.cntm1;
    rz.m2=max(a.m2,b.m1);
    if(a.m2==b.m1)
        rz.cntm2=a.cntm2+b.cntm1;
    else if(a.m2>b.m1)
        rz.cntm2=a.cntm2;
    else
        rz.cntm2=b.cntm1;
    return rz;
}
void build (int nod, int l, int r)
{
    if(l==r)
    {
        aint[nod].cntm1=1;
        aint[nod].m1=vi[l];
        aint[nod].cntm2=0;
        aint[nod].m2=-1;
        aint[nod].s=vi[l];
        return;
    }
    int mid=(l+r)/2;
    build(nod<<1,l,mid);
    build((nod<<1)|1,mid+1,r);
    aint[nod]=join(aint[nod<<1],aint[(nod<<1)|1]);
}
void propag (int nod, int l, int r)
{
    assert(lazy[nod]>=aint[nod].m2);
    if(lazy[nod]>aint[nod].m1)
    {
        lazy[nod]=1000000001;
        return;
    }
    aint[nod].s-=aint[nod].cntm1*1LL*(aint[nod].m1-lazy[nod]);
    aint[nod].m1=lazy[nod];
    if(l==r)
    {
        lazy[nod]=1000000001;
        return;
    }
    lazy[nod<<1]=min(lazy[nod<<1],lazy[nod]);
    lazy[(nod<<1)|1]=min(lazy[(nod<<1)|1],lazy[nod]);
    lazy[nod]=1000000001;
}
ura getstr (int nod, int l, int r, int ql, int qr)
{
    propag(nod,l,r);
    if(ql<=l && r<=qr)
        return aint[nod];
    int mid=(l+r)/2;
    if(qr<=mid)
        return getstr(nod<<1,l,mid,ql,qr);
    else if(mid<ql)
        return getstr((nod<<1)|1,mid+1,r,ql,qr);
    else
        return join(getstr(nod<<1,l,mid,ql,qr),getstr((nod<<1)|1,mid+1,r,ql,qr));
}
void updmin (int nod, int l, int r, int ql, int qr, int val)
{
    propag(nod,l,r);
    int mid=(l+r)/2;
    if(val>=aint[nod].m1)
        return;
    if(ql<=l && r<=qr)
    {
        if(aint[nod].m2<val)
        {
            lazy[nod]=min(lazy[nod],val);
            propag(nod,l,r);
            return;
        }
        updmin(nod<<1,l,mid,ql,qr,val);
        updmin((nod<<1)|1,mid+1,r,ql,qr,val);
    }
    else
    {
        if(qr<=mid)
            updmin(nod<<1,l,mid,ql,qr,val);
        else if(mid<ql)
            updmin((nod<<1)|1,mid+1,r,ql,qr,val);
        else
        {
            updmin(nod<<1,l,mid,ql,qr,val);
            updmin((nod<<1)|1,mid+1,r,ql,qr,val);
        }
    }
    propag(nod<<1,l,mid);
    propag((nod<<1)|1,mid+1,r);
    aint[nod]=join(aint[nod<<1],aint[(nod<<1)|1]);
}
void updpos (int nod, int l, int r, int pz, int newval)
{
    propag(nod,l,r);
    if(pz<l || r<pz)
        return;
    if(l==r)
    {
        aint[nod].cntm1=1;
        aint[nod].m1=newval;
        aint[nod].cntm2=0;
        aint[nod].m2=-1;
        aint[nod].s=newval;
        return;
    }
    int mid=(l+r)/2;
    if(pz<=mid)
        updpos(nod<<1,l,mid,pz,newval);
    else
        updpos((nod<<1)|1,mid+1,r,pz,newval);
    propag(nod<<1,l,mid);
    propag((nod<<1)|1,mid+1,r);
    aint[nod]=join(aint[nod<<1],aint[(nod<<1)|1]);
}
int cbin (int nod, int l, int r, int pz, int val, int kth)
{
    propag(nod,l,r);
    if(r<pz)
        return -1;
    if(l==r)
    {
        if(pz<=l && kth==1 && aint[nod].m1==val)
            return l;
        if(aint[nod].m1!=val)
            return -1;
        return -2;
    }
    int mid=(l+r)/2;
    if(pz<=l)
    {
        if(aint[nod<<1].m1==val && aint[nod<<1].cntm1>=kth || aint[nod<<1].m1>val)
            return cbin(nod<<1,l,mid,pz,val,kth);
        else
            return cbin((nod<<1)|1,mid+1,r,pz,val,kth-aint[nod<<1].cntm1*(aint[nod<<1].m1==val));
    }
    int a=cbin(nod<<1,l,mid,pz,val,kth);
    if(a<0)
    {
        ++a;
        a=-a;
        int b=cbin((nod<<1)|1,mid+1,r,pz,val,kth-a);
        if(b>0)
            return b;
        else
            return b-a;
    }
    else
        return a;
}
void initialise(int N, int Q, int h[]) {
	/// very useful Q
    n=N;
    for(int i=1;i<=n;++i)
        vi[i]=h[i];
    build(1,1,n);
    for(int i=1;i<=n*4;++i)
        lazy[i]=1000000001;
}
void cut(int l, int r, int k) {
	ura a=getstr(1,1,n,l,r);
	if(a.m1==0)
        return;
    if(a.m2==-1)
    {
        int catpot=k/a.cntm1;
        int ram=k%a.cntm1;
        if(catpot>=a.m1)
        {
            updmin(1,1,n,l,r,0);
            return;
        }
        updmin(1,1,n,l,r,a.m1-catpot);
        int pz;
        if(ram)
        {
            pz=cbin(1,1,n,l,a.m1-catpot,ram);
            updmin(1,1,n,l,pz,a.m1-catpot-1);
        }
        return;
    }
    else
    {
        int catpot=k/a.cntm1;
        int ram=k%a.cntm1;
        if(catpot>=a.m1-a.m2)
        {
            k-=(a.m1-a.m2)*a.cntm1;
            updmin(1,1,n,l,r,a.m2);
            cut(l,r,k);
        }
        else
        {
            updmin(1,1,n,l,r,a.m1-catpot);
            int pz;
            if(ram)
            {
                pz=cbin(1,1,n,l,a.m1-catpot,ram);
                updmin(1,1,n,l,pz,a.m1-catpot-1);
            }
            return;
        }
    }
}
void magic(int i, int x) {
	updpos(1,1,n,i,x);
}
long long int inspect(int l, int r) {
	ura a=getstr(1,1,n,l,r);
	return a.s;
}



/*
int main() {
    int N, Q;
    cin >> N >> Q;

    int h[N + 1];

    for (int i = 1; i <= N; ++i) cin >> h[i];

    initialise(N, Q, h);

    for (int i = 1; i <= Q; ++i) {
        int t;
        cin >> t;

        if (t == 1) {
            int l, r, k;
            cin >> l >> r >> k;
            cut(l, r, k);
        } else if (t == 2) {
            int i, x;
            cin >> i >> x;
            magic(i, x);
        } else {
            int l, r;
            cin >> l >> r;
            cout << inspect(l, r) << '\n';
        }
    }
    return 0;
}
*/
