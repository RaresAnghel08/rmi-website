/**
* user:  elbaum-6df
* fname: Eitan
* lname: Elbaum
* task:  NoM
* score: 0.0
* date:  2021-12-17 09:38:23.274846
*/
#include <algorithm>
#include <iostream>
#include<vector>
using namespace std;
typedef long long ll;
ll mod = 1e9 + 7;
int main(){
    ll n,m; cin>>n>>m;
    int a[2*n];
    ll s=0;
    for(int i=0;i< 2*n;i++) a[i]=i;
    do{
        bool f=1;
        for(int i=0;i< 2*n;i++){
            for(int j=m;i+j < 2*n;j += m){
                if((a[i]-a[i+j]) % n == 0) f=0;
            }
        }
        if(f) (s+=1)%=mod;
    }while(next_permutation(a, a+2*n));
    cout<<s;
}