/**
* user:  radoslavov-f96
* fname: Aleksandar
* lname: Radoslavov
* task:  restore
* score: 13.0
* date:  2019-10-10 07:56:05.053488
*/
#include<iostream>
#include<vector>
using namespace std;
struct con
{
   int l, r, k, val;
};
int n, m;
const int maxn = 5100;
int arr[maxn];
vector<con> check;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> n >> m;
    for(int i = 0; i < n; i ++)
    {
        arr[i] = -1;
    }
    for(int i = 0; i < m; i ++)
    {
        con c;
        cin >> c.l >> c.r >> c.k >> c.val;
        c.r ++;
        check.push_back(c);
        if(c.k == 1 && c.val == 1)
        {
            for(int j = c.l; j < c.r; j ++)
            {
                arr[j] = 1;
            }
        }
        if(c.k == c.r - c.l && c.val == 0)
        {
            for(int j = c.l; j < c.r; j ++)
            {
                arr[j] = 0;
            }
        }
    }
    for(auto c: check)
    {
        if(c.k == 1 && c.val == 0)
        {
            bool found = false;
            for(int j = c.l;!found && j < c.r; j ++)
            {
                if(arr[j] != 1) found = true;
            }
            if(!found)
            {
                cout << -1;
                return 0;
            }
        }
        if(c.k == c.r - c.l && c.val == 1)
        {
            bool found = false;
            for(int j = c.l;!found && j < c.r; j ++)
            {
                if(arr[j] != 0) found = true;
            }
            if(!found)
            {
                cout << -1;
                return 0;
            }
        }
    }
    for(int i = 0; i < n; i ++)
    {
        if(arr[i] == -1)    arr[i] = 0;
        cout << arr[i] << " ";
    }
}
/**
4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0
*/
