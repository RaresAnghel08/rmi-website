/**
* user:  verde-76f
* fname: Flaviu-Cristian
* lname: Verde
* task:  devil
* score: 0.0
* date:  2019-10-10 09:21:11.084853
*/
#include <iostream>
#include <cstdio>
using namespace std;
int v[100001],vf[10];
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    int t,k,s,x,l,i,y;
    cin>>t;
    for(l=1; l<=t; l++)
    {
        s=0;
        cin>>k;
        for(i=1; i<10; i++)
        {
            cin>>vf[i];
            s+=vf[i];
        }
        for(i=1; i<=s; i++)
            v[i]=0;
        x=9;
        y=1;
        while(!vf[x])
            x--;
        while(!vf[y])
            y++;
        for(i=s; i>=s-(k-2); i--)
        {
            v[i]=x;
            vf[x]--;
            while(x&&vf[x]==0)
                x--;
        }
        v[1]=x;
        vf[x]--;
        while(x&&vf[x]==0)
            x--;
        for(i=2; i<s-(k-2); i++)
        {
            if(i%2==0)
            {
                v[i]=y;
                vf[y]--;
                while(y<=9&&vf[y]==0)
                    y++;
            }
            else
            {
                v[i]=x;
                vf[x]--;
                while(x&&vf[x]==0)
                    x--;
            }
        }
        for(i=1; i<=s; i++)
            cout<<v[i];
        cout<<'\n';
    }
    return 0;
}
