/**
* user:  donciu-262
* fname: Mircea
* lname: Donciu
* task:  restore
* score: 13.0
* date:  2019-10-10 07:56:52.419312
*/
#include <iostream>

using namespace std;
int n,m,i,k,v[5005],x[10005],y[10005],c[10005];
int main()
{
    //ifstream cin("rmi.in");
    //ofstream cout("rmi.out");
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        cin>>x[i]>>y[i]>>k>>c[i];
        x[i]++;
        y[i]++;
        if(c[i]==1)
        {
            v[x[i]]++;
            v[y[i]+1]--;
        }
    }
    for(i=1; i<=n; i++)
    {
        v[i]+=v[i-1];
        if(v[i-1]) v[i-1]=1;
    }
    if(v[n]) v[n]=1;
    for(i=1; i<=n; i++) v[i]+=v[i-1];
    for(i=1; i<=m; i++)
    {
        if(c[i]==0&&v[y[i]]-v[x[i]-1]==y[i]-x[i]+1)
        {
            cout<<"-1";
            return 0;
        }
    }
    for(i=1; i<=n; i++) cout<<v[i]-v[i-1]<<" ";
    return 0;
}
