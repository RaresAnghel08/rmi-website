/**
* user:  seritan-abd
* fname: Luca
* lname: Seritan
* task:  lucky
* score: 28.0
* date:  2019-10-10 08:41:20.410712
*/
#include<bits/stdc++.h>
// #include<ext/pb_ds/assoc_container.hpp> 

#pragma GCC optimize("Ofast")
#pragma GCC optimize("O3")

// using namespace __gnu_pbds;

using namespace std;

#define mp make_pair
#define sz(x) (int)((x).size())
#define all(x) (x).begin(),(x).end()
#define eb emplace_back

typedef long long ll;
typedef long double ld;
typedef pair< int, int > pii;
typedef pair< ll, ll > pll;

typedef vector< int > vi;
typedef vector< ll > vll;
typedef vector< pii > vpii;

const int MOD = 1e9 + 7;
const int MAXN = 1e5 + 10;
int n, q;
int x[MAXN];
ll cateAu13InPrefix[MAXN];
ll cateSuntMaiMiciSt[MAXN];
ll cateSuntMaiMiciDr[MAXN];
ll cateTotal[MAXN];
ll amGasit[MAXN];

int getAns(int l, int r) {
	cateSuntMaiMiciSt[l] = x[l];
	cateAu13InPrefix[l] = 0;
	for(int i = l - 1; i >= l-2; --i) {
		cateAu13InPrefix[i] = 0;
		cateSuntMaiMiciSt[i] = 0;
	}
	for(int i = l + 1; i <= r; ++i) {
		cateSuntMaiMiciSt[i] = (10ll*cateSuntMaiMiciSt[i-1] + x[i]) % MOD;
	}

	for(int i = l-1; i <= r + 1; ++i) amGasit[i] = 0;
	cateSuntMaiMiciDr[r] = x[r];
	cateSuntMaiMiciDr[r+1] = 0;
	cateTotal[r] = 10;
	cateTotal[r + 1] = 1;
	for(int i = r - 1; i >= l; --i) {
		cateTotal[i] = (10ll*cateTotal[i + 1]) % MOD;
		cateSuntMaiMiciDr[i] = (cateSuntMaiMiciDr[i + 1] + 1ll * x[i] * cateTotal[i + 1]) % MOD;
	}

	int ans = cateSuntMaiMiciSt[r];
	for(int pos13 = l; pos13 < r; ++pos13) {
		int curVal = x[pos13] * 10 + x[pos13 + 1];
		if(curVal > 13) {
			ll current = 1ll*(cateSuntMaiMiciSt[pos13 - 1] + (1 - amGasit[pos13-1]) - cateAu13InPrefix[pos13-1])*cateTotal[pos13 + 2] % MOD;
			if(current < 0) current += MOD;
			// cerr << current << '\n';
			cateAu13InPrefix[pos13 + 1] = ((cateAu13InPrefix[pos13]*10)%MOD + (cateSuntMaiMiciSt[pos13 - 1] + (1 - amGasit[pos13-1]) - cateAu13InPrefix[pos13-1]) % MOD) % MOD;
			if(cateAu13InPrefix[pos13 + 1] < 0) cateAu13InPrefix[pos13 + 1] += MOD;
			ans -= current;
			if(ans < 0) ans += MOD;
		} else if(curVal < 13) {
			ll current = 1ll*(cateSuntMaiMiciSt[pos13 - 1] - cateAu13InPrefix[pos13 - 1])*cateTotal[pos13 + 2] % MOD;
			if(current < 0) current += MOD;
			// cerr << current << '\n';
			cateAu13InPrefix[pos13 + 1] = ((cateAu13InPrefix[pos13]*10)%MOD + cateSuntMaiMiciSt[pos13 - 1] - cateAu13InPrefix[pos13-1]) % MOD;
			if(cateAu13InPrefix[pos13 + 1] < 0) cateAu13InPrefix[pos13 + 1] += MOD;

			ans -= current;
			if(ans < 0) ans += MOD;
		} else {
			ll current = 1ll*(cateSuntMaiMiciSt[pos13 - 1] - cateAu13InPrefix[pos13 - 1])*cateTotal[pos13 + 2] % MOD;
			if(current < 0) current += MOD;
			current = current + cateSuntMaiMiciDr[pos13 + 2];
			// cerr << current << '\n';
			cateAu13InPrefix[pos13 + 1] = ((cateAu13InPrefix[pos13]*10)%MOD + cateSuntMaiMiciSt[pos13 - 1] - cateAu13InPrefix[pos13-1]) % MOD;
			if(cateAu13InPrefix[pos13 + 1] < 0) cateAu13InPrefix[pos13 + 1] += MOD;
			if(current >= MOD) current -= MOD;
			ans -= current;
			if(ans < 0) ans += MOD;

			amGasit[pos13+1] = (1 | amGasit[pos13]);
		}
		// cerr << curVal << '\n';
		// cerr << ans << '\n';
		// cerr << '\n';
	}

	// for(int i = l; i <= r; ++i) {
	// 	cerr << cateSuntMaiMiciSt[i] << ' ' << cateAu13InPrefix[i] << '\n';
	// }

	return ans + 1 - amGasit[r];
}
int main() {
	#ifndef EVAL
		freopen("stdin", "r", stdin);
		freopen("stderr", "w", stderr);
	#endif

	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	cin >> n >> q;
	string s;
	cin >> s;


	for(int i = 1; i <= n; ++i) x[i] = s[i-1] - '0'; 

	cout << getAns(1, n) << '\n';

	for(int i = 0; i < q; ++i) {
		int t, a, b;
		cin >> t >> a >> b;

		if(t == 1) {
			cout << getAns(a, b) << '\n';
		} else {
			x[a] = b;
		}

	}
	return 0;
}