/**
* user:  nagy-e76
* fname: Nándor
* lname: Nagy
* task:  restore
* score: 7.0
* date:  2019-10-10 09:16:59.461194
*/
#include <bits/stdc++.h>
using namespace std;

struct Req {
    int l, r;
    int k, val;
    int len;
    void olvas() {
        cin>>l>>r>>k>>val;
        len = r-l+1;
    }
    bool good(int summa) {

        if(val == 0) return (len-summa >= k);
        else return (len-summa < k);
    }
};

vector<Req> kell;
int n, m;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>n>>m;
    kell.resize(m);
    for(int i=0;i<m;i++) {
        kell[i].olvas();
    }
    if(n < 19) {
        int ans = -1;
        for(int i=0;i<(1<<n);i++) {
            vector<int> ps(n,0);
            for(int j=0;j<n;j++)  {
                ps[j] = (i>>j) % 2 + (j == 0 ? 0 : ps[j-1]);
            }
            bool joe = true;
            for(int j=0;j<m && joe;j++) {
                int summa = ps[kell[j].r]- (kell[j].l == 0 ? 0 : ps[kell[j].l-1]);
                joe = joe && kell[j].good(summa);
            }
            if(joe) {
                ans = i;
                break;
            }
        }
        if(ans == -1) {
            cout<<-1<<endl;
            return 0;
        }
        vector<int> ar(n,0);
        for(int i=0;i<n;i++) {
            ar[i] = (ans>>i) % 2;
        }
        for(int i=0;i<n;i++) {
            cout<<ar[i]<<" ";
        }
        cout<<endl;
        return 0;
    }

}
