/**
* user:  minkov-a23
* fname: Stefan
* lname: Minkov
* task:  restore
* score: 0.0
* date:  2019-10-10 09:52:07.248666
*/
#include<iostream>
using namespace std;
int main()
{
  return 0;
}
