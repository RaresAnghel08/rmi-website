/**
* user:  kemanov-48c
* fname: Lachezar
* lname: Kemanov
* task:  devil
* score: 0.0
* date:  2019-10-10 08:25:31.672092
*/
#include<iostream>
using namespace std;
int digits[10],k,t;
int main()
{
    cin>>t;
    for(int a=0; a<t; a++)
    {
        cin>>k;
        int j=0;
        for(int b=1; b<10; b++)
        {
            cin>>digits[b];
            if(digits[b]>0)
                j=b;
        }
        digits[j]--;
        int l=1,r=9;
        while(l!=r)
        {

            if(digits[r]==0)
            {
                r--;
                continue;
            }
            if(digits[l]==0)
            {
                l++;
                continue;
            }
            cout<<r<<l;
            digits[r]--;
            digits[l]--;
        }
        while(digits[l]!=0)
        {
            cout<<l;
            digits[l]--;
        }
        cout<<j<<endl;
    }

    return 0;
}
