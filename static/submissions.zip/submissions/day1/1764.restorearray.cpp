/**
* user:  hryshechkin-0d8
* fname: Tykhon
* lname: Hryshechkin
* task:  restore
* score: 7.0
* date:  2019-10-10 07:43:12.021693
*/
#pragma GCC optimize ("O3")
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
#define ff first
#define ss second
#define pb push_bacb
#define mp mabe_pair
#define ll long long
#define ld long double
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ios ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define iter set<int>::iterator
#define ull unsigned long long
#define int long long
using namespace std;
using namespace __gnu_pbds;

template<class T>
using ordered_set=tree<T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

template<class T>
using ordered_multiset=tree<T,null_type,less_equal<T>,rb_tree_tag,tree_order_statistics_node_update>;

//find_by_order
//order_of_bey

mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());
mt19937_64 rnd1(chrono::steady_clock::now().time_since_epoch().count());

const int N=10000+7;
const double inf=1e18+5;
const int mod=1e9+7;

struct mine
{
    int l,r,k,mx;
};

mine b[N];
int a[N];
int cnt[N];

bool cmp(mine a,mine b)
{
    if (a.l<b.l)return true;
    if (a.l>b.l)return false;
    return a.r<b.r;
}

main ()
{
    ios;
    int n,m;
    cin>>n>>m;
    bool cc=true;
    for (int i=1;i<=m;++i){
        cin>>b[i].l>>b[i].r>>b[i].k>>b[i].mx;
        if (!(b[i].mx==1 || b[i].mx==b[i].r-b[i].l+1)){
            cc=false;
        }
    }
    if (cc){
        memset(a,-1,sizeof(a));
        sort(b+1,b+m+1,cmp);
        for (int i=1;i<=m;++i){
            if (b[i].k==1 && b[i].mx==1){
                for (int j=b[i].l;j<=b[i].r;++j){
                    if (a[j]==0){
                        cout<<-1<<endl;
                        exit(0);
                    }
                    a[j]=1;
                }
            }
            if (b[i].k==b[i].r-b[i].l+1 && b[i].mx==0){
                for (int j=b[i].l;j<=b[i].r;++j){
                    if (a[j]==1){
                        cout<<-1<<endl;
                        exit(0);
                    }
                    a[j]=0;
                }
            }
        }
        for (int i=0;i<n;++i){
            if (a[i]==-1){
                a[i]=0;
            }
            if (a[i]==0){
                cnt[i]++;
            }
            if (i)cnt[i]+=cnt[i-1];
        }
        for (int i=1;i<=m;++i){
            int l1=b[i].l,r1=b[i].r,k=b[i].k,mx=b[i].mx;
            if (mx==1){
                int f=cnt[r1];
                if (l1)f-=cnt[l1-1];
                if (f!=0){
                    cout<<-1<<endl;
                    exit(0);
                }
            }
            else {
                int f=cnt[r1];
                if (l1)f-=cnt[l1-1];
                if (f==0){
                    cout<<-1<<endl;
                    exit(0);
                }
            }
        }
        for (int i=0;i<n;++i){
            cout<<a[i]<<' ';
        }
    }
    else {
        for (int mask=0;mask<(1LL<<n);++mask){
            for (int i=0;i<n;++i){
                cnt[i]=0;
                if (i)cnt[i]+=cnt[i-1];
                cnt[i]+=((mask&(1LL<<i))>0);
            }
            bool good=true;
            for (int i=1;i<=m;++i){
                int l1=b[i].l;
                int r1=b[i].r;
                int cnt1=cnt[r1];
                if (l1)cnt1-=cnt[l1-1];
                int cnt0=r1-l1+1-cnt1;
                if (b[i].mx==0){
                    if (b[i].k>cnt0){
                        good=false;
                        break;
                    }
                }
                else {
                    if (b[i].k<=cnt0){
                        good=false;
                        break;
                    }
                }
            }
            if (good){
                for (int i=0;i<n;++i){
                    if ((mask&(1LL<<i))>0)cout<<1;
                    else cout<<0;
                    cout<<' ';
                }
                exit(0);
            }
        }
        cout<<-1<<endl;
    }
}
