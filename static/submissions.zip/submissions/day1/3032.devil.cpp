/**
* user:  khamitov-0d0
* fname: Tagir
* lname: Khamitov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:25:42.182780
*/
#include <bits/stdc++.h>

#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define f first
#define s second
#define size(x) (int)x.size()

using namespace std;

typedef long long ll;
typedef long double ld;

void io() {
#ifdef MLOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
}

void solve() {
    /*for(int i = 0; i <= 3; i++) {
        for(int j = 0; j <= 3; j++) {
            for(int k = 0; k <= 3; k++) {
                for(int p = 0; p <= 3; p++) {

                }
            }
        }
    }*/
    int t;
    cin >> t;
    while(t--) {
        int k;
        cin >> k;
        vector<int> d(9, 0);
        int n = 0;
        for(int i = 0; i < 9; i++) {
            cin >> d[i];
            n += d[i];
        }
        vector<int> a(n, -1);
        for(int i = 0; i < k - 1; i++) {
            if(d[1]) {
                a[n - i - 1] = 2;
                d[1]--;
            }else {
                a[n - i - 1] = 1;
                d[0]--;
            }
        }
        if(!d[1]) {
            for(int i = 0; i < n; i++) {
                if(a[i] == -1) {
                    a[i] = 1;
                }
            }
        }else {
            int p = d[0] / d[1];
            if(p > k - 1) {
                p = k - 1;
            }
            int t = 0;
            while(d[1]) {
                a[t] = 2;
                for(int i = 0; i < p; i++) {
                    a[t + i + 1] = 1;
                    d[0]--;
                }
                d[1]--;
                t = t + p + 1;
            }
            for(int i = 0; i < n; i++) {
                if(a[i] == -1) {
                    a[i] = 1;
                }
            }
        }
        for(int i = 0; i < n; i++) {
            cout << a[i];
        }
        cout << "\n";
    }
}

int main() {
    io();
    solve();
    return 0;
}
