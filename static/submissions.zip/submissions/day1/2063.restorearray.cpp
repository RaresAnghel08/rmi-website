/**
* user:  bachurski-d21
* fname: Jakub
* lname: Bachurski
* task:  restore
* score: 0.0
* date:  2019-10-10 08:27:11.810631
*/
#include <bits/stdc++.h>

using namespace std;

struct query { size_t l, r, k, value; };

int main()
{
    size_t n, m;
    cin >> n >> m;
    
    vector<query> Q(m);
    for(auto& q : Q)
        cin >> q.l >> q.r >> q.k >> q.value;
    
    if(n <= 18)
    {
        for(size_t a = 0; a < (1u << n); a++)
        {
            bool ok = true;
            for(size_t i = 0; ok and i < m; i++)
            {
                const auto& q = Q[i];
                size_t h = (a >> q.l) & ((1 << (q.r-q.l+1)) - 1);
                size_t c = __builtin_popcount(h);
                if(not ((q.value == 0 and c <= q.k) or (q.value == 1 and c > q.r-q.l-q.k+1)))
                    ok = false;
            }
            if(ok)
            {
                for(size_t i = 0; i < n; i++)
                    cout << (a >> i & 1) << ' ';
                cout << endl;
                return 0;
            }
        }
        cout << -1;
    }
    else
    {
        
    }
}
