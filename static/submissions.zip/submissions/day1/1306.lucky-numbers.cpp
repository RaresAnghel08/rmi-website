/**
* user:  dobleaga-573
* fname: Alexandru
* lname: Dobleaga
* task:  lucky
* score: 0.0
* date:  2019-10-10 06:13:27.496332
*/
#include <iostream>
#define MOD 1e9 + 7

using namespace std;

constexpr int NMAX = 1e5 + 5;

int n, q;
char ch;

int a[NMAX];

/*
void Precalculare()
{
    for (int i=1; i<=9; ++i)
        dp[1][i] = 1;

    for (int i=2; i<=100000; ++i)
    {
        int sum=0;

        for (int j=1; j<=9; ++j)
            sum = (sum + dp[i-1][j]) % MOD;


    }
}*/

int main()
{
    cin >> n >> q;

    int numar=0;

    for (int i=1; i<=n; ++i)
    {
        cin >> ch;

        a[i] = ch-'0';
        numar = numar * 10 + a[i];
    }

    int sol=0;

    for (int val=1; val <= numar; ++val)
    {
        int cif=0;
        int cop=val;
        int ult=0;
        int ok=1;

        while (cop > 0)
        {
            cif = cop % 10;
            if (cif == 1 && ult == 3) ok = 0;
            ult = cif;
            cop /= 10;
        }
        sol += ok;
    }

    cout << sol << '\n';
    return 0;
}
