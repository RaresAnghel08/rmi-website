/**
* user:  kozhuharov-9a5
* fname: Viktor
* lname: Kozhuharov
* task:  restore
* score: 7.0
* date:  2019-10-10 09:13:31.016174
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXM = 1e4 + 7;

array<int, 4> a[MAXM];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n, m;

    cin >> n >> m;

    for(int i = 0; i < m; ++i){
        for(int j = 0; j < 4; ++j){
            cin >> a[i][j];
        }
    }

    for(int i = 0; i < (1 << n); ++i){
        bool is_ans = true;
        for(int j = 0; j < m; ++j){
            int cnt = a[j][3] ? (a[j][1] - a[j][0] + 2 - a[j][2]) : a[j][2];
            bool ok = false;


            for(int k = a[j][0]; k <= a[j][1]; ++k){
                if((bool)(i & (1 << k)) == a[j][3]){
                    --cnt;
                }
                if(cnt <= 0){
                    ok = true;
                    break;
                }
            }
            if(!ok){
                is_ans = false;
                break;
            }
        }

        if(is_ans){
            for(int j = 0; j < n; ++j){
                cout << (bool)(i & (1 << j)) << " ";
            }
            return 0;
        }
    }

    cout << "-1\n";

    return 0;
}
