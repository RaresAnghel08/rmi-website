/**
* user:  melnyk-1f2
* fname: Sofiia
* lname: Melnyk
* task:  devil
* score: 14.0
* date:  2019-10-10 07:54:19.597673
*/
#include<bits/stdc++.h>
using namespace std;

#define mp make_pair
#define ff first
#define ss second
#define pb push_back

const int N = 1e6 + 11;

int d[N];

void up()
{
    int k;
    cin>>k;
    for (int i=1; i<=9; i++)
    {
        cin>>d[i];
    }
    int p=0,pp=0;
    for (int i=9; i>=1; i--)
    {
        if (d[i]>0&&p==0) {p=i; d[i]--;}
        if (d[i]>0&&p!=0) {pp=i; d[i]--; break;}
    }
    int fir=pp;
    int sec=p;
    if (d[fir]>0)
    {
        for (int j=1; j<fir; j++)
            if (d[j]>0) sec=pp;
    }
    d[fir]++;
    for (int sc=1; sc<fir; sc++)
    if (d[sc]>0)
    {
        int k1=0,k2=0,k3=0;
        for (int i=1; i<=9; i++)
            if (i<=sc) k1+=d[i]; else
            if (i<fir) k2+=d[i]; else k3+=d[i];
        if (k1+k2==0) continue;
        if (k1<k3) continue;
        sec=sc;
        break;
    }
    if (sec==p)
    {
        for (int i=1; i<=9; i++)
        {
            while (d[i]>0) {cout<<i; d[i]--;}
        }
        cout<<sec<<endl;
        return;
    }
    if (sec==fir)
    {
        int ts=0;
        for (int i=1; i<fir; i++)
        if (d[i]>0) {ts=i; break;}
        d[ts]--;
        for (int i=1; i<=9; i++)
        {
            while (d[i]>0) {cout<<i; d[i]--;}
        }
        cout<<ts;
        cout<<p<<endl;
        return;
    }
    int maxx=p,mn;
    for (int i=9; i>=1; i--)
        if (d[i]>0&&i<fir) {d[i]--; mn=i; break;}
    while (d[fir]>0)
    {
        cout<<fir;
        d[fir]--;
        for (int i=1; i<=sec; i++)
        if (d[i]>0) {d[i]--; cout<<i; break;}
    }
    for (int i=9; i>=1; i--)
    {
        while (d[i]>0)
        {
            d[i]--;
            cout<<i;
        }
    }
    cout<<mn;
    cout<<maxx<<endl;
}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t;
    cin>>t;
    while (t--)
        up();
}
/**
3
2
1 1 2 0 0 0 0 0 0
7
2 4 2 0 0 6 2 2 2
7
3 3 3 0 0 6 2 2 2


**/
