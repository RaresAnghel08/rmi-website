/**
* user:  danailov-cda
* fname: Daniel
* lname: Danailov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:01:52.106125
*/
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long Int;

const int N=15;
const int S=(1e6)+5;

int k;
vector <int> v;
int d[N],a[S],b[N],od[N];

int main()
{

ios::sync_with_stdio(false);
cin.tie(nullptr);

int tests,i,j,s,mx,cnt,pos,mx2;

cin>>tests;

 while(tests--)
 {
  cin>>k;

  s=0;
   for(i=1;i<=9;i++)
   {
    cin>>d[i];
    od[i]=d[i];
    s+=d[i];

     if(d[i]!=0)
      mx=i;
   }

   for(i=1;i<=s;i++)
    a[i]=0;

  cnt=d[mx];
  pos=s;
   for(i=1;i<=cnt;i++)
   {
     if(pos<1)
      break;

    a[pos]=mx;
    d[mx]--;
    pos-=2;
   }

  v.clear();
   for(i=1;i<=9;i++)
    for(j=1;j<=d[i];j++)
     v.push_back(i);

   if(a[1]==0)
   {
    a[1]=v.back();
    v.pop_back();
   }
   else
   {
    a[2]=v.back();
    v.pop_back();
   }

  pos=1;
   for(i=0;i<v.size();i++)
   {
     while(a[pos]!=0)
      pos++;

    a[pos]=v[i];
    pos++;
   }

   /*for(i=1;i<=s;i++)
    cout<<a[i];

  cout<<"\n";*/

  s=0;
   for(i=1;i<=9;i++)
   {
    d[i]=od[i];
    s+=d[i];

     if(d[i]!=0)
      mx=i;
   }

   for(i=1;i<=s;i++)
    b[i]=0;

  cnt=d[mx];
  pos=s;
   for(i=1;i<=cnt;i++)
   {
     if(pos<1)
      break;

    b[pos]=mx;
    d[mx]--;
    pos-=2;
   }

  v.clear();
   for(i=1;i<=9;i++)
    for(j=1;j<=d[i];j++)
     v.push_back(i);

  pos=s;
   for(i=0;i<v.size();i++)
   {
     while(b[pos]!=0)
      pos--;

    b[pos]=v[i];
    pos--;
   }

  mx=-1;
   for(i=1;i<s;i++)
    mx=max(mx,a[i]*10+a[i+1]);

  mx2=-1;
   for(i=1;i<s;i++)
    mx2=max(mx2,b[i]*10+b[i+1]);

   if(mx<mx2)
   {
    for(i=1;i<=s;i++)
     cout<<a[i];
   }
   else
   {
    for(i=1;i<=s;i++)
     cout<<b[i];
   }

  cout<<endl;
 }

return 0;
}
