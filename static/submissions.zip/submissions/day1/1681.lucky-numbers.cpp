/**
* user:  savkin-047
* fname: Semen
* lname: Savkin
* task:  lucky
* score: 0.0
* date:  2019-10-10 07:29:56.406532
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <algorithm>
#include <queue>
#include <deque>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <string>
#include <cstring>
#include <numeric>
#include <cassert>
#include <cmath>
#include <random>
#define ll long long
#define ld long double
#define null NULL
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()

using namespace std;

template<class iterator> void output(iterator begin, iterator end, ostream &out = cerr) {
	while (begin != end) {
		out << (*begin) << " ";
		begin++;
	}
	out << endl;
}

template<class T> void output(const T &x, ostream &out = cerr) {
	output(x.begin(), x.end(), out);
}

template<class T> int chkmin(T &a, const T &b) {
	if (b < a) {
		a = b;
		return 1;
	}
	return 0;
}

template<class T> int chkmax(T &a, const T &b) {
	if (b > a) {
		a = b;
		return 1;
	}
	return 0;
}

void fast_io() {
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
}

typedef vector<vector<ll> > matrix;

const ll MOD = 1e9 + 7;

matrix operator * (const matrix &a, const matrix &b) {
	int n = a.size();
	matrix c(n, vector<ll> (n));
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			for (int k = 0; k < n; ++k) {
				c[i][j] = (c[i][j] + a[i][k] * b[k][j]) % MOD;
			}
		}
	}
	return c;
}

vector<matrix> mt;

void init(int n) {
	mt.resize(n + 1, matrix(2, vector<ll> (2)));
	mt[0][0][0] = 1;
	mt[0][1][1] = 1;
	matrix upd = {
		{0, 1},
		{MOD - 1, 10}
	};
	for (int i = 1; i <= n; ++i) {
		mt[i] = mt[i - 1] * upd;
		//cerr << mt[i][0][0] << " " << mt[i][0][1] << " " << mt[i][1][0] << " " << mt[i][1][1] << endl;
	}
}

struct node {
	ll val0, val1;
	int len;
	node(ll _val0, ll _val1, int _len): val0(_val0), val1(_val1), len(_len) {}
	node(ll _val0, ll _val1): val0(_val0), val1(_val1), len(1) {}
	node(): val0(0), val1(0), len(0) {}
};

node merge(const node &a, const node &b) {
	ll new_val0 = (a.val0 + mt[a.len][0][0] * b.val0 + mt[a.len][0][1] * b.val1) % MOD;
	ll new_val1 = (a.val1 + mt[a.len][1][0] * b.val0 + mt[a.len][1][1] * b.val1) % MOD;
	return node(new_val0, new_val1, a.len + b.len);
}

struct st {
	vector<node> t;
	ll basis;
	int n;

	void build(vector<ll> &a, int v, int tl, int tr) {
		if (tl == tr) {
			t[v] = node(a[tl], (a[tl] * basis) % MOD);
		} else {
			int tm = (tl + tr) >> 1;
			build(a, v * 2, tl, tm);
			build(a, v * 2 + 1, tm + 1, tr);
			t[v] = merge(t[v * 2], t[v * 2 + 1]);
		}
		//cerr << "t " << v << " " << tl << ".." << tr << " = " << t[v].len << " " << t[v].val0 << " " << t[v].val1 << endl;
	}

	void build(vector<ll> &a, ll _basis) {
		n = a.size();
		basis = _basis;
		t.resize(4 * n);

		//cerr << "build " << basis << endl;
		//output(all(a));

		build(a, 1, 0, n - 1);
	}

	void update(int pos, ll val, int v, int tl, int tr) {
		if (tl == tr) {
			t[v] = node(val, (val * basis) % MOD);
		} else {
			int tm = (tl + tr) >> 1;
			if (pos <= tm) {
				update(pos, val, v * 2, tl, tm);
			} else {
				update(pos, val, v * 2 + 1, tm + 1, tr);
			}
			t[v] = merge(t[v * 2], t[v * 2 + 1]);
		}
	}

	void update(int pos, ll val) {
		update(pos, val, 1, 0, n - 1);
	}

	node get(int l, int r, int v, int tl, int tr) {
		//cerr << "get " << l << " " << r << " " << v << " " << tl << " " << tr << endl;
		if (l > r) {
			return node();
		}
		if (l == tl && r == tr) {
			return t[v];
		}
		int tm = (tl + tr) >> 1;
		node res_l = get(l, min(r, tm), v * 2, tl, tm);
		node res_r = get(max(l, tm + 1), r, v * 2 + 1, tm + 1, tr);
		return merge(res_l, res_r);
	}

	ll get(int l, int r) {
		node res = get(l, r, 1, 0, n - 1);
		return res.val0;
	}
};

vector<ll> a;
set<int> badpos;

int n, q;
st t1, t2;

ll get(int l, int r) {
	ll ans = (t1.get(l, r) + t2.get(l, r)) % MOD;
	auto it = badpos.lower_bound(l);
	if (it == badpos.end() || (*it) >= r) {
		ans = (ans + 1) % MOD;
	}
	return ans;
}

void check(int pos) {
	if (a[pos] == 1 && a[pos + 1] == 3) {
		badpos.insert(pos);
	}
}

int digval(int d) {
	if (d == 0) {
		return 0;
	}
	if (d == 1) {
		return 1;
	}
	return d - 1;
}

signed main() {
	fast_io();
	cin >> n >> q;
	init(n);
	vector<ll> cur(n), cur1(n);
	for (int i = 0; i < n; ++i) {
		char ch;
		cin >> ch;
		cur[n - 1 - i] = ch - '0';
	}
	a = cur;
	for (int i = 0; i < n - 1; ++i) {
		if (a[i] == 1 && a[i + 1] == 3) {
			check(i);
		}
	}
	for (int i = 0; i < n; ++i) {
		cur1[i] = (cur[i] > 1);
	}
	for (int i = 0; i < n; ++i) {
		cur[i] = digval(cur[i]);
	}
	t1.build(cur, 10);
	t2.build(cur1, 9);
	//cerr << "huh" << endl;

	ll kek = get(0, n - 1);
	cout << kek << endl;

	for (int i = 0; i < q; ++i) {
		//cerr << "query " << i << endl;
		int type;
		cin >> type;
		if (type == 2) {
			int pos;
			ll val;
			cin >> pos >> val;
			pos = n - pos;
			t2.update(pos, (ll)(val > 0));
			t1.update(pos, digval(val));
			a[pos] = val;
			if (pos < n - 1) {
				badpos.erase(pos);
				check(pos);
			}
			if (pos) {
				badpos.erase(pos - 1);
				check(pos - 1);
			}
		} else {
			int l, r;
			cin >> l >> r;
			l = n - l;
			r = n - r;
			swap(l, r);
			ll ans = get(l, r);
			cout << ans << "\n";
		}
	}
}
