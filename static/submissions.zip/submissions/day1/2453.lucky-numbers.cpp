/**
* user:  wald-f11
* fname: Almog
* lname: Wald
* task:  lucky
* score: 100.0
* date:  2019-10-10 09:17:56.192361
*/
//============================================================================
// Name        : addition.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
#include <math.h>
#include <vector>
#include <set>
#include <map>
#include <utility>
//#include "euclid.h"
typedef long long lol;
#define into(b) cin >> b;
#define deft(a,b) a b; into(b);
#define def(b) deft(lol,b)
#define co cout <<
#define el << endl;
#define ell << '\n';
#define ld long double
#define forr(i,a,b,c) for(int i=a;i<b;i+=c)
#define fort(i,a,b) forr(i,a,b,1)
#define fortb(i,a,b) for(int i=b-1;i>=a;i--)
#define forn(i,b) fort(i,1,b)
#define fornb(i,b) fortb(i,1,b)
#define fori(i,b) fort(i,0,b)
#define forib(i,b) fortb(i,0,b)
#define maxi 1000000007
#define mod %maxi
#define con continue;
#define br break;
#define wne(arr) while(!arr.empty())
using namespace std;
typedef vector<int> veci;
typedef vector<lol> vecl;
typedef pair<lol,lol> point;
typedef vector<point> vecp;
typedef pair<point,lol> poin;
typedef vector<poin> vecpp;
lol tri(lol a){
	return (a*(a+1))/2;
}
lol modinverse(lol a,lol m){
	lol x=1;
	lol y=0, b=m;
	while(a!=1){
		lol num=b/a;
		b-=num*a;
		y-=num*x;
		swap(a,b);
		swap(x,y);
	}
	x= x%m;
	if(x<0){
		x+=m;
	}
	return x;
}
vector<vecl> a(10);
void out(string x){
	int n=x.size();
	lol sum=a[x[0]-'0'][n-1]+1;
	forib(i,n-1){
		sum= (sum+a[x[n-1-i]-'0'][i])mod;
		if(x[n-i-2]=='1'){
			if(x[n-i-1]=='3'){
				sum= (sum-1+maxi)mod;
				br

			}
			if(x[n-i-1]>'3'){
				sum= (sum-a[4][i]+a[3][i]+maxi)mod;
			}
		}
	}
	co sum el
}
int main() {
	ios::sync_with_stdio(false);
	def(n) def(m)

	fori(i,10){
		a[i].resize(n);
		a[i][0]=i;
	}
	forn(j,n){
		lol sum=a[9][j-1]+a[1][j-1];
		a[1][j]=sum;
		a[2][j]=(maxi+a[1][j]+sum-a[4][j-1]+a[3][j-1])mod;
		fort(i,3,10){
			a[i][j]=(a[i-1][j]+sum)mod;
		}
	}
	deft(string,line)
	out(line);
	fori(i,m){
		def(x)
			def(l) def(r)
			l--;
		if(x==2){
			line[l]=r+'0';
		}
		if(x==1){
			out(line.substr(l,r-l));
		}
	}
	return 0;
}
