/**
* user:  koynov-034
* fname: Daniel
* lname: Koynov
* task:  devil
* score: 14.0
* date:  2019-10-10 06:07:50.719711
*/
#include<bits/stdc++.h>

using namespace std;
typedef long long ll;

int d[10];
int main()
{
    ios_base::sync_with_stdio();
    cin.tie();
    cout.tie();

    int t;
    cin >> t;
    int i, j, k;
    for (i = 0; i < t; i ++)
    {
        cin >> k;
        for (j = 1; j < 10; j ++)
            cin >> d[j];

        int l = 1, r = 9;
        stack < char > c;
        while(l <= r)
        {
            while(r > 0 && d[r] == 0)
                r --;
            if (r > 0 && l <= r)
            {
                c.push(r + '0');
                d[r] --;
            }

            while(l < 10 && d[l] == 0)
                l ++;
            if (l < 10 && l <= r)
            {
                c.push(l + '0');
                d[l] --;
            }

        }
        while(!c.empty())
        {
            cout << c.top();
            c.pop();
        }
        cout << endl;
    }
    return 0;
}
