/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  lucky
* score: 14.0
* date:  2019-10-10 09:14:49.274750
*/
#include<bits/stdc++.h>
#pragma GCC optimize ("O3")
#pragma OGIoptimization
using namespace std;
#define ll long long
string x;
ll MOD=1e9+7;
ll ans;
bool ok(string s1,string s2,long long t)
{
	for(int i=s2.size()-1;i>=0;--i)
	{
		if(s2[i]=='o')
		{
			s2[i]=t%10+'0';
			t/=10;
		}
	}
	if(s1>s2)return 1;
	return 0;
}
ll pow1[20];
void gen(int i,int count,string s)
{
	if(i==x.size())
	{
		ll mid,ans1=0,l1=0,r1=pow1[x.size()-count*2]-1;
		while(l1<=r1)
		{
			mid=(l1+r1)/2;
			if(ok(x,s,mid))
			{
				ans1=mid;l1=mid+1ll;
			}
			else r1=mid-1ll;
		}
		ans1++;ans1%=MOD;
		if(count%2==1){ans+=ans1;ans%=MOD;}
		else {ans-=ans1;if(ans<0)ans+=MOD;}
		return;
	}
	gen(i+1,count,s+"o");
	if(i+2<=x.size())gen(i+2,count+1,s+"13");
}
int main()
{
	pow1[0]=1;
	for(int i=1;i<19;++i)
	{
		pow1[i]=pow1[i-1]*10;
	}
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	int n,q;cin>>n>>q;
	cin>>x;
	gen(0,0,"");
	cout<<(-ans+1+3*MOD)%MOD<<"\n";
return 0;
}
