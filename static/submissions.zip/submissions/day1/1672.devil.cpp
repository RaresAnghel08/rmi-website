/**
* user:  musat-50e
* fname: Tiberiu Ioan
* lname: Mușat
* task:  devil
* score: 14.0
* date:  2019-10-10 07:28:02.289803
*/
#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAX_S = 1e5;
int v[MAX_S];
int f[10];

char s[MAX_S + 1];

int main() {
    int t;
    for (cin >> t; t > 0; t--) {
        int k, n = 0;
        cin >> k;
        for (int i = 1; i < 10; i++) {
            cin >> f[i];
            for (int j = 0; j < f[i]; j++)
                v[n++] = i;
        }

        if (k == 2) {
            int ix = 0;
            for (int i = (n - 1) / 2; i >= 0; i--) {
                s[ix++] = '0' + v[i];
                if (i * 2 != n - 1)
                    s[ix++] = '0' + v[n - i - 1];
            }
            s[n] = 0;
            cout << s << '\n';
        } else if (n <= 2) {

            long long ans = 0, ans_val = 1e16;
            do {
                long long x = 0, p10 = 1, mx;
                for (int i = 0; i < k; i++) {
                    x = x * 10 + v[i];
                    p10 *= 10;
                }
                mx = x;
                for (int i = k; i < n; i++) {
                    x = x * 10 + v[i];
                    mx = max(mx, x % p10);
                }
                if (mx < ans_val) {
                    ans = x;
                    ans_val = mx;
                }
            } while (next_permutation(v, v + n));
            cout << ans << '\n';
        } else if (f[1] + f[2] == n) {
            if (f[2] <= k - 1) {
                cout << string(f[1], '1') << string(f[2], '2') << '\n';
                continue;
            }
            f[2] -= k - 1;
            if (f[1] > f[2]) {
                int r = f[1] / f[2];
                int l = f[1] % f[2];
                for (int i = 0; i < f[2]; i++) {
                    cout << '2' << string(r + (i >= f[2] - l), '1');
                }
                cout << string(k - 1, '2') << '\n';
            } else {
                int r = f[2] / f[1];
                int l = f[2] % f[1];
                for (int i = 0; i < f[1]; i++) {
                    cout << string(r + (i < l), '2') << '1';
                }
                cout << string(k - 1, '2') << '\n';
            }
        }
    }

    return 0;
}
