/**
* user:  dimitrov-6bb
* fname: Atanas
* lname: Dimitrov
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:24:23.533977
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
#define endl "\n"
#define sz(x) (int)x.size()

const ll mod = 1e9 + 7;
const int n = 10;

struct Node {
	ll dp[n + 2][n + 2], st, en, l;
	Node(int a) {for(int i = 0; i < n; i ++) for(int j = 0; j < n; j ++) {dp[i][j] = 0;} for(int i = 0; i <= a; i ++) {dp[i][i] = 1;} st = en = a; l = 1;}
	Node() {for(int i = 0; i < n; i ++) for(int j = 0; j < n; j ++) {dp[i][j] = 0;} dp[11][11] = -1;}
	ll ans() {
		ll ret = 0;
		for(int i = 0; i < n; i ++) {
			for(int j = 0; j < n; j ++) {
				ret += dp[i][j];
				if(ret >= mod) {ret -= mod;}
			}
		}
		return ret;
	}
};

const int MAX_N = 1e4 + 10;
ll prec[MAX_N][n][n], dp[n + 2][n + 2], dp2[n + 2][n + 2];

Node merge(Node l, Node r, int ind = -1) {
	if(l.dp[11][11] == -1) {return r;}
	if(r.dp[11][11] == -1) {return l;}
	Node m;
	m.dp[11][11] = 0;
	m.st = l.st; 
	m.en = r.en;
	m.l = l.l + r.l;
	for(int j = 0; j < n; j ++) {
		for(int k = 0; k < n; k ++) {
			if(k == 3 && l.en == 1) {continue;}
			m.dp[m.st][j] += r.dp[k][j];
		}
	}
	ll sum1[n + 2] = {0};
	ll sum2[n + 2] = {0};
	l.dp[l.st][l.en] --;
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < n; j ++) {
			sum1[i] += l.dp[i][j];
			sum2[j] += prec[r.l][i][j];
			if(sum1[i] >= mod) {sum1[i] -= mod;}
			if(sum2[j] >= mod) {sum2[j] -= mod;}
		}
	}
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < n; j ++) {
			m.dp[i][j] += (sum1[i] * sum2[j]) % mod - (l.dp[i][1] * prec[r.l][3][j]) % mod;
			if(m.dp[i][j] < 0) {m.dp[i][j] += mod;}
		}
	}
	l.dp[l.st][l.en] ++;
	return m;
	cout << "In";
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < n; j ++) {
			cout << l.dp[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < n; j ++) {
			cout << r.dp[i][j] << " ";
		}
		cout << endl;
	}

	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < n; j ++) {
			cout << m.dp[i][j] << " ";
		}
		cout << endl;
	}
	cout  << m.ans() << endl;
	return m;
}

char dig[MAX_N];

struct ST {
	Node data[4 * MAX_N + 20];
	void build(int curr, int l, int r) {
		if(l == r) {
			data[curr] = Node(dig[l] - '0');
			return;
		}
		build(curr * 2 + 1, l, (l + r) / 2);
		build(curr * 2 + 2, (l + r) / 2 + 1, r);
		data[curr] = merge(data[curr * 2 + 1], data[curr * 2 + 2]);
	}	
	Node ans(int curr, int l, int r, int ql, int qr) {
		if(ql <= l && r <= qr) {
			return data[curr];
		}
		if(ql > r || qr < l) {
			return Node();
		}
		return merge(ans(curr * 2 + 1, l, (l + r) / 2, ql, qr), ans(curr * 2 + 2, (l + r) / 2 + 1, r, ql, qr));
	}
	
};

ST ans;

int main() {
	//ios_base::sync_with_stdio(false); cin.tie(NULL);
	for(int i = 0; i < n; i ++) {
		prec[1][i][i] = 1;
	}
	for(int i = 0; i < n; i ++) {
		for(int j = 0; j < n; j ++) {
			prec[2][i][j] = 1;
		}
	}
	prec[2][1][3] = 0;
	for(int q = 3; q < MAX_N; q ++) {
		for(int i = 0; i < n; i ++) {
			for(int j = 0; j < n; j ++) {
				dp2[i][j] = 0;
				for(int k = 0; k < n; k ++) {
					prec[q][i][j] += prec[q - 1][i][k] * prec[q - 1][k][j];
					prec[q][i][j] %= mod;
				}				
			}
		}
	}
	int l, q;
	cin >> l >> q;
	Node ret;
	for(int i = 0; i < l; i ++) {
		cin >> dig[i];
	}
	ans.build(0, 0, l - 1);
	ll ret = ans.data[0].ans()) % mod;
	if(ret < 0) {ret += mod;}
	cout << ret;
	while(q --) {
		int t, a, b;
		cin >> t >> a >> b;
		if(t == 1) {
			cout << ans.ans(0, 0, l - 1, a - 1, b - 1).ans() << endl;
		} else {
		}
	}
}	
