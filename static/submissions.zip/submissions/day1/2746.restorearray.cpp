/**
* user:  dimitrov-6bb
* fname: Atanas
* lname: Dimitrov
* task:  restore
* score: 0.0
* date:  2019-10-10 09:54:38.802654
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
#define endl "\n"
#define sz(x) (int)x.size()

const int MAX_N = 210;
int l[MAX_N], r[MAX_N], ord[MAX_N], what[MAX_N];

set<int> st;

int main() {
	int n, m;
	cin >> n >> m;
	for(int i = 0; i < m; i ++) {
		cin >> l[i] >> r[i] >> ord[i] >> what[i];
	}
	for(int mask = 0; mask < (1 << n); mask ++) {
		bool flag = false;
		int i;
		int cnt[3] = {0, 0, 0};
		for(i = 0; i < m; i ++) {
			for(int j = l[i]; j <= r[i]; j ++) {
				cnt[(mask & (1 << j)) ? 1 : 0] ++;
			}
			int mx;
			if(ord[i] <= cnt[0]) {
				mx = 0;
			} else {
				mx = 1;
			}
			if(mx != what[i]) {
				flag = true;
				break;
			}
		}
		if(!flag) {
			cout << cnt[0] << " " << i << endl;
			for(int i = 0; i < n; i ++) {
				cout << (bool)(mask & (1 << i)) << " ";
			};
			return 0;
		}
	}
	cout << -1;
}
