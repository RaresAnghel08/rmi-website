/**
* user:  smilenov-5e5
* fname: Ivan
* lname: Smilenov
* task:  devil
* score: 0.0
* date:  2019-10-10 07:56:46.177982
*/
#include<bits/stdc++.h>
#define MAXN 131072
using namespace std;
int a[16],arr[MAXN];
vector<int>v;
vector<int>ans;
int main()
{
    int t,k,i,l,r,sz,j;
    cin>>t;
    while(t--)
    {
        cin>>k;
        for(i=1;i<=9;i++)
        {
            cin>>a[i];
            for(j=0;j<a[i];j++){arr[sz++]=i;}
        }
        sort(a,a+sz);
        ans.resize(sz);
        l=0;r=sz/2;
        while(l+r!=sz)
        {
            if(l<sz/2){cout<<arr[l];
            l++;}
            if(r!=sz-1){cout<<arr[r];
            r++;}
        }
        cout<<endl;
    }
    return 0;
}
