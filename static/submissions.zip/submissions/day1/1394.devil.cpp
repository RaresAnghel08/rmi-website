/**
* user:  karimov-095
* fname: Renat
* lname: Karimov
* task:  devil
* score: 0.0
* date:  2019-10-10 06:35:46.451273
*/
#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define ld long double
#define ll long long

ll sum = 0, mn = 1e18;
int k;
string s1 = "";

void check(vector<int> v1, int now = 0, string s = ""){
    if (now == sum){
        ll mx = 0;
        for (int i = 0; i < s.size() - k + 1; i++){
            ll sm = 0;
            for (int j = i; j < k + i; j++){
                sm *= 10;
                sm += s[j] - '0';
            }
            mx = max(mx, sm);
        }
        if (mx < mn){
            s1 = s;
            mn = mx;
        }
    }
    for (int i = 1; i <= 4; i++){
        if (v1[i] != 0){
            v1[i]--;
            check(v1, now + 1, s + (char)(i + '0'));
            v1[i]++;
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    //cin.tie(0);
    //cout.tie(0);
    int n;
    cin >> n;
    while(n-- != 0){
        bool x = 0;
        cin >> k;
        vector<int> v(10);
        for (int i = 1; i <= 9; i++){
            cin >> v[i];
            if (v[i] > 0 && i > 4){
                x = 1;
            }
        }
        if (!x && v[1] + v[2] + v[3] + v[4] <= 12){
            sum = v[1] + v[2] + v[3] + v[4];
            check(v);
            cout << s1 << "\n";
        }
    }
}
