/**
* user:  popescu-96c
* fname: Ioan
* lname: Popescu
* task:  restore
* score: 13.0
* date:  2019-10-10 09:51:16.294067
*/
/**
    Hotiiiiiiiii
**/

#include <bits/stdc++.h>
using namespace std;

int n, m;
struct interv{
    int l, r, k, pot;

    bool operator < (const interv &aux)const{
        if(l != aux.l) return l < aux.l;
        return r < aux.r;
    }
};

struct usu{
    int pot, r;
    bool operator < (const usu &aux)const{
        return pot > aux.pot;
    }
};

interv a1[10005], a0[10005];

priority_queue <usu> pq0, pq1;

bool f0[10005], f1[10005];
int d0[10005], d1[10005];
int s[10005];


int main()
{
//    freopen("1.in", "r", stdin);
    scanf("%d%d", &n, &m);

    for(int i = 1; i <= n ; ++i) s[i] = -1;

    int l, r, k, v, n1 = 0, n0 = 0;
    for(int i = 1; i <= m ; ++i){
        scanf("%d%d%d%d", &l, &r, &k, &v);
        ++l; ++r;
        if(v == 1) a1[++n1] = {l, r, (r - l  + 1) - k + 1};
        else a0[++n0] = {l, r, k};
    }

    sort(a0 + 1, a0 + n0 + 1);
    sort(a1 + 1, a1 + n1 + 1);

    bool ok = true;
    do{
        ok = false;
        for(int i = 1; i <= n0 ; ++i){
            if(f0[i]) continue ;

            int n0 = 0, lib = 0;
            for(int j = a0[i].l; j <= a0[i].r ; ++j){
                if(s[j] == -1) ++lib;
                else if(s[j] == 0) ++n0;
            }

            if(a0[i].k - n0 > lib) {printf("-1\n"); return 0;}

            if(a0[i].k - n0 == lib){
                f0[i] = true;
                ok = true;
                for(int j = a0[i].l; j <= a0[i].r ; ++j)
                    s[j] = 0;
            }
        }
        for(int i = 1; i <= n1 ; ++i){
            if(f1[i]) continue ;

            int n1 = 0, lib = 0;
            for(int j = a1[i].l; j <= a1[i].r ; ++j){
                if(s[j] == -1) ++lib;
                else if(s[j] == 1) ++n1;
            }

            if(a1[i].k - n1 > lib) {printf("-1\n"); return 0;}

            if(a1[i].k - n1 == lib){
                f1[i] = true;
                ok = true;
                for(int j = a1[i].l; j <= a1[i].r ; ++j)
                    s[j] = 1;
            }
        }
    }while(ok);

    for(int i = 1; i <= n0 ; ++i){
        if(f0[i]) continue ;

        int n0 = 0, lib = 0;
        for(int j = a0[i].l; j <= a0[i].r ; ++j){
            if(s[j] == -1) ++lib;
            else if(s[j] == 0) ++n0;
        }

        a0[i].k -= n0;
        a0[i].pot = lib - a0[i].k;
    }
    for(int i = 1; i <= n1 ; ++i){
        if(f1[i]) continue ;

        int n1 = 0, lib = 0;
        for(int j = a1[i].l; j <= a1[i].r ; ++j){
            if(s[j] == -1) ++lib;
            else if(s[j] == 1) ++n1;
        }

        a1[i].k -= n1;
        a1[i].pot = lib - a0[i].k;
    }

    int i0 = 1, i1 = 1, sc1 = 0, sc0 = 0;
    for(int i = 1; i <= n ; ++i){
        if(s[i] != - 1) continue ;

        while(i0 <= n0 && a0[i0].l <= i){
            pq0.push({a0[i0].pot + sc1, a0[i0].r});
            ++i0;
        }
        while(i1 <= n1 && a0[i1].l <= i){
            pq1.push({a0[i1].pot + sc0, a0[i1].r});
            ++i1;
        }

        while(!pq0.empty() && pq0.top().r < i) pq0.pop();
        while(!pq1.empty() && pq1.top().r < i) pq1.pop();

        int p1 = 1e9, p2 = 1e9;

        if(pq0.empty() && pq1.empty()) {s[i] = 0; continue ;}

        if(pq0.empty()) s[i] = 1, ++sc1;
        else if(pq1.empty()) s[i] = 0, ++sc0;
        else if(pq0.top().pot < pq1.top().pot) s[i] = 0, ++sc0;
        else s[i] = 1, ++sc1;

        if(!pq0.empty() && pq0.top().pot - sc1 < 0) {printf("-1\n"); return 0;}
        if(!pq1.empty() && pq1.top().pot - sc0 < 0) {printf("-1\n"); return 0;}
    }

    for(int i = 1; i <= n ; ++i) printf("%d ", s[i]);

    return 0;
}

























