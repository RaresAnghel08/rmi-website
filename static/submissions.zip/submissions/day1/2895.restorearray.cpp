/**
* user:  cercelescu-278
* fname: Șerban Ion
* lname: Cercelescu
* task:  restore
* score: 0.0
* date:  2019-10-10 10:11:43.007608
*/
// Gott mit uns!
#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;

using i64 = long long;
using pii = pair<int, int>;

#ifdef HOME
const int N = 1005, Q = 1005, MOD = 1e9 + 7, S = 3; 
#else
const int N = 1e5 + 5, Q = 1e4 + 5, MOD = 1e9 + 7, S = 3;
#endif

struct State {
	int eq[S][S], sm[S][S];
	int len;

	State(int a = 0, int b = -1) {
		len = b - a + 1;
		for (int i = 0; i < S; ++i)
		for (int j = 0; j < S; ++j)
			eq[i][j] = sm[i][j] = 0; } };


State pom[N * 4];
int any[N][S][S];
char str[N];

int n, q, ql, qr, qpos;
char qval;

static inline int mul(const int &a, const int &b) {
	return 1LL * a * b % MOD; }

static inline int add(const int &a, const int &b) {
	return (a + b >= MOD ? a + b - MOD : a + b); }

static inline int cod(const char &ch) {
	switch (ch) {
	case '3': return 2;
	case '1': return 1;
	default: return 0; } }

static State join(const State &a, const State &b) {
	State res;

	res.len = a.len + b.len;

	for (int l = 0; l < S; ++l)
	for (int r = 0; r < S; ++r)
	for (int u = 0; u < S; ++u)
	for (int v = 0; v < S; ++v)
		res.eq[l][r]+= (u != 1 || v != 2) * mul(a.eq[l][u], b.eq[v][r]);

	for (int l = 0; l < S; ++l)
	for (int r = 0; r < S; ++r) {
		// left conjoined
		for (int u = 0; u < S; ++u)
		for (int v = 0; v < S; ++v)
			res.sm[l][r] = add(res.sm[l][r], (u != 1 || v != 2) * mul(a.eq[l][u], b.sm[v][r]));

		// not conjoined
		for (int u = 0; u < S; ++u)
		for (int v = 0; v < S; ++v)
			res.sm[l][r] = add(res.sm[l][r], (u != 1 || v != 2) * mul(a.sm[l][u], any[b.len][v][r])); }

	return res; }


static void build(int nod, int st, int dr) {
	if (st == dr) {
		pom[nod].len = dr - st + 1;
		pom[nod].eq[cod(str[st])][cod(str[dr])] = 1;
		for (int ch = '0'; ch < str[st]; ++ch)
			pom[nod].sm[cod(ch)][cod(ch)]+= 1;
		return; }
	int mid = (st + dr) / 2;
	build(2 * nod, st, mid);
	build(2 * nod + 1, mid + 1, dr);
	pom[nod] = join(pom[2 * nod], pom[2 * nod + 1]); }


static void precalc() {
	any[1][0][0] = 8;
	any[1][1][1] = 1;
	any[1][2][2] = 1;
	for (int i = 2; i < N; ++i)
	for (int fst = 0; fst < S; ++fst) {
		any[i][fst][0] = add(any[i][fst][0], mul(any[i - 1][fst][0], 8));
		any[i][fst][0] = add(any[i][fst][0], mul(any[i - 1][fst][1], 8));
		any[i][fst][0] = add(any[i][fst][0], mul(any[i - 1][fst][2], 8));

		any[i][fst][1] = add(any[i][fst][1], any[i - 1][fst][0]);
		any[i][fst][1] = add(any[i][fst][1], any[i - 1][fst][1]);
		any[i][fst][1] = add(any[i][fst][1], any[i - 1][fst][2]);

		any[i][fst][2] = add(any[i][fst][2], any[i - 1][fst][0]);
		any[i][fst][2] = add(any[i][fst][2], any[i - 1][fst][2]); } }

static State query(int nod, int st, int dr) {
	if (ql <= st && dr <= qr)
		return pom[nod];
	int mid = (st + dr) / 2;

	if (ql <= mid && mid < qr)
		return join(query(2 * nod, st, mid), query(2 * nod + 1, mid + 1, dr));
	else if (ql <= mid)
		return query(2 * nod, st, mid);
	else
		return query(2 * nod + 1, mid + 1, dr); }

static void update(int nod, int st, int dr) {
	if (st == dr) {
		str[qpos] = qval;
		pom[nod] = State(st, dr);
		pom[nod].eq[cod(str[st])][cod(str[dr])] = 1;
		for (int ch = '0'; ch < str[st]; ++ch)
			pom[nod].sm[cod(ch)][cod(ch)]+= 1;
		return; }

	int mid = (st + dr) / 2;
	if (qpos <= mid)
		update(2 * nod, st, mid);
	else
		update(2 * nod + 1, mid + 1, dr);
	pom[nod] = join(pom[2 * nod], pom[2 * nod + 1]); }

static inline int eval(const State &s) {
	int ant = 0;
	for (int i = 0; i < S; ++i)
	for (int j = 0; j < S; ++j) {
		ant = add(ant, s.eq[i][j]);
		ant = add(ant, s.sm[i][j]); }
	return ant; }


int main() {
#ifdef HOME
	freopen("lucky.in", "r", stdin);
	freopen("lucky.out", "w", stdout);
#endif
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	precalc();

	cin >> n >> q >> (str + 1);
	build(1, 1, n);
	cout << eval(pom[1]) << '\n';
	while (q--) {
		int op;
		cin >> op;
		switch (op) {
		case 1: { // query
			cin >> ql >> qr;
			cout << eval(query(1, 1, n)) << '\n';
			break; }

		case 2: { // update
			cin >> qpos >> qval;
			update(1, 1, n);
			break; } } }

	return 0; }

