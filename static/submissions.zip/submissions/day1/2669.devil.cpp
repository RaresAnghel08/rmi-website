/**
* user:  koynov-034
* fname: Daniel
* lname: Koynov
* task:  devil
* score: 0.0
* date:  2019-10-10 09:46:14.758935
*/
#include<bits/stdc++.h>

using namespace std;
typedef long long ll;


int main()
{
    int t, one, two, i, gar;
    cin >> t;
    for (i = 0; i < t; i ++)
    {
        cin >> gar;
        cin >> one >> two >> gar >> gar >> gar >> gar >> gar >> gar >> gar;
        if (one > two)
        {
            int sum = one + two;
            int d = one / two;
            int p = sum % two, j;
            sum = sum - p;
            int k, cnt = 0;
            for (j = 0; j < sum / (d + 1); j ++)
            {
                if (cnt < p)
                {
                    cout << "1";
                    cnt ++;
                }
                for (k = 0; k < d; k ++)
                    cout << "1";
                cout << "2";
            }
            cout << endl;
        }
        else
        {
            int sum = one  + two;
            int d = two / one;
            int p = sum % one;
            sum = sum - p;

            int k, cnt = 0, j;
            for (j = 0; j < sum / d; j ++)
            {

                cout << "1";
                for (k = 0; k < d; k ++)
                    cout << "2";
                if (cnt < p)
                {
                    cout << "2";
                    cnt ++;
                }

            }
            cout << endl;
        }
    }
    return 0;
}
