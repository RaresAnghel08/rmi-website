/**
* user:  moldovan-92d
* fname: Andrei
* lname: Moldovan
* task:  restore
* score: 13.0
* date:  2019-10-10 09:31:33.157518
*/
#include <bits/stdc++.h>
using namespace std;
int v[5005];
struct dd
{
    int l,r,k,val;
};
struct ap
{
    int l,r;
};
dd t[10005];
int mars[10005];
int sp[10005];
int main()
{
    //freopen("a.in","r",stdin);
    int n,m,i,j;
    int cnt=0;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>t[i].l>>t[i].r>>t[i].k>>t[i].val;
        t[i].l++;
        t[i].r++;
        if(t[i].k==1&&t[i].val==1)
        {
            mars[t[i].l]++;
            mars[t[i].r+1]--;
        }
    }
        if(n<=18)
    {
        int ns=1<<n;
        int tot=0;
        for(int i=0;i<ns;++i)
        {
            fill(v+1,v+n+1,0);
            fill(sp+1,sp+n+1,0);
            for(j=0;j<n;j++)
                {{if(i&(1<<j))
                v[j]=1;sp[j+1]=sp[j]+v[j];}
                int ok=0;
            for(int t1=1;t1<=m;t1++)
            {
                int k=t[t1].k;
                int val1=t[t1].r-t[t1].l+1;
                int sp1=sp[t[t1].r]-sp[t[t1].l-1];
                if(t[t1].val==0)
                    if(sp1>(val1-k))
                {
                    ok=1;
                    break;
                }
                if(t[t1].val==1)
                    if(sp1<(val1-k+1))
                {
                    ok=1;
                    break;
                }
            }
            if(ok==0)
            {
                for(i=0;i<n;i++)
                    cout<<v[i]<<" ";
                cout<<"\n";
                tot=1;
                return 0;
            }
        }
    }
    if(tot==0)
    {
        printf("-1");
        return 0;
    }
    }

    int sum=0;
    for(i=1;i<=n;i++)
    {
        sum+=mars[i];
        if(sum>0)v[i]=1;
        sp[i]=sp[i-1]+v[i];
    }
    for(i=1;i<=m;i++)
    {
        if(t[i].val==0)
        {
            int sp1=sp[t[i].r]-sp[t[i].l-1];
            if(sp1==(t[i].r-t[i].l+1))
            {
                printf("-1");
                return 0;
            }
        }
    }
    for(i=1;i<=n;i++)
        cout<<v[i]<<" ";
    return 0;
}
