/**
* user:  radoslavov-f96
* fname: Aleksandar
* lname: Radoslavov
* task:  lucky
* score: 28.0
* date:  2019-10-10 10:24:34.982256
*/
#include<iostream>
using namespace std;
string s;
long long n, q;
const long long maxn = 100100;
long long ok[maxn], with3[maxn];
const long long mod = 1000000007;
long long ans(string &s, int from, int to)
{
    long long ans = 1;
    bool no13 = true;
    for(long long i = from; i < to && no13; i ++)
    {
        long long c = s[i] - '0';
        bool is1 = (c >= 1);
        bool is3 = (c >= 3);
        long long l = to - i - 1;
        ans += (ok[l] - with3[l]) * (is1);
        ans += ok[l] * (c - is1);
        ans %= mod;
        //cout << ">" << ans << endl;
        if(i > 0 && s[i] == '3' && s[i - 1] == '1')
        {
            no13 = false;
        }
    }
    ans %= mod;
    if(ans < 0) ans += mod;
    ans %= mod;
    return ans;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    ok[0] = 1;
    with3[0] = 0;
    cin >> n >> q;
    for(long long i = 1; i <= n; i ++)
    {
        ok[i] = ok[i - 1] * 9 + (ok[i - 1] - with3[i - 1]);
        ok[i] %= mod;
        with3[i] = ok[i - 1];
        //cout << "ok " << ok[i] << endl;
    }
    cin >> s;
    cout << ans(s, 0, n) << "\n";
    for(int i = 0; i < q; i ++)
    {
        int t;
        cin >> t;
        if(t == 1)
        {
            int l, r;
            cin >> l >> r;
            cout << ans(s, l - 1, r) << "\n";
        } else {
            int x, val;
            cin >> x >> val;
            s[x - 1] = val + '0';
        }
    }
}
/**
6 0
560484
*/
/**
6 10
560484
2 6 4
2 1 4
2 5 6
2 6 1
2 3 6
1 3 6
1 1 3
1 6 6
1 2 6
2 1 7
*/
