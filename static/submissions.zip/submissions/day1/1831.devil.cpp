/**
* user:  metehau-fd8
* fname: Luca
* lname: Metehău
* task:  devil
* score: 0.0
* date:  2019-10-10 07:54:25.118636
*/
#include <iostream>
#include <cstring>

using namespace std;

// eventual fac bruturi aici

int t, n, m, k;

int f[10], cnt[5];

string S[5][5][5][5][20], sol[5][5][5][5][20], ans;

string getMx(string s, int k, int m) {
  string mx = "", tmp;
  tmp.clear();
  if(s.size() < k)
    return mx;
  for(int i = 0; i < k; i++)
    tmp += s[i];
  mx = tmp;
    // cout << ans << "|\n";
  for(int i = k; i < m; i++) {
    tmp += s[i];
    tmp.erase(tmp.begin());
      // cout << tmp << "\n";
    if(tmp > mx) {
      mx = tmp;
    }
  }
  return mx;
}

void bkt(int niv) {
  // cout << ans << "\n";
  for(int k = 1; k <= cnt[1] + cnt[2] + cnt[3] + cnt[4]; k++) {
    if(sol[cnt[1]][cnt[2]][cnt[3]][cnt[4]][k] == "" || getMx(ans, k, ans.size()) < sol[cnt[1]][cnt[2]][cnt[3]][cnt[4]][k])
      S[cnt[1]][cnt[2]][cnt[3]][cnt[4]][k] = ans, sol[cnt[1]][cnt[2]][cnt[3]][cnt[4]][k] = getMx(ans, k, ans.size());
  }
  for(int i = 1; i <= 4; i++) {
    if(cnt[i] < 3) {
      ans += i + '0';
      cnt[i]++;
      bkt(niv + 1);
      cnt[i]--;
      ans.pop_back();
    }
  }
}

int main() {
  cin >> t;
  bkt(1);
  for(; t; t--) {
    cin >> k;
    m = 0;
    for(int i = 1; i <= 9; i++)
      cin >> f[i], m += f[i];
    if(m == f[1] + f[2] + f[3] + f[4] && k != 2) {
      cout << S[f[1]][f[2]][f[3]][f[4]][k] << "\n";
      continue;
    }
    if(k == 2) {
      int c, x = 0;
      for(int i = 9; i >= 1; i--) {
        if(f[i]) {
          c = i;
          f[i]--;
          break;
        }
      }
      x = c;
      while(!f[c] && c)
        c--;
      int sum = 0, ok = 0;
      for(int i = 1; i < c; i++) {
        if(f[i]) {
          sum += f[i];
          if(sum >= f[c]) {
            sum = f[c];
            for(int j = 1; j < i; j++) {
              if(f[j]) {
                for(int k = 1; k <= f[j]; k++)
                  cout << c << j;
                sum -= f[j];
                f[j] = 0;
              }
            }
            for(int j = 1; j <= sum; j++)
              cout << c << i;
            f[i] -= sum;
            for(int j = i; j < c; j++) {
              if(f[j]) {
                for(int k = 1; k <= f[j]; k++)
                  cout << j;
              }
            }
            cout << x << "\n";
            ok = 1;
            break;
          }
        }
      }
      if(!ok) {
        for(int i = 1; i <= 9; i++) {
          for(int j = 1; j <= f[i]; j++)
            cout << i;
        }
        cout << x;
        cout << "\n";
      }
    }
    /*if(f[2] < k) {
      for(int i = 1; i <= f[1]; i++)
        cout << 1, S += '1';
      for(int i = 1; i <= f[2]; i++)
        cout << 2, S += '2';
      cout << "\n";
    } else {
      f[2] -= k - 1;
      f[1]--;
      if(f[1] >= f[2]) {
        for(int i = 1; i <= f[2]; i++) {
          cout << 2, S += '2';
          for(int j = 1; j <= f[1] / f[2]; j++)
            cout << 1, S += '1';
        }
        for(int i = 1; i <= f[1] % f[2] + 1; i++)
          cout << 1, S += '1';
        for(int i = 1; i < k; i++)
          cout << 2, S += '2';
        cout << "\n";
      } else {
        for(int i = 1; i <= f[1]; i++)
          cout << "21", S += "21";
        for(int i = 1; i <= f[2] - f[1]; i++)
          cout << 2, S += '2';
        cout << 1, S += '1';
        for(int i = 1; i < k; i++)
          cout << 2, S += '2';
        cout << "\n";
      }
    }*/
  }
  return 0;
}
