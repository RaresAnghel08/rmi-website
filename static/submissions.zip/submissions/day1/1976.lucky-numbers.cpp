/**
* user:  mihov-a15
* fname: Rumen
* lname: Mihov
* task:  lucky
* score: 28.0
* date:  2019-10-10 08:15:57.429653
*/
# include <bits/stdc++.h>
const long long MOD=1e9+7;
using namespace std;
long long a[100005];
long long all=0;
long long ans[100005];
long long no,one,no1,one1,br;
void solve(int n)
{
    ans[0]=1;
    no = 1;
    one = 0;
    int i;
    for(i=1;i<=n;i++)
    {
        no1 = (no*(9)+one*8)%MOD;
        one1 = (no+one)%MOD;
        no=no1;
        one=one1;
        ans[i]=(no+one)%MOD;
       // cout<<i<<"**"<<ans[i]<<endl;
    }
}
int main()
{
ios_base::sync_with_stdio(false);
cin.tie(nullptr);
cout.tie(nullptr);
int n,q,i,j,t,l,r;
cin>>n>>q;
char ch;
solve(n);
for(i=1;i<=n;i++)
{
    cin>>ch;
    a[i]=ch-'0';
}
l=1;
r=n;
 {

all=0;

        for(j=l;j<=r;j++)
        {
            if((j==l)||(a[j-1]!=1)||(a[j]<=3))
 {all = (all + ans[r-j]*a[j])%MOD; if(a[j]>1){all = (all + MOD - ans[r-j-1])%MOD; }}
 else{
    all = (all + ans[r-j]*(a[j]-1))%MOD; if(a[j]>1){all = (all + MOD - ans[r-j-1])%MOD; }
 if(j>l&&a[j]==3&&a[j-1]==1)break;}
        /*    cout<<a[j]<<" ";
            br = a[j]+1;
if(a[j]>=1)br--;
            no1 = (no*br)%MOD;
  if(a[j]>=3)br--;
  no1=(no1+one*br)%MOD;
  if(a[j]==0)one1=0;
  else
    one1=(no+one)%MOD;
  no=no1;
  one=one1;
  cout<<endl<<no<<" "<<one<<endl; */ //cout<<"&&"<<all<<endl;
        }
if(j>r)all=(all+1)%MOD;
        cout<<(all)%MOD<<endl;;
    }
for(i=1;i<=q;i++)
{
    cin>>t>>l>>r;
    if(t==2)a[l]=r;
    else
    {

all=0;

        for(j=l;j<=r;j++)
        {
            if((j==l)||(a[j-1]!=1)||(a[j]<=3))
 {all = (all + ans[r-j]*a[j])%MOD; if(a[j]>1&&(r-j-1)>=0){all = (all + MOD - ans[r-j-1])%MOD; }}
 else{
    all = (all + ans[r-j]*(a[j]-1))%MOD; if(a[j]>1&&(r-j-1)>=0){all = (all + MOD - ans[r-j-1])%MOD; }
 if(j>l&&a[j]==3&&a[j-1]==1)break;}

        }
if(j>r)all=(all+1)%MOD;
        cout<<(all)%MOD<<endl;;
    }
}
}
/*
6 10
560484
2 6 4
2 1 4
2 5 6
2 6 1
2 3 6
1 3 6

*/

