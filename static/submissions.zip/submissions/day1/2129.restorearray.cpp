/**
* user:  malinin-a1f
* fname: Stoyan
* lname: Malinin
* task:  restore
* score: 20.0
* date:  2019-10-10 08:34:09.582617
*/
#include<bits/stdc++.h>

using namespace std;

const int MAXN = 5005;

struct requirement
{
    int l, r, k, val;
};

int n, m;
vector <requirement> v;

int answer[MAXN];
bool all1[MAXN], all0[MAXN];

int cnt0(int l, int r)
{
    int cnt = 0;
    for(int i = l;i<=r;i++)
    {
        if(answer[i]==0) cnt++;
    }

    return cnt;
}

int cnt1(int l, int r)
{
    int cnt = 0;
    for(int i = l;i<=r;i++)
    {
        if(answer[i]==1) cnt++;
    }

    return cnt;
}

bool check(bool mode)
{
    for(int i = 0;i<m;i++)
    {
        if(v[i].val==0)
        {
            if(cnt0(v[i].l, v[i].r)<v[i].k) return false;
        }

        if(v[i].val==1 && mode==true)
        {
            if(cnt0(v[i].l, v[i].r)>=v[i].k) return false;
        }
    }

    return true;
}

bool checkInd(int index)
{
    for(int i = 0;i<m;i++)
    {
        if(v[i].l>index) continue;

        if(v[i].val==1)
        {
            if(cnt0(v[i].l, v[i].r)>=v[i].k) return false;
        }
    }

    return true;
}

void bruteForce(int index)
{
    if(index==n)
    {
        if(check(true)==true)
        {
            for(int i = 0;i<n;i++) cout << answer[i] << " ";
            cout << '\n';

            exit(0);
        }

        return;
    }

    answer[index] = 0;
    bruteForce(index+1);

    answer[index] = 1;
    bruteForce(index+1);
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n >> m;
    for(int i = 0;i<m;i++)
    {
        int l, r, k, val;
        cin >> l >> r >> k >> val;

        v.push_back({l, r, k, val});

        if(k==1)
        {
            if(val==1)
            {
                for(int j = l;j<=r;j++)
                {
                    all1[j] = 1;
                    answer[j] = 1;
                }
            }
        }
    }

    if(n<=18)
    {
        memset(answer, 0, sizeof(answer));
        bruteForce(0);

        cout << "-1" << '\n';
        return 0;
    }

    if(check(true)==false)
    {
        cout << "-1" << '\n';
        return 0;
    }

    for(int i = 0;i<n;i++) cout << answer[i] << " ";
    cout << '\n';
}
/*
4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0
*/
