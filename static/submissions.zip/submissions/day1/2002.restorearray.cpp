/**
* user:  penchev-2b7
* fname: Jasen
* lname: Penchev
* task:  restore
* score: 20.0
* date:  2019-10-10 08:19:16.218737
*/
#include <algorithm>
#include <iostream>
#include <cstring>
#include <vector>
#define endl '\n'
using namespace std;

int n, m;
int a[5005];
int l[10005], r[10005], k[10005], val[10005];
vector<int> v;

void recurse(string s)
{
    if (s.size() == n)
    {
        for (int i = 0; i < m; ++ i)
        {
            v.clear();
            for (int j = l[i]; j <= r[i]; ++ j)
                v.push_back(s[j] - '0');
            sort(v.begin(), v.end());
            if (v[k[i] - 1] != val[i]) return;
        }
        for (int i = 0; i < n; ++ i)
            cout << s[i] << " ";
        cout << endl;
        exit(0);
    }
    recurse(s + '0');
    recurse(s + '1');
}

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    cin >> n >> m;

    memset(a, -1, sizeof(a));

    if (n <= 18 and m <= 200)
    {
        for (int i = 0; i < m; ++ i)
        {
            cin >> l[i] >> r[i] >> k[i] >> val[i];
        }

        recurse("");
        cout << -1 << endl;
    }
    else
    {
        for (int i = 0; i < m; ++ i)
        {
            cin >> l[i] >> r[i] >> k[i] >> val[i];
            if (k[i] == 1 and val[i] == 1)
            {
                for (int j = l[i]; j <= r[i]; ++ j)
                {
                    if (a[j] == 0)
                    {
                        cout << -1 << endl;
                        return 0;
                    }
                    a[j] = 1;
                }
            }
            if (k[i] == r[i] - l[i] + 1 and val[i] == 0)
            {
                for (int j = l[i]; j <= r[i]; ++ j)
                {
                    if (a[j] == 1)
                    {
                        cout << -1 << endl;
                        return 0;
                    }
                    a[j] = 0;
                }
            }
        }
        for (int i = 0; i < n; ++ i)
            cout << (a[i] != -1 ? a[i] : 0) << " ";
        cout << endl;
    }

    return 0;
}
