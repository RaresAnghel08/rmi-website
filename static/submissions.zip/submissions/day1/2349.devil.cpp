/**
* user:  kanafeev-1f0
* fname: Mark
* lname: Kanafeev
* task:  devil
* score: 0.0
* date:  2019-10-10 09:03:49.029445
*/
#include <bits/stdc++.h>


using namespace std;


#define x first
#define y second


signed main() {
    ios :: sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    for (int ccc = 0; ccc < n; ccc++) {
        int kk[10];
        int k, sm = 0;
        cin >> k;
        vector<int> tt;
        for (int i = 1; i <= 9; i++) {
            cin >> kk[i];
            sm += kk[i];
            for (int j = 0; j < kk[i]; j++)
                tt.push_back(i);
        }
        reverse(tt.begin(), tt.end());
        int pp = 9;
        while (kk[pp] == 0) {
            pp--;
        }
        if (2 * kk[pp] > sm) {
            for (int i = 1; i <= 9; i++)
                for (int j = 0; j < kk[j]; j++)
                    cout << i;
            cout << '\n';
            continue;
        }
        else {
            string ans(sm, '0');
            if (kk[pp] == 1) {
                ans.back() = pp + '0';
                kk[pp]--;
                tt.erase(tt.begin());
                sm--;
                if (sm == 0) {
                    cout << ans << '\n';
                    continue;
                }
                int pp2 = 9;
                while (kk[pp2] == 0) {
                    pp2--;
                }
                if (2 * kk[pp2] >= sm) {
                    for (int i = 9; i >= 1; i--)
                        for (int j = 0; j < kk[j]; j++)
                            cout << i;
                    cout << pp;
                    cout << '\n';
                    continue;
                }
                else {
                    for (int i = 0; i < kk[pp2]; i++) {
                        ans[2 * i] = pp2 + '0';
                    }
                    for (int i = 0; i < sm; i++) {
                        if (ans[i] == '0') {
                            ans[i] = '0' + tt.back();
                            tt.pop_back();
                        }
                    }
                    cout << ans << '\n';
                }
            }
            else {
                for (int i = 0; i < kk[pp]; i++) {
                    ans[sm - 2 * i - 1] = pp + '0';
                }
                for (int i = sm - 1; i >= 0; i--) {
                    if (ans[i] == '0') {
                        ans[i] = '0' + tt.back();
                        tt.pop_back();
                    }
                }
                cout << ans << '\n';
            }
        }
    }
    return 0;
}
