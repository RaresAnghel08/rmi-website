/**
* user:  dobleaga-573
* fname: Alexandru
* lname: Dobleaga
* task:  restore
* score: 0.0
* date:  2019-10-10 07:13:44.316397
*/
#include <iostream>

using namespace std;

constexpr int MMAX = 1e4 + 2;
constexpr int NMAX = 5e3 + 5;

struct interval
{
    int st, dr;
    int k, val;
};

interval a[MMAX];

int n, m;

bool ok = 0;

int prob[NMAX], sol[NMAX];

bool verif(int prob[])
{
    for (int i=1; i<=m; ++i)
    {
        int nr0=0, nr1=0;
        for (int j=a[i].st; j<=a[i].dr; ++j)
        {
            if (prob[j] == 0) nr0++;
            else nr1++;
        }

        int val = (nr0 >= a[i].k ? 0 : 1);
        if (val != a[i].val) return false;
    }

    return true;
}

void BKT (int k)
{
    if (ok == true) return;
    if (k == n)
    {
        if (verif(prob) == true)
        {
            ok = 1;
            for (int i=1; i<=n; ++i)
                sol[i] = prob[i];
        }
    }
    else
    {
        for (int i=0; i<=1 && ok == false; ++i)
        {
            prob[k]=i;
            BKT(k+1);
        }
    }
}

bool subtask2 ()
{
    for (int i=1; i<=m; ++i)
        if (a[i].k != 1) return false;

    return true;
}

int main()
{
    cin >> n >> m;

    for (int i=1; i<=m; ++i)
        cin >> a[i].st >> a[i].dr >> a[i].k >> a[i].val;

    if (n <= 18 && m <= 200)
    {
        ok = 0;
        BKT(0);

        if (ok == 0) cout << -1;
        else
        {
            for (int i=0; i<n; ++i)
                cout << sol[i] << " ";
        }
    }
    else if (subtask2() == true)
    {
        for (int i=1; i<=m; ++i)
        {
            if (a[i].val == 0) continue;
            for (int j=a[i].st; j<=a[i].dr; ++j)
                sol[j] = 1;
        }
        bool ok = verif(sol);

        if (ok == false)
        {
            cout << -1;
        }
        else
        {
            for (int i=0; i<n; ++i)
                cout << sol[i];
        }
    }
    return 0;
}
