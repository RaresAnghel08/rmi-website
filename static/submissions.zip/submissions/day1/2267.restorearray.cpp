/**
* user:  efremov-95c
* fname: Andrei
* lname: Efremov
* task:  restore
* score: 100.0
* date:  2019-10-10 08:52:14.018843
*/
#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <deque>
#include <iomanip>
#include <cassert>
#define rep(i, n) for (int i = 0; i < (n); i++)
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()

using namespace std;
using ll = long long;
using ul = unsigned long long;
using ld = long double;

const int N = 5002;
int d[N], used[N], q[N];
vector<pair<int, int>> g[N];
ll ct;

int main() {
#ifdef ONPC
	freopen("a.in", "r", stdin);
#endif
	ios_base::sync_with_stdio(0); cin.tie(0);
	ct = clock();
	int n, m, l, r, k, qt;
	cin >> n >> m;
	rep(i, n) {
		g[i].push_back({i + 1, 0});
		g[i + 1].push_back({i, -1});
	}
	rep(i, m) {
		cin >> l >> r >> k >> qt;
		r++;
		if (qt) { // < k <= k - 1
			g[r].push_back({l, 1 - k});
		}
		else { // >= k
			g[l].push_back({r, k});
		}
	}
	int ql = 0, qr = 0;
	rep(i, n + 1) {
		q[qr++] = i;
		used[i] = 1;
	}
	while (ql != qr && (clock() - ct) < 0.55 * CLOCKS_PER_SEC) {
		int v = q[ql];
		ql++;
		if (ql == N)
			ql = 0;
		used[v] = 0;
		for (auto &p : g[v])
			if (d[p.first] < d[v] + p.second) {
				d[p.first] = d[v] + p.second;
				if (!used[p.first]) {
					used[p.first] = 1;
					q[qr++] = p.first;
					if (qr == N)
						qr = 0;
				}
			}
	}
	if (ql != qr) {
		cout << -1;
		return 0;
	}
	rep(i, n)
		cout << d[i] - d[i + 1] + 1 << ' ';
}
