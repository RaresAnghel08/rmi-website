/**
* user:  apostol-c2d
* fname: Daniel
* lname: Apostol
* task:  devil
* score: 27.0
* date:  2019-10-10 10:27:10.235825
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define pb push_back
#define get_here cerr << "-1\n"
#define dbg(x) cerr << #x << " " << x << "\n"

int n, k;

ll d[10];
const int N = 1e5;
int ans[1 + N];
ll mx;
int a[1 + N];
void bkt (int p) {
    if (p == n + 1) {
        ll best = 0;
        ll nr = 0;
        ll put = 1;
        for (int i = 1; i <= k; i++) {
            nr = nr * 10 + a[i];
            put = put * 10;
        }
        best = nr;
        for (int i = k + 1; i <= n; i++) {
            nr = (nr * 10 + a[i]) % put;
            best = max (best, nr);
        }
        if (mx > best || mx == -1) {
            mx = best;
            for (int i = 1; i <= n; i++)
                ans[i] = a[i];
        }
        return;
    }
    for (int c = 1; c <= 9; c++)
        if (d[c]) {
            d[c]--;
            a[p] = c;
            bkt (p + 1);
            d[c]++;
        }
}

void brut () {
    bkt (1);
}

void solve_2 () {
    int big = 9;
    while (d[big] == 0)
        big--;
    ans[n] = big;
    d[big]--;
    while (d[big] == 0)
        big--;
    for (int i = n - 2; i > 0; i -= 2) {
        ans[i] = big;
        d[big]--;
        if (d[big] == 0)
            break;
    }
    for (int i = 1; i <= n; i++) {
        while (d[big] == 0)
            big--;

        if (!ans[i]) {
            ans[i] = big;
            d[big]--;
        }
    }
    for (int i = 1; i <= n; i++)
        cout << ans[i];
    cout << "\n";
}

void solve_3 () {
    if (k == 1) {
        for (int i = 1; i <= d[1]; i++)
            ans[i] = 1;
        for (int i = d[1] + 1; i <= n; i++)
            ans[i] = 2;
    }
    else if (d[2] < k) {
        for (int i = 1; i <= d[1]; i++)
            ans[i] = 1;
        for (int i = d[1] + 1; i <= n; i++)
            ans[i] = 2;
    }
    else if (d[2] == n) {
        for (int i = 1; i <= n; i++)
            ans[i] = 2;
    }
    else {
        int lft, lst_2;
        lft = n;
        lst_2 = -1;
        for (int i = n; i > n - k + 1; i--)
            ans[i] = 2;
        d[2] -= k - 1;
        ans[n - k + 1] = 1;
        d[1]--;//
        lft = n - k + 1;
        lst_2 = n - k + 2;

        ll space;
        ll grup;
        for (grup = 1; grup <= d[2]; grup++) {
            ll l = 0;
            ll r = lft - grup;
            space = 0;
            while (l <= r) {
                ll mid = (l + r) / 2;
                ll dist = 1ll * (d[2] / grup) * (mid + grup);
                if (d[2] % grup) {
                    dist += (d[2] % grup);
                    dist += mid;
                }
                if (dist < lst_2 || (lst_2 == -1 && dist - mid <= lft))
                    l = mid + 1, space = mid;
                else
                    r = mid - 1;
          //      dbg (mid);
            }
            if (space)
                break;
        }
        int j = 1;
        for (int i = 1; i <= d[2] / grup; i++) {
            for (int tt = 1; tt <= grup; tt++)
                ans[j] = 2, j++;
            j += space;
        }
        for (int tt = 1; tt <= d[2] % grup; tt++)
            ans[j] = 2, j++;
        for (int i = 1; i <= n; i++)
            if (!ans[i])
                ans[i] = 1;
    }
    for (int i = 1; i <= n; i++)
        cout << ans[i];
    cout << "\n";
}

void solve () {
    cin >> k;
    n = 0;
    for (int i = 1; i <= 9; i++)
        cin >> d[i], n += d[i];
    for (int i = 1; i <= n; i++)
        ans[i] = 0;
    if (k == 2) {
        solve_2 ();
        return;
    }
    if (d[1] + d[2] == n) {
        solve_3 ();
        return;
    }
    mx = -1;
    brut ();
    for (int i = 1; i <= n; i++)
        cout << ans[i];
    cout << "\n";
}

int main () {
    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);
 //  freopen ("devil.in", "r", stdin);
  //  freopen ("devil.out", "w", stdout);
    int t;
    cin >> t;
    while (t--)
        solve ();
    return 0;
}
