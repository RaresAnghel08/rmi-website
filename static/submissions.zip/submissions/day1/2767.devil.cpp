/**
* user:  perju-verzotti-a3f
* fname: Luca
* lname: Perju-Verzotti
* task:  devil
* score: 0.0
* date:  2019-10-10 09:56:51.225381
*/
#include <iostream>
#include <vector>
using namespace std;
int c[10];
vector <int> v[200006];
int main()
{
    ios_base::sync_with_stdio(0);
    int k,t,i,j,kc;
    cin>>t;
    while(t--)
    {
        cin>>k;
        for(i=1;i<=9;++i)
            cin>>c[i];
        int uc,f;
        int s=k-1;
        for(i=9;i>=1;--i)
        {
            if(c[i]<=s)
                s-=c[i];
            else
            {
                f=c[i]-s;
                uc=i;
                break;
            }
        }
        for(i=1;i<=f;++i)
            v[i].push_back(uc);
        j=1;
        int pzc=1,cat=f;
        kc=1;
        for(j=1;j<uc;++j)
        {
            int idk=0;
            while(c[j]>=cat)
            {
                for(i=1;i<=cat;++i)
                    v[i].push_back(j);
                c[j]-=cat;
            }
            if(c[j]==0)
                continue;
            int l=(cat-1)/c[j]+1;
            int cc=(cat-1)%c[j]+1;
            pzc=0;
            for(i=1;i<=c[j];++i)
            {
                if(i%2==1 && cc)
                    pzc+=l,--cc;
                else
                    pzc+=l-1;
                v[pzc].push_back(j);
            }
        }
        for(i=1;i<=f;++i)
        {
            for(j=0;j<v[i].size();++j)
                cout<<v[i][j];
            v[i].clear();
        }
        for(i=1;i<=s;++i)
            cout<<uc;
        for(j=uc+1;j<=9;++j)
            for(i=1;i<=c[j];++i)
                cout<<j;
        cout<<'\n';
    }
    return 0;
}
