/**
* user:  bortolin-a96
* fname: Alessandro
* lname: Bortolin
* task:  lucky
* score: 14.0
* date:  2019-10-10 10:37:26.973285
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
#define fi first
#define se second

constexpr int MAXN = 1 << 3, MOD = 1e9 + 7;

typedef vector<vector<int>> mat;

int N, Q;
int S[MAXN];
mat seg[2 * MAXN];

mat mult(mat& a, mat& b) {
	mat R(3, vector<int>(3));
	for (int i=0; i<3; i++) {
		for (int j=0; j<3; j++) {
			for (int k=0; k<3; k++) {
				R[i][j] += 1ll * a[i][k] * b[k][j] % MOD;
				R[i][j] %= MOD;
			}
		}
	}
	return R;
}

mat init(int a, int b) {
	mat R(3);
	R[0] = {9, 1, 0};
	R[1] = {8, 1, 0};
	if (a == 1) {
		if (b == 0) {
			R[2] = {0, 0, 1};
		} else if (b == 1) {
			R[2] = {1, 0, 1};
		} else if (b == 2) {
			R[2] = {1, 1, 1};
		} else if (b == 3) {
			R[2] = {2, 1, 0};
		} else {
			R[2] = {b - 2, 1, 1};
		}
	} else {
		if (b == 0) {
			R[2] = {0, 0, 1};
		} else if (b == 1) {
			R[2] = {1, 0, 1};
		} else {
			R[2] = {b - 1, 1, 1};
		}
	}
	return R;
}

mat _query(int a, int b, int l, int r, int p) {
	if (b <= l || r <= a) return {};
	if (a <= l && r <= b) return seg[p];
	int m = (l + r) / 2;
	mat rl = _query(a, b, l, m, 2 * p);
	mat rr = _query(a, b, m, r, 2 * p + 1);	
	if (rl.empty()) return rr;
	if (rr.empty()) return rl;
	return mult(rl, rr);
}

int query(int a, int b) {
	mat fi = init(0, S[a]);
	mat qq = _query(a, b, 0, MAXN, 1);
	mat res = qq.empty() ? fi : mult(fi, qq);
	int ans = 0;
	for (int i=0; i<3; i++) {
		ans = (ans + res[2][i]) % MOD;
	}
	return ans;
}

int main() {
	ios::sync_with_stdio(false);
	
	cin >> N >> Q;
	for (int i=N; i<MAXN; i++) {
		seg[i + MAXN] = init(0, 0);
	}
	for (int i=0; i<N; i++) {
		char c;
		cin >> c;
		S[i] = c - '0';
	}
	
	for (int i=N-1; i>=0; i--) {
		seg[i + MAXN] = init(S[i], S[i + 1]);
	}
	
	for (int i=MAXN-1; i>0; i--) {
		seg[i] = mult(seg[2*i], seg[2*i+1]);
	}
	
	cout << query(0, N - 1) << '\n';
	
	for (int i=0; i<Q; i++) {
		int t, a, b;
		cin >> t >> a >> b;
		if (t == 1) {
			cout << query(a - 1, b - 1) << '\n';
		} else {
			S[a - 1] = b;
			seg[i + a - 1] = init(S[i], S[i + 1]);
		}
	}
	
	return 0;
}
