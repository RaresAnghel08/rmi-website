/**
* user:  udristoiu-a44
* fname: Alexandra Maria
* lname: Udriștoiu
* task:  devil
* score: 0.0
* date:  2019-10-10 10:09:52.329442
*/
#include<iostream>
using namespace std;
int n, t, i, x, k, u, y;
int ff[12];
char sol[1000005];
//ifstream cin("date.in");
//ofstream cout("date.out");
int main(){
    cin>> t;
    for(; t; t--){
        n = 0;
        cin>> k;
        for(i = 1; i <= 9; i++){
            cin>> ff[i];
            n += ff[i];
        }
        sol[n + 1] = 0;
        if(k == 2){
            u = 9;
            for(i = n; i >= 1; i -= 2){
                while(ff[u] == 0){
                    u--;
                }
                sol[i] = u + '0';
                ff[u]--;
            }
            u = 0;
            for(i = n - 1; i >= 1; i -= 2){
                while(ff[u] == 0){
                    u++;
                }
                sol[i] = u + '0';
                ff[u]--;
            }
            cout<< sol + 1 <<"\n";
            return 0;
        }
    }
    return 0;
}
