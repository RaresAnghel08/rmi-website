/**
* user:  andreescu-960
* fname: Mihnea
* lname: Andreescu
* task:  lucky
* score: 14.0
* date:  2019-10-10 07:00:56.338652
*/
#include <bits/stdc++.h>

using namespace std;

const int N=(int)1e6+7;
bool con[N];

int main()
{
        int l,q,n,ans=1;
        cin>>l>>q>>n;

        for(int i=1;i<=n;i++)
        {
                if(con[i/10] || (i%10)==3 && (i/10)%10==1)
                        con[i]=1;
                else
                        ans++;
        }
        cout<<ans<<"\n";

        return 0;
}
