/**
* user:  semerdzhiev-688
* fname: Borislav
* lname: Semerdzhiev
* task:  lucky
* score: 28.0
* date:  2019-10-10 06:25:26.915595
*/
#include <cstdio>
#include <cstring>

using namespace std;

const int MAXN = 1e5 + 5;
const int MOD = 1e9 + 7;

int n, q;
char str[MAXN];

//FILE* open = fopen("happy_test.txt", "r");

int T[MAXN][2][2];

int add(int f, int s)
{
    f += s;
    if(f >= MOD)
    {
        f %= MOD;
    }
    return f;
}

void read_input()
{
    //fscanf(open, "%d %d", &n, &q);
    //fscanf(open, "%s", str);
    scanf("%d %d", &n, &q);
    scanf("%s", str);
}

int rec(int ind, int prev, int mark)
{
    if(T[ind][prev][mark] != -1)
    {
        return T[ind][prev][mark];
    }
    if(ind == n) return 1;
    int ans = 0;
    if(prev == 0)
    {
        for(int i = 0; i <= 9; i++)
        {
            if(mark && i == 3) continue;
            if(i == 1)
            {
                ans = add(ans, rec(ind + 1, 0, 1));
            }
            else
            {
                ans = add(ans, rec(ind + 1, 0, 0));
            }
        }
    }
    else
    {
        for(int i = 0; i < str[ind] - '0'; i++)
        {
            if(mark && i == 3) continue;
            if(i == 1)
            {
                ans = add(ans, rec(ind + 1, 0, 1));
            }
            else
            {
                ans = add(ans, rec(ind + 1, 0, 0));
            }
        }
        if(str[ind] == '1')
        {
            ans = add(ans, rec(ind + 1, 1, 1));
        }
        else
        {
            if(!mark || str[ind] != '3')
            {
                ans = add(ans, rec(ind + 1, 1, 0));
            }
        }
    }
    return T[ind][prev][mark] = ans;
}

void solve()
{
    int ans = 0;
    memset(T, -1, sizeof(T));
    for(int i = 0; i < str[0] - '0'; i++)
    {
        int par = 0;
        if(i == 1) par = 1;
        ans = add(ans, rec(1, 0, par));
    }
    if(str[0] == '1')
        ans = add(ans, rec(1, 1, 1));
    else
    {
        ans = add(ans, rec(1, 1, 0));
    }
    printf("%d\n", ans);

}

int main()
{
    read_input();

    solve();

    return 0;
}

/*
2 0
13
*/

/*
4 0
6461

*/

/*
6 0
560484
*/
