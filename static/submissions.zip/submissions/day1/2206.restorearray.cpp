/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  restore
* score: 7.0
* date:  2019-10-10 08:42:09.913170
*/
#include<bits/stdc++.h>
using namespace std;
bool b[20];
struct query
{
	int l,r,k,val;
};
vector<query>q;
int main()
{
	int n,m;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		int l,r,k,val;
		cin>>l>>r>>k>>val;
		q.push_back({l,r,k,val});
	}
	for(int mask=0;mask<(1<<n)-1;mask++)
	{
		for(int i=0;i<n;i++)
		{
			b[i]=(mask>>i)%2;
		}
		bool flag=1;
		for(int i=0;i<m;i++)
		{
			vector<int>v;
			for(int j=q[i].l;j<=q[i].r;j++)
			{
				v.push_back(b[j]);
			}
			sort(v.begin(),v.end());
			if(v[q[i].k-1]!=q[i].val)
			{
				flag=0;break;
			}
		}
		if(flag)
		{
			for(int i=0;i<n;i++)
			{
				cout<<b[i]<<" ";
			}
			cout<<endl;
			return 0;
		}
	}
	cout<<"-1\n";
return 0;
}
