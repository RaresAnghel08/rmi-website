/**
* user:  minkov-a23
* fname: Stefan
* lname: Minkov
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:36:18.854448
*/
#include<iostream>
#include<string>
using namespace std;
long long alf(long long a)
{
  long long m;
  while(a)
  {
    m*=a%10;
    a/=10;
  }
  return m;
}
const int M=1000000007;
long long pow(int n)
{
  if(n<=0) return 1;
  if(n==1) return 10;
  if(n%2==1) {return pow(n/2)*pow(n/2)*10;}
  else {return pow(n/2)*pow(n/2);}
}
int q,n;
long long a=0;
string s;
void Read()
{
  cin>>n>>q;
  cin>>s;
}
void ti(string x)
{
    n=x.size();

    for(int i=0;i<x.size();i++)
  {
    a*=10;
    a+=int (x[i]-'0');
  }
}
long long mod[100];
void Arr(int n,int p)
{
  bool f=1;
  for(int i=1;i<n;i+=2)
  {
    if(f==1)
    {
      if((n-i)*9+1==10) mod[p]+=1;
      else  mod[p]+=pow(n-i-2)*((n-i)*9+1);
      f=0;
    }
    else

    {
      if((n-i)*9+1==10) mod[p]-=1;
      else  mod[p]-=pow(n-i-2)*((n-i)*9+1);
      f=1;
    }
  }
}
void fun()
{
  long long c=13,c1,sum=0,cs=0;
  bool f=1;
  for(int i=1;i<n;i+=2)
  {
    for(int j=i;j<n;j++)
    {
      c1=a%pow(j-i)/pow(n-j-1);
      if(c1>c)
      {
        if(i=j) sum=+pow(n-j-1);
        else
        {
          sum+=alf(a/pow(n-j+i))*pow(n-j-1);
        }
      }
      else if(c==c1)
      {
        if(i==j) sum+=a%pow(n-j-1);
        else sum+=alf(a/pow(n-j+i)-1)*pow(n-j-1)+a%pow(n-j-1);
      }
      else
      {
        if(i!=j) sum+=alf(a/pow(n-j+i)-1)*pow(n-j-1);
      }
      cout<<sum<<" ";
    }
    if(f==1) {cs+=sum;f=0;}
    else {cs-=sum;f=1;}
    cout<<cs<<endl;
    sum=0;
    c*=100;
    c+=13;
  }
 // return cs;
}
void Solve(string x)
{
  ti(x);
  long long e=0;
  for(int i=0;i<n-1;i++) e+=mod[i];
  //e+=fun();
  e=a+1-e;
  e=e%M;
  cout<<e<<endl;
}
int main()

{

  ios_base::sync_with_stdio(0);
  Read();
  for(int i=0;i<s.size()-1;i++)
  {
    Arr(i+1,i);
cout<<mod[i]<<endl;
  }
  Solve(s);
fun();
  string s1;
  int t;
  int a,b;
  for(int i=0;i<q;i++)
  {
    cin>>t;
    if(t==2)
    {
      cin>>a>>b;
      s[a]=b;
    }
    else
    {
      cin>>a>>b;
      s1=s.substr(a-1,b-a+1);
      Solve(s1);
    }
  }


}
