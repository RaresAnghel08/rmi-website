/**
* user:  penchev-2b7
* fname: Jasen
* lname: Penchev
* task:  devil
* score: 27.0
* date:  2019-10-10 10:27:42.848117
*/
#include <algorithm>
#include <iostream>
#define endl '\n'
using namespace std;

int D[10];
int ans[1000005];
int a[1000005], b[1000005];

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int T;
    cin >> T;

    int K;
    for (int t = 0; t < T; ++ t)
    {
        cin >> K;

        int S = 0;
        for (int i = 1; i <= 9; ++ i)
        {
            cin >> D[i];
            S += D[i];
        }

        if (K == 1)
        {
            for (int i = 1; i <= 9; ++ i)
            {
                for (int j = 1; j <= D[i]; ++ j)
                    cout << i;
            }
            cout << endl;
        }
        else if (K == 2)
        {
            int i = 1, j = 9;
            for (int p = S; p >= 1; -- p)
            {
                if ((S - p) % 2 == 0)
                {
                    while (D[j] == 0) j--;
                    ans[p] = j;
                    D[j]--;
                }
                else
                {
                    while (D[i] == 0) i++;
                    ans[p] = i;
                    D[i]--;
                }
            }
            for (int p = 1; p <= S; ++ p)
                cout << ans[p];
            cout << endl;
        }
        else if (0 <= D[1] and D[1] <= 3 and 0 <= D[2] and D[2] <= 3)
        {
            string s = "";
            for (int i = 1; i <= 9; ++ i)
            {
                for (int j = 1; j <= D[i]; ++ j)
                    s += char(i + '0');
            }
            string ans = "", maxs = "", mins = "";
            for (int i = 0; i < K; ++ i)
            {
                maxs += '9';
                mins += '0';
            }
            do
            {
                string mm = mins;
                for (int i = 0; i < s.size() - K + 1; ++ i)
                    if (mm < s.substr(i, K)) mm = s.substr(i, K);
                if (mm < maxs)
                {
                    maxs = mm;
                    ans = s;
                }
            }while (next_permutation(s.begin(), s.end()));
            cout << ans << endl;
        }
        else
        {
            if (D[1] + D[2] < K or D[2] < K or (D[1] + 1) * (K - 1) < D[2])
            {
                for (int i = 1; i <= 2; ++ i)
                {
                    for (int j = 1; j <= D[i]; ++ j)
                        cout << i;
                }
                cout << endl;
            }
            else
            {
                D[2] -= K - 1;
                int nod = __gcd(D[1], D[2]);
                D[1] /= nod;
                D[2] /= nod;
                for (int i = 0; i < nod; ++ i)
                {
                    for (int j = 0; j < D[2]; ++ j)
                        cout << 2;
                    for (int j = 0; j < D[1]; ++ j)
                        cout << 1;
                }
                for (int i = 0; i < K - 1; ++ i)
                    cout << 2;
                cout << endl;
            }
        }
    }

    return 0;
}
