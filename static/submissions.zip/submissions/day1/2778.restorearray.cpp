/**
* user:  todorov-9fe
* fname: Andon
* lname: Todorov
* task:  restore
* score: 13.0
* date:  2019-10-10 09:57:30.105574
*/
#include <bits/stdc++.h>
using namespace std;
int n, m, a [5003];
struct str{
	int l, r, k, v;
	bool operator < (str s) const{
		return k == 1 && v > s.v || k == r - l + 1 && v < s.v;
	}
};
vector <str> b;
int main (){

	ios::sync_with_stdio (false);
	cin.tie (0);

	cin >> n >> m;
	for (int i = 0; i < m; i ++){
		int l, r, k, v;
		cin >> l >> r >> k >> v;
		if (k == 1 && v == 1){
			for (int j = l; j <= r; j ++){
				if (a [j] == -1){
					cout << "-1\n";
					return 0;
				}
				a [j] = 1;
			}
		}
		else if (k == r - l + 1 && v == 0){
			for (int j = l; j <= r; j ++){
				if (a [j] == 1){
					cout << "-1\n";
					return 0;
				}
				a [j] = -1;
			}
		}
		else b.push_back ({l, r, k, v}); 
	}
	int curr = 0;
	for (int i = 0; i < n; i ++){
		if (a [i] == 0){
			a [i] = curr;
			curr = 1 - curr;
		}
		if (a [i] == -1) a [i] = 0;
	}
	for (auto i : b){
		bool dali = 0;
		for (int j = i.l; j <= i.r; j ++){
			if (a [j] == i.v){
				dali = 1;
				break;
			}
		}
		if (!dali){
			cout << "-1\n";
			return 0;
		}
	}
	for (int i = 0; i < n; i ++) cout << a [i] << ' ';
	cout << '\n';

	cout << "-1\n";
return 0;}
