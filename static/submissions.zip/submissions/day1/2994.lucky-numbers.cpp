/**
* user:  licht-5c2
* fname: Noam
* lname: Licht
* task:  lucky
* score: 28.0
* date:  2019-10-10 10:21:57.494803
*/
#include <bits/stdc++.h>
#define int int64_t
#define vi vector<int>
#define vb vector<bool>
#define ii pair<int,int>
#define vii vector<ii>
#define vvi vector<vi>
#define x first
#define y second
#define loop(i,s,e) for(int i=(s);i<(e);++i)
#define mp make_pair
#define pb push_back
#define chkmax(a,b) a=max(a,b)
#define chkmin(a,b) a=min(a,b)
using namespace std;
using ll=long long;
using ld=long double;
const int INF=1e18;
const int MOD=1000000007;

vi c;

void prep(vi& s,int l, int r){
    int n=r-l+1;
    vi a(n+1,0), b(n+1,0);
    a[0]=1;
    b[0]=1;
    vi d(n+1,0);
    c.resize(n+1,0);
    c[0]=1;
    d[0]=1;
    loop(i,1,n+1){
        int ch = s[r-i+1];
        a[i]=(9*a[i-1]+b[i-1])%MOD;
        b[i]=(b[i-1]+8*a[i-1])%MOD;
        if (ch>=1){
            //puts 1
            if (ch==1){
                c[i]+=d[i-1];
                d[i]+=d[i-1];
            }
            else{
                c[i]+=b[i-1];
                d[i]+=b[i-1];
            }
        }
        if (ch==0){
            //puts 0
            c[i]+=c[i-1];
            d[i]+=c[i-1];
        }
        else if(ch==1){
            //puts 0
            c[i]+=a[i-1];
            d[i]+=a[i-1];
        }
        else if (ch==2){
            //puts 0 and 2
            c[i]+=c[i-1]+a[i-1];
            d[i]+=c[i-1]+a[i-1];
        }
        else if (ch==3){
            //puts 0 and 2 (and 3)
            c[i]+=c[i-1]+2*a[i-1];
            d[i]+=2*a[i-1];
        }
        else{
            //puts 0 and 2 (3) 4...x
            c[i]+=c[i-1]+(ch-1)*a[i-1];
            d[i]+=c[i-1]+(ch-2)*a[i-1];
        }
        c[i]%=MOD;
        d[i]%=MOD;
    }
}


int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int n=0,q=0; cin>>n>>q;
    string _s; cin>>_s;
    vi s(n);
    loop(i,0,n) s[i]=_s[i]-'0';
    int l,r,type;
    vvi querys(n);
    querys[n-1].pb(0);
    loop(i,0,q){
        cin>>type>>l>>r;
        if (type==1){
            l--; r--;
            querys[r].pb(l);
            //query(s,l,r);
        }
        else{
            s[l-1]=r;
        }
    }
    sort(querys.begin(),querys.end());
    loop(r,0,n){
        if (querys[r].size()>0){
            prep(s,0,r);
            for(auto l: querys[r])
                cout<<c[r-l+1]<<endl;
        }
    }
    return 0;
}


