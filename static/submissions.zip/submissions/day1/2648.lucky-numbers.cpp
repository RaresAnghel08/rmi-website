/**
* user:  kamenov-5bd
* fname: Konstantin
* lname: Kamenov
* task:  lucky
* score: 28.0
* date:  2019-10-10 09:43:11.637229
*/
#include<iostream>
#define MOD 1000000007
using namespace std;
long long nums[100005];
long long querry(long long a,long long b)
{
    long long f1=0,f2=0;
    if(nums[a]>0){
        f1=1;
    }
    f2=nums[a]+1-f1;
    for(long long i=a+1; i<=b; i++)
    {
        //cout<<f1<<" "<<f2<<endl;
        long long r1=f1,r2=f2;
        f1=r1+r2;
        if(nums[i]==0)f1--;
        f1+=MOD;
        f1%=MOD;

        f2=r2*9ll-(9ll-nums[i])+r1*8ll+MOD;
        if(nums[i]==0)f2++;
        f2%=MOD;
    }
    return f1+f2;
}
int main()
{
    cin.tie(nullptr);
    ios::sync_with_stdio(false);
    long long n,m;
    cin>>n>>m;
    for(long long i=0; i<n; i++)
    {
        char a;
        cin>>a;
        nums[i]=a-'0';
    }
    cout<<querry(0,n-1)%MOD<<endl;
    for(long long i=0; i<m; i++)
    {
        long long a,b,c;
        cin>>a>>b>>c;
        if(a==2)
        {
            nums[b-1]=c;
        }
        else
        {
            cout<<querry(b-1,c-1)%MOD<<"\n";
        }
    }
    std::cout.flush();
    return 0;
}
