/**
* user:  feodorov-90b
* fname: Andrei
* lname: Feodorov
* task:  lucky
* score: 14.0
* date:  2019-10-10 07:13:58.389454
*/
#include <iostream>

using namespace std;
bool verif(int x){
int cnt=0;
    while(x>=13){
        if(x%100==13)
            return true;
        x/=10;
    }
    return false;
}
int main()
{
    int n,q,x,cnt=0;
    cin>>n>>q;
    cin>>x;
    for(int i=13;i<=x;i++){
        if(verif(i)==true){
            cnt++;
        }
    }
    cout<<x-cnt+1;
    return 0;
}
