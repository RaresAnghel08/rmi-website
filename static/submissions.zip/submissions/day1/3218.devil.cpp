/**
* user:  ivan-6a1
* fname: Tudor
* lname: Ivan
* task:  devil
* score: 0.0
* date:  2019-10-10 10:39:27.647249
*/
#include <iostream>
#include<cstdio>
using namespace std;
int frv[10];
int pos[15];
int cf[15];
int s;
long long len,rasi,lenp;
long long mini=1LL<<60;
void bkt(int k,int aux){
  if(k==s+1){
    long long maxi=0;
    int caux=aux;
    while(aux){
      maxi=max(maxi,aux%lenp);
      aux/=10;
    }
    if(maxi<mini){
      mini=maxi;
      rasi=caux;
    }
    return;
  }
  for(int i=1;i<=4;i++){
    if(frv[i]>0){
      frv[i]--;
      bkt(k+1,aux*10LL+i);
      frv[i]++;
    }
  }
}
void solve(){
  int k;
  s=0;
  scanf("%d",&k);
  for(int i=1;i<=9;i++)
    scanf("%d",&frv[i]),s+=frv[i];
  len=k;
  lenp=1;
  while(k--)
    lenp*=10LL;
  mini=1LL<<60;
  bkt(1,0);
  cout<<rasi<<endl;
}
int main()
{
  int nrt;
  scanf("%d",&nrt);
  while(nrt--){
    solve();
  }
    return 0;
}
