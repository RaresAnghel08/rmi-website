/**
* user:  lifar-7f1
* fname: Egor
* lname: Lifar
* task:  restore
* score: 7.0
* date:  2019-10-10 06:31:52.902364
*/
#include <bits/stdc++.h>

using namespace std;
template<class A, class B> inline void chkmin(A &a, B b){ a = (a > b ? b: a);}
template<class A, class B> inline void chkmax(A &a, B b){ a = (a < b ? b: a);}
#define all(c) (c).begin(), (c).end()
#define sz(c) (int)(c).size()
#define pb push_back
#define mp make_pair
using ll = long long;
using ld = long double;
const int MAXN = 5005;


int n, m;
vector<pair<int, int> > g[MAXN], res[MAXN], f[MAXN];
int s[MAXN];
int s1[MAXN];


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	//freopen("input.in", "r", stdin);
	cin >> n >> m;
	for (int it = 0; it < m; it++) {
		int l, r, k, val;
		cin >> l >> r >> k >> val;
		l++;
		r++;
		if (val == 1) {
			g[r].pb({l - 1, k - 1});
			f[l - 1].pb({r, k - 1});
		} else {
			res[l - 1].pb({r, k});
		}
	}
	for (int i = 0; i <= n; i++) {
		if (i) {
			chkmax(s[i], s[i - 1]);
		}
		for (auto x: res[i]) {
			for (int j = i + 1; j <= x.first; j++) {
				chkmax(s[j], s[i] + x.second - (x.first - j));
			}
		}
	}
	for (int i = 1; i <= n; i++) {
		s1[i] = 1e9;
	}
	s1[0] = 0;
	for (int i = 0; i <= n; i++) {
		int t = s1[i];
		for (auto x: g[i]) {
			chkmin(t, s1[x.first] + x.second);
		}
		chkmin(t, s1[i - 1] + 1);
		for (int j = i + 1; j <= n; j++) {
			chkmin(t, s1[j]);
		}
		s1[i] = t;
		for (int j = n; j >= i; j--) {
			for (auto x: res[j]) {
				chkmin(s1[j], s1[x.first] - x.second);
			}
		}
		for (int jj = 0; jj <= n; jj++) {
			for (auto x: f[jj]) {
				for (int j = jj + 1; j <= x.first; j++) {
					chkmin(s1[j], s1[jj] + x.second);
				}
			}
		}
	}
	for (int i = 0; i <= n; i++) {
		for (auto x: res[i]) {
			if (s1[i] > s1[x.first] - x.second) {
				cout << -1 << endl;
				exit(0);
			}
		}
		for (auto x: f[i]) {
			if (s1[x.first] > s1[i] + x.second) {
				cout << -1 << endl;
				exit(0);
			}
		}
		if (i < n) {
			if (s1[i + 1] -s1[i] != 1 && s1[i + 1] -s1[i] != 0) {
				cout << -1 << endl;
				exit(0);
			}
		}
	}
	for (int i = 0; i < n; i++) {
		cout << 1 - (s1[i + 1] - s1[i]) << ' ';
	}
	cout << '\n';
	return 0;
}