/**
* user:  craciun-5f9
* fname: Mihai
* lname: Crăciun
* task:  devil
* score: 0.0
* date:  2019-10-10 09:19:51.322675
*/
#include <bits/stdc++.h>

using namespace std;

int k;
int d[10];
int s;

const int maxs = 1e6 + 5;

int afis[maxs];
int sz;

int main()  {
//    freopen("a.in", "r", stdin);
    int t;
    cin >> t;
    while(t--)  {
        cin >> k;
        s = 0;
        for(int i = 1;i <= 9;i++)
            cin >> d[i], s += d[i];
        sz = 0;
        if(d[1] < s / k)  {
            for(int i = 1;i <= d[2];i++)
                cout << "2 ";
            for(int i = 1;i <= d[1];i++)
                cout << "1 ";
            cout << '\n';
            continue;
        }
            int szz = 0;
            for(int poz = 1;poz <= k;poz++)  {
                int nrgr = (s - k) / poz;
                if(d[1] < nrgr + 1)  {
                    continue;
                }
                for(int j = 1;j <= nrgr + 1;j++)  {
                    for(int r = 1;r < poz;r++)  {
                        if(d[2])
                            afis[++szz] = 2, d[2]--;
                        else
                            afis[++szz] = 1, d[1]--;
                    }
                    if(d[1])
                        afis[++szz] = 1, d[1]--;
                    else
                        afis[++szz] = 2, d[2]--;
                }
                while(d[1])
                    afis[++szz] = 1, d[1]--;
                while(d[2])
                    afis[++szz] = 2, d[2]--;
            }
        for(int i = 1;i <= s;i++)
            cout << afis[i] << " ";
        cout << "\n";
    }
    return 0;
}
