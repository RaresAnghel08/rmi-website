/**
* user:  kozhuharov-9a5
* fname: Viktor
* lname: Kozhuharov
* task:  lucky
* score: 28.0
* date:  2019-10-10 06:59:35.274912
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e5 + 7;
const int mod = 1e9 + 7;

string x;
int n, q;

pair<int, int> dp[MAXN][2][2];
int curr_q;

void fix(int &x){
    if(x >= mod){
        x -= mod;
    }
}

int solve(int pos, bool eq, bool pr, int left){
    if(left == -1){
        return 1;
    }

    pair<int, int> &d = dp[left][eq][pr];
    if(d.second == curr_q || (d.second > 0 && !eq)){
        return d.first;
    }
    d.second = curr_q;

    int mx = (int)x[pos] - '0';
    if(!eq){
        mx = 9;
    }

    for(int i = 0; i <= mx; ++i){
        bool new_eq = eq ? (i == mx) : false;

        if(i == 1){
            d.first += solve(pos + 1, new_eq, true, left - 1);
            fix(d.first);
            continue;
        }
        if(i == 3){
            if(pr){
                continue;
            }
            d.first += solve(pos + 1, new_eq, false, left - 1);
            fix(d.first);
            continue;
        }
        d.first += solve(pos + 1, new_eq, false, left - 1);
        fix(d.first);
    }

    return d.first;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n >> q;
    cin >> x;

    curr_q = 1;
    cout << solve(0, true, false, n - 1) << "\n";
    for(int i = 0; i < q; ++i){
        int type;
        curr_q = i + 2;

        cin >> type;

        if(type == 1){
            int l, r;

            cin >> l >> r;
            --l;
            --r;

            cout << solve(l, true, false, r - l) << "\n";
        }
        else{

        }
    }

    return 0;
}
