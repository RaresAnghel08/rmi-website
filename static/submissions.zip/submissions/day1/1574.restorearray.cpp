/**
* user:  karimov-095
* fname: Renat
* lname: Karimov
* task:  restore
* score: 20.0
* date:  2019-10-10 07:09:37.762476
*/
#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define ld long double
#define ll long long


int main()
{
    ios_base::sync_with_stdio(0);
    //cin.tie(0);
    //cout.tie(0);
    int n, m;
    cin >> n >> m;
    vector<pair<int,int>> vn(m);
    vector<int> k(m), val(m);
    bool x = 1;
    for (int i = 0; i < m; i++){
        cin >> vn[i].first >> vn[i].second >> k[i] >> val[i];
        if (k[i] != 1){
            x = 0;
        }
    }
    if (x){
        vector<int> v(n);
        for (int i = 0; i < m; i++){
            if (val[i] == 1){
                for (int l = vn[i].first; l <= vn[i].second; l++){
                    v[l] = 1;
                }
            }
        }
        bool check = 0;
            for (int in = 0; in < m; in++){
                vector<int> v1;
                for (int l = vn[in].first; l <= vn[in].second; l++){
                    v1.pb(v[l]);
                }
                sort(v1.begin(), v1.end());
                if (v1[k[in] - 1] != val[in]){
                    check = 1;
                    break;
                }
            }
            if (!check){
                for (auto to : v){
                    cout << to << " ";
                }
                return 0;
            }
        cout << -1;
    }
    else{
        for (int i = 0; i < (1 << n); i++){
            vector<int> v;
            for (int j = 0; j < n; j++){
                if (i & (1 << j)){
                    v.pb(1);
                }
                else{
                    v.pb(0);
                }
            }
            bool check = 0;
            for (int in = 0; in < m; in++){
                vector<int> v1;
                for (int l = vn[in].first; l <= vn[in].second; l++){
                    v1.pb(v[l]);
                }
                sort(v1.begin(), v1.end());
                if (v1[k[in] - 1] != val[in]){
                    check = 1;
                    break;
                }
            }
            if (!check){
                for (auto to : v){
                    cout << to << " ";
                }
                return 0;
            }
        }
        cout << -1;
    }
}
