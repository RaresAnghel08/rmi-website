/**
* user:  ivan-6a1
* fname: Tudor
* lname: Ivan
* task:  restore
* score: 0.0
* date:  2019-10-10 10:38:17.052307
*/
#include <iostream>
#include<cstdio>
using namespace std;
const int N=5005;
const int INF=1e5;

struct querry{
  int st,dr,k,val;
};
querry q[2*N];
int sol[N];

int main()
{
  int n,m;
 // freopen("a.in","r",stdin);
  scanf("%d%d",&n,&m);
  for(int i=0;i<n;i++)
    sol[i]=0;
  for(int i=1;i<=m;i++){
    scanf("%d%d%d%d",&q[i].st,&q[i].dr,&q[i].k,&q[i].val);
    if(q[i].k==1 && q[i].val==1){
      for(int j=q[i].st;j<=q[i].dr;j++){
        sol[j]=1;
      }
    }
    /*if(q[i].k==q[i].dr-q[i].st+1 && q[i].val==0){
       for(int j=q[i].st;j<=q[i].dr;j++){
        if(sol[j]==1){
          printf("-1");
        }
        sol[j]=0;
      }
    }*/
  }
  for(int i=1;i<=m;i++){
    bool ok=false;
    int aux,j;
    if(q[i].k==1 && q[i].val==0){
      for(j=q[i].st;j<=q[i].dr;j++){
        if(sol[j]==0){
          ok=true;
          break;
        }
      }
    }
    if(q[i].k==1 && q[i].val==1){
      for(j=q[i].st;j<=q[i].dr;j++){
        if(sol[j]==0){
          ok=false;
          break;
        }
      }
    }
    if(ok==false){
      printf("-1");
      return 0;
    }
    /*if(q[i].k==q[i].dr-q[i].st+1 && q[i].val==1){
      aux=1;
    }
    int j;
    for(j=q[i].st;j<=q[i].dr;j++){
      if(sol[j]==aux || sol[j]==INF){
        ok=true;
        break;
      }
    }
    if(ok==false){
      printf("-1");
      return 0;
    }
    sol[j]=aux;*/
  }
 for(int i=0;i<n;i++){
    printf("%d ",sol[i]);
  }
  return 0;
}
