/**
* user:  metehau-fd8
* fname: Luca
* lname: Metehău
* task:  restore
* score: 0.0
* date:  2019-10-10 08:29:33.436174
*/
#include <iostream>

using namespace std;

struct S {
  int l, r, k, val;
};

int n, m;

int l, r, k, val;

int v[5005], a[20], cnt[20];
S s[5005];

int main() {
  cin >> n >> m;
  for(int i = 1; i <= n; i++)
    v[i] = -1;
  for(int i = 1; i <= m; i++) {
    cin >> l >> r >> k >> val;
    l++, r++;
    if(k == 1 && val == 1) {
      for(int j = l; j <= r; j++) {
        if(!v[j]) {
          cout << -1;
          return 0;
        }
        v[j] = 1;
      }
    } else if(k == r - l + 1 && val == 0) {
      for(int j = l; j <= r; j++) {
        if(v[j] == 1) {
          cout << -1;
          return 0;
        }
        v[j] = 0;
      }
    }
    s[i] = {l, r, k, val};
  }
  if(n <= 18) {
    for(int mask = 0; mask < (1 << n); mask++) {
      bool ok = 1;
      for(int j = 1; j < mask; j++)
        a[j] = ((mask & (1 << (j - 1))) > 0), cnt[j] = cnt[j - 1] + a[j];
      for(int i = 1; i <= m; i++) {
        // am cnt[r] - cnt[l - 1] 1uri
        int x = cnt[s[i].r] - cnt[s[i].l - 1];
        if(s[i].k < n - x && s[i].val) {
          ok = 0;
          break;
        }
        if(s[i].k > n - x && !s[i].val) {
          ok = 0;
          break;
        }
      }
      if(ok) {
        for(int i = 1; i <= n; i++)
          cout << a[i] << " ";
        return 0;
      }
    }
    cout << -1;
    return 0;
  }
  for(int i = 1; i <= n; i++) {
    if(v[i] == -1)
      v[i] = 0;
    cout << v[i] << " ";
  }
  return 0;
}
