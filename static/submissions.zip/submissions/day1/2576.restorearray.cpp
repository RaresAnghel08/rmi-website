/**
* user:  dorde-f8e
* fname: Matei
* lname: Dorde
* task:  restore
* score: 0.0
* date:  2019-10-10 09:32:21.274401
*/
#include <iostream>
#include <algorithm>
using namespace std;
int n , m;
int const N = 5001 , M = 10001;
int v [N] ;
//ifstream cin ("a.in");
//ofstream cout ("a.out");
struct code {
    int l , r , k ;
    bool val;
};
code q [M];
int chk [N];
bool check (){
    for(int i = 1 ; i <= m ; ++ i){
        int o = 0;
        for(int j = q [i] . l ; j <= q [i] . r ; ++ j )
            chk [o ++] = v [j];
        int lg = q [i] . r - q [i] . l + 1;
        sort (chk , chk + lg);
        if (chk [q [i] . k - 1] != q [i] . val)
            return false;
    }
    return true;
}
void solve (){
    for(int i = 0 ; i < (1 << n) ; ++ i){
        fill (v , v + n , false);
        for(int j = 0 ; (1 << j) <= i ; ++ j)
            if ((1 << j) & i)
                v [j] = true;
        if (check ()){
            for(int i = 0 ; i < n ; ++ i)
                cout << v [i] << ' ';
            return;
        }
    }
}
bool fil [N];
void out (){
    for(int i = 0 ; i < n ; ++ i)
        cout << v [i] << ' ';
}
//int zer [N] , unu [N];
/*
void solve23 (){
    int fld = 0;
    for(int i = 1 ; i <= m ; ++ i){
        int lg = q [i] . r - q [i] . l + 1;
        if (q [i] . k == 1 && q [i] . val){
            fill (v [i] + q [i] . l , v [i] + q [i] . r , true) ;
            chg [q [i] . l] = 1 , chg [q [i] . r] = 2 , fld += lg;

        }
        if (q [i] . k == lg && ! q [i] . val){
            fill (v [i] + q [i] . l , v [i] + q [i] . r , false) ;
             chg [q [i] . l] = 1 , chg [q [i] . r] = 3 , fld += lg;
             zer [q [i] . l] = 1 , zer [q [i]
        }
        if (lg == 1)
            v [q [i] . l] = q [i] . val;
    }
    if (fld == n)
        out ();
    else{

    }

}*/
/*int aint [2 * N + 1];
int query (int node , int from , int to , int st , int dr){
    int mid = (from + to) >> 1;
    int ans = 0;
    if (from == to)
        return aint [node];
    if (dr >= to && st <= from)
        return aint [node];
    else {
        if (dr >= mid && st <= mid)
            return query (node * 2 , from , mid , st , dr) + query (node * 2 + 1 , mid + 1 , to , st , dr);
        else
            if (dr <= mid)
                return query (node * 2 , from , mid , st , dr);
            else
                if (st > mid)
                    return query (node * 2 + 1 , mid + 1 , to , st , dr);
    }

}*/
int main()
{
    cin >> n >> m;
    bool p = true;
    for(int i = 1 ; i <= m ; ++ i){
        int a , b , c , d;
        cin >> a >> b >> c >> d;
        q [i] = {a , b , c , d};
        if (c != b - a + 1 && c != 1)
            p = false;

    }
    if (n < 19 && m < 201){
        solve ();
        return 0;
    }
   // if (! p)
     //   solve23 ();
   /* int ind = 0;
    while (ind <= n){
        for(int i = 1 ; i <= m ; ++ i){
            int st = q [i] . l;
            int dr = q [i] . r;
            int mk = q [i] . k;
            bool x = q [i] . val;
            int lg = dr - st + 1;
            if (x){
                int ones = dr - st - mk + 2;
                if (ones > query (1 , 1 , n , st , dr))
                    update (1 , st , dr);
                if (ones == lg)
                    ind += lg , fill (v + st , v + dr , true);

            }
        } */
    return 0;
}

