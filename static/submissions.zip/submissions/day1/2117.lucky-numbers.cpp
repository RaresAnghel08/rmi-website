/**
* user:  udristoiu-a44
* fname: Alexandra Maria
* lname: Udriștoiu
* task:  lucky
* score: 28.0
* date:  2019-10-10 08:33:00.521645
*/
#include<iostream>
#include<cstring>
#define DIM 100005
#define mod 1000000007
using namespace std;
int n, q, i, t, p, u, x, cif;
char s[DIM];
int aint[4 * DIM][4][4], sol[4][4], aux[4][4];
//ifstream cin("date.in");
//ofstream cout("date.out");
void copiere(){
   for(int i = 1; i <= 3; i++){
        for(int j = 1; j <= 3; j++){
            sol[i][j] = aux[i][j];
        }
   }
}
void mult(int a[4][4], int b[4][4], int c[4][4]){
    for(int i = 1; i <= 3; i++){
        for(int j = 1; j <= 3; j++){
            c[i][j] = 0;
            for(int k = 1; k <= 3; k++){
                c[i][j] = (c[i][j] + a[i][k] * 1LL * b[k][j]) % mod;
            }
        }
    }
}
void init(int a[4][4], int p){
    a[1][1] = 9;
    a[1][2] = 8;
    a[1][3] = s[p];
    if(s[p] > 1){
        a[1][3]--;
    }
    if(s[p] > 3 && s[p - 1] == 1){
        a[1][3]--;
    }
    a[2][1] = a[2][2] = 1;
    if(s[p] > 1){
        a[2][3] = 1;
    }
    else{
        a[2][3] = 0;
    }
    if(s[p - 1] == 1 && s[p] == 3){
        a[3][3] = 0;
    }
    else{
        a[3][3] = 1;
    }
}
void build(int nod, int st, int dr){
    if(st == dr){
        init(aint[nod], st);
    }
    else{
        int mid = (st + dr) / 2;
        build(2 * nod, st, mid);
        build(2 * nod + 1, mid + 1, dr);
        mult(aint[2 * nod + 1], aint[2 * nod], aint[nod]);
    }
}
void update(int nod, int st, int dr, int p){
    if(st == dr){
        init(aint[nod], st);
    }
    else{
        int mid = (st + dr) / 2;
        if(p <= mid){
            update(2 * nod, st, mid, p);
        }
        else{
            update(2 * nod + 1, mid + 1, dr, p);
        }
        mult(aint[2 * nod + 1], aint[2 * nod], aint[nod]);
    }
}
void query(int nod, int st, int dr, int p, int u){
    if(p <= st && dr <= u){
        mult(sol, aint[nod], aux);
       copiere();
    }
    else{
        int mid = (st + dr) / 2;
        if(u > mid){
            query(2 * nod + 1, mid + 1, dr, p, u);
        }
        if(p <= mid){
            query(2 * nod, st, mid, p, u);
        }
    }
}
int main(){
    cin>> n >> q;
    cin>> s + 1;
    for(i = 1; i <= n; i++){
        s[i] -= '0';
    }
    build(1, 1, n);
    memset(sol, 0, sizeof(sol) );
    sol[1][1] = sol[2][2] = sol[3][3] = 1;
    query(1, 1, n, 1, n);
    cout<< (sol[1][3] + sol[2][3] + sol[3][3]) % mod <<"\n";
    for(; q; q--){
        cin>> t >> p;
        if(t == 1){
            cin>> u;
            if(p != 1){
                cif = s[p - 1];
                s[p - 1] = 0;
                update(1, 1, n, p - 1);
            }
            memset(sol, 0, sizeof(sol) );
            sol[1][1] = sol[2][2] = sol[3][3] = 1;
            query(1, 1, n, p, u);
            cout<< (sol[1][3] * 1LL + sol[2][3] + sol[3][3]) % mod <<"\n";
            if(p != 1){
                s[p - 1] = cif;
                update(1, 1, n, p - 1);
            }
        }
        else{
            cin>> x;
            s[p] = x;
            update(1, 1, n, p);
            if(p != n){
                update(1, 1, n, p + 1);
            }
        }
    }
    return 0;
}
