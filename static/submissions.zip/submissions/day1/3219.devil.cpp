/**
* user:  spinei-1ec
* fname: Mihai
* lname: Spinei
* task:  devil
* score: 0.0
* date:  2019-10-10 10:39:29.551956
*/
#include <bits/stdc++.h>
#define fr first
#define sc second
#define pb push_back
#define ll long long
#define INF 1e9+7
#define LINF 1e18+7
#define pii pair<int,int>


using namespace std;
int t, k;
int d[10];
int rez[100005];
int rsz = 0;
vector <int> ques[100005];
int pr[100005];
int gr[100005];
int grt[100005];
int v[100005];

void solve(){
rsz = 0;
int maxim = 9;
while(rsz < k-1){
    while(d[maxim]==0)maxim--;
    if(d[maxim]>0){rez[rsz] = maxim; d[maxim]--;rsz++;}
}
while(d[maxim]==0 && maxim > 0)maxim--;
if(maxim != 0){
int lt = d[maxim];
int reset = 1 ,val = 1 , pos = 1 , sz = 1;
while(sz < k && val < maxim){
    if(d[val] <= 0 ){
        val ++;
        reset = pos;
        grt[pos] = 1;
    }else{
        ques[pos].pb(val);
        d[val]--;
        if(pos < lt){
            pos++;
        }else{
            pos = reset;
            sz++;
        }
    }
}
if(pos == lt){
cout << maxim;
for(int i = 0 ; i < ques[lt].size() ; i++){
    cout << ques[lt][i];
}
while( val < maxim){
    while(d[val]>0){
        cout << val;
        d[val]--;
    }
    if(d[val]==0)val++;
}
for(int q = 1 ; q < lt ; q++){
    cout << maxim;
    for(int i = 0 ; i < ques[q].size() ; i++)
    cout << ques[q][i];
}
for(int i = rsz - 1; i >= 0 ; i--){
    cout << rez[i];
}
for(int i = 1 ; i <= lt ; i++)
    ques[i].clear();
return ;
}
else{
    int T = reset - 1;
    int K = (lt - T + T - 1 )/(T);
    for(int i = 1 ; i <= T ; i++){
        cout << maxim;
        for(int j = 0 ; j <  ques[i].size() ; j++){
            cout << ques[i][j];
        }
        int rts = 1 ;
        while( rts <= T && K > 0){
            cout << maxim;
            for(int j = 0 ; j < ques[lt].size() ; j++){
                cout << ques[lt][j];
            }
            rts ++;
            K--;
        }
    }
    while(K > 0){
        cout << maxim;
            for(int j = 0 ; j < ques[lt].size() ; j++){
                cout << ques[lt][j];
            }
            K--;
    }
    for(int i = rsz - 1; i >= 0 ; i--)cout << rez[i];
}
}else{
    for(int i = rsz - 1; i >= 0 ; i--){
        cout << rez[i];
    }
    return ;
}

rsz = 0;
}

int main(){
    cin >> t;
    for(int i = 1 ; i <= t ; i++){
        cin >> k;
        for(int i = 1;  i <= 9 ;i++){
            cin >> d[i];
        }
        solve();
    }

}
