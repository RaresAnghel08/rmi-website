/**
* user:  karagyozov-c76
* fname: Ivo
* lname: Karagyozov
* task:  restore
* score: 0.0
* date:  2019-10-10 10:05:44.330098
*/
#include <bits/stdc++.h>

const int32_t MAX_M = 1e4;

struct Event {
	int32_t pos, type, req, ind;

	Event() {}
	Event(int32_t _pos, int32_t _type, int32_t _req, int32_t _ind) : pos(_pos), type(_type), req(_req), ind(_ind) {}

	bool operator< (const Event &e) const {
		if(pos != e.pos) {
			return pos < e.pos;
		}
		
		return type > e.type;
	}
};

int32_t m;
int32_t l[MAX_M + 5], r[MAX_M + 5], k[MAX_M + 5], val[MAX_M + 5];

int main() {
	std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);

	int32_t n;
	std::cin >> n >> m;

	for(int32_t i = 0; i < m; i++) {
		std::cin >> l[i] >> r[i] >> k[i] >> val[i];
	}
	
	std::vector< int32_t > v(n, -1);
	for(int32_t i = 0; i < m; i++) {
		if(k[i] == 1 && val[i] == 1) {
			for(int32_t j = l[i]; j <= r[i]; j++) {
				if(v[j] == 0) {
					std::cout << -1 << '\n';
					return 0;
				}
				
				v[j] = 1;
			}
		}
		else if(k[i] != 1 && val[i] == 0) {
			for(int32_t j = l[i]; j <= r[i]; j++) {
				if(v[j] == 1) {
					std::cout << -1 << '\n';
					return 0;
				}

				v[j] = 1;
			}
		}
	}

	std::vector< Event > ev;
	for(int32_t i = 0; i < m; i++) {
		if(k[i] == 1 && val[i] == 0) {
			ev.push_back(Event(l[i], 1, 0, r[i]));
			ev.push_back(Event(r[i] + 1, 2, 0, l[i]));
		}
		else if(k[i] != 1 && val[i] == 1) {
			ev.push_back(Event(l[i], 1, 1, r[i]));
			ev.push_back(Event(r[i] + 1, 2, 1, i));
		}
	}

	for(int32_t i = 0; i < n; i++) {
		ev.push_back(Event(i, 0, v[i], i));
	}

	std::sort(ev.begin(), ev.end());
	
	int32_t last[] = { -1, -1 };
	int32_t req[] = { n + 1, n + 1 };
	for(auto &x : ev) {
		if(x.type == 2) {
			if(last[x.req] < l[x.ind]) {
				std::cout << -1 << '\n';
				return 0;
			}
		}
		else if(x.type == 1) {
			req[x.req] = std::min(req[x.req], x.ind);	
		}
		else {
			if(x.req != -1) {
				last[x.req] = x.pos;
				req[x.req] = n + 1;
			}
			else {
				if(req[0] < req[1]) {
					v[x.pos] = 0;
					last[0] = x.pos;
					req[0] = n + 1;
				}
				else {
					v[x.pos] = 1;
					last[1] = x.pos;
					req[1] = n + 1;
				}
			}
		}
	}

	for(auto &x : v) {
		std::cout << x << " ";
	}
	std::cout << '\n';
}
