/**
* user:  mihov-a15
* fname: Rumen
* lname: Mihov
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:47:54.012605
*/
# include <bits/stdc++.h>

using namespace std;
const long long MOD=1e9+7;
long long a[100005];
long long all=0;
long long ans[100005];
long long no,one,no1,one1,br;
void solve(int n)
{
    ans[0]=1;
    no = 1;
    one = 0;
    int i;
    for(i=1;i<=n;i++)
    {
        no1 = ((no*(9))%MOD+(one*8)%MOD)%MOD;
        one1 = (no+one)%MOD;
        no=no1;
        one=one1;
        ans[i]=(no+one)%MOD;
       // cout<<i<<"**"<<ans[i]<<endl;
    }
}
void query(int l, int r)
{
    all=0;
int i,j;
        for(j=l;j<=r;j++)
        {
          //  if((j==l)||(a[j-1]!=1)||(a[j]<=3))
 all = (all + (ans[r-j]*a[j])%MOD)%MOD; if(a[j]>1&&(r-j-1)>=0){all = (all + MOD - ans[r-j-1])%MOD; }
 if(j>l&&a[j-1]==3&&a[j]>3)
 {

    all = (all + MOD - ans[r-j])%MOD;}
 if(j>l&&a[j]==3&&a[j-1]==1)break;}


if(j>r)all=(all+1)%MOD;
        cout<<(all)%MOD<<endl;
        return ;
}
int main()
{
ios_base::sync_with_stdio(false);
cin.tie(nullptr);
cout.tie(nullptr);
int n,q,i,j,t,l,r;
cin>>n>>q;
char ch;
solve(n);
for(i=1;i<=n;i++)
{
    cin>>ch;
    a[i]=ch-'0';
}
query(1,n);


for(i=1;i<=q;i++)
{
    cin>>t>>l>>r;
    if(t==2)a[l]=r;
    else
    {

query(l,r);
    }
}
}
/*
6 10
560484
2 6 4
2 1 4
2 5 6
2 6 1
2 3 6
1 3 6

*/

