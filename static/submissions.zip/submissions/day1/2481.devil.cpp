/**
* user:  bartoli-2aa
* fname: Davide
* lname: Bartoli
* task:  devil
* score: 0.0
* date:  2019-10-10 09:22:34.476413
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<ll>a(10);
vector<ll>pot;
ll prossimo(){
    for(ll i=9;i>0;i--){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
ll primo(){
    for(ll i=1;i<10;i++){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    pot.push_back(1);
    for(ll i=0;i<19;i++)pot.push_back((pot[i]*10));
    ll T;
    cin>>T;
    while(T--){
        ll K;
        cin>>K;
        fill(a.begin(),a.end(),0);
        ll tot=0;
        for(ll i=1;i<10;i++){
            cin>>a[i];
            tot+=a[i];
        }
        vector<ll>sol(tot,0);
        for(ll i=tot-1;i>tot-K;i--){
            sol[i]=prossimo();
        }
        vector<ll>p;
        for(ll i=1;i<10;i++){
            for(ll j=0;j<a[i];j++)p.push_back(i);
        }
        ll u=p.size();
        ll mi=1000000000000000;
        for(ll i=tot-K+1;i<tot;i++)p.push_back(sol[i]);
        while(next_permutation(p.begin(),p.begin()+u)){
            ll minimo=0;
            ll f=0;
            for(ll i=0;i<K;i++){
                f*=10;
                f+=p[i];
            }
            minimo=max(minimo,f);
            for(ll i=K;i<tot;i++){
                f-=p[i-K]*pot[K-1];
                f*=10;
                f+=p[i];
                minimo=max(minimo,f);
            }
            if(minimo<mi){
                mi=minimo;
                for(ll i=0;i<u;i++){
                    sol[i]=p[i];
                }
            }
        }
        for(ll i=0;i<tot;i++)cout<<sol[i];
        cout<<endl;
    }
    return 0;
}
