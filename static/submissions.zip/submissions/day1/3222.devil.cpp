/**
* user:  kozhuharov-9a5
* fname: Viktor
* lname: Kozhuharov
* task:  devil
* score: 27.0
* date:  2019-10-10 10:39:33.226409
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e5 + 7;

int a[11];
vector<string> v;
bool used[MAXN];

void solve(){
    int k;
    cin >> k;

    v.clear();
    //v.push_back("");
    string start = "";

    int n = 0;
    for(int i = 1; i < 10; ++i){
        cin >> a[i];
        n += a[i];
    }
    for(int i = 0; i < n; ++i){
        used[i] = false;
    }

    int x = k - 1, big;
    for(int i = 9; i >= 1; --i){
        if(a[i] > x){
            for(int j = x - 1; j >= 0; --j){
                start += i + '0';
            }
            a[i] -= x;
            big = i;
            break;
        }
        else{
            x -= a[i];
            for(int j = a[i] - 1; j >= 0; --j){
                start += i + '0';
            }
            a[i] = 0;
        }
    }

    reverse(start.begin(), start.end());

    n -= k - 1;
    int cnt_big = a[big];

    while(a[big]){
        string t = "";
        t += big + '0';
        v.push_back(t);
        --a[big];
    }

    //cout << v.size() << endl;

    int idx = 1, curr = -1, best;
    int left_cnt = (int)v.size(), left_cnt_2 = 0;
    while(idx < 10){
        while(a[idx] == 0 && idx < 10){
            ++idx;
        }
        if(idx == 10){
            break;
        }

        ++curr;
        while(true){
            //cout << curr << endl;
            if(curr >= (int)v.size()){
                curr = 0;
                left_cnt = left_cnt_2;
                left_cnt_2 = 0;
            }
            if(used[curr]){
                ++curr;
            }
            else{
                break;
            }
        }
        if(curr == 0){
            best = idx;
        }
        if(a[idx] < left_cnt){
            used[curr] = true;
        }
        else{
            ++left_cnt_2;
        }
        --left_cnt;

        //cout << left_cnt << " " << left_cnt_2 <<endl;
        //cout << curr << " - " << idx << endl;

        v[curr] += idx + '0';
        --a[idx];
    }

    int cntv = (int)v.size();

    if(left_cnt == 0){
        left_cnt = left_cnt_2;
    }

    //cout << left_cnt << endl;

    vector<int> cnt_one;

    for(int i = 0; i < cntv; ++i){
        cnt_one.push_back(v[i].size() - 1);
    }

    for(int i = cntv - left_cnt; i <= cntv - 1; ++i){
        cout << v[i];

        int j;
        for(j = i - left_cnt; j >= 0; j -= left_cnt){
        }
        j += left_cnt;
        for(; j < i; j += left_cnt){
            cout << v[j];
        }
    }
    cout << start;
    cout << "\n";
}

int main(){
    //ios::sync_with_stdio(false);
    //cin.tie(NULL);

    int t;

    cin >> t;

    while(t--){
        solve();
    }

    return 0;
}
/*
3
2
1 1 2 0 0 0 0 0 0
7
2 4 2 0 0 6 2 2 2
7
3 3 4 0 0 6 2 2 2

*/
/*
1
4
2 3 0 0 0 0 0 0 0
*/
/*
1
2
3 1 2 0 1 2 0 5 1
*/
/*
1
3
5 10 0 0 0 0 0 0 0
*/
/*
1
3
3 4 0 0 0 0 0 0 0
*/

