/**
* user:  lendvaj-f75
* fname: Dorijan
* lname: Lendvaj
* task:  lucky
* score: 28.0
* date:  2019-10-10 08:54:30.415257
*/
#include <bits/stdc++.h>
#pragma GCC optimize("unroll-loops")
#define x first
#define y second
#define pii pair<int,int>
#define vi vector<int>
using ll=long long;
#define vl vector<ll>
#define pb push_back
#define eb emplace_back
using ld=long double;
using namespace std;

const int N=100010,M=1<<17,MOD=1000000007;
ll seg[M*2+10][6],dp1[N][6];
//0: end with not 1
//1: end with 1
//2: anything
//3: start with not 3
//4: start with not 3,end with not 1
//5: start with not 3,end with 1
//less, not less or equal smh
bool ok[M*2+10];
int n,q;
string h;
const char en='\n';

array<ll,7> mer(array<ll,7> a,array<ll,7> b,int lo,int mid,int hi)
{
	if (mid>=hi)
	{
		return a;
	}
	if (lo>=mid)
	{
		return b;
	}
	int lb=hi-mid;
	array<ll,7> r={0,0,0,0,0,0,a[6] && b[6] && !(h[mid-1]=='1' && h[mid]=='3')};
	if (h[mid-1]!='1')
	{
		r[0]=a[0]*dp1[lb][0]+a[1]*dp1[lb][4]+b[0]*a[6];
		r[2]=a[0]*dp1[lb][2]+a[1]*dp1[lb][3]+b[2]*a[6];
		r[3]=a[4]*dp1[lb][2]+a[5]*dp1[lb][3]+b[2]*a[6];
		r[4]=a[4]*dp1[lb][0]+a[5]*dp1[lb][4]+b[0]*a[6];
		r[1]=r[2]-r[0];
		r[5]=r[3]-r[4];
		for (int j=0;j<6;++j)
		{
			r[j]%=MOD;
			r[j]+=MOD;
			r[j]%=MOD;
		}
	}
	else
	{
		r[0]=a[0]*dp1[lb][0]+a[1]*dp1[lb][4]+b[4]*a[6];
		r[2]=a[0]*dp1[lb][2]+a[1]*dp1[lb][3]+b[3]*a[6];
		r[3]=a[4]*dp1[lb][2]+a[5]*dp1[lb][3]+b[3]*a[6];
		r[4]=a[4]*dp1[lb][0]+a[5]*dp1[lb][4]+b[4]*a[6];
		r[1]=r[2]-r[0];
		r[5]=r[3]-r[4];
		for (int j=0;j<6;++j)
		{
			r[j]%=MOD;
			r[j]+=MOD;
			r[j]%=MOD;
		}
	}
	return r;
}

void up(int i,int mid,int hi)
{
	if (mid>=hi)
	{
		ok[i]=ok[i*2];
		for (int j=0;j<6;++j) seg[i][j]=seg[i*2][j];
		return;
	}
	ok[i]=ok[i*2] && ok[i*2+1] && !(h[mid-1]=='1' && h[mid]=='3');
	int lb=hi-mid;
	if (h[mid-1]!='1')
	{
		seg[i][0]=seg[i*2][0]*dp1[lb][0]+seg[i*2][1]*dp1[lb][4]+seg[i*2+1][0]*ok[i*2];
		seg[i][2]=seg[i*2][0]*dp1[lb][2]+seg[i*2][1]*dp1[lb][3]+seg[i*2+1][2]*ok[i*2];
		seg[i][3]=seg[i*2][4]*dp1[lb][2]+seg[i*2][5]*dp1[lb][3]+seg[i*2+1][2]*ok[i*2];
		seg[i][4]=seg[i*2][4]*dp1[lb][0]+seg[i*2][5]*dp1[lb][4]+seg[i*2+1][0]*ok[i*2];
		seg[i][1]=seg[i][2]-seg[i][0];
		seg[i][5]=seg[i][3]-seg[i][4];
		for (int j=0;j<6;++j)
		{
			seg[i][j]%=MOD;
			seg[i][j]+=MOD;
			seg[i][j]%=MOD;
		}
	}
	else
	{
		seg[i][0]=seg[i*2][0]*dp1[lb][0]+seg[i*2][1]*dp1[lb][4]+seg[i*2+1][4]*ok[i*2];
		seg[i][2]=seg[i*2][0]*dp1[lb][2]+seg[i*2][1]*dp1[lb][3]+seg[i*2+1][3]*ok[i*2];
		seg[i][3]=seg[i*2][4]*dp1[lb][2]+seg[i*2][5]*dp1[lb][3]+seg[i*2+1][3]*ok[i*2];
		seg[i][4]=seg[i*2][4]*dp1[lb][0]+seg[i*2][5]*dp1[lb][4]+seg[i*2+1][4]*ok[i*2];
		seg[i][1]=seg[i][2]-seg[i][0];
		seg[i][5]=seg[i][3]-seg[i][4];
		for (int j=0;j<6;++j)
		{
			seg[i][j]%=MOD;
			seg[i][j]+=MOD;
			seg[i][j]%=MOD;
		}
	}
}

void build(int l,int r,int lo=0,int hi=M,int i=1)
{
	if (lo>=r || hi<=l) return;
	if (i>=M)
	{
		ok[i]=1;
		int u=h[i-M]-'0';
		seg[i][0]=u-(u>1);
		seg[i][2]=u;
		seg[i][1]=u>1;
		seg[i][3]=u-(u>3);
		seg[i][5]=u>1;
		seg[i][4]=u-(u>3)-(u>1);
		return;
	}
	int mid=(lo+hi)/2;
	build(l,r,lo,mid,i*2);
	build(l,r,mid,hi,i*2+1);
	up(i,mid,min(hi,n));
}

array<ll,7> get(int l,int r,int lo=0,int hi=M,int i=1)
{
	if (lo>=r || hi<=l) return {0,0,0,0,0,0,1};
	if (lo>=l && hi<=r)
	{
		return {seg[i][0],seg[i][1],seg[i][2],seg[i][3],seg[i][4],seg[i][5],ok[i]};
	}
	int mid=(lo+hi)/2;
	array<ll,7> a=get(l,r,lo,mid,i*2);
	array<ll,7> b=get(l,r,mid,hi,i*2+1);
	return mer(a,b,max(lo,l),mid,min(hi,r));
}

void upd(int l,int r,char x,int lo=0,int hi=M,int i=1)
{
	if (i==l+M)
	{
		h[i-M]=x;
		int u=h[i-M]-'0';
		seg[i][0]=u-(u>1);
		seg[i][2]=u;
		seg[i][1]=u>1;
		seg[i][3]=u-(u>3);
		seg[i][5]=u>1;
		seg[i][4]=u-(u>3)-(u>1);
		return;
	}
	if (lo>=r || hi<=l) return;
	int mid=(lo+hi)/2;
	upd(l,r,x,lo,mid,i*2);
	upd(l,r,x,mid,hi,i*2+1);
	up(i,mid,min(n,hi));
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin>>n>>q>>h;
	dp1[1][0]=9;
	dp1[1][1]=1;
	dp1[1][2]=10;
	dp1[1][3]=9;
	dp1[1][4]=8;
	dp1[1][5]=1;
	dp1[0][2]=dp1[0][0]=dp1[0][3]=dp1[0][4]=1;
	for (int i=2;i<=n;++i)
	{
		//int a=i/2,b=(i+1)/2;
		int a=1,b=i-1;
		dp1[i][0]=dp1[a][0]*dp1[b][0]+dp1[a][1]*dp1[b][4];
		dp1[i][2]=dp1[a][0]*dp1[b][2]+dp1[a][1]*dp1[b][3];
		dp1[i][3]=dp1[a][4]*dp1[b][2]+dp1[a][5]*dp1[b][3];
		dp1[i][4]=dp1[a][4]*dp1[b][0]+dp1[a][5]*dp1[b][4];
		dp1[i][1]=dp1[i][2]-dp1[i][0];
		dp1[i][5]=dp1[i][3]-dp1[i][4];
		for (int j=0;j<6;++j)
		{
			dp1[i][j]%=MOD;
			dp1[i][j]+=MOD;
			dp1[i][j]%=MOD;
		}
	}
	build(0,n);
	array<ll,7> res=get(0,n);
	cout<<(res[2]+res[6])%MOD<<en;
	while (q--)
	{
		int t,l,r;
		cin>>t>>l>>r;
		--l;
		if (t==1)
		{
			array<ll,7> res=get(l,r);
			cout<<(res[2]+res[6])%MOD<<en;
		}
		else
		{
			upd(l,l+1,r+'0');
		}
	}
	
}
