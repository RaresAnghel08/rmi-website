/**
* user:  khamitov-0d0
* fname: Tagir
* lname: Khamitov
* task:  lucky
* score: 14.0
* date:  2019-10-10 09:09:28.610059
*/
#include <bits/stdc++.h>

#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define f first
#define s second
#define size(x) (int)x.size()

using namespace std;

typedef long long ll;
typedef long double ld;

void io() {
#ifdef MLOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
}

const ll MOD = 1000000007;

void solve() {
    vector<ll> st(100009);
    st[0] = 1;
    for(int i = 1; i < 100009; i++) {
        st[i] = st[i - 1] * 10;
        st[i] %= MOD;
    }
    int n, q;
    cin >> n >> q;
    vector<int> a(n);
    string s;
    cin >> s;
    for(int i = 0; i < n; i++) {
        a[i] = s[i] - '0';
    }
    vector<vector<ll>> dp(n, vector<ll>(10));
    for(int i = 0; i < 10; i++) {
        dp[0][i] = 0;
    }
    for(int i = 1; i < n; i++) {
        for(int j = 0; j < 10; j++) {
            for(int k = 0; k < 10; k++) {
                dp[i][j] += dp[i - 1][k];
                if(j == 1 && k == 3) {
                    dp[i][j] -= dp[i - 1][k];
                    dp[i][j] += st[i - 1];
                }
                dp[i][j] %= MOD;
            }
        }
    }
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < 10; j++) {
            cout << dp[i][j] << " ";
        }
        cout << "\n";
    }
    for(int i = 0; i < n; i++) {
        for(int j = 1; j < 10; j++) {
            dp[i][j] += dp[i][j - 1];
            dp[i][j] %= MOD;
        }
    }
    ll ans = 0;
    for(int i = 0; i < n; i++) {
        if(a[i] > 0) {
            ans += dp[n - i - 1][a[i] - 1];
            ans %= MOD;
        }
    }
    ans--;
    ll num = 0;
    for(int i = 0; i < n; i++) {
        num *= 10;
        num += a[i];
        num %= MOD;
    }
    ans = num - ans;
    ans %= MOD;
    if(ans < 0) {
        ans += MOD;
    }
    cout << ans << "\n";
    while(q--) {
        int t;
        cin >> t;
        if(t == 1) {
            int l, r;
            cin >> l >> r;
            l--;
            r--;
            num = 0;
            ans = 0;
            for(int i = l; i <= r; i++) {
                num *= 10;
                num += a[i];
                num %= MOD;
                if(a[i] > 0) {
                    ans += dp[r - i][a[i] - 1];
                    ans %= MOD;
                }
            }
            ans = num - ans + 1;
            ans %= MOD;
            if(ans < 0) {
                ans += MOD;
            }
            cout << ans << "\n";
        }else {
            int pos, nw;
            cin >> pos >> nw;
            a[pos - 1] = nw;
        }
    }
}

bool good(int n) {
    vector<int> a;
    while(n) {
        a.push_back(n % 10);
        n /= 10;
    }
    for(int i = 1; i < size(a); i++) {
        if(a[i - 1] == 3 && a[i] == 1) {
            return true;
        }
    }
    return false;
}

void solve1() {
    int n;
    cin >> n;
    cin >> n;
    cin >> n;
    int ans = 0;
    for(int i = 0; i <= n; i++) {
        if(!good(i)) {
            ans++;
        }
    }
    cout << ans;
}

int main() {
    io();
    //solve();
    solve1();
    return 0;
}
