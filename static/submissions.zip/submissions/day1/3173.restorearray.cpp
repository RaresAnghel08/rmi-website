/**
* user:  nanu-c77
* fname: Ruxandra Laura
* lname: Nanu
* task:  restore
* score: 7.0
* date:  2019-10-10 10:37:25.980796
*/
#include <cstdio>

using namespace std;
struct idk{
    int a,b,c,d;
} r[210];
int v[20],sp[20];
int main()
{
    FILE *fin = stdin;
    FILE *fout = stdout;
    int n,m,i,elem,x,ok,j;
    fscanf (fin,"%d%d",&n,&m);
    for (i=1;i<=m;i++){
        fscanf (fin,"%d%d%d%d",&r[i].a,&r[i].b,&r[i].c,&r[i].d);
        r[i].a++;
        r[i].b++;
    }
    if (n<=18){
        for (i=0;i<(1<<n);i++){
            elem = 0;
            x = i;
            for (j=1;j<=n;j++){
                v[++elem] = x%2;
                sp[elem] = (v[elem] == 0) + sp[elem-1];
                x/=2;
            }

            ok = 1;

            for (j=1;j<=m;j++){
                x = sp[r[j].b] - sp[r[j].a-1];
                if (r[j].d == 0){
                    if (x < r[j].c)
                        ok = 0;
                }
                else {
                    if (x >= r[j].c)
                        ok = 0;
                }
            }

            if (ok){
                for (j=1;j<=n;j++)
                    fprintf (fout,"%d ",v[j]);
                break;
            }

        }
        if (i == (1<<n))
            fprintf (fout,"-1");
    }
    return 0;
}
