/**
* user:  melnyk-1f2
* fname: Sofiia
* lname: Melnyk
* task:  restore
* score: 20.0
* date:  2019-10-10 06:08:47.002967
*/
#include<bits/stdc++.h>
using namespace std;

const int N = 1e6 + 11;

int a[N],b[N],c[N];
int l1[N],r1[N],k1[N],t1[N];

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n,m;
    cin>>n>>m;
    for (int i=1; i<=n; i++)
        a[i]=-1;
    int mm=0;
    for (int i=1; i<=m; i++)
    {
        int l,r,k,t;
        cin>>l>>r>>k>>t;
        l++;
        r++;
        if (k==r-l+1&&t==0)
        {
            for (int j=l; j<=r; j++)
                if (a[j]==-1||a[j]==0) a[j]=0; else return cout<<-1,0;
        } else
        if (k==1&&t==1)
        {
            for (int j=l; j<=r; j++)
                if (a[j]==-1||a[j]==1) a[j]=1; else return cout<<-1,0;
        } else
        {
            mm++;
            l1[mm]=l;
            r1[mm]=r;
            k1[mm]=k;
            t1[mm]=t;
        }
    }
    m=mm;
    int nn=0;
    for (int i=1; i<=n; i++)
        if (a[i]==-1) nn++;
    for (int p=0; p<(1<<nn); p++)
    {
        int ks=0;
        for (int i=1; i<=n; i++)
        {
            if (a[i]==-1) {b[i]=0; if (p&(1<<ks)) b[i]=1; ks++;} else b[i]=a[i];
            c[i]=c[i-1]+(b[i]==0);
        }
        int h=0;
        for (int i=1; i<=m; i++)
            if (t1[i]==0)
        {
            if (c[r1[i]]-c[l1[i]-1]<k1[i]) h=1;
        } else
        {
            if (c[r1[i]]-c[l1[i]-1]>=k1[i]) h=1;
        }
        if (h==0)
        {
            for (int i=1; i<=n; i++)
                cout<<b[i]<<" ";
            cout<<endl;
            exit(0);
        }
    }
    cout<<-1;
}
