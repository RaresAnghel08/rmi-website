/**
* user:  puzic-97a
* fname: Mladen
* lname: Puzic
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:32:49.227104
*/
#include <bits/stdc++.h>
#define PRINT(x) cerr<<#x<<'='<<x<<endl
#define NL(x) " \n"[(x)]
#define sz(x) int((x).size())
#define all(x) begin(x),end(x)
#define mid (l+r)/2
#define fi first
#define se second
#define endl '\n'
#define lld long long
#define pii pair<int,int>
#define pli pair<lld,int> 
#define pil pair<int,lld>
#define pll pair<lld,lld>
#define INF 1000000000
#define LINF 1000000000000000000LL
#define EPS 1e-9
using namespace std;
#define MOD 1000000007
#define MAXN 100010
int N, Q; 
lld dp[MAXN], dp3[MAXN], st[MAXN], hsh;
string X;
lld solve(int l, int r) {
	lld rez = 0;
	for(int i = l; i <= r; i++) {
		int kol = r-i;
		if(X[i] == '0') continue;
		else if(X[i] == '1') rez += dp[kol];
		else if(X[i] == '2' || X[i] == '3') {
			rez += dp3[kol] + (X[i]-'0'-1)*dp[kol];
		} else {
			if(X[i-1] == '1') {
				rez += dp3[kol] + (X[i]-'0'-2)*dp[kol];
			} else {
				rez += dp3[kol] + (X[i]-'0'-1)*dp[kol];
			}
		}
		if(rez >= MOD) rez %= MOD;
		if(X[i] == '3' && X[i-1] == '1') break;
	}
	return (rez+1)%MOD;
}
int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0); cerr.tie(0);
	cin >> N >> Q;
	dp[0] = dp3[0] = st[0] = 1;
	for(int i = 1; i < MAXN; i++) {
		st[i] = st[i-1]*10;
		if(st[i] >= MOD) st[i] %= MOD;

		dp[i] = st[i] - hsh;
		if(dp[i] < 0) dp[i] += MOD;

		dp3[i] = dp[i]-dp[i-1];
		if(dp3[i] < 0) dp3[i] += MOD;

		hsh = hsh*10 + dp[i-1];
		if(hsh >= MOD) hsh %= MOD;

		PRINT(st[i]);
		PRINT(dp[i]);
		PRINT(dp3[i]);
		PRINT(hsh);
	}
	cin >> X;
	X = '#'+X;
	cout << solve(1, N) << endl;
	while(Q--) {
		int t; cin >> t;
		if(t == 1) {
			int L, R; cin >> L >> R;
			cout << solve(L, R) << endl;
		} else {
			int idx, digit; cin >> idx >> digit;
			X[idx] = (digit+'0');
		}
	}
	return 0;
}
/*
6 10
560484
2 6 4
2 1 4
2 5 6
2 6 1
2 3 6
1 3 6
1 1 3
1 6 6
1 2 6
2 1 7
*/