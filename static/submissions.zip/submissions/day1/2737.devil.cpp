/**
* user:  coroian-5c7
* fname: David Nicolae
* lname: Coroian
* task:  devil
* score: 0.0
* date:  2019-10-10 09:53:44.091966
*/
#include <bits/stdc++.h>
//#include <fstream>
//#include <string>


using namespace std;

//ifstream cin("txt.in");
//ofstream cout("txt.out");

typedef long long lint;

int k;
int d[10];

string s;
string b;

int n;
string rez;

void init()
{
    n = 0;
    for(int i = 1; i <= 9; i ++)
        n += d[i];

    s.resize(n);
    b.resize(n);
    rez.resize(n);
}


void afis()
{
    for(int i = 0; i < n; i ++)
        s[i] += '0';

    cout << s << "\n";
}
void af(string s)
{
    for(int i = 0; i < n; i ++)
        s[i] += '0';

    cout << s << "\n";
}

lint MN;
lint CR;
lint CRN;
lint p10;

int a[10];


void verif()
{/*
    cout << " INTRU VERIF " << "\n";
    for(int i = 0 ;i < n; i ++)
        cout << (int)s[i];
    cout << "\n";
*/
    if(CRN < MN)
    {
        //cout << CRN << "\n";
        MN = CRN;
        rez = s;
        //for(int i = 0; i < n; i ++)
          //  rez[i] =
    }
}

void bkt(int kx)
{
   // cout << " SUNTEM " << kx << " " << CRN << " " << CR << " " << n - k + 1 << "\n";
   // af(s);
    //cout << "\n";

    if(kx == n - k + 1)
    {
            lint acr = CR;
            lint acrn = CRN;
        CR = (CR * 10 + s[kx]) % p10;
        CRN = max(CRN, CR);
        verif();

        CR = acr;
        CRN = acrn;

        return;
    }

    for(int i = 1; i <= 4; i ++)
    {
        if(a[i] > 0)
        {
            lint acr = CR;
            lint acrn = CRN;
            a[i] --;
            s[kx] = i;

            CR = (CR * 10 + s[kx]) % p10;
            CRN = max(CRN, CR);


            if(CRN < MN)
                bkt(kx + 1);

            a[i] ++;
            CR = acr;
            CRN = acrn;
        }
    }
}

void solve34()
{

   // cout << "INTRA\n";

    //return;

    int cr = 0;

    for(int i = 1; i <= 9; i ++)
    {
        for(int j = 1; j <= d[i]; j ++)
        {
            b[cr] = i;
            cr ++;
        }
    }

    if(k == 1 || k == n)
    {
        s = b;
        afis();

        return;
    }
/*
    char chr = b[n - k];
    for(int i = n - k; i >= 1; i --)
        b[i] = b[i - 1];
    b[0] = chr;*/

    for(int i = 0; i < n; i ++)
        s[i] = b[i];

   // af(s);

    p10 = 1;
    for(int i = 1; i <= k; i ++)
        p10 = p10 * 10;


    MN = p10 * 10;

    //af(s);

   // CR = s[0];
   //cout << "INRA BACK\n";

   // af(s);

    for(int i = 1; i <= 9; i ++)
        a[i] = d[i];

  //  a[s[0]] --;
    for(int i = n - k + 1; i < n; i ++)
        a[s[i]] --;
/*
    for(int i = 1; i < 5; i ++)
        cout << a[i] << " " ;
    cout << "\n";*/
//
   // af(s);

    bkt(0);

    for(int i = 0; i < n; i ++)
        rez[i] += '0';

    cout << rez << "\n";
}

void ansQues()
{
    int q;
    cin >> q;
    while(q > 0)
    {
        q --;

        cin >> k;

        for(int i = 1; i <= 9; i ++)
            cin >> d[i];

        init();

        if(d[1] + d[2] + d[3] + d[4] == n)
        {
            solve34();
        }


    }
}

int main()
{
    ansQues();

    return 0;
}
