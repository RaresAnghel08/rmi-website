/**
* user:  todoran-c08
* fname: Alexandru Raul
* lname: Todoran
* task:  restore
* score: 0.0
* date:  2019-10-10 09:25:29.850773
*/
#include <bits/stdc++.h>

using namespace std;

const int N_MAX = 5002;
const int M_MAX = 10002;

int n, m;

struct res
{
    int l, r, k;
    bool val;
};

bool operator < (const res &a, const res &b)
{
    return make_pair(a.l, a.r) < make_pair(b.l, b.r);
}

res v[M_MAX];

int a[N_MAX];

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        cin >> v[i].l >> v[i].r >> v[i].k >> v[i].val;
        v[i].l++;
        v[i].r++;
    }
    sort(v + 1, v + m + 1);
    memset(a, -1, sizeof(a));
    for(int i = 1; i <= m; i++)
    {
        if(v[i].k == 1)
        {
            if(v[i].val == 1)
            {
                for(int j = v[i].l; j <= v[i].r; j++)
                    a[j] = 1;
            }
        }
        else
        {
            if(v[i].val == 0)
            {
                for(int j = v[i].l; j <= v[i].r; j++)
                    a[j] = 0;
            }
        }
    }
    for(int i = 1; i <= m; i++)
    {
        bool ok = false;
        int s = 0;
        for(int j = v[i].l; j <= v[i].r; j++)
        {
            if(a[j] != -1)
                ok = true;
            s += a[j];
        }
        if(v[i].k == 1)
        {
            if(v[i].val == 0)
            {
                if(ok == false)
                {
                    if(s == v[i].r - v[i].l + 1)
                    {
                        cout << "-1\n";
                        return 0;
                    }
                }
                else
                {
                    for(int j = v[i].l; j <= v[i].r; j++)
                        if(a[j] == -1)
                        {
                            a[j] = 0;
                            break;
                        }
                }
            }
            else
            {
                if(s != v[i].r - v[i].l + 1)
                {
                    cout << "-1\n";
                    return 0;
                }
            }
        }
        else
        {
            if(v[i].val == 1)
            {
                if(ok == false)
                {
                    if(s != v[i].r - v[i].l + 1)
                    {
                        cout << "-1\n";
                        return 0;
                    }
                }
                else
                {
                    for(int j = v[i].l; j <= v[i].r; j++)
                        if(a[j] == -1)
                        {
                            a[j] = 1;
                            break;
                        }
                }
            }
            else
            {
                if(s != 0)
                {
                    cout << "-1\n";
                    return 0;
                }
            }
        }
    }
    for(int i = 1; i <= n; i++)
        cout << a[i] << " ";
    cout << "\n";
    return 0;
}
