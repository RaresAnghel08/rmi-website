/**
* user:  danailov-cda
* fname: Daniel
* lname: Danailov
* task:  restore
* score: 7.0
* date:  2019-10-10 06:24:51.000417
*/
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int N=5005;

int n,m;
bool found;
int a[N],l[N],r[N],ind[N],value[N];

void Solve()
{
 int i,j,x,limit,mask;
 vector <int> v;
 bool fl;

 limit=(1<<n);
  for(mask=0;mask<limit;mask++)
  {
   x=mask;
    for(i=1;i<=n;i++)
    {
     a[i]=x%2;
     x/=2;
    }

   fl=true;
    for(i=1;i<=m;i++)
    {
     v.clear();
      for(j=l[i];j<=r[i];j++)
       v.push_back(a[j]);

     sort(v.begin(),v.end());

      if(v[ind[i]-1]!=value[i])
      {
       fl=false;
       break;
      }
    }

    if(fl)
    {
     found=true;
     return;
    }
  }
}

void Subtask2()
{
 int i,j;
 bool ok;

  for(i=1;i<=m;i++)
  {
    if(value[i]==1)
    {
      for(j=l[i];j<=r[i];j++)
       a[j]=1;
    }
  }

  for(i=1;i<=m;i++)
  {
    if(value[i]==1)
     continue;

   ok=false;
    for(j=l[i];j<=r[i];j++)
    {
     if(a[j]==0)
     {
      ok=true;
      break;
     }
    }

    if(!ok)
     return;
  }

 found=true;
}

int main()
{

ios::sync_with_stdio(false);
cin.tie(nullptr);

int i;
bool ones;

cin>>n>>m;

ones=true;
 for(i=1;i<=m;i++)
 {
  cin>>l[i]>>r[i]>>ind[i]>>value[i];
  l[i]++;
  r[i]++;

   if(ind[i]!=1)
    ones=false;
 }

 if(n<=18)
 {
  Solve();

   if(found)
   {
     for(i=1;i<=n;i++)
      cout<<a[i]<<" ";

    cout<<"\n";
    return 0;
   }

  cout<<-1<<"\n";
  return 0;
 }

 if(ones)
 {
  Subtask2();

   if(found)
   {
     for(i=1;i<=n;i++)
      cout<<a[i]<<" ";

    cout<<"\n";
    return 0;
   }

  cout<<-1<<"\n";
  return 0;
 }
}
