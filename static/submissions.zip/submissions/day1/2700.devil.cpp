/**
* user:  efremov-95c
* fname: Andrei
* lname: Efremov
* task:  devil
* score: 14.0
* date:  2019-10-10 09:49:17.385503
*/
#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <deque>
#include <iomanip>
#include <cassert>
#define rep(i, n) for (int i = 0; i < (n); i++)
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()

using namespace std;
using ll = long long;
using ul = unsigned long long;
using ld = long double;

const int D = 10;
int d[D];

deque<int> cat(deque<int> a) {
	if (a.back() == a.front())
		return a;
	vector<vector<int>> fl;
	int fd = a.back();
	while (a.back() == fd) {
		fl.push_back({a.back()});
		a.pop_back();
	}
	int sz = fl.size();
	while (!a.empty()) {
		int pos = sz;
		if (a.size() <= sz) {
			for (int i : a)
				fl[--pos].push_back(i);
			a.clear();
		}
		else {
			rep(i, sz) {
				fl[sz - 1 - i].push_back(a[0]);
				a.pop_front();
			}
			while (fl[sz - 1].back() != fl[0].back())
				sz--;
		}
	}
	deque<int> num(fl.size()), lp(fl.size());
	int cn = 0;
	rep(i, fl.size()) {
		if (i > 0 && fl[i].back() != fl[i - 1].back())
			cn++;
		num[i] = cn;
		lp[cn] = i;
	}
	reverse(all(num));
	deque<int> rs = cat(num), ans;
	rep(i, fl.size())
		for (int j : fl[i])
			ans.push_back(j);
	return ans;
}

int main() {
#ifdef ONPC
	freopen("a.in", "r", stdin);
#endif
	ios_base::sync_with_stdio(0); cin.tie(0);
	int t, k;
	cin >> t;
	rep(z, t) {
		cin >> k;
		deque<int> a, b;
		for (int i = 1; i < D; i++) {
			cin >> d[i];
			rep(j, d[i])
				a.push_back(i);
		}
		int n = a.size();
		rep(i, k - 1) {
			d[a.back()]--;
			b.push_back(a.back());
			a.pop_back();
		}
		/*int fd = a.back();
		reverse(all(b));
		int sz = d[fd];
		while (!a.empty() && a.back() == fd)
			a.pop_back();
		vector<vector<int>> fl(sz, {fd});
		while (!a.empty()) {
			int pos = sz;
			if (a.size() <= sz) {
				for (int i : a)
					fl[--pos].push_back(i);
				a.clear();
			}
			else {
				rep(i, sz) {
					fl[sz - 1 - i].push_back(a[0]);
					a.pop_front();
				}
				while (fl[sz - 1].back() != fl[0].back())
					sz--;
			}
		}*/
		/*if (a.size() == d[fd]) {
			for (int i : a)
				cout << i;
			for (int i : b)
				cout << i;
			cout << '\n';
			continue;
		}
		int sd = a[d[fd] - 1];
		int lx = 0;
		rep(i, a.size()) {
			int md = (lx == fd ? sd : 9);
			while (!d[md])
				md--;
			cout << md;
			d[md]--;
			lx = md;
		}*/
		/*for (auto &pp : fl)
			for (int i : pp)
				cout << i;*/
		reverse(all(b));
		deque<int> res = cat(a);
		for (int i : res)
			cout << i;
		for (int i : b)
			cout << i;
		cout << '\n';
	}
}
