/**
* user:  enache-10e
* fname: Alexandru
* lname: Enache
* task:  restore
* score: 20.0
* date:  2019-10-10 09:17:45.829012
*/
//ALEX ENACHE

#include <bits/stdc++.h>

using namespace std;

int n , m;

struct qr{
    int l , r , k , val;
};

qr q[10100];

void brut(){

    for (int mask = 0 ; mask < (1 << n); mask++){
        int ok = 1;
        for (int i=1; i<=m; i++){
            int one = 0;
            for (int j=q[i].l; j<=q[i].r; j++){
                if (mask & (1 << j)){
                    one++;
                }
            }
            int zero = q[i].r - q[i].l + 1 - one;
            if (q[i].val == 0){
                if (zero < q[i].k){
                    ok = 0;
                    break;
                }
            }
            if (q[i].val == 1){
                if (zero >= q[i].k){
                    ok = 0;
                    break;
                }
            }
        }
        if (ok){
            for (int i=0; i<n; i++){
                if (mask & (1 << i)){
                    cout<<1<<" ";
                }
                else{
                    cout<<0<<" ";
                }
            }
            return;
        }
    }
    cout<<-1;
}

int one[5010];
int zero[5010];
int sp[5010];

void solve2(){

    for (int i=1; i<=m; i++){
        if (q[i].k == 1 && q[i].val == 1){
            one[q[i].l]++;
            one[q[i].r+1]--;
        }
    }

    for (int i=1; i<n; i++){
        one[i] += one[i-1];
    }
    for (int i=0; i<n; i++){
        if (one[i]){
            one[i] = 1;
        }
    }

    for (int i=1; i<=n; i++){
        sp[i] = sp[i-1];
        sp[i] += one[i-1];
    }

    /*for (int i=1; i<=n; i++){
        cerr<<one[i-1]<<" ";
    }
    cerr<<'\n';*/

    for (int i=1; i<=m; i++){
        if (q[i].k == 1 && q[i].val == 0){
            if (sp[q[i].r+1] - sp[q[i].l] == q[i].r - q[i].l + 1){
                cout<<-1;
                return;
            }
        }
    }

    for (int i=1; i<=n; i++){
        cout<<one[i-1]<<" ";
    }

}

void solve3(){


}



int main()
{
    //freopen ("input" , "r" , stdin);freopen ("output" , "w" , stdout);

    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin>>n>>m;

    int dif = 0;

    for (int i=1; i<=m; i++){
        cin>>q[i].l>>q[i].r>>q[i].k>>q[i].val;
        if (q[i].k != 1){
            dif = 1;
        }
    }

    if (n <= 18 && m <= 200){
        brut();
    }
    else if (!dif){
        solve2();
    }
    else{
        solve3();
    }

    return 0;
}
