/**
* user:  craciun-5f9
* fname: Mihai
* lname: Crăciun
* task:  devil
* score: 0.0
* date:  2019-10-10 07:16:04.869103
*/
#include <bits/stdc++.h>

using namespace std;

int k, d[10], s, cd[10];

vector <int> v, bst, clar;
long long bstmaxa = LLONG_MAX;

void bkt()  {
    if(v.size() == s)  {
        long long maxa = 0LL;
        for(int i = 0;i + k - 1 < v.size();i++)  {
            long long aa = 0LL;
            for(int j = i;j < i + k;j++)
                aa = aa * 10LL + 1LL * v[j];
            maxa = max(maxa, aa);
        }
        if(maxa < bstmaxa)  {
            bstmaxa = maxa;
            bst = v;
        }
        return;
    }
    for(int i = 1;i <= 9;i++)  {
        if(d[i] > 0)  {
            v.push_back(i);
            d[i]--;
            bkt();
            v.pop_back();
            d[i]++;
        }
    }
}

inline void solve1()  {
    bstmaxa = LLONG_MAX;
    v.clear();
    bst.clear();
    bkt();
}

inline void solve2()  {
    int cifmax = 9;
    while(d[cifmax] == 0)
        cifmax--;
    bst.clear();
    clar.clear(), clar.resize(s);
    bst.resize(s);
    int nextcif = cifmax - 1;
    while(nextcif > 0 && d[nextcif] == 0)
        nextcif--;
    if(nextcif == 0)  {
        for(int i = 0;i < d[cifmax];i++)
            bst[i] = cifmax;
        return;
    }
    for(int i = 1;i <= 9;i++)
        cd[i] = d[i];
    if(d[cifmax] == 1)  {
        int minx = nextcif * 10 + 1, maxx = nextcif * 10 + cifmax;
        for(int aa = minx;aa <= maxx;aa++)  {
            int ciff = aa % 10;
            int pozz = 0;
            bool ok = 1;
            while(d[nextcif] > 0)  {
                while(ciff > 0 && d[ciff] == 0)
                    ciff--;
                if(ciff == 0)  {
                    break;
                    ok = 0;
                }
                bst[pozz] = nextcif;
                pozz++;
                bst[pozz] = ciff;
                pozz++;
                d[nextcif]--;
                d[ciff]--;
            }
            if(ok == 0)  {
                for(int i = 1;i <= 9;i++)
                    d[i] = cd[i];
                bst = clar;
                continue;
            }
            for(int i = 1;i <= 9;i++)  {
                while(d[i])
                    bst[pozz++] = i, d[i]--;
            }
            return;
        }
    }
    else  {
        int minx = cifmax * 10 + 1, maxx = cifmax * 10 + cifmax;
        for(int aa = minx;aa <= maxx;aa++)  {
            int ciff = aa % 10;
            int pozz = 0;
            bool ok = 1;
            while(d[cifmax] > 0)  {
                while(ciff > 0 && d[ciff] == 0)
                    ciff--;
                if(ciff == 0)  {
                    break;
                    ok = 0;
                }
                bst[pozz] = cifmax;
                pozz++;
                bst[pozz] = ciff;
                pozz++;
                d[cifmax]--;
                d[ciff]--;
            }
            if(ok == 0)  {
                for(int i = 1;i <= 9;i++)
                    d[i] = cd[i];
                bst = clar;
                continue;
            }
            for(int i = 1;i <= 9;i++)  {
                while(d[i])
                    bst[pozz++] = i, d[i]--;
            }
            return;
        }
    }
}

inline void solve3()  {
    bst.clear();
    for(int poz = 1;poz <= k;poz++)  {
        int nrgrupe = (s - k) / poz;
        int rest = (s - k) % poz;
        if(d[1] < nrgrupe + 1)  {
            continue;
        }
        for(int i = 1;i <= nrgrupe;i++)  {
            for(int j = 1;j < poz;j++)  {
                if(d[2])
                    bst.push_back(2), d[2]--;
                else
                    bst.push_back(1), d[1]--;
            }
            bst.push_back(1), d[1]--;
        }
        for(int i = 1;i < poz;i++)  {
            if(d[2])
                bst.push_back(2), d[2]--;
            else
                bst.push_back(1), d[1]--;
        }
        bst.push_back(1), d[1]--;
        while(d[1])
            bst.push_back(1), d[1]--;
        while(d[2])
            bst.push_back(2), d[2]--;
        return;
    }
}

inline void solve()  {
    cin >> k;
    s = 0;
    for(int i = 1;i <= 9;i++)
        cin >> d[i], s += d[i];
    solve3();///pentru 3
    for(auto x : bst)
        cout << x;
    cout << "\n";
}

int main()  {
    int t;
    cin >> t;
    while(t--)  {
        solve();
    }
    return 0;
}
