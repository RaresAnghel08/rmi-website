/**
* user:  nicola-706
* fname: Alexandra Mihaela
* lname: Nicola
* task:  restore
* score: 13.0
* date:  2019-10-10 08:31:01.601166
*/
#include <iostream>
#define DIMN 5010
#define DIMM 10010
using namespace std;

//ifstream cin ("date.in");
//ofstream cout ("date.out");
struct interval{
    int x,y,val,nr;
};
interval qry[DIMM];
int v[DIMN],sp[DIMN];
int n,m,i,j,x,y,val,k,nr;
int main (){

    cin>>n>>m;
    int ok = 1;
    for (i=1;i<=m;i++){
        cin>>x>>y>>k>>val;
        qry[i] = {x+1,y+1,val,k};
        if (k == 1)
            nr++;
        if (k != 1 || k != y-x+1)
            ok = 0;
    }

    /*if (n <= 18){

        return 0;
    }*/
    if (nr == m){
        /// am doar k == 1
        for (i=1;i<=m;i++){
            if (qry[i].val == 1){
                v[qry[i].x]++;
                v[qry[i].y+1]--;
            }}
        for (i=1;i<=n;i++)
            v[i] += v[i-1];
        for (i=1;i<=n;i++)
            if (v[i] > 1)
                v[i] = 1;
        /// acum verific daca am cel putin un 0 in intervalele cu 0
        for (i=1;i<=n;i++)
            sp[i] = sp[i-1]+v[i];
        int ok = 1;
        for (i=1;i<=m;i++){
            if (qry[i].val == 0){
                if (sp[qry[i].y]-sp[qry[i].x-1] == qry[i].y-qry[i].x+1){
                    ok = 0;
                    break;
                }}}
        if (!ok){
            cout<<-1;
            return 0;
        }
        for (i=1;i<=n;i++)
            cout<<v[i]<<" ";
        return 0;
    }



    return 0;
}
/*#include <iostream>
#define DIMN 5010
#define DIMM 10010
using namespace std;

//ifstream cin ("date.in");
//ofstream cout ("date.out");
struct interval{
    int x,y,val,nr;
};
interval qry[DIMM];
int v[DIMN],sp[DIMN];
int n,m,i,j,x,y,val,k,nr;
pair <int,int> events[DIMM];
int main (){

    cin>>n>>m;
    ok = 1;
    for (i=1;i<=m;i++){
        cin>>x>>y>>k>>val;
        qry[i] = {x+1,y+1,val,k};
        if (k == 1)
            nr++;
        if (k != 1 || k != y-x+1)
            ok = 0;
    }


    if (nr == m){
        /// am doar k == 1
        el = 0;
        for (i=1;i<=m;i++){
            if (qry[i].val == 1){
                events[++el] = make_pair(qry[i].x,qry[i].y);
            }}
        sort (events+1,events+el+1);
        idx = 1;
        for (i=1;i<=n;i++){
            if (v[i] >= events[idx].first && v[i] <= events[idx].second)
                v[i] = 1;
            if (events[idx].second == i)
                idx++;
        }

        for (i=1;i<=n;i++)
            v[i] += v[i-1];
        for (i=1;i<=n;i++)
            if (v[i] > 1)
                v[i] = 1;
        /// acum verific daca am cel putin un 0 in intervalele cu 0
        for (i=1;i<=n;i++)
            sp[i] = sp[i-1]+v[i];
        int ok = 1;
        for (i=1;i<=m;i++){
            if (qry[i].val == 0){
                if (sp[qry[i].y]-sp[qry[i].x-1] < 1){
                    ok = 0;
                    break;
                }}}
        if (!ok){
            cout<<-1;
            return 0;
        }
        for (i=1;i<=n;i++)
            cout<<v[i]<<" ";
        return 0;
    }
    if (ok){
        /// am k 1 sau lg intervalului

    }


    return 0;
}
*/
