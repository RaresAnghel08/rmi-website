/**
* user:  luchianov-9b7
* fname: Alexandru
* lname: Luchianov
* task:  restore
* score: 13.0
* date:  2019-10-10 09:05:47.834945
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

//ifstream cin ("res.in");
//ofstream cout ("res.out");

#define ll long long
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) < (b)) ? (b) : (a))

int const nmax = 5000;
int v[1 + nmax];
int sum[1 + nmax]; //number of zeros in prefix i

struct Cond{
  int x;
  int y;
  int val;
  bool operator < (Cond const &a) const{
    if(y < a.x)
      return 1;
    else if(a.x <= x && x <= a.y)
      return 1;
    return 0;
  }
};
//*
vector<Cond> condmax;
vector<int> g[1 + nmax];
vector<Cond> condmin;


void update(int x, int n){
  for(int i = x; i <= n; i++)
    sum[i]++;
}

int seen[1 + nmax];

void tryit(int pos, int n){
  if(seen[pos] == 1)
    return ;
  seen[pos] = 1;
  bool canplace = 1;
  for(int i = 0; i < g[pos].size(); i++){
    Cond e = condmax[g[pos][i]];
    if(e.val == (sum[e.y] - sum[e.x - 1]))
      canplace = 0;
  }
  if(canplace == 1) {
    v[pos] = 0;
    update(pos, n);
  }
}
//*/


int main()
{
  int n, m;
  cin >> n >> m;
  for(int i = 1;i <= n; i++)
    v[i] = 1;
  for(int i = 1;i <= m; i++){
    int x, y, k, val;
    cin >> x >> y >> k >> val;
    x++;
    y++;
    if(val == 1) {
      condmax.push_back({x, y, k - 1});
      for(int j = x; j <= y; j++)
        g[j].push_back(condmax.size() - 1);
    } else {
      condmin.push_back({x, y, k});
    }
  }
  sort(condmin.begin(), condmin.end());
  sort(condmin.begin(), condmin.end());

  for(int i = 0;i < m; i++){
    Cond e = condmin[i];

    if(e.val <= sum[e.y] - sum[e.x - 1])
      continue;
    int pos = e.x;
    while(sum[e.y] - sum[e.x - 1] < e.val && pos <= e.y){
      tryit(pos, n);
      pos++;
    }
    if(sum[e.y] - sum[e.x - 1] < e.val){
      cout << -1;
      return 0;
    }
  }


  for(int i = 1;i <= n; i++)
    cout << v[i] << " ";
  return 0;
}
