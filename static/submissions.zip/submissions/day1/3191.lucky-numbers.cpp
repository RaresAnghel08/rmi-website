/**
* user:  bashev-75b
* fname: Dobrin
* lname: Bashev
* task:  lucky
* score: 28.0
* date:  2019-10-10 10:38:13.313965
*/
#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 100005;
const int MOD = 1000000007;

long long dp[MAXN], pw[MAXN];

long long solve(string &s, int n)
{
    long long ans = 1;
    for (int i = 0; i < n; ++ i)
    {
        if (i != 0 and s[i] == '3' and s[i - 1] == '1')
        {
            s[i]--;
            for (int j = i + 1; j < n; ++ j) s[j] = '9';
        }

        ans += (long long)(s[i] - '0') * dp[n - i - 1];
        if (s[i] > '1' or (s[i] == '1' and i + 1 < n and s[i + 1] >= '3'))
        {
            ans = ans - dp[n - i - 2];
           // cout << "!"<<  dp[n - i - 2] << endl;
        }

        //cout << (int)(s[i] - '0') << ' ' <<  dp[n - i - 1] << endl;
    }

    ans %= MOD;
    if (ans < 0) ans += MOD;
    return ans;
}

int n, q;
string s;

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    cin >> n >> q;
    cin >> s;

    pw[0] = 1;
    pw[1] = 10;
    for (int i = 2; i <= n; ++ i)
    {
        pw[i] = pw[i - 1] * 10;
        pw[i] %= MOD;
    }

    dp[0] = 1;
    dp[1] = 10;
    dp[2] = 99;
    for (int i = 3; i <= n; ++ i)
    {
        dp[i] = pw[i] - pw[i - 2];
        for (int j = 2; j <= i - 1; ++ j)
        {
            dp[i] -= dp[j - 1] * pw[i - j - 1];
            dp[i] %= MOD;
            // cout << dp[j - 1] << ' ' << pw[i - j - 1] << endl;
        }

        if (dp[i] < 0) dp[i] += MOD;
        // cout << dp[i] << endl;
    }

    cout << solve(s, s.size()) << endl;
    for (int i = 0; i < q; ++ i)
    {
        int x, l, r;
        cin >> x >> l >> r;

        string ss = "";
        if (x == 1)
        {
            ss = s.substr(l - 1, r);
            cout << solve(ss, ss.size()) << endl;;
        }
        else
        {
            s[l - 1] = r + '0';
        }
    }



    return 0;
}

/*
6  0  901763
*/
