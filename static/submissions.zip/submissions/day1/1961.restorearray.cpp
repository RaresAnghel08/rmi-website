/**
* user:  craciun-5f9
* fname: Mihai
* lname: Crăciun
* task:  restore
* score: 0.0
* date:  2019-10-10 08:14:06.458444
*/
#include <bits/stdc++.h>

using namespace std;

struct cer  {
    int l, r, k, val;
};

cer v[205];
int n, m;

vector <int> sol, ans;
bool ok = 0;
int s0[20], s1[20];

inline bool ver()  {
    for(int i = 1;i <= m;i++)  {
        int nr0, nr1;
        int l, r, k, val;
        l = v[i].l, r = v[i].r, k = v[i].k, val = v[i].val;
        nr0 = s0[r] - s0[l - 1];
        nr1 = s1[r] - s1[l - 1];
        if(val == 0)  {
            if(nr0 < k)  {
                return 0;
            }
        }
        else  {
            if(nr0 >= k)
                return 0;
        }
    }
    return 1;
}

void bkt()  {
    if(sol.size() == n)  {
        if(ver())
            ans = sol, ok = 1;
        return;
    }
    if(ok == 1)
        return;
    sol.push_back(0);
    s0[sol.size()] = s0[sol.size() - 1];
    s1[sol.size()] = s1[sol.size() - 1];
    s0[sol.size()]++;
    bkt();
    s0[sol.size()]--;
    sol.pop_back();
    sol.push_back(1);
    s1[sol.size()]++;
    bkt();
    s1[sol.size()]--;
    sol.pop_back();
}

int main()  {
    cin >> n >> m;
    for(int i = 1;i <= m;i++)  {
        cin >> v[i].l >> v[i].r >> v[i].k >> v[i].val;
        v[i].l++, v[i].r++;
    }
    bkt();
    for(auto x : ans)
        cout << x << " ";
    return 0;
}
