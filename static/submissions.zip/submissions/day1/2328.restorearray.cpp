/**
* user:  andreescu-960
* fname: Mihnea
* lname: Andreescu
* task:  restore
* score: 0.0
* date:  2019-10-10 09:00:47.569567
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int N=5000+7;
int n,m,t[N];

int par(int a)
{
        if(a==t[a])
        {
                return a;
        }
        return t[a]=par(t[a]);
}

void uni(int a,int b)
{
        a=par(a);
        b=par(b);
        if(a!=b)
                t[a]=b;
}

struct ele
{
        int l,r,k,x;
};

vector <ele> keks;
int c[N];

int main()
{
        ///freopen("input","r",stdin);

        cin>>n>>m;


        for(int i=1;i<=n;i++)
                t[i]=i;
        for(int i=1;i<=m;i++)
        {
                int l,r,k,x;
                cin>>l>>r>>k>>x;
                r++;
                if(k==r-l)
                {
                        /// toate sunt 0
                        keks.push_back({l,r,k,x});
                        continue;
                }
                if(x==1)
                {
                        for(int i=l;i<r;i++)
                                uni(i,i+1);
                }
                else
                        keks.push_back({l,r,k,x});
        }

        for(int i=1;i<=n;i++)
                c[i]=(par(i)!=par(i-1))+c[i-1];

        for(auto &it : keks)
        {
                int l=it.l;
                int r=it.r;
                int k=it.k;
                int x=it.x;
                if(x==0)
                {
                        if(c[r]-c[l-1]>=k)
                                continue;
                }
                else
                {
                        if(c[r]-c[l-1]<k)
                                continue;
                }
                cout<<"-1\n";
                return 0;
        }

        for(int i=1;i<=n;i++)
        {
                if(c[i]!=c[i-1])
                        cout<<"1 ";
                else
                        cout<<"0 ";
        }

        return 0;
}
