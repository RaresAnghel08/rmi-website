/**
* user:  karagyozov-c76
* fname: Ivo
* lname: Karagyozov
* task:  devil
* score: 13.0
* date:  2019-10-10 08:29:58.732190
*/
#include <bits/stdc++.h>

int32_t k;

std::string get_max(const std::string &s) {
	std::string currAns = s.substr(0, k);
	for(int32_t i = 1; i < s.size(); i++) {
		if(i + k > s.size()) {
			break;
		}

		currAns = std::max(currAns, s.substr(i, k));
	}

	return currAns;
}

int main() {
	std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);

	int32_t t;
	std::cin >> t;

	for(int32_t cs = 1; cs <= t; cs++) {
		std::cin >> k;
	
		std::vector< int32_t > a(10);
		for(int32_t i = 1; i < 10; i++) {
			std::cin >> a[i];
		}

		std::string s = "";
		for(int32_t i = 1; i < 10; i++) {
			for(int32_t j = 0; j < a[i]; j++) {
				s += (char) (i + '0');	
			}
		}
		
		std::string ans = "", best;
		do {
			auto currAns = get_max(s);
			if(currAns < ans || ans == "") {
				ans = currAns;
				best = s;
			}
		} while(std::next_permutation(s.begin(), s.end()));

		std::cout << best << '\n';
	}
}
