/**
* user:  nicolae-502
* fname: Radu Mihai
* lname: Nicolae
* task:  restore
* score: 0.0
* date:  2019-10-10 07:58:12.241493
*/
//#include<fstream>
#include<iostream>
using namespace std;
//ifstream fin("test.in");
//ofstream fout("tes.out");
int n,m,l,r,k,val,i;
int sol[50010];
int main()
{
    cin>>n>>m;
    for(;m--;)
    {
        cin>>l>>r>>k>>val;
        if(k==1)
        {
            if(val==0)
            {
                if(sol[l]!=0)
                {
                    cout<<"-1"; return 0;
                }
                sol[l]=1;
            }
            else
            {
                for(i=l;i<=r;i++)
                {
                    if(sol[i]!=0)
                    {
                        cout<<"-1"; return 0;
                    }
                    sol[i]=2;
                }
            }
        }
        else
            if(k==r-l+1)
            {
                if(val==1)
                {
                    if(sol[r]!=0)
                    {
                        cout<<"-1"; return 0;
                    }
                    sol[r]=2;
                }
                else
                {
                    for(i=l;i<=r;i++)
                    {
                        if(sol[i]!=0)
                        {
                            cout<<"-1"; return 0;
                        }
                        sol[i]=1;
                    }
                }
            }
    }
    for(i=0;i<n;i++) cout<<max(sol[i]-1,0);
    return 0;
}

