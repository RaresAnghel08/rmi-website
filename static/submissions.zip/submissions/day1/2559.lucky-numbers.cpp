/**
* user:  penchev-2b7
* fname: Jasen
* lname: Penchev
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:30:54.812313
*/
#include <iostream>
#include <cstring>
#include <string>
#define endl '\n'
using namespace std;

const unsigned long long MOD = 1000000007;

unsigned long long dp[16][32];

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n, q;
    cin >> n >> q;

    string x;
    cin >> x;

    unsigned long long ans = 0;

    for (int i = 0; i < x[0] - '0'; ++ i)
        dp[i][1] = 1;

    for (int k = 2; k <= n; ++ k)
    {
        for (int i = 0; i <= 9; ++ i)
        {
            for (int j = 0; j <= 9; ++ j)
            {
                if (j == 1 and i == 3) continue;
                dp[i][k] += dp[j][k - 1];
            }
        }
    }

    for (int i = 0; i <= 9; ++ i)
    {
        ans += dp[i][n];
        ans %= MOD;
    }

    for (int p = 1; p < n; ++ p)
    {
        memset(dp, 0, sizeof(dp));
        for (int i = 0; i < x[p] - '0'; ++ i)
        {
            if (x[p - 1] == 1 and i == 3) continue;
            dp[i][p + 1] = 1;
        }
        for (int k = p + 2; k <= n; ++ k)
        {
            for (int i = 0; i <= 9; ++ i)
            {
                for (int j = 0; j <= 9; ++ j)
                {
                    if (j == 1 and i == 3) continue;
                    dp[i][k] += dp[j][k - 1];
                }
            }
        }

        for (int i = 0; i <= 9; ++ i)
        {
            ans += dp[i][n];
            ans %= MOD;
        }

        if (x[p] == 1 and x[p + 1] == 3) break;
    }

    int k = x.find("13");
    if (!(0 <= k and k < x.size())) ans++;

    ans %= MOD;

    cout << ans << endl;

    return 0;
}
