/**
* user:  malinin-a1f
* fname: Stoyan
* lname: Malinin
* task:  devil
* score: 0.0
* date:  2019-10-10 07:40:03.106268
*/
#include<iostream>

using namespace std;

const int MAXN = 1e6 + 5;

int k;
int d[10];

int after[MAXN];

int main()
{
    //ios::sync_with_stdio(false);
    //cin.tie(NULL);

    int T;
    cin >> T;

    while(T--)
    {
        cin >> k;
        for(int i = 1;i<=2;i++)
        {
            cin >> d[i];
        }

        if(d[2]<k)
        {
            for(int i = 0;i<d[1];i++) cout << "1";
            for(int i = 0;i<d[2];i++) cout << "2";
            cout << '\n';
        }
        else
        {
            for(int i = 0;i<=d[2];i++)
            {
                after[i] = 0;
            }

            while(d[1]!=0)
            {
                for(int i = 0;i<d[2]-k+1;i++)
                {
                    if(d[1]==0) break;

                    d[1]--;
                    after[i]++;
                }
            }

            for(int i = 0;i<d[2];i++)
            {
                cout << "2";
                for(int j = 0;j<after[i];j++) cout << "1";
            }
            cout << '\n';
        }
    }
}
