/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  restore
* score: 13.0
* date:  2019-10-10 08:13:39.703513
*/
#include<bits/stdc++.h>
using namespace std;
int n,m;
int l,r,k,val;
bool b[5002];
vector<pair<int,int> >v;
int main()
{
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>l>>r>>k>>val;
		if(val==1)
		{
			for(int j=l;j<=r;j++)
			{
				b[j]=1;
			}
		}
		else v.push_back({l,r});
	}
	for(int i=0;i<v.size();i++)
	{
		bool flag=1;
		for(int j=v[i].first;j<=v[i].second;j++)
		{
			flag&=b[j];
		}
		if(flag)
		{
			cout<<"-1\n";
			return 0;
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<b[i]<<" ";
	}
	cout<<endl;
return 0;
}
