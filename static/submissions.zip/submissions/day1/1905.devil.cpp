/**
* user:  apostol-c2d
* fname: Daniel
* lname: Apostol
* task:  devil
* score: 13.0
* date:  2019-10-10 08:06:42.622297
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define pb push_back
#define get_here cerr << "-1\n"
#define dbg(x) cerr << #x << " " << x << "\n"

int n, k;

int d[10];
const int N = 1e5;
int ans[1 + N];
ll mx;
int a[1 + N];
void bkt (int p) {
    if (p == n + 1) {
        ll best = 0;
        ll nr = 0;
        ll put = 1;
        for (int i = 1; i <= k; i++) {
            nr = nr * 10 + a[i];
            put = put * 10;
        }
        best = nr;
        for (int i = k + 1; i <= n; i++) {
            nr = (nr * 10 + a[i]) % put;
            best = max (best, nr);
        }
        if (mx > best || mx == -1) {
            mx = best;
            for (int i = 1; i <= n; i++)
                ans[i] = a[i];
        }
        return;
    }
    for (int c = 1; c <= 9; c++)
        if (d[c]) {
            d[c]--;
            a[p] = c;
            bkt (p + 1);
            d[c]++;
        }
}

void brut () {
    bkt (1);
}

void solve () {
    cin >> k;
    n = 0;
    for (int i = 1; i <= 9; i++)
        cin >> d[i], n += d[i];
    mx = -1;
    brut ();
    for (int i = 1; i <= n; i++)
        cout << ans[i];
    cout << "\n";
}

int main () {
    ios::sync_with_stdio (false);
    cin.tie (0); cout.tie (0);
  //  freopen ("devil.in", "r", stdin);
  //  freopen ("devil.out", "w", stdout);
    int t;
    cin >> t;
    while (t--)
        solve ();
    return 0;
}
