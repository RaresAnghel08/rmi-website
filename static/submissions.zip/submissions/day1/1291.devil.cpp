/**
* user:  oparlakov-daf
* fname: Dimitar
* lname: Oparlakov
* task:  devil
* score: 0.0
* date:  2019-10-10 06:09:08.137957
*/
#include <iostream>
#include <cstdio>
using namespace std;

int t, dig[10];

int main()
{
    scanf("%d", &t);

    for(int x=0; x<t; x++)
    {
        int sum2 = 0;

        for(int i=1; i<=9; i++)
        {
            scanf("%d", &dig[i]);

            if(i>2) sum2 += dig[i];
        }

        if(sum2 == 0)
        {
            if(dig[2] == 1)
            {
                for(int i=0; i<dig[1]; i++) printf("1");
                printf("2");
            }
            else if(dig[2] == 0)
            {
                for(int i=0; i<dig[1]; i++) printf("1");
            }
            else if(dig[1] == 0)
            {
                for(int i=0; i<dig[2]; i++) printf("2");
            }
            else if(dig[2] > dig[1] + 1)
            {
                for(int i=0; i<dig[1]; i++) printf("1");
                for(int i=0; i<dig[1]; i++) printf("2");
            }
            else
            {
                for(int i=0; i<dig[1]; i++) printf("21");
                for(int i=0; i<dig[2] - dig[1]; i++) printf("2");
            }
            printf("\n");
        }

    }

    return 0;
}
