/**
* user:  czarkowski-d42
* fname: Arkadiusz
* lname: Czarkowski
* task:  restore
* score: 7.0
* date:  2019-10-10 06:46:38.736429
*/
#include <bits/stdc++.h>

using namespace std;

int n, m, l, r, k, v, d;
int t[5010];
vector <pair <int, int> > g[5010];

int sum(int u, int v)
{
	int z=0;
	for(int i=u; i<=v; ++i)
	{
		z+=t[i];
	}
	return z;
}

bool ch(int r)
{
	for(int i=0; i<(int)g[r].size(); ++i)
	{
		l=g[r][i].first;
		k=g[r][i].second;
		d=r-l+1;
		v=1;
		if(k<0)
		{
			v=0;
			k=-k;
		}
		if(v==1)
		{
			if(sum(l, r)<d-k+1)
			{
				return false;
			}
		}
		else
		{
			if(sum(l, r)>=d-k+1)
			{
				return false;
			}
		}
	}
	return true;
}

bool f(int x)
{
	if(x==n)
	{
		return true;
	}
	if(ch(x))
	{
		if(f(x+1))
		{
			return true;
		}
	}
	t[x]=1;
	if(ch(x))
	{
		if(f(x+1))
		{
			return true;
		}
	}
	t[x]=0;
	return false;
}

int main()
{
	scanf("%d%d", &n, &m);
	for(int i=0; i<m; ++i)
	{
		scanf("%d%d%d%d", &l, &r, &k, &v);
		if(v==1)
		{
			g[r].push_back({l, k});
		}
		else
		{
			g[r].push_back({l, -k});
		}
	}
	if(f(0))
	{
		for(int i=0; i<n; ++i)
		{
			printf("%d ", t[i]);
		}
	}
	else
	{
		printf("-1");
	}
	return 0;
}

/*

4 5
0 1 2 1
0 2 2 0
2 2 1 0
0 1 1 0
1 2 1 0

*/
