/**
* user:  pavic-9e7
* fname: Patrick
* lname: Pavić
* task:  lucky
* score: 0.0
* date:  2019-10-10 06:45:24.457461
*/
#include <cstdio>
#include <cstring>

using namespace std;

typedef long long ll;

const int N = 1e5 + 500;
const int MOD = 1e9 + 7;
const int OFF = (1 << 18);

inline int mul(const int &A, const int &B){
	return (ll)A * B % MOD;
}

inline int add(const int &A, const int &B){
	if(A + B >= MOD) return A + B - MOD;
	return A + B;
}

inline int sub(const int &A, const int &B){
	if(A - B < 0) return A - B + MOD;
	return A - B;
}

struct node{
	int mnj;
	int p3, z1, p3z1;
	int len;
	bool P3, Z1, OK;
};

int svep3[N], sve[N], svez1[N], svep3z1[N];

node tour[2 * OFF], NULA;

node mrg(node A, node B){
	if(A.len == 0) return B;
	if(B.len == 0) return A;
	node C;
	C.len = A.len + B.len;
	C.P3 = A.P3, C.Z1 = B.Z1;
	C.OK = A.OK & B.OK & (!(B.P3 && A.Z1));
	
	
	C.mnj = sub(mul(A.mnj , sve[B.len]), mul(A.z1, svep3[B.len]));
	C.p3 = sub(mul(A.p3, sve[B.len]), mul(A.p3z1, svep3[B.len]));
	C.z1 = sub(mul(A.mnj, svez1[B.len]), mul(A.z1, svep3z1[B.len]));
	C.p3z1 = sub(mul(A.p3, svez1[B.len]), mul(A.p3z1, svep3z1[B.len]));
	if(A.OK){
		if(!A.Z1){
			C.mnj = add(C.mnj, B.mnj);
			if(A.P3){
				C.p3 = add(C.p3, B.mnj);
				C.p3z1 = add(C.p3z1, B.z1);
			}
			C.z1 = add(C.z1, B.z1);
		}
		else{
			C.mnj = add(C.mnj, sub(B.mnj, B.p3));
			if(A.P3){
				C.p3 = add(C.p3, sub(B.mnj, B.p3));
				C.p3z1 = add(C.p3z1, sub(B.z1, B.p3z1));
			}
			C.z1 = add(C.z1, sub(B.z1, B.p3z1));
		}
	}
	return C;
}

void update(int i,int x){
	i += OFF;
	tour[i].mnj = x;
	tour[i].p3z1 = 0;
	tour[i].z1 = (x >= 1);
	tour[i].p3 = (x >= 3);
	tour[i].OK = 1;
	tour[i].P3 = (x == 3);
	tour[i].Z1 = (x == 1);
	tour[i].len = 1;
	for(i /= 2; i ; i /= 2)
		tour[i] = mrg(tour[2 * i], tour[2 * i + 1]);
}

node query(int i,int a,int b,int lo,int hi){
	if(lo <= a && b <= hi) return tour[i];
	if(a > hi || b < lo) return NULA;
	return mrg(query(2 * i, a, (a + b) / 2, lo, hi), query(2 * i + 1, (a + b) / 2 + 1, b, lo,hi));
}

void precompute(){
	sve[0] = 1;
	svep3[0] = 0;
	svez1[0] = 0;
	sve[1] = 10;
	svep3[1] = 1;
	svez1[1] = 1;
	for(int i = 2;i < N;i++){
		sve[i] = sub(mul(sve[i - 1], 10), svep3[i - 1]);
		svep3[i] = sve[i - 1];
		svez1[i] = sve[i - 1];
		svep3z1[i] = sve[i - 2];
	}
	//printf("%d\n", sve[6]);
}

int main(){
	precompute();
	//return 0;
	NULA.len = 0;
	int n, q; scanf("%d%d", &n, &q);
	for(int i = 0;i < n;i++){
		char c; scanf(" %c", &c);
		update(i, c - '0');
	}
	node ret = query(1, 0, OFF - 1, 0, n - 1);
	printf("%d\n", ret.mnj + ret.OK);
	for(int i = 0;i < q;i++){
		int x, y, z; scanf("%d%d%d", &x, &y, &z);
		if(x == 1){
			ret = query(1, 0, OFF - 1, y - 1, z - 1);
			printf("%d\n", ret.mnj + ret.OK);
		}
		else
			update(y - 1, z);
	}
}



