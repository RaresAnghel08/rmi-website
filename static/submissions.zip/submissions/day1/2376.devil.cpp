/**
* user:  mordecki-e78
* fname: Marcin
* lname: Mordecki
* task:  devil
* score: 27.0
* date:  2019-10-10 09:08:17.986462
*/
#include <bits/stdc++.h>
using namespace std;
typedef unsigned uns;
typedef long long lld;
typedef pair<int,int> pii;
typedef pair<lld,lld> pll;
typedef complex<double> cd;
typedef vector<cd> vcd;
typedef double lf;
typedef long double llf;
typedef pair<lf,lf> pff;
#define ff first
#define dd second
#define mp make_pair
#define pb push_back
#define sz size()
#define For(i,s,a) for(lld i = (lld)s;i<(lld)a;++i)
#define rpt(S,it) for(auto it=S.begin();it=S.end();++it)

inline void scan(int *i);
inline void scanll(int *i);
inline void scanu(int *i);
inline void print(int x);

int c[10];
int s[1000001];

void solve2(int K, int S){
	int t[S];
	int p = 1;
	while(!c[p])++p;
	char wyn[S],minx[S];
	memset(minx,'9',S);
	For(i,0,S){t[i]=p+'0';--c[p];while(!c[p] && p<9)++p;}
	do{
		//For(i,0,S)cout<<t[i]-'0'<<" ";puts("");
		char tmp[S],tmin[S];
		memset(tmin,0,S);
		For(i,0,S)tmp[i]=t[i];
		For(i,0,S+1-K){
			if(memcmp(tmp+i,tmin,K)>0)memcpy(tmin,tmp+i,K);
		}
		if(memcmp(tmin,minx,K)<0){memcpy(minx,tmin,K);For(jj,0,S)wyn[jj]=t[jj];}
		//For(i,0,K)cout<<tmin[i]-'0'<<" ";
		//cout<<" ";
		//For(i,0,S)cout<<wyn[i]-'0'<<" ";
		//puts("\n");
	}while(next_permutation(t,t+S));
	For(i,0,S)printf("%c",wyn[i]);
	puts("");
}

void solve(){
	int K;
	scan(&K);
	For(i,1,10)scan(&c[i]);
	if(K==2){
		int p = 1, k = 9, wsk = 0;
		while(!c[p])++p;
		while(!c[k])--k;
		while(p<k || c[p]){
			if(wsk&1){s[++wsk]=p;--c[p];while(!c[p] && p<9)++p;}
			else
			{s[++wsk]=k;--c[k];while(k && !c[k])--k;}
		}
		while(wsk)printf("%d",s[wsk]),--wsk;
		puts("");
	}
	else
	{
		int S = 0;
		For(i,1,10)S+=c[i];
		if(S<13){
			solve2(K,S);
		}
		else
		if(S==c[1]+c[2]){
			string xd="";
			int p = 1, k = 2;
			For(i,0,K-1){xd+=k+'0';--c[k];while(!c[k] && k)--k;}
			while(!c[p] && p<2)++p;
			xd+='1';
			--c[p];
			while(!c[p] && p<2)++p;
			if(!c[1]){
				For(i,0,c[2])putchar_unlocked('2');
				for(int i=xd.sz-1;i+1;--i)putchar_unlocked(xd[i]);
				puts("");
				return;
			}
			else
			if(!c[2]){
				For(i,0,c[1])putchar_unlocked('1');
				for(int i=xd.sz-1;i+1;--i)putchar_unlocked(xd[i]);
				puts("");
				return;
			}
			int J = c[1]/c[2];
			int D = c[2]/c[1];
			//cout<<J<<" "<<D<<endl;
			while(c[1]+c[2]){
				For(i,0,max(1,J))if(c[2])
				putchar_unlocked('2'),--c[2];
				For(i,0,max(1,D))if(c[1])
				putchar_unlocked('1'),--c[1];
			}
			for(int i=xd.sz-1;i+1;--i)putchar_unlocked(xd[i]);
			puts("");
			return;
		}
		else
		puts("well_hello");
		
		
	}
}

int32_t main(void){
	int t;
	scan(&t);
	while(t--)solve();
}









inline void scan(int *i){
	int t = 0;
	char z = 'a';
	bool neg = 0;
	while((z<'0') || (z>'9')){if(z=='-')neg=1;z=getchar_unlocked();}
	while((z>='0') && (z<='9')){t=((t<<3ll)+(t<<1ll)+z-'0');z=getchar_unlocked();}
	if(neg)t=(~(t-1));
	*i=t;
}

inline void scanll(lld *i){
	lld t = 0;
	char z = 'a';
	bool neg = 0;
	while((z<'0') || (z>'9')){if(z=='-')neg=1;z=getchar_unlocked();}
	while((z>='0') && (z<='9')){t=((t<<3ll)+(t<<1ll)+z-'0');z=getchar_unlocked();}
	if(neg)t=(~(t-1));
	*i=t;
}

inline void scanu(uns *i){
	uns t = 0;
	char z = 'a';
	while((z<'0') || (z>'9')){z=getchar_unlocked();}
	while((z>='0') && (z<='9')){t=((t<<3ll)+(t<<1ll)+z-'0');z=getchar_unlocked();}
	*i=t;
}


//repair
inline void print(int x){
	if(x==0){putchar_unlocked('0');return;}
	short stos[18],_end=0,help,help2;
	while(x){
		help=x;
		help>>=1;
		help/=5;
		help2=(help<<3ll)+(help<<1ll);
		stos[++_end]=help2;
		x=help;
	}
	while(_end)putchar_unlocked(stos[_end]+'0'),--_end;
}
