/**
* user:  kanafeev-1f0
* fname: Mark
* lname: Kanafeev
* task:  restore
* score: 13.0
* date:  2019-10-10 08:16:58.604908
*/
#include <bits/stdc++.h>


using namespace std;


#define x first
#define y second



signed main() {
    ios :: sync_with_stdio(false);
    cin.tie(0);
    int n, m, l, r, k, val;
    cin >> n >> m;
    vector<char> v(n);
    vector<pair<int, int>> check;
    for (int i = 0; i < m; i++) {
        cin >> l >> r >> k >> val;
        if (k == 1) {
            if (val == 1) {
                for (int i = l; i <= r; i++) {
                    v[i] = 1;
                }
            }
            else
                check.push_back({l, r});
        }
    }
    for (auto el : check) {
        bool f = 0;
        for (int i = el.x; i <= el.y; i++) {
            if (v[i] == 0) {
                f = 1;
                break;
            }
        }
        if (!f) {
            cout << -1;
            return 0;
        }
    }
    for (auto el : v)
        cout << (int)el << ' ';
    return 0;
}
