/**
* user:  shilyaeva-b16
* fname: Ekaterina
* lname: Shilyaeva
* task:  restore
* score: 13.0
* date:  2019-10-10 06:49:43.088447
*/
#include <bits/stdc++.h>

using namespace std;
#define x first
#define y second

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;

struct restr {
	int l, r, k, val;
	restr() {};
};

int answ[5009];
signed main() {
	ios :: sync_with_stdio(0);
	cin.tie(0);

	int  n, m;
	cin >> n >> m;

	vector<restr> ao(m);
	for (int i = 0; i < m; i ++) {
        cin >> ao[i].l >> ao[i].r >> ao[i].k >>  ao[i].val;
    }

	if (n <= 1 && m <= 200) {
		for (int mask = 0; mask < (1 << n); mask++) {
            bool ok = 1;
			for (auto &x : ao) {
				int cnt0 = 0;
				for (int i = x.l; i <= x.r; i++) {
					cnt0 += (((mask >> i) & 1) == 0);
				}

				if (cnt0 >= x.k && x.val == 1) {
                    ok = 0;
                    break;
				}

				if (cnt0 < x.k && x.val == 0) {
                    ok = 0;
                    break;
				}
			}

			if (ok) {
                for (int i = 0; i < n; i ++) {
                    cout << ((mask >> i) & 1) << ' ';
                }

                return 0;
			}
		}

		cout << -1;
		return 0;
	}

	for (int i = 0; i < n; i ++) {
        answ[i] = 0;
	}

    for (auto &x : ao) {
        if (x.k == 1 && x.val == 1) {
            for (int i = x.l; i <= x.r; i++) {
                answ[i] = 1;
            }
        }

        if (x.k != 1 && x.val == 0) {
            for (int i = x.l; i <= x.r; i++) {
                answ[i] = 0;
            }
        }
    }

    for (auto &x : ao) {
        int cnt0 = 0;
        for (int i = x.l; i <= x.r; i++) {
            cnt0 += (answ[i] == 0);
        }

        if (cnt0 >= x.k && x.val == 1) {
            cout << -1;
            return 0;
        }

        if (cnt0 < x.k && x.val == 0) {
            cout << -1;
            return 0;
        }
    }

    for (int i = 0; i < n; i ++) {
        cout << answ[i] << ' ';
    }

	return 0;
}
