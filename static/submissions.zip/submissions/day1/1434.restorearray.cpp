/**
* user:  khamitov-0d0
* fname: Tagir
* lname: Khamitov
* task:  restore
* score: 7.0
* date:  2019-10-10 06:46:46.532320
*/
#include <bits/stdc++.h>

#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define f first
#define s second
#define size(x) (int)x.size()

using namespace std;

typedef long long ll;
typedef long double ld;

void io() {
#ifdef MLOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
}

struct seg{
    int l, r, v;
    seg(int l_, int r_, int v_) {
        l = l_;
        r = r_;
        v = v_;
    }
    bool operator<(seg s) {
        return (r - l + 1) < (s.r - s.l + 1);
    }
};

void solve() {
    int n, m;
    cin >> n >> m;
    if(n <= 18 && m <= 200) {
        vector<int> a(n);
        vector<int> l(m), r(m), k(m), v(m);
        int ones;
        for(int i = 0; i < m; i++) {
            cin >> l[i] >> r[i] >> k[i] >> v[i];
        }
        for(int mask = 0; mask < (1 << n); mask++) {
            for(int i = 0; i < n; i++) {
                if(i == 0) {
                    a[i] = 0;
                }else {
                    a[i] = a[i - 1];
                }
                if(mask & (1 << i)) {
                    a[i]++;
                }
            }
            bool ok = true;
            for(int i = 0; i < m; i++) {
                if(l[i] == 0) {
                    ones = a[r[i]];
                }else {
                    ones = a[r[i]] - a[l[i] - 1];
                }
                if(v[i] == 0 && ones > r[i] - l[i] + 1 - k[i]) {
                    ok = false;
                    break;
                }else if(v[i] == 1 && ones < r[i] - l[i] + 2 - k[i]) {
                    ok = false;
                    break;
                }
            }
            if(ok) {
                cout << a[0] << " ";
                for(int i = 1; i < n; i++) {
                    cout << a[i] - a[i - 1] << " ";
                }
                exit(0);
            }
        }
        cout << -1;
    }else {
        vector<int> a(n, -1);
        vector<int> l(m), r(m), k(m), v(m);
        for(int i = 0; i < m; i++) {
            cin >> l[i] >> r[i] >> k[i] >> v[i];
        }
        for(int i = 0; i < m; i++) {
            if(v[i] == 0 && k[i] == (r[i] - l[i] + 1)) {
                for(int j = l[i]; j <= r[i]; j++) {
                    if(a[j] == 1) {
                        cout << -1;
                        exit(0);
                    }else {
                        a[j] = 0;
                    }
                }
            }
            if(v[i] == 1 && k[i] == 1) {
                for(int j = l[i]; j <= r[i]; j++) {
                    if(a[j] == 0) {
                        cout << -1;
                        exit(0);
                    }else {
                        a[j] = 1;
                    }
                }
            }
        }
        vector<seg> s;
        for(int i = 0; i < m; i++) {
            int tl = l[i], tr = l[i] - 1;
            for(int j = l[i]; j <= r[i]; j++) {
                if(a[j] == -1) {
                    tr++;
                }else {
                    if(tr >= tl) {
                        s.push_back(seg(tl, tr, v[i]));
                    }
                    tl = j + 1;
                    tr = j;
                }
            }
            if(tr >= tl) {
                s.push_back(seg(tl, tr, v[i]));
            }
        }
        sort(all(s));
        for(int i = 0; i < size(s); i++) {
            bool ok = false;
            for(int j = s[i].l; j <= s[i].r; j++) {
                if(a[j] == -1) {
                    a[j] = v[i];
                    ok = true;
                    break;
                }
            }
            if(!ok) {
                cout << -1;
                exit(0);
            }
        }
        for(int i = 0; i < n; i++) {
            if(a[i] == -1) {
                a[i] = 0;
            }
            cout << a[i] << " ";
        }
    }
}

int main() {
    io();
    solve();
    return 0;
}
