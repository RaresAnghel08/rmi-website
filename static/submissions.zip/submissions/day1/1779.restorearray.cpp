/**
* user:  tamyarov-797
* fname: Ilya
* lname: Tamyarov
* task:  restore
* score: 7.0
* date:  2019-10-10 07:45:48.979448
*/
#define ll long long
#include<bits/stdc++.h>
using namespace std;
void solve();
void file()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
}
int main(){
    solve();
    return 0;
}
void solve()
{
    ll n,m;
    cin>>n>>m;
    ll a[m],b[m],c[m],d[m];
    for(int i=0;i<m;i++)
    {
        cin>>a[i]>>b[i]>>c[i]>>d[i];
    }
    for(long long mask=0;mask<(1<<n);mask++)
    {
        vector<bool> now;
        for(ll i=0;i<n;i++)
        {
            now.push_back(mask&(1<<i));
        }
        bool ok=1;
        for(int i=0;i<m;i++)
        {
            ll cnt=0;
            for(int j=a[i];j<=b[i];j++)
            {
                cnt+=now[j];
            }
            ll sz=b[i]-a[i]+1;
            if(d[i]==0)
            {
                if(sz-cnt<c[i])
                {
                    ok=0;
                    break;
                }
            }
            else
            {
                if(cnt<sz+1-c[i])
                {
                    ok=0;
                    break;
                }
            }
        }
        if(ok)
        {
            for(auto x:now)
                cout<<x<<' ';
            return;
        }
    }
    cout<<-1;
    return;
}
