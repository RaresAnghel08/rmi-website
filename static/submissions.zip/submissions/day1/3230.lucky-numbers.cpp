/**
* user:  yanev-d24
* fname: Aleksandar
* lname: Yanev
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:39:47.493013
*/
#include<bits/stdc++.h>
#define mod 1000000007
using namespace std;
unsigned long long num,br;
unsigned long long check(unsigned long long j)
{
    while(j>0)
    {
        if(j%100==13)return 1;
        j/=10;
    }
    return 0;
}
int main()
{
    unsigned long long n,q;
    cin>>n>>q;
    cin>>num;
    for(unsigned long long i=1;i<=num;i++)
    {
        if(check(i))br++;
    }
    cout<<(num-br)%mod<<endl;
}
