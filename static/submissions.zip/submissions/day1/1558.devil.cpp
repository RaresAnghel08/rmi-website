/**
* user:  metehau-fd8
* fname: Luca
* lname: Metehău
* task:  devil
* score: 0.0
* date:  2019-10-10 07:07:10.409047
*/
#include <iostream>
#include <cstring>

using namespace std;

// eventual fac bruturi aici

int t, n, m, k;

int f[10], w[10];

string S, ans, currMn;

string getMx(string s) {
  string mx, tmp;
    tmp.clear();
    for(int i = 0; i < k; i++)
      tmp += s[i];
    mx = tmp;
    // cout << ans << "|\n";
    for(int i = n; i < m; i++) {
      tmp += s[i];
      tmp.erase(tmp.begin());
      // cout << tmp << "\n";
      if(tmp > mx) {
        mx = tmp;
      }
    }
  return mx;
}

void bkt(int niv) {
  if(niv == m + 1) {
    string mx = getMx(ans);
    // cout << ans << " " << mx << "\n";
    // cout << S << " " << ans << "\n";
    // cout << S << " " << ans << " " << mx << " " << currMn << "\n";
    if(mx < currMn)
      S = ans, currMn = mx;
  }
  for(int i = 1; i <= 9; i++) {
    if(f[i]) {
      ans += i + '0';
      f[i]--;
      bkt(niv + 1);
      f[i]++;
      ans.pop_back();
    }
  }
}

int main() {
  cin >> t;
  for(; t; t--) {
    cin >> k;
    m = 0;
    for(int i = 1; i <= 9; i++)
      cin >> f[i], m += f[i], w[i] = f[i];
    if(m == f[1] + f[2] + f[3] + f[4]) {
      S.clear();
      currMn.clear();
      for(int i = 1; i <= k; i++)
        currMn += '9';
      bkt(1);
      cout << S << "\n";
      continue;
    }
    if(f[2] < k) {
      for(int i = 1; i <= f[1]; i++)
        cout << 1, S += '1';
      for(int i = 1; i <= f[2]; i++)
        cout << 2, S += '2';
      cout << "\n";
    } else {
      f[2] -= k - 1;
      f[1]--;
      if(f[1] >= f[2]) {
        for(int i = 1; i <= f[2]; i++) {
          cout << 2, S += '2';
          for(int j = 1; j <= f[1] / f[2]; j++)
            cout << 1, S += '1';
        }
        for(int i = 1; i <= f[1] % f[2] + 1; i++)
          cout << 1, S += '1';
        for(int i = 1; i < k; i++)
          cout << 2, S += '2';
        cout << "\n";
      } else {
        for(int i = 1; i <= f[1]; i++)
          cout << "21", S += "21";
        for(int i = 1; i <= f[2] - f[1]; i++)
          cout << 2, S += '2';
        cout << 1, S += '1';
        for(int i = 1; i < k; i++)
          cout << 2, S += '2';
        cout << "\n";
      }
    }
  }
  return 0;
}
