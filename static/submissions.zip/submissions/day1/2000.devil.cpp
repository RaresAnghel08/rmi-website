/**
* user:  shilyaeva-b16
* fname: Ekaterina
* lname: Shilyaeva
* task:  devil
* score: 0.0
* date:  2019-10-10 08:19:14.868106
*/
#include <bits/stdc++.h>

using namespace std;

#define x first
#define y second

/*
#define tm ((tl + tr) >> 1)
#define left (v << 1), tl, tm
#define right (v << 1) + 1, tm, tr
#define vert int v, int tl, int tr
#define root 1, 0, n
*/

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;

ll fpow(ll x, ll y, ll mod) {
    ll answ = 1;
    while (y) {
        if (y & 1) {
            answ *= x;
            answ %= mod;
        }

        x *= x;
        x %= mod;
        y >>= 1;
    }

    return answ;
}

ll del(ll a, ll b, ll mod) {
    return (a * fpow(b, mod - 2, mod)) % mod;
}

vector<int> a(10);
string answ = "";
int n = 0;

bool check(int m) {
    answ.clear();
    int last = -1;
    int en = -1;
    vector<int> b = a;

    int cntmore = 0;
    for (int i = 1; i <= 9; i ++) {
        if (i * 10 + 1 > m) {
            cntmore += b[i];
            if (b[i] > 0)
                en = i;
        }
    }

    if (cntmore >= 2) return 0;

    if (en != -1)
        b[en]--;

    if (en != -1) {
        for (int i = en - 1; i >= 1; i--) {
            if (b[i] == 0) continue;
            if (last == -1) {
                last = i;
                break;
            }
        }
    }

    else {
        for (int i = 9; i >= 1; i--) {
            if (b[i] == 0) continue;
            if (last == -1) {
                last = i;
                en = i;
                b[i]--;
                if (b[i] > 0) {
                    bool fnd = 0;
                    for (int j = 1; j <= 9; j++) {
                        if (i * 10 + j <= m && b[j] > 0) {
                            fnd = 1;
                            break;
                        }
                    }

                    if (fnd) {
                        last = i;
                        break;
                    }
                }
            }

            else {
                last = i;
                break;
            }
        }
    }

    answ += last;
    b[last]--;

    for (int i = 1; i < n - (en != -1); i++) {
        bool fnd = 0;
        for (int j = 9; j > 0 && !fnd; j--) {
            if (b[j] > 0) {
                if (answ.back() * 10 + j <= m) {
                    b[j]--;
                    answ.push_back(j);
                    fnd = 1;
                }
            }
        }

        if (!fnd && i != 1) return 0;
    }

    if (en != -1) answ += en;

    return 1;
}

signed main() {
	ios :: sync_with_stdio(0);
	cin.tie(0);

    int ttt;
    cin >> ttt;

    while (ttt--) {
        int k;
        cin >> k;
        n = 0;

        for (int i = 1; i <= 9; i ++) {
            cin >> a[i];
            n += a[i];
        }

        if (k == 2) {
            int l = -1, r = 100;
            while (r - l > 1) {
                int m = (r + l) / 2;
                if (check(m)) {
                    r = m;
                }

                else {
                    l = m;
                }
            }

            check(r);
            for (auto u : answ) {
                cout << (int)u;
            }

            cout << endl;
            continue;
        }
    }

	return 0;
}
