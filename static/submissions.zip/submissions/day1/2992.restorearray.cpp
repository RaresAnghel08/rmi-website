/**
* user:  nikolov-5e9
* fname: Stanislav
* lname: Nikolov
* task:  restore
* score: 0.0
* date:  2019-10-10 10:21:25.100971
*/
#pragma GCC Optimize "O3"
#include <iostream>

const int MAX_N = 5e3 + 10;
const int MAX_M = 1e4 + 10;
struct Con {
	int l, r, k, v;
} con[MAX_M];
bool arr[MAX_N];
bool forced[MAX_N];

int main() {
	std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);

	int n, m;
	std::cin >> n >> m;

	for(int i = 0;i < m;i ++) {
		std::cin >> con[i].l >> con[i].r >> con[i].k >> con[i].v;
	}

	bool shit = false;
	for(int i = 0;i < m;i ++) {
		if(con[i].k == 1) { // smallest
			if(con[i].v == 1) {
				for(int l = con[i].l;l <= con[i].r;l ++) {
					if(forced[l] and arr[l] == false) {
						shit = true;
						goto end;
					}
					arr[l] = true;
					forced[l] = true;
				}
			}
			if(con[i].v == 0) {
				bool ok = false;
				for(int l = con[i].l;l <= con[i].r;l ++) {
					if(forced[l] and arr[l] == false) {
						ok = true;
						break;
					}
				}
				if(!ok) {
					shit = true;
					goto end;
				}
			}
		} else { // biggest
			if(con[i].v == 0) {
				for(int l = con[i].l;l <= con[i].r;l ++) {
					if(forced[l] and arr[l] == true) {
						shit = true;
						goto end;
					}
					arr[l] = false;
					forced[l] = true;
				}
			}
			if(con[i].v == 1) {
				bool ok = false;
				for(int l = con[i].l;l <= con[i].r;l ++) {
					if(forced[l] and arr[l] == 1) {
						ok = true;
						break;
					}
				}
				if(!ok) {
					shit = true;
					goto end;
				}
			}
		}
	}

end:
	if(shit) {
		std::cout << -1 << std::endl;
		return 0;
	}
	for(int i = 0;i < n;i ++) {
		std::cout << arr[i] << ' ';
	}
	std::cout << std::endl;
	return 0;
}
