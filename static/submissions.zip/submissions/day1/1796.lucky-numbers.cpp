/**
* user:  tudose-aad
* fname: Maria Alexa
* lname: Tudose
* task:  lucky
* score: 0.0
* date:  2019-10-10 07:48:39.389650
*/
#include <bits/stdc++.h>

using namespace std;

const int Mod = 1e9 + 7;
const int Nmax = 1e5 + 5;


typedef long long ll;
typedef vector<vector<int>> matrix;

static int inm(int x, int y) { return (ll) x * y % Mod; }
static void add_to(int &x, int y) { x += y; if(x >= Mod) x -= Mod; }
static int add(int x, int y) { x+=y; return (x < Mod ? x : x - Mod); }




matrix A, B, invA, powA[Nmax], inv_powA[Nmax];
matrix coef[16];


int n, q;
char X[Nmax];


void init(matrix &A, int n, int m)
{
    A.clear();
    A.resize(n);
    for(auto &it : A)
        it.resize(m, 0);
}

matrix inm(const matrix &A, const matrix &B)
{
    matrix C;
    assert(A[0].size() == B.size());

    init(C, A.size(), B[0].size());

    int i, j, k;
    for(i=0; i<A.size(); ++i)
        for(j=0; j<B[0].size(); ++j)
            for(k=0; k<B.size(); ++k)
                add_to(C[i][j], inm(A[i][k], B[k][j]));
    return C;
}

void operator += (matrix &A, const matrix &B)
{
    assert(A.size() == B.size() && A[0].size() == B[0].size());

    int i, j;
    for(i=0; i<A.size(); ++i)
        for(j=0; j<A[0].size(); ++j)
            add_to(A[i][j], B[i][j]);
}


int query(int l, int r) /// ma opresc la prima aparitie de 13 /// am grija sa adaug si numarul care e egal cu X daca e cazu
{


}

void update(int pos, int val)
{

}

void init_matrix()
{
    init(A, 2,2); init(invA, 2,2);

    A[0][0] = 9; A[0][1] = 1;
    A[1][0] = 8; A[1][1] = 1;

    invA[0][0] = 1; invA[0][1] = Mod-1;
    invA[1][0] = Mod-8; invA[1][1] = 9;

    init(powA[0], 2, 2); init(inv_powA[0], 2, 2);
    powA[0][0][0] = powA[0][1][1] = inv_powA[0][0][0] = inv_powA[0][1][1] = 1;

    powA[1] = A; inv_powA[1] = invA;

    int i;
    for(i=2; i<=n; ++i)
    {
        powA[i] = inm(powA[i-1], A);
        inv_powA[i] = inm(inv_powA[i-1], invA);
    }

    for(i=0; i<=9; ++i)
    {
        init(coef[i], 1, 2);
        if(i!=1) coef[i][0][0] = 1;
            else coef[i][0][1] = 1;
    }

    for(i=1; i<=9; ++i)
        coef[i] += coef[i-1];

    for(i=9; i; --i)
        coef[i] = coef[i-1];

    init(coef[0], 1, 2);

    init(B, 2, 1);
    B[0][0] = B[1][0] = 1;
}

void prepare()
{
    matrix sum;
    init(sum, 1, 2);

    int i;
    for(i=1; i<=n; ++i)
    {
        if(i >= 3 && X[i-2] == '1' && X[i-1] == '3') break;
        sum += inm(coef[X[i] - '0'], powA[n-i]);
    }

    int ans = inm(sum, B)[0][0];

    if(i == n+1) add_to(ans, 1);
    cout << ans << '\n';
}

int main()
{
    //freopen("input", "r", stdin);
    cin.sync_with_stdio(false); cin.tie(0);

    cin >> n >> q;
    cin >> (X+1);

    init_matrix();
    prepare();

    while(q--)
    {
        int tip, x, y;
        cin >> tip >> x >> y;

        if(tip == 1)
            cout << query(x, y) << '\n';
                else update(x, y);
    }

    return 0;
}
