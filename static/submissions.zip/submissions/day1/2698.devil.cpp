/**
* user:  bartoli-2aa
* fname: Davide
* lname: Bartoli
* task:  devil
* score: 0.0
* date:  2019-10-10 09:49:03.417029
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<int>a(10);
int pros=9,prim=1;
int prossimo(){
    if(a[pros]>0){
        a[pros]--;
        return pros;
    }
    pros--;
    return prossimo();
}
int primo(){
    if(a[prim]>0){
        a[prim]--;
        return pros;
    }
    prim++;
    return primo();
}
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int T;
    cin>>T;
    while(T--){
        int K;
        cin>>K;
        fill(a.begin(),a.end(),0);
        int tot=0;
        for(int i=1;i<10;i++){
            cin>>a[i];
            tot+=a[i];
        }
        vector<int>sol(tot,0);
        for(int i=tot-1;i>tot-K;i--){
            sol[i]=prossimo();
        }
        sol[tot-K]=primo();
        tot-=K;
        bool p=0;
        if(a[1]<a[2]){
            p=1;
        }
        if(p==0){
            if(a[2]==0){
                for(int i=0;i<sol.size();i++){
                    if(sol[i]==0)sol[i]=primo();
                    cout<<sol[i];
                }
                cout<<endl;
                continue;
            }
            int o=(int)(ceil((float)(tot)/a[2]));
            for(int i=0;i<K;i+=o){
                for(int j=i;j<tot;j+=K)sol[j]=prossimo();
            }
            for(int i=0;i<sol.size();i++){
                if(sol[i]==0)sol[i]=primo();
                cout<<sol[i];
            }
            cout<<endl;
        }else{
            int o=(int)(ceil((float)(tot)/(a[1]+1)))-1;
            for(int i=o;i<K;i+=o){
                for(int j=i;j<tot;j+=K)sol[j]=primo();
            }
            for(int i=0;i<sol.size();i++){
                if(sol[i]==0)sol[i]=prossimo();
                cout<<sol[i];
            }
            cout<<endl;
        }
    }
    return 0;
}
