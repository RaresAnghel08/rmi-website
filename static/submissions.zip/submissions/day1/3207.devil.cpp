/**
* user:  kuts-04f
* fname: Andiy
* lname: Kuts
* task:  devil
* score: 0.0
* date:  2019-10-10 10:38:51.936672
*/
#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define ld long double
#define fi first
#define se second
#define ull unsigned long long
#define db double

const int MAXN = 100005;


int main()
{
    int t; cin >> t;
    while(t--)
    {
        int k; cin >> k; int n = 0;
        int cnt[9];
        vector<int> dat;
        for(int i = 0; i < 9; i++)
        {
            cin >> cnt[i]; n += cnt[i];
            for(int j = 0; j < cnt[i]; j++)
            {
                dat.push_back(i+1);
            }
        }
        vector<string> strs;
        for(int i = 0; i < cnt[dat.back()-1]; i++)
        {
            string s = ""; s += (char)(dat.back()+'0');
            strs.push_back(s);
        }
        int ind = 0, sm = 0;
        while(1)
        {
            if(dat[sm] == dat.back())
                break;
            for(int i = ind; i < strs.size(); i++)
            {
                char c = dat[sm++]+'0';
                strs[i] += c;
                if(dat[sm] == dat.back())
                    break;
            }
            if(dat[sm] == dat.back())
                break;
            for(int i = ind; i < strs.size(); i++)
            {
                if(strs[i].back() < strs.back().back())
                    ind++;
                else
                    break;
            }
        }
        string ans = "";
        for(int i = 0; i < strs.size(); i++)
        {
            ans += strs[i];
        }
        cout << ans << '\n';

    }

}


































/// Shche ne vmerla Ykraina i Rok
