/**
* user:  perju-verzotti-a3f
* fname: Luca
* lname: Perju-Verzotti
* task:  restore
* score: 13.0
* date:  2019-10-10 09:25:04.639564
*/
#include <iostream>
#include <algorithm>
using namespace std;
struct ura
{
    int l,r,k,val;
}v[10003];
int rz[5003];
bool cmp (ura a, ura b)
{
    if(a.l<b.l)
        return true;
    if(a.l>b.l)
        return false;
    return a.r<b.r;
}
int main()
{
    ios_base::sync_with_stdio(0);
    int n,m,i,j;
    cin>>n>>m;
    for(i=1;i<=m;++i)
    {
        cin>>v[i].l>>v[i].r>>v[i].k>>v[i].val;
        ++v[i].l;
        ++v[i].r;
    }
    for(i=1;i<=m;++i)
    {
        if(v[i].l==v[i].r)
        {
            if(v[i].val==0)
                --v[i].val;
            j=v[i].l;
            if(rz[j]==0 || rz[j]==v[i].val)
                rz[j]=v[i].val;
            else
            {
                cout<<-1;
                return 0;
            }
            v[i].val=-1;
            continue;
        }
        if(v[i].val==0)
        {
            if(v[i].k!=1)
            {
                for(j=v[i].l;j<=v[i].r;++j)
                {
                    if(rz[j]==0 || rz[j]==-1)
                        rz[j]=-1;
                    else
                    {
                        cout<<-1;
                        return 0;
                    }
                }
                v[i].val=-1;
            }
        }
        if(v[i].val==1)
        {
            if(v[i].k==1)
            {
                for(j=v[i].l;j<=v[i].r;++j)
                {
                    if(rz[j]==0 || rz[j]==1)
                        rz[j]=1;
                    else
                    {
                        cout<<-1;
                        return 0;
                    }
                }
                v[i].val=-1;
            }
        }
    }
    sort(v+1,v+m+1,cmp);
    for(i=1;i<=m;++i)
    {
        if(v[i].val==-1)
            continue;
        int a=v[i].val;
        if(a==0)
            --a;
        for(j=v[i].l;j<=v[i].r;++j)
        {
            if(rz[j]==a)
                break;
            if(rz[j]==0)
            {
                rz[j]=a;
                break;
            }
        }
        if(j==v[i].r+1)
        {
            cout<<-1;
            return 0;
        }
    }
    for(i=1;i<=n;++i)
    {
        if(rz[i]==0)
            cout<<i%2<<' ';
        else
        if(rz[i]==-1)
            cout<<0<<' ';
        else
            cout<<1<<' ';
    }
    return 0;
}
