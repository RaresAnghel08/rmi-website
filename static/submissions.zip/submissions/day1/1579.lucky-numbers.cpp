/**
* user:  bachurski-d21
* fname: Jakub
* lname: Bachurski
* task:  lucky
* score: 46.0
* date:  2019-10-10 07:10:12.503138
*/
#ifdef EVAL
#pragma GCC optimize ("Ofast")
#pragma GCC target ("tune=native")
#endif
#include <bits/stdc++.h>

using namespace std;

using uint = unsigned;
const uint64_t MOD = 1e9 + 7;

pair<uint, uint> brute_pair(vector<uint> S, size_t n, bool plusone = false)
{
    uint v = 0;
    for(size_t i = 1; i <= n; i++)
        v *= 10, v += S[i];
    v += plusone;
    uint r0 = 0, r1 = 0;
    for(size_t x = 0; x < v; x++)
    {
        auto s = to_string(x);
        bool ok = true;
        for(size_t i = 0; i+1 < s.size(); i++)
            if(s[i] == '1' and s[i+1] == '3')
                ok = false;
        if(ok)
        {
            if(x % 10 == 1)
                r1++;
            else
                r0++;
        }
    }
    return {r0, r1};
}

uint brute(vector<uint> S, size_t n, bool plusone = false)
{
    auto w = brute_pair(S, n, plusone);
    return w.first + w.second;
}

uint64_t calc(vector<uint> S)
{
    const size_t n = S.size() - 1;
    bool no13 = true;
    vector<pair<uint64_t, uint64_t>> W(n + 1);
    
    for(size_t i = 1; i <= n; i++)
    {
        W[i] = {
            (9*W[i-1].first + 8*W[i-1].second + no13*(S[i] - (S[i-1] == 1 and S[i] > 3) - (S[i] > 1))) % MOD,
            (W[i-1].first + W[i-1].second + no13*(S[i] > 1)) % MOD
        };
        if(S[i-1] == 1 and S[i] == 3)
            no13 = false;
    }

#ifndef EVAL
    if(S.size() < 8)
        cout << flush << "?? " << brute(S, S.size()-1, true) << endl;
#endif

    return (W.back().first + W.back().second + no13) % MOD;
}

int main()
{
    ios::sync_with_stdio(false); cin.tie(nullptr);
    
    size_t n, q;
    cin >> n >> q;
    string S;
    cin >> S;
    
    vector<uint> A(n+1);
    for(size_t i = 1; i <= n; i++)
        A[i] = S[i-1] - '0';
        
    cout << calc(A) << '\n';

    while(q --> 0)
    {
        size_t t, l, r;
        cin >> t >> l >> r;
        if(t == 1)
        {
            vector<uint> B(A.begin() + (l-1), A.begin() + r+1);
            B[0] = 0;
            cout << calc(B) << '\n';
        }
        else if(t == 2)
        {
            A[l] = r;
        }
    }
}
