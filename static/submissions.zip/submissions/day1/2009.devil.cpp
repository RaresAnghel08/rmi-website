/**
* user:  lifar-7f1
* fname: Egor
* lname: Lifar
* task:  devil
* score: 0.0
* date:  2019-10-10 08:19:59.258007
*/
#include <bits/stdc++.h>

using namespace std;
template<class A, class B> inline void chkmin(A &a, B b){ a = (a > b ? b: a);}
template<class A, class B> inline void chkmax(A &a, B b){ a = (a < b ? b: a);}
#define all(c) (c).begin(), (c).end()
#define sz(c) (int)(c).size()
#define pb push_back
#define mp make_pair
using ll = long long;
using ld = long double;


int k;
int d[10];


void solve() {
	cin >> k;
	for (int i = 1; i <= 9; i++) {
		cin >> d[i];
	}
	if (d[2] < k) {
		for (int i = 0; i < d[1]; i++) {
			cout << 1;
		}
		for (int i = 0; i < d[2]; i++) {
			cout << 2;
		}
		cout << '\n';
	} else {
		int t = d[2] - k + 1;
		int f = d[1] / t;
		int g = d[1] % t;
		string s;
		for (int i = 0; i < t; i++) {
			s += '2';
			for (int j = 0; j < f; j++) {
				s += '1';
			}
			if (t - i <= g) {
				s += '1';
			}
		}
		for (int i = 0; i < k - 1; i++) {
			s += '2';
		}
		cout << s << '\n';
	}
}


int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	//freopen("input.in", "r", stdin);
	int t;
	cin >> t;
	for (int it = 0; it < t; it++) {
		solve();
	}
	return 0;
}