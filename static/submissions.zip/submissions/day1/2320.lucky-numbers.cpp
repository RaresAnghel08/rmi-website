/**
* user:  todorov-9fe
* fname: Andon
* lname: Todorov
* task:  lucky
* score: 0.0
* date:  2019-10-10 09:00:00.786459
*/
#include <bits/stdc++.h>
#define mod 1000000007
using namespace std;
long long n, q, dp [100005][2][2];
string x;
void solve (){
	if (x [0] == '0'){
		dp [0][0][1] = 1;
		dp [0][0][0] = dp [0][1][0] = dp [0][1][1] = 0;
	}
	else{
		if (x [0] != '1'){
			dp [0][0][1] = 1;
			dp [0][1][0] = 1;
			dp [0][1][1] = 0;
			dp [0][0][0] = x [0] - '1';
		}
		else{
			dp [0][0][1] = dp [0][1][0] = 0;
			dp [0][1][1] = dp [0][0][0] = 1;
		}
	}
	for (int i = 1; i < n; i ++){
		dp [i][0][0] = dp [i - 1][1][0] * 8ll + dp [i - 1][0][0] * 9ll + dp [i - 1][0][1] * (x [i] - '1') + dp [i - 1][1][1] * (x [i] - '1');
		if (x [i] == '0' || x [i] == '1') dp [i][0][0] += dp [i - 1][0][1] + dp [i - 1][1][1];
		if (x [i] > '3') dp [i][0][0] -= dp [i - 1][1][1];
		dp [i][1][0] = dp [i - 1][0][0] + dp [i - 1][1][0] + dp [i - 1][1][1] + dp [i - 1][0][1];
		if (x [i] == '0' || x [i] == '1') dp [i][1][0] -= dp [i - 1][1][1] + dp [i - 1][0][1];
		dp [i][0][1] = dp [i - 1][1][1] + dp [i - 1][0][1];
		if (x [i] == '3') dp [i][0][1] -= dp [i - 1][1][1];
		if (x [i] == '1') dp [i][0][1] = 0;
		dp [i][1][1] = 0;
		if (x [i] == '1') dp [i][1][1] = 1;
		dp [i][0][0] %= mod;
		dp [i][0][1] %= mod;
		dp [i][1][0] %= mod;
		dp [i][1][1] %= mod;
	}
	cout <<( dp [n - 1][0][0] + dp [n - 1][0][1] + dp [n - 1][1][1] + dp [n - 1][1][0]) % mod << '\n';

}
int main (){

	ios::sync_with_stdio (false);
	cin.tie (0);

	cin >> n >> q >> x;
	string y = x;
	
	while (q --){
		int t;
		cin >> t;
		if (t == 1){
			int l, r;
			cin >> l >> r;
			r = r - l + 1;
			l --;
			x = y.substr (l, r);
			n = r;
			solve ();
		}
		if (t == 2){
			int pos, d;
			cin >> pos >> d;
			y [pos - 1] = d + '0';
		}
	}

}
