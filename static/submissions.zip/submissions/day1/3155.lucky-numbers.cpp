/**
* user:  smilenov-5e5
* fname: Ivan
* lname: Smilenov
* task:  lucky
* score: 14.0
* date:  2019-10-10 10:35:52.040924
*/
#include<bits/stdc++.h>
#define MAXN 131072
#define MOD 1000000007
using namespace std;
unsigned long long n,q,ans,t;
unsigned long long dp[MAXN];
string s,h;
int main()
{
    long long i,j,a,b;
    dp[0]=1;
    dp[1]=10;
    cin>>n>>q;
    cin>>s;
    for(i=2; i<n; i++)
    {
        dp[i]=(((((dp[i-1]*10))+MOD)-dp[i-2]));
        dp[i]%=MOD;
    }
    ans=dp[n-1];
    if(n==1)
    {
        t+=((s[0]-'0')*dp[n-1]);
    }
    else
    if(s[0]!='0')t+=((s[0]-'0'-1)*dp[n-1]);
    t%=MOD;
    if(n>=3)t+=(MOD-dp[n-2]);
    t%=MOD;
    //cout<<t<<endl;
    for(i=2; i<=n; i++)
    {
        //cout<<i<<" "<<s[i]<<endl;
        if(i==n)t=t+(((s[i-1]-'0'+1)*dp[n-i]));
        else if(s[i-1]!='0')t=t+(((s[i-1]-'0')*dp[n-i]));
        t%=MOD;
        if(s[i-1]!='0'&&n-i-1>=0)t+=(MOD-dp[n-i-1]);
        t%=MOD;
    }
    //cout<<t<<endl;
    cout<<(ans+t)%MOD<<endl;
    h=s;
    while(q--)
    {
        cin>>t>>a>>b;
        if(t==2)
        {
            h[a-1]=char((b+'0'));
            //cout<<h<<endl;
        }
        else
        {
            s="";
            for(i=a; i<=b; i++)
            {
                s+=h[i-1];
            }
            //cout<<s<<endl;
            n=s.size();
            ans=dp[n-1];
            if(s[0]!='0')t+=((s[0]-'0'-1)*dp[n-1]);
            t%=MOD;
            if(n>=2)t+=(MOD-dp[n-2]);
            t%=MOD;
            //cout<<t<<endl;
            for(i=2; i<=n; i++)
            {
                //cout<<i<<" "<<s[i]<<endl;
                /*if(i==n)t=t+(((s[i-1]-'0'+1)*dp[n-i]));
                else*/ if(s[i-1]!='0')t=t+(((s[i-1]-'0')*dp[n-i]));
                t%=MOD;
                if(s[i-1]!='0'&&n-i-1>=0)t+=(MOD-dp[n-i-1]);
                t%=MOD;
            }
            cout<<(ans+t)%MOD<<endl;
        }

    }
    return 0;
}
