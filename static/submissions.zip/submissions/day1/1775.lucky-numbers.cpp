/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  lucky
* score: 14.0
* date:  2019-10-10 07:45:15.488496
*/
#include<bits/stdc++.h>
using namespace std;
#define ll long long
string x;
ll k;
ll q;
ll MOD=1e18;
pair<ll,ll>ans=make_pair(0ll,0ll);
bool ok(string s1,string s2,ll t)
{
	for(ll i=s2.size()-1;i>=0;i--)
	{
		if(s2[i]=='o')
		{
			s2[i]=t%10+'0';
			t/=10;
		}
	}
	if(s1>s2)return 1;
	return 0;
}
ll pow1(ll x,ll y)
{
	ll ret=1;
	for(ll i=0;i<y;i++)ret*=x;
	return ret;
}
void gen(ll i,ll count,string s)
{
	if(i==x.size())
	{
		ll mid,ans1=0,l1=0,r1=pow1(10ll,x.size()-count*2)-1;
		while(l1<=r1)
		{
			mid=l1/2+r1/2+max(0ll,l1%2+r1%2-1);
			if(ok(x,s,mid))
			{
				ans1=mid;l1=mid+1ll;
			}
			else r1=mid-1ll;
		}
		ans1++;
		if(count%2==1){/*cout<<s<<" "<<ans1<<endl;*/ans.second+=ans1;ans.first+=ans.second/MOD;ans.second%=MOD;}
		else {ans.second-=ans1;if(ans.first>0&&ans.second<0)ans.second+=MOD,ans.first--;/*cout<<s<<" "<<-ans1<<endl;*/}
		return;
	}
	gen(i+1,count,s+"o");
	if(i+2<=x.size())gen(i+2,count+1,s+"13");
	
}
int main()
{
	ll n,q;cin>>n>>q;
	cin>>x;
	for(ll i=0;i<n;i++)
	{
		k*=10;k+=x[i]-'0';
	}
	gen(0,0,"");
	cout<<-ans.first*MOD-ans.second+1<<endl;
return 0;
}
