/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  lucky
* score: 14.0
* date:  2019-10-10 06:57:07.279206
*/
#include <iostream>

using namespace std;

int N, Q;

int Nr1;

static inline bool Ok (int X)
{
    int ld = 0;

    while(X)
    {
        int d = (X % 10);

        if(d == 1 && ld == 3)
            return false;

        ld = d;

        X /= 10;
    }

    return true;
}

int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> N >> Q;

    if(N <= 6)
    {
        cin >> Nr1;

        int ans = 0;

        for(int i = 0; i <= Nr1; ++i)
            if(Ok(i))
                ++ans;

        cout << ans << '\n';
    }

    return 0;
}
