/**
* user:  ismailov-374
* fname: Ferit
* lname: Ismailov
* task:  devil
* score: 0.0
* date:  2019-10-10 07:02:15.852815
*/
#include<bits/stdc++.h>
#define endl "\n"
using namespace std;
int t,d[10],k;
/*void rec(int l,int r,int cu,int sz)
{
    if(l>r)return;
    if(d[l]<=0)rec(l+1,r,cu,sz);
    if(d[r]<=0)rec(l,r-1,cu,sz);
    //if(sz>10)return;
    //cout<<d[l]<<" "<<d[r]<<endl;
    if(cu==0)
    {
        cout<<l<<"sad";
        d[l]--;
        rec(l,r,(cu+1)%2,sz+1);
    }
    else
    {
        cout<<r<<"sad";
        d[r]--;
        rec(l,r,(cu+1)%2,sz+1);
    }
}*/
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    while(t--)
    {
        cin>>k;
        for(int i=1;i<=9;i++)
        {
            cin>>d[i];
        }
        int l=1,r=9,sh=0;
        while(l<=r)
        {
            if(d[l]<=0){l++;continue;}
            if(d[r]<=0){r--;continue;}
            if(sh==0)
            {
                cout<<l;
                d[l]--;
                sh^=1;
            }
            else
            {
                cout<<r;
                d[r]--;
                sh^=1;
            }
        }
        cout<<endl;
    }
}
