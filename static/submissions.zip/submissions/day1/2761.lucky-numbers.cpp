/**
* user:  frolov-001
* fname: Konstantin
* lname: Frolov
* task:  lucky
* score: 28.0
* date:  2019-10-10 09:56:16.556511
*/
#include <bits/stdc++.h>
#define FOR(i, n) for (int i = 0; i < n; ++i)
#define debug(x) std::cout << #x << ": " << x << '\n';
#define pb push_back
typedef long long ll;
const int N = 1e4 + 10, mod = 1e9 + 7;
int add(int a, int b) {
	return (a + b) % mod;
}
int sub(int a, int b) {
	return (a - b + mod) % mod;
}
struct vertex {
	bool isNull = false;
	int kek[10][10][3];
	vertex() {
		isNull = false;
		memset(kek, 0, sizeof(kek));
	}
	vertex(bool x) {
		isNull = x;
	}
	friend vertex operator+(vertex a, vertex b) {
		if (a.isNull) return b;
		if (b.isNull) return a;
		vertex answ;
		for (int pref1 = 0; pref1 < 3; ++pref1) {
			for (int suf1 = 0; suf1 < 3; ++suf1) {
				int res = 0;
				if (pref1 == 0) {
					res = 0;
				}
				if (pref1 == 1) {
					res = suf1;
				}
				if (pref1 == 2) {
					res = 2;
				}
				FOR(t1, 10) {
					FOR(t2, 10) {
						FOR(t3, 10) {
							FOR(t4, 10) {
								if (t2 != 1 || t3 != 3) {
									answ.kek[t1][t4][res] += (a.kek[t1][t2][pref1] * 1LL * b.kek[t3][t4][suf1]) % mod;
									answ.kek[t1][t4][res] %= mod;
								}
							}
						}
					}
				}
			}
		}
		return answ;
	}
	int getAnsw() {
		int sum = 0;
		FOR(j, 10) {
			FOR(q, 10) {
				sum = add(sum, kek[j][q][0]);
				sum = add(sum, kek[j][q][1]);
				// if (kek[j][q][0] != 0) {
				// 	debug(j << ' ' << q)
				// }
			}
		}
		return sum;
	}
};
struct seg_tree {
	vertex tree[4 * N];
	seg_tree() {}
	void upd(int v, int tl, int tr, int i, int x) {
		if (tl == tr) {
			tree[v] = vertex();
			// debug(v << ' ' << x)
			for (int j = 0; j < 10; ++j) {
				if (j < x) {
					tree[v].kek[j][j][0] = 1;
				}
				if (j == x) {
					tree[v].kek[j][j][1] = 1;
				}
				if (j > x) {
					tree[v].kek[j][j][2] = 1;
				}
			}
			// debug(v)
			return;
		}
		int tm = (tl + tr) / 2;
		if (tm >= i) {
			upd(v * 2, tl, tm, i, x);
		}
		else {
			upd(v * 2 + 1, tm + 1, tr, i, x);
		}
		// debug(v);
		tree[v] = tree[v * 2] + tree[v * 2 + 1];
	}
	vertex get(int v, int tl, int tr, int l, int r) {
		if (l > r) return vertex(true);
		if (tl == l && tr == r) {
			// debug(v)
			return tree[v];
		}
		int tm = (tl + tr) / 2;
		return get(v * 2, tl, tm, l, std::min(r, tm)) + 
			   get(v * 2 + 1, tm + 1, tr, std::max(tm + 1, l), r);
	}
};

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(0); std::cout.tie(0);
	int n, q;
	std::cin >> n >> q;
	std::string s;
	std::cin >> s;
	seg_tree kek;
	FOR(i, s.size()) {
		kek.upd(1, 0, n - 1, i, s[i] - '0');
	}
	std::cout << kek.get(1, 0, n - 1, 0, n - 1).getAnsw() << '\n';
	FOR(i, q) {
		int t, l, r;
		std::cin >> t >> l >> r;
		if (t == 1) {
			std::cout << kek.get(1, 0, n - 1, l - 1, r - 1).getAnsw() << '\n';
		}
		else {
			kek.upd(1, 0, n - 1, l - 1, r);
		}
	}
}