/**
* user:  todorov-9fe
* fname: Andon
* lname: Todorov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:20:10.015670
*/
#include <bits/stdc++.h>
using namespace std;
int s, k, d [10];
int main (){

	ios::sync_with_stdio (false);
	cin.tie (0);

	int t;
	cin >> t;
	while (t --){
		cin >> k;
		s = 0;
		for (int i = 1; i < 9; i ++) cin >> d [i], s += d [i];
		if (d [2] < k){
			for (int i = 0; i < d [1]; i ++) cout << 1;
			for (int i = 0; i < d [2]; i ++) cout << 2;
			cout << '\n';
			continue;
		}
		int a = d [1], b = d [2];
		string A = "1", B = "2";
		b -= k - 1;
		while (a > 0){
			int x = a / b, y = a % b;
			for (int i = 0; i < x; i ++){
				a -= b;
				B += A;
			}
			A = B + A;
			a = y;
			b -= y;
		}
		for (int i = 0; i < b; i ++) cout << b;
		for (int i = 1; i < k; i ++) cout << 2;
		cout << '\n';
	}


}
