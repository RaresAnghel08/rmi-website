/**
* user:  dimitrov-6bb
* fname: Atanas
* lname: Dimitrov
* task:  devil
* score: 14.0
* date:  2019-10-10 07:34:35.599126
*/
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
#define endl "\n"
#define sz(x) (int)x.size()

const int n = 10;
int cnt[13], cpy[13];

int main() {
	ios_base::sync_with_stdio(false); cin.tie(NULL);
	int t;
	cin >> t;
	while(t --) {
		int k;
		cin >> k;
		string mas;
		for(int i = 1; i < n; i ++) {
			cin >> cnt[i];
			cpy[i] = cnt[i];
			for(int j = 0; j < cnt[i]; j ++) {
				mas.push_back(i + '0');
			}
		}
		int l = 0, r = mas.size() - 1;
		string ans = "";
		while(l < r) {
			ans.push_back(mas[r]);
			ans.push_back(mas[l]);
			-- r; ++ l;
		}
		if(l == r) {
			ans.push_back(mas[l]);
		}
		for(int i = 0; i < ans.size(); i ++) {
			cout << ans[ans.size() - 1 - i];
		}
		cout << endl;
	}
}	
