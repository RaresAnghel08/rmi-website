/**
* user:  mihov-a15
* fname: Rumen
* lname: Mihov
* task:  restore
* score: 0.0
* date:  2019-10-10 06:24:14.249107
*/
# include <bits/stdc++.h>

using namespace std;
int a[5005];
struct pipe
{
    int l,r,ans;
} ;
pipe q[5001];
int br;
bool cmp(pipe i, pipe j)
{
    if(i.l<j.l)return true;
    if(i.l==j.l)
    {
        return i.r<j.r;
    }
    return false;
}
int main()
{
ios_base::sync_with_stdio(false);
cin.tie(nullptr);
cout.tie(nullptr);
int n,m;
cin>>n>>m;
int i,j;
memset(a,-1,sizeof(a));
int l,r,k,ans;
for(i=1;i<=m;i++)
{
    cin>>l>>r>>k>>ans;
    if(k==1&&ans==1)
    {
        for(j=l;j<=r;j++)
        {
            if(a[j]==0){cout<<"-1"<<endl;return 0;}
            a[j]=1;
        }
    }
    if(k==(r-l+1)&&ans==0)
    {
        for(j=l;j<=r;j++)
        {
            if(a[j]==1){cout<<"-1"<<endl;return 0;}
            a[j]=0;
        }
    }
    if(k==1&&ans==0)
    {
        br++;
        q[br].l=l;
        q[br].r=r;
        q[br].ans=0;
    }
    if(k==(r-l+1)&&ans==1)
    {
         br++;
        q[br].l=l;
        q[br].r=r;
        q[br].ans=1;
    }
}sort(q+1,q+br+1,cmp);
for(i=1;i<=br;i++)
{
    l=q[i].l;
    r=q[i].r;
    ans=q[i].ans;
    bool fl=false;
    for(j=l;j<=r;j++)
    {
        if(a[j]==ans){fl=true;break;}
    }
    if(!fl)
    {
        for(j=l;j<=r;j++)
        {
            if(a[j]==-1){a[j]=ans;fl=true;break;}
        }
        if(!fl){cout<<-1<<endl;return 0;}
    }
}

for(i=0;i<n;i++)
{
    if(a[i]==0||a[i]==-1)cout<<"0"<<" ";
    else
        cout<<1<<" ";
}
}

