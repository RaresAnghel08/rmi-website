/**
* user:  gyimesi-781
* fname: Péter
* lname: Gyimesi
* task:  devil
* score: 56.0
* date:  2019-10-10 10:37:05.370552
*/
#include <bits/stdc++.h>

using namespace std;
int q;
int t[10];
int s;
int sum;
vector<int> v;
long long check()
{
    long long maxi=0;
    int si=v.size();
    for (int i=si; i>=s; i--) {
        long long ans=0;
        for (int j=i-s; j<i; j++) {
            ans*=10;
            ans+=v[j];
        }
        maxi=max(maxi, ans);
    }
    return maxi;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin >> q;
    for (int i=1; i<=q; i++) {
        cin >> s;
        int n;
        v.clear();
        sum=0;
        for (int i=1; i<=9; i++) {
            cin >> t[i];
            sum+=t[i];
            for (int j=1; j<=t[i]; j++) {
                v.push_back(i);
            }
        }
        n=v.size();
        int x=(n-1)/2;
        if (s==2) {
            cout << v[x];
            for (int i=1; i<=x; i++) {
                if (n%2==0) {
                    cout << v[x+i] << v[x-i];
                } else {
                    cout << v[x-i] << v[x+i];
                }
            }
            if (n%2==0) {
                cout << v.back();
            }
            cout << "\n";
        } else  if (sum<=12){
            long long mini=(long long)1000000000000000;
            mini=min(mini, check());
            while(next_permutation(v.begin(), v.end())) {
                mini=min(mini, check());
            }
            if (mini==check()) {
                for (int i=0; i<v.size(); i++) {
                    cout << v[i];
                }
                cout << "\n";
                continue;
            }
            while(next_permutation(v.begin(), v.end())) {
                if (mini==check()) {
                    for (int i=0; i<v.size(); i++) {
                        cout << v[i];
                    }
                    cout << "\n";
                    break;
                }
            }
        } else {
            int a=t[1], b=t[2];
            if (s>b) {
                for (int i=1; i<=a+b; i++) {
                    if (i<=a) {
                        cout << 1;
                    } else {
                        cout << 2;
                    }
                }
                cout << "\n";
            } else {
            b-=s-1;
            int j=1;
            for (int i=1; i<=a+b; i++) {
                double x=a+b;
                double y=i;
                double p=j;
                double q=a;
                if (y/x>=p/q) {
                    cout << 1;
                    j++;
                } else {
                    cout << 2;
                }
            }
            for (int i=1; i<s; i++) {
                cout << 2;
            }
            cout << "\n";
        }
        }
    }
    return 0;
}
