/**
* user:  purice-512
* fname: Victor
* lname: Purice
* task:  devil
* score: 0.0
* date:  2019-10-10 06:40:08.225535
*/
#include <bits/stdc++.h>
#define rc(s) return cout << s,0
#define all(s) s.begin(),e.end()
#define int long long
#define fr first
#define sc second
using namespace std;

int t,k,d[10],ans=1e18;
vector<int>arr;
vector<int>rs;

int32_t main(){
    ios_base::sync_with_stdio();cin.tie();cout.tie();
    cin >> t;
    while(t--){
        cin >> k;
        arr.clear();
        rs.clear();
        ans=1e18;
        if(k==2){
            int j=-1;
            int sum=0;
            for(int i=1;i<=9;i++){
                cin >> d[i];
                sum+=d[i];
            }
            int rrr[sum+5];
            for(int i=1;i<=9;i++){
                while(d[i]){
                    d[i]--;
                    j+=2;
                    if(j>sum) j=2;
                    rrr[j]=i;
                }
            }
            for(int i=1;i<=sum;i++){
                cout << rrr[i];
            }
            cout << '\n';
        }
        else{for(int i=1;i<=9;i++){
            cin >> d[i];
            while(d[i]){
                d[i]--;
                arr.push_back(i);
            }
        }
        do{
            int cntmax=0;
            for(int i=0;i<=arr.size()-k;i++){
                int cnt=0;
                for(int j=i;j<=i+k-1;j++){
                    cnt*=10;
                    cnt+=arr[j];
                }
                cntmax=max(cnt,cntmax);
            }
            if(cntmax<ans){
                ans=cntmax;
                rs=arr;
            }
        }while(next_permutation(arr.begin(),arr.end())==true);
        for(int i=0;i<rs.size();i++){
            cout << rs[i];
        }
        cout <<  '\n';}
    }
}
