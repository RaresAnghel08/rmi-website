/**
* user:  ibovski-dc0
* fname: Adriyan
* lname: Ibovski
* task:  devil
* score: 0.0
* date:  2019-10-10 10:34:35.402149
*/
# include<iostream>
using namespace std;

long long a[16];

int main()
{
    int t;
    cin>>t;
    for(int Test=0; Test<t; Test++)
    {
        int k;
        cin>>k;
        if(k==2)
        {
            long long last=0,last2=0;
            for(int i=1; i<10; i++)
            {
                cin>>a[i];
                if(a[i]) last2=i;
            }
            last=last2;
            long long minp=0;
            for(int i=1; i<10; i++)
                if(a[i]) {minp=i; break;}
            if(a[last2]==1)
                for(int i=1; i<last2; i++) if(a[i]) last=i;
            long long sum=0;
            a[last]-=2;
            if(last!=last2) a[last]++;
            a[minp]--;
            for(int i=minp; i<last; i++) sum+=a[i];
            cout<<last<<minp;
            long long d=sum-a[last];
            if(d<0)
            {
                while(a[last]>0) {cout<<last; a[last]--;}
                for(int i=minp; i<=9; i++)
                    for(int j=0; j<a[i]; j++) cout<<i;
                    if(last==last2)
                cout<<last;
            }
            else
            {
                for(int i=1; i<last; i++)
                {
                    while(a[i]>0 && a[last]>0)
                    {
                        cout<<last<<i;
                        a[i]--;
                        a[last]--;
                    }
                }
                for(int i=last-1; i>=1; i--)
                {
                    if(d<0) break;
                    while(a[i]>0 && d>0)
                    {
                        cout<<i;
                        a[i]--;
                        d--;
                    }
                }
                for(int i=minp; i<=9; i++)
                {
                    for(int j=0; j<a[i]; j++) cout<<i;
                }
                if(last==last2)
                cout<<last;

            }
            cout<<endl;
        }

    }

    return 0;
}
