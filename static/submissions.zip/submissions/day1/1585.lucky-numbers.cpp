/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  lucky
* score: 14.0
* date:  2019-10-10 07:11:35.549213
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long x,n,q,ans=0;
	cin>>n>>q;
	cin>>x;
	for(int i=0;i<x;i++)
	{
	long long x1=i;
	while(x1)
	{
		if(x1%100==13){ans++;break;}
		x1/=10;
	}
	}
	cout<<x-ans+1<<endl;
return 0;
}
