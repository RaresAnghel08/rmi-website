/**
* user:  kliska-f84
* fname: Pavel
* lname: Kliska
* task:  devil
* score: 0.0
* date:  2019-10-10 07:30:37.854727
*/
#include <cstdio>
#include <vector>


using namespace std;

const int MAXL = 1000006;

int k,l, d[10];
char str[MAXL];
vector<vector<char>> seg;

int main(){
	int tcc;
	scanf("%d", &tcc);
	for(int tc=0;tc<tcc;++tc){
		int l=0;
		scanf("%d", &k);
		for(int i=1;i<=9;++i){
			scanf("%d", &d[i]);
			l += d[i];
		}
		str[l]=0;
		for(int i=1;i<k;++i){
			for(int j=9;j>=1;--j){
				if(d[j]){
					d[j]--;
					str[l-i]='0'+j;
					break;
				}
			}
		}
		l-=k-1;
		int m=0;
		for(int i=9;i>=1;--i){
			if(d[i]){
				m=i;
				break;
			}
		}
		seg.clear();
		seg.resize(d[m]);
		for(int i=0;i<d[m];++i){
			seg[i].push_back('0'+m);	
		}
		d[m]=0;
		int last=0, start=0;
		for(int num=1;num<=9;){
			for(int i=start;i<seg.size();++i){
				if(d[num]){
					seg[i].push_back('0'+num);
					last=i;
					d[num]--;
				}else{
					num++;
					if(i!=start){
						start=i;
					}
					break;
				}
			}
		}

		int sp=0;

		if(last==seg.size()-1){
			for(int t=0;t<start;){
				for(int i=start;i<seg.size();++i){
					seg[i].insert(seg[i].end(), seg[t].begin(), seg[t].end());
					t++;
				}
			}
			for(int i=start;i<seg.size();++i){
				for(int j=0;j<seg[i].size();++j){
					str[sp++]=seg[i][j];	
				}	
			}
		}else{
			for(int t=0;t<=last;){
				for(int i=last+1;i<seg.size();++i){
					seg[i].insert(seg[i].end(), seg[t].begin(), seg[t].end());
					t++;
				}
			}
			for(int i=last+1;i<seg.size();++i){
				for(int j=0;j<seg[i].size();++j){
					str[sp++]=seg[i][j];	
				}	
			}
		}
		puts(str);
	}	
	
}
