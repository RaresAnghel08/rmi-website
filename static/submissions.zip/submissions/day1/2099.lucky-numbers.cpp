/**
* user:  ibovski-dc0
* fname: Adriyan
* lname: Ibovski
* task:  lucky
* score: 14.0
* date:  2019-10-10 08:30:53.378642
*/
# include<iostream>
using namespace std;


bool ima(int x)
{
    int a=0,b=0;
    while(x>0)
    {
        b=x%10;
        x/=10;
        if(b==1 && a==3) return true;
        a=b;

    }
    return false;
}

int main()
{
    int n,q;
    cin>>n>>q;
    int x;
    cin>>x;
    int cnt=0;
    for(int i=x-1; i>=0; i--)
    {
        if(ima(i)) {cnt++;}// cout<<i<<endl;}
    }
    cout<<x-cnt+1<<endl;//<<" "<<cnt<<endl;
}
