/**
* user:  budnikov-2df
* fname: Mikhail
* lname: Budnikov
* task:  devil
* score: 0.0
* date:  2019-10-10 06:54:53.225068
*/
#include <bits/stdc++.h>
#define all(x) begin(x), end(x)
typedef long long ll;
typedef long double ld;
using namespace std;

void solve() {
	int k;
	cin >> k;
	ll pw = 1;
	for (int i = 0; i < k; ++i) {
		pw *= 10;
	}
	auto test = [&](vector<int> a) {
		ll max_sub = 0, sub = 0;
		for (int i = 0; i < k; ++i) {
			sub = 10 * sub + a[i];
		}
		max_sub = sub;
		for (int i = k; i < (int)a.size(); ++i) {
			sub = 10 * sub + a[i];
			sub -= pw * a[i - k];
			max_sub = max(max_sub, sub);
		}
		return max_sub;
	};
	vector<int> a;
	for (int i = 1; i < 10; ++i) {
		int c;
		cin >> c;
		while (c--) {
			a.push_back(i);
		}
	}
	
	int c1 = count(all(a), 1);
	int c2 = count(all(a), 2);
	assert((int)a.size() == c1 + c2);
	if (c2 <= k - 1 || c1 == 0) {
		sort(all(a));
	} else if (c2 - (k - 1) <= c1 || c1 == 1) {
		a.clear();
		int least1 = c1, least2 = c2;
		for (int it = 0; it < k - 1 && least2; ++it) {
			--least2;
			a.push_back(2);
		}
		assert(least2);
		int portion = least1 / least2, add = least1 % least2;
		for (int it = 0; it < add && least1; ++it) {
			--least1;
			a.push_back(1);
		}
		assert(least1 == portion * least2);
		while (least2) {
			for (int it = 0; it < portion; ++it) {
				a.push_back(1);
			}
			a.push_back(2);
			--least2;
			least1 -= portion;
		}
		assert(least1 == 0 && least2 == 0);
		reverse(all(a));
	} else {
		a.clear();
		int least1 = c1, least2 = c2;
		for (int it = 0; it < k - 1 && least2; ++it) {
			--least2;
			a.push_back(2);
		}
		assert(least2);
		int portion = least2 / least1;
		while (least1) {
			a.push_back(1);
			for (int it = 0; it < portion; ++it) {
				a.push_back(2);
			}
			--least1;
			least2 -= portion;
		}
		while (least2) {
			a.push_back(2);
			--least2;
		}
		assert(least1 == 0 && least2 == 0);
		reverse(all(a));
	}
	
#ifdef LC
	cout << test(a) << endl;
	for (int e : a) {
		cerr << e;
	}
	cerr << "\n";
#else
	for (int e : a) {
		cout << e;
	}
	cout << "\n";
#endif
}

int main() {
#ifdef LC
	assert(freopen("input.txt", "r", stdin));
#endif
	ios::sync_with_stdio(0);
	cin.tie(0);
	
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
	
	return 0;
}

