/**
* user:  kozhuharov-9a5
* fname: Viktor
* lname: Kozhuharov
* task:  devil
* score: 0.0
* date:  2019-10-10 08:01:16.887964
*/
#include <bits/stdc++.h>

using namespace std;

int a[11];
string s;

void solve(){
    int k;
    cin >> k;

    s = "";

    for(int i = 1; i < 10; ++i){
        cin >> a[i];
        for(int j = 0; j < a[i]; ++j){
            s += '0';
        }
    }

    int n = (int)s.size();

    int x = k - 1, big;
    for(int i = 9; i >= 1; --i){
        if(a[i] > x){
            for(int j = 0; j < x; ++j){
                s[n - k + 1 + j] = i + '0';
            }
            a[i] -= x;
            big = i;
            break;
        }
        else{
            x -= a[i];
            for(int j = 0; j < a[i]; ++j){
                s[n - k + 1 + x + j] = i + '0';
            }
            a[i] = 0;
        }
    }

    n -= k - 1;
    int curr = 0, t;

    t = (n / k) * k;

    while(a[big]){
        s[curr] = big + '0';
        --a[big];
        if(curr + k < t){
            curr += k;
        }
        else{
            if(curr >= t - 1){
                ++curr;
            }
            else{
                curr = (curr % k) + 1;
            }
        }
    }

    int idx = 1;
    while(idx < 10){
        while(a[idx] == 0 && idx < 10){
            ++idx;
        }
        if(idx == 10){
            break;
        }
        s[curr] = idx + '0';
        --a[idx];
        if(curr + k < t){
            curr += k;
        }
        else{
            if(curr >= t - 1){
                ++curr;
            }
            else{
                curr = (curr % k) + 1;
            }
        }
    }

    cout << s << "\n";

    return;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int t;

    cin >> t;

    while(t--){
        solve();
    }

    return 0;
}
/*
3
2
1 1 2 0 0 0 0 0 0
7
2 4 2 0 0 6 2 2 2
7
3 3 3 0 0 6 2 2 2
*/
/*
1
4
2 3 0 0 0 0 0 0 0
*/

