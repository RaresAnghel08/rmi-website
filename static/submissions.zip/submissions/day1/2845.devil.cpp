/**
* user:  savulescu-3de
* fname: Ștefan
* lname: Săvulescu
* task:  devil
* score: 13.0
* date:  2019-10-10 10:06:26.346912
*/
#include <cstdio>

using namespace std;
int i,t,k,j,s,nr,a[1000004],be[1000004],c[1000004],d[1000004];
bool ok;
void verif ()
{
    int i,j,q;
    for (i=1;i<=k;i++)
        d[i]=0;
    for (i=1;i<=(s-k+1);i++)
    {
        ok=false;
        for (j=i;j<=(i+k-1);j++)
        {
            if (c[j]>d[j-i+1])
            {
                ok=true;
                break;
            }
            else if (c[j]<d[j-i+1])
                break;
        }
        if (ok==true)
        {
            for (q=j;q<=(i+k-1);q++)
                d[q-i+1]=c[q];
        }
    }
    ok=false;
    for (j=1;j<=k;j++)
    {
        if (d[j]<a[j])
        {
            ok=true;
            break;
        }
        else if (d[j]>a[j])
            break;
    }
    if (ok==true)
    {
        for (q=j;q<=k;q++)
            a[q]=d[q];
        for (i=1;i<=s;i++)
            be[i]=c[i];
    }
}
void b (int x, int y, int z, int t)
{
    if ((x==0) && (y==0) && (z==0) && (t==0))
        verif();
    if (x>=1)
    {
        c[++nr]=1;
        b(x-1,y,z,t);
    }
    if (y>=1)
    {
        c[++nr]=2;
        b(x,y-1,z,t);
    }
    if (z>=1)
    {
        c[++nr]=3;
        b(x,y,z-1,t);
    }
    if (t>=1)
    {
        c[++nr]=4;
        b(x,y,z,t-1);
    }
    nr--;
    return;
}
int main()
{
    //freopen ("devil.in","r",stdin);
    //freopen ("devil.out","w",stdout);
    scanf ("%d", &t);
    for (i=1;i<=t;i++)
    {
        scanf ("%d", &k);
        ok=true;
        s=0;
        for (j=1;j<=9;j++)
        {
            scanf ("%d", &d[j]);
            if ((j<=4) && (d[j]>=4))
                ok=false;
            if ((j>=5) && (d[j]>=1))
                ok=false;
            s+=d[j];
        }
        for (j=1;j<=s;j++)
        {
            a[j]=9;
            be[j]=9;
        }
        nr=0;
        if (ok==true)
        {
            b(d[1],d[2],d[3],d[4]);
            for (j=1;j<=s;j++)
                printf ("%d", be[j]);
            printf ("\n");
        }
    }
    return 0;
}
