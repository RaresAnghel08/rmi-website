/**
* user:  coroian-5c7
* fname: David Nicolae
* lname: Coroian
* task:  restore
* score: 38.0
* date:  2019-10-10 08:52:03.645768
*/
#include <bits/stdc++.h>
//#include <fstream>
//#include <vector>
//#include <algorithm>

#define MAX_M 10000
#define MAX_N 5000

using namespace std;

//ifstream cin("rst.in");
//ofstream cout("rst.out");

int sum[MAX_N + 1][2];

int n, m;

struct que
{
    int st, dr, k, nr;
};

que v[MAX_M + 1];

void readFile()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i ++)
    {
        cin >> v[i].st >> v[i].dr >> v[i].k >> v[i].nr;
    }
}

int s[MAX_N + 1];

bool verif()
{

    for(int i = 0; i < n; i ++)
    {
        sum[i][0] = sum[i][1] = 0;

        if(i > 0)
        {
            sum[i][0] = sum[i - 1][0];
            sum[i][1] = sum[i - 1][1];
        }

        sum[i][s[i]] ++;
    }

    for(int i = 1; i <= m; i ++)
    {
        int a[2];
        a[0] = a[1] = 0;
        for(int h = 0; h <= 1; h ++)
            a[h] = sum[v[i].dr][h];

        if(v[i].st > 0)
        {
            for(int h = 0; h <= 1; h ++)
                a[h] -= sum[v[i].st - 1][h];
        }

        int nr = 0;
        if(v[i].k > a[0])
            nr = 1;

       // if(s[0] == 0 && s[1] == 1 && s[2] == 0 && s[3] == 0)
       //     cout << sum[3][1] << "++\n";

       // if(s[1] == 1 && sum[3][1] == 1)
      //      cout << nr << " == " << v[i].nr << " k " << v[i].k << " a0 " << a[0] << " a1 " << a[1] << "\n";

        if(nr != v[i].nr)
            return 0;
    }

    return 1;
}

vector <int> g[MAX_N + 1];

void verif2()
{

    for(int i = 0; i < n; i ++)
    {
        sum[i][0] = sum[i][1] = 0;

        if(i > 0)
        {
            sum[i][0] = sum[i - 1][0];
            sum[i][1] = sum[i - 1][1];
        }

        if(s[i] != -1)
            sum[i][s[i]] ++;

        else
            sum[i][0] ++;

        for(auto j : g[i])
        {
            int a[2];
            a[0] = a[1] = 0;
            for(int h = 0; h <= 1; h ++)
                a[h] = sum[v[j].dr][h];

            if(v[j].st > 0)
            {
                for(int h = 0; h <= 1; h ++)
                    a[h] -= sum[v[j].st - 1][h];
            }

            int nr = 0;
            if(v[j].k > a[0])
                nr = 1;

           // if(s[0] == 0 && s[1] == 1 && s[2] == 0 && s[3] == 0)
           //     cout << sum[3][1] << "++\n";

           // if(s[1] == 1 && sum[3][1] == 1)
          //      cout << nr << " == " << v[j].nr << " k " << v[j].k << " a0 " << a[0] << " a1 " << a[1] << "\n";

           // if(v[j].nr == 1 && v[j].k == v[j].dr - v[j].st + 1)
             //   cout << " SUNTEM " << i << " " << j << "\n";

            if(nr == 0 && v[j].nr == 1 && v[j].k > 1/* == v[j].dr - v[j].st + 1*/)
            {
                int diff = v[j].dr - v[j].st + 1 - v[j].k + 1;
               // cout << "AVEM PB " << v[j].st << " " << v[j].dr << " " << v[j].k << " " << v[j].nr << "\n";
                int CAT = 0;
                for(int h = v[j].st; h <= v[j].dr; h ++)
                {
                    if(diff > 0 && s[h] == -1)
                    {
                        s[h] = 1;
                        CAT ++;
                        diff --;
                    }

                    sum[h][1] += CAT;
                    sum[h][0] -= CAT;
                }

            }
        }
    }
}

struct cmpDr
{
    bool operator() (const que &a, const que &b) const
    {
        return (a.st < b.st);
    }

};


void solve()
{/*
    if(n <= 18)
    {
        for(int i = 0; i < (1 << n); i ++)
        {
            for(int j = 0; j < n; j ++)
            {
                s[j] = (((1 << j) & i) != 0);
            }


            if(verif())
            {
                for(int i = 0; i < n; i ++)
                    cout << s[i] << " ";
                cout << "\n";

                exit(0);
            }
        }

        cout << "-1\n";
    }*/

    for(int i = 0; i < n; i ++)
        s[i] = -1;

    for(int i = 1; i <= m; i ++)
    {
        if((v[i].nr == 1 && v[i].k == 1) || (v[i].nr == 0 && v[i].k == v[i].dr - v[i].st + 1))
        {
            for(int j = v[i].st; j <= v[i].dr; j ++)
            {
                s[j] = v[i].nr;
            }
        }
    }

    sort(v + 1, v + m + 1, cmpDr());

    for(int i = 1; i <= m; i ++)
        g[v[i].dr].push_back(i);

    verif2();

    for(int i = 0; i < n; i ++)
        if(s[i] == -1)
            s[i] = 0;

    if(verif())
    {
        for(int i = 0; i < n; i ++)
            cout << s[i] << " ";
        cout << "\n";
    }

    else
        cout << "-1\n";
}

int main()
{
    readFile();

    solve();

    return 0;
}
