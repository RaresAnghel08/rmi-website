/**
* user:  sisovic-018
* fname: Marko
* lname: Sisovic
* task:  lucky
* score: 14.0
* date:  2019-10-10 06:37:56.907503
*/
#include <bits/stdc++.h>
using namespace std;

int n,q;
long long num,cnt;

string nts(int a)
{
	string out="";
	while(a>0)
	{
		out.push_back('0'+a%10);
		a/=10;
	}
	reverse(out.begin(),out.end());
	return out;
}

bool tst(string s)
{
	for(int i=1;i<(int)s.size();i++)
	{
		if(s[i]=='3' && s[i-1]=='1')
		{
			return false;
		}
	}
	return true;
}

int main()
{
	ios::sync_with_stdio(false);
	cin>>n>>q>>num;
	for(int i=0;i<=num;i++)
	{
		if(tst(nts(i)))
		{
			cnt++;
		}
	}
	cout<<cnt;
}
