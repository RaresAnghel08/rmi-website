/**
* user:  oparlakov-daf
* fname: Dimitar
* lname: Oparlakov
* task:  restore
* score: 7.0
* date:  2019-10-10 08:12:02.095366
*/
#include <iostream>
#include <cstdio>
using namespace std;

struct criteria
{
    int from, to, k;
    int val;

    criteria(){};
    criteria(int a, int b, int c, int d)
    {
        from = a, to = b, k = c, val = d;
    }
} crit[202];

int cnt0[20];
int n, m;
bool fl;

void solve(string s)
{
    if(fl == 1) return ;
    if(s.size() == n)
    {
        for(int i=0; i<n; i++) cnt0[i] = 0;

        for(int i=0; i<n; i++)
        {
            if(i==0 && s[i]=='0') {cnt0[i] = 1; continue;}
            if(i>0 && s[i] == '0') cnt0[i] = cnt0[i-1] + 1;
            else if(i>0 && s[i] == '1') cnt0[i] = cnt0[i-1];
        }

        bool ok = 1;
        for(int i=0; i<m; i++)
        {
            int br;

            if(crit[i].from == 0) br = cnt0[crit[i].to];
            else br = cnt0[crit[i].to] - cnt0[crit[i].from - 1];

            if(crit[i].k > br && crit[i].val == 0) ok = 0;
            else if(crit[i].k <= br && crit[i].val == 1) ok = 0;

            if(ok == 0) break;
        }
        if(ok == 1)
        {
            for(int i=0; i<s.size(); i++)
                printf("%d ", s[i] - '0');
            printf("\n");
            fl = 1;
        }
        return ;
    }

    solve(s + "0");
    solve(s + "1");
}

int main()
{

    scanf("%d%d", &n, & m);

    for(int i=0; i<m; i++)
        scanf("%d%d%d%d", &crit[i].from, &crit[i].to, &crit[i].k, &crit[i].val);

    fl = 0;
    solve("");

    if(fl == 0) printf("-1\n");

    return 0;

}
