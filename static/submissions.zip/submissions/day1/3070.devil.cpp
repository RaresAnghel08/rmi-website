/**
* user:  moldovan-92d
* fname: Andrei
* lname: Moldovan
* task:  devil
* score: 0.0
* date:  2019-10-10 10:28:55.621698
*/
#include <bits/stdc++.h>
using namespace std;
struct dd
{
    int max1;
    long long sol;
};
dd dp[4][4][4][4][13];
long long put=0;
void dfs(long long nr,long long max2,int c1,int c2,int c3,int c4,int k,int last,int v[15])
{
    if(dp[c1][c2][c3][c4][k].max1>max2)
    {
        dp[c1][c2][c3][c4][k].max1=max2;
        dp[c1][c2][c3][c4][k].sol=nr;
    }
        int v1[15];
        for(int i=2;i<k;++i)v1[i-1]=v[i];
    long long nr1=0;
    if(c1<3)
    {
        nr1=nr*10+1;
        long long last1=last*10+1;

        v1[k-1]=1;
        dfs(nr1,max(max2,last1),c1+1,c2,c3,c4,k,last1-put*v[1],v1);
    }
    if(c2<3)
    {
        nr1=nr*10+2;
        long long last1=last*10+2;
        v1[k-1]=2;
        dfs(nr1,max(max2,last1),c1,c2+1,c3,c4,k,last1-put*v[1],v1);
    }

    if(c3<3)
    {
        nr1=nr*10+3;
        long long last1=last*10+3;
        v1[k-1]=3;
        dfs(nr1,max(max2,last1),c1,c2,c3+1,c4,k,last1-put*v[1],v1);
    }

    if(c4<3)
    {
        nr1=nr*10+4;
        long long  last1=last*10+4;
        v1[k-1]=4;
        dfs(nr1,max(max2,last1),c1,c2,c3,c4+1,k,last1-put*v[1],v1);
    }

}
int v[15];
int main()
{
    int i;
    put=1;int t,j;
    for(i=0;i<=3;i++)
        for(j=0;j<=3;j++)
        for(int t=0;t<=3;t++)
        for(int r=0;r<=3;r++)
        for(int l=1;l<=12;l++)
        dp[i][j][t][r][l].max1=10000000000000;
    for(i=1;i<=12;i++)
        {memset(v,0,sizeof(v);dfs(0,0,0,0,0,0,i,0,v);
        put=put*10;}
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        int k,fr[10];
        cin>>k;
        for(j=1;j<=9;j++)cin>>fr[j];
        cout<<dp[fr[1]][fr[2]][fr[3]][fr[4]][k].sol<<"\n";
    }
    return 0;
}
