/**
* user:  wald-761
* fname: Inbar
* lname: Wald
* task:  lucky
* score: 14.0
* date:  2019-10-10 07:50:29.078473
*/
#include <iostream>
#include <vector>
#include <utility>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <algorithm>
using namespace std;
#define int63 long long
#define make(name) int63 name; cin >> name
#define out(data) cout << data << endl
#define __ << " " <<
#define forf(name,start,end) for(int63 name = start; name < end; name++)
#define forfb(name,start,end) for(int63 name = end-1; name >= start; name--)
#define fort(start,end) forf(i,start,end)
#define fortb(start,end) forf(i,start,end)
#define forto(start,end) forf(j,start,end)
#define fortob(start,end) forf(j,start,end)
#define fortoo(start,end) forf(k,start,end)
#define fortoob(start,end) forf(k,start,end)
#define all(name) name.begin(), name.end()
#define first(name) name[0]
#define last(name) name[name.size() - 1]
int main(){
	make(n);
	make(q);
	int63 N;
	cin >> N;
	int63 ans = N+1;
	fort(1,N+1){
		int63 j = i;
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
		j/=10;
		if(j % 10 == 1){
			ans--;
			continue;
		}
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
		j/=10;
		if(j % 10 == 1){
			ans--;
			continue;
		}
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
		j/=10;
		if(j % 10 == 1){
			ans--;
			continue;
		}
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
		j/=10;
		if(j % 10 == 1){
			ans--;
			continue;
		}
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
		j/=10;
		if(j % 10 == 1){
			ans--;
			continue;
		}
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
		j/=10;
		if(j % 10 == 1){
			ans--;
			continue;
		}
		while(j > 0 && j % 10 != 3){
			j/=10;
		}
	}
	out(ans);
	return 0;
}
