/**
* user:  bazac-891
* fname: Tudor
* lname: Bazac
* task:  devil
* score: 0.0
* date:  2019-10-10 09:57:40.722802
*/
#include <bits/stdc++.h>

using namespace std;

int f[11],v[100010];

int main()
{
    int t,k,i,s,s1,j,a;
    cin>>t;
    while(t>0)
    {
        t--;
        s=0;
        cin>>k;
        for(i=1;i<=9;i++)
        {
            cin>>f[i];
            s=s+f[i];
        }
        for(i=9;i>=1;i--)
            if(f[i]!=0)
            {
                f[i]--;
                v[s]=i;
                break;
            }
        for(j=1;j<=9;j++)
            if(f[j]!=0)
            {
                f[j]--;
                v[s-1]=j;
                break;
            }
        for(i=9;i>=1;i--)
            if(f[i]!=0)
            {
                f[i]--;
                v[s-2]=i;
                break;
            }
        s1=s;
        s=s-3;
        a=1;
        while(s>0)
        {
            if(a=1)
            {
                if(f[j]==0)
                    for(;j<=9;j++)
                        if(f[j]!=0)
                        {
                            f[j]--;
                            v[s]=j;
                            break;
                        }
                else
                    v[s]=j;
            }
            else
            {
                if(f[i]==0)
                    for(;i>=1;i--)
                        if(f[i]!=0)
                        {
                            f[i]--;
                            v[s]=i;
                            break;
                        }
                else
                    v[s]=i;
            }
            s--;
            a=1-a;
        }
        for(i=1;i<=s1;i++)
            cout<<v[i];
    }
    return 0;
}
