/**
* user:  kliska-f84
* fname: Pavel
* lname: Kliska
* task:  devil
* score: 0.0
* date:  2019-10-10 08:41:18.507502
*/
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;

const ll INF = 1e18;

int k;

int main(){
	int tcc;
	scanf("%d", &tcc);
	for(int tc=0;tc<tcc;++tc){
		int n=0,m=1;
		scanf("%d", &k);
		for(int i=0;i<k;++i) m*=10;
		vector<int> sol;
		for(int i=1;i<=9;++i){
			int tmp;
			scanf("%d", &tmp);
			for(int j=0;j<tmp;++j) sol.push_back(i);
		}
		ll bestv=INF;
		vector<int> bestsol;
		do{
			ll x=0, v=0;
			for(int i=0;i<k-1;++i){
				x=((10*x)%m+sol[i])%m;
			}
			for(int i=k-1;i<sol.size();++i){
				x=((10*x)%m+sol[i])%m;
				v=max(v, x);
			}
			if(v<bestv){
				bestv=v;
				bestsol=sol;	
			}
		}while(next_permutation(sol.begin(), sol.end()));
		for(auto i:bestsol){
			printf("%c", '0'+i);
		}
		puts("");
	}		
	
}
