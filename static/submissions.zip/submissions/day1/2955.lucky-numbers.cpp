/**
* user:  sisovic-018
* fname: Marko
* lname: Sisovic
* task:  lucky
* score: 37.0
* date:  2019-10-10 10:18:08.714750
*/
#include <bits/stdc++.h>
using namespace std;

const long long MOD=1000000007;

int n,q,in1,in2,in3;
string num;
long long base[100005][2];

long long solve(string s,int lb,int rb)
{
	long long l[2]={1,0},c[2]={};
	for(int i=rb;i>=lb;i--)
	{
		c[0]=0,c[1]=0;
		int x=s[i]-'0',rest=x;
		if(3<x)
		{
			c[1]+=base[rb-i][0]+base[rb-i][1];
			c[1]%=MOD;
			rest--;
		}
		if(1<x)
		{
			c[0]+=base[rb-i][0];
			c[0]%=MOD;
			rest--;
		}
		c[0]+=(base[rb-i][0]+base[rb-i][1])*rest;
		c[0]%=MOD;
		if(x==3)
		{
			c[1]+=l[0]+l[1];
			c[1]%=MOD;
		}
		else if(x==1)
		{
			c[0]+=l[0];
			c[0]%=MOD;
		}
		else
		{
			c[0]+=l[0]+l[1];
			c[0]%=MOD;
		}
		l[0]=c[0],l[1]=c[1];
	}
	return (c[0]+c[1])%MOD;
}

int main()
{
	ios::sync_with_stdio(false);
	cin>>n>>q>>num;
	base[0][0]=1,base[0][1]=0;
	for(int i=1;i<=n;i++)
	{
		base[i][0]=(9*base[i-1][0]+8*base[i-1][1])%MOD;
		base[i][1]=(base[i-1][0]+base[i-1][1])%MOD;
	}
	cout<<solve(num,0,n-1)<<"\n";
	for(int i=0;i<q;i++)
	{
		cin>>in1>>in2>>in3;
		if(in1==1)
		{
			cout<<solve(num,in2-1,in3-1)<<"\n";
		}
		else
		{
			num[in2-1]='0'+in3;
		}
	}
}
