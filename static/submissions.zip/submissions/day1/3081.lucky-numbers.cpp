/**
* user:  kwiatkowski-76e
* fname: Jan
* lname: Kwiatkowski
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:29:29.203353
*/
#include <bits/stdc++.h>

using namespace std;

#define f first
#define s second
#define int long long

const int MAXN = 1e5 + 3;
const int MAXM = 100;
const long long MOD = 1e9 + 7;

long long dp[MAXM][MAXN];
int t[MAXN];
long long br[1013];

bool check(int x) {
    int y;
    while (x >= 10) {
        y = x % 100;
        if (y == 13)
            return true;
        x /= 10;
    }
    return false;
}

long long zrob(int x, int y, int poz) {
    long long ret = 0LL;
    int dl, temp;
    if (y - x + 1 <= 3) {
        temp = 0;
        for (int i = x; i <= y; i++) {
            temp *= 10;
            temp += t[i];
        }
        return br[temp];
    }
    dl = y - x + 1;
    temp = 10 * t[x] + t[x + 1];
    for (int i = 0; i < temp; i++) {
        ret += dp[i][poz];
        ret %= MOD;
    }
    //printf("%lld ", ret);
    ret += zrob(x + 2, y, poz - 2);
    ret %= MOD;
    return ret;
}

int32_t main() {
    int n, z;
    int cs, x, y;
    char ch;
    scanf("%lld %lld ", &n, &z);
    for (int i = 1; i <= n; i++) {
        scanf("%c", &ch);
        t[i] = (long long)(ch - '0');
    }
    br[0] = 1LL;
    for (int i = 1; i < 1000; i++) {
        br[i] = br[i - 1] + 1LL;
        if (check(i))
            br[i]--;
    }
    long long sum = 10LL, sum3 = 9LL;
    for (int i = 0; i < 100; i++)
        dp[i][2] = 1LL;
    dp[13][2] = 0LL;
    for (int i = 3; i <= n; i++) {
        for (int j = 0; j < 100; j++) {
            if (j == 13)
                continue;
            if (j % 10 == 1)
                dp[j][i] = sum3;
            else
                dp[j][i] = sum;
        }
        sum = sum3 = 0LL;
        for (int j = 0; j < 100; j++) {
            sum += dp[j][i - 1];
            sum %= MOD;
        }
        for (int j = 0; j < 30; j++) {
            sum3 += dp[j][i - 1];
            sum3 %= MOD;
        }
        for (int j = 40; j < 100; j++) {
            sum3 += dp[j][i - 1];
            sum3 %= MOD;
        }
    }
    int pocz = 1LL;
    while (t[pocz] == 0LL)
        pocz++;
    if (pocz == n + 1) {
        printf("1");
        return 0;
    }
    printf("%lld\n", zrob(pocz, n, n));
    while (z--) {
        scanf("%lld %lld %lld", &cs, &x, &y);
        //if (cs == 1)

    }
    //for (int i = 0; i <= n; i++)
    //    cout << dp[i] << ' ';
    return 0;
}
