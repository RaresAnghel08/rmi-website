/**
* user:  hadzhi-manich-035
* fname: Deyan
* lname: Hadzhi-Manich
* task:  restore
* score: 0.0
* date:  2019-10-10 09:48:46.015969
*/
#include<bits/stdc++.h>
using namespace std;
int b[5002];
int minr[5002];
bool b1[5002];
int n,m;
struct query
{
	int l,r,k,val;
	bool operator<(query const& other)const
	{
		if(r!=other.r)return r<other.r;
		if(l!=other.l)return l<other.l;
		if(k!=other.k)return k<other.k;
		return val<other.val;
	}
};
set<query>s;
vector<query>q;
set<query>a[5002];
int main()
{
	cin>>n>>m;
	for(int i=0;i<5002;i++)minr[i]=100000;
	memset(b,-1,sizeof(b));
	int l,r,k,val;
	for(int i=0;i<m;i++)
	{
		cin>>l>>r>>k>>val;
		q.push_back({l,r,k,val});
	}
	for(int i=0;i<m;i++)
	{
		if(q[i].k==1&&q[i].val==1)
		{
			for(int j=q[i].l;j<=q[i].r;j++)
			{
				if(b[j]==0)
				{
					cout<<"-1\n";
					return 0;
				}
				b[j]=1;
			}
		}
		if(q[i].k==q[i].r-q[i].l+1&&q[i].val==0)
		{
			for(int j=q[i].l;j<=q[i].r;j++)
			{
				if(b[j]==1)
				{
					cout<<"-1\n";
					return 0;
				}
				b[j]=0;
			}
		}
	}
	for(int i=0;i<m;i++)
	{
		if(q[i].k==1&&q[i].val==0)
		{
			bool flag=0;
			for(int j=q[i].l;j<=q[i].r;j++)
			{
				if(b[j]==0){flag=1;break;}
			}
			if(!flag)
			{
				for(int j=q[i].l;j<=q[i].r;j++)
				{
					if(b[j]==-1)
					{
						a[j].insert(q[i]);
					}
				}
			}
		}
		if(q[i].k==q[i].r-q[i].l+1&&q[i].val==1)
		{
			bool flag=0;
			for(int j=q[i].l;j<=q[i].r;j++)
			{
				if(b[j]==1){flag=1;break;}
			}
			if(!flag)
			{
				for(int j=q[i].l;j<=q[i].r;j++)
				{
					if(b[j]==-1)
					{
						a[j].insert(q[i]);
					}
				}
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		if(b[i]==-1)
		{
			bool flag=0;
			for(auto j:a[i])
			{
				if(s.find(j)==s.end())
				{
					for(int t=0;t<m;t++)
					{
						if(q[t].l<=i&&q[t].r>=i&&q[t].val==b[i])s.insert(q[t]);
					}
					b[i]=j.val;
					flag=1;
				}
			}
			if(!flag)
			{
				cout<<"-1\n";
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<b[i]<<" ";
	}
	cout<<endl;
return 0;
}
