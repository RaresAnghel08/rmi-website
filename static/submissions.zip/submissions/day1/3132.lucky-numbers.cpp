/**
* user:  nicola-706
* fname: Alexandra Mihaela
* lname: Nicola
* task:  lucky
* score: 14.0
* date:  2019-10-10 10:33:48.134029
*/
#include <iostream>
#define DIM 100010
#define MOD 1000000007
using namespace std;

//ifstream cin ("date.in");
//ofstream cout ("date.out");
int v[DIM],f[11],frecv[11],x[DIM],cif[DIM];
int dp[20][11];
int n,q,i,nr_tot;
long long sol;
char s[DIM];
/*void back (int pas){
    if (pas == 6){
        int ok = 1;
        for (int i=1;i<n;i++)
            if (x[i] == 1 && x[i+1] == 3){
                ok = 0;
                break;
            }
        if (ok)
            nr_tot++;
        return;
    }
    for (int i=0;i<=9;i++){
        if (pas == 1 && i == 0)
            continue;
        x[pas] = i;
        back(pas+1);
    }
}|*/
int main (){

    cin>>n>>q;
    cin>>s+1;
    for (i=1;i<=n;i++)
        v[i] = s[i] - '0';
    /*nr_tot = 0;
    back(1);
    cout<<nr_tot;*/
    if (q == 0){
        if (n <= 6){
            int nr = 0;
            for (i=1;i<=n;i++)
                nr = nr*10+v[i];
            for (i=1;i<=nr;i++){
                int x = i, k = 0, ok = 1;
                while (x){
                    cif[++k] = x%10;
                    if (cif[k] == 1 && cif[k-1] == 3){
                        ok = 0;
                        break;
                    }
                    x /= 10;
                }
                if (ok)
                    sol++;
            }
            cout<<(sol+1)%MOD;
            return 0;
        }
        /// dp[i][cif] - cate numere de i cifre pot forma care se termina cu cifra cif
            for (i=0;i<=9;i++)
                dp[1][i] = 1;
            for (i=2;i<=n;i++){
                long long sum = 0;
                for (int cif2=0;cif2<=9;cif2++){
                    //if (i == 2 && cif2 == 0)
                        //continue;
                    sum += dp[i-1][cif2];
                    if (sum >= MOD)
                        sum -= MOD;
                }
                for (int cif=0;cif<=9;cif++){
                    if (cif == 3){
                        int nr = sum-dp[i-1][1];
                        if (nr < 0)
                            nr += MOD;
                        dp[i][cif] = nr;
                    } else {
                        dp[i][cif] = sum;
                    }}}
       /* for (i=1;i<=5;i++){
            int idk = 0;
            for (int cif=0;cif<=9;cif++)
                idk += dp[i][cif];
           // cout<<idk<<" ";
        }*/
        if (n <= 18){
            sol = 0;
            for (i=1;i<n;i++){
                for (int cif=0;cif<=9;cif++){
                    sol = sol+dp[i][cif];
                    if (sol >= MOD)
                        sol -= MOD;
                }
                if (i > 1){
                    /// trb sa le scad pe alea care incep cu 0
                    for (int cif=0;cif<=9;cif++){
                        sol -= dp[i-1][cif];
                        if (sol < 0)
                            sol += MOD;
                    }

                }
            }

            for (i=0;i<n;i++){
                /// toate pana la pozitia i sunt egale cu v si la i+1 vreau sa pun ceva mai mic
                if (i >= 2 && v[i] == 3 && v[i-1] == 1)
                    break;
                if (i == n-1){
                    sol = (sol+v[n])%MOD;
                    if (v[n] > 3 && v[n-1] == 1)
                        sol--;
                    if (sol < 0)
                        sol += MOD;
                    break;
                }
                long long val = 0;
                for (int cif=0;cif<=9;cif++)
                    val = (val+dp[n-i-1][cif])%MOD;
                long long nr = 0;
                if (i > 0)
                    nr = 1LL*v[i+1]*val%MOD;
                else nr = 1LL*(v[i+1]-1)*val%MOD;

                if (v[i+1] > 1){
                    /// trebuie sa scad atunci cand pe i+1 am 1 si pe i+2 am 3
                    for (int cif=0;cif<=9;cif++){
                        nr -= dp[n-i-1-1][cif];
                        if (nr < 0)
                            nr += MOD;
                    }
                    if (v[i] == 1 && v[i+1] > 3){
                        for (int cif=0;cif<=9;cif++){
                            nr -= dp[n-i-1-1][cif];
                            if (nr < 0)
                                nr += MOD;
                        }}}

                sol += nr;
                if (sol >= MOD)
                    sol -= MOD;
            }

           // back(1);
            cout<<sol;

            return 0;
        }
        return 0;
    }





    return 0;
}
