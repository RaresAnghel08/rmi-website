/**
* user:  verde-76f
* fname: Flaviu-Cristian
* lname: Verde
* task:  restore
* score: 7.0
* date:  2019-10-10 10:22:56.054449
*/
#include <iostream>
#include <cstdio>
using namespace std;
struct mazan
{
    int l,r,k,value;
};
mazan v[5001];
int vec[5001],s[5001],s1[5001];
int main()
{
#ifdef HOME
    freopen("test.in","r",stdin);
    freopen("test.out","w",stdout);
#endif // HOME
    int n,m,i,j,x;
    cin>>n>>m;
    for(i=1; i<=m; i++)
        cin>>v[i].l>>v[i].r>>v[i].k>>v[i].value;
    if(n<=18&&m<=200)
    {
        for(i=0; i<(1<<n); i++)
        {
            for(j=0; j<n; j++)
                if((1<<j)&i)
                    vec[j]=1;
                else
                    vec[j]=0;
            for(j=0; j<n; j++)
                s[j]=s[j-1]+vec[j];
            for(j=1; j<=m; j++)
            {
                x=s[v[j].r]-s[v[j].l-1];
                if(v[j].value==1&&v[j].k<=v[j].r-v[j].l+1-x)
                    break;
                if(v[j].value==0&&v[j].k>v[j].r-v[j].l+1-x)
                    break;
            }
            if(j==m+1)
            {
                for(j=0; j<n; j++)
                    cout<<vec[j]<<" ";
                return 0;
            }
        }
        cout<<-1;
        return 0;
    }
    for(i=1; i<=m; i++)
    {
        if(v[i].k==1&&v[i].value==1)
        {
            for(j=v[i].l; j<=v[i].r; j++)
                vec[j]=1;
            s1[v[i].l]++;
            s1[v[i].r+1]--;
        }
        else if(v[i].k==v[i].r-v[i].l+1&&v[i].value==0&&vec[v[i].l]!=-1)
        {
            s1[v[i].l]++;
            s1[v[i].r+1]--;
        }
    }
    for(i=0; i<n; i++)
    {
        vec[i]+=vec[i-1];
        s[i]=s[i-1]+vec[i];
        s1[i]+=s1[i-1];
    }
    //for(i=0; i<n; i++)
    //cout<<vec[i]<<" ";
    for(i=1; i<=m; i++)
    {
        if(v[i].k==1&&v[i].value==1&&s[v[i].r]-s[v[i].l-1]!=v[i].r-v[i].l+1)
        {
            cout<<-1;
            return 0;
        }
        else if(v[i].k==v[i].r-v[i].l+1&&v[i].value==0&&s[v[i].r]-s[v[i].l-1]!=0)
        {
            cout<<-1;
            return 0;
        }
        else if(v[i].k==v[i].r-v[i].l+1)
            for(j=v[i].l; j<=v[i].r; j++)
            {
                if(!s1[i])
                {
                    vec[i]=1;
                    break;
                }
            }
    }
    for(i=1; i<=n; i++)
        cout<<vec[i]<<" ";
    return 0;
}
