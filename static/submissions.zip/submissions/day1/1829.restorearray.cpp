/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  restore
* score: 13.0
* date:  2019-10-10 07:54:12.133951
*/
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int NMAX = 5e3 + 5, MMAX = 1e4 + 5;

int N, M;

int A[NMAX];

struct Query
{
    int Left, Right, K, Val;
};

Query V[MMAX];

int dp[NMAX];

int Must_Zero[NMAX];

static inline bool Final_Check ()
{
    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(K == 1)
        {
            if(X == 0)
            {
                if(dp[V[i].Right] - dp[V[i].Left - 1] == (V[i].Right - V[i].Left + 1))
                    return false;
            }
            else
            {
                if(dp[V[i].Right] - dp[V[i].Left - 1] != (V[i].Right - V[i].Left + 1))
                    return false;
            }
        }
        else
        {
            if(X == 0)
            {
                if(dp[V[i].Right] - dp[V[i].Left - 1])
                    return false;
            }
            else
            {
                if((dp[V[i].Right] - dp[V[i].Left - 1]) == 0)
                    return false;
            }
        }
    }

    return true;
}

int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> N >> M;

    for(int i = 1; i <= M; ++i)
    {
        cin >> V[i].Left >> V[i].Right >> V[i].K >> V[i].Val;

        ++V[i].Left;
        ++V[i].Right;
    }

    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(K == 1)
        {
            if(X == 1)
            {
                for(int j = V[i].Left; j <= V[i].Right; ++j)
                    A[j] = 1;
            }
        }
    }

    for(int i = 1; i <= N; ++i)
        dp[i] = dp[i - 1] + A[i];

    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(K != 1)
        {
            if(X == 1)
                continue;

            if(dp[V[i].Right] - dp[V[i].Left - 1])
            {
                cout << -1 << '\n';

                return 0;
            }

            for(int j = V[i].Left; j <= V[i].Right; ++j)
                Must_Zero[j] = true;
        }
    }

    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(K != 1)
        {
            if(X == 1)
            {
                bool Ok = false;

                for(int j = V[i].Left; j <= V[i].Right; ++j)
                    if(Must_Zero[j] == false)
                    {
                        Ok = true;

                        A[j] = 1;

                        break;
                    }

                if(!Ok)
                {
                    cout << -1 << '\n';
                }
            }
        }
    }

    ////////////////////////////////////////
    for(int i = 1; i <= N; ++i)
        dp[i] = dp[i - 1] + A[i];

    if(!Final_Check())
    {
        cout << -1 << '\n';

        return 0;
    }

    for(int i = 1; i <= N; ++i)
        cout << A[i] << ' ';

    cout << '\n';

    return 0;
}
