/**
* user:  licht-5c2
* fname: Noam
* lname: Licht
* task:  lucky
* score: 14.0
* date:  2019-10-10 08:07:27.286304
*/
#include <bits/stdc++.h>
#define int int64_t
#define vi vector<int>
#define vb vector<bool>
#define ii pair<int,int>
#define vii vector<ii>
#define vvi vector<vi>
#define x first
#define y second
#define loop(i,s,e) for(int i=(s);i<(e);++i)
#define mp make_pair
#define pb push_back
#define chkmax(a,b) a=max(a,b)
#define chkmin(a,b) a=min(a,b)
using namespace std;
using ll=long long;
using ld=long double;
const int INF=1e18;
const int MOD=1000000007;


bool check(int x){
    while(x>12){
        if (x%100==13) return false;
        x/=10;
    }
    return true;
}

int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int n,q; cin>>n>>q;
    int x;
    cin>>x;
    int cnt=0;
    loop(i,0,x+1){
        if (check(i)) cnt++;
    }
    cout<<cnt<<endl;
    return 0;
}


