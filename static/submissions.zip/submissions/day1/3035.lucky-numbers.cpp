/**
* user:  oparlakov-daf
* fname: Dimitar
* lname: Oparlakov
* task:  lucky
* score: 14.0
* date:  2019-10-10 10:26:02.906685
*/
#include <iostream>
#include <cstdio>
using namespace std;

#define Mod 1000000007LL
#define NMax 100000

long long n, q, pow = 0;
long long a[NMax + 2], b[NMax + 2];
long long  num, ans;

int main()
{
    scanf("%lld%lld", &n, &q);
    scanf("%lld", &num);

    a[0] = 0LL;
    b[0] = 1LL;
    a[1] = 1LL;
    b[1] = 9LL;

    for(long long i=2; i<=9; i++)
    {
        b[i] = ((a[i-1] * 8)%Mod + (b[i-1] * 9)%Mod) % Mod;
        a[i] = (a[i-1] + b[i-1]) % Mod;
    }

    for(; num>0; num /= 10)
    {
        long long cur = num % 10;

        if(cur>=1)ans = (ans + ((cur-1)*a[pow])%Mod + (cur*b[pow])%Mod) % Mod;

        pow ++;
    }

    printf("%lld\n", (ans+1)%Mod);



    return 0;
}
