/**
* user:  dicu-3f6
* fname: Adrian Emanuel
* lname: Dicu
* task:  restore
* score: 45.0
* date:  2019-10-10 09:10:26.590871
*/
// am stat 2 ore pe problema asta ca am zis ca am timp sa le codez pe
// celelalte 2 ca nu par asa grele ... sper sa merite
#include <bits/stdc++.h>
using namespace std;

const int DIM = 10005;

struct Segment {
	int l, r, p, v, len, o;
} seg[DIM];

bool oki[DIM];
int val[DIM];

void noAnswer(void) {
	cout << -1 << endl;
	exit(0);
}

int main(void) {
#ifdef HOME
	freopen("restore.in", "r", stdin);
	freopen("restore.out", "w", stdout);
#endif
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= m; ++i) {
		cin >> seg[i].l >> seg[i].r >> seg[i].p >> seg[i].v;
		++seg[i].l; ++seg[i].r;
		seg[i].len = seg[i].r - seg[i].l + 1;
		seg[i].o = seg[i].p;
		if (seg[i].v == 0) 
			seg[i].p = seg[i].len - seg[i].p;
		else
			seg[i].p = seg[i].p - 1;
	}
	for (int i = 1; i <= n; ++i) {
		int mn = 100000, ps = -1;
		for (int j = 1; j <= m; ++j) {
			// iau segmentul cu restrictia maxima
			if (!seg[j].len)
				continue;
			if (mn > seg[j].p) {
				mn = seg[j].p;
				ps = j;
			}
		}
		if (ps == -1)
			break;
		// caut o pozitie valida
		int p = seg[ps].r;
		while (oki[p])
			--p;
		if (p > seg[ps].r)
			noAnswer();
		oki[p] = true;
		val[p] = seg[ps].v;
		for (int j = 1; j <= m; ++j) {
			if (!seg[j].len or seg[j].r < p or p < seg[j].l)
				continue;
			--seg[j].len;
			if (seg[j].v != seg[ps].v)
				--seg[j].p;
			if (seg[j].p < 0)
				noAnswer();
		}
	}
	for (int j = 1; j <= m; ++j) {
		int nr0 = 0, nr1 = 0;
		for (int i = seg[j].l; i <= seg[j].r; ++i) {
			if (val[i] == 1)
				++nr1;
			else
				++nr0;
		}
		if (seg[j].v == 0 and nr0 < seg[j].o)
			noAnswer();
		if (seg[j].v == 1 and nr0 >= seg[j].o)
			noAnswer();
	}
	for (int i = 1; i <= n; ++i)
		cout << val[i] << " ";
	return 0;
}
