/**
* user:  taga-e6c
* fname: Ștefan
* lname: Țaga
* task:  devil
* score: 13.0
* date:  2019-10-10 09:19:59.583547
*/
#include <bits/stdc++.h>
//#define cin f
//#define cout g
using namespace std;
ifstream f("date.in");
ofstream g("date.out");
int t,v[11],n,sf,q,i,k,st,dr,test1;
int sol[100005],sol2[100000];
long long minim,maxim,numar;
void back1(int nr)
{
    int i,j;
    if (nr>n)
    {
        maxim=0;
        for (i=1;i<=n-k+1;i++)
        {
            numar=0;
            for (j=i;j<=i+k-1;j++)
            {
                numar=numar*10+sol2[j];
            }
            maxim=max(maxim,numar);
        }
        if (maxim<minim)
        {
            minim=maxim;
            for (i=1;i<=n;i++)
            {
                sol[i]=sol2[i];
            }
        }
    }
    else
    {
        for (i=1;i<=9;i++)
        {
            if (v[i]>0)
            {
                sol2[nr]=i;
                v[i]--;
                back1(nr+1);
                v[i]++;
            }
        }
    }
}
int main()
{
    cin>>t;
    for (;t--;)
    {
        cin>>k;
        n=0;
        test1=1;
        for (i=1;i<=9;i++)
        {
            cin>>v[i];
            n=n+v[i];
        }
        minim=1000000000000000;
        back1(1);
        for (i=1;i<=n;i++)
           {
               cout<<sol[i];
           }
        cout<<'\n';
    }
    return 0;
}
