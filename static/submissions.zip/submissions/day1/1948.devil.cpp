/**
* user:  sisovic-018
* fname: Marko
* lname: Sisovic
* task:  devil
* score: 0.0
* date:  2019-10-10 08:12:08.084299
*/
#include <bits/stdc++.h>
using namespace std;

int t,k,d[10],n;
string s;

pair<string,string> rec(int c)
{
	if(c==5)
	{
		string tmax="";
		for(int i=0;i+k<=n;i++)
		{
			string tmp="";
			for(int j=i;j<i+k;j++)
			{
				tmp+=s[j];
			}
			tmax=max(tmax,tmp);
		}
		return {s,tmax};
	}
	if(d[c]==0)
	{
		return rec(c+1);
	}
	string tmin="a",tp="";
	for(int i=0;i<n;i++)
	{
		if(s[i]=='0')
		{
			s[i]='0'+c;
			d[c]--;
			pair<string,string> ret=rec(c);
			if(ret.second<tmin)
			{
				tmin=ret.second;
				tp=ret.first;
			}
			d[c]++;
			s[i]='0';
		}
	}
	return {tp,tmin};
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>t;
	while(t--)
	{
		cin>>k;
		for(int i=1;i<=9;i++)
		{
			cin>>d[i];
		}
		n=d[1]+d[2]+d[3]+d[4];
		s="";
		for(int i=0;i<n;i++)
		{
			s+='0';
		}
		cout<<rec(1).first<<"\n";
	}
}
