/**
* user:  perju-verzotti-a3f
* fname: Luca
* lname: Perju-Verzotti
* task:  devil
* score: 0.0
* date:  2019-10-10 10:27:40.785772
*/
#include <iostream>
#include <vector>
using namespace std;
int c[10];
vector <int> v[200006];
int rz[50],k,s;
long long bst[50],mn=-1;
void verif ()
{
    long long vlc=0,p=1,mx;
    int i;
    for(i=1;i<=k;++i)
        p=p*10LL;
    for(i=1;i<=k;++i)
        vlc=vlc*10LL+rz[i];
    mx=vlc;
    for(i=k+1;i<=s;++i)
    {
        vlc=vlc*10LL+rz[i];
        vlc-=p*1LL*rz[i-k];
        mx=max(mx,vlc);
    }
    if(mn==-1 || mn>mx)
    {
        mn=mx;
        for(i=1;i<=s;++i)
            bst[i]=rz[i];
    }
}
void bkt (int pz)
{
    if(pz==s-k+2)
        verif();
    else
    for(int i=1;i<=4;++i)
    {
        if(c[i])
        {
            --c[i];
            rz[pz]=i;
            bkt(pz+1);
            ++c[i];
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(0);
    int t,i,j,kc;
    cin>>t;
    while(t--)
    {
        cin>>k;
        s=0;
        for(i=1;i<=9;++i)
        {
            cin>>c[i];
            s+=c[i];
        }
        j=9;
        for(i=s;i>=s-k+2;--i)
        {
            while(!c[j])
                --j;
            rz[i]=j;
            --c[j];
        }
        bkt(1);
        for(i=1;i<=s;++i)
            cout<<bst[i];
        cout<<'\n';
    }
    return 0;
}
