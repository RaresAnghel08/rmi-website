/**
* user:  vukelic-2d0
* fname: Mateja
* lname: Vukelic
* task:  devil
* score: 14.0
* date:  2019-10-10 10:18:35.721246
*/
#include <bits/stdc++.h>
#define pb push_back
using namespace std;
int t;
int k;
int m;
int dig[15];
vector<int>cif;
void solve(){
    m = 0;
    cif.clear();
    cin >> k;
    for(int i=1; i<10; i++){
        cin >> dig[i];
        m += dig[i];
        for(int j=0; j<dig[i]; j++)cif.pb(i);
    }
    cout << endl;
    if(k == 2){
        //sort(cif.begin(), cif.end());
        if(m == 1){
            cout << cif[0] << endl;
            return;
        }
        else if(m == 2){
            cout << cif[0] << cif[1] << endl;
            return;
        }
        int l = 0;
        int r = m - 2;
        string x = "";
        while(r >= l){
            //cout << cif[r];
            x += char(cif[r] + '0');
            if(l != r)x += char(cif[l] + '0');//cout << cif[l];
            r--;
            l++;
        }
        if(x[x.length() - 1] == x[0])swap(x[x.length()-1], x[1]);
        cout << x;
        cout << cif[m-1] << endl;
        return;
    }
    if(dig[1] + dig[2] == m){
        if(k-1 >= dig[2]){
            for(auto c:cif)cout << c;
            cout << endl;
            return;
        }
        dig[2] -= (k-1);
        int sta = dig[1] / dig[2];
        int y = dig[1] % dig[2];
        int x = dig[2] - y;
        //cout << x << " " << y << " " << sta <<  " " << dig[1] << " " << dig[2] << endl << endl;
        vector<int>v;
        while(x > 0 && y > 0){
            v.pb(2);
            for(int i=0; i<sta+1; i++)v.pb(1);
            v.pb(2);
            for(int i=0; i<sta; i++)v.pb(1);
            x--;
            y--;
        }
        while(x>0){
            v.pb(2);
            for(int i=0; i<sta; i++)v.pb(1);
            x--;
        }
        while(y>0){
            v.pb(2);
            for(int i=0; i<sta+1; i++)v.pb(1);
            y--;
        }
        for(int i=0; i<k-1; i++)v.pb(2);
        for(auto c:v)cout << c;
        cout << endl;
        return;
        //cout << "s";
        while(x > 0 && y > 0){
            for(int i=0; i<sta+1; i++)v.pb(1);
            v.pb(2);
            for(int i=0; i<sta; i++)v.pb(1);
            v.pb(2);
            x--;
            y--;
        }
        //cout << sta << " " << y << " " << x << endl;
        //cout << "a";
        while(x > 0){
            for(int i=0; i<sta; i++)v.pb(1);
            v.pb(2);
            x--;
        }
        //cout << "b";
        while(y > 0){
            for(int i=0; i<sta+1; i++)v.pb(1);
            v.pb(2);
            y--;
        }
        reverse(v.begin(), v.end());
       // cout << "c";
        for(int i=0; i<k-1; i++)v.pb(2);
        for(auto c:v)cout << c;
        cout << endl;
        return;
    }
}
int main()
{
    //ios_base::sync_with_stdio(false);
    cin >> t;
    while(t--)solve();
    return 0;
}
