/**
* user:  florescu-0a6
* fname: Cella
* lname: Florescu
* task:  devil
* score: 0.0
* date:  2019-10-10 08:32:50.632923
*/
#include <bits/stdc++.h>

using namespace std;

const int MAXD = 9;
const int MAXN = 1e6;

int freq[MAXD + 1], v[MAXN + 1];

inline int minc() {
  for (int i = 1; i <= MAXD; ++i)
    if (freq[i])
      return i;
  return MAXD + 1;
}

inline int maxc() {
  for (int i = MAXD; i > 0; --i)
    if (freq[i])
      return i;
  return 0;
}

void subtask1(int n, int k) {}

void subtask2(int n, int k) {
  int mc = maxc();
  if (freq[mc] > 1) {
    v[n] = mc;
    --freq[mc];
    for (int i = 1; i < n; ++i) {
      if (i & 1)
        v[i] = maxc();
      else
        v[i] = minc();
      --freq[v[i]];
    }
    return;
  }
  v[n] = mc;
  --freq[mc];
  if (n == 1)
    return;
  mc = maxc();
  if (n % 2 == 0 && freq[mc] >= n / 2) {
    for (int i = 1; i < n; ++i) {
      v[i] = maxc();
      --freq[v[i]];
    }
    return;
  }
  for (int i = 1; i < n; ++i) {
    if (i & 1)
      v[i] = maxc();
    else
      v[i] = minc();
    --freq[v[i]];
  }
}

void subtask3(int n, int k) {
  if (freq[2] < k) {
    int p = 1;
    for (int i = 0; i < freq[1]; ++i)
      v[p++] = 1;
    for (int i = 0; i < freq[2]; ++i)
      v[p++] = 2;
    return;
  }
  if (freq[2] == k) {
    int p = 2;
    v[1] = 2;
    for (int i = 0; i < freq[1]; ++i)
      v[p++] = 1;
    for (int i = 1; i < freq[2]; ++i)
      v[p++] = 2;
    return;
  }
  if (freq[1] == 0) {
    for (int i = 1; i <= n; ++i)
      v[i] = 2;
    return;
  }
  for (int i = n - k + 2; i <= n; ++i) {
    v[i] = 2;
    --freq[2];
  }
  int ming = n;
  while (1LL * ming * freq[2] > freq[1])
    --ming;
  if (ming > 0) {
    int p = n - k + 1;
    while (p > 0) {
      for (int i = 0; i < ming && p > 0; ++i)
        v[p--] = 1;
      if (freq[2] > 0) {
        v[p--] = 2;
        --freq[2];
      }
    }
    return;
  }
  int maxbatch = freq[2] / freq[1], r = freq[2] % freq[1], p = 1;
  while (freq[1] + freq[2] > 0) {
    for (int i = 0; i < maxbatch && freq[2] > 0; ++i) {
      v[p++] = 2;
      --freq[2];
    }
    if (r > 0) {
      --freq[2];
      v[p++] = 2;
      --r;
    }
    if (freq[1] > 0) {
      --freq[1];
      v[p++] = 1;
    }
  }
}

void subtask4(int n, int k) {}

int main()
{
//    ifstream cin(".in");
//    ofstream cout(".out");
    int t;
    cin >> t;
    for (int test = 0; test < t; ++test) {
      int k, sum = 0, zero = 0;
      cin >> k;
      for (int i = 1; i <= MAXD; ++i) {
        cin >> freq[i];
        sum += freq[i];
        zero += (freq[i] == 0);
      }
      if (k == 2)
        subtask2(sum, k);
      else if (freq[1] + freq[2] == sum)
        subtask3(sum, k);
      else if (sum <= 12)
        subtask1(sum, k);
      else
        subtask4(sum, k);
      for (int i = 1; i <= sum; ++i)
        cout << v[i];
      cout << '\n';
    }
    return 0;
}
