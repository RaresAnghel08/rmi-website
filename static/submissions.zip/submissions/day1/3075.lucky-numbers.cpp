/**
* user:  kliska-f84
* fname: Pavel
* lname: Kliska
* task:  lucky
* score: 0.0
* date:  2019-10-10 10:29:03.078097
*/
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;


int main(){
	int tcc;
	scanf("%d", &tcc);
	for(int tc=0;tc<tcc;++tc){
		int k,o,t, x;
		scanf("%d%d%d", &k, &o, &t);
		for(int i=3;i<=9;++i) scanf("%d", &x);
		vector<int> sol;
		for(int i=0;i<k-1 && t;++i){
			sol.push_back(2);
			t--;
		}
		if(t==0){
			for(int i=0;i<o;++i) sol.push_back(1);
		}else{
			int q = o/t;
			int qpc = o%t;
			int qc = t-qpc;
			while(qc || qpc){
				if(qpc){
					for(int i=0;i<q+1;++i) sol.push_back(1);
					sol.push_back(2);
					qpc--;
				}
				if(qc){	
					for(int i=0;i<q;++i) sol.push_back(1);
					sol.push_back(2);
					qc--;
				}
			}
		}
		reverse(sol.begin(), sol.end());
		for(auto i:sol){
			printf("%d", i);	
		}
		puts("");
	}	
	
}
