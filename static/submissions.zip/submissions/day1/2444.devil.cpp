/**
* user:  bartoli-2aa
* fname: Davide
* lname: Bartoli
* task:  devil
* score: 0.0
* date:  2019-10-10 09:16:47.833227
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<int>a(10);
vector<ll>pot;
int prossimo(){
    for(int i=9;i>0;i--){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int primo(){
    for(int i=1;i<10;i++){
        if(a[i]>0){
            a[i]--;
            return i;
        }
    }
}
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    pot.push_back(1);
    for(int i=0;i<19;i++)pot.push_back((pot[i]*10));
    int T;
    cin>>T;
    while(T--){
        int K;
        cin>>K;
        fill(a.begin(),a.end(),0);
        int tot=0;
        for(int i=1;i<10;i++){
            cin>>a[i];
            tot+=a[i];
        }
        vector<int>sol(tot,0);
        for(int i=tot-1;i>tot-K;i--){
            sol[i]=prossimo();
        }
        vector<int>p;
        for(int i=1;i<10;i++){
            for(int j=0;j<a[i];j++)p.push_back(i);
        }
        int u=p.size();
        ll mi=1000000000000000;
        for(int i=tot-K+1;i<tot;i++)p.push_back(sol[i]);
        while(next_permutation(p.begin(),p.begin()+u)){
            ll minimo=0;
            ll f=0;
            for(int i=0;i<K;i++){
                f*=10;
                f+=p[i];
            }
            minimo=max(minimo,f);
            for(int i=K;i<tot;i++){
                f-=p[i-K]*pot[K-1];
                f*=10;
                f+=p[i];
                minimo=max(minimo,f);
            }
            if(minimo<mi){
                mi=minimo;
                for(int i=0;i<u;i++){
                    sol[i]=p[i];
                }
            }
        }
        for(int i=0;i<tot;i++)cout<<sol[i];
        cout<<endl;
    }
    return 0;
}
