/**
* user:  kanafeev-1f0
* fname: Mark
* lname: Kanafeev
* task:  devil
* score: 0.0
* date:  2019-10-10 10:30:42.166716
*/
#include <bits/stdc++.h>


using namespace std;


#define x first
#define y second


signed main() {
    ios :: sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    for (int ccc = 0; ccc < n; ccc++) {
        int kk[10];
        int k, sm = 0;
        cin >> k;
        for (int i = 1; i <= 9; i++) {
            cin >> kk[i];
            sm += kk[i];
        }
        if (kk[1] == 0 || kk[2] == 0 || kk[2] < k) {
            for (int i = 0; i < kk[1]; i++)
                cout << 1;
            for (int i = 0; i < kk[2]; i++)
                cout << 2;
            cout << '\n';
            continue;
        }
        int l = 1;
        int r = sm;
        while (r - l > 1) {
            int m = (l + r) / 2;
            int cnt = 0, lst;
            for (int i = 0; i <= sm - k + 1; i += m) {
                cnt++;
                lst = i;
            }
            for (int i = lst + m; i < sm; i++)
                cnt++;
            if (cnt >= kk[2])
                l = m;
            else
                r = m;
        }
        int m = l, lst, cnt = 0;
        string ans(sm, '1');
        for (int i = 0; i <= sm - k + 1; i += m) {
            cnt++;
            lst = i;
            ans[i] = '2';
            if (cnt == kk[2])
                break;
        }
        if (cnt != kk[2]) {
            vector<int> pps;
            for (int i = lst + m; i < sm; i++) {
                pps.push_back(i);
            }
            reverse(pps.begin(), pps.end());
            for (int i : pps) {
                cnt++;
                ans[i] = '2';
                if (cnt == kk[2])
                    break;
            }
        }
        cout << ans << '\n';
    }
    return 0;
}
