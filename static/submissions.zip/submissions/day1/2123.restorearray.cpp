/**
* user:  noszaly-f9c
* fname: Áron
* lname: Noszály
* task:  restore
* score: 20.0
* date:  2019-10-10 08:33:32.734547
*/
#include<bits/stdc++.h>
using namespace std;
struct clue {
	int l,r,k,val;
	int len;
};

int main() {
	int n,m;
	cin>>n>>m;
	vector<clue> c(m);
	for(int i=0;i<m;++i) {
		cin>>c[i].l>>c[i].r>>c[i].k>>c[i].val;
		c[i].len=c[i].r-c[i].l+1;
	}
	if(n<=18 && m<=200) {
		for(int i=0;i<(1<<n);++i) {
			vector<int> arr(n);
			for(int j=0;j<n;++j) {
				if((1<<j)&i) {
					arr[j]=1;
				}
			}
			
			for(int j=1;j<n;++j) arr[j]+=arr[j-1];
			bool ok=true;
			for(int j=0;j<m&&ok;++j) {
				int egyes=arr[c[j].r]-(c[j].l>=0?arr[c[j].l-1]:0);
				int nullas=c[j].len-egyes;
				if(c[j].val==0) {
					ok&=c[j].k<=nullas;
				}else {
					//cerr<<nullas<<" "<<egyes<<"\n";
					ok&=c[j].len-c[j].k+1<=egyes;
				}
			}
			if(ok) { 
				for(int j=0;j<n;++j) {
					if((1<<j)&i) {
						cout<<"1";
					}else {
						cout<<"0";
					}
					cout<<" \n"[j==n-1];
				}
				exit(0);
			}
		}
		cout<<"-1\n";
		exit(0);
	}else {
		
		vector<int> ans(n, 0);
		for(int i=0;i<m;++i) {
			if(c[i].k==1) {
				if(c[i].val==0) {
					
				}else {
					for(int j=c[i].l;j<=c[i].r;++j) ans[j]=1;
				}
			}
		}
		
		bool ok=true;
		for(int i=0;i<m;++i) {
			if(c[i].k==1) {
				if(c[i].val==0) {
					bool van=false;
					for(int j=c[i].l;j<=c[i].r;++j) van|=ans[j]==0;
					ok&=van;
				}else {
					
				}
			}
		}
		
		if(!ok) cout<<"-1\n";
		else {
			for(auto i:ans) cout<<i<<" ";
			cout<<"\n";
		}
		
	}
	return 0;
}
