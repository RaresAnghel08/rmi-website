/**
* user:  koynov-034
* fname: Daniel
* lname: Koynov
* task:  devil
* score: 0.0
* date:  2019-10-10 10:31:40.455205
*/
#include<iostream>

using namespace std;
typedef long long ll;


int main()
{
    ll t, k, i, one, two;
    cin >> t;
    for (i = 0; i < t; i ++)
    {
        cin >> k;
        cin >> one >> two;
        ll garbage, j;
        for (j = 3; j < 10; j ++)
            cin >> garbage;

        string aft = "";
        ll p = 0;
        while(two > 0 && p < k - 1)
        {
            aft = "2" + aft;
            two --;
            p ++;
        }
        if (two == 0)
        {
            for (j = 0; j < one; j ++)
                cout << "1";
            cout << aft << endl;
            continue;
        }
        aft = "1" + aft;
        one --;

        if (two > one)
        {

            ll sum = one + two;
            ll ost = two / one;
            ll dd = two % ost;
            ll pp = 0;
            ll jj;
            for (j = 0; j < one; j ++)
            {
                if (pp < dd)
                {
                    cout << "2";
                    p ++;
                }
                for (jj = 0; jj < ost; jj ++)
                    cout << "2";
                cout << "1";
            }
            cout << aft << endl;
        }
        else
        {
            ll sum = one + two;
            ll ost = one / two;
            ll dd = one % ost;
            ll pp = 0, jj;
            for (j = 0; j < two; j ++)
            {
                if (pp < dd)
                {
                    cout << "1";
                }
                for (jj = 0; jj < ost; jj ++)
                    cout << "1";
                cout << "2";
            }
        }
    }
    return 0;
}
