/**
* user:  onut-b62
* fname: Andrei
* lname: Onuț
* task:  restore
* score: 13.0
* date:  2019-10-10 08:51:23.513203
*/
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int NMAX = 5e3 + 5, MMAX = 1e4 + 5;

int N, M;

int A[NMAX];

struct Query
{
    int Left, Right, K, Val;
};

Query V[MMAX];

int dp[NMAX], dp0[NMAX];
int Must_Zero[NMAX];

vector < int > G[MMAX];
bool Marked[MMAX];

int Left[MMAX], Right[MMAX];

static inline bool Final_Check ()
{
    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(V[i].Left == V[i].Right)
            continue;

        if(K == 1)
        {
            if(X == 0)
            {
                if((dp[V[i].Right] - dp[V[i].Left - 1]) == (V[i].Right - V[i].Left + 1))
                    return false;
            }
            else
            {
                if((dp[V[i].Right] - dp[V[i].Left - 1]) != (V[i].Right - V[i].Left + 1))
                    return false;
            }
        }
        else
        {
            if(X == 0)
            {
                if(dp[V[i].Right] - dp[V[i].Left - 1])
                    return false;
            }
            else
            {
                if((dp[V[i].Right] - dp[V[i].Left - 1]) == 0)
                    return false;
            }
        }
    }

    return true;
}

static inline bool Cupleaza (int Node)
{
    Marked[Node] = true;

    for(auto it : G[Node])
        if(!Right[it])
        {
            Right[it] = Node;
            Left[Node] = it;

            return true;
        }

    for(auto it : G[Node])
        if(!Marked[Right[it]] && Cupleaza(Right[it]))
        {
            Right[it] = Node;
            Left[Node] = it;

            return true;
        }

    return false;
}

int main()
{
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);

    cin >> N >> M;

    for(int i = 1; i <= M; ++i)
    {
        cin >> V[i].Left >> V[i].Right >> V[i].K >> V[i].Val;

        ++V[i].Left;
        ++V[i].Right;

        if(V[i].Left == V[i].Right)
        {
            if(V[i].Val == 1)
            {
                if(Must_Zero[V[i].Left])
                {
                    cout << -1 << '\n';

                    return 0;
                }

                A[V[i].Left] = 1;
            }
            else
            {
                if(A[V[i].Left])
                {
                    cout << -1 << '\n';

                    return 0;
                }

                Must_Zero[i] = 1;
            }
        }
    }

    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(K == 1)
        {
            if(X == 1)
            {
                for(int j = V[i].Left; j <= V[i].Right; ++j)
                    if(Must_Zero[j] == false)
                        A[j] = 1;
                    else
                    {
                        cout << -1 << '\n';

                        return 0;
                    }
            }
        }
    }

    dp[0] = 0;
    for(int i = 1; i <= N; ++i)
        dp[i] = dp[i - 1] + A[i];

    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(K != 1)
        {
            if(X == 1)
                continue;

            if(dp[V[i].Right] - dp[V[i].Left - 1])
            {
                cout << -1 << '\n';

                return 0;
            }

            for(int j = V[i].Left; j <= V[i].Right; ++j)
                if(A[j] == 0)
                    Must_Zero[j] = true;
                else
                {
                    cout << -1 << '\n';

                    return 0;
                }
        }
    }

    dp0[0] = 0;
    for(int i = 1; i <= N; ++i)
        dp0[i] = dp0[i - 1] + Must_Zero[i];
    ///OK pana aici;

    ///Verific ce a ramas nesatisfacut;

    for(int i = 1; i <= M; ++i)
    {
        int K = V[i].K;
        int X = V[i].Val;

        if(V[i].Left == V[i].Right)
            continue;

        if(K == 1 && X == 0)
        {
            if(dp0[V[i].Right] - dp0[V[i].Left - 1])
                continue;

            for(int j = V[i].Left; j <= V[i].Right; ++j)
                if(A[j] != 1)
                    G[i].push_back(j);
        }
        else
        {
            if(K != 1 && X == 1)
            {
                if(dp[V[i].Right] - dp[V[i].Left - 1])
                    continue;

                for(int j = V[i].Left; j <= V[i].Right; ++j)
                    if(!Must_Zero[j])
                        G[i].push_back(j);
            }
        }
    }

    bool done = true;

    while(done)
    {
        done = false;

        for(int i = 1; i <= M; ++i)
            Marked[i] = false;

        for(int i = 1; i <= M; ++i)
            if(!Left[i] && !Marked[i])
                done |= Cupleaza(i);
    }

    for(int i = 1; i <= M; ++i)
        if(Left[i])
        {
            int K = V[i].K;
            int X = V[i].Val;

            if(V[i].Left == V[i].Right)
                continue;

            if(K != 1 && X == 1)
                A[Left[i]] = 1;
        }

    ///?

    /// OK de aici in jos;
    dp[0] = 0;
    for(int i = 1; i <= N; ++i)
        dp[i] = dp[i - 1] + A[i];

    if(!Final_Check())
    {
        cout << -1 << '\n';

        return 0;
    }

    for(int i = 1; i <= N; ++i)
        cout << A[i] << ' ';

    cout << '\n';

    return 0;
}
