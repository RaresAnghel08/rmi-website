/**
* user:  pavic-9e7
* fname: Patrick
* lname: Pavić
* task:  devil
* score: 0.0
* date:  2019-10-10 10:38:12.166300
*/
#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

#define PB push_back

using namespace std;

const int N = 1e5 + 500;
const int ALP = 12;

int D[ALP], T, K, n;
string bst = "", cur;

string get(string s){
	string ret = "";
	for(int i = 0;i < (int)s.size() - K +  1;i++)
		ret = max(ret, s.substr(i, K));
	return ret;
}

void gen(){
	if(cur.size() == n){
		if(bst == "" || get(cur) < get(bst))
			bst = cur;
		return;
	}
	if(get(cur) > get(bst) && bst != "") return;
	for(int i = 1;i < 5;i++){
		if(D[i] > 0){
			cur.PB('0' + i);
			D[i]--;gen();D[i]++;
			cur.pop_back();
		}
	}
}


int main(){
	//ios_base::sync_with_stdio(false);
	//cin.tie(0);
	cin >> T;
	//T = 1;
	for(int asd = 0;asd < T;asd++){
		bst = ""; cur = "";
		cin >> K; n = 0;
		for(int i = 1;i <= 9;i++)
			cin >> D[i], n += D[i];
		gen(); cout << bst << endl;
	}
}

