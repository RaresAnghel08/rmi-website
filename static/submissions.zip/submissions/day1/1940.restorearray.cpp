/**
* user:  kwiatkowski-76e
* fname: Jan
* lname: Kwiatkowski
* task:  restore
* score: 7.0
* date:  2019-10-10 08:11:27.646337
*/
#include <bits/stdc++.h>

using namespace std;

#define f first
#define s second

const int MAXN = 203;
const int MAXM = 23;
pair<pair<int, int>, pair<int, int> > zap[MAXN];
int t[MAXM];
int pref[MAXM];

int main() {
    int n, m;
    int l, r, k, val;
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= m; i++) {
        scanf("%d %d %d %d", &zap[i].f.f, &zap[i].f.s, &zap[i].s.f, &zap[i].s.s);
        zap[i].f.f++;
        zap[i].f.s++;
    }
    int mx = 1 << n;
    int x, licz;
    bool por;
    for (int i = 0; i < mx; i++) {
        x = i;
        licz = 1;
        while (licz <= n) {
            t[licz] = x & 1;
            x >>= 1;
            licz++;
        }
        for (int j = 1; j <= n; j++) {
            pref[j] = pref[j - 1];
            if (t[j] == 0)
                pref[j]++;
        }
        /*
        for (int j = 1; j <= n; j++)
            printf("%d ", pref[j]);
        printf("\n");
        */
        por = false;
        for (int j = 1; j <= m; j++) {
            if (zap[j].s.s == 0) {
                if (pref[zap[j].f.s] - pref[zap[j].f.f - 1] < zap[j].s.f) {
                    por = true;
                    break;
                }
            }
            else {
                if (pref[zap[j].f.s] - pref[zap[j].f.f - 1] >= zap[j].s.f) {
                    por = true;
                    break;
                }
            }
        }
        if (por)
            continue;
        for (int j = 1; j <= n; j++)
            printf("%d ", t[j]);
        return 0;
    }
    printf("-1");
    return 0;
}

