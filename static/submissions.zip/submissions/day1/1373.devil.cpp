/**
* user:  nanu-c77
* fname: Ruxandra Laura
* lname: Nanu
* task:  devil
* score: 14.0
* date:  2019-10-10 06:30:07.528291
*/
#include <cstdio>

using namespace std;
FILE *fin = stdin;
FILE *fout = stdout;
int sum;
int s[10],sol[1000010];
void subtask2(){
    int poz,i;
    poz = sum;
    for (i=9;i;i--){
        while (poz>0 && s[i]){
            sol[poz] = i;
            s[i]--;
            poz-=2;
        }
    }
    if (poz == 0)
        poz = 1;
    else if (poz == -1)
        poz = 2;
    for (i=9;i;i--){
        while (poz<=sum && s[i]){
            sol[poz] = i;
            s[i]--;
            poz+=2;
        }
    }
    for (i=1;i<=sum;i++){
        fprintf (fout,"%d",sol[i]);
    }
    fprintf (fout,"\n");

}
void subtask3(){
}
int main()
{

    int t,k,i;
    fscanf (fin,"%d",&t);
    for (;t;t--){
        fscanf (fin,"%d",&k);
        sum = 0;
        for (i=1;i<=9;i++){
            fscanf (fin,"%d",&s[i]);
            sum+=s[i];
        }
        if (k==2){
            subtask2();
        }
        else if (s[3] == 0 && s[4] == 0 && s[5] == 0 && s[6] == 0 && s[7] == 0 && s[8] == 0 && s[9] == 0){
            subtask3();
        }
    }
    return 0;
}
