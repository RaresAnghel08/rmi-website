/**
* user:  kopchev-ba2
* fname: Martin
* lname: Kopchev
* task:  restore
* score: 13.0
* date:  2019-10-10 06:53:59.270567
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=1e4+42;

int n,m;

struct query
{
    int l,r,k,value;
};

query there[nmax];

int output[nmax];

bool test()
{
    for(int i=1;i<=m;i++)
    {
        int zeros=0;
        for(int j=there[i].l;j<=there[i].r;j++)
            if(output[j]==0)zeros++;

        if(there[i].value==0&&zeros<there[i].k)return 0;
        if(there[i].value==1&&zeros>=there[i].k)return 0;
    }
    return 1;
}
int main()
{
    scanf("%i%i",&n,&m);
    for(int i=1;i<=m;i++)
    {
        query now;
        scanf("%i%i%i%i",&now.l,&now.r,&now.k,&now.value);

        there[i]=now;

        assert(now.k==1);

        if(now.value==1)
        {
            for(int j=now.l;j<=now.r;j++)
                output[j]=1;
        }
    }

    if(test())
    {
        for(int i=0;i<n;i++)
            printf("%i ",output[i]);
        printf("\n");
    }
    else
    {
        printf("-1\n");
    }
    return 0;
}
