#include "weirdtree.h"

void initialise(int N, int Q, int h[]) {
	// Your code here.
}
void cut(int l, int r, int k) {
	// Your code here.
}
void magic(int i, int x) {
	// Your code here.
}
long long int inspect(int l, int r) {
	// Your code here.
	return -1;
}
