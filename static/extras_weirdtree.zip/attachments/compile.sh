#!/bin/sh

g++ -DEVAL -O2 -std=c++11 grader.cpp weirdtree.cpp -o weirdtree
