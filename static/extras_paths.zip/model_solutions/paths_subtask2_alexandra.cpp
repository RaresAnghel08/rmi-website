//N^2 * K^2
#include<iostream>
#include<vector>
#include<cstring>
#include<stdlib.h>
#include<time.h>
using namespace std;
int n, i, x, y, c, k;
long long d[1005][1005];
vector< pair<int, int> > v[1005];
void dfs(int nod, int t) {
    for (int i = 0; i < v[nod].size(); i++) {
        int fiu = v[nod][i].first;
        if (fiu == t) {
            continue;
        }
        dfs(fiu, nod);
        for (int j = k; j >= 1; j--) {
            d[nod][j] = max(d[nod][j], d[nod][j - 1] + v[nod][i].second);
            for (int jj = 1; jj <= j; jj++) {
                d[nod][j] = max(d[nod][j], d[nod][j - jj] + d[fiu][jj] + v[nod][i].second);
            }
        }
    }
}
int main() {
    cin>> n >> k;
    for (i = 1; i < n; i++) {
        cin>> x >> y >> c;
        v[x].push_back(make_pair(y, c));
        v[y].push_back(make_pair(x, c));
    }
    for (i = 1; i <= n; i++) {
        memset(d, 0, sizeof(d));
        dfs(i, 0);
        cout<< d[i][k] <<"\n";
    }
}
