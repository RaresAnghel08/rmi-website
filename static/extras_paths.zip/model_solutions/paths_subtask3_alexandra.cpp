// N * K^2
#include<iostream>
#include<vector>
using namespace std;
int n, k, i, x, y, c, j;
int tcost[2005];
long long djos[2005][2005], dsus[2005][2005], daux[2005][2005], sol;
vector< pair<int, int> > v[2005];
int nxt(int nod, int t, int i) {
    if (i == v[nod].size() - 1) {
        return 0;
    }
    if (v[nod][i + 1].first != t) {
        return v[nod][i + 1].first;
    }
    if (i + 1 != v[nod].size() - 1) {
        return v[nod][i + 2].first;
    }
    return 0;
}
int prv(int nod, int t, int i) {
    if (i == 0) {
        return 0;
    }
    if (v[nod][i - 1].first != t) {
        return v[nod][i - 1].first;
    }
    if (i - 1 != 0) {
        return v[nod][i - 2].first;
    }
    return 0;
}
void dfs(int nod, int t) {
    int i, j, jj, fiu;
    for (i = 0; i < v[nod].size(); i++) {
        fiu = v[nod][i].first;
        if (fiu == t) {
            tcost[nod] = v[nod][i].second;
            continue;
        }
        dfs(fiu, nod);
        for (j = k; j >= 1; j--) {
            for (jj = 1; jj <= j; jj++) {
                djos[nod][j] = max(djos[nod][j], djos[nod][j - jj] + djos[fiu][jj] + v[nod][i].second);
            }
        }
        if (nxt(nod, t, i)) {
            fiu = nxt(nod, t, i);
            for (j = 1; j <= k; j++) {
                dsus[fiu][j] = djos[nod][j];
            }
        }
    }

    for (i = v[nod].size() - 1; i >= 1; i--) {
        fiu = v[nod][i].first;
        if (fiu == t) {
            continue;
        }
        for (j = k; j >= 1; j--) {
            for (jj = 1; jj <= j; jj++) {
                daux[nod][j] = max(daux[nod][j], daux[nod][j - jj] + djos[fiu][jj] + v[nod][i].second);
            }
        }
        if (prv(nod, t, i)) {
            fiu = prv(nod, t, i);
            for (j = k; j >= 1; j--) {
                for (jj = 1; jj <= j; jj++) {
                    dsus[fiu][j] = max(dsus[fiu][j], dsus[fiu][j - jj] + daux[nod][jj]);
                }
            }
        }
    }
}
void dfs2(int nod, int t) {
    int i, j, fiu;
    for (i = k; i >= 1; i--) {
        for (j = 1; j <= i; j++) {
            dsus[nod][i] = max(dsus[nod][i], dsus[nod][i - j] + dsus[t][j]);
        }
        dsus[nod][i] += tcost[nod];
    }
    for (i = 0; i < v[nod].size(); i++) {
        if (v[nod][i].first != t) {
            dfs2(v[nod][i].first, nod);
        }
    }
}
int main() {
    cin>> n >> k;
    for (i = 1; i < n; i++) {
        cin>> x >> y >> c;
        v[x].push_back(make_pair(y, c));
        v[y].push_back(make_pair(x, c));
    }
    dfs(1, 0);
    dfs2(1, 0);
    for (i = 1; i <= n; i++) {
        sol = 0;
        for (j = 0; j <= k; j++) {
            sol = max(sol, djos[i][j] + dsus[i][k - j]);
        }
        cout<< sol <<"\n";
    }
}
