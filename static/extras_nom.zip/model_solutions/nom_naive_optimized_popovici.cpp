#include <iostream>
#include <fstream>
#include <algorithm>
 
/*
     Time       O(M * N ^ 2)
     Memory     O(M * N)
*/
 
 
constexpr int MOD = (int)1e9 + 7;
constexpr int MAXN = 3000;
constexpr int MAXM = 3000;
 
int dp[MAXM + 1][MAXN + 1];
 
int comb[2 * MAXN + 1][2 * MAXN + 1];
int pow2[2 * MAXN + 1], fact[2 * MAXN + 1];
int counter[MAXM];
 
inline void add(int& x, int y) {
    x += y;
    if (x >= MOD)
        x -= MOD;
}
 
void prec(int N, int M) {
    for (int i = 0; i <= 2 * N; i++) {
        comb[i][0] = 1;
        for (int j = 1; j <= i; j++) {
            add(comb[i][j], comb[i - 1][j]);
            add(comb[i][j], comb[i - 1][j - 1]);
        }
    }
 
    for (int i = 0; i < 2 * N; i++) {
        counter[i % M]++;
    }
 
    pow2[0] = fact[0] = 1;
    for (int i = 1; i <= 2 * N; i++) {
        pow2[i] = (2LL * pow2[i - 1]) % MOD;
        fact[i] = (1LL * i * fact[i - 1]) % MOD;
    }
}
 
 
 
int main() {
    std::istream& fin = std::cin;
    std::ostream& fout = std::cout;
 
    int N, M;
    fin >> N >> M;
 
    prec(N, M);
    
    dp[M][N] = 1;
    int used = 0;
 
    for (int rem = M; rem > 0; rem--) {
        used += counter[rem];
        for (int pairs = 0; pairs <= N; pairs++) {
            if (dp[rem][pairs] == 0) 
                continue;
 
            int need = counter[rem - 1];
            for (int p = 0; p <= pairs; p++) {
                int others = 2 * N - 2 * pairs - used;
 
                if (need > p + others || need < p)
                    continue;
 
                int current = (1LL * comb[pairs][p] * comb[others][need - p]) % MOD;
                // current = (1LL * current * pow2[p]) % MOD;
                current = (1LL * current * dp[rem][pairs]) % MOD;
                add(dp[rem - 1][pairs - p], current);
            }
        }
    }
 
    int answer = (1LL * dp[0][0] * pow2[N]) % MOD;
    for (int rem = 0; rem < M; rem++) {
        answer = (1LL * answer * fact[counter[rem]]) % MOD;
    }
 
    fout << answer << "\n";
 
    return 0;
}