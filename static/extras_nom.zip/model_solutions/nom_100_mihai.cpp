#include <bits/stdc++.h>
 
using namespace std;
 
const int DIM = 2000;
const int mod = 1e9 + 7;
 
int comb[2 * DIM + 1][2 * DIM + 1];
int fact[2 * DIM + 1];
int cnt[DIM + 1];
int dp[DIM + 1][DIM + 1];
int pre[DIM + 1];
 
inline void add(int& x, int y) {
    x += y;
    if (x >= mod)
        x -= mod;
}
 
void precalc(int n, int m)
{
    fact[0] = 1;
 
    for(int i = 0; i <= 2 * n; ++i)
    {
        comb[i][0] = 1;
 
        if(i >= 1)
            fact[i] = (fact[i - 1] * 1LL * i) % mod;
 
        for(int j = 1; j <= i; ++j)
        {
            add(comb[i][j], comb[i - 1][j]);
            add(comb[i][j], comb[i - 1][j - 1]);
        }
    }
 
    for(int i = 0; i < 2 * n; ++i)
        ++cnt[i % m];
 
    pre[0] = cnt[0];
 
    for(int i = 1; i < m; ++i)
        pre[i] = pre[i - 1] + cnt[i];
}
 
main()
{
    int n, m;
    cin >> n >> m;
 
    precalc(n, m);
 
    dp[0][0] = (comb[n][cnt[0]] * 1LL * fact[cnt[0]]) % mod;
 
    for(int rest = 0; rest < m - 1; ++rest)
        for(int dubluri = 0; dubluri <= n; ++dubluri)
            if(dp[rest][dubluri])
            {
                for(int extra = 0; extra <= cnt[rest + 1] && extra + dubluri <= n; ++extra)
                {
                    int a = dp[rest][dubluri];
                    int b = comb[pre[rest] - 2 * dubluri][extra];
                    int c = comb[n - pre[rest] + dubluri][cnt[rest + 1] - extra];
                    int d = fact[cnt[rest + 1]];
 
                    a = (a * 1LL * b) % mod;
                    a = (a * 1LL * c) % mod;
                    a = (a * 1LL * d) % mod;
 
                    add(dp[rest + 1][dubluri + extra], a);
                }
            }
 
    int ans = dp[m - 1][n];
 
    for(int i = 1; i <= n; ++i)
        ans = (ans * 2) % mod;
 
    cout << ans << '\n';
}